import { useState, useEffect, useCallback } from 'react';
import {
  Box, Container, Typography, Paper, Card, Button,
  TextField, Alert, CircularProgress, Chip,
  Dialog, DialogTitle, DialogContent, DialogActions,
  IconButton, Menu, MenuItem, Snackbar
} from '@mui/material';
import {
  Add, MoreVert, Delete, Edit,
  ThumbUp, Comment, Share, Person, Visibility
} from '@mui/icons-material';
import { useRouter } from 'next/router';
import { styled } from '@mui/material/styles';
import { Layout } from '../components/AllComponents';
import api from '../components/axiosConfig';
import { useAuth } from '../components/AuthContext';

// 修复：正确的 styled 组件语法
const PostCard = styled(Card)(({ theme }) => ({
  padding: theme.spacing(3),
  marginBottom: theme.spacing(2),
  borderRadius: 12,
  boxShadow: '0 2px 12px rgba(0,0,0,0.08)',
  transition: 'all 0.3s ease',
  border: '1px solid rgba(0,0,0,0.05)',
  '&:hover': {
    boxShadow: '0 4px 20px rgba(0,0,0,0.12)',
    transform: 'translateY(-2px)'
  }
}));

const ActionSection = styled(Box)(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
  marginTop: theme.spacing(2),
  paddingTop: theme.spacing(2),
  borderTop: '1px solid rgba(0,0,0,0.08)'
}));

// 帖子详情对话框
const PostDetailDialog = ({ open, onClose, post }) => {
  if (!post) return null;

  return (
    <Dialog
      open={open}
      onClose={onClose}
      maxWidth="md"
      fullWidth
      PaperProps={{
        sx: { borderRadius: 2, maxHeight: '80vh' }
      }}
    >
      <DialogTitle sx={{
        borderBottom: '1px solid rgba(0,0,0,0.08)',
        pb: 2
      }}>
        {post.title}
      </DialogTitle>

      <DialogContent sx={{ pt: 3 }}>
        {/* 作者信息 */}
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 3 }}>
          <Person sx={{ color: 'primary.main', fontSize: 20 }} />
          <Typography variant="subtitle1" fontWeight="600">
            {post.author || '匿名用户'}
          </Typography>
          <Typography variant="caption" color="text.secondary">
            · {formatTime(post.createdAt)}
          </Typography>
        </Box>

        {/* 帖子内容 */}
        <Typography
          variant="body1"
          sx={{
            lineHeight: 1.8,
            whiteSpace: 'pre-wrap',
            fontSize: '1.1rem'
          }}
        >
          {post.content || '暂无内容'}
        </Typography>

        {/* 统计信息 */}
        <Box sx={{
          display: 'flex',
          gap: 3,
          mt: 4,
          pt: 2,
          borderTop: '1px solid rgba(0,0,0,0.08)'
        }}>
          <Typography variant="caption" color="text.secondary">
            👍 {post.likes || 0} 点赞
          </Typography>
          <Typography variant="caption" color="text.secondary">
            💬 {post.comments || 0} 评论
          </Typography>
          <Typography variant="caption" color="text.secondary">
            👁️ {post.views || 0} 浏览
          </Typography>
          {post.readingTime > 0 && (
            <Typography variant="caption" color="text.secondary">
              ⏱️ {post.readingTime} 分钟阅读
            </Typography>
          )}
        </Box>
      </DialogContent>

      <DialogActions sx={{ px: 3, pb: 3 }}>
        <Button onClick={onClose}>
          关闭
        </Button>
      </DialogActions>
    </Dialog>
  );
};

// 论坛API服务
const forumService = {
  // 获取帖子列表
  getPosts: async () => {
    try {
      const response = await api.get('/api/forum/posts');
      console.log('📦 获取帖子列表响应:', response.data);
      return response.data;
    } catch (error) {
      console.error('获取帖子列表失败:', error);
      throw error;
    }
  },

  // 创建新帖子
  createPost: async (postData) => {
    try {
      console.log('📤 发送创建帖子请求:', postData);
      const response = await api.post('/api/forum/posts', postData);
      console.log('✅ 创建帖子响应:', response.data);
      return response.data;
    } catch (error) {
      console.error('创建帖子失败:', error);
      throw error;
    }
  },

  // 删除帖子
  deletePost: async (postId) => {
    try {
      const response = await api.delete(`/api/forum/posts/${postId}`);
      return response.data;
    } catch (error) {
      console.error('删除帖子失败:', error);
      throw error;
    }
  },

  // 获取单个帖子详情
  getPostDetail: async (postId) => {
    try {
      const response = await api.get(`/api/forum/posts/${postId}`);
      return response.data;
    } catch (error) {
      console.error('获取帖子详情失败:', error);
      throw error;
    }
  },

  // 上传文件
  uploadFile: async (formData) => {
    try {
      const response = await api.post('/api/forum/posts/upload', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
      return response.data;
    } catch (error) {
      console.error('上传文件失败:', error);
      throw error;
    }
  },

  // 获取帖子附件
  getPostAttachments: async (postId) => {
    try {
      const response = await api.get(`/api/forum/posts/${postId}/attachments`);
      return response.data;
    } catch (error) {
      console.error('获取附件失败:', error);
      return [];
    }
  }
};

// 工具函数
const formatTime = (dateString) => {
  if (!dateString) return '未知时间';

  try {
    const date = new Date(dateString);
    const now = new Date();
    const diffInMs = now - date;
    const diffInHours = diffInMs / (1000 * 60 * 60);

    if (diffInHours < 1) {
      const minutes = Math.floor(diffInMs / (1000 * 60));
      return minutes < 1 ? '刚刚' : `${minutes}分钟前`;
    } else if (diffInHours < 24) {
      return `${Math.floor(diffInHours)}小时前`;
    } else {
      return date.toLocaleDateString('zh-CN', {
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
    }
  } catch (error) {
    return '未知时间';
  }
};

// 单个帖子组件
const PostItem = ({ post, currentUser, onDelete, onViewDetail }) => {
  const [menuAnchor, setMenuAnchor] = useState(null);
  const [isDeleting, setIsDeleting] = useState(false);

  // 修复：检查是否是作者
  const isAuthor = currentUser && post.author === currentUser.username;

  const handleMenuOpen = (event) => {
    setMenuAnchor(event.currentTarget);
  };

  const handleMenuClose = () => {
    setMenuAnchor(null);
  };

  const handleDelete = async () => {
    if (!window.confirm('确定要删除这个帖子吗？此操作不可撤销。')) {
      return;
    }

    setIsDeleting(true);
    try {
      await onDelete(post.ID);
    } catch (error) {
      console.error('删除失败:', error);
    } finally {
      setIsDeleting(false);
      handleMenuClose();
    }
  };

  const handleViewDetail = () => {
    onViewDetail(post);
  };

  // 生成内容预览
  const getContentPreview = () => {
    const content = post.content || post.excerpt || '';
    if (content.length > 150) {
      return content.substring(0, 150) + '...';
    }
    return content;
  };

  return (
    <PostCard>
      {/* 帖子标题和操作菜单 */}
      <Box sx={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'flex-start',
        mb: 2
      }}>
        <Typography
          variant="h6"
          sx={{
            fontWeight: 600,
            lineHeight: 1.4,
            flex: 1,
            cursor: 'pointer',
            '&:hover': { color: 'primary.main' }
          }}
          onClick={handleViewDetail}
        >
          {post.title || '无标题'}
        </Typography>

        {/* 更多操作菜单 */}
        {isAuthor && (
          <>
            <IconButton
              size="small"
              onClick={handleMenuOpen}
              disabled={isDeleting}
            >
              <MoreVert />
            </IconButton>
            <Menu
              anchorEl={menuAnchor}
              open={Boolean(menuAnchor)}
              onClose={handleMenuClose}
            >
              <MenuItem onClick={handleMenuClose}>
                <Edit sx={{ mr: 1, fontSize: 18 }} />
                编辑
              </MenuItem>
              <MenuItem onClick={handleDelete} disabled={isDeleting}>
                <Delete sx={{ mr: 1, fontSize: 18 }} />
                {isDeleting ? '删除中...' : '删除'}
              </MenuItem>
            </Menu>
          </>
        )}
      </Box>

      {/* 帖子内容预览 */}
      <Box sx={{ cursor: 'pointer' }} onClick={handleViewDetail}>
        <Typography
          variant="body1"
          color="text.secondary"
          sx={{
            lineHeight: 1.6,
            mb: 2,
            minHeight: '40px'
          }}
        >
          {getContentPreview()}
        </Typography>

        {/* 标签 */}
        {post.category && post.category !== 'general' && (
          <Chip
            label={post.category}
            size="small"
            color="primary"
            variant="outlined"
            sx={{ mr: 1, mb: 1 }}
          />
        )}
      </Box>

      {/* 互动区域 */}
      <ActionSection>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
          <Button
            size="small"
            startIcon={<ThumbUp />}
            sx={{
              color: 'text.secondary',
              minWidth: 'auto',
              '&:hover': {
                backgroundColor: 'rgba(25, 118, 210, 0.04)',
                color: 'primary.main'
              }
            }}
          >
            {post.likes || 0}
          </Button>

          <Button
            size="small"
            startIcon={<Comment />}
            sx={{
              color: 'text.secondary',
              minWidth: 'auto',
              '&:hover': {
                backgroundColor: 'rgba(0, 0, 0, 0.04)',
                color: 'text.primary'
              }
            }}
          >
            {post.comments || 0}
          </Button>

          <Button
            size="small"
            startIcon={<Share />}
            sx={{
              color: 'text.secondary',
              minWidth: 'auto',
              '&:hover': {
                backgroundColor: 'rgba(0, 0, 0, 0.04)',
                color: 'text.primary'
              }
            }}
          >
            分享
          </Button>

          <Button
            size="small"
            startIcon={<Visibility />}
            onClick={handleViewDetail}
            sx={{
              color: 'primary.main',
              minWidth: 'auto',
              '&:hover': {
                backgroundColor: 'rgba(25, 118, 210, 0.04)',
              }
            }}
          >
            查看详情
          </Button>
        </Box>

        {/* 作者和阅读信息 */}
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <Person sx={{ color: 'text.secondary', fontSize: 16 }} />
          <Typography variant="caption" color="text.secondary">
            {post.author || '匿名用户'}
          </Typography>
          <Typography variant="caption" color="text.secondary">
            ·
          </Typography>
          <Typography variant="caption" color="text.secondary">
            {post.views || 0} 阅读
          </Typography>
          {post.readingTime > 0 && (
            <>
              <Typography variant="caption" color="text.secondary">
                ·
              </Typography>
              <Typography variant="caption" color="text.secondary">
                {post.readingTime} 分钟
              </Typography>
            </>
          )}
          <Typography variant="caption" color="text.secondary">
            · {formatTime(post.createdAt)}
          </Typography>
        </Box>
      </ActionSection>
    </PostCard>
  );
};

// 发布帖子对话框
const CreatePostDialog = ({ open, onClose, onSubmit, currentUser }) => {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!title.trim() || !content.trim()) return;

    setIsSubmitting(true);
    try {
      const postData = {
        title: title.trim(),
        content: content.trim(),
        category: "general",
        tags: [],
        excerpt: content.trim().substring(0, 100) + (content.length > 100 ? '...' : '')
      };

      await onSubmit(postData);
      setTitle('');
      setContent('');
      onClose();
    } catch (error) {
      console.error('发布失败:', error);
      throw error;
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleClose = () => {
    if (!isSubmitting) {
      setTitle('');
      setContent('');
      onClose();
    }
  };

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      maxWidth="md"
      fullWidth
      PaperProps={{
        sx: { borderRadius: 2 }
      }}
    >
      <DialogTitle sx={{
        borderBottom: '1px solid rgba(0,0,0,0.08)',
        pb: 2
      }}>
        发布新帖子
      </DialogTitle>

      <form onSubmit={handleSubmit}>
        <DialogContent sx={{ pt: 3 }}>
          <TextField
            fullWidth
            label="帖子标题"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            margin="normal"
            required
            placeholder="请输入帖子标题..."
            sx={{ mb: 3 }}
          />

          <TextField
            fullWidth
            label="帖子内容"
            value={content}
            onChange={(e) => setContent(e.target.value)}
            multiline
            rows={6}
            margin="normal"
            required
            placeholder="请输入帖子内容..."
          />

          {/* 用户认证状态提示 */}
          {!currentUser && (
            <Alert severity="warning" sx={{ mt: 2 }}>
              请先登录后再发布帖子
            </Alert>
          )}
        </DialogContent>

        <DialogActions sx={{
          px: 3,
          pb: 3,
          gap: 1
        }}>
          <Button
            onClick={handleClose}
            disabled={isSubmitting}
          >
            取消
          </Button>
          <Button
            type="submit"
            variant="contained"
            disabled={isSubmitting || !title.trim() || !content.trim() || !currentUser}
            sx={{
              minWidth: 100,
              borderRadius: 2
            }}
          >
            {isSubmitting ? <CircularProgress size={20} /> : '发布'}
          </Button>
        </DialogActions>
      </form>
    </Dialog>
  );
};

// 主论坛组件
const ForumSection = ({ config }) => {
  const { user: currentUser, loading: authLoading } = useAuth();
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [detailDialogOpen, setDetailDialogOpen] = useState(false);
  const [selectedPost, setSelectedPost] = useState(null);
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: '',
    severity: 'success'
  });

  // 加载帖子数据
  const loadPosts = useCallback(async () => {
    setLoading(true);
    try {
      const result = await forumService.getPosts();
      console.log('📦 解析后的帖子数据:', result);

      // 适配后端数据结构
      const postsData = result.posts || result.Posts || [];
      setPosts(postsData);
      setError('');
    } catch (err) {
      console.error('❌ 加载帖子失败:', err);
      setError('加载帖子失败，请刷新页面重试');
      setPosts([]);
    } finally {
      setLoading(false);
    }
  }, []);

  // 初始化加载 - 等待认证检查完成
  useEffect(() => {
    if (!authLoading) {
      loadPosts();
    }
  }, [authLoading, loadPosts]);

  // 显示提示消息
  const showSnackbar = (message, severity = 'success') => {
    setSnackbar({ open: true, message, severity });
  };

  // 处理发布帖子
  const handleCreatePost = async (postData) => {
    try {
      await forumService.createPost(postData);
      showSnackbar('帖子发布成功！');
      // 重新加载帖子列表
      await loadPosts();
    } catch (error) {
      console.error('❌ 发布帖子错误:', error);
      const errorMessage = error.response?.data?.message ||
                          error.response?.data?.error ||
                          '发布失败，请重试';
      showSnackbar(errorMessage, 'error');

      // 如果是白名单认证错误
      if (error.response?.status === 403) {
        showSnackbar('您没有发布帖子的权限，请联系管理员添加到白名单', 'error');
      }
      throw error;
    }
  };

  // 处理删除帖子
  const handleDeletePost = async (postId) => {
    try {
      await forumService.deletePost(postId);
      showSnackbar('帖子删除成功！');
      // 重新加载帖子列表
      await loadPosts();
    } catch (error) {
      console.error('❌ 删除帖子错误:', error);
      showSnackbar(
        error.response?.data?.message || '删除失败，请重试',
        'error'
      );
      throw error;
    }
  };

  // 处理查看帖子详情
  const handleViewDetail = (post) => {
    setSelectedPost(post);
    setDetailDialogOpen(true);
  };

  const handleCloseDetail = () => {
    setDetailDialogOpen(false);
    setSelectedPost(null);
  };

  // 如果认证检查还在进行，显示加载状态
  if (authLoading) {
    return (
      <Box sx={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        minHeight: '50vh',
        flexDirection: 'column'
      }}>
        <CircularProgress size={40} />
        <Typography sx={{ mt: 2 }}>检查认证状态...</Typography>
      </Box>
    );
  }

  return (
    <Box sx={{
      minHeight: '100vh',
      background: 'linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%)',
      py: 4
    }}>
      <Container maxWidth="md">
        {/* 头部 */}
        <Paper
          elevation={0}
          sx={{
            p: 4,
            mb: 4,
            borderRadius: 3,
            background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
            color: 'white',
            textAlign: 'center'
          }}
        >
          <Typography
            variant="h3"
            component="h1"
            fontWeight="700"
            sx={{ mb: 2 }}
          >
            技术论坛
          </Typography>
          <Typography variant="h6" sx={{ opacity: 0.9 }}>
            分享知识，交流技术，共同成长
          </Typography>
        </Paper>

        {/* 操作栏 */}
        <Box sx={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          mb: 4
        }}>
          <Typography variant="h5" fontWeight="600">
            最新帖子 ({posts.length})
          </Typography>

          <Button
            variant="contained"
            startIcon={<Add />}
            onClick={() => setCreateDialogOpen(true)}
            size="large"
            sx={{
              borderRadius: 2,
              px: 3,
              py: 1
            }}
            disabled={!currentUser}
          >
            {currentUser ? '发布帖子' : '请先登录'}
          </Button>
        </Box>

        {/* 用户状态提示 */}
        {!currentUser && (
          <Alert severity="info" sx={{ mb: 3, borderRadius: 2 }}>
            请登录后发布帖子和参与讨论
          </Alert>
        )}

        {/* 错误提示 */}
        {error && (
          <Alert
            severity="error"
            sx={{ mb: 3, borderRadius: 2 }}
            onClose={() => setError('')}
          >
            {error}
          </Alert>
        )}

        {/* 帖子列表 */}
        {loading ? (
          <Box sx={{
            display: 'flex',
            justifyContent: 'center',
            my: 8
          }}>
            <CircularProgress size={40} />
          </Box>
        ) : posts.length === 0 ? (
          <Paper
            elevation={0}
            sx={{
              p: 8,
              textAlign: 'center',
              borderRadius: 3,
              backgroundColor: 'background.paper'
            }}
          >
            <Typography variant="h6" color="text.secondary" gutterBottom>
              暂无帖子
            </Typography>
            <Typography variant="body1" color="text.secondary" sx={{ mb: 3 }}>
              {currentUser ? '快来发布第一个帖子吧！' : '登录后发布第一个帖子吧！'}
            </Typography>
            <Button
              variant="contained"
              startIcon={<Add />}
              onClick={() => setCreateDialogOpen(true)}
              disabled={!currentUser}
            >
              {currentUser ? '发布帖子' : '请先登录'}
            </Button>
          </Paper>
        ) : (
          <Box>
            {posts.map(post => (
              <PostItem
                key={post.ID}
                post={post}
                currentUser={currentUser}
                onDelete={handleDeletePost}
                onViewDetail={handleViewDetail}
              />
            ))}
          </Box>
        )}

        {/* 发布帖子对话框 */}
        <CreatePostDialog
          open={createDialogOpen}
          onClose={() => setCreateDialogOpen(false)}
          onSubmit={handleCreatePost}
          currentUser={currentUser}
        />

        {/* 帖子详情对话框 */}
        <PostDetailDialog
          open={detailDialogOpen}
          onClose={handleCloseDetail}
          post={selectedPost}
        />

        {/* 提示消息 */}
        <Snackbar
          open={snackbar.open}
          autoHideDuration={3000}
          onClose={() => setSnackbar(prev => ({ ...prev, open: false }))}
          message={snackbar.message}
        />
      </Container>
    </Box>
  );
};

// 页面入口
export default function ForumPage() {
  const [config, setConfig] = useState(null);
  const [loadingConfig, setLoadingConfig] = useState(true);

  useEffect(() => {
    const loadData = async () => {
      try {
        // 获取站点配置
        const response = await fetch('/config/site-config.json');
        const data = await response.json();
        setConfig(data);
      } catch (err) {
        console.error('加载配置失败:', err);
        setConfig({ site: { name: '技术论坛' } });
      } finally {
        setLoadingConfig(false);
      }
    };

    loadData();
  }, []);

  if (loadingConfig) {
    return (
      <Box sx={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        minHeight: '100vh'
      }}>
        <CircularProgress size={40} />
      </Box>
    );
  }

  return (
    <Layout config={config}>
      <ForumSection config={config} />
    </Layout>
  );
}