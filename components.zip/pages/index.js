import Head from 'next/head';
import { Layout, Header, ServicesAndProductsSection } from '../components/AllComponents';
import { useEffect, useState } from 'react';
import { initializeApi } from '../components/config';

export default function Home() {
  const [config, setConfig] = useState(null);



  useEffect(() => {
    // 加载配置文件
    const init = async () => {
      // 在这里使用await
      await initializeApi();
      }
    init();
    fetch('/config/site-config.json')
      .then(res => res.json())
      .then(data => setConfig(data))
      .catch(err => console.error('Failed to load config:', err));
  }, []);

  if (!config) return <div>Loading...</div>;

  return (
    <Layout config={config}>
      <Head>
        <title>{config.site?.name || 'Nova科技'}</title>
        <meta name="description" content={config.site?.description} />
      </Head>

      <Header config={config} />
      <ServicesAndProductsSection config={config} />
    </Layout>
  );
}




