import Head from 'next/head';
import { Layout, AboutSection } from '../components/AllComponents';
import { useEffect, useState } from 'react';

export default function About() {
  const [config, setConfig] = useState(null);

  useEffect(() => {
    fetch('/config/site-config.json')
      .then(res => res.json())
      .then(data => setConfig(data))
      .catch(err => console.error('Failed to load config:', err));
  }, []);

  if (!config) return <div>Loading...</div>;

  return (
    <Layout config={config}>
      <Head>
        <title>关于我们 - {config.site?.name}</title>
      </Head>

      <AboutSection config={config} />
    </Layout>
  );
}