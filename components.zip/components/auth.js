import { ROLES } from '../constants/roles';

export const hasPermission = (userRole, requiredPermission) => {
  const role = ROLES[userRole];
  return role && role.permissions.includes(requiredPermission);
};