// AuthContext.js - 简化修复版本
import { createContext, useContext, useState, useEffect } from 'react';
import axios from 'axios';

const AuthContext = createContext({
  token: null,
  user: null,
  loading: true,
  login: () => {},
  logout: () => {},
  isAuthenticated: false,
  checkAuth: () => {}
});

export const AuthProvider = ({ children }) => {
  const [token, setToken] = useState(null);
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  // 简化的认证检查
  const checkAuth = async () => {
    try {
      console.log('🔄 检查认证状态...');

      // 首先检查 localStorage
      const storedToken = localStorage.getItem('token');
      const storedUser = localStorage.getItem('user');

      if (storedToken && storedUser) {
        console.log('📁 找到本地存储的认证信息');
        setToken(storedToken);
        setUser(JSON.parse(storedUser));
        axios.defaults.headers.common['Authorization'] = `Bearer ${storedToken}`;
        setLoading(false);
        return true;
      }

      // 如果没有本地存储，尝试服务器检查
      try {
        const response = await axios.get('/api/auth/check');
        console.log('🔐 服务器认证检查:', response.data);

        if (response.data.logged_in) {
          const userData = {
            username: response.data.username,
            role: response.data.role || 'user'
          };

          setToken(response.data.token || 'virtual-token');
          setUser(userData);

          // 保存到 localStorage
          localStorage.setItem('token', response.data.token || 'virtual-token');
          localStorage.setItem('user', JSON.stringify(userData));

          setLoading(false);
          return true;
        }
      } catch (serverError) {
        console.log('❌ 服务器认证检查失败，使用本地状态');
      }

      // 如果都没有，设置为未登录
      setToken(null);
      setUser(null);
      setLoading(false);
      return false;

    } catch (error) {
      console.error('❌ 认证检查失败:', error);
      setToken(null);
      setUser(null);
      setLoading(false);
      return false;
    }
  };

  // 初始化：检查认证状态
  useEffect(() => {
    checkAuth();
  }, []);

  // 登录方法
  const login = async (newToken, newUser) => {
    try {
      console.log('🔐 执行登录:', { newToken, newUser });

      setToken(newToken);
      setUser(newUser);

      // 保存到 localStorage
      localStorage.setItem('token', newToken);
      localStorage.setItem('user', JSON.stringify(newUser));

      // 设置 axios 默认头部
      if (newToken) {
        axios.defaults.headers.common['Authorization'] = `Bearer ${newToken}`;
      }

      console.log('✅ 登录成功 - 用户信息已保存');

    } catch (error) {
      console.error('保存认证数据失败:', error);
    }
  };

  // 登出方法
  const logout = () => {
    console.log('🚪 执行登出');
    setToken(null);
    setUser(null);
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    delete axios.defaults.headers.common['Authorization'];
  };

  return (
    <AuthContext.Provider
      value={{
        token,
        user,
        loading,
        login,
        logout,
        checkAuth,
        isAuthenticated: !!user
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};