__turbopack_load_page_chunks__("/_app", [
  "static/chunks/node_modules_next_dist_compiled_next-devtools_index_5277ebc8.js",
  "static/chunks/node_modules_next_dist_compiled_37759e4c._.js",
  "static/chunks/node_modules_next_dist_shared_lib_2c2ec201._.js",
  "static/chunks/node_modules_next_dist_client_d0aa886c._.js",
  "static/chunks/node_modules_next_dist_2e2215b7._.js",
  "static/chunks/node_modules_react_e3593a73._.js",
  "static/chunks/node_modules_react-dom_cjs_react-dom_development_2b5e0eb3.js",
  "static/chunks/node_modules_react-dom_8a8085df._.js",
  "static/chunks/node_modules_react-query_es_490c5286._.js",
  "static/chunks/node_modules_axios_lib_2c8bf6cb._.js",
  "static/chunks/node_modules_414c115f._.js",
  "static/chunks/[root-of-the-server]__f2434fab._.js",
  "static/chunks/styles_globals_dc36e6c9.css",
  "static/chunks/pages__app_2da965e7._.js",
  "static/chunks/turbopack-pages__app_7cd2a6d7._.js"
])
