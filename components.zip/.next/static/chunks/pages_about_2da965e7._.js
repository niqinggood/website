(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__3bbbda8a._.js",
  "static/chunks/node_modules_next_dist_compiled_next-devtools_index_5277ebc8.js",
  "static/chunks/node_modules_next_dist_compiled_166120c5._.js",
  "static/chunks/node_modules_next_dist_shared_lib_d35f3a8e._.js",
  "static/chunks/node_modules_next_dist_client_3ede7da4._.js",
  "static/chunks/node_modules_next_dist_0d80a400._.js",
  "static/chunks/node_modules_next_e5450561._.js",
  "static/chunks/node_modules_react_e3593a73._.js",
  "static/chunks/node_modules_react-dom_cjs_react-dom_development_2b5e0eb3.js",
  "static/chunks/node_modules_react-dom_8a8085df._.js",
  "static/chunks/node_modules_@mui_system_esm_1f3550b1._.js",
  "static/chunks/node_modules_@mui_material_esm_styles_dadc1482._.js",
  "static/chunks/node_modules_@mui_material_esm_c59b22d2._.js",
  "static/chunks/node_modules_f8547470._.js"
],
    source: "entry"
});
