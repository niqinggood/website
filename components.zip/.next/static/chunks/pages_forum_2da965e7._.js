(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__8ef71cd6._.js",
  "static/chunks/node_modules_next_dist_compiled_next-devtools_index_5277ebc8.js",
  "static/chunks/node_modules_next_dist_compiled_37759e4c._.js",
  "static/chunks/node_modules_next_dist_shared_lib_f041b118._.js",
  "static/chunks/node_modules_next_dist_client_3ede7da4._.js",
  "static/chunks/node_modules_next_dist_0d80a400._.js",
  "static/chunks/node_modules_next_5cb05f67._.js",
  "static/chunks/node_modules_react_e3593a73._.js",
  "static/chunks/node_modules_react-dom_cjs_react-dom_development_2b5e0eb3.js",
  "static/chunks/node_modules_react-dom_8a8085df._.js",
  "static/chunks/node_modules_@mui_system_esm_99d3da89._.js",
  "static/chunks/node_modules_@mui_material_esm_styles_62666c8e._.js",
  "static/chunks/node_modules_@mui_material_esm_103d9b9d._.js",
  "static/chunks/node_modules_axios_lib_2c8bf6cb._.js",
  "static/chunks/node_modules_2ee002fe._.js"
],
    source: "entry"
});
