
def yolov5_seg_train(dataset_path='/path/to/dataset.yaml', model_name='yolov5s-seg.pt', epochs=50, imgsz=640, batch=16, device='cuda',
                     project='segruns', name='train'):
    """
    使用 YOLOv5 Segmentation 训练模型。

    参数:
        dataset_path (str): 数据集配置文件路径（YAML 格式）。
        model_name (str): 预训练模型名称（如 'yolov5s-seg.pt'）。
        epochs (int): 训练轮数。
        imgsz (int): 输入图像尺寸。
        batch (int): 批量大小。
        device (str): 使用的设备（'cuda' 或 'cpu'）。
        project (str): 保存目录的父目录。
        name (str): 实验名称，训练结果会保存在 `project/name` 目录下。
    """
    from ultralytics import YOLO

    # 加载预训练的 YOLOv5 Segmentation 模型
    model = YOLO(model_name)

    # 训练模型
    results = model.train(
        data=dataset_path,
        epochs=epochs,
        imgsz=imgsz,
        batch=batch,
        device=device,
        project=project,  # 指定保存目录的父目录
        name=name  # 指定实验名称
    )

    #print(f"训练完成！结果保存在 {project}/{name}")

def yolov5_seg_inference(model_path='yolov8n-seg.pt', image_path='path/to/test_image.jpg', result_path='path/to/save/results.jpg'):
    """
    使用 YOLOv5 Segmentation 进行推理。

    参数:
        model_path (str): 训练好的模型路径（如 'best.pt'）。
        image_path (str): 测试图像路径。
        result_path (str): 结果保存路径。
    """
    from ultralytics import YOLO

    # 加载训练好的模型
    model = YOLO(model_path)

    # 推理
    results = model(image_path)

    # 可视化结果
    for result in results:
        result.show()  # 显示结果
        result.save(filename=result_path)  # 保存结果

    print(f"推理结果已保存到 {result_path}")

def yolov5_seg_evaluate(model_path='runs/train/exp/weights/best.pt', dataset_path='/path/to/dataset.yaml'):
    """
    使用 YOLOv5 Segmentation 评估模型。

    参数:
        model_path (str): 训练好的模型路径（如 'best.pt'）。
        dataset_path (str): 数据集配置文件路径（YAML 格式）。
    """
    from ultralytics import YOLO

    # 加载训练好的模型
    model = YOLO(model_path)

    # 评估模型
    metrics = model.val(data=dataset_path)
    # 打印评估结果
    print("评估结果:")
    print(f"mAP@0.5: {metrics.box.map}")  # mAP@0.5
    print(f"mAP@0.5:0.95: {metrics.box.map50_95}")  # mAP@0.5:0.95
    print(f"Mask mAP@0.5: {metrics.seg.map}")  # Mask mAP@0.5
    print(f"Mask mAP@0.5:0.95: {metrics.seg.map50_95}")  # Mask mAP@0.5:0.95

#YOLOv5 的开发者 Ultralytics 提供了一个扩展版本 YOLOv5 Segmentation，支持实例分割（Instance Segmentation）。以下是关于 YOLOv5 和图像分割的详细说明：
if __name__ == "__main__":
    # 1. 训练模型
    # yolov5_seg_train(
    #     dataset_path='./dataset.yaml',  # 数据集配置文件
    #     model_name='./yolov5s-seg.pt',  # 预训练模型
    #     epochs=50,
    #     imgsz=640,
    #     batch=16,
    #     device='cuda',  # 使用 GPU
    #     project='./segrun',  # 指定保存目录的父目录
    #     name='face_segmentation_exp'  # 指定实验名称
    # )

    # 2. 推理测试
    yolov5_seg_inference(
        model_path= 'yolo11n-seg.pt',#'yolov8s-seg.pt',#'yolo11n-seg.pt'  ,#  # 训练好的模型路径 #yolo11n-seg.pt
        image_path=  'test4.jpeg',#'F:\\work\\hms_ml_project\\red.jpg',#'D:\\bak\\FDDB\\yolo_dataset\\images\\val\\250.jpg',#'./test.png',  # 测试图像路径
        result_path='./result.jpg'  # 结果保存路径
    )

    # 3. 评估模型
    yolov5_seg_evaluate(
        model_path='yolo11n-seg.pt',  # 训练好的模型路径
        dataset_path='./dataset.yaml'  # 数据集配置文件
    )