import functools
import traceback
import logging
def monitor_function(func):
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        try:
            result = func(*args, **kwargs)
            return result
        except Exception as e:
            logging.error(f"Error in function {func.__name__}: {str(e)}")
            logging.error(f"Traceback:\n{traceback.format_exc()}")
            raise  # 重新抛出异常，以便调用者可以处理
    return wrapper

# 示例函数
@monitor_function
def example_function(x, y):
    return x / y


if __name__ == '__main__':
    example_function(1,0)