import os
try:
    from minio import Minio
except ModuleNotFoundError:
    raise ImportError(
        "The 'minio' package is required but not installed. "
        "Please install it using 'pip install minio'."
    )
from datetime import timedelta
from typing import List, Dict, Optional


class Bucket(object):
    client = None
    policy = '{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Principal":{"AWS":["*"]},"Action":["s3:GetBucketLocation","s3:ListBucket"],"Resource":["arn:aws:s3:::%s"]},{"Effect":"Allow","Principal":{"AWS":["*"]},"Action":["s3:GetObject"],"Resource":["arn:aws:s3:::%s/*"]}]}'

    def __new__(cls, *args, **kwargs):
        if not cls.client:
            cls.client = object.__new__(cls)
        return cls.client

    def __init__(self, service: str, access_key: str, secret_key: str, secure: bool = False):
        self.service = service
        self.client = Minio(service, access_key=access_key, secret_key=secret_key, secure=secure)

    def exists_bucket(self, bucket_name: str) -> bool:
        """
        判断桶是否存在
        :param bucket_name: 桶名称
        :return: 是否存在
        """
        return self.client.bucket_exists(bucket_name=bucket_name)

    def create_bucket(self, bucket_name: str, is_policy: bool = True) -> bool:
        """
        创建桶 + 赋予策略
        :param bucket_name: 桶名
        :param is_policy: 策略
        :return: 是否创建成功
        """
        if self.exists_bucket(bucket_name=bucket_name):
            return False
        else:
            self.client.make_bucket(bucket_name=bucket_name)
        if is_policy:
            policy = self.policy % (bucket_name, bucket_name)
            self.client.set_bucket_policy(bucket_name=bucket_name, policy=policy)
        return True

    def get_bucket_list(self) -> List[Dict]:
        """
        列出存储桶
        :return: 存储桶列表
        """
        buckets = self.client.list_buckets()
        bucket_list = []
        for bucket in buckets:
            bucket_list.append(
                {"bucket_name": bucket.name, "create_time": bucket.creation_date}
            )
        return bucket_list

    def remove_bucket(self, bucket_name: str) -> bool:
        """
        删除桶
        :param bucket_name: 桶名
        :return: 是否删除成功
        """
        try:
            self.client.remove_bucket(bucket_name=bucket_name)
        except Exception as e:
            print("[error]:", e)
            return False
        return True

    def bucket_list_files(self, bucket_name: str, prefix: Optional[str] = None) -> List[Dict]:
        """
        列出存储桶中所有对象
        :param bucket_name: 桶名
        :param prefix: 前缀
        :return: 文件列表
        """
        try:
            files_list = self.client.list_objects(bucket_name=bucket_name, prefix=prefix, recursive=True)
            result = []
            for obj in files_list:
                result.append({
                    "bucket_name": obj.bucket_name,
                    "object_name": obj.object_name,
                    "last_modified": obj.last_modified,
                    "etag": obj.etag,
                    "size": obj.size,
                    "content_type": obj.content_type
                })
            return result
        except Exception as e:
            print("[error]:", e)
            return []

    def bucket_policy(self, bucket_name: str) -> Optional[str]:
        """
        列出桶存储策略
        :param bucket_name: 桶名
        :return: 存储策略
        """
        try:
            policy = self.client.get_bucket_policy(bucket_name)
            return policy
        except Exception as e:
            print("[error]:", e)
            return None

    def download_file(self, bucket_name: str, file: str, file_path: str, stream: int = 1024 * 32) -> bool:
        """
        从bucket 下载文件 + 写入指定文件
        :param bucket_name: 桶名
        :param file: 文件名
        :param file_path: 本地文件路径
        :param stream: 流大小
        :return: 是否下载成功
        """
        try:
            data = self.client.get_object(bucket_name, file)
            with open(file_path, "wb") as fp:
                for d in data.stream(stream):
                    fp.write(d)
            return True
        except Exception as e:
            print("[error]:", e)
            return False

    def fget_file(self, bucket_name: str, file: str, file_path: str) -> bool:
        """
        下载保存文件保存本地
        :param bucket_name: 桶名
        :param file: 文件名
        :param file_path: 本地文件路径
        :return: 是否下载成功
        """
        try:
            self.client.fget_object(bucket_name, file, file_path)
            return True
        except Exception as e:
            print("[error]:", e)
            return False

    def upload_file(self, bucket_name: str, file: str, file_path: str, content_type: str) -> bool:
        """
        上传文件 + 写入
        :param bucket_name: 桶名
        :param file: 文件名
        :param file_path: 本地文件路径
        :param content_type: 文件类型
        :return: 是否上传成功
        """
        try:
            with open(file_path, "rb") as file_data:
                file_stat = os.stat(file_path)
                self.client.put_object(bucket_name, file, file_data, file_stat.st_size, content_type=content_type)
            return True
        except Exception as e:
            print("[error]:", e)
            return False

    def fput_file(self, bucket_name: str, file: str, file_path: str) -> bool:
        """
        上传文件
        :param bucket_name: 桶名
        :param file: 文件名
        :param file_path: 本地文件路径
        :return: 是否上传成功
        """
        try:
            self.client.fput_object(bucket_name, file, file_path)
            return True
        except Exception as e:
            print("[error]:", e)
            return False

    def stat_object(self, bucket_name: str, file: str) -> Optional[Dict]:
        """
        获取文件元数据
        :param bucket_name: 桶名
        :param file: 文件名
        :return: 文件元数据
        """
        try:
            data = self.client.stat_object(bucket_name, file)
            return {
                "bucket_name": data.bucket_name,
                "object_name": data.object_name,
                "last_modified": data.last_modified,
                "etag": data.etag,
                "size": data.size,
                "metadata": data.metadata,
                "content_type": data.content_type
            }
        except Exception as e:
            print("[error]:", e)
            return None

    def remove_file(self, bucket_name: str, file: str) -> None:
        """
        移除单个文件
        :param bucket_name: 桶名
        :param file: 文件名
        :return: None
        """
        self.client.remove_object(bucket_name, file)

    def presigned_get_file(self, bucket_name: str, file: str, days: int = 7) -> Optional[str]:
        """
        生成一个http GET操作 签证URL
        :param bucket_name: 桶名
        :param file: 文件名
        :param days: 有效期天数
        :return: 签证URL
        """
        try:
            return self.client.presigned_get_object(bucket_name, file, expires=timedelta(days=days))
        except Exception as e:
            print("[error]:", e)
            return None

    def download_directory(self, bucket_name: str, prefix: str, local_dir: str) -> bool:
        """
        下载目录及其包含的所有文件
        :param bucket_name: 桶名
        :param prefix: 目录前缀
        :param local_dir: 本地目录路径
        :return: 是否下载成功
        """
        try:
            objects = self.client.list_objects(bucket_name, prefix=prefix, recursive=True)
            print('objects:', objects)
            for obj in objects:
                local_file_path = os.path.join(local_dir, obj.object_name.replace(prefix, '', 1).lstrip('/'))
                local_file_dir = os.path.dirname(local_file_path)
                print('local_file_dir:', local_file_dir)
                if not os.path.exists(local_file_dir):
                    os.makedirs(local_file_dir)
                self.fget_file(bucket_name, obj.object_name, local_file_path)
            return True
        except Exception as e:
            print("[error]:", e)
            return False

    def upload_directory(self, bucket_name: str, local_dir: str, prefix: str = '') -> bool:
        """
        上传本地目录及其包含的所有文件
        :param bucket_name: 桶名
        :param local_dir: 本地目录路径
        :param prefix: 上传到桶中的前缀
        :return: 是否上传成功
        """
        prefix = prefix.replace('\\', '/')
        try:
            for root, dirs, files in os.walk(local_dir):
                print('files:', files)
                for file in files:
                    print('begin upload:', file)
                    local_file_path = os.path.join(root, file)
                    object_name = os.path.join(prefix, os.path.relpath(local_file_path, local_dir)).replace('\\', '/')
                    print('object_name:', object_name, 'local_file_path:', local_file_path)
                    self.fput_file(bucket_name, object_name, local_file_path)
            return True
        except Exception as e:
            print("[error]:", e)
            return False


if __name__ == '__main__':
    url = '127.0.0.1:9000'
    access_key = '3625GSv6cfNMsXDfhHNW'
    secret_key = '30uLX4FS9qg8Ob2mlSQrsGsHx8jwgTH0nbMF4yWV'
    client = Bucket(url, access_key, secret_key)
    buckets = client.get_bucket_list()
    print('buckets:', buckets)
    objects = client.client.list_objects('saddle', prefix='backend/saddle/__pycache__/*', recursive=True)
    print('objects:', objects)
    for obj in objects:
        object_name = obj.object_name
        print(object_name)

    status = client.download_directory(bucket_name='saddle', prefix='backend/saddle/__pycache__/', local_dir='./test')
    print('download directory status:', status)
    status = client.upload_directory(bucket_name='upload', local_dir='test', prefix='')
    print('upload directory status:', status)
    print('begin test:bucket_list_files')
    filelist = client.bucket_list_files(bucket_name='test', prefix=None)
    # client.download_file(bucket_name='test', file='df_train_bin.csv', file_path='test.csv')