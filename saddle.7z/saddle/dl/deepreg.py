#!/usr/bin/env python
# -*- coding: UTF-8 -*-
'''
@Project ：DeepReg 
@File    ：deepreg.py
@IDE     ：PyCharm 
@Author  ：patrick
@Date    ：2022/7/18 23:00
'''
#pip install torch torchvision scikit-learn
import torch
import torch.nn as nn
import torch.optim as optim
from torchvision import models
from sklearn.base import BaseEstimator, ClassifierMixin, RegressorMixin
from sklearn.metrics import accuracy_score, mean_squared_error
from torch.utils.data import DataLoader, TensorDataset
from tqdm import tqdm

class TemporalBlock(nn.Module):
    def __init__(self, n_inputs, n_outputs, kernel_size, stride, dilation, padding, dropout=0.2):
        super(TemporalBlock, self).__init__()
        self.conv1 = nn.Conv1d(n_inputs, n_outputs, kernel_size, stride=stride, padding=padding, dilation=dilation)
        self.relu1 = nn.ReLU()
        self.dropout1 = nn.Dropout(dropout)
        self.conv2 = nn.Conv1d(n_outputs, n_outputs, kernel_size, stride=stride, padding=padding, dilation=dilation)
        self.relu2 = nn.ReLU()
        self.dropout2 = nn.Dropout(dropout)
        self.net = nn.Sequential(self.conv1, self.relu1, self.dropout1, self.conv2, self.relu2, self.dropout2)
        self.downsample = nn.Conv1d(n_inputs, n_outputs, kernel_size=1) if n_inputs != n_outputs else None
        self.relu = nn.ReLU()
        self.init_weights()

    def init_weights(self):
        nn.init.normal_(self.conv1.weight, 0, 0.01)
        nn.init.normal_(self.conv2.weight, 0, 0.01)
        if self.downsample is not None:
            nn.init.normal_(self.downsample.weight, 0, 0.01)

    def forward(self, x):
        out = self.net(x)
        res = x if self.downsample is None else self.downsample(x)

        # 调整 res 的尺寸，以匹配 out 的时间维度
        if res.size(2) > out.size(2):
            res = res[:, :, :out.size(2)]
        elif res.size(2) < out.size(2):
            out = out[:, :, :res.size(2)]

        return self.relu(out + res)


class TCN(nn.Module):
    def __init__(self, input_size, output_size, num_layers, base_channels, kernel_size, dropout):
        super(TCN, self).__init__()
        layers = []
        for i in range(num_layers):
            dilation_size = 2 ** i
            in_channels = input_size if i == 0 else base_channels
            out_channels = base_channels
            padding = (kernel_size - 1) * dilation_size
            layers += [TemporalBlock(in_channels, out_channels, kernel_size, stride=1,
                                     dilation=dilation_size,
                                     padding=padding, dropout=dropout)]
        self.network = nn.Sequential(*layers)
        self.fc = nn.Linear(base_channels, output_size)

    def forward(self, x):
        x = self.network(x)
        x = x.mean(dim=2)  # Global average pooling
        return self.fc(x)

class TCNWrapper:
    def __init__(self, input_size, output_size, num_layers, base_channels, kernel_size, dropout, epochs=10, batch_size=32, lr=0.001, task="classification",device='cpu'): #cuda
        self.model = TCN(input_size, output_size, num_layers, base_channels, kernel_size, dropout)
        self.epochs = epochs
        self.batch_size = batch_size
        self.lr = lr
        self.task = task
        self.criterion = nn.CrossEntropyLoss() if task == "classification" else nn.MSELoss()
        self.optimizer = optim.Adam(self.model.parameters(), lr=self.lr)
        self.device = device #torch.device("cuda" if torch.cuda.is_available() else "cpu")
        print('device:',self.device)
        self.model.to(self.device)
    def fit(self, X, y):
        self.model.train()

        # 确保数据是 3D 形状，格式为 [batch_size, input_channels, sequence_length]
        if len(X.shape) == 2:
            X = np.expand_dims(X, axis=1)  # 变为 (samples, 1, features)
        elif X.shape[1] > X.shape[2]:  # 如果维度不匹配，调整格式
            X = np.transpose(X, (0, 2, 1))

        # 确保输入数据的通道数与 input_size 一致
        if X.shape[1] != self.model.network[0].conv1.in_channels:
            X = np.expand_dims(X, axis=1)
            X = np.repeat(X, self.model.network[0].conv1.in_channels, axis=1)

        # 确保输入数据的形状正确
        if len(X.shape) == 4:
            X = X.squeeze(2)

        # 根据任务类型调整目标张量的形状
        if self.task == "classification":
            y = y.reshape(-1).astype(np.int64)  # 确保 y 为 1D 张量 [batch_size]，整数标签
        else:  # 回归任务
            y = y.reshape(-1, 1).astype(np.float32)  # 确保 y 为 2D 张量 [batch_size, 1]

        train_dataset = TensorDataset(torch.tensor(X, dtype=torch.float32), torch.tensor(y))
        train_loader = DataLoader(train_dataset, batch_size=self.batch_size, shuffle=True)

        for epoch in range(self.epochs):
            for batch_X, batch_y in train_loader:
                self.optimizer.zero_grad()
                output = self.model(batch_X)
                if self.task == "classification":
                    loss = self.criterion(output, batch_y)
                else:
                    loss = self.criterion(output.squeeze(), batch_y.squeeze())
                loss.backward()
                self.optimizer.step()
            print(f'Epoch {epoch + 1}/{self.epochs}, Loss: {loss.item()}')

    def predict(self, X):
        self.model.eval()

        # Ensure data is 3D with shape [batch_size, input_channels, sequence_length]
        if len(X.shape) == 2:
            X = np.expand_dims(X, axis=1)
        elif X.shape[1] > X.shape[2]:  # Adjust shape if necessary
            X = np.transpose(X, (0, 2, 1))

        # 确保输入数据的通道数与 input_size 一致
        if X.shape[1] != self.model.network[0].conv1.in_channels:
            X = np.expand_dims(X, axis=1)
            X = np.repeat(X, self.model.network[0].conv1.in_channels, axis=1)

        # 确保输入数据的形状正确
        if len(X.shape) == 4:
            X = X.squeeze(2)

        with torch.no_grad():
            X_tensor = torch.tensor(X, dtype=torch.float32)
            output = self.model(X_tensor)
            if self.task == "classification":
                _, predicted = torch.max(output, 1)
                return predicted.numpy()
            else:
                return output.numpy()

    def score(self, X, y):
        y_pred = self.predict(X)
        if self.task == "classification":
            return accuracy_score(y, y_pred)
        else:
            return mean_squared_error(y, y_pred)

def test_tcn():
    # Test with 3D data (classification)
    X = np.random.rand(1000, 10, 20)  # 1000 samples, 10 features, 20 time steps
    y = np.random.randint(0, 2, 1000)  # Binary classification task

    tcn_model = TCNWrapper(input_size=10, output_size=2, num_layers=3, base_channels=10, kernel_size=3, dropout=0.2, epochs=10, task="classification",device='cpu')
    tcn_model.fit(X, y)
    score = tcn_model.score(X, y)
    print(f"TCN Classification Accuracy: {score}")

    # Test with 2D data (regression)
    X_reg = np.random.rand(1000, 10)  # 1000 samples, 10 features
    y_reg = np.random.rand(1000, 1)  # Single output for regression
    tcn_model_reg = TCNWrapper(input_size=10, output_size=1, num_layers=3, base_channels=10, kernel_size=3, dropout=0.2, epochs=10, task="regression",device='cpu')
    tcn_model_reg.fit(X_reg, y_reg)
    mse = tcn_model_reg.score(X_reg, y_reg)
    print(f"TCN Regression MSE: {mse}")

class CrossLayer_simple(nn.Module):
    def __init__(self, input_dim, layer_idx):
        super(CrossLayer_simple, self).__init__()
        self.weight = nn.Parameter(torch.Tensor(input_dim, 1))
        self.bias = nn.Parameter(torch.Tensor(input_dim))
        self.init_weights(layer_idx)

    def init_weights(self, layer_idx):
        nn.init.normal_(self.weight, mean=0, std=0.01 / (layer_idx + 1))
        nn.init.normal_(self.bias, mean=0, std=0.01 / (layer_idx + 1))

    def forward(self, x0, x):
        return x0 * torch.bmm(x.unsqueeze(1), self.weight).squeeze() + x + self.bias


class DCN_simple(nn.Module):
    def __init__(self, input_dim, num_cross_layers, num_deep_layers, deep_dim, output_dim):
        super(DCN_simple, self).__init__()
        self.cross_layers = nn.ModuleList([CrossLayer_simple(input_dim, i) for i in range(num_cross_layers)])
        self.deep_layers = nn.ModuleList()
        for i in range(num_deep_layers):
            if i == 0:
                self.deep_layers.append(nn.Linear(input_dim, deep_dim))
            else:
                self.deep_layers.append(nn.Linear(deep_dim, deep_dim))
            self.deep_layers.append(nn.ReLU())
        self.final_layer = nn.Linear(input_dim + deep_dim, output_dim)
    def forward(self, x):
        x0 = x
        cross_out = x0
        for layer in self.cross_layers:
            cross_out = layer(x0, cross_out)
        deep_out = x0
        for layer in self.deep_layers:
            deep_out = layer(deep_out)
        out = torch.cat([cross_out, deep_out], dim=1)
        return self.final_layer(out)


class CrossLayer(nn.Module):
    def __init__(self, input_dim):
        super(CrossLayer, self).__init__()
        self.weight = nn.Parameter(torch.Tensor(input_dim, 1))
        self.bias = nn.Parameter(torch.Tensor(input_dim))
        self.reset_parameters()

    def reset_parameters(self):
        nn.init.normal_(self.weight)
        nn.init.zeros_(self.bias)

    def forward(self, x):
        xw = torch.matmul(x, self.weight)
        return x * xw + self.bias

class DCN(nn.Module):
    def __init__(self, num_continuous, num_categories, embedding_dims, num_cross_layers, deep_layer_dims, output_dim, task='classification'):
        super(DCN, self).__init__()
        self.task = task
        self.num_continuous = num_continuous
        self.num_categories = num_categories
        self.deep_layer_dims= deep_layer_dims
        if num_categories > 0:
            self.embeddings = nn.ModuleList([nn.Embedding(num_embed, embed_dim) for num_embed, embed_dim in embedding_dims[:num_categories]])
            embedding_output_dim = sum(embed_dim for _, embed_dim in embedding_dims[:num_categories])
        else:
            self.embeddings = nn.ModuleList()
            embedding_output_dim = 0

        input_dim = num_continuous + embedding_output_dim
        self.cross_layers = nn.ModuleList([CrossLayer(input_dim) for _ in range(num_cross_layers)])
        self.deep_layers = nn.ModuleList()

        for i in range(len(deep_layer_dims)):
            if i == 0:
                self.deep_layers.append(nn.Linear(input_dim, deep_layer_dims[i]))
            else:
                self.deep_layers.append(nn.Linear(deep_layer_dims[i-1], deep_layer_dims[i]))
            self.deep_layers.append(nn.BatchNorm1d(deep_layer_dims[i]))  # Add BatchNorm
            self.deep_layers.append(nn.ReLU())

        self.deep_layers.append(nn.Linear(deep_layer_dims[-1], output_dim))
        self.final_layer = nn.Linear(input_dim + output_dim, output_dim)  # deep_layer_dims[-1]

        if task == 'classification':
            self.activation = nn.Sigmoid()
        else:
            self.activation = nn.Identity()

        self.init_weights()

    def init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight)  # Use Xavier uniform initialization
                nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.Embedding):
                nn.init.normal_(m.weight, mean=0, std=0.01)

    def forward(self, continuous_inputs, categorical_inputs):
        if self.num_continuous > 0:
            x_continuous = continuous_inputs
        else:
            x_continuous = torch.tensor([], dtype=torch.float32)

        if self.num_categories > 0:
            embedding_outputs = [embedding(categorical_inputs[:, i]) for i, embedding in enumerate(self.embeddings)]
            embedding_output = torch.cat(embedding_outputs, dim=1)
        else:
            embedding_output = torch.tensor([], dtype=torch.float32)

        x = torch.cat([x_continuous, embedding_output], dim=1)
        cross_output = x
        for layer in self.cross_layers:
            cross_output = layer(cross_output)

        deep_output = x
        for layer in self.deep_layers:
            deep_output = layer(deep_output)

        final_output = torch.cat([cross_output, deep_output], dim=1)
        final_output = self.final_layer(final_output)
        final_output = self.activation(final_output)
        return final_output

class DCNWrapper(BaseEstimator, ClassifierMixin):
    def __init__(self, num_continuous, num_categories, embedding_dims, num_cross_layers, deep_layer_dims, output_dim, task='classification', epochs=10, batch_size=32, lr=0.001,
                 clip_value=1.0, weight_decay=0.01, threshold=0.5):
        self.model          = DCN(num_continuous, num_categories, embedding_dims, num_cross_layers, deep_layer_dims, output_dim, task)
        self.deep_layer_dims= deep_layer_dims
        self.epochs         = epochs
        self.task           = task
        self.batch_size     = batch_size
        self.lr             = lr
        self.clip_value     = clip_value
        self.weight_decay   = weight_decay
        self.optimizer      = optim.Adam(self.model.parameters(), lr=self.lr, weight_decay=self.weight_decay)
        self.criterion      = nn.BCELoss() if task == 'classification' else nn.MSELoss()
        self.threshold      = threshold
        self.num_continuous = num_continuous
        self.num_categories = num_categories
        # 用于存储统计信息的 DataFrame
        self.stats_df = pd.DataFrame(columns=['model_name', 'batch_size', 'epoch', 'loss', 'accuracy', 'mse', 'memory_usage'])

    def fit(self, X, y):
        self.model.train()

        if self.num_continuous > 0:
            X_continuous = np.asarray(X[:, :self.num_continuous], dtype=np.float32)
        else:
            X_continuous = np.array([], dtype=np.float32).reshape(X.shape[0], 0)

        if self.num_categories > 0:
            X_categorical = np.asarray(X[:, self.num_continuous:], dtype=np.int64)
        else:
            X_categorical = np.array([], dtype=np.int64).reshape(X.shape[0], 0)

        dataset = TensorDataset(torch.tensor(X_continuous, dtype=torch.float32), torch.tensor(X_categorical, dtype=torch.long), torch.tensor(y, dtype=torch.float32))
        dataloader = DataLoader(dataset, batch_size=self.batch_size, shuffle=True)

        for epoch in range(self.epochs):

            for X_cont_batch, X_cat_batch, y_batch in tqdm(dataloader, desc=f"Epoch {epoch + 1}/{self.epochs}"):
                self.optimizer.zero_grad()
                outputs = self.model(X_cont_batch, X_cat_batch)
                if self.task == 'classification':
                    y_batch = y_batch.unsqueeze(1)  # Ensure y_batch is (batch_size, 1)
                loss = self.criterion(outputs, y_batch)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.clip_value)  # Gradient clipping
                self.optimizer.step()



        return self

    def predict(self, X):
        self.model.eval()
        if self.num_continuous > 0:
            X_continuous = X[:, :self.num_continuous]
        else:
            X_continuous = np.array([], dtype=np.float32).reshape(X.shape[0], 0)

        if self.num_categories > 0:
            X_categorical = X[:, self.num_continuous:]
        else:
            X_categorical = np.array([], dtype=np.int64).reshape(X.shape[0], 0)

        with torch.no_grad():
            X_cont_tensor = torch.tensor(X_continuous, dtype=torch.float32)
            X_cat_tensor = torch.tensor(X_categorical, dtype=torch.long)
            outputs = self.model(X_cont_tensor, X_cat_tensor)
            if self.model.task == 'classification':
                predicted = (outputs > self.threshold).float()
            else:
                predicted = outputs
        return predicted.numpy()

    def to(self,device):
        self.model.to(device )
        return self
    def score(self, X, y):
        y_pred = self.predict(X)
        if self.model.task == 'classification':
            return accuracy_score(y, y_pred)
        else:
            return mean_squared_error(y, y_pred)

def test_dcn():
    ############################################## only categorical
    print('##' * 10, 'only categorical')
    # Generate synthetic data
    X_categorical = np.random.randint(0, 10, (1000, 3))  # 1000 samples, 3 categorical features with 10 categories each
    y = np.random.randint(0, 2, 1000)  # Binary classification

    X = X_categorical

    # Initialize and train the DCN model
    dcn_model = DCNWrapper(num_continuous=0, num_categories=3, embedding_dims=[(10, 5), (10, 5), (10, 5)], num_cross_layers=6, deep_layer_dims=[10, 10], output_dim=1,
                           task='classification', epochs=22)
    dcn_model.fit(X, y)

    # Predict and score
    y_pred = dcn_model.predict(X)
    score = dcn_model.score(X, y)
    print(f"DCN Accuracy (only categorical): {score}")

    ############################################## only continuous
    print('##' * 10, 'only continuous')
    # Generate synthetic data
    X_continuous = np.random.rand(1000, 5)  # 1000 samples, 5 continuous features
    y = np.random.randint(0, 2, 1000)  # Binary classification

    X = X_continuous

    # Initialize and train the DCN model
    dcn_model = DCNWrapper(num_continuous=5, num_categories=0, embedding_dims=[], num_cross_layers=6, deep_layer_dims=[10, 10], output_dim=1,
                           task='classification', epochs=22)
    dcn_model.fit(X, y)

    # Predict and score
    y_pred = dcn_model.predict(X)
    score = dcn_model.score(X, y)
    print(f"DCN Accuracy (only continuous): {score}")

    ############################################## only categorical
    print('##' * 10, 'only categorical')
    # Generate synthetic data
    X_categorical = np.random.randint(0, 10, (1000, 3))  # 1000 samples, 3 categorical features with 10 categories each
    y = np.random.randint(0, 2, 1000)  # Binary classification

    X = X_categorical

    # Initialize and train the DCN model
    dcn_model = DCNWrapper(num_continuous=0, num_categories=3, embedding_dims=[(10, 5), (10, 5), (10, 5)], num_cross_layers=6, deep_layer_dims=[10, 10], output_dim=1,
                           task='classification', epochs=22)
    dcn_model.fit(X, y)

    # Predict and score
    y_pred = dcn_model.predict(X)
    score = dcn_model.score(X, y)
    print(f"DCN Accuracy (only categorical): {score}")

    ############################################## only continuous
    print('##' * 10, 'only continuous')
    # Generate synthetic data
    X_continuous = np.random.rand(1000, 5)  # 1000 samples, 5 continuous features
    y = np.random.randint(0, 2, 1000)  # Binary classification

    X = X_continuous

    # Initialize and train the DCN model
    dcn_model = DCNWrapper(num_continuous=5, num_categories=0, embedding_dims=[], num_cross_layers=6, deep_layer_dims=[10, 10], output_dim=1,
                           task='classification', epochs=22)
    dcn_model.fit(X, y)

    # Predict and score
    y_pred = dcn_model.predict(X)
    score = dcn_model.score(X, y)
    print(f"DCN Accuracy (only continuous): {score}")

    ############################################## regression
    print('##' * 10, 'regression')
    # Generate synthetic data
    X_continuous = np.random.rand(1000, 5)  # 1000 samples, 5 continuous features
    X_categorical = np.random.randint(0, 10, (1000, 3))  # 1000 samples, 3 categorical features with 10 categories each
    y = np.random.rand(1000)  # Regression task

    X = np.hstack([X_continuous, X_categorical])

    # Initialize and train the DCN model
    dcn_model = DCNWrapper(num_continuous=5, num_categories=3, embedding_dims=[(10, 5), (10, 5), (10, 5)], num_cross_layers=3, deep_layer_dims=[10, 10], output_dim=1, task='regression',
                           epochs=30, clip_value=0.5)
    dcn_model.fit(X, y)

    # Predict and score
    y_pred = dcn_model.predict(X)
    print('y_pred:',y_pred)
    score = dcn_model.score(X, y)
    print(f"DCN MSE: {score}")

    # Generate synthetic data
    X_continuous = np.random.rand(1000, 5)  # 1000 samples, 5 continuous features
    X_categorical = np.random.randint(0, 10, (1000, 3))  # 1000 samples, 3 categorical features with 10 categories each
    y = np.random.randint(0, 2, 1000)  # Binary classification

    X = np.hstack([X_continuous, X_categorical])

    # Initialize and train the DCN model
    dcn_model = DCNWrapper(num_continuous=5, num_categories=3, embedding_dims=[(10, 5), (10, 5), (10, 5)], num_cross_layers=6, deep_layer_dims=[10, 10], output_dim=1,
                           task='classification', epochs=22)
    dcn_model.fit(X, y)

    # Predict and score
    y_pred = dcn_model.predict(X)
    score = dcn_model.score(X, y)
    print(f"DCN Accuracy: {score}")


class DetNet(nn.Module):
    def __init__(self, num_classes=10):
        super(DetNet, self).__init__()
        self.backbone = models.resnet50(pretrained=True)
        self.backbone = nn.Sequential(*list(self.backbone.children())[:-2])  # Remove the last two layers (avgpool and fc)
        self.conv1 = nn.Conv2d(2048, 256, kernel_size=1)
        self.conv2 = nn.Conv2d(256, num_classes, kernel_size=1)

    def forward(self, x):
        x = x.repeat(1, 3, 1, 1)  # 将单通道复制为 3 通道
        x = self.backbone(x)  # [batch_size, 2048, H, W]
        x = self.conv1(x)  # [batch_size, 256, H, W]
        x = self.conv2(x)  # [batch_size, num_classes, H, W]
        return x


class DetNetWithLinear(nn.Module):
    def __init__(self, num_classes=10):
        super(DetNetWithLinear, self).__init__()
        self.detnet = DetNet(num_classes=num_classes)
        self.adaptive_pool = nn.AdaptiveAvgPool2d((1, 1))  # 将特征图调整为 [batch_size, channels, 1, 1]
        self.flatten = nn.Flatten()  # 展平为 [batch_size, channels]
        self.linear = nn.Linear(num_classes, num_classes)  # 输入大小 = num_classes

    def forward(self, x):
        x = self.detnet(x)  # [batch_size, num_classes, 2, 2]
        x = self.adaptive_pool(x)  # [batch_size, num_classes, 1, 1]
        x = self.flatten(x)  # [batch_size, num_classes]
        x = self.linear(x)  # [batch_size, num_classes]
        return x

#
# class FPN(nn.Module):
#     def __init__(self, num_classes=10):
#         super(FPN, self).__init__()
#         self.backbone = models.resnet50(pretrained=True)
#         self.backbone = nn.Sequential(*list(self.backbone.children())[:-2])  # Remove the last two layers (avgpool and fc)
#
#         self.lateral_conv1 = nn.Conv2d(2048, 256, kernel_size=1 )
#         self.lateral_conv2 = nn.Conv2d(1024, 256, kernel_size=1 )
#         self.lateral_conv3 = nn.Conv2d(512, 256,  kernel_size=1 )
#         self.lateral_conv4 = nn.Conv2d(256, 256,  kernel_size=1 )
#
#         self.predict_conv = nn.Conv2d(256, num_classes, kernel_size=1)
#
#     def forward(self, x):
#         if x.shape[1] == 1:
#             x = x.repeat(1, 3, 1, 1)
#         c2, c3, c4, c5 = self.backbone(x)
#         p5 = self.lateral_conv1(c5)
#         p4 = self.lateral_conv2(c4) + nn.functional.interpolate(p5, scale_factor=2, mode='nearest')
#         p3 = self.lateral_conv3(c3) + nn.functional.interpolate(p4, scale_factor=2, mode='nearest')
#         p2 = self.lateral_conv4(c2) + nn.functional.interpolate(p3, scale_factor=2, mode='nearest')
#
#         p5 = nn.functional.interpolate(p5, size=p2.shape[2:], mode='nearest')
#         p4 = nn.functional.interpolate(p4, size=p2.shape[2:], mode='nearest')
#         p3 = nn.functional.interpolate(p3, size=p2.shape[2:], mode='nearest')
#
#         features = p2 + p3 + p4 + p5           ; print('features shape1',features.shape)
#         output   = self.predict_conv(features)   ; print('output shape1',  output.shape)
#         return output
#
class R_FCN(nn.Module):
    def __init__(self, num_classes=10):
        super(R_FCN, self).__init__()
        self.backbone = models.resnet50(pretrained=True)
        self.backbone = nn.Sequential(*list(self.backbone.children())[:-2])  # Remove the last two layers (avgpool and fc)

        self.conv1 = nn.Conv2d(2048, 1024, kernel_size=1)
        self.conv2 = nn.Conv2d(1024, num_classes, kernel_size=1)

    def forward(self, x):
        x = x.repeat(1, 3, 1, 1)
        x = self.backbone(x)
        x = self.conv1(x)
        x = self.conv2(x)
        return x

import torch
import torch.nn as nn
import torchvision.models as models

class FPN(nn.Module):
    def __init__(self, num_classes=10):
        super(FPN, self).__init__()
        self.backbone = models.resnet50(pretrained=True)
        self.backbone = nn.Sequential(*list(self.backbone.children())[:-2])  # Remove the last two layers (avgpool and fc)

        self.lateral_conv1 = nn.Conv2d(2048, 256, kernel_size=1)
        self.lateral_conv2 = nn.Conv2d(2048, 256, kernel_size=1)
        self.lateral_conv3 = nn.Conv2d(1024, 256, kernel_size=1)
        self.lateral_conv4 = nn.Conv2d(512, 256, kernel_size=1)

        self.predict_conv = nn.Conv2d(256, num_classes, kernel_size=1)

        # Define hooks to extract features from different layers
        self.feature_maps = {}
        self.backbone[5].register_forward_hook(self.save_feature_map('c2'))
        self.backbone[6].register_forward_hook(self.save_feature_map('c3'))
        self.backbone[7][0].register_forward_hook(self.save_feature_map('c4'))
        self.backbone[7][1].register_forward_hook(self.save_feature_map('c5'))

    def save_feature_map(self, name):
        def hook(module, input, output):
            self.feature_maps[name] = output
        return hook

    def forward(self, x):
        x = x.repeat(1, 3, 1, 1)
        self.backbone(x)

        c2 = self.feature_maps['c2']
        c3 = self.feature_maps['c3']
        c4 = self.feature_maps['c4']
        c5 = self.feature_maps['c5']

        p5 = self.lateral_conv1(c5)
        p4 = self.lateral_conv2(c4) + nn.functional.interpolate(p5, size=c4.shape[2:], mode='nearest')
        p3 = self.lateral_conv3(c3) + nn.functional.interpolate(p4, size=c3.shape[2:], mode='nearest')
        p2 = self.lateral_conv4(c2) + nn.functional.interpolate(p3, size=c2.shape[2:], mode='nearest')

        p5 = nn.functional.interpolate(p5, size=p2.shape[2:], mode='nearest')
        p4 = nn.functional.interpolate(p4, size=p2.shape[2:], mode='nearest')
        p3 = nn.functional.interpolate(p3, size=p2.shape[2:], mode='nearest')

        features = p2 + p3 + p4 + p5
        #print('Shape of features:', features.shape)  # [batch_size, 256, H, W]

        output = self.predict_conv(features)
        return output

# # Example usage
# model = FPN(num_classes=10)
# input_tensor = torch.randn(32, 3, 64, 64)  # Example input tensor
# output = model(input_tensor)
# print(output.shape)

class MaskRCNN(nn.Module):
    def __init__(self, num_classes=10):
        super(MaskRCNN, self).__init__()
        self.backbone = models.resnet50(pretrained=True)
        self.backbone = nn.Sequential(*list(self.backbone.children())[:-2])  # Remove the last two layers (avgpool and fc)

        self.conv1 = nn.Conv2d(2048, 1024, kernel_size=1)
        self.conv2 = nn.Conv2d(1024, num_classes, kernel_size=1)

    def forward(self, x):
        x = x.repeat(1, 3, 1, 1)
        x = self.backbone(x)
        x = self.conv1(x)
        x = self.conv2(x)
        return x

class DoubleConv(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(DoubleConv, self).__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels, out_channels, kernel_size=3, padding=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        return self.conv(x)

class UNet(nn.Module):
    def __init__(self, in_channels=3, out_channels=1, features=[64, 128, 256, 512]):
        super(UNet, self).__init__()
        self.ups = nn.ModuleList()
        self.downs = nn.ModuleList()
        self.pool = nn.MaxPool2d(kernel_size=2, stride=2)

        # Down part of UNet
        for feature in features:
            self.downs.append(DoubleConv(in_channels, feature))
            in_channels = feature

        # Up part of UNet
        for feature in reversed(features):
            self.ups.append(
                nn.ConvTranspose2d(feature*2, feature, kernel_size=2, stride=2)
            )
            self.ups.append(DoubleConv(feature*2, feature))

        self.bottleneck = DoubleConv(features[-1], features[-1]*2)
        self.final_conv = nn.Conv2d(features[0], out_channels, kernel_size=1)

    def forward(self, x):
        skip_connections = []
        for down in self.downs:
            x = down(x)
            skip_connections.append(x)
            x = self.pool(x)

        x = self.bottleneck(x)
        skip_connections = skip_connections[::-1]

        for idx in range(0, len(self.ups), 2):
            x = self.ups[idx](x)
            skip_connection = skip_connections[idx//2]

            if x.shape != skip_connection.shape:
                x = nn.functional.interpolate(x, size=skip_connection.shape[2:], mode='bilinear', align_corners=True)

            concat_skip = torch.cat((skip_connection, x), dim=1)
            x = self.ups[idx+1](concat_skip)
        x = self.final_conv(x)
        return x

import os
from PIL import Image
def create_and_save_random_image(image_number, size=(32, 32)):
    if not os.path.exists("images"):
        os.makedirs("images")

    array = np.random.randint(0, 256, (size[0], size[1], 3), dtype=np.uint8)
    image = Image.fromarray(array)

    image_name = f"image_{image_number}.png"
    image.save(os.path.join("images", image_name))

    return image_name

MODEL_INPUT_SIZE = {
    'vgg':(224,224),
    'alexnet': (227, 227),
    'resnet18': (224, 224),
     'resnet50':(224, 224),
     'resnet101':(224, 224),
     'vit-base':(224,224),
    'mobilenet_v2': (224, 224),
    'unet': (64, 64),
    'detnet': (64, 64),
    'fpn': (64, 64),
    'r_fcn': (64, 64),
    'mask_rcnn': (64, 64),
    'sam': (1024, 1024),  # SAM 模型的输入尺寸
    'tcn': None,  # TCN 不需要调整输入尺寸
    'dcn': None,  # DCN 不需要调整输入尺寸
}

from transformers import ViTModel
class ViTClassifier(nn.Module):
    def __init__(self, num_classes, pretrained_model_name='./models/vit-base-patch16-224'):
        super(ViTClassifier, self).__init__()
        self.vit = ViTModel.from_pretrained(pretrained_model_name)
        self.classifier = nn.Linear(self.vit.config.hidden_size, num_classes)

    def forward(self, x):
        outputs = self.vit(pixel_values=x)
        cls_output = outputs.last_hidden_state[:, 0, :]
        logits = self.classifier(cls_output)
        return logits

class ViTRegressor(nn.Module):
    def __init__(self, pretrained_model_name='google/vit-base-patch16-224'):
        super(ViTRegressor, self).__init__()
        self.vit = ViTModel.from_pretrained(pretrained_model_name)
        self.regressor = nn.Linear(self.vit.config.hidden_size, 1)

    def forward(self, x):
        outputs = self.vit(pixel_values=x)
        cls_output = outputs.last_hidden_state[:, 0, :]
        predictions = self.regressor(cls_output)
        return predictions


import time
import numpy as np
import torch.nn.functional as F
from torch.cuda.amp import GradScaler, autocast
class DeepRegWrapper(BaseEstimator, ClassifierMixin, RegressorMixin):
    def __init__(self, task='classification', in_channels=1, num_classes=10, epochs=10, batch_size=32, learning_rate=0.001, device='cuda', name='alexnet', model_path='path/to/checkpoint'):
        self.task           = task
        self.name           = name
        self.num_classes    = num_classes
        self.epochs         = epochs
        self.in_channels    = in_channels
        self.model_path     = model_path
        self.batch_size     = batch_size
        self.learning_rate  = learning_rate
        self.device         = 'cuda' if torch.cuda.is_available() else 'cpu'
        self.model          = self._create_model().to(self.device)
        self.criterion      = self._create_criterion()
        self.optimizer      = optim.Adam(self.model.parameters(), lr=self.learning_rate)
        self.stats_df       = pd.DataFrame(columns=['model_name', 'batch_size', 'epoch', 'loss', 'accuracy', 'mse', 'memory_usage'])
        print('self.device', self.device)

    def _create_model(self):
        print('create model', self.name)
        # if self.name == 'tcn':
        #     model = TCN(input_size=self.in_channels, output_size=self.num_classes if self.task == 'classification' else 1, num_channels=[64] * 5, kernel_size=3, dropout=0.2)
        # if self.name == 'dcn':
        #     model = DCN(num_continuous=self.in_channels, num_categories=0, embedding_dims=[], num_cross_layers=3, deep_layer_dims=[64, 64], output_dim=self.num_classes if self.task == 'classification' else 1, task=self.task)

        if self.name == 'alexnet':
            model                   = models.alexnet(pretrained=True)
            if self.task == 'classification':
                num_features        = model.classifier[6].in_features
                model.classifier[6] = nn.Linear(num_features, self.num_classes)
            elif self.task == 'regression':
                num_features        = model.classifier[6].in_features
                model.classifier[6] = nn.Linear(num_features, 1)

        if self.name == 'vgg':
            model = models.vgg16(pretrained=True)
            model.features[0]       = nn.Conv2d(1, 64, kernel_size=3, stride=1, padding=1)
            if self.task == 'classification':
                num_features = model.classifier[6].in_features
                model.classifier[6] = nn.Linear(num_features, self.num_classes)
            elif self.task == 'regression':
                # 修改最后一层，输出 1 个值
                num_features        = model.classifier[6].in_features
                model.classifier[6] = nn.Linear(num_features, 1)

        if self.name == 'resnet18':
            model = models.resnet18(pretrained=True)
            if self.task == 'classification':
                num_features = model.fc.in_features
                model.fc = nn.Linear(num_features, self.num_classes)
            elif self.task == 'regression':
                num_features = model.fc.in_features
                model.fc = nn.Linear(num_features, 1)

        if self.name == 'resnet50':
            model = models.resnet50(pretrained=True)
            # 修改第一层卷积，使其接受 1 通道输入
            model.conv1 = nn.Conv2d(1, 64, kernel_size=7, stride=2, padding=3, bias=False)
            # 修改全连接层
            num_features = model.fc.in_features
            if self.task == 'classification':
                model.fc = nn.Linear(num_features, self.num_classes)
            elif self.task == 'regression':
                model.fc = nn.Linear(num_features, 1)

        # 加载预训练的 ResNet101 模型
        if self.name == 'resnet101':
            model = models.resnet101(pretrained=True)
            # 修改第一层卷积，使其接受 1 通道输入
            model.conv1 = nn.Conv2d(1, 64, kernel_size=7, stride=2, padding=3, bias=False)
            # 修改全连接层
            num_features = model.fc.in_features
            if self.task == 'classification':
                model.fc = nn.Linear(num_features, self.num_classes)
            elif self.task == 'regression':
                model.fc = nn.Linear(num_features, 1)

        if self.name == 'mobilenet_v2':
            model = models.mobilenet_v2(pretrained=True)
            if self.task == 'classification':
                num_features = model.classifier[1].in_features
                model.classifier[1] = nn.Linear(num_features, self.num_classes)
            elif self.task == 'regression':
                num_features = model.classifier[1].in_features
                model.classifier[1] = nn.Linear(num_features, 1)

        if self.name == 'unet':
            if self.task == 'classification':
                model = UNet(in_channels=1, out_channels=self.num_classes)  # Assuming 1 input channel
                model.final_conv = nn.Sequential(
                    model.final_conv,
                    nn.Flatten(),
                    nn.Linear(self.num_classes * 64 * 64, self.num_classes)
                )
            elif self.task == 'regression':
                model = UNet(in_channels=1, out_channels=1)  # Assuming 1 input channel
                model.final_conv = nn.Sequential(
                    model.final_conv,
                    nn.Flatten(),
                    nn.Linear(64 * 64, 1)
                )

                # model = DetNet(num_classes=self.num_classes)
        if self.name == 'detnet':
            if self.task == 'classification':
                model = DetNetWithLinear(num_classes=self.num_classes)
            elif self.task == 'regression':
                model = DetNetWithLinear(num_classes=1)
        if self.name == 'fpn':
            if self.name == 'fpn':
                if self.task == 'classification':
                    model = FPN(num_classes=self.num_classes)
                    model.predict_conv = nn.Sequential(
                        model.predict_conv,  # [batch_size, num_classes, H, W]
                        nn.Flatten(),  # [batch_size, num_classes * H * W]
                        nn.Linear(640, self.num_classes)  # 输入大小 = 256 * H * W
                    )
                elif self.task == 'regression':
                    model = FPN(num_classes=1)
                    model.predict_conv = nn.Sequential(
                        model.predict_conv,  # [batch_size, 1, H, W]
                        nn.Flatten(),  # [batch_size, 1 * H * W]
                        nn.Linear(640, 1)  # 输入大小 = 256 * H * W
                    )
        if self.name == 'r_fcn':
            if self.task == 'classification':
                model = R_FCN(num_classes=self.num_classes)
                model.conv2 = nn.Sequential(   model.conv2,  nn.Flatten(),nn.Linear(4*self.num_classes, self.num_classes) )# nn.Conv2d(model.conv2.out_channels, self.num_classes, kernel_size=1),
            elif self.task == 'regression':
                model = R_FCN(num_classes=1)
                model.conv2 = nn.Sequential(model.conv2,   nn.Flatten(), nn.Linear(4*self.num_classes, 1)  )  # nn.Conv2d(model.conv2.out_channels, 1, kernel_size=1),

        if self.name == 'mask_rcnn':
            if self.task == 'classification':
                model = MaskRCNN(num_classes=self.num_classes)
                model.conv2 = nn.Sequential(    model.conv2, nn.Flatten(), nn.Linear(self.num_classes * 2 * 2, self.num_classes) )# nn.Conv2d(model.conv2.out_channels, self.num_classes, kernel_size=1),
            elif self.task == 'regression':
                model = MaskRCNN(num_classes=1)
                model.conv2 = nn.Sequential(  model.conv2,  nn.Flatten(), nn.Linear(2 * 2, 1))# nn.Conv2d(model.conv2.out_channels, 1, kernel_size=1),

        if self.name == 'sam':
            from segment_anything import sam_model_registry, SamPredictor
            model = sam_model_registry["default"](checkpoint=self.model_path)
            model.to(self.device)
        if self.name == 'tcn':
            model = TCN(
                input_size=self.in_channels,  # 输入数据的通道数
                output_size=self.num_classes if self.task == 'classification' else 1,  # 输出大小
                num_layers=5,  # TCN 的层数
                base_channels=64,  # 每层的通道数
                kernel_size=3,  # 卷积核大小
                dropout=0.2  # Dropout 概率
            )
        if self.name == 'vit-base':
            if self.task == 'classification':
                model = ViTClassifier(num_classes=self.num_classes)
            elif self.task == 'regression':
                model = ViTRegressor()
            model.to(self.device)
        # if self.name == 'dcn':
        #     model = DCNWrapper(
        #         num_continuous=self.in_channels,  # 连续特征的维度
        #         num_categories=0,  # 类别特征的维度
        #         embedding_dims=[],  # 类别特征的嵌入维度
        #         num_cross_layers=3,  # 交叉层数
        #         deep_layer_dims=[64, 64],  # 深层网络的维度
        #         output_dim=self.num_classes if self.task == 'classification' else 1,  # 输出维度
        #         task=self.task  # 任务类型
        #     )

        # else:
        #     raise ValueError(f"Unsupported model name: {self.name}")
        return model

    def _create_criterion(self):
        if self.task == 'classification':
            return nn.CrossEntropyLoss()
        elif self.task == 'regression':
            return nn.MSELoss()

    def _adjust_input_size(self, X):
        """根据模型名称调整输入数据的尺寸"""
        target_size = MODEL_INPUT_SIZE.get(self.name, (64, 64))  # 默认尺寸为 64x64
        if target_size is None:  # 如果模型不需要调整尺寸
            return X

        # 如果输入数据是 numpy 数组，转换为 PyTorch 张量
        if isinstance(X, np.ndarray):
            X = torch.tensor(X, dtype=torch.float32)

        # 调整输入数据的形状
        if len(X.shape) == 3:
            # 输入数据形状为 [batch_size, height, width]，添加通道维度 [batch_size, 1, height, width]
            X = X.unsqueeze(1)
        elif len(X.shape) == 4 and X.shape[3] == 3:
            # 输入数据形状为 [batch_size, height, width, 3]，转换为 [batch_size, 3, height, width]
            X = X.permute(0, 3, 1, 2)

        # 将灰度图像转换为 3 通道 [batch_size, 3, height, width]
        if self.name in ['alexnet', 'resnet18', 'mobilenet_v2', 'vit-base']:
            if X.shape[1] == 1:  # 如果输入是单通道图像
                X = X.repeat(1, 3, 1, 1)  # 复制为 3 通道

        # 上采样到目标尺寸
        if X.shape[2:] != target_size:
            X = F.interpolate(X, size=target_size, mode='bilinear', align_corners=False)

        return X
    # def _adjust_input_size(self, X):
    #     """根据模型名称调整输入数据的尺寸"""
    #     target_size = MODEL_INPUT_SIZE.get(self.name, (64, 64))  # 默认尺寸为 64x64
    #     if target_size is None:  # 如果模型不需要调整尺寸
    #         return X
    #
    #     # 添加通道维度 [batch_size, 1, height, width]
    #     if len(X.shape) == 3:
    #         X = X.unsqueeze(1)
    #
    #     # 将灰度图像转换为 3 通道 [batch_size, 3, height, width]
    #     if self.name in ['alexnet', 'resnet18', 'mobilenet_v2','vit-base']:
    #         X = X.repeat(1, 3, 1, 1)
    #     X = F.interpolate(X, size=target_size, mode='bilinear', align_corners=False)  # 上采样到目标尺寸
    #     return X

    def fit(self, X, y):
        # 调整输入数据形状并转换为张量
        X = self._adjust_input_size(X)
        X = torch.tensor(X, dtype=torch.float32)
        y = torch.tensor(y, dtype=torch.long if self.task == 'classification' else torch.float32)

        print('X shape:', X.shape)
        print('y shape:', y.shape)

        # 创建数据集和数据加载器
        dataset = TensorDataset(X, y)
        dataloader = DataLoader(dataset, batch_size=self.batch_size, shuffle=True)

        # 初始化混合精度训练
        scaler = GradScaler()
        self.model.train()

        for epoch in range(self.epochs):
            running_loss = 0.0
            correct = 0
            total = 0
            start_time = time.time()
            # 使用 tqdm 显示进度条
            with tqdm(dataloader, desc=f"Epoch {epoch + 1}/{self.epochs}", unit="batch") as pbar:
                for inputs, targets in pbar:
                    inputs, targets = inputs.to(self.device), targets.to(self.device)
                    self.optimizer.zero_grad()

                    # 使用混合精度训练
                    with autocast():
                        outputs = self.model(inputs)

                        # 计算损失
                        if self.task == 'classification':
                            loss = self.criterion(outputs, targets)
                            _, predicted = torch.max(outputs, 1)
                            total += targets.size(0)
                            correct += (predicted == targets).sum().item()
                        elif self.task == 'regression':
                            loss = self.criterion(outputs.view(-1), targets)

                    # 反向传播和优化
                    scaler.scale(loss).backward()
                    scaler.step(self.optimizer)
                    scaler.update()

                    # 记录损失
                    running_loss += loss.item()

                    # 更新进度条
                    if self.task == 'classification':
                        pbar.set_postfix(loss=running_loss / len(dataloader), accuracy=100 * correct / total)
                    else:
                        pbar.set_postfix(loss=running_loss / len(dataloader))

            end_time     = time.time()
            execute_time = end_time - start_time
            # 计算 epoch 的平均损失和准确率（或均方误差）
            epoch_loss = running_loss / len(dataloader)
            if self.task == 'classification':
                epoch_accuracy = 100 * correct / total
                print(f'Epoch {epoch + 1}/{self.epochs}, Loss: {epoch_loss:.4f}, Accuracy: {epoch_accuracy:.2f}%')
            else:
                epoch_mse = epoch_loss  # 对于回归任务，损失本身就是 MSE
                print(f'Epoch {epoch + 1}/{self.epochs}, Loss: {epoch_loss:.4f}')

            # 记录显存使用情况（仅当使用 GPU 时）
            # memory_usage = torch.cuda.memory_allocated() / (1024 ** 2) if torch.cuda.is_available() else None
                # 记录显存使用情况
            if torch.cuda.is_available():
                memory_allocated = torch.cuda.memory_allocated() / (1024 ** 2)  # 当前分配的显存（MB）
                memory_reserved = torch.cuda.memory_reserved() / (1024 ** 2)  # 当前保留的显存（MB）
                memory_cached = memory_reserved - memory_allocated  # 缓存显存（MB）
                memory_usage = f"Allocated: {memory_allocated:.2f} MB, Reserved: {memory_reserved:.2f} MB, Cached: {memory_cached:.2f} MB"
            else:
                memory_usage = None

            new_row = pd.DataFrame({
                'model_name': [self.name],  # 模型名称
                'batch_size': [self.batch_size],  # batch_size
                'epoch': [epoch + 1],  # 当前 epoch
                'loss': [epoch_loss],  # 平均损失
                'accuracy': [epoch_accuracy if self.task == 'classification' else None],  # 准确率
                'mse': [epoch_mse if self.task == 'regression' else None],  # 均方误差
                'memory_usage': [memory_usage],  # 显存使用量
                'execute_time':[execute_time ]
            })

            # 使用 pd.concat 替代 append
            self.stats_df = pd.concat([self.stats_df, new_row], ignore_index=True)

            # 打印当前 epoch 的统计信息
            print(self.stats_df.tail(1))  # 打印最新一行的统计信息

    def predict(self, X,device='cpu'):
        if isinstance(X,list):
            X = torch.tensor(X,device=device,dtype=torch.float32)
            logging.info("Xshape[%s], X len[%s]",X.shape,len(X))
        X          = self._adjust_input_size( X )
        X          = torch.tensor(X, dtype=torch.float32 )                          #  X = X.reshape(X.shape[0], self.in_channels, 64, 64)
        dataset    = TensorDataset(X)                                               #  torch.tensor(X, dtype=torch.float32)
        dataloader = DataLoader(dataset, batch_size=self.batch_size, shuffle=False)

        self.model.eval()
        predictions = []
        with torch.no_grad():
            for inputs in dataloader:
                inputs = inputs[0].to(self.device)
                outputs = self.model(inputs)
                if self.task == 'classification':
                    _, preds = torch.max(outputs, 1)
                elif self.task == 'regression':
                    preds = outputs.view(-1)
                predictions.extend(preds.cpu().numpy())

        return np.array(predictions)

    def score(self, X, y):
        y_pred = self.predict(X)
        if self.task == 'classification':
            return accuracy_score(y, y_pred)
        elif self.task == 'regression':
            return mean_squared_error(y, y_pred, squared=False)



from sklearn.datasets import make_classification, make_regression
from sklearn.model_selection import train_test_split
def test_deepReg( model_name ):
    # X_train = np.random.rand(100, 64, 64, 3)
    # y_train_cls = np.random.randint(0, 10, 100)
    # y_train_reg = np.random.rand(100)
    #
    # X_test = np.random.rand(20n_feature, 64, 64, 3)
    # y_test_cls = np.random.randint(0, 10, 20)
    # y_test_reg = np.random.rand(20)

    n_class     = 2
    in_channels = 64
    n_feature   = in_channels*1 #in_channels*64 * 64  # 12288
    X, y        = make_classification(n_samples=3000, n_features=n_feature, n_classes=n_class, random_state=999)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=999)
    print('finished split',  X_train.shape, X_test.shape, y_train.shape, y_test.shape  ,X_test.shape )

    # 分类任务
    clf         = DeepRegWrapper(task='classification', name=model_name, num_classes=n_class, epochs=2, in_channels=1)
    clf.fit(X_train, y_train)
    print('Classification accuracy:', clf.score(X_test, y_test))

    # 回归任务测试
    X, y        = make_regression(n_samples=3000, n_features=n_feature, random_state=42)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    reg         = DeepRegWrapper( task='regression',name=model_name )
    print('x y shape',X_train.shape, y_train.shape )
    reg.fit(X_train, y_train)
    y_pred      = reg.predict(X_test)
    print("Regression MSE:", mean_squared_error(y_test, y_pred))
    return

import os
import random
import numpy as np
import pandas as pd
from PIL import Image
from faker import Faker
import torch
from pytorch_widedeep.preprocessing import TabPreprocessor, TextPreprocessor, ImagePreprocessor, WidePreprocessor
from pytorch_widedeep.models import TabMlp, BasicRNN, WideDeep, ModelFuser, Vision
from pytorch_widedeep.training import Trainer
from pytorch_widedeep.losses_multitarget import MultiTargetClassificationLoss
from sklearn.metrics import accuracy_score, mean_squared_error
import pandas as pd
from PIL import Image
# 显示所有列
pd.set_option('display.max_columns', None)
# 显示所有行
pd.set_option('display.max_rows', None)
# 设置每列的最大宽度
pd.set_option('display.max_colwidth', None)
# 设置每行的最大宽度
pd.set_option('display.width', None)

def create_and_save_random_image(image_number, size=(32, 32)):
    if not os.path.exists("images"):
        os.makedirs("images")

    array = np.random.randint(0, 256, (size[0], size[1], 3), dtype=np.uint8)

    image = Image.fromarray(array)

    image_name = f"image_{image_number}.png"
    image.save(os.path.join("images", image_name))

    return image_name
from PIL import Image
import logging
class WideDeepMWrapper:
    def __init__(self, wide_cols=None, crossed_cols=None, embed_cols=None, continuous_cols=None, text_cols=None, img_col=None, img_path=None, objective="binary", custom_loss_function=None, n_epochs=1, batch_size=32, sorted_xcols=[],device='cpu'):
        self.wide_cols = wide_cols
        self.crossed_cols = crossed_cols
        self.embed_cols = embed_cols
        self.continuous_cols = continuous_cols
        self.text_cols = text_cols
        self.img_col = img_col
        self.img_path = img_path
        self.objective = objective
        self.custom_loss_function = custom_loss_function
        self.n_epochs = n_epochs
        self.batch_size = batch_size
        self.model = None
        self.trainer = None
        self.preprocessors = {}
        self.is_trained = False  # Add a flag to indicate if the model is trained
        self.sorted_xcols = sorted_xcols
        self.device      = device #cuda
        logging.info("sorted_xcols:%s",self.sorted_xcols)


    def _create_preprocessors(self, df):
        if self.wide_cols:
            self.preprocessors['wide'] = WidePreprocessor(wide_cols=self.wide_cols, crossed_cols=self.crossed_cols)
        if self.embed_cols or self.continuous_cols:
            self.preprocessors['tab'] = TabPreprocessor(embed_cols=self.embed_cols, continuous_cols=self.continuous_cols)
        if self.text_cols:
            self.preprocessors['text'] = [TextPreprocessor(text_col=col, maxlen=20, max_vocab=100, n_cpus=1) for col in self.text_cols]
        if self.img_col:
            self.preprocessors['img'] = ImagePreprocessor(img_col=self.img_col, img_path=self.img_path)

    def _fit_preprocessors(self, df):
        if 'wide' in self.preprocessors:
            self.preprocessors['wide'].fit_transform(df)
        if 'tab' in self.preprocessors:
            self.preprocessors['tab'].fit_transform(df)
        if 'text' in self.preprocessors:
            for i, preprocessor in enumerate(self.preprocessors['text']):
                self.preprocessors['text'][i] = preprocessor.fit(df)
        if 'img' in self.preprocessors:
            self.preprocessors['img'].fit_transform(df)

    def _create_model(self, df, y):
        components = []
        if 'tab' in self.preprocessors:
            tab_mlp = TabMlp(
                column_idx=self.preprocessors['tab'].column_idx,
                cat_embed_input=self.preprocessors['tab'].cat_embed_input,
                continuous_cols=self.preprocessors['tab'].continuous_cols,
                mlp_hidden_dims=[64, 32],
            )
            components.append(('deeptabular', tab_mlp))
        if 'text' in self.preprocessors:
            rnn_models = []
            for preprocessor in self.preprocessors['text']:
                rnn = BasicRNN(
                    vocab_size=len(preprocessor.vocab.itos),
                    embed_dim=16,
                    hidden_dim=8,
                    n_layers=1,
                )
                rnn_models.append(rnn)
            if len(rnn_models) == 1:
                components.append(('deeptext', rnn_models[0]))
            else:
                models_fuser = ModelFuser(models=rnn_models, fusion_method="mult")
                components.append(('deeptext', models_fuser))
        if 'img' in self.preprocessors:
            vision = Vision(pretrained_model_setup="resnet18", head_hidden_dims=[16, 8])
            components.append(('deepimage', vision))

        # Set pred_dim based on the number of targets
        pred_dim = 1 if y.ndim == 1 else y.shape[1]
        print('pred_dim:',pred_dim)
        self.model = WideDeep(**dict(components), pred_dim=pred_dim)
    def X_map(self,X):
        if  isinstance(X,pd.DataFrame):
            df = X
        else:
            df = pd.DataFrame(X,columns=self.sorted_xcols,index=range(0,len(X)))
        return df

        return
    def fit(self, X, y):
        df = self.X_map(X)
        self._create_preprocessors(df)
        self._fit_preprocessors(df)
        self._create_model(df,y)
        if y.ndim > 1 and y.shape[1] > 1:
            self.objective = "multitarget"
            if self.custom_loss_function is None:
                raise ValueError("Custom loss function must be provided for multitarget objective.")
            self.trainer = Trainer(self.model, objective="multitarget", custom_loss_function=self.custom_loss_function,device=self.device)
        else:
            self.trainer = Trainer(self.model, objective=self.objective,device=self.device)
        # self._fit_preprocessors(df)
        X_processed = {}
        if 'wide' in self.preprocessors:
            X_processed['X_wide']   = torch.tensor(self.preprocessors['wide'].transform(df)).float()
        if 'tab' in self.preprocessors:
            x_tab               = self.preprocessors['tab'].transform(df)
            x_tab               = np.asarray(x_tab,'float32')
            X_processed['X_tab']= x_tab
        if 'text' in self.preprocessors:
            X_processed['X_text'] = [preprocessor.transform(df) for preprocessor in self.preprocessors['text']]
        if 'img' in self.preprocessors:
            X_processed['X_img'] = self.preprocessors['img'].transform(df)

        # Convert target to numpy array or PyTorch tensor
        if isinstance(y, pd.DataFrame):
            y = y.values
        elif isinstance(y, pd.Series):
            y = y.values
        self.trainer.fit(**X_processed, target=y, n_epochs=self.n_epochs, batch_size=self.batch_size)
        self.is_trained = True  # Set the flag to indicate the model is trained

    def score(self, X, y):
        if not self.is_trained:
            raise ValueError("Model is not trained. Call fit method before scoring.")

        df = self.X_map(X)
        X_processed = {}
        if 'wide' in self.preprocessors:
            X_processed['X_wide'] = self.preprocessors['wide'].transform(df)
        if 'tab' in self.preprocessors:
            x_tab = self.preprocessors['tab'].transform(df)
            x_tab = np.asarray(x_tab, 'float32')
            X_processed['X_tab'] = x_tab
        if 'text' in self.preprocessors:
            X_processed['X_text'] = [preprocessor.transform(df) for preprocessor in self.preprocessors['text']]
        if 'img' in self.preprocessors:
            X_processed['X_img'] = self.preprocessors['img'].transform(df)

        predictions = self.trainer.predict(**X_processed)

        if predictions is None:
            # print('X_processed:', X_processed)
            # print('trainer:', self.trainer)
            raise ValueError("Predictions are None. Ensure the model is trained before scoring.")

        if self.objective == "binary":
            return accuracy_score(y, np.round(predictions))
        elif self.objective == "regression":
            return mean_squared_error(y, predictions)
        elif self.objective == "multitarget":
            return accuracy_score(y, np.round(predictions))
        else:
            raise ValueError(f"Unsupported objective: {self.objective}")

    def predict(self, X):
        if not self.is_trained:
            raise ValueError("Model is not trained. Call fit method before predicting.")

        df = self.X_map(X)

        X_processed = {}
        if 'wide' in self.preprocessors:
            X_processed['X_wide'] = self.preprocessors['wide'].transform(df)
        if 'tab' in self.preprocessors:
            x_tab  = self.preprocessors['tab'].transform(df)
            x_tab  = np.asarray( x_tab,'float32' )
            X_processed['X_tab'] = x_tab
        if 'text' in self.preprocessors:
            X_processed['X_text'] = [preprocessor.transform(df) for preprocessor in self.preprocessors['text']]
        if 'img' in self.preprocessors:
            X_processed['X_img'] = self.preprocessors['img'].transform(df)

        return self.trainer.predict(**X_processed)

def test_deepwideMWrapper():
    # 创建数据
    fake = Faker()
    cities = ["New York", "Los Angeles", "Chicago", "Houston"]
    names = ["Alice", "Bob", "Charlie", "David", "Eva"]
    data = {
        "city": [random.choice(cities) for _ in range(100)],
        "name": [random.choice(names) for _ in range(100)],
        "age": [random.uniform(18, 70) for _ in range(100)],
        "height": [random.uniform(150, 200) for _ in range(100)],
        "sentence": [fake.sentence() for _ in range(100)],
        "other_sentence": [fake.sentence() for _ in range(100)],
        "image_name": [create_and_save_random_image(i) for i in range(100)],
        "target": [random.choice([0, 1]) for _ in range(100)],
    }
    df = pd.DataFrame(data)

    # 测试多目标任务
    print("######Testing multi-target task...")
    df["target2"] = [random.choice([0, 1]) for _ in range(100)]
    selected_cols = df.drop(columns=["target", "target2"]).columns
    print('selected_cols:',selected_cols)

    ##mudlti targe has some problem to fix
    # model_multitarget = WideDeepMWrapper(
    #     embed_cols=["city", "name"],
    #     continuous_cols=["age", "height"],
    #     # text_cols=["sentence", "other_sentence"],
    #     # img_col="image_name",
    #     # img_path="images",
    #     objective="multitarget",
    #     custom_loss_function=MultiTargetClassificationLoss(binary_config=[0, 1], reduction="mean"),
    #     sorted_xcols=selected_cols
    # )
    # model_multitarget.fit( df[selected_cols].values, df[["target", "target2"]].values)
    # predictions_multitarget = model_multitarget.predict(df[selected_cols].values)
    # score_multitarget = model_multitarget.score(df.drop(columns=["target", "target2"]).values, df[["target", "target2"]].values)
    # print(f"Multi-target score: {score_multitarget}")

    # 测试回归任务
    print("######Testing regression task...")
    df["target_regression"] = [random.uniform(150, 200) for _ in range(100)]
    model_regression = WideDeepMWrapper(
        embed_cols=["city", "name"],
        continuous_cols=["age", "height"],
        text_cols=["sentence", "other_sentence"],
        img_col="image_name",
        img_path="images",
        objective="regression",
        sorted_xcols=df.drop(columns=["target_regression"]).columns
    )
    model_regression.fit(df.drop(columns=["target_regression"]).values, df["target_regression"].values)
    predictions_regression = model_regression.predict(df.drop(columns=["target_regression"]).values)
    score_regression = model_regression.score(df.drop(columns=["target_regression"]).values, df["target_regression"].values)
    print(f"Regression score: {score_regression}")

    # 测试分类任务
    print("######Testing classification task...")
    model = WideDeepMWrapper(
        embed_cols=["city", "name"],
        continuous_cols=["age", "height"],
        text_cols=["sentence", "other_sentence"],
        img_col="image_name",
        img_path="images",
        objective="binary",
        sorted_xcols=df.drop(columns=["target"]).columns
    )
    model.fit(df.drop(columns=["target"]).values, df["target"].values)
    predictions = model.predict(df.drop(columns=["target"]).values)
    score = model.score(df.drop(columns=["target"]).values, df["target"].values)
    print(f"Classification score: {score}")

def train_epoch(model, train_loader, device, criterion, optimizer, scaler):
    """训练一个 epoch，并返回该 epoch 的平均损失和准确率 参数:
    - model (torch.nn.Module): 训练的模型
    - train_loader (DataLoader): 用于加载训练数据的 DataLoader
    - device (torch.device): 当前模型所在的设备（CPU 或 GPU）
    - criterion (torch.nn.Module): 损失函数
    - optimizer (torch.optim.Optimizer): 优化器
    - scaler (GradScaler): 混合精度训练的梯度缩放器
    返回:
    - epoch_loss (float): 当前 epoch 的平均损失
    - epoch_accuracy (float): 当前 epoch 的准确率
    """
    from torch.cuda.amp import GradScaler, autocast
    model.train()
    running_loss = 0.0
    correct = 0
    total = 0
    with tqdm(train_loader, desc="Training", unit="batch", ncols=100) as pbar:
        for data, target in pbar:
            data, target = data.to(device, non_blocking=True), target.to(device, non_blocking=True)
            optimizer.zero_grad()
            # 混合精度训练
            with autocast():
                output  = model(data)
                loss    = criterion(output, target)

            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()

            running_loss += loss.item()
            _, predicted = torch.max(output, 1)
            total += target.size(0)
            correct += (predicted == target).sum().item()
            # 更新进度条
            pbar.set_postfix(loss=running_loss / (total // len(data)), accuracy=100 * correct / total)

    return running_loss / len(train_loader), 100 * correct / total

def evaluate_model(model, test_loader, device):
    """ 评估模型并返回准确率和前六张图片的预测与标签 """
    model.eval()
    correct = 0
    total = 0
    images, labels, preds = [], [], []

    with torch.no_grad():
        for data, target in test_loader:
            data, target    = data.to(device), target.to(device)
            output          = model(data)
            _, predicted    = torch.max(output, 1)
            total           += target.size(0)
            correct         += (predicted == target).sum().item()

            # 记录前六张图片及其标签和预测
            if len(images) < 6:
                batch_size = data.size(0)
                for i in range(min(6 - len(images), batch_size)):
                    images.append(data[i].cpu())
                    labels.append(target[i].cpu())
                    preds.append(predicted[i].cpu())

    accuracy = 100 * correct / total
    return accuracy, images, labels, preds

def save_model(model, filepath='vggnet_mnist.pth'):
    """
    保存训练的模型到指定文件（覆盖之前的文件）

    参数:
    - model (torch.nn.Module): 训练完成后的模型
    - filepath (str): 保存模型的文件路径，默认 'vggnet_mnist.pth'
    """
    torch.save(model.state_dict(), filepath)
    print(f"Model saved to {filepath}")

def get_optimizer( paramaters ):
    optimizer = optim.AdamW(paramaters, lr=0.001, weight_decay=1e-4)
    return optimizer

def get_criterion():
    criterion = torch.nn.CrossEntropyLoss()
    return criterion


import torch.nn as nn
class VGG(nn.Module):
    def __init__(self, num_classes=10, input_channels=1):
        """
        VGG 网络的初始化方法，包含卷积层和全连接层。
        参数：
        - num_classes (int): 分类的类别数量，默认 10 (适用于 MNIST)
        - input_channels (int): 输入图片的通道数，默认 1 (适用于灰度图像)
        """
        super(VGG, self).__init__()
        # 构建卷积层部分
        self.features = self._make_layers(input_channels)

        # 构建分类器部分
        self.classifier = self._make_classifier(num_classes)

    def _make_layers(self, input_channels):
        """
        构建卷积层部分，通过堆叠卷积层、ReLU 激活和池化层来构建特征提取部分

        参数：
        - input_channels (int): 输入图像的通道数，默认为 1（灰度图）

        返回：
        - features (nn.Sequential): 包含卷积层和池化层的神经网络模块
        """
        layers = []
        # 卷积块 1
        layers += self._conv_block(input_channels, 64)
        # 卷积块 2
        layers += self._conv_block(64, 128)
        # 卷积块 3
        layers += self._conv_block(128, 256)
        # 卷积块 4
        layers += self._conv_block(256, 512)

        # 将所有卷积块和池化层堆叠在一起
        return nn.Sequential(*layers)

    def _conv_block(self, in_channels, out_channels):
        """ 创建一个卷积块，包含两个卷积层和一个最大池化层, 参数：
        - in_channels (int): 输入通道数
        - out_channels (int): 输出通道数
        返回：
        - block (list): 卷积块 [卷积层 + ReLU + 卷积层 + ReLU + 最大池化层]
        """
        block = [
            nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels, out_channels, kernel_size=3, padding=1),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2)
        ]
        return block

    def _make_classifier(self, num_classes):
        """构建全连接层部分，最后的输出层为分类层。参数：  - num_classes (int): 分类类别数
        返回：- classifier (nn.Sequential): 包含全连接层和 Dropout 层的网络模块
        """
        return nn.Sequential(
            nn.Linear(512 * 1 * 1, 4096),
            nn.ReLU(inplace=True),
            nn.Dropout(),
            nn.Linear(4096, 4096),
            nn.ReLU(inplace=True),
            nn.Dropout(),
            nn.Linear(4096, num_classes)
        )

    def forward(self, x):
        """  前向传播方法，输入图像通过卷积层提取特征后再通过全连接层进行分类。
        参数： - x (Tensor): 输入的图像数据
        返回： - x (Tensor): 分类结果"""
        # 通过卷积层提取特征
        x = self.features(x)
        # 将特征图展平为一维向量
        x = x.view(x.size(0), -1)  # 这里将 4D 张量转换为 2D，保留 batch_size
        # 通过分类器进行最终分类
        x = self.classifier(x)
        return x

def initialize_model(device, num_classes=10):
    """    初始化模型和优化器，并将其移动到指定设备
    参数:
    - device (torch.device): 使用的计算设备（CUDA 或 CPU）
    - num_classes (int): 分类任务中的类别数量，默认为 10（MNIST）
    返回:
    - model (torch.nn.Module): 初始化后的模型
    - optimizer (torch.optim.Optimizer): AdamW 优化器
    - criterion (torch.nn.Module): 交叉熵损失函数
    """
    model       = VGG(num_classes=num_classes).to(device)
    optimizer   = optim.AdamW(model.parameters(), lr=0.001, weight_decay=1e-4)
    criterion   = torch.nn.CrossEntropyLoss()
    return model, optimizer, criterion

import torch.optim as optim
from torch.utils.data import DataLoader
from torchvision import datasets, transforms
from tqdm import tqdm

def get_mnist_traindata(batch_size=64, num_workers=2,transform       = transforms.Compose([    transforms.ToTensor(),   transforms.Normalize((0.5,), (0.5,))   ])):
    """  获取 MNIST 数据集的 DataLoader,参数:
    - batch_size (int): 每个 batch 的大小，默认 64
    - num_workers (int): 用于数据加载的线程数，默认 2
    返回:
    - DataLoader: 用于加载 MNIST 训练数据的 DataLoader 对象
    """

    train_dataset   = datasets.MNIST(root='D:/workspace/data', train=True, download=True, transform=transform)
    return DataLoader(  train_dataset, batch_size=batch_size, shuffle=True, num_workers=num_workers )

def get_minist_testdata(batch_size=64, data_dir='D:/workspace/data',transform = transforms.Compose([ transforms.ToTensor(), transforms.Normalize((0.5,), (0.5,))  ])):
    """ 获取 MNIST 测试数据加载器 """
    test_dataset = datasets.MNIST(   root=data_dir, train=False, download=True, transform=transform)
    return DataLoader(test_dataset, batch_size=batch_size, shuffle=False)


class AlexNet(nn.Module):
    def __init__(self,num_classes=10):
        super(AlexNet, self).__init__()
        # 定义卷积层和池化层
        self.num_classes = num_classes
        self.features = nn.Sequential(
            nn.Conv2d(1, 64, kernel_size=11, stride=4, padding=2),  # 第一个卷积层
            nn.ReLU(inplace=True),  # 激活函数
            nn.MaxPool2d(kernel_size=3, stride=2),  # 池化层
            nn.Conv2d(64, 192, kernel_size=5, padding=2),  # 第二个卷积层
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=3, stride=2),
            nn.Conv2d(192, 384, kernel_size=3, padding=1),  # 第三个卷积层
            nn.ReLU(inplace=True),
            nn.Conv2d(384, 256, kernel_size=3, padding=1),  # 第四个卷积层
            nn.ReLU(inplace=True),
            nn.Conv2d(256, 256, kernel_size=3, padding=1),  # 第五个卷积层
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=3, stride=2)  # 池化层
        )
        # 定义全连接层
        self.classifier = nn.Sequential(
            nn.Dropout(),  # Dropout 层，防止过拟合
            nn.Linear(256 * 6 * 6, 4096),  # 第一个全连接层
            nn.ReLU(inplace=True),
            nn.Dropout(),
            nn.Linear(4096, 4096),  # 第二个全连接层
            nn.ReLU(inplace=True),
            nn.Linear(4096, self.num_classes)  # 输出层，10 个类别
        )

    def forward(self, x):
        # 前向传播
        x = self.features(x)  # 卷积层
        x = x.view(x.size(0), -1)  # 展平数据
        x = self.classifier(x)  # 全连接层
        return x

def load_cifar10_batch(file_path):
    import pickle
    """加载单个 CIFAR-10 数据批次"""
    with open(file_path, 'rb') as f:
        batch = pickle.load(f, encoding='latin1')
    return batch


def load_cifar10(data_dir):
    """加载整个 CIFAR-10 数据集"""

    train_data = []
    train_labels = []

    # 加载训练数据（5 个批次）
    for i in range(1, 6):
        file_path = os.path.join(data_dir, f'data_batch_{i}')
        batch = load_cifar10_batch(file_path)
        train_data.append(batch['data'])
        train_labels.append(batch['labels'])

    # 加载测试数据
    test_batch = load_cifar10_batch(os.path.join(data_dir, 'test_batch'))
    test_data = test_batch['data']
    test_labels = test_batch['labels']

    # 合并训练数据
    train_data = np.concatenate(train_data, axis=0)
    train_labels = np.concatenate(train_labels, axis=0)

    # 将数据转换为图像格式 [N, H, W, C]
    train_data = train_data.reshape(-1, 3, 32, 32).transpose(0, 2, 3, 1)
    test_data = test_data.reshape(-1, 3, 32, 32).transpose(0, 2, 3, 1)

    return train_data, train_labels, test_data, test_labels

# 测试代码
if __name__ == "__main__":
    test_dcn()
    test_tcn()

    for model_name in [ 'fpn', 'alexnet','resnet18','mobilenet_v2', 'unet','detnet', 'r_fcn', 'mask_rcnn', 'sam' ]:
        test_deepReg( model_name )

    test_deepwideMWrapper(  )
    #test_dcn(   )
    # # test_tcn()
    # exit()
    # modelname ='sam'
    # for model_name in [ 'fpn', 'alexnet','resnet18','mobilenet_v2', 'unet','detnet', 'r_fcn', 'mask_rcnn', 'sam' ]:
    #     test_deepReg( model_name )
    #
    # for model_name in [  'tcn','dcn' ]: #  'fpn', 'alexnet','resnet18','mobilenet_v2', 'unet','detnet', 'r_fcn', 'mask_rcnn', sam
    #     test_deepReg( model_name )

    # mobilenet_v2 本身在torchvision里
    ## 假设SAM模型已经定义并导入
    # from segment_anything import sam_model_registry, SamPredictor
    # sam = sam_model_registry["default"](checkpoint="path/to/checkpoint")
    #
    #
    # unet      #  only batches of spatial targets supported (3D tensors) but got targets of dimension: 1
    # detnet    #  RuntimeError: only batches of spatial targets supported (3D tensors) but got targets of dimension: 1
    # fpn       #  ValueError: too many values to unpack (expected 4)
    # r_fcn     #  RuntimeError: only batches of spatial targets supported (3D tensors) but got targets of dimension: 1
    # mask_rcnn #  RuntimeError: only batches of spatial targets supported (3D tensors) but got targets of dimension: 1
    # sam       # FileNotFoundError: [Errno 2] No such file or directory: 'path/to/checkpoint'


    # 回归任务
    # reg = DeepRegWrapper(task='regression', name='unet', num_classes=1, epochs=2, in_channels=3)
    # reg.fit(X_train, y_train_reg)
    # print('Regression RMSE:', reg.score(X_test, y_test_reg))
# resnet18
# mobilenet_v2
# unet
# detnet
# fpn
# r_fcn
# mask_rcnn
# sam
#
#
# class CrossLayer(nn.Module):
#     def __init__(self, input_dim):
#         super(CrossLayer, self).__init__()
#         self.weight = nn.Parameter(torch.Tensor(input_dim, 1))
#         self.bias = nn.Parameter(torch.Tensor(input_dim))
#         self.reset_parameters()
#
#     def reset_parameters(self):
#         nn.init.normal_(self.weight)
#         nn.init.zeros_(self.bias)
#
#     def forward(self, x):
#         xw = torch.matmul(x, self.weight)
#         return x * xw + self.bias
#
# class DCN(nn.Module):
#     def __init__(self, num_continuous, num_categories, embedding_dims, num_cross_layers, deep_layer_dims, output_dim, task='classification'):
#         super(DCN, self).__init__()
#         self.task = task
#         self.embeddings         = nn.ModuleList([nn.Embedding(num_embed, embed_dim) for num_embed, embed_dim in embedding_dims[:num_categories] ])
#         embedding_output_dim    = sum(embed_dim for _, embed_dim in embedding_dims[:num_categories])
#         input_dim               = num_continuous + embedding_output_dim
#         print('input_dim num_continuous + embedding_output_dim',input_dim, num_continuous , embedding_output_dim)
#         print('deep_layer_dims[-1]',deep_layer_dims[-1] )
#         self.cross_layers   = nn.ModuleList([CrossLayer(input_dim) for _ in range(num_cross_layers)])
#         self.deep_layers    = nn.ModuleList()
#         for i in range(len(deep_layer_dims)):
#             if i == 0:
#                 self.deep_layers.append(nn.Linear(input_dim, deep_layer_dims[i]))
#             else:
#                 self.deep_layers.append(nn.Linear(deep_layer_dims[i-1], deep_layer_dims[i]))
#             self.deep_layers.append(nn.BatchNorm1d(deep_layer_dims[i]))  # Add BatchNorm
#             self.deep_layers.append(nn.ReLU())
#         self.deep_layers.append( nn.Linear(deep_layer_dims[-1], output_dim) )
#         self.final_layer = nn.Linear(input_dim + output_dim, output_dim)  #deep_layer_dims[-1]
#         if task == 'classification':
#             self.activation = nn.Sigmoid()
#         else:
#             self.activation = nn.Identity()
#         self.init_weights()
#     def init_weights(self):
#         for m in self.modules():
#             if isinstance(m, nn.Linear):
#                 nn.init.xavier_uniform_(m.weight)  # Use Xavier uniform initialization
#                 nn.init.constant_(m.bias, 0)
#             elif isinstance(m, nn.Embedding):
#                 nn.init.normal_(m.weight, mean=0, std=0.01)
#             # if isinstance(m, nn.Linear):
#             #     nn.init.kaiming_normal_(m.weight, mode='fan_in', nonlinearity='relu')
#             #     nn.init.constant_(m.bias, 0)
#             # elif isinstance(m, nn.Embedding):
#             #     nn.init.normal_(m.weight, mean=0, std=0.01)
#
#     def forward(self, continuous_inputs, categorical_inputs):
#         embedding_outputs   = [embedding(categorical_inputs[:, i]) for i, embedding in enumerate(self.embeddings)]
#         embedding_output    = torch.cat(embedding_outputs, dim=1)
#         x                   = torch.cat([continuous_inputs, embedding_output], dim=1)
#         cross_output = x
#         for layer in self.cross_layers:
#             cross_output = layer(cross_output)
#
#         deep_output = x
#         for layer in self.deep_layers:
#             deep_output = layer(deep_output)
#
#         # Concatenate cross_output and deep_output
#         final_output = torch.cat([cross_output, deep_output], dim=1)
#         final_output = self.final_layer(final_output)
#         final_output = self.activation(final_output)
#         return final_output#.squeeze(1)


#
#
# class TCNWrapper(BaseEstimator, ClassifierMixin):
#     def __init__(self, input_size, output_size, num_channels, kernel_size, dropout, epochs=10, batch_size=32, lr=0.001):
#         self.model = TCN(input_size, output_size, num_channels, kernel_size, dropout)
#         self.epochs = epochs
#         self.batch_size = batch_size
#         self.lr = lr
#         self.optimizer = optim.Adam(self.model.parameters(), lr=self.lr)
#         self.criterion = nn.CrossEntropyLoss()
#
#     def fit(self, X, y):
#         self.model.train()
#         dataset = TensorDataset(torch.tensor(X, dtype=torch.float32), torch.tensor(y, dtype=torch.long))
#         dataloader = DataLoader(dataset, batch_size=self.batch_size, shuffle=True)
#
#         for epoch in range(self.epochs):
#             for X_batch, y_batch in tqdm(dataloader, desc=f"Epoch {epoch + 1}/{self.epochs}"):
#                 self.optimizer.zero_grad()
#                 outputs = self.model(X_batch.unsqueeze(1))
#                 loss = self.criterion(outputs, y_batch)
#                 loss.backward()
#                 torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.clip_value)  # Gradient clipping
#                 self.optimizer.step()
#         return self
#
#     def predict(self, X):
#         self.model.eval()
#         with torch.no_grad():
#             X_tensor = torch.tensor(X, dtype=torch.float32)
#             outputs = self.model(X_tensor.unsqueeze(1))
#             _, predicted = torch.max(outputs, 1)
#         return predicted.numpy()
#
#     def score(self, X, y):
#         y_pred = self.predict(X)
#         return accuracy_score(y, y_pred)


# class CrossLayer(nn.Module):
#     def __init__(self, input_dim):
#         super(CrossLayer, self).__init__()
#         self.weight = nn.Parameter(torch.Tensor(input_dim, 1))
#         self.bias = nn.Parameter(torch.Tensor(input_dim))
#         self.reset_parameters()
#
#     def reset_parameters(self):
#         nn.init.normal_(self.weight)
#         nn.init.zeros_(self.bias)
#
#     def forward(self, x):
#         xw = torch.matmul(x, self.weight)
#         return x * xw + self.bias
#
# class DCN(nn.Module):
#     def __init__(self, num_continuous, num_categories, embedding_dims, num_cross_layers, deep_layer_dims, output_dim, task='classification'):
#         super(DCN, self).__init__()
#         self.task = task
#         self.embeddings         = nn.ModuleList([nn.Embedding(num_embed, embed_dim) for num_embed, embed_dim in embedding_dims[:num_categories] ])
#         embedding_output_dim    = sum(embed_dim for _, embed_dim in embedding_dims[:num_categories])
#         input_dim               = num_continuous + embedding_output_dim
#         print('input_dim num_continuous + embedding_output_dim',input_dim, num_continuous , embedding_output_dim)
#         print('deep_layer_dims[-1]',deep_layer_dims[-1] )
#         self.cross_layers   = nn.ModuleList([CrossLayer(input_dim) for _ in range(num_cross_layers)])
#         self.deep_layers    = nn.ModuleList()
#         for i in range(len(deep_layer_dims)):
#             if i == 0:
#                 self.deep_layers.append( nn.Linear(input_dim, deep_layer_dims[i] )  )
#             else:
#                 self.deep_layers.append(nn.Linear(deep_layer_dims[i-1] , deep_layer_dims[i]))
#             self.deep_layers.append(nn.BatchNorm1d( deep_layer_dims[i]) )  # Add BatchNorm
#             self.deep_layers.append(nn.ReLU())
#         self.deep_layers.append( nn.Linear(deep_layer_dims[-1], output_dim) )
#         self.final_layer = nn.Linear(input_dim + output_dim, output_dim)  #deep_layer_dims[-1]
#         if task == 'classification':
#             self.activation = nn.Sigmoid()
#         else:
#             self.activation = nn.Identity()
#         self.init_weights()
#     def init_weights(self):
#         for m in self.modules():
#             if isinstance(m, nn.Linear):
#                 nn.init.xavier_uniform_(m.weight)  # Use Xavier uniform initialization
#                 nn.init.constant_(m.bias, 0)
#             elif isinstance(m, nn.Embedding):
#                 nn.init.normal_(m.weight, mean=0, std=0.01)
#             # if isinstance(m, nn.Linear):
#             #     nn.init.kaiming_normal_(m.weight, mode='fan_in', nonlinearity='relu')
#             #     nn.init.constant_(m.bias, 0)
#             # elif isinstance(m, nn.Embedding):
#             #     nn.init.normal_(m.weight, mean=0, std=0.01)
#
#     def forward(self, continuous_inputs, categorical_inputs):
#         embedding_outputs   = [embedding(categorical_inputs[:, i]) for i, embedding in enumerate(self.embeddings)]
#         embedding_output    = torch.cat(embedding_outputs, dim=1)
#         x                   = torch.cat([continuous_inputs, embedding_output], dim=1)
#         cross_output = x
#         for layer in self.cross_layers:
#             cross_output = layer(cross_output)
#         deep_output = x
#         for layer in self.deep_layers:
#             deep_output = layer(deep_output)
#         # for i, layer in enumerate(self.deep_layers):
#         #     if isinstance(layer, nn.Linear) and i > 0:  # Add residual connection
#         #         deep_output += layer(deep_output)  # Residual connection
#         #     else:
#         #         deep_output = layer(deep_output)
#
#         # Concatenate cross_output and deep_output
#         final_output = torch.cat([cross_output, deep_output], dim=1)
#         final_output = self.final_layer(final_output)
#         final_output = self.activation(final_output)
#         return final_output#.squeeze(1) 请给代码加残差网络，给出完整代码
#
# class DCNWrapper(BaseEstimator, ClassifierMixin):
#     def __init__(self, num_continuous, num_categories, embedding_dims, num_cross_layers, deep_layer_dims, output_dim, task='classification', epochs=10, batch_size=32, lr=0.001,
#                  clip_value=1.0, weight_decay=0.01,thresold=0.5):
#         self.model = DCN(num_continuous, num_categories, embedding_dims, num_cross_layers, deep_layer_dims, output_dim, task)
#         self.epochs     = epochs
#         self.task       = task
#         self.batch_size = batch_size
#         self.lr         = lr
#         self.clip_value = clip_value
#         self.weight_decay=weight_decay
#         self.optimizer = optim.Adam(self.model.parameters(), lr=self.lr, weight_decay=self.weight_decay)
#         self.criterion  = nn.BCELoss() if task == 'classification' else nn.MSELoss()
#         self.thresold   = thresold
#
#     def fit(self, X_continuous, X_categorical, y):
#         self.model.train()
#         dataset    = TensorDataset(torch.tensor(X_continuous, dtype=torch.float32), torch.tensor(X_categorical, dtype=torch.long), torch.tensor(y, dtype=torch.float32))
#         dataloader = DataLoader(dataset, batch_size=self.batch_size, shuffle=True)
#
#         for epoch in range(self.epochs):
#             for X_cont_batch, X_cat_batch, y_batch in tqdm(dataloader, desc=f"Epoch {epoch + 1}/{self.epochs}"):
#                 # print( 'y_batch.shape:',y_batch.shape )
#                 self.optimizer.zero_grad()
#                 outputs = self.model(X_cont_batch, X_cat_batch)
#                 if self.task == 'classification':
#                     y_batch = y_batch.unsqueeze(1)  # Ensure y_batch is (batch_size, 1)
#                 # print('outputs detail:',    outputs)
#                 # print('y_batch detail:',    y_batch)
#                 # print('two shape:', outputs.shape, y_batch.shape  )
#                 loss = self.criterion(outputs, y_batch)
#                 loss.backward()
#                 torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.clip_value)  # Gradient clipping
#                 self.optimizer.step()
#         return self
#
#     def predict(self, X_continuous, X_categorical):
#         self.model.eval()
#         with torch.no_grad():
#             X_cont_tensor   = torch.tensor(X_continuous, dtype=torch.float32)
#             X_cat_tensor    = torch.tensor(X_categorical, dtype=torch.long)
#             outputs         = self.model(X_cont_tensor, X_cat_tensor)
#             if self.model.task == 'classification':
#                 predicted   = (outputs > self.thresold ).float()
#             else:
#                 predicted = outputs
#         return predicted.numpy()
#
#     def score(self, X_continuous, X_categorical, y):
#         y_pred = self.predict(X_continuous, X_categorical)
#         if self.model.task == 'classification':
#             return accuracy_score(y, y_pred)
#         else:
#             return mean_squared_error(y, y_pred)
#
# def test_dcn():
#     # Generate synthetic data
#     X_continuous    = np.random.rand(  1000, 5)  # 1000 samples, 5 continuous features
#     X_categorical   = np.random.randint(0, 10, (1000, 3))  # 1000 samples, 3 categorical features with 10 categories each
#     y               = np.random.randint(0, 2, 1000)  # Binary classification
#
#     print('X_categorical shape:',X_categorical.shape)
#     # Initialize and train the DCN model
#     dcn_model = DCNWrapper(num_continuous=5, num_categories=3, embedding_dims=[(10, 5), (10, 5), (10, 5)], num_cross_layers=6, deep_layer_dims=[10, 10], output_dim=1,
#                            task='classification', epochs=22)
#     dcn_model.fit(X_continuous, X_categorical, y)
#
#     # Predict and score
#     y_pred  = dcn_model.predict(X_continuous, X_categorical)
#     score   = dcn_model.score(X_continuous, X_categorical, y)
#     print(f"DCN Accuracy: {score}")
#
#     ############################################## regresion
#     print('##'*10,'regression')
#     # Generate synthetic data
#     X_continuous    = np.random.rand(1000, 5)  # 1000 samples, 5 continuous features
#     X_categorical   = np.random.randint(0, 10, (1000, 3))  # 1000 samples, 3 categorical features with 10 categories each
#     y               = np.random.rand(1000)  # Regression task
#     # Initialize and train the DCN model
#     dcn_model       = DCNWrapper(num_continuous=5, num_categories=3, embedding_dims=[(10, 5), (10, 5), (10, 5)], num_cross_layers=6, deep_layer_dims=[10, 10], output_dim=1, task='regression',
#                                  epochs=30, clip_value=0.5)
#     dcn_model.fit(X_continuous, X_categorical, y)
#
#     # Predict and score
#     y_pred          = dcn_model.predict(X_continuous, X_categorical)
#     # print('y_pred:',y_pred)
#     score           = dcn_model.score(X_continuous,   X_categorical, y)
#     print(f"DCN MSE: {score}")
#     return
# class CrossLayer(nn.Module):
#     def __init__(self, input_dim):
#         super(CrossLayer, self).__init__()
#         self.weight = nn.Parameter(torch.Tensor(input_dim, 1))
#         self.bias = nn.Parameter(torch.Tensor(input_dim))
#         self.reset_parameters()
#
#     def reset_parameters(self):
#         nn.init.normal_(self.weight)
#         nn.init.zeros_(self.bias)
#
#     def forward(self, x):
#         xw = torch.matmul(x, self.weight)
#         return x * xw + self.bias
#
# class DCN(nn.Module):
#     def __init__(self, num_continuous, num_categories, embedding_dims, num_cross_layers, deep_layer_dims, output_dim, task='classification'):
#         super(DCN, self).__init__()
#         self.task = task
#         self.embeddings = nn.ModuleList([nn.Embedding(num_embed, embed_dim) for num_embed, embed_dim in embedding_dims[:num_categories]])
#         embedding_output_dim = sum(embed_dim for _, embed_dim in embedding_dims[:num_categories])
#         input_dim = num_continuous + embedding_output_dim
#         self.cross_layers = nn.ModuleList([CrossLayer(input_dim) for _ in range(num_cross_layers)])
#         self.deep_layers = nn.ModuleList()
#         for i in range(len(deep_layer_dims)):
#             if i == 0:
#                 self.deep_layers.append(nn.Linear(input_dim, deep_layer_dims[i]))
#             else:
#                 self.deep_layers.append(nn.Linear(deep_layer_dims[i-1], deep_layer_dims[i]))
#             self.deep_layers.append(nn.BatchNorm1d(deep_layer_dims[i]))  # Add BatchNorm
#             self.deep_layers.append(nn.ReLU())
#         self.deep_layers.append(nn.Linear(deep_layer_dims[-1], output_dim))
#         self.final_layer = nn.Linear(input_dim + output_dim, output_dim)  # deep_layer_dims[-1]
#         if task == 'classification':
#             self.activation = nn.Sigmoid()
#         else:
#             self.activation = nn.Identity()
#         self.init_weights()
#
#     def init_weights(self):
#         for m in self.modules():
#             if isinstance(m, nn.Linear):
#                 nn.init.xavier_uniform_(m.weight)  # Use Xavier uniform initialization
#                 nn.init.constant_(m.bias, 0)
#             elif isinstance(m, nn.Embedding):
#                 nn.init.normal_(m.weight, mean=0, std=0.01)
#
#     def forward(self, continuous_inputs, categorical_inputs):
#         embedding_outputs = [embedding(categorical_inputs[:, i]) for i, embedding in enumerate(self.embeddings)]
#         embedding_output = torch.cat(embedding_outputs, dim=1)
#         x = torch.cat([continuous_inputs, embedding_output], dim=1)
#         cross_output = x
#         for layer in self.cross_layers:
#             cross_output = layer(cross_output)
#         deep_output = x
#         for layer in self.deep_layers:
#             deep_output = layer(deep_output)
#         final_output = torch.cat([cross_output, deep_output], dim=1)
#         final_output = self.final_layer(final_output)
#         final_output = self.activation(final_output)
#         return final_output
#
# class DCNWrapper(BaseEstimator, ClassifierMixin):
#     def __init__(self, num_continuous, num_categories, embedding_dims, num_cross_layers, deep_layer_dims, output_dim, task='classification', epochs=10, batch_size=32, lr=0.001,
#                  clip_value=1.0, weight_decay=0.01, threshold=0.5):
#         self.model = DCN(num_continuous, num_categories, embedding_dims, num_cross_layers, deep_layer_dims, output_dim, task)
#         self.epochs = epochs
#         self.task = task
#         self.batch_size = batch_size
#         self.lr = lr
#         self.clip_value = clip_value
#         self.weight_decay = weight_decay
#         self.optimizer = optim.Adam(self.model.parameters(), lr=self.lr, weight_decay=self.weight_decay)
#         self.criterion = nn.BCELoss() if task == 'classification' else nn.MSELoss()
#         self.threshold = threshold
#         self.num_continuous = num_continuous
#         self.num_categories = num_categories
#
#     def fit(self, X, y):
#         self.model.train()
#         X_continuous = X[:, :self.num_continuous]
#         X_categorical = X[:, self.num_continuous:]
#         dataset = TensorDataset(torch.tensor(X_continuous, dtype=torch.float32), torch.tensor(X_categorical, dtype=torch.long), torch.tensor(y, dtype=torch.float32))
#         dataloader = DataLoader(dataset, batch_size=self.batch_size, shuffle=True)
#
#         for epoch in range(self.epochs):
#             for X_cont_batch, X_cat_batch, y_batch in tqdm(dataloader, desc=f"Epoch {epoch + 1}/{self.epochs}"):
#                 self.optimizer.zero_grad()
#                 outputs = self.model(X_cont_batch, X_cat_batch)
#                 if self.task == 'classification':
#                     y_batch = y_batch.unsqueeze(1)  # Ensure y_batch is (batch_size, 1)
#                 loss = self.criterion(outputs, y_batch)
#                 loss.backward()
#                 torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.clip_value)  # Gradient clipping
#                 self.optimizer.step()
#         return self
#
#     def predict(self, X):
#         self.model.eval()
#         X_continuous = X[:, :self.num_continuous]
#         X_categorical = X[:, self.num_continuous:]
#         with torch.no_grad():
#             X_cont_tensor = torch.tensor(X_continuous, dtype=torch.float32)
#             X_cat_tensor = torch.tensor(X_categorical, dtype=torch.long)
#             outputs = self.model(X_cont_tensor, X_cat_tensor)
#             if self.model.task == 'classification':
#                 predicted = (outputs > self.threshold).float()
#             else:
#                 predicted = outputs
#         return predicted.numpy()
#
#     def score(self, X, y):
#         y_pred = self.predict(X)
#         if self.model.task == 'classification':
#             return accuracy_score(y, y_pred)
#         else:
#             return mean_squared_error(y, y_pred)