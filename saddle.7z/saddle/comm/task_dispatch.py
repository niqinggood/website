# -*- coding: utf-8 -*-
import json
from os import makedirs
from random import sample
import pandas
from pandas.core.interchange.dataframe_protocol import DataFrame
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from .logic_dispatch import  str_to_list
import copy
import numpy as np
import networkx as nx
import logging
import os
import pandas as pd
import traceback
from flask import Flask, request, jsonify
import requests
import re
from urllib.parse import urlparse
from typing import Dict, List, Any, Optional
# import seaborn as sns
# import matplotlib.pyplot as plt
# from sklearn.preprocessing import StandardScaler, MinMaxScaler
# from sklearn.linear_model import LinearRegression, Ridge, Lasso
# from sklearn.cross_decomposition import PLSRegression
# from lightgbm import LGBMRegressor
# from swift.llm.dataset.dataset.mllm import subset
# from xgboost import XGBRegressor

global has_import_agent
has_import_agent = False
def download_file_from_url(url, save_path):
    """
    从 URL 下载文件并保存到指定路径
    :param url: 文件的 URL 链接
    :param save_path: 保存文件的路径
    """
    import requests
    try:
        # 发送 GET 请求
        response = requests.get(url, stream=True)
        response.raise_for_status()  # 检查请求是否成功

        # 将文件写入本地
        with open(save_path, 'wb') as file:
            for chunk in response.iter_content(chunk_size=8192):
                file.write(chunk)

        logging.info(f"File downloaded successfully: {save_path}")
    except requests.exceptions.RequestException as e:
        logging.info(f"Error downloading file: {e}")


def load_model(projectName, trainingRecord):
    load_file = os.path.join('projects', projectName,
                             trainingRecord.replace("Result-", '').replace("Result",''),
                             '%s__engine.pkl' % projectName)

    # port       = config_['port']
    # apiUrl     = config_.get('apiUrl','/test')
    ai_agent = joblib.load(load_file)
    return ai_agent





def predict_data_trans( data, labelname, nodetype ):

    if ('CSV' in labelname  or  nodetype not in ["computerVision","ImageProcess","largeModel","nlp"] ) and isinstance(data,str):
        if isinstance( data,str ):
            header, *rows = data.split("|")

            # 将表头和数据转换为列表
            header_list = header.split(",")
            rows_list = [row.split(",") for row in rows]

            # 将数据转换为 Pandas DataFrame
            ret = pd.DataFrame(rows_list, columns=header_list)

            # 打印 DataFrame
            # print(ret)
    else:
        ret = data
    return ret

from PIL import Image
import io
import base64

def image_to_base64(image_path):
    try:
        # 打开图片文件
        with Image.open(image_path) as img:
            # 将图片转换为字节流
            buffered = io.BytesIO()
            img.save(buffered, format="PNG")  # 根据图片格式调整
            # 将字节流转换为Base64编码的字符串
            img_str = base64.b64encode(buffered.getvalue()).decode("utf-8")
            return img_str
    except Exception as e:
        logging.info(f"图片处理失败: {e}")
        return None


def get_infer_dataframe(train_url, inferparams={}):
    try:
        parsed_url = urlparse(train_url)
        logging.info(f"train_url：{train_url}")

        # 提取域名/IP
        host = parsed_url.hostname
        if not host:
            raise ValueError("训练URL格式错误，未包含域名或IP（如localhost、example.com、192.168.1.1）")

        # 提取端口
        default_port = 443 if parsed_url.scheme == 'https' else 80
        port = parsed_url.port if parsed_url.port is not None else default_port

        # -------------------- 优化：提取taskid --------------------
        # 匹配规则：
        # 1. 以"task"开头
        # 2. 后面跟随任意字符（除了/和.，避免跨路径/文件后缀）
        # 3. 排除以.csv结尾的情况
        # 4. 优先选择最长的匹配（避免短匹配）
        path = parsed_url.path
        # 匹配所有可能的taskid（不以.csv结尾）
        taskid_matches = re.findall(r'task[^/.]+', path)
        # 过滤掉以.csv结尾的匹配（防止误匹配文件名）
        valid_taskids = [t for t in taskid_matches if not t.endswith('.csv')]

        if not valid_taskids:
            raise ValueError("训练URL路径中未找到有效的taskid（需包含'task'开头且非.csv结尾的字符串）")

        # 选择最长的有效匹配作为taskid（通常是最完整的）
        taskid = max(valid_taskids, key=len)
        # ---------------------------------------------------------

        logging.info(f"从训练URL提取到：主机={host}，端口={port}，taskid={taskid}")
    except Exception as e:
        logging.error(f"URL解析失败：{str(e)}")
        return None

    # 拼接推理接口URL
    infer_url = f"{parsed_url.scheme}://{host}:{port}/api/infer-fetch-data"
    logging.info(f"生成推理接口URL：{infer_url}，使用taskid={taskid}")

    # 配置POST请求参数
    headers = {"Content-Type": "application/json"}
    post_params = {
        "taskid": taskid,
        "inferparams": inferparams,
        "triggersource": "manual_test"
    }

    # 发送请求并转换为DataFrame
    try:
        response = requests.post(
            url=infer_url,
            data=json.dumps(post_params),
            headers=headers,
            timeout=15
        )
        response.raise_for_status()
        infer_result = response.json()

        if not infer_result.get("success", False):
            raise ValueError(f"推理失败：{infer_result.get('message', '未知错误')}")

        dataframe_data = infer_result.get("dataframe")
        if not dataframe_data or "Columns" not in dataframe_data or "Rows" not in dataframe_data:
            raise KeyError("推理结果缺少'Columns'或'Rows'字段")

        infer_df = pd.DataFrame(
            data=dataframe_data["Rows"],
            columns=dataframe_data["Columns"]
        )
        logging.info("推理数据已转换为DataFrame")
        return infer_df

    except requests.exceptions.RequestException as e:
        logging.error(f"接口请求失败（网络/连接问题）：{str(e)}")
        return None
    except (ValueError, KeyError) as e:
        logging.error(f"数据处理失败：{str(e)}")
        return None

def get_nodes_after(start_node, graph):
    try:
        # 获取完整的拓扑排序
        full_order = list(nx.topological_sort(graph))

        # 检查起始节点是否在拓扑排序中
        if start_node not in full_order:
            return {'error': f"Node '{start_node}' not found in the graph"}

        # 找到起始节点的索引位置
        start_index = full_order.index(start_node)

        # 获取起始节点之后的所有节点（不包含起始节点本身）
        nodes_after = full_order[start_index :]

        return {'order': nodes_after}

    except nx.NetworkXUnfeasible:
        return {'error': 'The graph has a cycle, cannot determine task execution order.'}


def get_subG_order(G, start_operators=None):
    """
    获取任务执行顺序，可指定从特定算子开始

    参数:
        start_operators: 起始算子列表，如果为None则返回完整拓扑排序
    """
    try:
        # 获取完整拓扑排序
        full_order = copy.deepcopy( list(nx.topological_sort(G)) )

        # 如果没有指定起始算子，直接返回完整顺序
        if not start_operators:
            return full_order

        # 找到所有起始算子在拓扑排序中的位置
        start_indices = []
        for op in start_operators:
            if op not in full_order:
                return {'error': f"Operator '{op}' not found in the graph"}
            start_indices.append(full_order.index(op))

        # 找到最早的起始位置
        min_start_index = min(start_indices)

        # 从最早起始位置开始截取，包含所有起始算子及其之后的节点
        filtered_order = full_order[min_start_index:]

        # 进一步过滤：只保留起始算子及其可达节点（确保不会包含起始算子之前的节点）
        # 创建子图包含起始算子及其所有后继节点
        subgraph_nodes = set()
        for op in start_operators:
            # 获取所有可达节点（包括自身）
            reachable = nx.descendants(G, op)
            reachable.add(op)
            subgraph_nodes.update(reachable)

        # 从过滤后的顺序中只保留子图中的节点
        final_order = [node for node in filtered_order if node in subgraph_nodes]

        return final_order

    except nx.NetworkXUnfeasible:
        return {'error': 'The graph has a cycle, cannot determine task execution order.'}
from .Agent  import  LLMAgent
import mlflow
import datetime
import subprocess
class WorkflowEngine:
    def __init__(self, flow_data ,root_dir="projects",work_path=None,execute_time = None    ):
        logging.info('begin init workflow engine: %s %s',work_path,execute_time  )
        self.flow_data      = flow_data
        self.projectname    = flow_data.get('projectName')
        #aiagent = joblib.load(args.load_file)
        if flow_data.get("baseExecuteTime") not in ["", None]:
            excute_r_f = '%s__engine.pkl' % self.projectname
            engine_file = os.path.join(flow_data.get("baseExecuteTime"), excute_r_f)
            logging.info("notice#### :this task will use the previous run result to fast the speed base %s" % engine_file)
            self.pre_engine = joblib.load(engine_file)
        else:
            self.pre_engine = None

        if execute_time!=None:
            self.execute_time = execute_time
        else:
            self.execute_time = 'T' + datetime.datetime.now().strftime("%Y%m%d-%H%M%S")[2:]

        if work_path==None:
            self.project_dir    = os.path.join(root_dir, self.projectname)
            os.makedirs( self.project_dir )
        else:
            self.project_dir    = work_path

        self.nodes          = flow_data.get('nodes', [])
        self.edges          = flow_data.get('edges', [])
        self.G              = nx.DiGraph()
        self.results        = {}
        self.later_addFunc  = {
            "Agent":self.process_agent

        }

        for node in self.nodes:
            self.G.add_node(node['id'], **node)
        for edge in self.edges:
            self.G.add_edge(edge['source'], edge['target'])

        self.entry_node_ids = [node for node in self.G.nodes() if self.G.in_degree(node) == 0 and  self.get_label_byId(node)  not in ['Result'] ]
        self.exit_node_ids  = [node for node in self.G.nodes() if self.G.out_degree(node) == 0 and self.get_label_byId(node) not in ['Result'] ]
        logging.info( 'Entry nodes: %s', self.entry_node_ids  )
        logging.info( 'Exit nodes: %s',  self.exit_node_ids   )

    def get_nodedata_byid(self,node_id):
        node = self.G.nodes[node_id]
        node_data = node.get('data', {})
        return node_data
    def get_label_byId(self,node_id):
        node = self.G.nodes[node_id]
        return node.get('label')
    def get_type_byId(self,node_id):
        node = self.G.nodes[node_id]
        return node.get('type')
    def subf_execute_save(self,node_label,node_id, dependency_dict):

        logging.info("begin sub execute save")
        if not os.path.exists(self.project_dir):
            os.makedirs(self.project_dir)
        algo_labes  = [  'Melt','Pivot','OnlineCtrl','CSV',"If","DataEdit","StatM","MultiModel","Derive","MachineLearning","AutoML", "NeuralNet", "MultiModal", "TimeSeries"]
        if node_label in ['Preprocess',"Derive","StatM","Deduplicate",'KeyFeature', 'Derive', "DataSetSplit", "Fileter", "Append","Merge","dataSource","DataSource"]+algo_labes:

            try:
                logging.info("subf_execute_save node_label:%s,node_id.keys(%s)",node_label,self.results[node_id].keys() )
                for key in self.results[node_id].keys():
                    logging.info("save node reslult key[%s],dest_project_dir[%s] type[%s]", key, self.project_dir, type(self.results[node_id][key]))

                    if "models_dict" == key:  #saved_mode_dict['models_dict']
                        from .logic_dispatch import save_model
                        save_model( self.results[node_id][key],os.path.join(self.project_dir, self.execute_time),
                                    node_id + "__" + key  )
                    if isinstance(self.results[node_id][key], pd.DataFrame) == True :
                        file_path = os.path.join(self.project_dir,self.execute_time, node_id + "__" + key + ".csv")
                        logging.info("file_path:%s", file_path)


                            # mlflow.log_input(dataset=mlflow.data.from_pandas(self.results[node_id][key].head(10)),
                            #                  context=file_path,tags=None )

                        #columns = 'key,DType,MAE,MSE,STD,ABS_STD,R2,MAPE,max_diff,min_diff,Len,small_except_ratio,big_except_ratio'.split(',')
                        self.results[node_id][key].to_csv(file_path, index=False)
                        if  dependency_dict.get( "use_mlflow" ) ==True:   #use_mlflow==True:
                            logging.info("begin ##log input file_path:%s", file_path)
                            mlflow.log_artifact(file_path, artifact_path=None)
                    if key in ['mets_df']:
                        tmp_df           = copy.deepcopy(  self.results[node_id][key]    )
                        tmp_df['source'] = node_id
                        file_path        = os.path.join(  self.project_dir,  self.execute_time  ,"all"+"__"+key + ".csv" )
                        columns          = 'source,key,DType,MAE,MSE,STD,ABS_STD,R2,MAPE,max_diff,min_diff,Len'.split(',')
                        tmp_df[columns].to_csv( file_path ,index=False,mode='a')
                        del tmp_df
            except:
                logging.error(traceback.format_exc())
                logging.error("%s %s ", node_label, node_id)
        logging.info("finish sub execute save")
        return

    def _execute_condition_node(self, node_id, node_data, dependency_dict):
        """
        执行条件节点，根据条件选择分支
        """
        logging.info("begin if node _execute_condition_node ")

        pre_node_ids = node_data.get('prenodeId')
        if not pre_node_ids:
            logging.error(f"Condition node {node_id} has no prenode")
            return {'error': 'No prenode found', 'next_nodes': []}

        pre_node_id = pre_node_ids[0]
        pre_node_result = self.results.get(pre_node_id)

        if pre_node_result is None:
            logging.error(f"No data found for prenode {pre_node_id}")
            return {'error': 'No prenode data', 'next_nodes': []}

        logging.info("in if nodes pre_node_result keys: %s", pre_node_result.keys())

        try:
            # 获取条件配置 - 从 config 中获取
            config = node_data.get('config', {})
            conditions = config.get('conditions', [])
            if not conditions:
                logging.warning(f"Condition node {node_id} has no conditions configured")
                return {'error': 'No conditions configured', 'next_nodes': []}

            logging.info(f"Evaluating {len(conditions)} conditions")

            # 评估条件
            selected_branch = self._evaluate_conditions(conditions, pre_node_result)

            if selected_branch:
                # 找到选中分支对应的输出边
                next_node_id = self._find_next_node_by_branch(node_id, selected_branch['id'])
                logging.info(f"Condition node {node_id} selected branch: {selected_branch['type']} ({selected_branch['id']}), next node: {next_node_id}")

                # 返回结果，包含选中的下一个节点
                result = pre_node_result.copy()
                result['next_nodes'] = [next_node_id] if next_node_id else []
                result['selected_branch'] = selected_branch['id']
                return result
            else:
                logging.warning(f"Condition node {node_id} no branch condition matched")
                result = pre_node_result.copy()
                result['next_nodes'] = []
                return result

        except Exception as e:
            logging.error(f"Error executing condition node {node_id}: {str(e)}")
            import traceback
            logging.error(traceback.format_exc())
            result = pre_node_result.copy() if pre_node_result else {}
            result['next_nodes'] = []
            return result

    def process_for(self, node_id, node_data, task,sample_dict={}):
        """
        处理 For 循环节点
        """
        try:
            logging.info(f"Processing For node {node_id}, task: {task}")

            # 获取迭代配置
            config = node_data.get("config", {})
            iteration_source = config.get("iterationSource", "dynamic")
            summary_strategy = config.get("summaryStrategy", "last_only")
            parallel_execution = config.get("parallelExecution", False)

            # 获取迭代列表
            iteration_list = self._get_iteration_list(node_id, config, iteration_source)
            if not iteration_list:
                logging.warning(f"For node {node_id}: 迭代列表为空")
                return self._create_empty_result(node_id)

            logging.info(f"For node {node_id}: 迭代次数 {len(iteration_list)}")

            # 获取子图执行顺序
            subgraph_start =  node_data.get("forIterationStartNextNodeId")#self._get_next_node_id(node_id)
            if not subgraph_start:
                logging.error(f"For node {node_id}: 找不到子图起始节点")
                return self._create_empty_result(node_id)

            task_order = get_subG_order(self.G, subgraph_start)
            logging.info(f"For node {node_id}: 子图执行顺序 {task_order}")

            # 执行迭代
            iteration_results = []
            # for i, item in enumerate(iteration_list):
            #     logging.info(f"For node {node_id}: 开始第 {i + 1}/{len(iteration_list)} 次迭代")
            #
            #     # 设置当前迭代项到上下文
            #     iteration_context = {
            #         "current_iteration": i,
            #         "current_item": item,
            #         "total_iterations": len(iteration_list),
            #         "for_node_id": node_id
            #     }
            #
            #     # 执行子图
            #     result = self._execute_subgraph_iteration( task_order, iteration_context, task, node_id,sample_dict )
            #
            #     iteration_results.append( result )
            #
            #     # 检查是否需要提前终止
            #     if self._should_break_early(config, iteration_context, result):
            #         logging.info(f"For node {node_id}: 满足提前终止条件，终止迭代")
            #         break
            # 执行迭代（支持并行）
            if parallel_execution:
                iteration_results = self._execute_parallel_iterations(
                    iteration_list, task_order, node_id, task, sample_dict  )
            else:
                iteration_results = self._execute_sequential_iterations(
                    iteration_list, task_order, node_id, task, sample_dict
                )


            # 汇总结果
            final_result = self._summarize_results(
                iteration_results, summary_strategy, config, iteration_list
            )

            # 设置跳过节点（除了第一个后续节点）
            self._setup_skip_nodes(node_id, task_order)

            return self._create_final_result(node_id, final_result, iteration_results)

        except Exception as e:
            logging.error(f"For node {node_id} 处理失败: {str(e)}")
            return self._create_error_result(node_id, str(e))

    def _execute_sequential_iterations(self, iteration_list, task_order, for_node_id, task, sample_dict):
        """顺序执行迭代"""
        iteration_results = []

        for i, item in enumerate(iteration_list):
            logging.info(f"For node {for_node_id}: 开始第 {i + 1}/{len(iteration_list)} 次迭代")

            iteration_context = {
                "current_iteration": i,
                "current_item": item,
                "total_iterations": len(iteration_list),
                "for_node_id": for_node_id
            }

            # 执行子图
            result = self._execute_subgraph_iteration(
                task_order, iteration_context, task, for_node_id, sample_dict
            )

            iteration_results.append(result)

            # 检查是否需要提前终止
            if self._should_break_early(for_node_id, iteration_context, result):
                logging.info(f"For node {for_node_id}: 满足提前终止条件，终止迭代")
                break

        return iteration_results
    def _get_iteration_list(self, node_id, config, iteration_source):
        """
        获取迭代列表
        """
        if iteration_source == "static":
            # 静态列表
            static_list = config.get("staticList", [])
            if isinstance(static_list, str):
                try:
                    import json
                    static_list = json.loads(static_list)
                except:
                    logging.error(f"For node {node_id}: 静态列表JSON解析失败")
                    return []
            return static_list if isinstance(static_list, list) else []

        elif iteration_source == "dynamic":
            # 动态输入 - 从前置节点获取
            dynamic_source = config.get("dynamicSource")
            iteration_variable = config.get("iterationVariable")

            if not dynamic_source or not iteration_variable:
                logging.error(f"For node {node_id}: 动态源配置不完整")
                return []

            # 获取前置节点的结果
            pre_node_result = self.results.get(dynamic_source, {})
            data = pre_node_result.get("data", {})

            # 从变量路径获取迭代列表
            return self._get_value_from_path(data, iteration_variable, [])

        return []

    def _get_value_from_path(self, data, path, default=None):
        """
        从嵌套字典中根据路径获取值
        """
        try:
            keys = path.split('.')
            current = data
            for key in keys:
                if isinstance(current, dict) and key in current:
                    current = current[key]
                else:
                    return default
            return current if current is not None else default
        except:
            return default
    #self, node_id, node_label, node_data, task, sample_dict, dependency_dict
    def switch_excute(self,node_id,node_type,node_label,node_data,task,sample_dict={},dependency_dict={},swith_pass_case_nodes=set()):
        ret_={}
        if node_type == 'dataSource':
            ret_ = self.process_data_source(node_id, node_label, node_data, task, sample_dict)
        elif node_label == 'Preprocess':
            ret_ = self.preprocess_data(node_id, node_data, task, inf_dict)

        elif node_label == 'Merge':
            ret_ = self.process_merge(node_id, node_data, task)
        elif node_label in ['StatM', 'NeuralNet', 'AutoML', 'MultiModal', 'TimeSeries']:
            ret_ = self.process_algorithm(node_id, node_data, task, sample_dict)
        elif node_label in ["MultiModel"]:
            ret_ = self.process_multimodel(node_id, node_data, task, sample_dict)
        elif node_label == 'Derive':
            ret_ = self.process_feature_derive(node_data, self.results, task)
        elif node_label == 'Append':
            ret_ = self.process_append(node_id, node_data, task)
        elif node_label == 'Filter':
            ret_ = self.process_filter(node_id, node_data, task)
        elif node_label == 'DataEdit':
            ret_ = self.process_dataedit(node_id, node_data, task)

        elif node_label == 'EDA':
            ret_ = self.process_eda(node_id, node_data, task)
        elif node_label == 'Correlation':
            ret_ = self.process_correlation_analysis(node_id, node_data, task)
        elif node_label == '数据分布':
            ret_ = self.process_data_distribution(node_data, self.results)
        elif node_label in ['KeyFeature']:
            ret_ = self.process_feature_importance(node_data, self.results)
        elif node_label == "Rename":
            ret_ = self.process_rename(node_id, node_data, task)
        elif node_label == "PivotTable":
            ret_ = self.process_pivottable(node_id, node_data, task)

        elif node_label == "Candidate":
            ret_ = self.process_candidate(node_id, node_data, task)
        elif node_label == 'Deduplicate':
            ret_ = self.process_Deduplicate(node_id, node_data, task)

        elif node_label == 'Sample':
            ret_ = self.process_sample(node_id, node_data, task)

        elif node_label == 'Melt':
            ret_ = self.process_melt( node_id, node_data, task)

        elif node_label == 'TypeTransform':
            ret_ = self.process_type_transform(node_id, node_data, task)

        elif node_label == 'DataBase':
            ret_ = self.process_database(node_id, node_data, task)

        elif node_label == "DataSetSplit":
            ret_ = self.process_data_split(node_id, node_data, task)

        elif node_label == 'Sort':
            ret_ = self.process_sort(node_id, node_data, task)

        elif node_label == 'OnlineCtrl':
            ret_ = self.process_onlineCtrl(node_id, node_data, self.results, task)

        elif node_label == "ImageSource":
            ret_ = self.process_images_source(node_id, node_data, task, sample_dict)

        elif node_label == "ImageClassify":
            ret_ = self.process_images_algo(node_id, node_data, task, sample_dict)

        elif node_label == 'ObjectDetect':
            ret_ = self.process_image_detect(node_id, node_data, task, sample_dict)
        elif node_label == "ImageSegment":
            ret_ = self.process_image_seg(node_id, node_data, task, sample_dict)
        elif node_label == "Agent":
            ret_ = self.process_agent(node_id, node_data, task, sample_dict)

        elif node_label in ["If"]:  # "For"
            ret_ = self._execute_condition_node(node_id, node_data, dependency_dict)
            logging.info("result keys:%s", ret_.keys())
            logging.info("next nodes:%s", ret_["next_nodes"])
        elif node_label in ["For"]:  # "For"
            ret_ = self.process_for(node_id, node_data, task)
            for kk in  node_data.get("forIterationStartNextNodeId",[]):
                swith_pass_case_nodes.add( kk )
                if kk not in self.results: self.results[kk]={}
                self.results[kk]["status"]  =   "success"
                self.results[kk]["message"] =   ""
                self.results[kk]["progress"]=   100
            logging.info("result keys:%s", ret_.keys())
        else:
            proc_func = self.later_addFunc.get(node_label)
            if proc_func != None:
                ret_ = proc_func(node_id, node_data, task, sample_dict)
            else:
                logging.info("unknow node_label[%s]", node_label)
        return ret_

    def _execute_subgraph_iteration(self, task_order, iteration_context, task, for_node_id,sample_dict={},dependency_dict={}):
        """
        执行单次迭代的子图
        """
        config.get('errorHandling', 'continue')
        iteration_results = {}

        for current_node_id in task_order:
            try:
                # 跳过 For 节点自身（避免递归）
                if current_node_id == for_node_id:
                    continue

                node = self.G.nodes[current_node_id] #
                node_data = node.get('data', {})
                node_label = node_data.get("label", "")
                node_type = node.get('type')
                logging.info(f"迭代执行节点: {current_node_id} ({node_label})")
                config    = node_data.get("config")


                if node_label=='For':
                    result ={"error":"can not use for in for Graph","message":"can not use for in for Graph"}
                    return result
                else:
                    node_data["iteration_context"] = iteration_context
                    #self,node_id,node_label,node_data,task,sample_dict={},dependency_dict={}
                    result = self.switch_excute(current_node_id,node_type,node_label,node_data,task,sample_dict,dependency_dict)
                iteration_results[current_node_id] = result

            except Exception as e:
                import traceback
                logging.info("error:%s",traceback.format_exc() )
                logging.error(f"迭代执行节点 {current_node_id} 失败: {str(e)}")
                iteration_results[current_node_id] = {
                    "error": str(e),
                    "status": "error",
                    "message": f"迭代执行失败: {str(e)}"
                }
                error_handling =  config.get('errorHandling', 'continue')
                if error_handling == "stop":
                    raise e
                elif error_handling == "retry":
                    # 简化的重试逻辑，实际可以更复杂
                    try:
                        result = self.switch_excute(
                            current_node_id, node_type, node_label, node_data,
                            task, sample_dict, current_dependency_dict
                        )
                        iteration_results[current_node_id] = result
                    except Exception as retry_error:
                        logging.error(f"重试执行节点 {current_node_id} 失败: {str(retry_error)}")
                        # 重试失败后根据策略决定
                        if error_handling == "retry":
                            continue  # 继续下一个节点

        return iteration_results

    def _should_break_early(self, config, iteration_context, result):
        """
        检查是否满足提前终止条件
        """
        break_condition = config.get("breakCondition", "").strip()
        if not break_condition:
            return False

        try:
            # 简单的条件判断实现
            # 这里可以根据实际需求扩展更复杂的条件解析
            context = {
                "iteration": iteration_context["current_iteration"],
                "index": iteration_context["current_iteration"],
                "item": iteration_context["current_item"],
                "total": iteration_context["total_iterations"]
            }

            # 添加结果指标到上下文
            for node_id, node_result in result.items():
                if isinstance(node_result, dict) and "metrics" in node_result:
                    for metric_name, metric_value in node_result["metrics"].items():
                        context[metric_name] = metric_value

            # 执行条件判断（简化版）
            # 实际使用时可能需要更安全的条件执行方式
            condition_met = eval(break_condition, {"__builtins__": {}}, context)
            return bool(condition_met)

        except Exception as e:
            logging.warning(f"提前终止条件解析失败: {str(e)}")
            return False

    def _summarize_results(self, iteration_results, strategy, config, iteration_list):
        """
        汇总迭代结果
        """
        if not iteration_results:
            return {}

            # 过滤掉有错误的结果（根据配置决定）
        valid_results = self._filter_valid_results(iteration_results, config)

        if not valid_results:
            logging.warning("所有迭代结果都包含错误")
            return self._create_error_summary(iteration_results)

        if strategy == "last_only":
            return self._summarize_last_only(valid_results)

        elif strategy == "all_results":
            return self._summarize_all_results(valid_results, iteration_list)

        elif strategy in ["max_metric", "min_metric"]:
            return self._summarize_by_metric(valid_results, config, strategy)

        elif strategy == "with_metadata":
            return self._summarize_with_metadata(valid_results, iteration_list, config)

        elif strategy == "kv_lookup":
            return self._summarize_kv_lookup(valid_results, config, iteration_list)

        else:
            logging.warning(f"未知的汇总策略: {strategy}，使用默认策略")
            return self._summarize_last_only(valid_results)

    def _filter_valid_results(self, iteration_results, config):
        """
        过滤有效结果
        """
        error_handling = config.get('errorHandling', 'continue')

        if error_handling == 'continue':
            # 跳过有错误的结果
            return [result for result in iteration_results if not self._has_critical_error(result)]
        else:
            # 包含所有结果
            return iteration_results

    def _has_critical_error(self, result):
        """
        检查结果是否包含关键错误
        """
        if not isinstance(result, dict):
            return False

        # 检查节点级别的错误
        for node_id, node_result in result.items():
            if isinstance(node_result, dict) and node_result.get('status') == 'error':
                return True
        return False

    def _summarize_last_only(self, valid_results):
        """仅最后一次结果"""
        if not valid_results:
            return {}
        return valid_results[-1]

    def _summarize_all_results(self, valid_results, iteration_list):
        """所有结果"""
        return {
            "all_iterations": valid_results,
            "iteration_count": len(valid_results),
            "iteration_items": iteration_list[:len(valid_results)],
            "summary_type": "all_results"
        }

    def _summarize_by_metric(self, valid_results, config, strategy):
        """根据指标选择最佳结果"""
        metric_field = config.get("metricField", "score")
        best_result = None
        best_value = None
        best_index = -1

        for i, result in enumerate(valid_results):
            current_value = self._find_metric_in_result(result, metric_field)

            if current_value is not None:
                if best_value is None:
                    best_value = current_value
                    best_result = result
                    best_index = i
                elif strategy == "max_metric" and current_value > best_value:
                    best_value = current_value
                    best_result = result
                    best_index = i
                elif strategy == "min_metric" and current_value < best_value:
                    best_value = current_value
                    best_result = result
                    best_index = i

        if best_result is not None:
            return {
                "best_result": best_result,
                "best_metric_value": best_value,
                "best_iteration_index": best_index,
                "metric_field": metric_field,
                "strategy": strategy,
                "summary_type": "best_by_metric"
            }
        else:
            logging.warning(f"未找到指标字段 '{metric_field}'，返回最后一次结果")
            return valid_results[-1] if valid_results else {}

    def _summarize_with_metadata(self, valid_results, iteration_list, config):
        """带元数据的完整结果"""
        # 计算统计信息
        metrics_stats = self._calculate_metrics_statistics(valid_results)

        return {
            "iterations": valid_results,
            "metadata": {
                "total_iterations": len(valid_results),
                "completed_iterations": len([r for r in valid_results if not self._has_critical_error(r)]),
                "iteration_items": iteration_list[:len(valid_results)],
                "metrics_statistics": metrics_stats,
                "summary_strategy": config.get("summaryStrategy", "with_metadata"),
                "execution_info": self._collect_execution_info(valid_results)
            }
        }

    def _summarize_kv_lookup(self, valid_results, config, iteration_list):
        """KV 查找表模式 - 特别适用于推理场景"""
        lookup_key = config.get("lookupKey", "id")
        lookup_value = config.get("lookupValue", "")

        lookup_table = {}
        failed_lookups = []

        for i, (item, result) in enumerate(zip(iteration_list, valid_results)):
            try:
                # 生成键
                key = self._extract_lookup_key(item, lookup_key, i)

                # 生成值
                value = self._extract_lookup_value(result, lookup_value)

                if key is not None:
                    lookup_table[key] = {
                        "value": value,
                        "iteration_index": i,
                        "source_item": item,
                        "result_metadata": self._extract_result_metadata(result)
                    }
                else:
                    failed_lookups.append(i)

            except Exception as e:
                logging.warning(f"KV查找表构建失败于迭代 {i}: {str(e)}")
                failed_lookups.append(i)

        return {
            "lookup_table": lookup_table,
            "key_field": lookup_key,
            "value_field": lookup_value if lookup_value else "full_result",
            "total_entries": len(lookup_table),
            "failed_lookups": failed_lookups,
            "summary_type": "kv_lookup"
        }

    def _extract_lookup_key(self, item, lookup_key, default_index):
        """提取查找键"""
        if isinstance(item, dict):
            return item.get(lookup_key, default_index)
        elif hasattr(item, '__dict__'):
            return getattr(item, lookup_key, default_index)
        else:
            return default_index

    def _extract_lookup_value(self, result, lookup_value_path):
        """提取查找值"""
        if not lookup_value_path:
            return result

        # 支持路径查找，如 "model.output.prediction"
        return self._find_value_in_result(result, lookup_value_path)

    def _calculate_metrics_statistics(self, valid_results):
        """计算指标统计信息"""
        all_metrics = {}

        for result in valid_results:
            metrics = self._extract_all_metrics(result)
            for metric_name, metric_value in metrics.items():
                if metric_name not in all_metrics:
                    all_metrics[metric_name] = []
                if metric_value is not None:
                    all_metrics[metric_name].append(metric_value)

        statistics = {}
        for metric_name, values in all_metrics.items():
            if values:
                statistics[metric_name] = {
                    "mean": sum(values) / len(values),
                    "min": min(values),
                    "max": max(values),
                    "std": self._calculate_std(values),
                    "count": len(values)
                }

        return statistics

    def _extract_all_metrics(self, result):
        """从结果中提取所有指标"""
        metrics = {}

        if not isinstance(result, dict):
            return metrics

        for node_id, node_result in result.items():
            if isinstance(node_result, dict):
                # 从metrics字段提取
                node_metrics = node_result.get("metrics", {})
                for k, v in node_metrics.items():
                    metrics[f"{node_id}.{k}"] = v

                # 从data字段提取数值型数据
                node_data = node_result.get("data", {})
                if isinstance(node_data, dict):
                    for k, v in node_data.items():
                        if isinstance(v, (int, float)):
                            metrics[f"{node_id}.data.{k}"] = v

        return metrics

    def _calculate_std(self, values):
        """计算标准差"""
        if len(values) <= 1:
            return 0
        mean = sum(values) / len(values)
        variance = sum((x - mean) ** 2 for x in values) / (len(values) - 1)
        return variance ** 0.5

    def _collect_execution_info(self, valid_results):
        """收集执行信息"""
        total_nodes = 0
        successful_nodes = 0
        failed_nodes = 0

        for result in valid_results:
            for node_id, node_result in result.items():
                total_nodes += 1
                if isinstance(node_result, dict) and node_result.get('status') == 'success':
                    successful_nodes += 1
                else:
                    failed_nodes += 1

        return {
            "total_nodes_executed": total_nodes,
            "successful_nodes": successful_nodes,
            "failed_nodes": failed_nodes,
            "success_rate": successful_nodes / total_nodes if total_nodes > 0 else 0
        }

    def _create_empty_summary(self, strategy):
        """创建空汇总结果"""
        return {
            "summary_type": strategy,
            "message": "没有有效的迭代结果",
            "iteration_count": 0
        }

    def _create_error_summary(self, iteration_results):
        """创建错误汇总结果"""
        error_count = sum(1 for result in iteration_results if self._has_critical_error(result))

        return {
            "summary_type": "error_summary",
            "total_iterations": len(iteration_results),
            "error_iterations": error_count,
            "error_rate": error_count / len(iteration_results) if iteration_results else 0,
            "message": f"{error_count}/{len(iteration_results)} 次迭代包含错误"
        }

    def _execute_parallel_iterations(self, iteration_list, task_order, for_node_id, task, sample_dict):
        """
        并行执行迭代（如果配置启用）
        """
        config = self.G.nodes[for_node_id].get('data', {}).get('config', {})

        if not config.get('parallelExecution', False):
            # 顺序执行
            return self._execute_sequential_iterations(iteration_list, task_order, for_node_id, task, sample_dict)

        try:
            import concurrent.futures
            max_workers = config.get('maxParallelWorkers', 4)

            with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
                future_to_iteration = {}

                for i, item in enumerate(iteration_list):
                    iteration_context = {
                        "current_iteration": i,
                        "current_item": item,
                        "total_iterations": len(iteration_list),
                        "for_node_id": for_node_id
                    }

                    future = executor.submit(
                        self._execute_single_iteration,
                        task_order, iteration_context, task, for_node_id, sample_dict
                    )
                    future_to_iteration[future] = i

                # 收集结果
                iteration_results = [None] * len(iteration_list)
                for future in concurrent.futures.as_completed(future_to_iteration):
                    i = future_to_iteration[future]
                    try:
                        result = future.result()
                        iteration_results[i] = result
                    except Exception as e:
                        logging.error(f"并行迭代 {i} 执行失败: {str(e)}")
                        iteration_results[i] = {"error": str(e)}

                return iteration_results

        except ImportError:
            logging.warning("concurrent.futures 不可用，回退到顺序执行")
            return self._execute_sequential_iterations(iteration_list, task_order, for_node_id, task, sample_dict)

    def _execute_single_iteration(self, task_order, iteration_context, task, for_node_id, sample_dict):
        """执行单次迭代（用于并行执行）"""
        # 创建独立的执行上下文避免竞争条件
        original_results = self.results.copy()
        try:
            return self._execute_subgraph_iteration(
                task_order, iteration_context, task, for_node_id, sample_dict
            )
        finally:
            self.results = original_results

    def _find_value_in_result(self, result, path):
        """
        从结果中根据路径查找值
        """
        return self._get_value_from_path(result, path)

    def _setup_skip_nodes(self, for_node_id, task_order):
        """
        设置跳过节点（除了第一个后续节点）
        """
        if not hasattr(self, 'switch_pass_case_nodes'):
            self.switch_pass_case_nodes = set()

        # 将子图中除了第一个节点外的所有节点添加到跳过集合
        if len(task_order) > 1:
            skip_nodes = set(task_order[1:])  # 跳过第一个节点之后的所有节点
            self.switch_pass_case_nodes.update(skip_nodes)
            logging.info(f"For node {for_node_id}: 设置跳过节点 {skip_nodes}")

    def _get_next_node_id(self, node_id):
        """
        获取节点的第一个后续节点ID（子图起始节点）
        """
        successors = list(self.G.successors(node_id))
        return successors[0] if successors else None

    def _create_empty_result(self, node_id):
        """创建空结果"""
        return {
            "node_id": node_id,
            "data": {},
            "metrics": {},
            "next_nodes": [],
            "status": "completed",
            "message": "迭代列表为空"
        }

    def _create_final_result(self, node_id, final_result, iteration_results):
        """创建最终结果"""
        return {
            "node_id": node_id,
            "data": final_result,
            "metrics": {
                "iteration_count": len(iteration_results),
                "completed_iterations": len([r for r in iteration_results if not r.get("error")])
            },
            "next_nodes": self._get_next_nodes(node_id),
            "status": "completed",
            "message": f"完成 {len(iteration_results)} 次迭代"
        }

    def _create_error_result(self, node_id, error_msg):
        """创建错误结果"""
        return {
            "node_id": node_id,
            "data": {},
            "metrics": {},
            "next_nodes": [],
            "status": "error",
            "message": error_msg
        }

    def process_default(self, node_id, node_data, task):
        """
        默认节点处理（用于迭代中的其他节点类型）
        """
        # 这里可以调用你现有的节点处理逻辑
        # 或者实现一个通用的处理方式
        return {
            "node_id": node_id,
            "data": node_data.get("config", {}),
            "status": "completed",
            "message": "默认处理完成"
        }

    def _evaluate_conditions(self, conditions, input_data):
        """
        评估条件表达式，返回匹配的分支
        """
        logging.info("_evaluate_conditions input_data keys: %s", input_data.keys())

        # 按顺序评估条件
        for condition in conditions:
            cond_type = condition.get('type')
            config_mode = condition.get('configMode', 'keyValue')

            logging.info("Evaluating condition: %s, type: %s, mode: %s",
                         condition.get('condition', ''), cond_type, config_mode)

            # else 分支直接匹配（但只在前面条件都不满足时）
            if cond_type == 'else':
                continue  # 先跳过，如果前面条件都不匹配，最后返回else

            # 评估条件表达式
            try:
                if self._evaluate_single_condition(condition, input_data):
                    logging.info(f"Condition matched: {condition.get('condition')}")
                    return condition
            except Exception as e:
                logging.warning(f"Error evaluating condition '{condition.get('condition')}': {str(e)}")
                continue

        # 如果前面的条件都不匹配，返回 else 分支
        else_condition = next((cond for cond in conditions if cond.get('type') == 'else'), None)
        if else_condition:
            logging.info("No condition matched, using else branch")
            return else_condition

        return None

    def _evaluate_single_condition(self, condition, input_data):
        """
        评估单个条件
        """
        config_mode = condition.get('configMode', 'keyValue')

        if config_mode == 'custom':
            return self._evaluate_custom_expression(condition, input_data)
        elif config_mode == 'keyValue':
            return self._evaluate_key_value_condition(condition, input_data)
        elif config_mode == 'tableOverall':
            return self._evaluate_table_overall_condition(condition, input_data)
        elif config_mode == 'tableColumn':
            return self._evaluate_table_column_condition(condition, input_data)
        else:
            logging.warning(f"Unknown config mode: {config_mode}")
            return False

    def _evaluate_custom_expression(self, condition, input_data):
        """
        评估自定义表达式
        """
        expression = condition.get('customExpression', '').strip()
        if not expression:
            return False

        try:
            # 安全地执行自定义Python表达式
            # 注意：这里需要根据安全要求限制可用的变量和函数
            local_vars = {
                'df': None,
                'result_count': 0,
                'status': '',
                'error_message': '',
                'execution_time': 0,
                'success': False
            }

            # 从输入数据中提取可用变量
            if input_data:
                for key, value in input_data.items():
                    if key == 'df' and value is not None:
                        local_vars['df'] = value
                    elif isinstance(value, (int, float)):
                        local_vars[key] = value
                    elif isinstance(value, str):
                        local_vars[key] = value
                    elif isinstance(value, bool):
                        local_vars[key] = value

            # 执行表达式
            result = eval(expression, {"__builtins__": {}}, local_vars)
            return bool(result)

        except Exception as e:
            logging.error(f"Error evaluating custom expression '{expression}': {str(e)}")
            return False

    def _evaluate_key_value_condition(self, condition, input_data):
        """
        评估键值对条件
        """
        field = condition.get('field', '')
        operator = condition.get('operator', '==')
        value = condition.get('value', '')
        value_type = condition.get('valueType', 'string')

        if not field:
            return False

        # 获取字段值
        field_value = self._get_field_value(field, input_data)

        # 转换比较值类型
        try:
            if value_type == 'number':
                compare_value = float(value) if value else 0
                field_value = float(field_value) if field_value else 0
            elif value_type == 'boolean':
                compare_value = value.lower() in ('true', '1', 'yes')
                field_value = bool(field_value)
            else:  # string
                compare_value = str(value)
                field_value = str(field_value)
        except (ValueError, TypeError):
            compare_value = value
            field_value = str(field_value)

        # 执行比较
        return self._apply_operator(field_value, operator, compare_value)

    def _evaluate_table_overall_condition(self, condition, input_data):
        """
        评估表格整体条件
        """
        field = condition.get('field', '')
        operator = condition.get('operator', '==')
        value = condition.get('value', '')

        if not field:
            return False

        # 获取DataFrame
        df = self._get_dataframe_from_input(input_data)
        if df is None:
            return False

        # 计算字段值
        try:
            if field == 'df.shape[0]':
                field_value = df.shape[0]
            elif field == 'df.shape[1]':
                field_value = df.shape[1]
            elif field == 'len(df.columns)':
                field_value = len(df.columns)
            elif field == 'df.size':
                field_value = df.size
            elif field == 'df.isnull().sum().sum()':
                field_value = df.isnull().sum().sum()
            elif field == 'df.duplicated().sum()':
                field_value = df.duplicated().sum()
            else:
                # 尝试执行字段表达式
                field_value = eval(field, {'df': df})
        except Exception as e:
            logging.error(f"Error calculating field value '{field}': {str(e)}")
            return False

        # 转换比较值
        try:
            compare_value = float(value) if value else 0
            field_value = float(field_value)
        except (ValueError, TypeError):
            compare_value = str(value)
            field_value = str(field_value)

        # 特殊操作符处理
        if operator == 'has_column':
            return value in df.columns
        elif operator == 'has_columns':
            columns = [col.strip() for col in value.split(',')]
            return all(col in df.columns for col in columns)
        else:
            return self._apply_operator(field_value, operator, compare_value)

    def _evaluate_table_column_condition(self, condition, input_data):
        """
        评估表格列条件
        """
        column_name = condition.get('columnName', '')
        column_operation = condition.get('columnOperation', 'count')
        column_condition = condition.get('columnCondition', 'value')
        operator = condition.get('operator', '==')
        value = condition.get('value', '')

        if not column_name:
            return False

        # 获取DataFrame
        df = self._get_dataframe_from_input(input_data)
        if df is None or column_name not in df.columns:
            return False

        try:
            # 计算列操作结果
            if column_operation == 'count':
                op_result = df[column_name].count()
            elif column_operation == 'sum':
                op_result = df[column_name].sum()
            elif column_operation == 'mean':
                op_result = df[column_name].mean()
            elif column_operation == 'max':
                op_result = df[column_name].max()
            elif column_operation == 'min':
                op_result = df[column_name].min()
            elif column_operation == 'nunique':
                op_result = df[column_name].nunique()
            elif column_operation == 'std':
                op_result = df[column_name].std()
            elif column_operation == 'null_count':
                op_result = df[column_name].isnull().sum()
            else:
                op_result = df[column_name]

            # 根据条件类型处理
            if column_condition == 'value':
                compare_value = float(value) if value else 0
                return self._apply_operator(float(op_result), operator, compare_value)
            elif column_condition == 'contains':
                return df[column_name].astype(str).str.contains(value).any()
            elif column_condition == 'startswith':
                return df[column_name].astype(str).str.startswith(value).any()
            elif column_condition == 'endswith':
                return df[column_name].astype(str).str.endswith(value).any()
            elif column_condition == 'unique_count':
                unique_count = df[column_name].nunique()
                compare_value = int(value) if value else 0
                return self._apply_operator(unique_count, operator, compare_value)
            else:
                return False

        except Exception as e:
            logging.error(f"Error evaluating table column condition: {str(e)}")
            return False

    def _get_field_value(self, field, input_data):
        """
        从输入数据中获取字段值
        """
        # 如果是预定义字段
        if field == 'result_count':
            return len(input_data) if hasattr(input_data, '__len__') else 0
        elif field == 'status':
            return input_data.get('status', '') if isinstance(input_data, dict) else ''
        # 其他预定义字段...

        # 从字典中获取
        if isinstance(input_data, dict) and field in input_data:
            return input_data[field]

        # 从DataFrame属性中获取
        df = self._get_dataframe_from_input(input_data)
        if df is not None and hasattr(df, field):
            return getattr(df, field)

        return None

    def _get_dataframe_from_input(self, input_data):
        """
        从输入数据中提取DataFrame
        """
        if hasattr(input_data, 'df'):
            return input_data.df
        elif isinstance(input_data, dict) and 'df' in input_data:
            return input_data['df']
        elif hasattr(input_data, 'shape'):  # 本身就是DataFrame
            return input_data
        else:
            # 尝试找到第一个DataFrame
            if isinstance(input_data, dict):
                for key, value in input_data.items():
                    if hasattr(value, 'shape'):
                        return value
            return None

    def _apply_operator(self, left_value, operator, right_value):
        """
        应用比较操作符
        """
        try:
            if operator == '==':
                return left_value == right_value
            elif operator == '!=':
                return left_value != right_value
            elif operator == '>':
                return left_value > right_value
            elif operator == '<':
                return left_value < right_value
            elif operator == '>=':
                return left_value >= right_value
            elif operator == '<=':
                return left_value <= right_value
            elif operator == 'contains':
                return str(right_value) in str(left_value)
            elif operator == 'not_contains':
                return str(right_value) not in str(left_value)
            elif operator == 'startswith':
                return str(left_value).startswith(str(right_value))
            elif operator == 'endswith':
                return str(left_value).endswith(str(right_value))
            elif operator == 'is_empty':
                return not left_value or len(str(left_value)) == 0
            elif operator == 'is_not_empty':
                return bool(left_value) and len(str(left_value)) > 0
            elif operator == 'in':
                return left_value in right_value
            elif operator == 'not in':
                return left_value not in right_value
            else:
                logging.warning(f"Unknown operator: {operator}")
                return False
        except Exception as e:
            logging.error(f"Error applying operator {operator}: {str(e)}")
            return False

    def _get_value_from_data(self, expr, data):
        """
        从数据中提取值
        """
        # 如果是数字字符串，转换为数字
        if expr.replace('.', '').isdigit():
            return float(expr) if '.' in expr else int(expr)

        # 如果是变量名，从数据中获取
        # 这里需要根据你的数据结构来调整
        if hasattr(data, expr):
            return getattr(data, expr)
        elif isinstance(data, dict) and expr in data:
            return data[expr]
        elif hasattr(data, '__getitem__') and expr in data:
            return data[expr]

        # 如果无法解析，返回原字符串
        return expr

    def _find_next_node_by_branch(self, node_id, branch_id):
        """
        根据分支ID找到对应的下一个节点
        """
        # 查找从当前节点出发的边
        out_edges = list(self.G.out_edges(node_id, data=True))
        logging.info(f"out_edges for node {node_id}: {out_edges}")

        if not out_edges:
            logging.warning(f"No out edges found for node {node_id}")
            return None

        # 简单规则：按边的顺序匹配分支
        # 第一个边 -> condition1 (if)
        # 第二个边 -> else
        # 如果有更多边，按顺序对应更多elif条件

        if branch_id == 'condition1' and len(out_edges) >= 1:
            target_node = out_edges[0][1]
            logging.info(f"Matched condition1 to first edge: {target_node}")
            return target_node
        elif branch_id == 'else' and len(out_edges) >= 2:
            target_node = out_edges[1][1]
            logging.info(f"Matched else to second edge: {target_node}")
            return target_node
        # 如果有更多分支，可以继续扩展
        elif len(out_edges) >= 3 and branch_id.startswith('condition'):
            # 尝试匹配condition2, condition3等
            try:
                cond_num = int(branch_id.replace('condition', ''))
                if 2 <= cond_num < len(out_edges):
                    target_node = out_edges[cond_num - 1][1]  # condition2对应索引1，condition3对应索引2...
                    logging.info(f"Matched {branch_id} to edge index {cond_num - 1}: {target_node}")
                    return target_node
            except ValueError:
                pass

        # 默认返回第一个边
        target_node = out_edges[0][1]
        logging.info(f"Using default first edge: {target_node}")
        return target_node

    def execute(self,task='train',sample_dict={},dependency_dict={} ):
        logging.info('######begin workflow execute')
        import datetime
        try:
            if task  not in ["train","offline"]:
                start_g =  [ i for i in sample_dict if i in self.G.nodes]
                task_order = get_subG_order( self.G, start_g)
            else:
                task_order = list( nx.topological_sort(self.G) )
        except nx.NetworkXUnfeasible:
            import  traceback
            logging.info("error:%s",traceback.format_exc() )
            return {'error': 'The graph has a cycle, cannot determine task execution order.'}
        ret_={}
        execute_dir = os.path.join(  self.project_dir,self.execute_time)
        if os.path.exists(  execute_dir )==False:
            os.makedirs( execute_dir )
        import datetime
        logging.info("task_order:%s",task_order)

        swith_pass_case_nodes= set(  )

        for node_id in task_order:

            node        = self.G.nodes[node_id]
            node_type   = node.get('type')
            node_label  = node.get('label')
            node_data   = node.get('data', {})

            if task not in ['predict',"inference"] and self.pre_engine!=None and node_id in self.pre_engine.results :
                self.results[node_id] =  self.pre_engine.results[node_id]
                logging.info("Notice:[%s] Utilizing previous run-results to accelerate",node_id)
            else:
                try:

                    if node_label =='Result': continue
                    logging.info( 'begin node_id[%s] step,node_type[%s] node_label[%s]', node_id, node_type, node_label)
                    if task in ["train","offline"]:logging.info( 'node_data:%s', node_data )

                    inf_dict ={}

                    pre_node_ids = node_data.get('prenodeId',[])
                    if len( set(pre_node_ids) )==1:
                        pre_node_id   =  pre_node_ids[0]
                        pre_node_label =  self.get_label_byId( pre_node_id )
                        logging.info("prenode %s  label:%s",pre_node_id,pre_node_label)
                        if ( pre_node_label =="If" and ( 'next_nodes' in self.results[pre_node_id] )  and
                             ( node_id not in  str_to_list( self.results[pre_node_id]['next_nodes']  ) ) ) or  pre_node_id in  swith_pass_case_nodes:
                            swith_pass_case_nodes.add( node_id )

                    if node_id  in swith_pass_case_nodes:
                        logging.info("%s hit the if node skip ruler",node_id)

                    elif node_label == 'Result':
                        continue
                    else:
                        if  node_label=="For":
                            pre_node_ids = node_data.get('prenodeId')
                            if not pre_node_ids:
                                logging.error(f"Condition node {node_id} has no prenode")
                                return {'error': 'No prenode found', 'next_nodes': []}

                            pre_node_id = pre_node_ids[0]
                            pre_node_result = self.results.get(pre_node_id)
                            self.results[node_id] = pre_node_result.copy()
                        self.results[node_id] = self.switch_excute( node_id,node_type, node_label, node_data, task, sample_dict, dependency_dict,swith_pass_case_nodes)

                    if task in ["predict","inference","infer"]:
                        if node_id in self.results and 'sample_df' in self.results[node_id]:
                            logging.info('nodeid[%s] sample_df len[%s],%s', node_id, len( self.results[node_id]["sample_df"] ), self.results[node_id]["sample_df"] )
                        else:
                            logging.info( "nodeid[%s] not contain sample_df",node_id )

                except:
                        import traceback
                        msg = traceback.format_exc()
                        # if len(msg)>30:
                        #     msg = msg[-40:]
                        if task not in ["train","offline"]:
                            return "node[%s] error:%s"%(node_id,msg)
                        ret_[node_id] = {"status": "error", "message": 'error details in logfile', "progress": 0}
                        logging.info(str(msg))
                        logging.info("finish step node_id[%s]", node_id)
                        return ret_

            try:
                if node_id in self.results:
                    if task=="train" and node_label == 'Derive':
                        if isinstance(self.results[node_id].get('df'),pd.DataFrame ):
                            ret_[node_id] = { "status": "success", "message": "", "progress": 100,"columns":self.results[node_id]['df'].columns.tolist() }
                        else:
                            ret_[node_id] = {"status": "success", "message": "", "progress": 100}
                    elif task=="train" and node_label == 'ImageSource':
                        ret_[node_id] = {"status": "success", "message": "%s data"%( self.results[node_id]['data_type']  ), "progress": 100}
                    elif task == "train" and node_label == 'ImageClassify':
                        ret_[node_id] = {"status": "success", "message": "%s Accuray:%s" % (self.results[node_id]['alg_name'],round( float(self.results[node_id]['stats_df']['accuracy'].tolist()[-1]),2 )), "progress": 100}
                    elif task == "train" and node_label == 'ObjectDetect':
                        ret_[node_id] = {"status": "success", "message": "mAP_50_95:%s" % ( self.results[node_id]['mAP_50_95'] ), "progress": 100}  # #result_dict['mAP_50_95'] = mAP_50_95

                    elif task =='train' and node_label =='ImageSegment':
                        ret_[node_id] = {"status": "success","message": "", "progress": 100  } # "message": "mAP_50_95:%s" % (self.results[node_id]['mAP_50_95']),
                    elif task =='train' and node_label  in ["CSV","URL"]:
                        ret_[node_id] = {"status": "success", "message": node_data.get("config")["filename"], "progress": 100}
                    else:
                        ret_[node_id] = { "status": "success", "message": "","progress":100  }

                    # if task in ['predict','inference']:
                    #     logging.info('%s : %s',node_id, str( self.results[node_id] )[:5] )  #['sample_df']
                    if task in ['train',"offline"]:   self.subf_execute_save( node_label,node_id,dependency_dict)
                    logging.info('finish step node_id[%s]', node_id)
                else:
                    ret_[node_id] = {"status": "", "message": "not run", "progress":0}
            except:
                import traceback
                msg = traceback.format_exc()
                # if len(msg)>30:
                #     msg = msg[-40:]

                ret_[node_id] = {"status": "error", "message": 'error details in logfile', "progress": 0}
                logging.info(str(msg))
                logging.info("finish step node_id[%s]", node_id)


            # 其他节点类型处理
        if task not in ["train","offline"]:
            ret_={}
            logging.info('iter exit_node_ids %s ,task mode[%s]',self.exit_node_ids,task)
            for id in self.exit_node_ids:
                if id not in self.G.nodes():
                    logging.info("node[%s] not in self.nodes[%s],pass",id,self.nodes)
                    continue
                logging.info(' pred iter id:%s',id)
                ret_[id] = { k:self.results[id][k]  for k in ['sample_df','preds_df' ,'Image',"text_response" ] if k in self.results[id]  }
        logging.info('######finish workflow execute ret_:%s',ret_)
        return ret_

    def process_data_split(self,node_id, node_data, task):
        logging.info("begin process_data_split")
        pre_node_ids    = node_data.get('prenodeId')
        ret_dict        ={ }
        if node_data['config'].get("indieNode")!=None and node_data['config'].get('trainNode')!=None:
            logging.info("two node[%s] [%s] ",node_data['config'].get("trainNode"),node_data['config'].get("indieNoe")  )
            train_df = self.results[ node_data['config'].get("trainNode")  ]['df']
            indie_df = self.results[ node_data['config'].get("indieNode")  ]['df']
        else:
            logging.info("prenode id[%s]",pre_node_ids)
            pre_node_result = self.results.get(   pre_node_ids[0])
            pre_node_data   = self.get_nodedata_byid(pre_node_ids[0])
            pre_node_result =  self.results.get(  pre_node_ids[0]  )
            pre_node_data   =  self.get_nodedata_byid(pre_node_ids[0])

            #按比例拆分
            indie_ratio = float(  node_data['config'].get("splitPercentage",30))/100
            train_ratio = 1-indie_ratio #70%用于训练
            logging.info("trian ratio:%s indie_ratio:%s ",train_ratio,indie_ratio)
            logging.info("pre node:%s",pre_node_result.keys())
            df  = pre_node_result['df']
            if train_ratio >1 or train_ratio <0:
                train_ratio=0.7
            train_df = df.sample(frac=train_ratio,random_state=42)
            indie_df = df.drop(train_df.index)  #剩下的30%用于测试集

        ret_dict['train_df'] = train_df
        ret_dict['indie_df'] = indie_df

        logging.info("finish process data split")
        return ret_dict

    def process_images_source(self, node_id, node_data, task,sample_dict):

        import torchvision.datasets.mnist as mnist
        dataSourceType = node_data.get("config").get('dataSourceType', None)
        ret_dict = {}
        if task != 'predict':
            if dataSourceType=='classic'   :#data_type == 'mnist':
                classicDataset = node_data.get("config").get('classicDataset', None)
                if classicDataset in [ 'mnist','cifar10']:
                    if classicDataset =='mnist':
                        root = 'D:\\workspace\\data\\MNIST\\raw\\'
                        train_data              = mnist.read_image_file(os.path.join(root, 'train-images-idx3-ubyte'))
                        train_labels            = mnist.read_label_file(os.path.join(root, 'train-labels-idx1-ubyte'))
                        indie_data              = mnist.read_image_file(os.path.join(root, 't10k-images-idx3-ubyte'))
                        indie_labels             = mnist.read_label_file(os.path.join(root, 't10k-labels-idx1-ubyte'))
                    if classicDataset == 'cifar10':
                        from ..cv.deepreg import load_cifar10
                        train_data, train_labels, indie_data, indie_labels = load_cifar10(  data_dir='E:\\ml_data\\cifar-10-batches-py')
                        logging.info("train_data shape %s",train_data.shape)

                    ret_dict['train_data']   = train_data
                    ret_dict['train_labels'] = train_labels
                    ret_dict['indie_data']   = indie_data
                    ret_dict['indie_labels'] = indie_labels
                    ret_dict['data_type']    = classicDataset
                    logging.info('%s  train_len[%s]  indie_len[%s] ',classicDataset,len(train_labels ) ,len( indie_labels )  )
        else:
            ret_dict = {}  # self.results[ node_id ]
            sample_df = sample_dict[node_id]
            ret_dict['sample_df'] = sample_df
            logging.info('sample_df:%s', sample_df)

        return ret_dict

    def process_images_algo(self, node_id, node_data, task,sample_dict={}):
        logging.info('begin images_algo')
        from ..dl.deepreg import DeepRegWrapper
        pre_node_ids = node_data.get('prenodeId')
        pre_node_id = pre_node_ids[0]
        pre_result = self.results[pre_node_id]

        if task=='train':
            result_dict = {}
            alg_name        = node_data.get("config").get('image_algo', None)
            epoch           = node_data.get("config").get('epoch', 1)
            logging.info('%s ',alg_name )
            total_stat_df   = []
            # for alg_name in ['mask_rcnn', 'vgg', 'resnet18', 'mobilenet_v2', 'unet', 'detnet', 'fpn','r_fcn']:  # alexnet resnet18 mobilenet_v2 unet detnet
            logging.info('*** %s' % alg_name)
            clf = DeepRegWrapper(task='classification', name=alg_name, batch_size=128, num_classes=10, epochs=epoch,in_channels=3)
            clf.fit(pre_result['train_data'], pre_result['train_labels'])
            # total_stat_df.append(clf.stats_df)
            # total_stat = pd.concat(total_stat_df)
            result_dict['stats_df'] = copy.deepcopy(  clf.stats_df )
            result_dict['model']    = clf
            result_dict['alg_name'] = alg_name
        else:
            if 'sample_data' in pre_result:
                sample_data = pre_result['sample_data']
            if 'sample_df' in pre_result:
                sample_data = pre_result['sample_df']

            result_dict = self.results[node_id]
            clf         = result_dict['model']
            preds      = clf.predict( sample_data )

            result_dict['sample_df'] = preds
            logging.info('result:%s',preds)

        #total_stat.to_excel('stat_df2.xlsx')
        logging.info('end images_algo')
        return result_dict

    def get_project_path(self):
        proj_dir = "projects"
        proj_dir = os.path.join(proj_dir, self.projectname, self.execute_time)
        if not os.path.exists(proj_dir):
            os.makedirs(proj_dir)
        return proj_dir


    def process_image_detect(self, node_id, node_data, task,sample_dict={} ):
        logging.info(' task[%s]',task)
        logging.info("sample_dict keys %s",sample_dict.keys())
        mode            = node_data.get("config").get('mode', 'inference')


        epochs          = node_data.get("config").get('CVepochs',3)
        batch           = node_data.get("config").get('CVbatchSize',32)
        result_dict ={  }
        if  task=='train':
            model_path = node_data.get("config").get('model_path', './runs/yolo11n.pt')  # ,'./runs/detect/train2/weights/best.pt'
            dataset_path = node_data.get("config").get('dataset_yaml_path',None)
            yaml_content = node_data.get("config").get('CVdatasetYaml')

            if dataset_path==None:
                dataset_path = os.path.join( self.get_project_path(), 'dataset.yaml' )
                with open(dataset_path, 'w') as file:
                    file.write(yaml_content)

            from ..cv.deepdetect import yolo_train
            results =  yolo_train(model_path =model_path,
                       dataset_path          =dataset_path,
                       epochs=int(epochs),batch= int(batch),
                       project= self.get_project_path( ) )
            # result_dict['train_result'] = results
            if hasattr(results, 'results_dict'):
                # YOLOv5 的处理方式
                mAP_50 = results.results_dict.get('metrics/mAP50(B)')
                mAP_50_95 = results.results_dict.get('metrics/mAP50-95(B)')
                result_dict['mAP_50_95'] = mAP_50_95
            elif hasattr(results, 'metrics'):
                # YOLOv8 的处理方式
                mAP_50 = results.metrics.get('map50', None)
                mAP_50_95 = results.metrics.get('map', None)
            else:
                mAP_50 = None
                mAP_50_95 = None

        elif mode == 'inference' or task == 'predict' or task == 'inference':

            default_model_path = os.path.join(  self.get_project_path( ),'./train/weights/best.pt' ) #runs/detect/
            if  os.path.exists(  default_model_path ):
                model_path  =    default_model_path
                logging.info('current dir has trained best.pt')
            logging.info('has load model@@')

            pre_node_ids = node_data.get('prenodeId')
            if pre_node_ids !=None and len( pre_node_ids )!=0:
                pre_node_id  = pre_node_ids[0]
                pre_result   = self.results[pre_node_id]

                if 'sample_image_path' in pre_result:
                    sample_image_path = pre_result['sample_image_path']
                elif  node_data.get("config").get('sample_image_path')!=None:
                    sample_image_path = node_data.get("config").get('sample_image_path')
            else:
                sample_image_path = os.path.join(  self.get_project_path( ) , "tmp.png" )
                if node_id in sample_dict:
                    pic_data = np.array( sample_dict[node_id] )
                    pic_data = pic_data.astype(np.uint8)
                    logging.info('pic_data shape %s',pic_data.shape)

                image_data = np.transpose(pic_data, (1, 2, 0))
                # 创建 PIL 图像
                from PIL import Image
                image = Image.fromarray(image_data)
                # 保存图像
                image.save( sample_image_path )
                logging.info("######saved pic path:%s",  sample_image_path )
            logging.info("######saved pic path:%s", sample_image_path)
            logging.info("####################################"  )
            from ..cv.deepdetect import yolo_inference
            save_pic_path = os.path.join( self.get_project_path( ), '%s_result.jpg'% node_id)
            yolo_inference(
                model_path = model_path,  # 训练好的模型路径
                image_path = sample_image_path, #'./test.png' # 测试图像路径  'F:\\work\\hms_ml_project\\red.jpg',#
                result_path= save_pic_path    # 结果保存路径
            )
            image_base64            = image_to_base64(save_pic_path)
            result_dict['Image']    = image_base64

        else:
            logging.info("unknown process_image_detect mode situation")


        return result_dict

    def process_image_seg(self, node_id, node_data, task,sample_dict={}):
        result_dict = {}
        logging.info("begin process_image_seg [%s]", task)
        model_path  = node_data.get("config").get('model_path') #, './yolov8n-seg.pt'
        epochs      = int( node_data.get("config").get('epochs', 3) )
        batch       = int( node_data.get("config").get('batchSize', 16) )

        if task == 'train':
            dataset_path = node_data.get("config").get('dataset_yaml_path', None)
            yaml_content = node_data.get("config").get('yoloDatasetYaml')

            if dataset_path == None:
                dataset_path = os.path.join(self.get_project_path(), 'dataset.yaml')
                with open(dataset_path, 'w') as file:
                    file.write(yaml_content)

            from ..cv.deepseg import  yolov5_seg_train
            yolov5_seg_train(
                dataset_path= dataset_path, #'./dataset.yaml',  # 数据集配置文件
                model_name  = './yolov8n-seg.pt',  # 预训练模型
                epochs      = epochs,
                imgsz       = 640,
                batch       = batch,
                device      = 'cuda',
                project     = self.get_project_path(),#'./segrun',  # 指定保存目录的父目录
                name        = node_id    #    'face_segmentation_exp'  # 指定实验名称
            )
            logging.info("train task finish")
        else:
            default_model_path = os.path.join(self.get_project_path(),node_id,"weights","best.pt")
            if os.path.exists(default_model_path):
                model_path = default_model_path
                logging.info('current dir has trained best.pt [%s]',default_model_path)
            else:
                logging.info("path %s not exits",default_model_path )
            logging.info('has load model@@')

            pre_node_ids = node_data.get('prenodeId')
            if pre_node_ids != None and len(pre_node_ids)>0:
                pre_node_id = pre_node_ids[0]
                pre_result = self.results[pre_node_id]

                if 'sample_image_path' in pre_result:
                    sample_image_path = pre_result['sample_image_path']
                elif node_data.get("config").get('sample_image_path') != None:
                    sample_image_path = node_data.get("config").get('sample_image_path')
            else:
                sample_image_path = os.path.join(self.get_project_path(), "tmp.png")
                if node_id in sample_dict:
                    pic_data = np.array(sample_dict[node_id])
                    pic_data = pic_data.astype(np.uint8)
                    logging.info('pic_data shape %s', pic_data.shape)

                image_data = np.transpose(pic_data, (1, 2, 0))
                from PIL import Image
                image = Image.fromarray(image_data)
                # 保存图像
                image.save(sample_image_path)
                logging.info("######saved pic path:%s", sample_image_path)
            logging.info("######saved pic path:%s", sample_image_path)
            logging.info("####################################")
            from ..cv.deepseg   import yolov5_seg_inference
            save_pic_path = os.path.join(self.get_project_path(), '%s_result.jpg' % node_id)
            yolov5_seg_inference(
                model_path=model_path,  # 训练好的模型路径
                image_path=sample_image_path,  # './test.png' # 测试图像路径  'F:\\work\\hms_ml_project\\red.jpg',#
                result_path=save_pic_path  # 结果保存路径
            )
            image_base64 = image_to_base64(save_pic_path)
            result_dict['Image'] = image_base64
        return result_dict

    def process_sort(self,node_id,node_data,task):
        logging.info("begin process_sort")
        pre_node_ids=node_data.get('prenodeId')
        pre_node_id = pre_node_ids[0]
        pre_result  = self.results[ pre_node_id ]
        logging.info("predict_id[%s]",pre_node_id)
        ret_dict   = {}
        for i in pre_result:
            if isinstance( pre_result[i],pd.DataFrame ) and node_data['config'].get('sortConfig',None)!=None:
                logging.info("node_data.config:%s",node_data['config'])
                for k in node_data['config'].get('sortConfig'):
                    ret_dict[i] = pre_result[i].sort_values(  by= [k['column']],ascending= True if  k['order'] in ['asc'] else False )
        # logging.info("ret_dict:%s",ret_dict )
        logging.info("finish process_sort")
        return ret_dict

    def process_rename(self,node_id,node_data,task):
        logging.info("begin process_df_rename")
        pre_node_ids=node_data.get('prenodeId')
        pre_node_id = pre_node_ids[0]
        pre_result  = self.results[ pre_node_id ]
        logging.info("predict_id[%s]",pre_node_id)
        ret_dict   = {}
        rename_dict= node_data['config']['renameMapping']
        for i in pre_result:
            if isinstance( pre_result[i],pd.DataFrame ):
                ret_dict[i] = pre_result[i].rename( columns =rename_dict )
        # logging.info("ret_dict:%s",ret_dict )
        logging.info("finish process_df_rename")
        return ret_dict

    def process_pivottable(self, node_id: str, node_data: Dict, task: str) -> Dict:
        """
        处理透视表算子
        """
        logging.info("begin process_pivot")

        try:
            # 获取前置节点ID
            pre_node_ids = node_data.get('prenodeId', [])
            if not pre_node_ids:
                logging.error("PivotTable算子缺少前置节点")
                return {}

            pre_node_id = pre_node_ids[0]

            # 从self.results中获取前置节点数据
            if pre_node_id not in self.results:
                logging.error(f"前置节点 {pre_node_id} 在results中不存在")
                return {}

            pre_result = self.results[pre_node_id]
            logging.info(f"pre_node_id[{pre_node_id}]")

            # 获取配置
            config = node_data.get('config', {})
            logging.info(f"pivot table config: {config}")

            ret_dict = {}

            # 处理每个数据集
            for key, df in pre_result.items():
                if isinstance(df, pd.DataFrame):
                    try:
                        # 验证配置
                        if not self._validate_pivot_config(df, config):
                            logging.warning(f"数据集 {key} 的透视表配置无效，返回原始数据")
                            ret_dict[key] = df
                            continue

                        # 创建透视表
                        pivot_df = self._create_pivot_table(df, config)
                        ret_dict[key] = pivot_df

                        logging.info(f"数据集 {key} 透视表生成成功，形状: {pivot_df.shape}")
                        logging.info(f"透视表列信息: {pivot_df.columns}")
                        logging.info(f"透视表索引信息: {pivot_df.index}")

                    except Exception as e:
                        logging.error(f"数据集 {key} 透视表生成失败: {str(e)}")
                        ret_dict[key] = df
                else:
                    # 非DataFrame数据直接传递
                    ret_dict[key] = df

            logging.info("finish process_pivot")
            return ret_dict

        except Exception as e:
            logging.error(f"PivotTable算子处理失败: {str(e)}", exc_info=True)
            return {}

    def _create_pivot_table(self, df: pd.DataFrame, config: Dict) -> pd.DataFrame:
        """
        根据配置创建透视表
        """
        index_cols = config.get('index', [])
        columns_cols = config.get('columns', [])
        values_cols = config.get('values', [])
        aggfunc = config.get('aggfunc', 'sum')
        multiple_agg = config.get('multipleAgg', False)
        custom_aggfunc = config.get('customAggfunc', [])
        fill_value = config.get('fillValue')
        margins = config.get('margins', True)
        sort_values = config.get('sortValues', 'none')
        limit = config.get('limit')
        output_format = config.get('outputFormat', 'dataframe')
        include_index = config.get('includeIndex', True)

        logging.info(f"创建透视表 - 行索引: {index_cols}, 列标签: {columns_cols}, 计算值: {values_cols}")

        # 处理聚合函数
        if multiple_agg and custom_aggfunc:
            aggfunc_dict = self._parse_custom_aggfunc(custom_aggfunc, values_cols)
        else:
            aggfunc_dict = {col: aggfunc for col in values_cols}

        # 如果没有指定行索引，自动添加索引
        df_processed = df.copy()
        auto_index_used = False
        if not index_cols:
            logging.info("未指定行索引，自动生成索引")
            df_processed['_auto_index'] = range(len(df_processed))
            index_cols = ['_auto_index']
            auto_index_used = True
        logging.info(f"创建透视表 - 行索引: {index_cols}, 列标签: {columns_cols}, 计算值: {values_cols}")
        logging.info("df_processed:%s",df_processed.head(3))
        # 创建透视表
        try:
            pivot_df = pd.pivot_table(
                df_processed,
                index=index_cols,
                columns=columns_cols if columns_cols else None,
                values=values_cols,
                aggfunc=aggfunc_dict,
                fill_value=fill_value,
                margins=margins,
                margins_name='_all'
            )

            logging.info(f"透视表创建成功，形状: {pivot_df.shape}")
            logging.info(f"透视表列结构: {pivot_df.columns}")
            logging.info(f"透视表索引结构: {pivot_df.index}")
            logging.info("pivot_df:%s",)
            # 如果使用了自动索引，在最终结果中移除
            pivot_df = pivot_df.reset_index()
            if auto_index_used and '_auto_index' in pivot_df.index.names:
                if hasattr(pivot_df, 'index'):
                    pivot_df = pivot_df.droplevel('_auto_index')

            # 处理多级列索引 - 将多级列索引合并为单级
            if hasattr(pivot_df, 'columns') and isinstance(pivot_df.columns, pd.MultiIndex):
                logging.info("检测到多级列索引，进行扁平化处理")
                pivot_df = self._flatten_multiindex_columns(pivot_df)

        except Exception as e:
            logging.error(f"标准透视表创建失败，使用回退方法: {str(e)}")
            pivot_df = self._fallback_pivot(df_processed, index_cols, values_cols, aggfunc_dict)

        # 应用排序
        pivot_df = self._apply_pivot_sorting(pivot_df, sort_values)

        # 应用行数限制
        pivot_df = self._apply_pivot_limit(pivot_df, limit)

        # 处理输出格式
        pivot_df = self._format_pivot_output(pivot_df, output_format, include_index, auto_index_used)

        logging.info(f"最终透视表形状: {pivot_df.shape}")
        logging.info(f"最终列名: {list(pivot_df.columns)}")

        return pivot_df

    def _flatten_multiindex_columns(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        将多级列索引扁平化为单级列索引
        """
        try:
            if isinstance(df.columns, pd.MultiIndex):
                # 将多级列索引转换为单级列名
                new_columns = []
                for col in df.columns:
                    if isinstance(col, tuple):
                        # 过滤掉空字符串和None，然后用下划线连接
                        filtered_parts = [str(part) for part in col if part and str(part) != '']
                        if filtered_parts:
                            new_col_name = '_'.join(filtered_parts)
                        else:
                            new_col_name = 'value'
                        new_columns.append(new_col_name)
                    else:
                        new_columns.append(str(col))

                # 创建新的DataFrame
                df_flattened = df.copy()
                df_flattened.columns = new_columns
                return df_flattened
            else:
                return df
        except Exception as e:
            logging.error(f"多级列索引扁平化失败: {str(e)}")
            return df

    def _format_pivot_output(self, df: pd.DataFrame, output_format: str, include_index: bool, auto_index_used: bool) -> pd.DataFrame:
        """
        格式化输出
        """
        try:
            if output_format == 'matrix':
                # 矩阵格式 - 重置索引为普通列
                if include_index and hasattr(df, 'index') and not df.index.names == [None]:
                    result = df.reset_index()
                    # 确保列名是字符串
                    result.columns = [str(col) for col in result.columns]
                    return result
                return df

            elif output_format == 'long':
                # 长格式 - 转换为变量-值结构
                if hasattr(df, 'index') and not df.index.names == [None]:
                    df_reset = df.reset_index()
                    # 获取所有值列（排除索引列）
                    index_names = [name for name in df.index.names if name is not None]
                    value_cols = [col for col in df_reset.columns if col not in index_names]

                    if value_cols:
                        long_df = df_reset.melt(id_vars=index_names, value_vars=value_cols,
                                                var_name='指标', value_name='值')
                        return long_df
                # 如果无法识别索引，使用简单的melt
                return df.reset_index().melt(var_name='指标', value_name='值')

            else:  # dataframe - 标准透视表格式
                # 对于自动索引的情况，确保不包含无意义的索引
                if auto_index_used and hasattr(df, 'index'):
                    if df.index.names == [None] or all(name is None for name in df.index.names):
                        result = df.reset_index(drop=True)
                        # 确保列名是字符串
                        result.columns = [str(col) for col in result.columns]
                        return result

                # 确保列名是字符串
                df.columns = [str(col) for col in df.columns]
                return df

        except Exception as e:
            logging.error(f"输出格式化失败: {str(e)}")
            return df

    # 其他辅助方法保持不变
    def _validate_pivot_config(self, df: pd.DataFrame, config: Dict) -> bool:
        """
        验证透视表配置
        """
        index_cols = config.get('index', [])
        columns_cols = config.get('pivotcolumns', [])
        values_cols = config.get('values', [])

        # 检查必要配置
        if not values_cols:
            logging.error("缺少计算值列配置")
            return False

        # 检查列是否存在
        all_cols = index_cols + columns_cols + values_cols
        missing_cols = [col for col in all_cols if col not in df.columns]
        if missing_cols:
            logging.error(f"列不存在于DataFrame中: {missing_cols}")
            return False

        # 检查数据是否为空
        if df.empty:
            logging.error("输入DataFrame为空")
            return False

        # 检查列冲突
        conflict_cols = set(values_cols) & set(index_cols + columns_cols)
        if conflict_cols:
            logging.error(f"列配置冲突: {conflict_cols} 不能同时作为索引和计算值")
            return False

        return True

    def _parse_custom_aggfunc(self, custom_aggfunc: List[str], default_values: List[str]) -> Dict[str, str]:
        """
        解析自定义聚合函数配置
        """
        aggfunc_dict = {}
        valid_aggfuncs = {
            'sum': 'sum', 'mean': 'mean', 'count': 'count',
            'min': 'min', 'max': 'max', 'std': 'std',
            'var': 'var', 'first': 'first', 'last': 'last'
        }

        for item in custom_aggfunc:
            if ':' in item:
                try:
                    col, func = item.split(':', 1)
                    col = col.strip()
                    func = func.strip().lower()

                    if func in valid_aggfuncs:
                        aggfunc_dict[col] = valid_aggfuncs[func]
                    else:
                        logging.warning(f"无效的聚合函数 {func}，列 {col} 使用默认函数 sum")
                        aggfunc_dict[col] = 'sum'
                except Exception as e:
                    logging.warning(f"解析聚合函数配置失败: {item}, 错误: {str(e)}")

        # 为未指定的列设置默认值
        for col in default_values:
            if col not in aggfunc_dict:
                aggfunc_dict[col] = 'sum'

        return aggfunc_dict

    def _fallback_pivot(self, df: pd.DataFrame, index_cols: List[str],
                        values_cols: List[str], aggfunc_dict: Dict) -> pd.DataFrame:
        """
        回退方法：使用分组聚合
        """
        logging.info("使用分组聚合作为回退方案")
        try:
            # 简单的分组聚合
            if len(values_cols) == 1:
                # 单列情况
                result = df.groupby(index_cols)[values_cols[0]].agg(aggfunc_dict[values_cols[0]])
                return result.to_frame()
            else:
                # 多列情况
                grouped = df.groupby(index_cols)[values_cols].agg(aggfunc_dict)
                return grouped
        except Exception as e:
            logging.error(f"回退方法也失败: {str(e)}")
            # 返回原始数据的前100行作为降级方案
            return df.head(100)

    def _apply_pivot_sorting(self, df: pd.DataFrame, sort_values: str) -> pd.DataFrame:
        """
        应用排序
        """
        if sort_values == 'none' or df.empty:
            return df

        try:
            ascending = sort_values == 'asc'
            if hasattr(df, 'columns') and len(df.columns) > 0:
                # 尝试按第一列排序
                sort_column = df.columns[0]
                return df.sort_values(by=sort_column, ascending=ascending)
            return df
        except Exception as e:
            logging.warning(f"排序失败: {str(e)}")
            return df

    def _apply_pivot_limit(self, df: pd.DataFrame, limit: Optional[int]) -> pd.DataFrame:
        """
        应用行数限制
        """
        if limit and isinstance(limit, int) and limit > 0:
            return df.head(limit)
        return df

    def _format_pivot_output(self, df: pd.DataFrame, output_format: str, include_index: bool, auto_index_used: bool) -> pd.DataFrame:
        """
        格式化输出
        """
        try:
            if output_format == 'matrix':
                # 矩阵格式 - 重置索引为普通列
                if include_index and hasattr(df, 'index') and not df.index.names == [None]:
                    return df.reset_index()
                return df

            elif output_format == 'long':
                # 长格式 - 转换为变量-值结构
                if hasattr(df, 'index') and not df.index.names == [None]:
                    df_reset = df.reset_index()
                    # 获取所有值列
                    value_cols = [col for col in df_reset.columns if col not in df.index.names]
                    if value_cols:
                        return df_reset.melt(id_vars=df.index.names, value_vars=value_cols,
                                             var_name='指标', value_name='值')
                # 如果无法识别索引，使用简单的melt
                return df.reset_index().melt(var_name='指标', value_name='值')

            else:  # dataframe - 标准透视表格式
                # 对于自动索引的情况，确保不包含无意义的索引
                if auto_index_used and hasattr(df, 'index'):
                    if df.index.names == [None] or all(name is None for name in df.index.names):
                        return df.reset_index(drop=True)
                return df

        except Exception as e:
            logging.error(f"输出格式化失败: {str(e)}")
            return df

    def process_melt(self,node_id, node_data, task):
        """
        处理宽表变长表转换（melt）
        """
        ret_dict = {}
        try:
            # 获取前置节点数据
            config = node_data.get("config",{})
            id_vars = config.get("id_vars", [])
            value_vars = config.get("value_vars", [])
            var_name = config.get("var_name", "variable")
            value_name = config.get("value_name", "value")
            ignore_index = config.get("ignore_index", True)

            if not value_vars:
                return {"error": "至少需要选择一个值变量"}

            pre_node_ids = node_data.get('prenodeId', [])
            if not pre_node_ids:
                logging.error("PivotTable算子缺少前置节点")
                return {}

            pre_node_id = pre_node_ids[0]
            # 从self.results中获取前置节点数据
            if pre_node_id not in self.results:
                logging.error(f"前置节点 {pre_node_id} 在results中不存在")
                return {}

            pre_result = self.results[pre_node_id]
            logging.info(f"pre_node_id[{pre_node_id}]")

            # 处理每个数据集
            for key, df in pre_result.items():
                if isinstance(df, pd.DataFrame):
                    try:
                        # 创建透视表
                        melted_df = pd.melt(
                            df,
                            id_vars=id_vars if id_vars else None,
                            value_vars=value_vars,
                            var_name=var_name,
                            value_name=value_name,
                            ignore_index=ignore_index
                        )
                        ret_dict[key] = melted_df

                        logging.info(f"melted_df {key} 透视表生成成功，形状: {melted_df.shape}")
                        logging.info(f"melted_df columns: {pivot_df.columns}")
                        logging.info(f"melted_df index: {pivot_df.index}")

                    except Exception as e:
                        logging.error(f"数据集 {key} melt表生成失败: {str(e)}")
            logging.info("finish process_melt")
        except Exception as e:
            import  traceback
            logging.error("traceback:%s",traceback.format_exc())
            logging.error(f'melt处理失败: {str(e)}')
            return ret_dict

        return ret_dict

    # 如果在DataEdit中集成使用的版本
    def _process_pivot_columns(data_dict: Dict, pivot_config: Dict, task: Any) -> Dict:
        """
        在DataEdit算子中处理透视表的函数
        """
        logging.info('开始处理透视表列')

        if not pivot_config:
            logging.warning('透视表配置为空，跳过处理')
            return data_dict

        try:
            return _process_pivot_table(data_dict, pivot_config, task)
        except Exception as e:
            logging.error(f'透视表处理失败: {str(e)}')
            return data_dict


    def process_candidate(self,node_id,node_data,task):
        logging.info("begin process_candidate")
        ret_dict = {}
        ret_dict['candidateData'] = rename_dict= node_data['config'].get('candidateData','')
        return ret_dict

    def process_Deduplicate(self,node_id,node_data,task):
        logging.info("begin process_Deduplicate")
        pre_node_ids = node_data.get('prenodeId')
        pre_node_id = pre_node_ids[0]
        pre_result = self.results[pre_node_id]
        logging.info("predict_id[%s]", pre_node_id)
        ret_dict = {}
        columns_ = node_data['config']['deduplicateColumns']  #
        keep_    = node_data['config']['keepMethod']  #'keepMethod'
        for i in pre_result:
            if isinstance( pre_result[i],pd.DataFrame ):
                ret_dict[i] = pre_result[i].drop_duplicates( subset = columns_,keep=keep_ )
        # logging.info("ret_dict:%s",ret_dict )
        logging.info("finish process_df_rename")
        return ret_dict

    def process_sample(self, node_id, node_data, task):
        logging.info("begin process_sample")
        pre_node_ids = node_data.get('prenodeId')
        pre_node_id = pre_node_ids[0]
        pre_result = self.results[pre_node_id]
        logging.info("pre_node_id[%s]", pre_node_id)
        ret_dict = {}

        sample_type = node_data['config'].get('sampleType', 'whole')
        sample_method = node_data['config'].get('sampleMethod', 'downsample')
        sample_ratio = node_data['config'].get('sampleRatio', 10) / 100
        sample_column = node_data['config'].get('sampleColumn')
        sample_condition = node_data['config'].get('sampleCondition')
        sample_condition_value = node_data['config'].get('sampleConditionValue')

        for key, df in pre_result.items():
            if isinstance(df, pd.DataFrame):
                if sample_type == 'whole':
                    if sample_method == 'downsample':
                        ret_dict[key] = df.sample(frac=sample_ratio)
                    else:
                        ret_dict[key] = df.sample(frac=sample_ratio, replace=True)
                else:
                    if sample_condition == 'eq':
                        filtered_df = df[df[sample_column] == sample_condition_value]
                    elif sample_condition == 'lt':
                        filtered_df = df[df[sample_column] < float(sample_condition_value)]
                    elif sample_condition == 'gt':
                        filtered_df = df[df[sample_column] > float(sample_condition_value)]
                    elif sample_condition == 'between':
                        lower, upper = map(float, sample_condition_value.split(','))
                        filtered_df = df[(df[sample_column] >= lower) & (df[sample_column] <= upper)]

                    if sample_method == 'downsample':
                        ret_dict[key] = filtered_df.sample(frac=sample_ratio)
                    else:
                        ret_dict[key] = filtered_df.sample(frac=sample_ratio, replace=True)
        logging.info("finish process_sample")
        return ret_dict

    def process_type_transform(self, node_id, node_data, task):
        logging.info("begin process_transform")
        pre_node_ids = node_data.get('prenodeId')
        pre_node_id = pre_node_ids[0]
        pre_result = self.results[pre_node_id]
        logging.info("pre_node_id[%s]", pre_node_id)
        ret_dict = {}

        transform_configs = node_data['config'].get('transformConfigs', [])

        for key, df in pre_result.items():
            if isinstance(df, pd.DataFrame):
                for config in transform_configs:
                    column = config.get('column')
                    transform_type = config.get('type')
                    param = config.get('param')
                    if column and transform_type:
                        if transform_type == 'string_to_number':
                            df[column] = pd.to_numeric(df[column], errors='coerce')
                        elif transform_type == 'number_to_string':
                            df[column] = df[column].astype(str)
                        elif transform_type == 'date_format':
                            df[column] = pd.to_datetime(df[column], format=param, errors='coerce')
                        elif transform_type == 'custom':
                            try:
                                df[column] = df[column].apply(eval(param))
                            except Exception as e:
                                logging.error(f"Custom transform failed: {e}")
                ret_dict[key] = df

        logging.info("finish process_transform")
        return ret_dict

    def process_database(self, node_id, node_label, node_data, task='train'):
        logging.info('begin process_database')
        pre_node_ids = node_data.get('prenodeId')
        project_dir = self.project_dir
        if not os.path.exists(project_dir):
            os.makedirs(project_dir)

        config = node_data.get('config', {})
        db_type = config.get('dbType', 'mysql').lower()
        db_url = config.get('dbUrl', '')
        db_name = config.get('dbdb', '')
        username = config.get('username', '')
        password = config.get('password', '')
        sql_query = config.get('sqlQuery', '')

        ret_dict = {}
        add_str = ""

        try:
            # Handle candidate data from previous node if exists
            if len(pre_node_ids) > 0:
                pre_node_label = self.get_label_byId(pre_node_ids[0])
                pre_node_type = self.get_type_byId(pre_node_ids[0])
                pre_node_result = self.results.get(pre_node_ids[0])
                pre_node_data = self.get_nodedata_byid(pre_node_ids[0])
                logging.info('pre_node_data:%s', pre_node_data)

                if pre_node_type == "Candidate":
                    candidateData = pre_node_result['candidateData']
                    # Database-specific variable handling
                    if db_type == 'mysql':
                        add_str = f"SET @candidateData = '{candidateData}'"
                    elif db_type == 'oracle':
                        # Oracle uses bind variables or substitution variables
                        add_str = f"VAR candidateData VARCHAR2(4000)\n" \
                                  f"EXEC :candidateData := '{candidateData}'"
                    # Add proper escaping to prevent SQL injection
                    candidateData = candidateData.replace("'", "''")

            # Create database engine
            if db_type == 'mysql':
                from .db import get_mysql_engine
                engine = get_mysql_engine(username, password, db_url, db_name)
            elif db_type == 'oracle':
                from .db import get_oracle_engine
                # Make connection mode configurable (sid/service_name)
                oracle_mode = config.get('oracleMode', 'sid')  # Default to SID
                engine = get_oracle_engine(username, password, db_url, db_name, mode=oracle_mode)
            else:
                raise ValueError(f"Unsupported database type: {db_type}")

            # Combine the SQL queries if we have additional statements
            if add_str:
                sql_query = f"{add_str}\n{sql_query}"

            # Execute SQL query
            from .db import get_sql_df
            df = get_sql_df(sql_query, engine)

            # Save results
            file_path = os.path.join(project_dir, f'{node_id}.csv')
            df.to_csv(file_path, index=False)
            logging.info(f'Saved database query results to: {file_path}')
            ret_dict['df'] = df
            logging.info(f'Loaded database data with shape: {df.shape}')

        except Exception as e:
            logging.error(f"Error processing database node {node_id}: {str(e)}")
            logging.error(f"Database type: {db_type}, URL: {db_url}")
            raise
        return ret_dict

    def process_data_source(self, node_id,node_label, node_data,task='train',sample_dict={},ini_conf={}):
        logging.info('begin process_data_source node_label[%s]  node_id[%s] task[%s]',node_label,node_id,task)
        project_dir     = self.project_dir #os.path.join(proj_dir, self.projectname)
        if not os.path.exists(project_dir):
            os.makedirs(project_dir)
        # 处理数据源节点
        ret_dict = {}
        if task !='predict':
            if node_label=='CSV':
                file_path       = os.path.join(project_dir,  node_id+ '__' +node_data.get('config').get('filename'))
                if file_path.endswith(".csv"):
                    df              = pd.read_csv(file_path,    sep=node_data.get('delimiter', ','),index_col=False )
                elif file_path.endswith(".xlsx"):
                    df             = pd.read_excel(file_path,index_col=False)
                else:
                    logging.info("unknow file type")
                logging.info('loaded df shape[%s]',df.shape)
                ret_dict        = {'df':df}
            elif node_label =="S3":
                from unkops import Bucket
                ds_id           = node_data.get("config").get("dsId")
                train_file      = node_data.get("config").get("trainFileName")
                indie_file      = node_data.get("config").get("indieFileName")
                logging.info("begin download dataserver data ds_id[%s] train_file[%s]  indie_file[%s]"%
                             (ds_id,train_file,indie_file ) )
                client = Bucket(ini_conf["minioexplore"]['url'],ini_conf["minioexplore"]['access_key'],ini_conf["minioexplore"]['secret_key'])

                trainFileName_file_path = os.path.join(project_dir,f'{node_id}__{train_file}')
                indieFileName_file_path = os.path.join(project_dir,f'{node_id}__{indie_file}')

                if train_file!=None:
                    logging.info("download %s %s",train_file,trainFileName_file_path)
                    client.download_file(bucket_name="mlapc.dataserver.new",file="/%s/%s"%(ds_id,train_file),     file_path=trainFileName_file_path)
                if indie_file != None:
                    logging.info("download %s %s", indie_file, indieFileName_file_path)
                    client.download_file(bucket_name="mlapc.dataserver.new", file="/%s/%s" % (ds_id, indie_file), file_path=indieFileName_file_path )
                ret_dict = {}
                ret_dict['train_df'] = pd.read_csv(trainFileName_file_path,sep=node_data.get("delimiter",","),index_col=False)
                ret_dict['indie_df'] = pd.read_csv(indieFileName_file_path,sep=node_data.get("delimiter",","),index_col=False)

            elif node_label =="URL":

                trainFileName = node_data.get("config").get("trainFileName")
                indieFileName = node_data.get("config").get("indieFileName")
                fileType      = node_data.get("config").get("fileType")
                singleFileUrl = node_data.get("config").get("singleFileUrl")

                nodeId          = node_id
                sep             = node_data.get("config").get('sep', ',')
                proj_dir        = "projects";
                project_dir     = os.path.join(proj_dir, self.projectname)
                logging.info("####node_label %s fileType %s ", node_label,fileType )

                if fileType in ['single', 'train_test']:
                    if fileType == 'single':
                        urlfile = singleFileUrl
                        tmpfile = os.path.join(self.project_dir, '%s__df.csv' % nodeId)  #
                        if os.path.exists( tmpfile ) ==False :download_file_from_url(singleFileUrl, tmpfile)
                        ret_dict['df'] = pd.read_csv(tmpfile, sep=sep)
                    elif fileType == 'train_test':
                        urlfile = indieFileName
                        tmpfile = os.path.join(self.project_dir, '%s__indie_df.csv' % nodeId)
                        if os.path.exists( tmpfile ) ==False :download_file_from_url(urlfile, tmpfile)
                        ret_dict['indie_df'] = pd.read_csv(tmpfile,sep=sep)

                        urlfile = trainFileName
                        tmpfile = os.path.join(self.project_dir, '%s__train_df.csv' % nodeId)
                        if os.path.exists( tmpfile ) ==False : download_file_from_url(urlfile, tmpfile)
                        ret_dict['train_df'] = pd.read_csv(tmpfile, sep=sep)
                    else:
                        logging.info("unknow filetype[%s]", fileType)

            elif node_label == "DataBase":
                # 新增的数据库处理逻辑
                config = node_data.get('config', {})
                db_type = config.get('dbType', 'mysql').lower()
                db_url = config.get('dbUrl', '')
                db_name = config.get('dbdb', '')
                username = config.get('username', '')
                password = config.get('password', '')
                sql_query = config.get('sqlQuery', '')
                try:
                    # 根据数据库类型创建引擎
                    if db_type == 'mysql':
                        from .db import  get_mysql_engine
                        engine = get_mysql_engine(username, password, db_url, db_name)
                    elif db_type == 'oracle':
                        # 默认使用SID模式，可以根据需要调整
                        from .db import get_oracle_engine
                        engine = get_oracle_engine(username, password, db_url, db_name, mode="sid")
                    else:
                        raise ValueError(f"Unsupported database type: {db_type}")

                    # 执行SQL查询获取数据]
                    from .db import  get_sql_df
                    df = get_sql_df(sql_query, engine)

                    # 如果是在训练阶段，保存数据到本地文件
                    file_path = os.path.join(project_dir, f'{node_id}.csv')
                    df.to_csv(file_path, index=False)
                    logging.info(f'Saved database query results to: {file_path}')

                    ret_dict['df'] = df
                    logging.info(f'Loaded database data with shape: {df.shape}')

                except Exception as e:
                    logging.error(f"Error processing database node: {str(e)}")
                    raise

        else:
            ret_dict                = {}#self.results[ node_id ]
            if node_id in sample_dict:
                logging.info("%s in sample_dict",node_id)
                sample_df = sample_dict[node_id]
            else:
                logging.info("%s not in sample_dict", node_id)
                inferenceDataMode = node_data.get("config").get("inferenceDataMode")  #
                inferenceFunction = node_data.get("config").get("inferenceFunction")
                inferenceDebugParams = node_data.get("config").get("inferenceDebugParams",{})
                if inferenceDataMode!="train" and inferenceFunction!=None:
                    import re
                    function_name = re.findall(r"^def +(.+?)\(", inferenceFunction)[0]
                    exec(inferenceFunction, globals())
                    logging.info("run func:%s", function_name)
                    if not function_name:
                        logging.error('No function definition found in the code,please check')
                    else:
                        sample_df = eval(function_name)( inferenceDebugParams )
                elif node_label == "URL":
                    trainFileName = node_data.get("config").get("trainFileName")
                    indieFileName = node_data.get("config").get("indieFileName")
                    fileType = node_data.get("config").get("fileType")
                    singleFileUrl = node_data.get("config").get("singleFileUrl")

                    if inferenceDataMode=="train":
                        if fileType in ['single', 'train_test']:
                            if fileType == 'single':
                                urlfile = singleFileUrl
                                tmpfile = os.path.join(self.project_dir, '%s__df.csv' % nodeId)  #
                                if os.path.exists(tmpfile) == False: download_file_from_url(singleFileUrl, tmpfile)
                                ret_dict['sample_df'] = pd.read_csv(tmpfile, sep=sep)
                            else:
                                logging.info("unknow filetype[%s]", fileType)

                    elif fileType in ['single', 'train_test']:
                        if fileType == 'single':
                            sample_df = get_infer_dataframe(singleFileUrl)
                        elif fileType == 'train_test':
                            sample_df = get_infer_dataframe(trainFileName)
                        else:
                            logging.info("unknow filetype[%s]", fileType)
                elif node_label =="CSV" :
                    if  "df" in self.results[node_id]:
                        if len( self.results[node_id]['df'] )<10000:
                            sample_df       = copy.deepcopy(self.results[node_id]["df"])
                            ret_dict["df"] =  self.results[node_id]["df"]
                        else:
                            logging.info("%s data not in sample dict,try to use old excel file,but len>10000")

                    elif "sample_df" in self.results[node_id]:
                        sample_df = self.results[node_id]["sample_df"]
                    else:
                        logging.info("df not in self.results[%s]",node_id)
                else:
                    logging.info("unknown node label[%s]",node_label)

            ret_dict['sample_df']   = sample_df

        logging.info('finish process_data_source ')
        return ret_dict

    def preprocess_data(self,node_id, node_data, task='train',sample_dict={}):
        # 处理类型设置节点
        pre_node_ids        = node_data.get('prenodeId')
        logging.info('prenode id %s ', pre_node_ids)
        pre_node_label      = self.get_label_byId( pre_node_ids[0] )
        pre_node_type       = self.get_type_byId(  pre_node_ids[0] )
        # 获取前一个节点的数据结构
        pre_node_result     = self.results.get(   pre_node_ids[0]     )
        pre_node_data       = self.get_nodedata_byid( pre_node_ids[0] )
        logging.info('pre_node_data:%s',pre_node_data)
        pre_node_columns    = pre_node_data['config']['columns']
        logging.info('columns:%s',pre_node_columns)
        #from auto_ml_v2 import data_process, map_to_localargs
        from .automl_utils    import  map_to_localargs
        from ..data_process.data_preprocess  import data_process_byparams
        pre_dict = self.get_pre_data(task=task, pre_node_type=pre_node_type, pre_node_label=pre_node_label,pre_node_data= pre_node_result)
        logging.info("pre_dict keys:%s",pre_dict.keys() )
        ret_dict = {}
        if task =='train':
            #df = self.results[node_data.get('node_id')]
            preprocess_json  ={ }
            columnTypes     = node_data['config'].get('columnTypes',[ ] )
            batch_group_dict={ }
            for k in columnTypes:
                if columnTypes[k] != 'no':
                    if k in node_data['config']['batchFill']:
                        v = node_data['config']['batchFill'][k]
                        batch_group_dict.setdefault("batchfill",[])  #node_data['config']['batchFill'][k]
                        batch_group_dict['batchfill'].append(   "%s|%s|%s"%( k,v,columnTypes[k] )  )
                    if k in node_data['config']['groupFill']:
                        v = node_data['config']['groupFill'][k]
                        batch_group_dict.setdefault("groupfill",[])  # node_data['config']['batchFill'][k]
                        batch_group_dict['groupfill'].append("%s|%s|%s" % (k, v, columnTypes[k]))
                    tmp_dict = {'data_type': columnTypes[k]}
                    if k in node_data['config']['outlierHandling']:
                        tmp_dict['outlier'] = node_data['config']['outlierHandling'][k]
                    if k in node_data['config']['missingFill']:
                        tmp_dict['fillna'] = node_data['config']['missingFill'][k]
                    if k in node_data['config']['preprocessing']:
                        tmp_dict['proc'] =  node_data['config']['preprocessing'][k]
                    preprocess_json[k] = copy.deepcopy(tmp_dict)

            logging.info("from preprocess_json:%s",preprocess_json)
            params   = map_to_localargs(   {"preprocess_json":preprocess_json,"batchfill": batch_group_dict.get("batchfill",None) ,"groupfill":batch_group_dict.get("groupfill",None) } )
            logging.info("params:%s",params)
            ret_dict['params']      = params
            ret_dict['columnTypes'] = columnTypes
            ret_dict['pre_node_columns'] = pre_node_columns

            if  'df' in pre_dict:
                df, p_dict          = data_process_byparams(pre_dict['df'],keys=[], xcols=pre_node_columns, ycol=None, params=params, if_train=True, data_type="train", use_mlflow=None)
                ret_dict['df']      = df
                ret_dict['p_dict']  = p_dict
            elif 'train_df'  in pre_dict:
                train_df, p_dict    = data_process_byparams(pre_dict['train_df'], keys=[], xcols=pre_node_columns, ycol=None, params=params, if_train=True, data_type="train", use_mlflow=None)
                ret_dict['train_df']= train_df
                ret_dict['p_dict']  = p_dict

                if "test_df" in pre_dict and pre_dict['test_df'] is not None:
                    test_df             = data_process_byparams( pre_dict['test_df'], keys=[], xcols=pre_node_columns, ycol=None, params=params,if_train= False, preprocess_dict=p_dict, data_type="test", use_mlflow=None )
                    ret_dict['test_df'] = test_df
                if 'indie_df' in pre_dict  and pre_dict['indie_df'] is not None:
                    indie_df             = data_process_byparams( pre_dict['indie_df'],keys=[], xcols=pre_node_columns, ycol=None, params=params, if_train=False, preprocess_dict=p_dict, data_type="indie", use_mlflow=None)
                    ret_dict['indie_df'] = indie_df
            else:
                logging.info("unknow prednode data")
        else:
            if 'sample_df'  in pre_dict :
                ret_dict= self.results[node_id]
                params  = self.results[node_id]['params']
                p_dict  = self.results[node_id]['p_dict']
                col_dict= self.results[node_id]['columnTypes']
                sample_df             = data_process_byparams( pre_dict['sample_df'], keys=[], xcols=pre_node_columns, ycol=None, params=params,if_train= False, preprocess_dict=p_dict, data_type="test", use_mlflow=None,type_dict=col_dict )
                ret_dict['sample_df'] = sample_df

        return  ret_dict


    def process_merge(self,node_id, node_data, task):
        # 处理Merge节点
        logging.info("begin process_merge")
        left_df     = self.results[ node_data['config']['leftNode']   ]['df']
        right_df    = self.results[ node_data['config']['rightNode']  ]['df']
        merge_keys = node_data['config']['mergeKeys']   #.get('merge_keys', [])
        merged_df = pd.merge(left_df, right_df, on=merge_keys)
        logging.info('merged_df shape[%s]',merged_df.shape)
        if task !="predict":
            ret_dict = {'df':merged_df}
        else:
            ret_dict = {'sample_df':merged_df}
        logging.info("finish process_merge")
        return ret_dict

    def get_pre_data(self,task,pre_node_type,pre_node_label,pre_node_data):
        if task != 'predict':
            if pre_node_label == 'CSV' or 'df' in pre_node_data:
                df      = pre_node_data.get('df')
                ret_dict= {"df":df}
            elif pre_node_label == 'DataServer':
                if "train_df" in pre_node_data:
                    train_df    = pre_node_data.get('train_df')
                    indie_df    = pre_node_data.get('indie_df', pd.DataFrame())
                    ret_dict    = {"train_df":train_df,"indie_df":indie_df}
                elif "df" in pre_node_data:
                    train_df = pre_node_data.get("df")
                    test_df  = pre_node_data.get('df', pd.DataFrame())
                    indie_df = pre_node_data.get('df', pd.DataFrame())
                    ret_dict ={"train_df":train_df,"test_df":test_df,"indie_df":indie_df}
                elif 'pred_df' in  pre_node_data:
                    ret_dict = {"df":  pre_node_data.get("pred_df") }
                else:
                    logging.info("has no DataServer data")
            else:
                if "train_df" in pre_node_data:
                    train_df = pre_node_data.get('train_df')
                    ret_dict = {"train_df": train_df}
                    if "indie_df" in pre_node_data:
                        indie_df                = pre_node_data.get('indie_df')
                        ret_dict['indie_df']    = indie_df
                    if "test_df" in pre_node_data:
                        test_df                 = pre_node_data.get('test_df')
                        ret_dict['test_df']     = test_df
                elif 'df' in pre_node_data:
                    df = pre_node_data.get("df")
                    ret_dict = {"df":df}
                elif 'pred_df' in pre_node_data:
                    pred_df = pre_node_data.get("pred_df")
                    ret_dict = {"df": pred_df}
                else:
                    logging.info("unknow pre_node_label,has no data,pre_data:%s",pre_node_data.keys())
        else:
            if "sample_df" in pre_node_data:
                sample_df = pre_node_data.get('sample_df')
            elif 'pred_df' in pre_node_data:
                sample_df = pre_node_data.get('pred_df')
            else:
                logging.info("unknow pre_node_data data,has no data,pre_data:%s", pre_node_data.keys())
            ret_dict  = {'sample_df': sample_df}
        return ret_dict

    def process_agent( self, node_id,node_data, task=None,sample_dict={}) :
        logging.info("begin process agent")
        global has_import_agent
        if has_import_agent ==False:
            has_import_agent = True
        if node_id in self.results:
            if "agent_config" in self.results[node_id]:
                agent_config = self.results[node_id]['agent_config']
            else:
                agent_config = node_data.get('config') ;
        else:
            agent_config = node_data.get('config') ;
        logging.info( "agent_config:%s",agent_config );
        agent        = LLMAgent( agent_config )
        text_prompt = sample_dict.get(node_id ,"请解释什么是大语言模型（LLM），并说明其核心原理")  #"请解释什么是大语言模型（LLM），并说明其核心原理"
        logging.info(f"text_prompt:{text_prompt}" )
        text_response = agent.generate(text_prompt)
        logging.info("text_response:%s",text_response["data"])
        # logging.info("config:",config )
        logging.info("finish process agent")
        ret = {"text_response":text_response["data"],"agent_config":agent_config }
        return ret

    def process_if( self, node_id,node_data, task=None,sample_dict={}) :
        logging.info("begin process if")
        logging.info("node_data:%s", node_data)
        pre_node_ids = node_data.get('prenodeId');
        logging.info('prenode id[%s]', pre_node_ids)


        logging.info("finish process if")
        ret = { }
        return ret

    def process_multimodel(self,node_id,node_data, task=None,sample_dict={}):
        from .logic_dispatch import get_train_model, evaluate_, str_to_list, multi_models_predicts, save_model
        logging.info('begin process_multimodel')

        saved_mode_dict={}
        model_configs = node_data.get('config').get("models",[])
        keys          = node_data.get('config').get("selectedGlobalKey",[])
        pre_node_ids    = node_data.get('prenodeId');
        logging.info('prenode id[%s]', pre_node_ids)

        pre_node_label  = self.get_label_byId( pre_node_ids[0] )
        pre_node_type   = self.get_type_byId(  pre_node_ids[0] )
        if keys !=None:
            keys            = str_to_list( node_data.get('config').get("selectedGlobalKey",[]) )  ;
            keys= [ i for i in keys  if i!="" ]
        else:
            keys=[]
        model_type      = node_data.get('config').get("selectedModelType",'reg')
        pre_node_data   = self.results.get(pre_node_ids[0])
        logging.info('pre_node_data:%s', pre_node_data.keys())
        # if task != 'predict':
        #     select_cols = x_candidates+y_candidates + set( keys )
        # else:
        #     select_cols = x_candidates + set( keys )
        xcols_set = set()
        ycols_set = set()
        if task != 'predict':
            for idx_dict in model_configs:
                xcols_set = xcols_set | set(  idx_dict.get("x",[]) )
                ycols_set = ycols_set | set(  [idx_dict.get("y")] )
            select_cols = set(keys) |  xcols_set | ycols_set
            select_cols = list( select_cols  )
            logging.info(" select_cols set %s" , select_cols)

            pre_dict = self.get_pre_data(task, pre_node_type, pre_node_label, pre_node_data)
            train_df, test_df, indie_df = pre_dict.get('train_df', None), pre_dict.get('test_df', None), pre_dict.get('indie_df', None)  # ['test_df'] indie_df  ['indie_df']
            if train_df is None and test_df is None and indie_df is None:
                logging.error('Missing train_df, test_df, or indie_df in prenode data')
                if 'df' not in pre_dict:
                    return {'error': 'no train/test/indie data %s' % pre_node_label[0]}
                else:
                    df = pre_dict['df']
                    train_df, indie_df = train_test_split(df, train_size=0.8)
                    train_df, test_df = train_test_split(train_df, train_size=0.8)
                    logging.info("dataset len train[%s] test[%s] indie[%s]", len(train_df), len(test_df), len(indie_df))
            if test_df is None and (train_df is not None and indie_df is not None):
                test_df = train_df.sample(frac=0.2, random_state=42)
                train_df = train_df.drop(test_df.index)
            if len(train_df) != 0:   train_df = train_df[select_cols]
            if len(test_df) != 0:    test_df = test_df[select_cols]
            if len(indie_df) != 0:
                if ycols_set & set(indie_df.columns) != ycols_set:
                    indie_df = indie_df[xcols_set]
                else:
                    indie_df = indie_df[select_cols]


            import argparse
            params              = argparse.Namespace()
            params.mode         = 'quick'  # 默认模式为 'quick'
            params.model_type   = model_type  # 默认模型类型为 'reg'
            params.algo_name    = [ ii.get("y") +"__" +ii.get("algorithm") for ii in model_configs ]   #idx_dict.get("algorithm")
            # params.tuning_json  = idx_dict.get('params', None)
            # params.search_algo  = idx_dict.get('search_algo', 'grid')
            params.algo_xcols_dict   = { ii.get("y") +"__" +ii.get("algorithm"):ii.get("x") for ii in model_configs   }
            params.algo_ycol_dict   = {  ii.get("y") +"__" +ii.get("algorithm"):ii.get("y") for ii in model_configs   }
            models_dict, model_best_params = get_train_model(params, train_df, None, None)
            
            saved_mode_dict = {"models_dict":{} , "mets_df":[],"select_cols":{} ,"model_config_dict":{},"model_params_dict":{ } }

            mets_df, pred_df = evaluate_(params, models_dict, train_df, test_df, indie_df, keys, None, None)
            saved_mode_dict = {}
            saved_mode_dict['models_dict'] = models_dict
            saved_mode_dict['mets_df'] = mets_df
            saved_mode_dict['pred_df'] =  pred_df
            saved_mode_dict["params"]   = params
            saved_mode_dict["xcols"]   = list( xcols_set )
            #saved_mode_dict['mets_df'] = pd.concat( saved_mode_dict['mets_df'] , ignore_index=True  )
        else:

            if node_id in sample_dict:
                sample_df = sample_dict[node_id]  # pre_node_data.get('sample_df')
            else:
                sample_df = pre_node_data.get('sample_df')
            logging.info("sample_df:%s", sample_df)
            if sample_df is None:
                logging.error('predict sample_df is None')
                return {'error': 'no predict sample data %s' % pre_node_label[0]}

            saved_mode_dict= self.results[node_id]
            if "xcols" in saved_mode_dict:
                xcols       =   saved_mode_dict["xcols"]


            select_cols = set(keys) | set( xcols  )
            select_cols = [ i for i in sample_df.columns if i in select_cols ]

            if len(sample_df) != 0:
                sample_df = sample_df[select_cols]
            else:
                logging.error('predict sample_df len is 0')
                saved_mode_dict['error']='no predict data,sample data %s' % pre_node_label[0]
                return saved_mode_dict

            models_dict         = saved_mode_dict['models_dict']

            preds = multi_models_predicts(models_dict, sample_df, keys, None, None, deploy=True,model_params=saved_mode_dict["params"])
            saved_mode_dict['sample_df'] = preds

        logging.info('finish process_algorithm')
        return saved_mode_dict

    def process_algorithm(self, node_id,node_data, task=None,sample_dict={}):
        # 处理传统算法节点
        from  .logic_dispatch import get_train_model, evaluate_,str_to_list,multi_models_predicts,save_model

        logging.info('begin process_algorithm')

        xcols       = node_data.get('config').get('xColumns')
        ycol        = node_data.get('config').get('yColumn')
        keys        = node_data.get('config').get('algoKeys',[])
        if keys in [None,'NoneType']: keys=[]

        if xcols == None or xcols =="":
            continuousxcolumns = node_data.get('config').get("continuousxColumns",[])
            categoriesxcolumns = node_data.get('config').get("categoriesxColumns",[])
            textxcolunns       = node_data.get('config').get("textxColumns",[])
            imagexcolunns      = node_data.get('config').get("imagexColumns",[])
            xcols = continuousxcolumns + categoriesxcolumns + textxcolunns + imagexcolunns

        algorithm   = node_data.get('config').get('Algorithm')
        logging.info('keys[%s]  X[%s] y[%s] algo[%s] ',keys, xcols, ycol, algorithm)
        if task != 'predict':
            select_cols = keys+ str_to_list(ycol) + xcols
        else:
            select_cols = keys + xcols
        logging.info('select_cols:%s',select_cols)
        pre_node_ids    = node_data.get('prenodeId');
        logging.info('prenode id[%s]', pre_node_ids)

        pre_node_label  = self.get_label_byId( pre_node_ids[0] )
        pre_node_type   = self.get_type_byId(  pre_node_ids[0] )
        # 获取前一个节点的数据结构
        pre_node_data   = self.results.get( pre_node_ids[0] )
        logging.info('pre_node_data:%s',pre_node_data.keys() )

        if pre_node_data is None:
            logging.error( 'No data found for prenode id[%s]', pre_node_ids[0] )
            return {'error':'prenode id[%s] no data'%pre_node_data[0] }

        logging.info('x[%s] y[%s] algo[%s]', xcols, ycol, algorithm)  # 创建 argparse.Namespace 对象并填充参数
        if task != 'predict':
            pre_dict = self.get_pre_data( task,pre_node_type,pre_node_label,pre_node_data )
            train_df ,test_df,indie_df = pre_dict.get('train_df',None),pre_dict.get('test_df',None),pre_dict.get('indie_df',None) #['test_df'] indie_df  ['indie_df']
            if  train_df is  None and test_df is  None and indie_df is  None :
                logging.error('Missing train_df, test_df, or indie_df in prenode data')
                if 'df' not in pre_dict:
                    return {'error': 'no train/test/indie data %s'%pre_node_label[0] }
                else:
                    df = pre_dict['df']
                    train_df,indie_df = train_test_split(df,train_size=0.8)
                    train_df,test_df  = train_test_split(train_df,train_size=0.8)
                    logging.info("dataset len train[%s] test[%s] indie[%s]",len(train_df),len(test_df),len(indie_df))
            if test_df is None and (train_df is not None and indie_df is not None):
                test_df  = train_df.sample(frac = 0.2,random_state =42 )
                train_df = train_df.drop( test_df.index  )
            if len(train_df) != 0:   train_df = train_df[select_cols]
            if len(test_df)  != 0:   test_df  = test_df[select_cols]
            if len(indie_df) != 0  :
                if set( str_to_list(ycol) ) & set( indie_df.columns )!=set( str_to_list(ycol) ):
                    indie_df = indie_df[xcols]
                else:
                    indie_df = indie_df[select_cols]

            import argparse
            params              = argparse.Namespace()
            params.mode = node_data.get('config').get('AlgoMode', 'quick')  # 默认模式为 'quick'
            params.model_type   = node_data.get('config').get('AlgoType', 'reg')  # 默认模型类型为 'reg'
            params.algo_name    = algorithm
            params.tuning_json =  node_data.get('config').get('tuning_json', None)
            params.search_algo =  node_data.get('config').get('search_algo', 'grid')

            params.xcols                    = xcols
            params.continuousxcolumns       = node_data.get('config').get("continuousxColumns",None )
            params.categoriesxcolumns       = node_data.get('config').get("categoriesxColumns", None)
            params.textxcolumns             = node_data.get('config').get("textxColumns", None      )
            params.imagexcolumns            = node_data.get('config').get("imagexColumns", None     )
            params.num_continuousxcolumns  = len(params.continuousxcolumns) if params.continuousxcolumns !=None else 0
            params.num_categoriesxcolumns  = len(params.categoriesxcolumns) if params.categoriesxcolumns !=None else 0
            params.num_textxcolumns        = len(params.textxcolumns)       if params.textxcolumns       !=None else 0
            params.num_imagexcolunns       = len(params.imagexcolumns)      if params.imagexcolumns      !=None else 0

            params.num_continuous  =  params.num_continuousxcolumns
            params.num_categories  =  params.num_categoriesxcolumns

            models_dict, model_best_params = get_train_model( params, train_df, xcols, ycol )
            logging.info('models dict keys **********:%s', models_dict.keys()    )
            mets_df, pred_df = evaluate_(params, models_dict, train_df, test_df, indie_df, keys, xcols, ycol)
            saved_mode_dict                     = {}
            saved_mode_dict['models_dict']      = models_dict
            saved_mode_dict['mets_df']          = mets_df
            saved_mode_dict['pred_df']          = pred_df

        else:
            if node_id in sample_dict:
                sample_df = sample_dict[ node_id ]  #pre_node_data.get('sample_df')
            else:
                sample_df = pre_node_data.get('sample_df')
            logging.info("sample_df:%s",sample_df)
            if  sample_df is  None:
                logging.error('predict sample_df is None')
                return { 'error': 'no predict sample data %s' % pre_node_label[0] }
            if len(sample_df) != 0:
                sample_df = sample_df[select_cols]
            else:
                logging.error('predict sample_df len is 0')
                return { 'error': 'no predict sample data %s' % pre_node_label[0] }

            saved_mode_dict  =  self.results[node_id]

            models_dict      =  saved_mode_dict['models_dict']
            preds            =  multi_models_predicts( models_dict, sample_df, keys, xcols, ycol, deploy=True)
            saved_mode_dict['sample_df'] = preds

        logging.info('finish process_algorithm')
        return saved_mode_dict

    def process_onlineCtrl(self, node_id,node_data,results,  task="train"):
        logging.info("begin process_onlineCtrl")
        """
        处理在线预测控制节点
        """
        try:
            # 获取配置参数
            config = node_data.get('config', {})
            user_code = config.get('code', '')
            json_config_str = config.get('config_dict', '{}')
            input_mode = config.get('inputMode', 'single')  # 默认为单输入模式

            logging.info("OnlineCtrl input_mode: %s", input_mode)
            logging.info("OnlineCtrl user_code length: %s", len(user_code))
            logging.info("OnlineCtrl json_config: %s", json_config_str)

            # 解析 JSON 配置
            try:
                config_dict = json.loads(json_config_str) if json_config_str else {}
            except json.JSONDecodeError as e:
                logging.error("JSON config parse error: %s", e)
                return {'error': f'Invalid JSON config: {str(e)}'}

            # 单输入模式
            if input_mode == 'single':
                pre_node_ids = node_data.get('prenodeId', [])

                if not pre_node_ids:
                    return {'error': 'No input nodes found for single mode'}

                logging.info('OnlineCtrl prenode ids: %s', pre_node_ids)

                # 获取第一个前置节点的数据
                first_node_id = pre_node_ids[0]
                if first_node_id not in results:
                    return {'error': f'Input node {first_node_id} data not found'}

                pre_node_label = self.get_label_byId(first_node_id)
                pre_node_type = self.get_type_byId(first_node_id)
                pre_node_data = self.results.get(first_node_id)
                pre_dict = self.get_pre_data(task, pre_node_type, pre_node_label, pre_node_data)

                logging.info("OnlineCtrl pre_dict keys: %s", pre_dict.keys())

                # 执行用户代码
                import re
                function_match = re.findall(r"^def +(.+?)\(", user_code)
                if not function_match:
                    return {'error': 'No function definition found in the code'}

                function_name = function_match[0]
                exec(user_code, globals())
                logging.info("OnlineCtrl running function: %s", function_name)

                # 处理不同类型的数据
                ret_ = {}
                data_processed = False

                # 尝试处理各种可能的数据键
                for data_key in ['df', 'train_df', 'indie_df', 'test_df', 'sample_df', 'result']:
                    if data_key in pre_dict and pre_dict[data_key] is not None:
                        try:
                            logging.info("Processing data_key: %s", data_key)
                            result_data = eval(function_name)(pre_dict[data_key], config_dict)
                            ret_[data_key] = result_data
                            data_processed = True
                            # logging.info("result_data:%s",result_data)
                            # 如果是训练任务且第一次处理成功，设置columns
                            if task == 'train' and 'columns' not in ret_:
                                if hasattr(result_data, 'columns'):
                                    ret_['columns'] = list(result_data.columns)
                                elif isinstance(result_data, dict):
                                    ret_['columns'] = list(result_data.keys())

                        except Exception as e:
                            logging.error("Error processing %s: %s", data_key, e)
                            continue

                if not data_processed:
                    return {'error': 'No valid input data found to process'}

                return ret_

            # 多输入模式
            else:
                pre_node_ids = node_data.get('prenodeId', [])
                logging.info('OnlineCtrl prenode ids: %s', pre_node_ids)
                if not pre_node_ids:
                    return {'error': 'No input nodes found for multiple mode'}

                # 构建输入字典 {nodeId: 对应数据}
                input_dict = {}
                for node_id in pre_node_ids:
                    if node_id not in results:
                        return {'error': f'Input node {node_id} data not found'}

                    node_label = self.get_label_byId(node_id)
                    node_type = self.get_type_byId(node_id)
                    node_data = self.results.get(node_id)
                    pre_data = self.get_pre_data(task, node_type, node_label, node_data)
                    logging.info("pre_data keys:%s",pre_data.keys())
                    # 根据节点类型决定使用哪个数据
                    data_found = False
                    for data_key in ['df', 'train_df', 'indie_df', 'test_df', 'sample_df', 'result']:
                        if data_key in pre_data and pre_data[data_key] is not None:
                            input_dict[node_id] = pre_data[data_key]
                            data_found = True
                            break

                    if not data_found:
                        # 如果没有找到标准数据键，使用整个pre_data
                        input_dict[node_id] = pre_data

                logging.info("OnlineCtrl multiple mode input_dict keys: %s", input_dict.keys())

                # 执行用户代码
                import re
                function_match = re.findall(r"^def +(.+?)\(", user_code)
                if not function_match:
                    return {'error': 'No function definition found in the code'}

                function_name = function_match[0]
                exec(user_code, globals())
                logging.info("OnlineCtrl running function: %s", function_name)

                # 调用用户函数，传入input_dict和config_dict
                result = eval(function_name)(input_dict, config_dict)
                logging.info("OnlineCtrl run result type: %s", type(result))

                # 根据返回类型组织结果
                if hasattr(result, 'columns'):  # pandas DataFrame
                    if task in ["train","offline"]:
                        ret_data = {"df": result}
                    else:
                        ret_data = {"sample_df": result}
                    if task == 'train':
                        ret_data['columns'] = list(result.columns)
                    return ret_data
                elif isinstance(result, dict):
                    # 如果返回的是字典，直接使用
                    if task == 'train' and 'columns' not in result:
                        # 尝试从字典中提取columns
                        for key, value in result.items():
                            if hasattr(value, 'columns'):
                                result['columns'] = list(value.columns)
                                break
                    return result
                else:
                    # 其他类型包装在result键中
                    ret_data = {"result": result}
                    if task == 'train' and hasattr(result, 'columns'):
                        ret_data['columns'] = list(result.columns)
                    return ret_data

        except Exception as e:
            logging.error("OnlineCtrl process error: %s", str(e))
            import traceback
            logging.error("OnlineCtrl traceback: %s", traceback.format_exc())
            return {'error': f'OnlineCtrl processing failed: {str(e)}'}

    def process_feature_derive(self, node_data, results,task="train"):
        # 处理特征衍生节点
        logging.info("begin process_feature_derive")
        derive_func = node_data.get('config',{}).get('deriveFunc')
        input_mode = node_data.get('config', {}).get('deriveInputMode', 'single')  # 默认为单输入模式
        logging.info("input_mode:%s", input_mode)
        if input_mode == 'single':
            pre_node_ids = node_data.get('prenodeId');
            logging.info('prenode id[%s]', pre_node_ids)
            pre_node_label  = self.get_label_byId(pre_node_ids[0])
            pre_node_type   = self.get_type_byId(pre_node_ids[0])
            pre_node_data   = self.results.get(pre_node_ids[0])
            if pre_node_ids[0] not in results:
                return {'error': 'before run deriveFunc,Input node[%s] result data not found'%pre_node_ids[0] }
            pre_dict        = self.get_pre_data(task, pre_node_type, pre_node_label, pre_node_data)
            ret_            = {  }
            import re
            function_name = re.findall(r"^def +(.+?)\(", derive_func)[0]
            exec(derive_func, globals())
            logging.info("run func:%s", function_name)
            if not function_name:
                return jsonify({'error': 'No function definition found in the code'}), 400
            if task not in ["train"]:
                logging.info("deriveFunction indf:%s", pre_dict['sample_df'] )
                result            = eval(function_name)(pre_dict['sample_df'])
                ret_["sample_df"] = result
            else:
                for f in ['df','train_df','indie_df','test_df']:
                    logging.info('pre keys:%s', pre_dict.keys() )
                    if f not in pre_dict:
                        continue
                    logging.info(' %s appear in pre_node_results, data will used in deriveFunc', f)
                    logging.info("f head:%s",f,pre_dict[f].head())
                    result = eval(function_name)(pre_dict[f])
                    ret_[f]= result
                    if 'columns' not in ret_ and task=='train': ret_['columns'] = list(ret_[f].columns)
            return ret_
        else:
            # 多输入模式
            pre_node_ids = node_data.get('prenodeId', [])
            if not pre_node_ids:
                return {'error': 'No input nodes found'}

            # 构建输入字典 {nodeId: 对应数据}
            input_dict = {}
            for node_id in pre_node_ids:
                if node_id not in results:
                    return {'error': f'Input node {node_id} data not found'}

                node_label = self.get_label_byId(node_id)
                node_type = self.get_type_byId(node_id)
                node_data = self.results.get(node_id)
                pre_data = self.get_pre_data(task, node_type, node_label, node_data)

                # 根据节点类型决定使用哪个数据
                if task in ["train","offline"]:
                    if node_type in ['DataSource',"CSV"] or  'df' in pre_data:
                        input_dict[node_id] = pre_data.get('df')
                else:
                    if 'sample_df' in pre_data:
                        input_dict[node_id] = pre_data.get('sample_df')
                    elif 'pred_df' in pre_data:
                        input_dict[node_id] = pre_data.get('pred_df')
                    else:
                        # 对于其他类型节点，可以根据需要调整
                        input_dict[node_id] = pre_data

            # 执行用户代码
            import re
            function_name = re.findall(r"^def +(.+?)\(", derive_func)[0]
            exec(derive_func, globals())

            if not function_name:
                return {'error': 'No function definition found in the code'}
            if task not in ["train","offline"]:
                logging.info("deriveFunction input_dict:%s",input_dict)
                # 调用用户函数，传入input_dict
            result = eval(function_name)(input_dict)
            logging.info("deriveFunc return result type %s",type(result))

            if isinstance(result,pd.DataFrame):
                if task in ["train","offline"]:
                    return {"df": result}
                else:
                    return {"sample_df":result}
            else:
                return {"result":result}



    def process_append(self, node_id, node_data, task="task"):
        # 处理Append节点
        logging.info('begin process_append')
        node_ids = node_data.get( "prenodeId",[ ] )

        if not node_ids :
            return {'error': 'Node IDs or results not provided'}
        if task != "predict":
            dfs = [  self.results[node_id  ]['df'] for node_id in node_ids if node_id in self.results        ]
        else:
            dfs = [  self.results[node_id  ]['sample_df'] for node_id in node_ids if node_id in self.results ]
        if not dfs:
            return {'error': 'No valid dataframes found'}

        appended_df = pd.concat(dfs, ignore_index=True)
        if task !="predict":
            ret_dict = {'df':appended_df }
        else:
            ret_dict = {'sample_df':appended_df}
        return ret_dict

    def _apply_row_filters(self, df, conditions):
        """应用行筛选条件"""
        if not conditions:
            return df

        # 为每个条件生成筛选掩码
        masks = []

        for condition in conditions:
            if not condition.get('column'):
                continue  # 跳过没有选择列的条件

            column = condition['column']
            operator = condition.get('operator', '==')
            value = condition.get('value', '')
            value_type = condition.get('valueType', 'string')

            # 确保列存在
            if column not in df.columns:
                logging.warning('Column %s not found in DataFrame, skipping condition', column)
                continue

            # 根据值类型转换
            try:
                if value_type == 'number' and value:
                    value = float(value)
            except (ValueError, TypeError):
                logging.warning('Cannot convert value %s to number, treating as string', value)
                value_type = 'string'

            # 生成条件掩码
            mask = self._generate_condition_mask(df, column, operator, value, value_type)
            if mask is not None:
                masks.append(mask)

        # 组合所有条件（使用 AND 逻辑）
        if masks:
            combined_mask = masks[0]
            for mask in masks[1:]:
                combined_mask = combined_mask & mask
            return df[combined_mask]

        return df

    def _generate_condition_mask(self, df, column, operator, value, value_type):
        """生成单个条件的布尔掩码"""
        try:
            if operator == '==':
                return df[column] == value
            elif operator == '!=':
                return df[column] != value
            elif operator == '>':
                return df[column] > value
            elif operator == '<':
                return df[column] < value
            elif operator == '>=':
                return df[column] >= value
            elif operator == '<=':
                return df[column] <= value
            elif operator == 'contains':
                return df[column].astype(str).str.contains(str(value), na=False)
            elif operator == 'not_contains':
                return ~df[column].astype(str).str.contains(str(value), na=False)
            elif operator == 'startswith':
                return df[column].astype(str).str.startswith(str(value), na=False)
            elif operator == 'endswith':
                return df[column].astype(str).str.endswith(str(value), na=False)
            elif operator == 'is_empty':
                return df[column].isnull() | (df[column].astype(str) == '')
            elif operator == 'is_not_empty':
                return df[column].notnull() & (df[column].astype(str) != '')
            else:
                logging.warning('Unknown operator: %s', operator)
                return None
        except Exception as e:
            logging.error('Error applying condition %s %s %s: %s', column, operator, value, e)
            return None

    def _apply_column_filters(self, df, selected_columns, filter_mode):
        """应用列筛选"""
        available_columns = [col for col in selected_columns if col in df.columns]

        if filter_mode == 'include':
            # 只保留选中的列
            return df[available_columns] if available_columns else df
        else:  # exclude
            # 排除选中的列
            columns_to_keep = [col for col in df.columns if col not in selected_columns]
            return df[columns_to_keep]

    def process_filter(self, node_id, node_data, task="train"):
        """处理筛选节点 - 支持行列筛选，行优先"""
        logging.info('begin process_filter')

        # 获取配置参数
        config = node_data['config']
        filter_mode = config.get("filterMode", "include")  # include 或 exclude
        selected_columns = config.get("selectedColumns", [])  # 列筛选
        conditions = config.get("conditions", [])  # 行筛选条件

        pre_node_ids = node_data.get('prenodeId')
        logging.info('prenode id[%s]', pre_node_ids)

        if not pre_node_ids:
            logging.error('No prenode found for filter node')
            return {'error': 'No prenode found'}

        pre_node_label = self.get_label_byId(pre_node_ids[0])
        pre_node_type = self.get_type_byId(pre_node_ids[0])
        pre_node_data = self.results.get(pre_node_ids[0])

        if pre_node_data is None:
            logging.error('No data found for prenode id[%s]', pre_node_ids[0])
            return {'error': 'prenode id[%s] no data' % pre_node_ids[0]}

        ret_dict = self.get_pre_data(task, pre_node_type, pre_node_label, pre_node_data)
        logging.info("ret_dict keys:%s",ret_dict.keys() )
        # 处理每个 DataFrame
        for key in ret_dict:
            logging.info("iter %s",key)
            if isinstance(ret_dict[key], pd.DataFrame):
                df = ret_dict[key].copy()

                # 第一步：行筛选（优先）
                if conditions:
                    df = self._apply_row_filters(df, conditions)
                    logging.info('Applied %d row filter conditions, result shape: %s',len(conditions), df.shape)
                else:
                    logging.info("no sample conditions")
                # 第二步：列筛选
                if selected_columns:
                    df = self._apply_column_filters(df, selected_columns, filter_mode)
                    logging.info('Applied column filter (%s), result shape: %s',filter_mode, df.shape)
                else:
                    logging.info("no selected columns")
                logging.info("df:%s",df.head())
                ret_dict[key] = df
            else:
                logging.info("%s not dataframe"%key )

        logging.info('finish process_filter')
        return ret_dict

    def process_dataedit(self, node_id, node_data, task="train"):
        """
        处理DataEdit算子，支持四种操作：
        1. 列筛选
        2. 表达式列衍生
        3. 列合并
        4. 透视表生成
        """
        logging.info('开始处理DataEdit算子')

        try:
            # 获取前置节点数据
            pre_node_ids = node_data.get('prenodeId')
            logging.info(f'前置节点ID: {pre_node_ids}')

            if not pre_node_ids or len(pre_node_ids) == 0:
                logging.error('DataEdit算子缺少前置节点')
                return {'error': 'DataEdit算子缺少前置节点'}

            pre_node_data = self.results.get(pre_node_ids[0])
            if pre_node_data is None:
                logging.error(f'前置节点{pre_node_ids[0]}无数据')
                return {'error': f'前置节点{pre_node_ids[0]}无数据'}

            # 获取前置节点的元数据
            pre_node_label = self.get_label_byId(pre_node_ids[0])
            pre_node_type = self.get_type_byId(pre_node_ids[0])

            # 获取前置节点的DataFrame数据并创建深拷贝，避免修改原始数据
            ret_dict = self.get_pre_data(task, pre_node_type, pre_node_label, pre_node_data)

            # 对返回的每个数据集进行深拷贝
            copied_ret_dict = {}
            for key, value in ret_dict.items():
                if isinstance(value, pd.DataFrame):
                    # 创建DataFrame的深拷贝
                    copied_ret_dict[key] = value.copy(deep=True)
                else:
                    # 对其他类型数据也进行拷贝
                    copied_ret_dict[key] = copy.deepcopy(value)

            # 获取配置的操作类型和对应列配置
            config = node_data.get('config', {})
            selected_operation = config.get('selectedOperation')
            selected_columns = config.get('selectedColumns', [])  # 获取筛选的列

            # 先执行列筛选（无论后续操作如何，都先应用筛选）
            if selected_columns and isinstance(selected_columns, list) and len(selected_columns) > 0:
                self._process_column_filter(copied_ret_dict, selected_columns)
            else:
                logging.info('未配置列筛选或筛选列列表为空，将使用所有列')

            # 根据选择的操作类型进行处理
            if selected_operation == 'expression':
                self._process_expression_columns(copied_ret_dict, config.get('expressionColumns', []), task)
            elif selected_operation == 'merge':
                self._process_merge_columns(copied_ret_dict, config.get('mergeColumns', []), task)
            elif selected_operation == 'pivot':
                self._process_pivot_columns(copied_ret_dict, config.get('pivotColumns', []), task)
            else:
                logging.warning(f'未识别的操作类型: {selected_operation}，仅执行列筛选')

            logging.info('完成处理DataEdit算子')
            return copied_ret_dict

        except Exception as e:
            logging.error(f'DataEdit算子处理主流程出错: {str(e)}', exc_info=True)
            return {'error': f'DataEdit算子处理失败: {str(e)}'}

    def _process_column_filter(self, data_dict, selected_columns):
        """处理列筛选"""
        try:
            logging.info(f'开始执行列筛选，选中的列: {selected_columns}')

            if not isinstance(selected_columns, list) or len(selected_columns) == 0:
                logging.warning('列筛选配置无效，未执行筛选')
                return

            for data_key in data_dict:
                df = data_dict[data_key]
                if not isinstance(df, pd.DataFrame):
                    logging.warning(f'跳过非DataFrame数据的列筛选: {data_key}')
                    continue

                # 检查选中的列是否存在于DataFrame中
                valid_columns = [col for col in selected_columns if col in df.columns]
                missing_columns = [col for col in selected_columns if col not in df.columns]

                if missing_columns:
                    logging.warning(f'筛选列中存在不存在的列: {missing_columns}，已自动忽略')

                if not valid_columns:
                    logging.warning('没有有效的筛选列，将保留所有列')
                    continue

                # 执行筛选
                data_dict[data_key] = df[valid_columns].copy()
                logging.info(f'完成列筛选，保留 {len(valid_columns)} 列，移除 {len(df.columns) - len(valid_columns)} 列')

        except Exception as e:
            logging.error(f'执行列筛选时出错: {str(e)}', exc_info=True)

    def _process_expression_columns(self, data_dict, expression_columns, task):
        """处理表达式列衍生"""
        try:
            if not isinstance(expression_columns, list):
                expression_columns = [expression_columns]

            logging.info(f'开始处理表达式列: {[col["name"] for col in expression_columns if "name" in col]}')

            for data_key in data_dict:
                df = data_dict[data_key]
                if not isinstance(df, pd.DataFrame):
                    logging.warning(f'跳过非DataFrame数据的表达式列处理: {data_key}')
                    continue

                for expr_col in expression_columns:
                    # 基础验证
                    if not isinstance(expr_col, dict):
                        logging.warning(f'无效的表达式列配置格式: {expr_col}，跳过处理')
                        continue

                    col_name = expr_col.get('name')
                    expression = expr_col.get('expression')

                    if not col_name or not expression:
                        logging.warning(f'表达式列配置缺少名称或表达式: {expr_col}，跳过处理')
                        continue

                    try:
                        # 检查表达式中引用的列是否存在
                        referenced_cols = re.findall(r'\[(.*?)\]', expression)
                        missing_cols = [col for col in referenced_cols if col not in df.columns]

                        # 处理推理阶段可能不存在的列
                        if task != "train":
                            valid_cols = [col for col in referenced_cols if col in df.columns]
                            if not valid_cols and missing_cols:
                                logging.warning(f'推理阶段缺少列{missing_cols}，将{col_name}置为None')
                                df[col_name] = None
                                continue

                        # 检查是否有缺失的必要列
                        if missing_cols:
                            logging.error(f'列{missing_cols}不存在，无法计算表达式{expression}')
                            df[col_name] = None
                            continue

                        # 转换表达式为可执行的Python代码
                        python_expr = re.sub(r'\[(.*?)\]', r"df['\1']", expression)

                        # 安全执行表达式计算（限制可用变量）
                        allowed_vars = {
                            "df": df,
                            "pd": pd,
                            "np": pd.np  # 允许使用numpy
                        }

                        # 限制内置函数访问
                        safe_builtins = {
                            'abs': abs, 'min': min, 'max': max,
                            'sum': sum, 'len': len, 'round': round
                        }

                        # 执行表达式
                        df[col_name] = eval(
                            python_expr,
                            {"__builtins__": safe_builtins},
                            allowed_vars
                        )
                        logging.info(f'成功生成表达式列: {col_name}')

                    except SyntaxError as e:
                        logging.error(f'表达式{expression}语法错误: {str(e)}', exc_info=True)
                        df[col_name] = None
                    except NameError as e:
                        logging.error(f'表达式{expression}引用了未定义的变量: {str(e)}', exc_info=True)
                        df[col_name] = None
                    except Exception as e:
                        logging.error(f'计算表达式列{col_name}时出错: {str(e)}', exc_info=True)
                        df[col_name] = None

        except Exception as e:
            logging.error(f'处理表达式列时发生全局错误: {str(e)}', exc_info=True)

    def _process_merge_columns(self, data_dict, merge_columns, task):
        """处理列合并"""
        try:
            if not isinstance(merge_columns, list):
                merge_columns = [merge_columns]

            logging.info(f'开始处理合并列: {[col["name"] for col in merge_columns if "name" in col]}')

            for data_key in data_dict:
                df = data_dict[data_key]
                if not isinstance(df, pd.DataFrame):
                    logging.warning(f'跳过非DataFrame数据的合并列处理: {data_key}')
                    continue

                for merge_col in merge_columns:
                    # 基础验证
                    if not isinstance(merge_col, dict):
                        logging.warning(f'无效的合并列配置格式: {merge_col}，跳过处理')
                        continue

                    col_name = merge_col.get('name')
                    source_columns = merge_col.get('sourceColumns', [])
                    separator = merge_col.get('separator', '_')

                    # 验证配置有效性
                    if not col_name:
                        logging.warning('合并列缺少名称，跳过处理')
                        continue

                    if not isinstance(source_columns, list) or len(source_columns) < 2:
                        logging.warning(f'合并列{col_name}需要至少2个源列，当前配置: {source_columns}，跳过处理')
                        continue

                    try:
                        # 检查源列是否存在
                        missing_cols = [col for col in source_columns if col not in df.columns]

                        # 处理推理阶段可能不存在的列
                        if task != "train":
                            valid_cols = [col for col in source_columns if col in df.columns]
                            if len(valid_cols) < 2:
                                logging.warning(f'推理阶段有效列不足，将{col_name}置为None')
                                df[col_name] = None
                                continue

                        # 检查是否有缺失的必要列
                        if missing_cols:
                            logging.error(f'合并列{col_name}需要的源列{missing_cols}不存在')
                            df[col_name] = None
                            continue

                        # 执行列合并（将非空值转换为字符串后拼接）
                        df[col_name] = df[source_columns].apply(
                            lambda row: separator.join([str(val) for val in row if pd.notna(val)]),
                            axis=1
                        )
                        logging.info(f'成功生成合并列: {col_name}')

                    except Exception as e:
                        logging.error(f'合并列{col_name}处理出错: {str(e)}', exc_info=True)
                        df[col_name] = None

        except Exception as e:
            logging.error(f'处理合并列时发生全局错误: {str(e)}', exc_info=True)

    def _process_pivot_columns(self, data_dict, pivot_columns, task):
        """处理透视表生成"""
        try:
            if not isinstance(pivot_columns, list):
                pivot_columns = [pivot_columns]

            logging.info(f'开始处理透视表列: {[col["name"] for col in pivot_columns if "name" in col]}')

            for data_key in data_dict:
                df = data_dict[data_key]
                if not isinstance(df, pd.DataFrame):
                    logging.warning(f'跳过非DataFrame数据的透视表处理: {data_key}')
                    continue

                original_df = df.copy()  # 保存原始DataFrame用于异常恢复

                for pivot_col in pivot_columns:
                    # 基础验证
                    if not isinstance(pivot_col, dict):
                        logging.warning(f'无效的透视表配置格式: {pivot_col}，跳过处理')
                        continue

                    col_name = pivot_col.get('name')
                    index_columns = pivot_col.get('indexColumns', [])
                    value_columns = pivot_col.get('valueColumns', [])
                    agg_function = pivot_col.get('aggFunction', 'sum')

                    # 验证配置有效性
                    if not col_name:
                        logging.warning('透视表缺少名称，跳过处理')
                        continue

                    if not isinstance(index_columns, list) or len(index_columns) == 0:
                        logging.warning(f'透视表{col_name}需要至少1个索引列，当前配置为空，跳过处理')
                        continue

                    if not isinstance(value_columns, list) or len(value_columns) == 0:
                        logging.warning(f'透视表{col_name}需要至少1个数值列，当前配置为空，跳过处理')
                        continue

                    try:
                        # 检查索引列和数值列是否存在
                        missing_index_cols = [col for col in index_columns if col not in df.columns]
                        missing_value_cols = [col for col in value_columns if col not in df.columns]
                        missing_cols = missing_index_cols + missing_value_cols

                        # 处理推理阶段可能不存在的列
                        if task != "train":
                            valid_index_cols = [col for col in index_columns if col in df.columns]
                            valid_value_cols = [col for col in value_columns if col in df.columns]
                            if not valid_index_cols or not valid_value_cols:
                                logging.warning(f'推理阶段透视表{col_name}所需列不足，将相关结果置为None')
                                df[f'{col_name}_pivot_available'] = False
                                continue

                        # 检查是否有缺失的必要列
                        if missing_cols:
                            logging.error(f'透视表{col_name}需要的列{missing_cols}不存在')
                            df[f'{col_name}_pivot_available'] = False
                            continue

                        # 检查数值列是否为数值类型
                        for val_col in value_columns:
                            if not pd.api.types.is_numeric_dtype(df[val_col]):
                                logging.warning(f'透视表数值列{val_col}不是数值类型，尝试转换为数值')
                                # 尝试转换为数值类型
                                df[val_col] = pd.to_numeric(df[val_col], errors='coerce')
                                # 检查转换后是否还有有效值
                                if df[val_col].isna().all():
                                    logging.error(f'透视表数值列{val_col}无法转换为有效数值，跳过该透视表')
                                    df[f'{col_name}_pivot_available'] = False
                                    raise ValueError(f'数值列{val_col}无法转换为有效数值')

                        # 根据聚合函数选择对应的pandas方法
                        agg_method_map = {
                            'sum': 'sum',
                            'avg': 'mean',
                            'count': 'count',
                            'max': 'max',
                            'min': 'min'
                        }
                        agg_method = agg_method_map.get(agg_function, 'sum')

                        # 执行透视表操作
                        pivot_df = pd.pivot_table(
                            df,
                            index=index_columns,
                            values=value_columns,
                            aggfunc=agg_method
                        ).reset_index()

                        # 重命名透视表的列，避免与原始列冲突
                        rename_mapping = {col: f'{col}_{agg_method}_{col_name}' for col in value_columns}
                        pivot_df = pivot_df.rename(columns=rename_mapping)

                        # 将透视表结果合并回原始DataFrame
                        merged_df = pd.merge(df, pivot_df, on=index_columns, how='left')

                        # 更新当前DataFrame
                        df = merged_df
                        data_dict[data_key] = df
                        logging.info(f'成功生成透视表: {col_name}，使用聚合函数: {agg_function}')

                    except ValueError as e:
                        logging.error(f'透视表{col_name}参数错误: {str(e)}')
                        df[f'{col_name}_pivot_available'] = False
                    except Exception as e:
                        logging.error(f'生成透视表{col_name}时出错: {str(e)}', exc_info=True)
                        df[f'{col_name}_pivot_available'] = False
                        # 恢复到处理前的状态
                        data_dict[data_key] = original_df

        except Exception as e:
            logging.error(f'处理透视表时发生全局错误: {str(e)}', exc_info=True)

    # def process_eda(self, node_id,node_data,task="train"):
    #     # 处理EDA分析节点
    #     logging.info("begin process_eda")
    #     if task == "train":
    #         pre_node_ids = node_data.get("prenodeId")[0]
    #         tmp_file    = './%s.csv'%node_id
    #         file_path = os.path.join(self.project_dir, self.execute_time,node_id + '__' + "eda.html")
    #         if 'df' in self.results[pre_node_ids]:
    #             self.results[pre_node_ids]['df'].to_csv(tmp_file,index=False)
    #         elif "train_df" in self.results[pre_node_ids]:
    #             self.results[pre_node_ids]['train_df'].to_csv(tmp_file,index=False)
    #         else:
    #             logging.info("has no data")
    #         cmd_str = ''' python eda_ops.py --input_file %s --output %s '''%(tmp_file,file_path)
    #         logging.info( "cmd:%s",cmd_str )
    #         os.system(cmd_str)
    #     return {}
    def process_eda(self, node_id, node_data, task="train"):
        """处理EDA分析节点，自动选择python3或python执行"""
        logging.info("begin process_eda")

        # 1. 确定Python解释器路径
        python_cmd = self._get_python_executable()
        if not python_cmd:
            logging.error("Python interpreter not found (tried python3 and python)")
            return {"error": "Python interpreter not available"}

        # 2. 处理训练任务
        if task == "train":
            pre_node_ids = node_data.get("prenodeId")[0]
            # tmp_file = f'./{node_id}.csv'
            tmp_file = os.path.join(
                self.project_dir,
                self.execute_time,
                f"{node_id}.csv"
            )

            file_path = os.path.join(
                self.project_dir,
                self.execute_time,
                f"{node_id}__eda.html"
            )

            # 3. 获取数据并保存临时文件
            df = self._get_dataframe(pre_node_ids)
            if df is None:
                logging.error("No available data for EDA")
                return {"error": "No data available"}

            df.to_csv(tmp_file, index=False)

            # 4. 构建并执行命令
            cmd_str = f"{python_cmd} -m saddle.comm.eda_ops  --input_file {tmp_file} --output {file_path}"
            logging.info("Executing: %s", cmd_str)

            try:
                exit_code = os.system(cmd_str)
                if exit_code != 0:
                    logging.error("EDA failed with exit code: %d", exit_code)
                    return {"error": f"EDA process failed (code {exit_code})"}
            except Exception as e:
                logging.exception("EDA execution error")
                return {"error": str(e)}
            finally:
                # 清理临时文件
                if os.path.exists(tmp_file):
                    os.remove(tmp_file)

        return {"success": True, "output_path": file_path}

    def _get_python_executable(self):
        """获取可用的Python解释器路径"""
        for cmd in ["python3", "python"]:
            try:
                if subprocess.run([cmd, "--version"],
                                  check=True,
                                  stdout=subprocess.PIPE,
                                  stderr=subprocess.PIPE).returncode == 0:
                    return cmd
            except (subprocess.SubprocessError, FileNotFoundError):
                continue
        return None

    def _get_dataframe(self, pre_node_id):
        """安全获取DataFrame数据"""
        result = self.results.get(pre_node_id, {})
        # return result.get('df') or result.get('train_df')
        if 'df' in result:
            return result['df']
        elif "train_df" in result:
            return result['train_df']
        else:
            logging.info("has no data")
            return None

    def process_correlation_analysis(self, node_id,node_data,task="train"):
        # 处理相关性分析节点
        logging.info("begin process_correlation_analysis")
        if task=="train":
            pre_node_ids = node_data.get("prenodeId")[0]
            file_path =   os.path.join(self.project_dir, node_id + "__correlation_matrix.csv")
            corr_columns = node_data['config'].get("correlationColumns",[])
            if 'df' in self.results[pre_node_ids]:
                tmp_df = self.results[pre_node_ids]['df']
            elif "train_df" in self.results[ pre_node_ids ]:
                tmp_df = self.results[ pre_node_ids ]['train_df']
            else:
                logging.info('has no data')
            corr_matrix = tmp_df[ corr_columns ].corr( )
            corr_matrix.to_csv('%s'%file_path,index=True)
        logging.info("finish process_correlation_analysis")
        return


    def process_data_distribution(self, node_data, results):
        # 处理数据分布节点
        columns = node_data.get('columns')
        input_node_id = node_data.get('input_node_id')

        if input_node_id not in results:
            return {'error': 'Input node data not found'}

        df = results[input_node_id]

        if not columns or not all(col in df.columns for col in columns):
            return {'error': 'Invalid columns provided'}

        distribution_stats = df[columns].describe(include='all').to_dict()
        return distribution_stats


    def process_feature_importance(self, node_data, results):
        logging.info('begin process_feature_importance')
        # 处理特征重要性节点
        xcolumns = node_data['config'].get('featureImportanceXColumns')
        ycolumn  = node_data['config'].get('featureImportanceYColumn')
        pre_node_ids = node_data.get("prenodeId")[0]

        logging.info('%s %s %s',xcolumns,ycolumn,pre_node_ids)
        if pre_node_ids not in results:
            return {'error': 'Input node data not found'}

        if 'df' in self.results[pre_node_ids]:
            df = self.results[pre_node_ids]['df']
        elif "train_df" in self.results[pre_node_ids]:
            df = self.results[pre_node_ids]['train_df']
        else:
            logging.info('has no data')

        if not xcolumns or not all(col in df.columns for col in xcolumns):
            return {'error': 'Invalid columns provided'}

        # 这里假设使用随机森林来计算特征重要性
        X = df[xcolumns]
        y = df[ ycolumn  ]  # 假设目标列名为 'target'
        model = RandomForestRegressor()
        model.fit(X, y)
        importance = model.feature_importances_
        #importance_dict = dict(zip(columns, importance))

        # 将特征重要性组织成 DataFrame
        importance_df = pd.DataFrame({
            'Feature': xcolumns,
            'Importance': importance
        })

        # 按重要性排序（可选）
        importance_df = importance_df.sort_values(by='Importance', ascending=False)
        ret_ = { 'importance_df':importance_df }
        logging.info("importance_df:\n%s", importance_df)

        logging.info('finish process_feature_importance')
        return ret_



# def  predict(agent,input_dict):
#     for k in input_dict:
#         input_dict[k]= predict_data_trans(  input_dict[k],k)
#     ret_result = agent.execute(task='predict', sample_dict=input_dict)
#     exit_nodeid= agent.exit_node_ids
#     nodedata   = agent.get_nodedata_byid( exit_nodeid[0]  )
#     ycol       = nodedata[  ]
#     algos      = nodedata[  ]
#     algorithm = node_data.get('config').get('Algorithm')
#     return ret_result

# import joblib
# def load_ai_agent( user_id,proj_name ):
#     import unkops
#     client = unkops.Bucket(ini_conf['minioexplore']['url'], ini_conf['minioexplore']['access_key'], ini_conf['minioexplore']['secret_key'])
#     dest_file = './tmp.ckp'
#     client.download_file(bucket_name='mlapc', file='/projects/%s/%s/%s_engine.ckp' % (user_id, proj_name, proj_name), file_path=dest_file)
#     ai_agent = joblib.load(dest_file)
#     return ai_agent

global ai_agent
def predict_( agent,  data_dict  ):
    logging.info("begin predict_, agent.G.nodes():%s",agent.G.nodes() )
    for k in data_dict:
        if k not in agent.G.nodes():
            logging.info("nodes %s not in agent.nodes",k)
            continue
        node_type   = agent.get_type_byId( k )
        data_dict[k]= predict_data_trans(  data_dict[k],k,node_type)
    logging.info("Input data dict from trigger: %s,next sample_dict refers to data from the trigger.", str(data_dict))
    ret_result  = agent.execute( task='predict', sample_dict=data_dict )
    if isinstance(ret_result,str):
        return ret_result
    exit_nodeid = agent.exit_node_ids
    node_data   = agent.get_nodedata_byid(exit_nodeid[0])

    xcols       = node_data.get('config').get('xColumns')
    ycol        = node_data.get('config').get('yColumn')
    algorithm   = node_data.get('config').get('Algorithm')
    logging.info("run execute result keys:%s",ret_result.keys() )
    #logging.info("run execute result :%s", ret_result)
    pred_result = "no result"
    for iter_nodeid in exit_nodeid:
        if iter_nodeid not in agent.G.nodes:
            continue
        if iter_nodeid in ret_result:
            logging.info("node id[%s] ret_result keys:%s",iter_nodeid, ret_result[ iter_nodeid ].keys())

            if 'Image' in  ret_result[ iter_nodeid ]:
                pred_result = {
                    "image": f"data:image/png;base64,%s"%ret_result[iter_nodeid]['Image']  # 根据图片格式调整MIME类型
                }
            elif 'sample_df' in ret_result[ iter_nodeid ] or 'sample_data' in ret_result[ iter_nodeid ]:
                if 'sample_df' in ret_result[ iter_nodeid ]:
                    pred_result = ret_result[ iter_nodeid ]['sample_df']
                if 'sample_data' in ret_result[ iter_nodeid ]:
                    pred_result = ret_result[ iter_nodeid ]['sample_data']
                logging.info("type:%s",type(pred_result))
                if isinstance( pred_result,pandas.DataFrame ):
                    pred_result =pred_result.reset_index().to_json()
                else:
                    logging.info("not pandas dataframe")
            elif 'text_response'  in ret_result[ iter_nodeid ]:
                pred_result = { 'text': ret_result[ iter_nodeid ]['text_response']  }
            else:
                logging.info("unknonw, need to debug %s", ret_result[ iter_nodeid ] )

    # ret_dict  = ai_agent.predict( data_dict )
    return pred_result

import joblib
def set_args():
    import argparse
    parser = argparse.ArgumentParser()

    parser.add_argument('--task',   default='train',    type=str,required=False )
    parser.add_argument('--stdin',  action='store_true',default=False)  # 0.0.0.0
    parser.add_argument('--flowdata_file', default='',  type=str,required=False  ) #0.0.0.0
    parser.add_argument('--host', default='0.0.0.0', type=str, required=False)
    parser.add_argument('--root_dir', default="projects", type=str, required=False)
    parser.add_argument('--work_path',    default=None,     type=str,required=False )
    parser.add_argument('--execute_time',  default=None,       type=str,required=False )
    parser.add_argument('--load_file', default='projects\\test_diamonds_feature\\T25021211000\\test_diamonds_feature__engine.pkl', type=str, required=False) #for predict
    parser.add_argument('--port', default='9159', type=str, required=False)
    parser.add_argument('--api', default='/inference/', type=str, required=False)
    parser.add_argument('--infer_proccode', default=None, type=str, required=False)
    parser.add_argument('--start_node', default=None, type=str, required=False)
    args   = parser.parse_args()
    return args

def inference_task(  port,load_file='',host='0.0.0.0' ):
    from .utils import set_logging
    set_logging(log_dir='log',file_name='task_dispatch', mode='dev')
    logging.info('begin inference task')

    #ai_agent = joblib.load( args.load_file )
    from flask import Flask, request, jsonify, redirect, url_for, session, send_file
    app = Flask(__name__)
    app.logger.setLevel(logging.INFO)

    api =  args.api
    if not api.startswith('/'):api  = '/' + api
    if not api.endswith('/'):  api  = api + '/'

    @app.route('%s'%( api ), methods=['POST'] ) #   '/predict/'
    def run_inference( ):
        trigger_data =  request.get_json( )
        sample_df    =  pd.read_json( trigger_data['dataSource']  ) #pd.read_csv('dataSource1726409657775__df_train_bin.csv').head(3);
        logging.info("sample_df:%s",sample_df )
        result       = predict_( ai_agent,{"dataSource":sample_df})
        logging.info('result %s',result)
        return jsonify( {'message': 'Logged out successfully'} ), 200

    logging.info(' run port[%s] ',  port )
    try:
        #app.run(   debug=True, host='0.0.0.0', port=int(args.port ) )
        app.run( debug=True, host=host, port= port )
    except OSError as e:
        logging.info( f"启动 Flask 服务失败: {e}" )

import struct
import zlib
def send_frame(msg_type, data):
    # 构造帧
    frame = struct.pack('>II', msg_type, len(data)) + data
    frame += struct.pack('>I', zlib.crc32(frame))
    sys.stdout.buffer.write(frame)
    sys.stdout.buffer.flush()


# def read_frame():
#     """读取带帧头的二进制数据帧（类型+长度+数据+CRC）"""
#     try:
#         # 1. 读取帧头 (8字节: 4字节类型 + 4字节长度)
#         header = sys.stdin.buffer.read(8)
#         if len(header) < 8:
#             logging.error("⚠️ 帧头读取不完整 (got %d/8 bytes)", len(header))
#             raise EOFError("Incomplete frame header")
#
#         # 解析帧头
#         msg_type, length = struct.unpack('>II', header)
#         logging.debug("📥 收到帧头 | 类型:0x%08x | 数据长度:%d", msg_type, length)
#
#         # 2. 读取数据+CRC (length + 4字节)
#         payload_with_crc = sys.stdin.buffer.read(length + 4)
#         if len(payload_with_crc) < length + 4:
#             logging.error("⚠️ 数据读取不完整 (got %d/%d bytes)",
#                          len(payload_with_crc), length+4)
#             raise EOFError("Incomplete payload")
#
#         # 分离数据和CRC
#         data = payload_with_crc[:length]
#         received_crc = struct.unpack('>I', payload_with_crc[length:])[0]
#         logging.debug("📦 收到数据 | 长度:%d | CRC:0x%08x",
#                      len(data), received_crc)
#
#         # 3. CRC校验 (校验范围: header + data)
#         calculated_crc = zlib.crc32(header + data)
#         if calculated_crc != received_crc:
#             logging.error("❌ CRC校验失败 (计算值:0x%08x ≠ 接收值:0x%08x)",
#                           calculated_crc, received_crc)
#             raise ValueError("CRC mismatch")
#
#         logging.debug("✅ 帧接收成功 | 类型:0x%x | 数据:%s",
#                      msg_type, data[:100].hex() + ('...' if len(data)>100 else ''))
#         return msg_type, data
#
#     except Exception as e:
#         logging.exception("‼️ 读帧异常")
#         raise

# # === 增强版帧读取 ===
# def read_frame(timeout: float = 5.0) -> tuple[int, bytes]:
#     """
#     带完整调试的二进制帧读取
#     返回: (msg_type, payload)
#     异常: EOFError/ValueError/TimeoutError
#     """
#
#     def log_hex(data: bytes, prefix: str = ''):
#         """安全记录二进制数据"""
#         if len(data) > 100:
#             logging.debug(f"{prefix} HEX[{len(data)}]: {data[:100].hex()}...")
#         else:
#             logging.debug(f"{prefix} HEX[{len(data)}]: {data.hex()}")
#
#     try:
#         # 1. 检查输入流状态
#         if sys.stdin.buffer.closed:
#             print("⚠️ sys.stdin.buffer.closed ", file=sys.stderr)
#             logging.error("标准输入流已关闭！当前PID: %d", os.getpid())
#
#             raise IOError("stdin buffer already closed")
#
#             # 检查是否还有可读数据
#         if sys.stdin.buffer.peek(1) == b'':
#             logging.warning("输入流已到EOF")
#             print("⚠️ 输入流已到EOF ", file=sys.stderr)
#             raise EOFError("No more data")
#
#         if sys.stdin.closed:
#             print("⚠️ 标准输入已被关闭！", file=sys.stderr)
#             print(f"当前文件描述符状态: {os.fstat(0)}", file=sys.stderr)
#             raise IOError("stdin closed")
#
#             # 检查缓冲区
#         if not hasattr(sys.stdin, 'buffer'):
#             print("❌ 缺失二进制缓冲区！", file=sys.stderr)
#             print("建议启动时使用: python -u your_script.py", file=sys.stderr)
#             raise AttributeError("No buffer")
#
#         # 2. 等待数据到达（带超时）
#         logging.info("⌛ 等待输入数据...")
#         rlist, _, _ = select.select([sys.stdin], [], [], timeout)
#         if not rlist:
#             logging.error("⏰ 等待输入超时（%.1fs）", timeout)
#             raise TimeoutError("Input timeout")
#
#         # 3. 读取帧头
#         header = sys.stdin.buffer.read(8)
#         log_hex(header, "帧头")
#         if len(header) < 8:
#             logging.error("⚠️ 帧头不完整 (got %d/8 bytes)", len(header))
#             raise EOFError("Incomplete header")
#
#         # 4. 解析帧头
#         msg_type, length = struct.unpack('>II', header)
#         logging.info(f"📥 帧头解析: type=0x{msg_type:08x}, length={length}")
#
#         # 5. 读取数据+CRC
#         required_bytes = length + 4
#         payload_with_crc = sys.stdin.buffer.read(required_bytes)
#         log_hex(payload_with_crc, "原始数据+CRC")
#
#         if len(payload_with_crc) < required_bytes:
#             logging.error("⚠️ 数据不完整 (got %d/%d bytes)",
#                           len(payload_with_crc), required_bytes)
#             raise EOFError("Incomplete payload")
#
#         # 6. 分离数据
#         data = payload_with_crc[:length]
#         received_crc = struct.unpack('>I', payload_with_crc[length:])[0]
#         logging.debug(f"📦 数据分离: payload_len={len(data)}, crc=0x{received_crc:08x}")
#
#         # 7. CRC校验
#         calculated_crc = zlib.crc32(header + data)
#         if calculated_crc != received_crc:
#             logging.error(f"❌ CRC校验失败 (calc 0x{calculated_crc:08x} != recv 0x{received_crc:08x})")
#             raise ValueError("CRC mismatch")
#
#         logging.info(f"✅ 帧接收成功: type=0x{msg_type:x}, data_len={len(data)}")
#         return msg_type, data
#
#     except Exception as e:
#         logging.exception("‼️ 读帧异常", exc_info=True)
#         raise

def get_or_create_experiment(projectname):
    """获取实验ID，如果不存在则创建"""
    from mlflow.tracking import MlflowClient
    client = MlflowClient()

    # 尝试通过名称查询实验
    experiment = client.get_experiment_by_name(projectname)

    if experiment:
        # 实验已存在，返回其ID
        return experiment.experiment_id
    else:
        # 实验不存在，创建并返回新ID
        return client.create_experiment(name=projectname)
import sys
import os
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')
os.environ["MLFLOW_DISABLE_EMOJI"] = "true"
def main_logic( args ):
    if  args.task in ['train','explore','offline']:
        #json                    = json.loads()
        with open(args.flowdata_file, "r",encoding='utf8') as file:
            flow_data = json.load(file)
        projectname = flow_data.get("projectName")
        excuteType  = flow_data.get("excuteType", "train")  # inference
        from .utils import set_logging
        import os
        set_logging(log_dir=os.path.join(args.work_path, args.execute_time), file_name=projectname + "__run", mode='dev')  # run.log

        engine = WorkflowEngine(flow_data, args.root_dir, args.work_path, args.execute_time)

        use_mlflow = True if  flow_data.get( "mlflowTrackingUri" ) not in ["",None] else False
        dependency_dict ={}
        if use_mlflow:
            import mlflow
            mlflow.set_tracking_uri(  flow_data.get( "mlflowTrackingUri" ) )
            from mlflow.tracking import MlflowClient
            experiment_id = get_or_create_experiment(projectname)
            print(f"实验ID: {experiment_id}")

            # 创建并启动运行（关键修改）
            mlflow.set_experiment(experiment_id=experiment_id)
            # 使用 start_run 而不是直接创建 run
            current_time = datetime.datetime.now().strftime("%Y%m%d_%H%M")
            run_name = f"{projectname}_{current_time}"
            with mlflow.start_run(run_name=run_name, experiment_id=experiment_id ) as run:
                run_id = run.info.run_id
                print(f"运行ID: {run_id}")
                print(f"运行名称: {run_name}")

                tracking_uri = mlflow.get_tracking_uri()
                run_url = f"{tracking_uri}/#/experiments/{experiment_id}/runs/{run_id}"
                logging.info("mlflow_run_url[%s]", run_url)

                dependency_dict = {"use_mlflow": True, "run_id": run_id}

                os.environ["MLFLOW_RUN_ID"] = run_id
                dependency_dict = {"use_mlflow": True, "run_id" :run_id }

                try:
                    exe_status_result = engine.execute(task="train", dependency_dict=dependency_dict)
                    logging.info("exe_status_result:%s",exe_status_result)
                    # 自动标记运行状态（成功）
                    #mlflow.set_tag("mlflowrunStatus", "FINISHED")
                except Exception as e:
                    # 标记运行状态为失败
                    import traceback
                    #mlflow.set_tag(  "mlflow runStatus", "FAILED")
                    mlflow.log_param("error_message",     str(e)  )
                    import traceback
                    errorinfo = traceback.format_exc()
                    # exe_status_result['errorinfo'] = errorinfo
                    logging.info(" %s ", errorinfo )

                excute_r_f = 'statusresults.json'
                execute_path = os.path.join(engine.project_dir, engine.execute_time, excute_r_f)
                try:
                    with open(execute_path, "w") as f:  # joblib.dump( exe_status_result, execute_path)
                        json.dump(exe_status_result, f)
                except:
                    import traceback
                    logging.eror(" %s ", traceback.format_exc())


            if 'errorinfo' not in exe_status_result:
                excute_r_f = '%s__engine.pkl' % engine.projectname;
                execute_path = os.path.join(engine.project_dir, engine.execute_time, excute_r_f)
                joblib.dump(engine, execute_path)
        else:
            try:
                exe_status_result   = engine.execute(task="train", dependency_dict=dependency_dict )  #=use_mlflow
            except:
                logging.error("engine execute train task error")
                import traceback
                errorinfo           = traceback.format_exc()
                logging.error('######errorinfo,%s', errorinfo)
                #return {'errorinfo': errorinfo}
                exe_status_result['errorinfo'] = errorinfo
            excute_r_f = 'statusresults.json'
            execute_path = os.path.join(engine.project_dir, engine.execute_time, excute_r_f)
            with open(execute_path, "w") as f:  # joblib.dump( exe_status_result, execute_path)
                json.dump(exe_status_result, f)

            if 'errorinfo' not in exe_status_result:
                excute_r_f = '%s__engine.pkl' % engine.projectname;
                execute_path = os.path.join(engine.project_dir, engine.execute_time, excute_r_f)
                joblib.dump(engine, execute_path)

    elif args.task in [ 'predict','inference','inline' ]:
        if args.stdin==True:
            from .utils import set_logging
            import os
            if not (args.load_file.endswith('.pkl') and '__engine.pkl' in args.load_file):
                raise ValueError(f"Invalid load_file: {load_file}\nMust contain '__engine.pkl' and end with .pkl")
            log_dir  =  os.path.dirname(args.load_file)
            log_name =  os.path.basename(args.load_file).replace('__engine.pkl', '__inference')
            logging.info("log name %s",log_name)
            logging.info("log dir %s", log_dir)
            set_logging(log_dir=log_dir, file_name=log_name, mode='dev')
            logging.info("begin inference task")
            aiagent = joblib.load(args.load_file)
            logging.info("aiagent load succ")
            # 设置标准输入输出的编码
            # sys.stdin = io.TextIOWrapper(sys.stdin.buffer, encoding='utf-8', errors='replace')
            # sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
            # sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
            while True:
                try:
                    logging.info("wating data input")
                    line_bytes = sys.stdin.buffer.readline()
                    if not line_bytes:
                        break
                    line = line_bytes.decode('utf-8', errors='replace').strip()
                    if not line:
                        continue
                    if args.infer_proccode not in [None,""]:
                        import re
                        function_name = re.findall(r"^def +(.+?)\(", args.infer_proccode )[0]  #infer_config.get("processingCode")
                        exec(  args.infer_proccode , globals())  #infer_config
                        if not function_name:
                            return {'error': 'No function definition found in the code'}
                        dataSource = eval(function_name)(  line.strip() )

                        logging.info("dataSource:%s", dataSource)
                    else:
                        request = json.loads(line.strip())
                        dataSource = request["dataSource"]

                except:
                    import traceback
                    logging.exception("except")
                    logging.error("error %s",traceback.format_exc())
                    break

                for k in ['unknown','nomatter']:
                    if k in dataSource and len(dataSource.keys())==1:
                        if args.start_node in aiagent.G.nodes():
                            dataSource[args.start_node] = dataSource[k]
                        else:
                            for ii in aiagent.entry_node_ids:
                                dataSource[ii] = dataSource[k]

                try:
                    result = predict_(aiagent,dataSource)

                    result = json.dumps(result)+"EndbyPython\n"
                    if len(result)>50:
                        logging.info("predict,result:%s", result[:50])
                    else:
                        logging.info("predict,result:%s", result)
                    print(result) #sys.stdout.write
                    sys.stdout.flush()

                except Exception as e:
                    import traceback
                    logging.error("error %s", traceback.format_exc())
                    logging.info(f"Error processing request: {e}")
                    sys.stderr.write(f"Error processing request: {str(e)}\n")
                    sys.stderr.flush()
        else:
            inference_task( port=args.port, load_file=args.load_file,host=args.host)
    else:
        logging.info('unkwon arg.task[%s]',args.task )
    #engine  save


if __name__ == '__main__':
    args  = set_args()
    main_logic( args )
 # except EOFError:
                #     logging.info("🔌 连接终止 (EOF)")
                #     break
                # except ValueError as e:
                #     logging.error("‼️ 协议错误: %s", e)
                #     break
                # except Exception as e:

# else :
            #
            #     pred_result = ret_result[exit_nodeid[0]]['sample_df'][ycol]  # .to_json()
