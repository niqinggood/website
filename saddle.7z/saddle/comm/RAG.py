import os
import time
import uuid
import hashlib
import logging
import asyncio
from enum import Enum
from typing import List, Dict, Optional, Any, Tuple, Callable, Union
from pydantic import BaseModel, Field
from fastapi import FastAPI, HTTPException, File, UploadFile, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import uvicorn
from functools import lru_cache
import numpy as np
import jieba
import spacy
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import nltk
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
import html
import re
from datetime import datetime, timedelta
import json

# 确保下载必要的NLTK资源
try:
    nltk.data.find('corpora/stopwords')
except LookupError:
    nltk.download('stopwords')

try:
    nltk.data.find('corpora/wordnet')
except LookupError:
    nltk.download('wordnet')

# 加载Spacy模型（如果需要更高级的NLP处理）
try:
    nlp = spacy.load("en_core_web_sm")
except:
    try:
        import spacy.cli
        spacy.cli.download("en_core_web_sm")
        nlp = spacy.load("en_core_web_sm")
    except:
        nlp = None
        logging.warning("无法加载Spacy模型，部分NLP功能将受限")

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler("rag_system.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("RAGSystem")

# 全局缓存设置
CACHE_TTL = 3600  # 缓存过期时间（秒）
MAX_CACHE_SIZE = 1000  # 最大缓存条目数

class TaskStatus(str, Enum):
    READY = "ready"
    RUNNING = "running"
    SUCCESS = "success"
    FAILED = "failed"
    PAUSED = "paused"
    STOPPED = "stopped"
    QUEUED = "queued"
    CANCELLED = "cancelled"

class KnowledgeSourceType(str, Enum):
    PRELOADED = "preloaded"
    UPLOAD = "upload"
    URL = "url"
    DATABASE = "database"
    API = "api"
    GITHUB = "github"
    GOOGLE_DRIVE = "google_drive"
    AWS_S3 = "aws_s3"
    AZURE_BLOB = "azure_blob"
    SLACK = "slack"
    NOTION = "notion"
    CONFLUENCE = "confluence"

class RetrieverType(str, Enum):
    BM25 = "bm25"
    DENSE = "dense"
    HYBRID = "hybrid"

class KnowledgeSourceConfig(BaseModel):
    type: KnowledgeSourceType
    name: str
    config: Dict[str, Any] = Field(default_factory=dict)
    enabled: bool = True
    last_updated: Optional[datetime] = None

class RAGConfig(BaseModel):
    knowledge_sources: List[KnowledgeSourceConfig] = Field(default_factory=list)
    default_retriever: RetrieverType = RetrieverType.HYBRID
    default_model: str = "gpt-3.5-turbo"
    default_temperature: float = 0.7
    default_top_k: int = 3
    cache_enabled: bool = True
    batch_size: int = 32
    max_concurrent_tasks: int = 5

class DocumentMetadata(BaseModel):
    source: str
    title: Optional[str] = None
    url: Optional[str] = None
    author: Optional[str] = None
    date: Optional[str] = None
    language: Optional[str] = None
    length: Optional[int] = None
    file_type: Optional[str] = None
    additional_info: Dict[str, Any] = Field(default_factory=dict)

class DocumentChunk(BaseModel):
    id: str
    text: str
    metadata: DocumentMetadata
    tokens: int
    embedding: Optional[List[float]] = None
    keywords: List[str] = Field(default_factory=list)
    chunk_index: int = 0
    total_chunks: int = 1

class RetrievedDocument(BaseModel):
    id: str
    title: str
    content: str
    metadata: DocumentMetadata
    score: float
    chunk_id: Optional[str] = None

class RAGQuery(BaseModel):
    query_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    query: str
    retriever: RetrieverType = RetrieverType.HYBRID
    model: str = "gpt-3.5-turbo"
    temperature: float = 0.7
    top_k: int = 3
    score_threshold: float = 0.7
    max_tokens: int = 512
    system_message: Optional[str] = None
    prompt_template: Optional[str] = None
    postprocessing: List[str] = Field(default_factory=list)
    preprocessing: List[str] = Field(default_factory=list)
    fallback_strategy: str = "generate_anyway"
    enable_semantic_cache: bool = True
    enable_debug: bool = False
    task_priority: str = "medium"
    batch_id: Optional[str] = None

class RAGResponse(BaseModel):
    answer: str
    retrieved_documents: List[RetrievedDocument]
    metrics: Dict[str, Any] = Field(default_factory=dict)
    citations: List[Dict[str, str]] = Field(default_factory=list)
    generated_queries: List[str] = Field(default_factory=list)
    related_concepts: List[Dict[str, Any]] = Field(default_factory=list)
    confidence_score: float = 0.0
    warnings: List[str] = Field(default_factory=list)
    status: TaskStatus = TaskStatus.SUCCESS
    query_id: str
    processing_time: Optional[float] = None
    token_usage: Dict[str, int] = Field(default_factory=dict)

class CacheEntry(BaseModel):
    data: Any
    timestamp: float
    ttl: int = CACHE_TTL

class BatchQueryRequest(BaseModel):
    batch_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    queries: List[RAGQuery]
    priority: str = "medium"
    parallel: bool = False

class BatchResponse(BaseModel):
    batch_id: str
    status: TaskStatus
    total_queries: int
    completed: int = 0
    failed: int = 0
    results: List[RAGResponse] = Field(default_factory=list)
    started_at: datetime
    completed_at: Optional[datetime] = None

class DocumentProcessor:
    """文档处理工具类，负责文档清洗、分块和预处理"""
    
    _stop_words_en = set(stopwords.words('english'))
    _lemmatizer = WordNetLemmatizer()
    
    @staticmethod
    def clean_html(text: str) -> str:
        """移除HTML标签"""
        if not text:
            return ""
        clean = re.sub(r'<.*?>', '', text)
        return html.unescape(clean)
    
    @staticmethod
    def remove_special_chars(text: str) -> str:
        """移除特殊字符"""
        if not text:
            return ""
        # 保留字母、数字、常见标点和中文
        return re.sub(r'[^\w\s,.!?;:\'\"()\[\]{}<>@#$%^&*\-_+=~`|\\/《》，。！？；：‘’“”（）【】{}「」『』〈〉￥…—～、]', '', text)
    
    @staticmethod
    def split_documents(
        text: str, 
        chunk_size: int = 500, 
        overlap: float = 0.2,
        token_counter: Optional[Callable[[str], int]] = None
    ) -> List[str]:
        """
        将文档分割成块
        
        Args:
            text: 要分割的文本
            chunk_size: 块大小（token数）
            overlap: 块之间的重叠比例
            token_counter: 计算token数量的函数
        
        Returns:
            分割后的文本块列表
        """
        if not text:
            return []
            
        # 简单的token计数函数
        def default_token_counter(t: str) -> int:
            return len(t.split())
            
        token_counter = token_counter or default_token_counter
        overlap_size = int(chunk_size * overlap)
        
        # 先按句子分割
        sentences = re.split(r'(?<=[.!?;。！？；])\s+', text)
        chunks = []
        current_chunk = []
        current_length = 0
        
        for sentence in sentences:
            sentence_length = token_counter(sentence)
            
            # 如果句子长度超过块大小，单独作为一个块
            if sentence_length > chunk_size:
                if current_chunk:
                    chunks.append(' '.join(current_chunk))
                    current_chunk = []
                    current_length = 0
                
                # 将长句分割成更小的部分
                words = sentence.split()
                for i in range(0, len(words), chunk_size):
                    chunk_words = words[i:i+chunk_size]
                    chunks.append(' '.join(chunk_words))
                continue
            
            # 如果加入当前句子会超过块大小，保存当前块
            if current_length + sentence_length > chunk_size:
                chunks.append(' '.join(current_chunk))
                
                # 确定重叠部分
                overlap_tokens = 0
                new_chunk = []
                for sent in reversed(current_chunk):
                    sent_len = token_counter(sent)
                    if overlap_tokens + sent_len <= overlap_size:
                        new_chunk.insert(0, sent)
                        overlap_tokens += sent_len
                    else:
                        break
                
                current_chunk = new_chunk
                current_length = overlap_tokens
            
            current_chunk.append(sentence)
            current_length += sentence_length
        
        # 添加最后一个块
        if current_chunk:
            chunks.append(' '.join(current_chunk))
            
        return chunks
    
    @staticmethod
    def lowercase(text: str) -> str:
        """转换为小写"""
        return text.lower()
    
    @staticmethod
    def remove_stopwords(text: str, language: str = 'en') -> str:
        """移除停用词"""
        if language == 'en':
            words = text.split()
            filtered_words = [word for word in words if word.lower() not in DocumentProcessor._stop_words_en]
            return ' '.join(filtered_words)
        elif language == 'zh':
            # 简单的中文停用词处理，实际应用中应使用更完整的停用词表
            words = jieba.cut(text)
            stop_words_zh = {'的', '了', '在', '是', '我', '有', '和', '就', '不', '人', '都', '一', '一个', '上', '也', '很', '到', '说', '要', '去', '你', '会', '着', '没有', '看', '好', '自己', '这'}
            filtered_words = [word for word in words if word not in stop_words_zh]
            return ' '.join(filtered_words)
        return text
    
    @staticmethod
    def lemmatize(text: str) -> str:
        """词形还原"""
        words = text.split()
        lemmatized_words = [DocumentProcessor._lemmatizer.lemmatize(word) for word in words]
        return ' '.join(lemmatized_words)
    
    @staticmethod
    def extract_keywords(text: str, top_n: int = 5, language: str = 'en') -> List[str]:
        """提取关键词"""
        if not text:
            return []
            
        # 简单实现，实际应用中可使用更复杂的算法
        if language == 'en':
            words = text.lower().split()
            words = [word for word in words if word not in DocumentProcessor._stop_words_en and len(word) > 2]
        elif language == 'zh':
            words = list(jieba.cut(text))
            stop_words_zh = {'的', '了', '在', '是', '我', '有', '和', '就', '不', '人', '都', '一', '一个', '上', '也', '很', '到', '说', '要', '去', '你', '会', '着', '没有', '看', '好', '自己', '这'}
            words = [word for word in words if word not in stop_words_zh and len(word) > 1]
        else:
            words = text.split()
            
        # 计算词频
        word_freq = {}
        for word in words:
            word_freq[word] = word_freq.get(word, 0) + 1
            
        # 按词频排序并返回前n个
        sorted_words = sorted(word_freq.items(), key=lambda x: x[1], reverse=True)
        return [word for word, _ in sorted_words[:top_n]]
    
    @staticmethod
    def detect_language(text: str) -> str:
        """检测文本语言（简单实现）"""
        # 简单的语言检测，实际应用中应使用专门的语言检测库
        chinese_chars = re.findall(r'[\u4e00-\u9fff]', text)
        if len(chinese_chars) > len(text) * 0.3:
            return 'zh'
        return 'en'

class Retriever:
    """检索器，负责从文档集中检索相关文档"""
    
    def __init__(self, retriever_type: RetrieverType = RetrieverType.HYBRID):
        self.retriever_type = retriever_type
        self.documents = []
        self.vectorizer = TfidfVectorizer(stop_words='english')
        self.tfidf_matrix = None
        self.embeddings = []
        self.document_ids = []
        self.metadata = []
        self._is_fitted = False
        
        # 缓存最近的查询结果
        self.query_cache = {}
    
    def add_documents(self, documents: List[DocumentChunk]):
        """添加文档到检索器"""
        if not documents:
            return
            
        self.documents.extend(documents)
        self.document_ids.extend([doc.id for doc in documents])
        self.metadata.extend([doc.metadata for doc in documents])
        
        # 提取文本用于TF-IDF
        texts = [doc.text for doc in documents]
        
        # 更新TF-IDF矩阵
        if self.tfidf_matrix is None:
            self.tfidf_matrix = self.vectorizer.fit_transform(texts)
        else:
            self.tfidf_matrix = self.vectorizer.transform(texts)
        
        # 收集嵌入
        self.embeddings.extend([doc.embedding for doc in documents if doc.embedding])
        
        self._is_fitted = True
        
        # 日志
        logger.info(f"Added {len(documents)} documents to retriever. Total: {len(self.documents)}")
    
    def clear_documents(self):
        """清空所有文档"""
        self.documents = []
        self.tfidf_matrix = None
        self.embeddings = []
        self.document_ids = []
        self.metadata = []
        self._is_fitted = False
        logger.info("Cleared all documents from retriever")
    
    def _bm25_retrieve(self, query: str, top_k: int = 3, score_threshold: float = 0.0) -> List[Tuple[DocumentChunk, float]]:
        """使用BM25算法检索（简化实现）"""
        if not self._is_fitted or not self.documents:
            return []
            
        # 简单实现，实际应用中应使用专门的BM25库
        query_vec = self.vectorizer.transform([query])
        similarities = cosine_similarity(query_vec, self.tfidf_matrix).flatten()
        
        # 获取排序后的索引
        sorted_indices = similarities.argsort()[::-1]
        
        # 筛选结果
        results = []
        for i in sorted_indices[:top_k]:
            score = similarities[i]
            if score >= score_threshold:
                results.append((self.documents[i], score))
        
        return results
    
    def _dense_retrieve(self, query_embedding: List[float], top_k: int = 3, score_threshold: float = 0.0) -> List[Tuple[DocumentChunk, float]]:
        """使用密集向量检索"""
        if not self._is_fitted or not self.embeddings or not query_embedding:
            return []
            
        # 计算与所有文档的相似度
        similarities = []
        query_vec = np.array(query_embedding).reshape(1, -1)
        
        for embedding in self.embeddings:
            if embedding is None:
                similarities.append(0.0)
                continue
                
            doc_vec = np.array(embedding).reshape(1, -1)
            sim = cosine_similarity(query_vec, doc_vec)[0][0]
            similarities.append(sim)
        
        # 获取排序后的索引
        sorted_indices = np.argsort(similarities)[::-1]
        
        # 筛选结果
        results = []
        for i in sorted_indices[:top_k]:
            score = similarities[i]
            if score >= score_threshold:
                results.append((self.documents[i], score))
        
        return results
    
    def _hybrid_retrieve(self, query: str, query_embedding: List[float], top_k: int = 3, score_threshold: float = 0.0) -> List[Tuple[DocumentChunk, float]]:
        """混合检索：结合BM25和密集向量检索"""
        if not self._is_fitted or not self.documents:
            return []
            
        # 获取两种检索结果
        bm25_results = self._bm25_retrieve(query, top_k * 2, max(0.0, score_threshold - 0.1))
        dense_results = self._dense_retrieve(query_embedding, top_k * 2, max(0.0, score_threshold - 0.1)) if query_embedding else []
        
        # 构建结果字典，合并分数
        result_dict = {}
        for doc, score in bm25_results:
            if doc.id in result_dict:
                result_dict[doc.id] = (doc, (result_dict[doc.id][1] + score * 0.4) / 1.4)
            else:
                result_dict[doc.id] = (doc, score * 0.4)
        
        for doc, score in dense_results:
            if doc.id in result_dict:
                result_dict[doc.id] = (doc, (result_dict[doc.id][1] + score * 0.6) / 1.6)
            else:
                result_dict[doc.id] = (doc, score * 0.6)
        
        # 排序并返回结果
        sorted_results = sorted(result_dict.values(), key=lambda x: x[1], reverse=True)
        return [res for res in sorted_results[:top_k] if res[1] >= score_threshold]
    
    def retrieve(self, query: str, top_k: int = 3, score_threshold: float = 0.0, query_embedding: Optional[List[float]] = None) -> List[Tuple[DocumentChunk, float]]:
        """
        检索相关文档
        
        Args:
            query: 查询文本
            top_k: 返回的最大文档数
            score_threshold: 分数阈值
            query_embedding: 查询的嵌入向量（可选）
            
        Returns:
            文档和分数的元组列表
        """
        start_time = time.time()
        
        # 检查缓存
        cache_key = hashlib.md5(f"{query}:{top_k}:{score_threshold}:{self.retriever_type}".encode()).hexdigest()
        if cache_key in self.query_cache:
            cached = self.query_cache[cache_key]
            if time.time() - cached['timestamp'] < CACHE_TTL:
                logger.info(f"Using cached results for query: {query[:30]}...")
                return cached['results']
        
        # 根据检索器类型执行不同的检索策略
        if self.retriever_type == RetrieverType.BM25:
            results = self._bm25_retrieve(query, top_k, score_threshold)
        elif self.retriever_type == RetrieverType.DENSE:
            results = self._dense_retrieve(query_embedding, top_k, score_threshold) if query_embedding else []
        else:  # HYBRID
            results = self._hybrid_retrieve(query, query_embedding, top_k, score_threshold)
        
        # 更新缓存
        if len(self.query_cache) >= MAX_CACHE_SIZE:
            # 移除最旧的缓存条目
            oldest_key = min(self.query_cache.keys(), key=lambda k: self.query_cache[k]['timestamp'])
            del self.query_cache[oldest_key]
        
        self.query_cache[cache_key] = {
            'results': results,
            'timestamp': time.time()
        }
        
        logger.info(f"Retrieval completed in {time.time() - start_time:.4f}s. Found {len(results)} results.")
        return results

class LLMClient:
    """LLM客户端，负责与语言模型交互"""
    
    def __init__(self):
        self.model_cache = {}
        self.token_usage = {}
        self.last_request_time = 0
        self.rate_limit_delay = 1.0  # 限制请求频率（秒）
        
    async def generate(self, prompt: str, model: str = "gpt-3.5-turbo", temperature: float = 0.7, max_tokens: int = 512) -> Tuple[str, Dict[str, int]]:
        """
        生成文本
        
        Args:
            prompt: 提示文本
            model: 模型名称
            temperature: 温度参数
            max_tokens: 最大生成token数
            
        Returns:
            生成的文本和token使用情况
        """
        # 简单的速率限制
        current_time = time.time()
        if current_time - self.last_request_time < self.rate_limit_delay:
            await asyncio.sleep(self.rate_limit_delay - (current_time - self.last_request_time))
        self.last_request_time = time.time()
        
        # 检查缓存
        cache_key = hashlib.md5(f"{prompt}:{model}:{temperature}:{max_tokens}".encode()).hexdigest()
        if cache_key in self.model_cache:
            cached = self.model_cache[cache_key]
            if time.time() - cached['timestamp'] < CACHE_TTL:
                logger.info(f"Using cached LLM response for prompt: {prompt[:30]}...")
                return cached['response'], cached['token_usage']
        
        # 模拟LLM调用
        try:
            # 实际应用中这里应该调用真实的LLM API
            logger.info(f"Generating response with model {model}")
            
            # 模拟网络延迟
            await asyncio.sleep(0.5 + min(2.0, len(prompt) / 1000))
            
            # 生成模拟响应
            if "什么是RAG" in prompt or "RAG系统" in prompt:
                response = """RAG系统通过结合检索和生成两阶段工作。首先从知识库检索相关文档，然后基于这些文档生成最终回答。
                
检索增强生成(RAG)是一种将大型语言模型(LLM)与外部知识源相结合的技术，通过检索相关信息来增强LLM的回答能力，特别适用于需要最新知识或特定领域专业知识的场景。

主要优势包括:
1. 可以利用外部知识源，不受限于模型训练数据
2. 可以动态更新知识库而无需重新训练模型
3. 可以提供引用来源，增加回答可信度"""
            else:
                response = f"这是针对查询 '{prompt[:50]}...' 的模拟回答。在实际应用中，这里会返回由 {model} 生成的真实响应。"
            
            # 模拟token使用情况
            prompt_tokens = len(prompt.split())
            completion_tokens = len(response.split())
            token_usage = {
                "prompt_tokens": prompt_tokens,
                "completion_tokens": completion_tokens,
                "total_tokens": prompt_tokens + completion_tokens
            }
            
            # 更新缓存
            if len(self.model_cache) >= MAX_CACHE_SIZE:
                # 移除最旧的缓存条目
                oldest_key = min(self.model_cache.keys(), key=lambda k: self.model_cache[k]['timestamp'])
                del self.model_cache[oldest_key]
            
            self.model_cache[cache_key] = {
                'response': response,
                'token_usage': token_usage,
                'timestamp': time.time()
            }
            
            # 更新token使用统计
            self.token_usage[model] = self.token_usage.get(model, {
                "prompt_tokens": 0,
                "completion_tokens": 0,
                "total_tokens": 0,
                "requests": 0
            })
            self.token_usage[model]["prompt_tokens"] += token_usage["prompt_tokens"]
            self.token_usage[model]["completion_tokens"] += token_usage["completion_tokens"]
            self.token_usage[model]["total_tokens"] += token_usage["total_tokens"]
            self.token_usage[model]["requests"] += 1
            
            return response, token_usage
            
        except Exception as e:
            logger.error(f"LLM generation failed: {str(e)}")
            raise
    
    async def embed(self, text: str, model: str = "text-embedding-ada-002") -> List[float]:
        """生成文本嵌入"""
        # 检查缓存
        cache_key = hashlib.md5(f"embed:{text}:{model}".encode()).hexdigest()
        if cache_key in self.model_cache:
            cached = self.model_cache[cache_key]
            if time.time() - cached['timestamp'] < CACHE_TTL:
                return cached['response']
        
        # 模拟嵌入生成
        try:
            logger.info(f"Generating embedding for text: {text[:30]}...")
            
            # 模拟网络延迟
            await asyncio.sleep(0.3 + min(1.0, len(text) / 2000))
            
            # 生成随机向量作为模拟嵌入
            embedding = list(np.random.rand(384))  # 384维向量
            
            # 更新缓存
            if len(self.model_cache) >= MAX_CACHE_SIZE:
                oldest_key = min(self.model_cache.keys(), key=lambda k: self.model_cache[k]['timestamp'])
                del self.model_cache[oldest_key]
            
            self.model_cache[cache_key] = {
                'response': embedding,
                'timestamp': time.time()
            }
            
            return embedding
            
        except Exception as e:
            logger.error(f"Embedding generation failed: {str(e)}")
            raise
    
    def get_token_usage(self) -> Dict[str, Any]:
        """获取token使用统计"""
        return self.token_usage.copy()

class KnowledgeBaseManager:
    """知识库管理器，负责管理不同来源的知识"""
    
    def __init__(self):
        self.knowledge_sources = {}
        self.documents = {}  # 按知识源ID组织的文档
        self.embeddings_enabled = True
        self.chunk_size = 500
        self.chunk_overlap = 0.2
        
        # 初始化预处理工具
        self.processor = DocumentProcessor()
        
        # 确保上传目录存在
        os.makedirs("uploads", exist_ok=True)
        
    def add_knowledge_source(self, config: KnowledgeSourceConfig) -> str:
        """添加知识源"""
        source_id = str(uuid.uuid4())
        self.knowledge_sources[source_id] = config
        self.documents[source_id] = []
        logger.info(f"Added knowledge source: {config.name} (ID: {source_id})")
        return source_id
    
    def remove_knowledge_source(self, source_id: str) -> bool:
        """移除知识源"""
        if source_id in self.knowledge_sources:
            del self.knowledge_sources[source_id]
            del self.documents[source_id]
            logger.info(f"Removed knowledge source: {source_id}")
            return True
        return False
    
    def get_knowledge_sources(self) -> Dict[str, KnowledgeSourceConfig]:
        """获取所有知识源"""
        return self.knowledge_sources.copy()
    
    async def load_knowledge_source(self, source_id: str, llm_client: LLMClient) -> int:
        """加载知识源内容"""
        if source_id not in self.knowledge_sources:
            raise ValueError(f"Knowledge source {source_id} not found")
            
        source = self.knowledge_sources[source_id]
        logger.info(f"Loading knowledge source: {source.name} (Type: {source.type})")
        
        # 清空现有文档
        self.documents[source_id] = []
        
        try:
            # 根据知识源类型加载文档
            if source.type == KnowledgeSourceType.PRELOADED:
                documents = await self._load_preloaded(source.config.get('preloaded_name', 'default'))
            elif source.type == KnowledgeSourceType.UPLOAD:
                documents = await self._load_uploaded(source.config.get('files', []))
            elif source.type == KnowledgeSourceType.URL:
                documents = await self._load_url(source.config.get('url', ''))
            elif source.type == KnowledgeSourceType.DATABASE:
                documents = await self._load_database(source.config)
            elif source.type == KnowledgeSourceType.API:
                documents = await self._load_api(source.config)
            else:
                # 其他类型的知识源处理
                documents = []
                logger.warning(f"Unsupported knowledge source type: {source.type}")
            
            # 处理文档（分块、预处理等）
            processed_chunks = []
            for doc in documents:
                chunks = self._process_document(doc, source_id)
                processed_chunks.extend(chunks)
            
            # 生成嵌入（如果启用）
            if self.embeddings_enabled and processed_chunks:
                # 批量生成嵌入
                for i in range(0, len(processed_chunks), self.chunk_size):
                    batch = processed_chunks[i:i+self.chunk_size]
                    texts = [chunk.text for chunk in batch]
                    
                    # 并行生成嵌入（模拟）
                    embeddings = await asyncio.gather(
                        *[llm_client.embed(text) for text in texts]
                    )
                    
                    for j, chunk in enumerate(batch):
                        chunk.embedding = embeddings[j]
            
            # 保存处理后的文档块
            self.documents[source_id] = processed_chunks
            
            # 更新最后更新时间
            self.knowledge_sources[source_id] = source.copy(update={
                "last_updated": datetime.now()
            })
            
            logger.info(f"Successfully loaded {len(processed_chunks)} chunks from {source.name}")
            return len(processed_chunks)
            
        except Exception as e:
            logger.error(f"Failed to load knowledge source {source_id}: {str(e)}")
            raise
    
    async def _load_preloaded(self, name: str) -> List[Dict[str, Any]]:
        """加载预加载的知识库"""
        # 模拟加载预加载知识库
        await asyncio.sleep(1.0)
        
        # 为演示创建一些模拟文档
        if name == "default":
            return [
                {
                    "text": "检索增强生成(RAG)是一种将大型语言模型与外部知识源相结合的技术。RAG通过检索相关信息来增强LLM的回答能力，特别适用于需要最新知识或特定领域专业知识的场景。",
                    "metadata": {
                        "source": "preloaded",
                        "title": "RAG技术简介",
                        "author": "AI Research Team",
                        "date": "2023-01-15"
                    }
                },
                {
                    "text": "RAG系统通常包含三个主要组件：文档加载器、检索器和生成器。文档加载器负责从各种来源获取和处理文档，检索器负责根据查询找到相关文档，生成器则基于检索到的文档生成回答。",
                    "metadata": {
                        "source": "preloaded",
                        "title": "RAG系统组件",
                        "author": "AI Research Team",
                        "date": "2023-02-10"
                    }
                },
                {
                    "text": "与传统的微调方法相比，RAG具有明显优势：无需重新训练模型即可更新知识，能够提供答案的来源引用，降低了幻觉风险，并且可以处理超出模型训练数据时间范围的知识。",
                    "metadata": {
                        "source": "preloaded",
                        "title": "RAG与传统方法的比较",
                        "author": "AI Research Team",
                        "date": "2023-03-05"
                    }
                }
            ]
        elif name == "tech":
            return [
                {
                    "text": "向量数据库是RAG系统的关键组件，用于高效存储和检索文档嵌入。常见的向量数据库包括Pinecone、Weaviate、Milvus和Qdrant等。",
                    "metadata": {
                        "source": "preloaded",
                        "title": "RAG中的向量数据库",
                        "author": "Tech Team",
                        "date": "2023-04-20"
                    }
                }
            ]
        else:
            return [
                {
                    "text": f"这是{name}预加载知识库中的示例文档。",
                    "metadata": {
                        "source": "preloaded",
                        "title": f"{name}知识库示例",
                        "date": "2023-01-01"
                    }
                }
            ]
    
    async def _load_uploaded(self, files: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """加载上传的文档"""
        # 模拟加载上传的文档
        documents = []
        
        for file in files:
            await asyncio.sleep(0.5)  # 模拟文件读取延迟
            
            # 简单的文件内容模拟
            if file.get('type', '').startswith('text/') or file.get('name', '').endswith(('.txt', '.md')):
                content = f"这是上传文件 {file.get('name')} 中的内容。该文件大小为 {file.get('size')} 字节。"
            elif file.get('name', '').endswith('.pdf'):
                content = f"这是PDF文件 {file.get('name')} 中的内容。PDF包含多页文档，这里是提取的文本内容。"
            else:
                content = f"这是上传文件 {file.get('name')} 的内容摘要。"
            
            documents.append({
                "text": content,
                "metadata": {
                    "source": "upload",
                    "title": file.get('name'),
                    "file_type": file.get('type'),
                    "size": file.get('size'),
                    "upload_date": datetime.now().isoformat()
                }
            })
        
        return documents
    
    async def _load_url(self, url: str) -> List[Dict[str, Any]]:
        """从URL加载内容"""
        # 模拟URL内容加载
        await asyncio.sleep(1.5)  # 模拟网络请求延迟
        
        return [
            {
                "text": f"这是从URL {url} 提取的内容。网页包含有关RAG技术的信息，包括其工作原理和应用场景。",
                "metadata": {
                    "source": "url",
                    "title": f"从{url}获取的内容",
                    "url": url,
                    "fetch_date": datetime.now().isoformat()
                }
            }
        ]
    
    async def _load_database(self, config: Dict[str, Any]) -> List[Dict[str, Any]]:
        """从数据库加载内容"""
        # 模拟数据库内容加载
        await asyncio.sleep(2.0)  # 模拟数据库查询延迟
        
        return [
            {
                "text": "这是从数据库查询获取的记录。包含产品信息、价格和库存数据。",
                "metadata": {
                    "source": "database",
                    "title": "数据库查询结果",
                    "query": config.get('query', 'SELECT * FROM products LIMIT 10'),
                    "record_count": 10,
                    "fetch_date": datetime.now().isoformat()
                }
            }
        ]
    
    async def _load_api(self, config: Dict[str, Any]) -> List[Dict[str, Any]]:
        """从API加载内容"""
        # 模拟API内容加载
        await asyncio.sleep(1.8)  # 模拟API请求延迟
        
        return [
            {
                "text": f"这是从API {config.get('api_endpoint')} 获取的响应数据。包含最新的市场趋势和分析报告。",
                "metadata": {
                    "source": "api",
                    "title": "API响应数据",
                    "endpoint": config.get('api_endpoint'),
                    "fetch_date": datetime.now().isoformat()
                }
            }
        ]
    
    def _process_document(self, doc: Dict[str, Any], source_id: str) -> List[DocumentChunk]:
        """处理文档，包括清洗、分块等"""
        text = doc.get('text', '')
        metadata = doc.get('metadata', {})
        
        # 检测语言
        language = self.processor.detect_language(text)
        
        # 预处理文本
        processed_text = self.processor.clean_html(text)
        processed_text = self.processor.remove_special_chars(processed_text)
        
        # 分块
        chunks = self.processor.split_documents(
            processed_text,
            chunk_size=self.chunk_size,
            overlap=self.chunk_overlap
        )
        
        # 处理每个块
        document_chunks = []
        for i, chunk in enumerate(chunks):
            # 提取关键词
            keywords = self.processor.extract_keywords(chunk, language=language)
            
            # 创建文档块
            chunk_id = str(uuid.uuid4())
            document_chunk = DocumentChunk(
                id=chunk_id,
                text=chunk,
                metadata=DocumentMetadata(
                    source=metadata.get('source', 'unknown'),
                    title=metadata.get('title'),
                    url=metadata.get('url'),
                    author=metadata.get('author'),
                    date=metadata.get('date'),
                    language=language,
                    length=len(chunk),
                    file_type=metadata.get('file_type'),
                    additional_info={
                        "source_id": source_id,
                        **metadata.get('additional_info', {})
                    }
                ),
                tokens=len(chunk.split()),
                keywords=keywords,
                chunk_index=i,
                total_chunks=len(chunks)
            )
            
            document_chunks.append(document_chunk)
        
        return document_chunks
    
    def get_all_documents(self, source_ids: Optional[List[str]] = None) -> List[DocumentChunk]:
        """获取所有文档（可按知识源筛选）"""
        if source_ids:
            documents = []
            for source_id in source_ids:
                if source_id in self.documents:
                    documents.extend(self.documents[source_id])
            return documents
        else:
            return [doc for docs in self.documents.values() for doc in docs]
    
    def update_settings(self,** kwargs):
        """更新知识库设置"""
        if 'embeddings_enabled' in kwargs:
            self.embeddings_enabled = kwargs['embeddings_enabled']
        if 'chunk_size' in kwargs:
            self.chunk_size = kwargs['chunk_size']
        if 'chunk_overlap' in kwargs:
            self.chunk_overlap = kwargs['chunk_overlap']

class RAGGenerator:
    """检索增强生成器，协调检索和生成过程"""
    
    def __init__(self, config: RAGConfig):
        self.config = config
        self.retrievers = {
            RetrieverType.BM25: Retriever(RetrieverType.BM25),
            RetrieverType.DENSE: Retriever(RetrieverType.DENSE),
            RetrieverType.HYBRID: Retriever(RetrieverType.HYBRID)
        }
        self.llm_client = LLMClient()
        self.kb_manager = KnowledgeBaseManager()
        self.cache = {}  # 语义缓存
        self.task_queue = asyncio.Queue()
        self.running_tasks = 0
        self.batch_jobs = {}
        
        # 初始化知识源
        for source_config in config.knowledge_sources:
            self.kb_manager.add_knowledge_source(source_config)
        
        # 启动任务处理器
        asyncio.create_task(self.process_task_queue())
    
    async def process_task_queue(self):
        """处理任务队列"""
        while True:
            try:
                # 等待任务
                task = await self.task_queue.get()
                self.running_tasks += 1
                
                # 执行任务
                if task['type'] == 'query':
                    try:
                        result = await self.query(task['query'])
                        task['callback'](result)
                    except Exception as e:
                        error_result = RAGResponse(
                            answer=f"处理查询时出错: {str(e)}",
                            retrieved_documents=[],
                            metrics={},
                            query_id=task['query'].query_id,
                            status=TaskStatus.FAILED,
                            warnings=[str(e)]
                        )
                        task['callback'](error_result)
                elif task['type'] == 'batch':
                    try:
                        result = await self.process_batch(task['batch_request'])
                        task['callback'](result)
                    except Exception as e:
                        error_result = BatchResponse(
                            batch_id=task['batch_request'].batch_id,
                            status=TaskStatus.FAILED,
                            total_queries=len(task['batch_request'].queries),
                            started_at=datetime.now()
                        )
                        task['callback'](error_result)
                
            except Exception as e:
                logger.error(f"Error processing task: {str(e)}")
            finally:
                self.running_tasks -= 1
                self.task_queue.task_done()
    
    def add_to_queue(self, task_type: str, task_data: Any, callback: Callable):
        """添加任务到队列"""
        self.task_queue.put_nowait({
            'type': task_type,
            'data': task_data,
            'callback': callback
        })
    
    async def add_knowledge_source(self, config: KnowledgeSourceConfig) -> str:
        """添加知识源并加载"""
        source_id = self.kb_manager.add_knowledge_source(config)
        await self.kb_manager.load_knowledge_source(source_id, self.llm_client)
        
        # 更新检索器
        documents = self.kb_manager.get_all_documents()
        for retriever in self.retrievers.values():
            retriever.add_documents(documents)
            
        return source_id
    
    async def generate_prompt(self, query: str, context: List[str], template: Optional[str] = None) -> str:
        """生成提示词"""
        if template:
            # 使用自定义模板
            return template.replace("{context}", "\n\n".join(context)).replace("{question}", query)
        
        # 默认模板
        prompt = f"""基于以下参考文档，回答问题：
        
参考文档:
{chr(10).join([f"[{i+1}] {doc}" for i, doc in enumerate(context)])}

问题:
{query}

回答时请遵循以下要求:
1. 仅使用参考文档中的信息
2. 回答要准确、简洁、清晰
3. 如果参考文档中没有相关信息，请明确说明
4. 在回答的最后，注明使用了哪些参考文档（使用上面标记的编号）
"""
        return prompt
    
    async def postprocess_answer(self, answer: str, retrieved_docs: List[RetrievedDocument], operations: List[str]) -> str:
        """后处理回答"""
        processed_answer = answer
        
        # 添加引用
        if "add_citations" in operations and retrieved_docs:
            citations = "\n\n参考文献:\n"
            for i, doc in enumerate(retrieved_docs):
                citations += f"{i+1}. {doc.title}\n"
                if doc.metadata.url:
                    citations += f"   URL: {doc.metadata.url}\n"
            processed_answer += citations
        
        # 格式化响应
        if "format_response" in operations:
            processed_answer = processed_answer.replace("\n", "\n\n").strip()
            
        # 其他后处理操作可以在这里添加
        
        return processed_answer
    
    async def query(self, rag_query: RAGQuery) -> RAGResponse:
        """处理RAG查询"""
        query_id = rag_query.query_id
        logger.info(f"Processing RAG query {query_id}")
        
        start_time = time.time()
        metrics = {
            "retrieval_time": 0,
            "generation_time": 0,
            "total_time": 0,
            "tokens_used": 0,
            "estimated_cost": 0,
            "documents_processed": 0,
            "chunks_generated": 0,
            "api_calls": 0,
            "cache_hits": 0
        }
        
        try:
            # 1. 检索阶段
            retrieval_start = time.time()
            
            # 检查缓存
            cache_key = hashlib.md5(rag_query.query.encode()).hexdigest()
            if rag_query.enable_semantic_cache and cache_key in self.cache:
                cached_data = self.cache[cache_key]
                if time.time() - cached_data['timestamp'] < CACHE_TTL:
                    metrics["cache_hits"] = 1
                    logger.info(f"Using cached results for query: {rag_query.query}")
                    
                    # 更新指标
                    metrics["total_time"] = time.time() - start_time
                    
                    return RAGResponse(
                        answer=cached_data['answer'],
                        retrieved_documents=cached_data['retrieved_docs'],
                        metrics={** metrics, **cached_data['metrics']},
                        citations=cached_data['citations'],
                        generated_queries=cached_data['generated_queries'],
                        related_concepts=cached_data['related_concepts'],
                        confidence_score=cached_data['confidence_score'],
                        warnings=cached_data['warnings'],
                        query_id=query_id,
                        processing_time=metrics["total_time"]
                    )
            
            # 获取检索器
            retriever = self.retrievers.get(rag_query.retriever, self.retrievers[self.config.default_retriever])
            
            # 获取查询嵌入（如果需要）
            query_embedding = None
            if rag_query.retriever in (RetrieverType.DENSE, RetrieverType.HYBRID):
                query_embedding = await self.llm_client.embed(rag_query.query)
                metrics["api_calls"] += 1
            
            # 检索文档
            retrieved_pairs = retriever.retrieve(
                rag_query.query,
                top_k=rag_query.top_k,
                score_threshold=rag_query.score_threshold,
                query_embedding=query_embedding
            )
            
            # 转换为RetrievedDocument对象
            retrieved_docs = [
                RetrievedDocument(
                    id=doc.id,
                    title=doc.metadata.title or f"文档 {i+1}",
                    content=doc.text,
                    metadata=doc.metadata,
                    score=score,
                    chunk_id=doc.id
                )
                for i, (doc, score) in enumerate(retrieved_pairs)
            ]
            
            metrics["retrieval_time"] = time.time() - retrieval_start
            metrics["documents_processed"] = len(retrieved_docs)
            
            # 处理没有检索到文档的情况
            if not retrieved_docs:
                if rag_query.fallback_strategy == "inform_user":
                    return RAGResponse(
                        answer="抱歉，没有找到相关信息。",
                        retrieved_documents=[],
                        metrics=metrics,
                        citations=[],
                        generated_queries=[],
                        related_concepts=[],
                        confidence_score=0,
                        warnings=["没有检索到相关文档"],
                        query_id=query_id,
                        processing_time=time.time() - start_time
                    )
                elif rag_query.fallback_strategy == "use_general_knowledge":
                    # 使用通用知识回答，不提供来源
                    pass
                # 否则，继续生成回答
            
            # 2. 生成阶段
            generation_start = time.time()
            
            # 准备上下文
            context = [doc.content for doc in retrieved_docs]
            
            # 生成提示词
            prompt = await self.generate_prompt(
                rag_query.query,
                context,
                rag_query.prompt_template
            )
            
            # 添加系统消息（如果有）
            full_prompt = prompt
            if rag_query.system_message:
                full_prompt = f"系统消息: {rag_query.system_message}\n\n{prompt}"
            
            # 调用LLM生成回答
            answer, token_usage = await self.llm_client.generate(
                full_prompt,
                model=rag_query.model,
                temperature=rag_query.temperature,
                max_tokens=rag_query.max_tokens
            )
            
            metrics["api_calls"] += 1
            metrics["tokens_used"] = token_usage["total_tokens"]
            metrics["estimated_cost"] = metrics["tokens_used"] * 0.000002  # 模拟成本
            
            # 后处理
            processed_answer = await self.postprocess_answer(
                answer,
                retrieved_docs,
                rag_query.postprocessing
            )
            
            metrics["generation_time"] = time.time() - generation_start
            
            # 3. 生成相关查询和概念（模拟）
            related_queries = [
                f"{rag_query.query}的工作原理是什么?",
                f"{rag_query.query}有哪些应用场景?",
                f"{rag_query.query}的优势和局限是什么?",
                f"{rag_query.query}与其他技术的区别?",
                f"如何实现{rag_query.query}?"
            ]
            
            # 提取关键词作为相关概念
            all_context = " ".join(context) + " " + rag_query.query
            keywords = DocumentProcessor.extract_keywords(all_context, top_n=5)
            related_concepts = [
                {"name": keyword, "score": round(0.8 + i * 0.04, 2)}
                for i, keyword in enumerate(keywords)
            ]
            
            # 4. 计算置信度分数（简单实现）
            confidence_score = sum(doc.score for doc in retrieved_docs) / len(retrieved_docs) if retrieved_docs else 0.5
            confidence_score = round(confidence_score, 2)
            
            # 5. 准备响应
            metrics["total_time"] = time.time() - start_time
            
            # 准备引用信息
            citations = [
                {"id": doc.id, "title": doc.title, "url": doc.metadata.url or ""}
                for doc in retrieved_docs
            ]
            
            # 存入缓存
            if rag_query.enable_semantic_cache:
                # 限制缓存大小
                if len(self.cache) >= MAX_CACHE_SIZE:
                    # 移除最旧的缓存
                    oldest_key = min(self.cache.keys(), key=lambda k: self.cache[k]['timestamp'])
                    del self.cache[oldest_key]
                
                self.cache[cache_key] = {
                    'answer': processed_answer,
                    'retrieved_docs': retrieved_docs,
                    'metrics': metrics,
                    'citations': citations,
                    'generated_queries': related_queries,
                    'related_concepts': related_concepts,
                    'confidence_score': confidence_score,
                    'warnings': [],
                    'timestamp': time.time()
                }
            
            return RAGResponse(
                answer=processed_answer,
                retrieved_documents=retrieved_docs,
                metrics=metrics,
                citations=citations,
                generated_queries=related_queries,
                related_concepts=related_concepts,
                confidence_score=confidence_score,
                warnings=["部分内容基于模拟数据"] if rag_query.enable_debug else [],
                query_id=query_id,
                processing_time=metrics["total_time"],
                token_usage=token_usage
            )
        
        except Exception as e:
            logger.error(f"Error processing RAG query {query_id}: {e}")
            return RAGResponse(
                answer=f"处理查询时出错: {str(e)}",
                retrieved_documents=[],
                metrics=metrics,
                citations=[],
                generated_queries=[],
                related_concepts=[],
                confidence_score=0,
                warnings=[f"处理错误: {str(e)}"],
                status=TaskStatus.FAILED,
                query_id=query_id,
                processing_time=time.time() - start_time
            )
    
    async def process_batch(self, batch_request: BatchQueryRequest) -> BatchResponse:
        """处理批量查询"""
        batch_id = batch_request.batch_id
        logger.info(f"Starting batch processing: {batch_id} with {len(batch_request.queries)} queries")
        
        started_at = datetime.now()
        results = []
        completed = 0
        failed = 0
        
        # 更新批次状态
        self.batch_jobs[batch_id] = {
            "status": TaskStatus.RUNNING,
            "progress": 0,
            "started_at": started_at
        }
        
        try:
            if batch_request.parallel and len(batch_request.queries) > 1:
                # 并行处理
                tasks = [self.query(query) for query in batch_request.queries]
                batch_results = await asyncio.gather(*tasks, return_exceptions=True)
                
                for result in batch_results:
                    if isinstance(result, Exception):
                        failed += 1
                        # 创建错误响应
                        error_resp = RAGResponse(
                            answer=f"查询处理失败: {str(result)}",
                            retrieved_documents=[],
                            metrics={},
                            query_id=str(uuid.uuid4()),
                            status=TaskStatus.FAILED,
                            warnings=[str(result)]
                        )
                        results.append(error_resp)
                    else:
                        completed += 1
                        results.append(result)
            else:
                # 串行处理
                for query in batch_request.queries:
                    try:
                        result = await self.query(query)
                        results.append(result)
                        completed += 1
                    except Exception as e:
                        failed += 1
                        error_resp = RAGResponse(
                            answer=f"查询处理失败: {str(e)}",
                            retrieved_documents=[],
                            metrics={},
                            query_id=query.query_id,
                            status=TaskStatus.FAILED,
                            warnings=[str(e)]
                        )
                        results.append(error_resp)
                    
                    # 更新进度
                    progress = int((completed + failed) / len(batch_request.queries) * 100)
                    self.batch_jobs[batch_id]["progress"] = progress
            
            # 更新批次状态
            self.batch_jobs[batch_id] = {
                "status": TaskStatus.SUCCESS,
                "progress": 100,
                "started_at": started_at,
                "completed_at": datetime.now()
            }
            
            return BatchResponse(
                batch_id=batch_id,
                status=TaskStatus.SUCCESS,
                total_queries=len(batch_request.queries),
                completed=completed,
                failed=failed,
                results=results,
                started_at=started_at,
                completed_at=datetime.now()
            )
            
        except Exception as e:
            logger.error(f"Batch processing failed: {str(e)}")
            self.batch_jobs[batch_id] = {
                "status": TaskStatus.FAILED,
                "progress": int((completed + failed) / len(batch_request.queries) * 100),
                "started_at": started_at,
                "error": str(e)
            }
            
            return BatchResponse(
                batch_id=batch_id,
                status=TaskStatus.FAILED,
                total_queries=len(batch_request.queries),
                completed=completed,
                failed=failed,
                results=results,
                started_at=started_at
            )
    
    def get_batch_status(self, batch_id: str) -> Optional[Dict[str, Any]]:
        """获取批次处理状态"""
        return self.batch_jobs.get(batch_id)
    
    def get_system_status(self) -> Dict[str, Any]:
        """获取系统状态"""
        return {
            "knowledge_sources": len(self.kb_manager.get_knowledge_sources()),
            "total_documents": len(self.kb_manager.get_all_documents()),
            "queue_size": self.task_queue.qsize(),
            "running_tasks": self.running_tasks,
            "cache_size": len(self.cache),
            "token_usage": self.llm_client.get_token_usage(),
            "batch_jobs": {
                id: {
                    "status": job["status"],
                    "progress": job.get("progress", 0)
                }
                for id, job in self.batch_jobs.items()
            }
        }

# ====================== FastAPI 应用 ======================

app = FastAPI(
    title="RAG 后台服务",
    description="检索增强生成系统的后台实现",
    version="0.1.0"
)

# 配置CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 全局RAG系统实例
rag_system = None

@app.on_event("startup")
async def startup_event():
    """初始化RAG系统"""
    global rag_system
    config = RAGConfig(
        knowledge_sources=[
            KnowledgeSourceConfig(
                type=KnowledgeSourceType.PRELOADED,
                name="默认知识库",
                config={"preloaded_name": "default"}
            )
        ]
    )
    rag_system = RAGGenerator(config)
    
    # 加载默认知识库
    source_ids = list(rag_system.kb_manager.get_knowledge_sources().keys())
    if source_ids:
        await rag_system.kb_manager.load_knowledge_source(source_ids[0], rag_system.llm_client)
        
        # 更新检索器
        documents = rag_system.kb_manager.get_all_documents()
        for retriever in rag_system.retrievers.values():
            retriever.add_documents(documents)
    
    logger.info("RAG system initialized")

@app.post("/query", response_model=RAGResponse)
async def process_query(query: RAGQuery):
    """处理RAG查询"""
    try:
        if not rag_system:
            raise HTTPException(status_code=503, detail="RAG system not initialized")
        
        response = await rag_system.query(query)
        return response
    except Exception as e:
        logger.error(f"Error in /query endpoint: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/batch-query", response_model=BatchResponse)
async def process_batch_query(batch: BatchQueryRequest):
    """处理批量查询"""
    try:
        if not rag_system:
            raise HTTPException(status_code=503, detail="RAG system not initialized")
        
        response = await rag_system.process_batch(batch)
        return response
    except Exception as e:
        logger.error(f"Error in /batch-query endpoint: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/batch-status/{batch_id}")
async def get_batch_status(batch_id: str):
    """获取批量查询状态"""
    try:
        if not rag_system:
            raise HTTPException(status_code=503, detail="RAG system not initialized")
        
        status = rag_system.get_batch_status(batch_id)
        if not status:
            raise HTTPException(status_code=404, detail="Batch not found")
        
        return status
    except Exception as e:
        logger.error(f"Error in /batch-status endpoint: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/upload")
async def upload_file(file: UploadFile = File(...)):
    """上传文件到知识库"""
    try:
        contents = await file.read()
        file_path = f"uploads/{file.filename}"
        
        os.makedirs("uploads", exist_ok=True)
        with open(file_path, "wb") as f:
            f.write(contents)
        
        # 创建知识源配置
        source_config = KnowledgeSourceConfig(
            type=KnowledgeSourceType.UPLOAD,
            name=f"上传文件: {file.filename}",
            config={
                "files": [
                    {
                        "uid": str(uuid.uuid4()),
                        "name": file.filename,
                        "type": file.content_type,
                        "size": len(contents),
                        "lastModified": file.last_modified
                    }
                ]
            }
        )
        
        # 添加并加载知识源
        source_id = await rag_system.add_knowledge_source(source_config)
        
        return JSONResponse(
            content={
                "filename": file.filename,
                "size": len(contents),
                "saved_path": file_path,
                "source_id": source_id
            }
        )
    except Exception as e:
        logger.error(f"Error uploading file: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/add-knowledge-source")
async def add_knowledge_source(config: KnowledgeSourceConfig):
    """添加知识源"""
    try:
        if not rag_system:
            raise HTTPException(status_code=503, detail="RAG system not initialized")
        
        source_id = await rag_system.add_knowledge_source(config)
        return {"source_id": source_id, "message": f"Knowledge source '{config.name}' added successfully"}
    except Exception as e:
        logger.error(f"Error adding knowledge source: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/knowledge-sources")
async def get_knowledge_sources():
    """获取所有知识源"""
    try:
        if not rag_system:
            raise HTTPException(status_code=503, detail="RAG system not initialized")
        
        sources = rag_system.kb_manager.get_knowledge_sources()
        return {
            "sources": [
                {
                    "id": source_id,
                    "name": config.name,
                    "type": config.type,
                    "enabled": config.enabled,
                    "last_updated": config.last_updated
                }
                for source_id, config in sources.items()
            ]
        }
    except Exception as e:
        logger.error(f"Error getting knowledge sources: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/status")
async def get_status():
    """获取系统状态"""
    if not rag_system:
        return {
            "status": "initializing",
            "version": "0.1.0"
        }
    
    return {
        "status": "running",
        "version": "0.1.0",
        **rag_system.get_system_status()
    }

# ====================== 测试代码 ======================

def test_document_processor():
    """测试文档处理器"""
    print("=== Testing DocumentProcessor ===")
    text = "<p>This is a <b>test</b> document. It contains some special characters!@#$</p>"
    
    # 清理HTML
    cleaned = DocumentProcessor.clean_html(text)
    print(f"After clean_html: {cleaned}")
    
    # 移除特殊字符
    no_special = DocumentProcessor.remove_special_chars(cleaned)
    print(f"After remove_special_chars: {no_special}")
    
    # 分块
    chunks = DocumentProcessor.split_documents(no_special, chunk_size=10, overlap=0.2)
    print(f"After split_documents: {chunks}")
    
    # 小写转换
    lower = DocumentProcessor.lowercase(no_special)
    print(f"After lowercase: {lower}")
    
    # 提取关键词
    keywords = DocumentProcessor.extract_keywords(no_special)
    print(f"Extracted keywords: {keywords}")
    
    # 语言检测
    lang = DocumentProcessor.detect_language(no_special)
    print(f"Detected language: {lang}")
    
    zh_text = "这是一个中文测试文档。包含一些特殊字符！@#$"
    lang_zh = DocumentProcessor.detect_language(zh_text)
    print(f"Detected language for Chinese text: {lang_zh}")

def test_retriever():
    """测试检索器"""
    print("\n=== Testing Retriever ===")
    
    # 创建一些测试文档
    docs = [
        DocumentChunk(
            id=str(uuid.uuid4()),
            text="检索增强生成(RAG)是一种将大型语言模型与外部知识源相结合的技术",
            metadata=DocumentMetadata(source="测试"),
            tokens=15
        ),
        DocumentChunk(
            id=str(uuid.uuid4()),
            text="RAG通过检索相关信息来增强LLM的回答能力",
            metadata=DocumentMetadata(source="测试"),
            tokens=10
        ),
        DocumentChunk(
            id=str(uuid.uuid4()),
            text="语言模型如GPT-3可以生成流畅的文本",
            metadata=DocumentMetadata(source="测试"),
            tokens=8
        )
    ]
    
    # 初始化检索器
    retriever = Retriever(RetrieverType.HYBRID)
    retriever.add_documents(docs)
    
    # 创建LLM客户端获取嵌入
    llm_client = LLMClient()
    
    # 测试查询
    async def test_query():
        query = "什么是RAG?"
        query_embedding = await llm_client.embed(query)
        results = retriever.retrieve(query, top_k=2, query_embedding=query_embedding)
        
        print(f"Query: {query}")
        for doc, score in results:
            print(f"Score: {score:.2f} - Text: {doc.text[:50]}...")
    
    asyncio.run(test_query())

def test_rag_system():
    """测试RAG系统"""
    print("\n=== Testing RAG System ===")
    
    # 创建配置
    config = RAGConfig(
        knowledge_sources=[
            KnowledgeSourceConfig(
                type=KnowledgeSourceType.PRELOADED,
                name="测试知识库",
                config={"preloaded_name": "default"}
            )
        ]
    )
    
    # 初始化RAG系统
    rag = RAGGenerator(config)
    
    # 创建查询
    query = RAGQuery(
        query="什么是RAG系统?",
        retriever=RetrieverType.HYBRID,
        top_k=2
    )
    
    # 处理查询
    async def run_query():
        # 加载知识库
        source_ids = list(rag.kb_manager.get_knowledge_sources().keys())
        if source_ids:
            await rag.kb_manager.load_knowledge_source(source_ids[0], rag.llm_client)
            documents = rag.kb_manager.get_all_documents()
            for retriever in rag.retrievers.values():
                retriever.add_documents(documents)
        
        response = await rag.query(query)
        
        print(f"Question: {query.query}")
        print(f"Answer: {response.answer[:100]}...")
        print(f"Retrieved documents: {len(response.retrieved_documents)}")
        print(f"Metrics: {response.metrics}")
    
    asyncio.run(run_query())

if __name__ == "__main__":
    # 运行测试
    test_document_processor()
    test_retriever()
    test_rag_system()
    
    # 启动FastAPI应用
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)


# import os
# import json
# import uuid
# import time
# import logging
# from typing import List, Dict, Optional, Tuple, Any
# from dataclasses import dataclass, field
# from enum import Enum
# from pathlib import Path
# from functools import lru_cache
# import hashlib

# import numpy as np
# from pydantic import BaseModel, Field, validator
# from sentence_transformers import SentenceTransformer
# from rank_bm25 import BM25Okapi
# from sklearn.metrics.pairwise import cosine_similarity
# import requests
# from fastapi import FastAPI, HTTPException, UploadFile, File, Form
# from fastapi.responses import JSONResponse
# from fastapi.middleware.cors import CORSMiddleware

# # 配置日志
# logging.basicConfig(
#     level=logging.INFO,
#     format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
# )
# logger = logging.getLogger(__name__)

# # ====================== 数据模型和配置 ======================

# class TaskStatus(str, Enum):
#     READY = "ready"
#     RUNNING = "running"
#     SUCCESS = "success"
#     FAILED = "failed"
#     PAUSED = "paused"
#     STOPPED = "stopped"
#     QUEUED = "queued"
#     CANCELLED = "cancelled"

# class KnowledgeSourceType(str, Enum):
#     PRELOADED = "preloaded"
#     UPLOAD = "upload"
#     URL = "url"
#     DATABASE = "database"
#     API = "api"
#     GITHUB = "github"

# class RetrieverType(str, Enum):
#     BM25 = "bm25"
#     DENSE = "dense"
#     HYBRID = "hybrid"

# class SimilarityMetric(str, Enum):
#     COSINE = "cosine"
#     EUCLIDEAN = "euclidean"
#     MANHATTAN = "manhattan"
#     DOT_PRODUCT = "dot_product"

# class TaskPriority(str, Enum):
#     LOW = "low"
#     MEDIUM = "medium"
#     HIGH = "high"
#     CRITICAL = "critical"

# class DocumentType(str, Enum):
#     PDF = "pdf"
#     DOCX = "docx"
#     TXT = "txt"
#     MD = "md"
#     HTML = "html"
#     JSON = "json"
#     CSV = "csv"
#     PPTX = "pptx"
#     XLSX = "xlsx"
#     JPG = "jpg"
#     PNG = "png"
#     ZIP = "zip"

# class DocumentMetadata(BaseModel):
#     source: str
#     title: Optional[str] = None
#     author: Optional[str] = None
#     date: Optional[str] = None
#     url: Optional[str] = None
#     size: Optional[int] = None
#     pages: Optional[int] = None
#     language: Optional[str] = None
#     keywords: List[str] = []

# class DocumentChunk(BaseModel):
#     id: str
#     text: str
#     metadata: DocumentMetadata
#     embedding: Optional[List[float]] = None
#     tokens: int
#     score: Optional[float] = None

# class RetrievedDocument(BaseModel):
#     id: str
#     title: str
#     content: str
#     metadata: DocumentMetadata
#     score: float
#     chunks: List[DocumentChunk] = []

# class RAGQuery(BaseModel):
#     query: str
#     query_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
#     task_type: str = "query"
#     priority: TaskPriority = TaskPriority.MEDIUM
#     model: str = "gpt-3.5-turbo"
#     temperature: float = Field(0.7, ge=0, le=1)
#     max_tokens: int = Field(512, ge=1, le=8000)
#     top_p: float = Field(0.9, ge=0.1, le=1)
#     system_message: Optional[str] = None
#     prompt_template: str = (
#         "基于以下参考文档，回答问题：\n\n参考文档:\n{context}\n\n问题:\n{question}\n\n回答:"
#     )
    
#     # 检索配置
#     retriever: RetrieverType = RetrieverType.HYBRID
#     embedding_model: str = "text-embedding-ada-002"
#     similarity_metric: SimilarityMetric = SimilarityMetric.COSINE
#     top_k: int = Field(3, ge=1, le=20)
#     score_threshold: float = Field(0.7, ge=0, le=1)
#     query_expansion: bool = True
#     rerank_strategy: str = "simple"
#     enable_hybrid_search: bool = True
#     enable_semantic_cache: bool = True
    
#     # 知识库配置
#     document_processing: List[str] = ["clean_html", "remove_special_chars", "split_documents"]
#     chunk_size: int = 500
#     chunk_overlap: float = 0.2
#     metadata_fields: List[str] = ["author", "date", "source"]
    
#     # 后处理
#     postprocessing: List[str] = ["refine_answer", "add_citations", "format_response"]
#     fallback_strategy: str = "generate_anyway"
#     safety_checks: bool = True
#     enable_debug: bool = False
#     enable_experimental: bool = False
    
#     class Config:
#         json_schema_extra = {
#             "example": {
#                 "query": "什么是RAG系统?",
#                 "model": "gpt-3.5-turbo",
#                 "temperature": 0.7,
#                 "retriever": "hybrid",
#                 "top_k": 3
#             }
#         }

# class RAGResponse(BaseModel):
#     answer: str
#     retrieved_documents: List[RetrievedDocument]
#     metrics: Dict[str, Any]
#     citations: List[Dict[str, str]]
#     generated_queries: List[str]
#     related_concepts: List[Dict[str, Any]]
#     confidence_score: float
#     warnings: List[str]
#     status: TaskStatus = TaskStatus.SUCCESS
#     query_id: str

# class KnowledgeSourceConfig(BaseModel):
#     type: KnowledgeSourceType
#     name: str
#     config: Dict[str, Any]

# class RAGConfig(BaseModel):
#     knowledge_sources: List[KnowledgeSourceConfig]
#     default_query: RAGQuery = Field(default_factory=RAGQuery)

# # ====================== 核心RAG实现 ======================

# class DocumentProcessor:
#     """处理文档的预处理和后处理"""
    
#     @staticmethod
#     def clean_html(text: str) -> str:
#         """简单清理HTML标签"""
#         import re
#         clean_text = re.sub(r'<[^>]+>', '', text)
#         return clean_text
    
#     @staticmethod
#     def remove_special_chars(text: str) -> str:
#         """移除特殊字符"""
#         import re
#         clean_text = re.sub(r'[^\w\s\-.,;:!?]', '', text)
#         return clean_text
    
#     @staticmethod
#     def split_documents(text: str, chunk_size: int = 500, overlap: float = 0.2) -> List[str]:
#         """将文档分割成块"""
#         from nltk.tokenize import sent_tokenize
#         try:
#             sentences = sent_tokenize(text)
#         except:
#             sentences = text.split('. ')
        
#         chunks = []
#         current_chunk = []
#         current_length = 0
#         overlap_size = int(chunk_size * overlap)
        
#         for sentence in sentences:
#             sentence_length = len(sentence.split())
#             if current_length + sentence_length <= chunk_size:
#                 current_chunk.append(sentence)
#                 current_length += sentence_length
#             else:
#                 chunks.append(' '.join(current_chunk))
#                 current_chunk = current_chunk[-int(len(current_chunk) * overlap_size):] + [sentence]
#                 current_length = sum(len(s.split()) for s in current_chunk)
        
#         if current_chunk:
#             chunks.append(' '.join(current_chunk))
        
#         return chunks
    
#     @staticmethod
#     def lowercase(text: str) -> str:
#         """转换为小写"""
#         return text.lower()
    
#     @staticmethod
#     def remove_stopwords(text: str, language: str = 'english') -> str:
#         """移除停用词"""
#         from nltk.corpus import stopwords
#         from nltk.tokenize import word_tokenize
        
#         try:
#             stop_words = set(stopwords.words(language))
#             words = word_tokenize(text)
#             filtered_text = ' '.join([word for word in words if word.lower() not in stop_words])
#             return filtered_text
#         except:
#             return text
    
#     @staticmethod
#     def process_document(text: str, operations: List[str], **kwargs) -> str:
#         """应用指定的预处理操作"""
#         processed_text = text
#         for op in operations:
#             if op == "clean_html":
#                 processed_text = DocumentProcessor.clean_html(processed_text)
#             elif op == "remove_special_chars":
#                 processed_text = DocumentProcessor.remove_special_chars(processed_text)
#             elif op == "split_documents":
#                 return processed_text  # 分块需要特殊处理
#             elif op == "lowercase":
#                 processed_text = DocumentProcessor.lowercase(processed_text)
#             elif op == "remove_stopwords":
#                 processed_text = DocumentProcessor.remove_stopwords(processed_text, kwargs.get('language', 'english'))
        
#         return processed_text

# class EmbeddingModel:
#     """封装嵌入模型"""
    
#     def __init__(self, model_name: str = "all-MiniLM-L6-v2"):
#         self.model_name = model_name
#         self.model = self._load_model()
    
#     def _load_model(self):
#         """加载嵌入模型"""
#         try:
#             from sentence_transformers import SentenceTransformer
#             return SentenceTransformer(self.model_name)
#         except Exception as e:
#             logger.error(f"Failed to load embedding model: {e}")
#             raise
    
#     def embed(self, text: str) -> List[float]:
#         """生成文本嵌入"""
#         if isinstance(text, list):
#             return self.model.encode(text).tolist()
#         return self.model.encode([text])[0].tolist()

# class Retriever:
#     """实现不同的检索方法"""
    
#     def __init__(self, retriever_type: RetrieverType = RetrieverType.HYBRID):
#         self.retriever_type = retriever_type
#         self.embedding_model = EmbeddingModel()
#         self.bm25 = None
#         self.documents = []
#         self.document_embeddings = []
    
#     def add_documents(self, documents: List[DocumentChunk]):
#         """添加文档到检索器"""
#         self.documents = documents
        
#         # 为BM25准备
#         tokenized_corpus = [doc.text.split() for doc in documents]
#         self.bm25 = BM25Okapi(tokenized_corpus)
        
#         # 为密集检索准备
#         texts = [doc.text for doc in documents]
#         self.document_embeddings = self.embedding_model.embed(texts)
    
#     def retrieve(self, query: str, top_k: int = 5, score_threshold: float = 0.7) -> List[Tuple[DocumentChunk, float]]:
#         """检索相关文档"""
#         if self.retriever_type == RetrieverType.BM25:
#             return self._bm25_retrieve(query, top_k, score_threshold)
#         elif self.retriever_type == RetrieverType.DENSE:
#             return self._dense_retrieve(query, top_k, score_threshold)
#         else:  # HYBRID
#             return self._hybrid_retrieve(query, top_k, score_threshold)
    
#     def _bm25_retrieve(self, query: str, top_k: int, score_threshold: float) -> List[Tuple[DocumentChunk, float]]:
#         """BM25检索"""
#         tokenized_query = query.split()
#         scores = self.bm25.get_scores(tokenized_query)
        
#         # 获取top_k结果
#         top_indices = np.argsort(scores)[-top_k:][::-1]
#         results = []
#         for idx in top_indices:
#             if scores[idx] >= score_threshold:
#                 results.append((self.documents[idx], float(scores[idx])))
        
#         return results
    
#     def _dense_retrieve(self, query: str, top_k: int, score_threshold: float) -> List[Tuple[DocumentChunk, float]]:
#         """密集检索"""
#         query_embedding = self.embedding_model.embed(query)
#         similarities = cosine_similarity([query_embedding], self.document_embeddings)[0]
        
#         # 获取top_k结果
#         top_indices = np.argsort(similarities)[-top_k:][::-1]
#         results = []
#         for idx in top_indices:
#             if similarities[idx] >= score_threshold:
#                 results.append((self.documents[idx], float(similarities[idx])))
        
#         return results
    
#     def _hybrid_retrieve(self, query: str, top_k: int, score_threshold: float) -> List[Tuple[DocumentChunk, float]]:
#         """混合检索"""
#         bm25_results = self._bm25_retrieve(query, top_k * 2, 0)  # 降低阈值获取更多结果
#         dense_results = self._dense_retrieve(query, top_k * 2, 0)
        
#         # 合并结果
#         combined = {}
#         for doc, score in bm25_results:
#             combined[doc.id] = (doc, score * 0.4)  # BM25权重
        
#         for doc, score in dense_results:
#             if doc.id in combined:
#                 _, bm25_score = combined[doc.id]
#                 combined[doc.id] = (doc, bm25_score + score * 0.6)  # 密集检索权重更高
#             else:
#                 combined[doc.id] = (doc, score * 0.6)
        
#         # 排序并筛选
#         sorted_results = sorted(combined.values(), key=lambda x: x[1], reverse=True)
#         return [r for r in sorted_results[:top_k] if r[1] >= score_threshold]

# class RAGGenerator:
#     """生成RAG回答"""
    
#     def __init__(self, config: RAGConfig):
#         self.config = config
#         self.retriever = Retriever()
#         self.embedding_model = EmbeddingModel()
#         self.cache = {}
#         self.setup()
    
#     def setup(self):
#         """初始化知识库"""
#         # 这里应该加载所有知识源
#         logger.info("Initializing RAG system with knowledge sources...")
        
#         # 模拟加载一些文档
#         example_docs = [
#             DocumentChunk(
#                 id=str(uuid.uuid4()),
#                 text="检索增强生成(RAG)是一种将大型语言模型与外部知识源相结合的技术",
#                 metadata=DocumentMetadata(
#                     source="预加载知识库",
#                     title="RAG介绍",
#                     author="AI研究团队",
#                     date="2023-01-01"
#                 ),
#                 tokens=20
#             ),
#             DocumentChunk(
#                 id=str(uuid.uuid4()),
#                 text="RAG通过检索相关信息来增强LLM的回答能力，特别适用于需要最新知识的场景",
#                 metadata=DocumentMetadata(
#                     source="预加载知识库",
#                     title="RAG优势",
#                     author="AI研究团队",
#                     date="2023-01-15"
#                 ),
#                 tokens=25
#             )
#         ]
        
#         # 处理文档
#         processed_docs = []
#         for doc in example_docs:
#             processed_text = DocumentProcessor.process_document(
#                 doc.text,
#                 self.config.default_query.document_processing
#             )
#             processed_docs.append(DocumentChunk(
#                 **{**doc.dict(), "text": processed_text}
#             ))
        
#         self.retriever.add_documents(processed_docs)
    
#     def generate_prompt(self, query: str, context: List[str]) -> str:
#         """生成提示词"""
#         context_str = "\n\n".join([f"文档 {i+1}:\n{text}" for i, text in enumerate(context)])
#         return self.config.default_query.prompt_template.format(
#             context=context_str,
#             question=query
#         )
    
#     def llm_call(self, prompt: str, model: str = "gpt-3.5-turbo", **kwargs) -> str:
#         """模拟LLM调用"""
#         # 在实际应用中，这里应该调用真实的LLM API
#         logger.info(f"Calling LLM with model {model}")
        
#         # 模拟不同模型的响应
#         if "gpt-4" in model:
#             return ("RAG (检索增强生成) 系统是一种结合了信息检索和文本生成的技术框架。"
#                    "它首先从知识库中检索相关文档，然后基于这些文档生成回答。"
#                    "这种方法可以增强语言模型的事实准确性，并提供引用来源。")
#         else:
#             return ("RAG系统通过检索外部知识库来增强语言模型的生成能力。"
#                    "它先检索相关文档，然后基于这些文档生成回答。"
#                    "这种方法可以帮助模型提供更准确和最新的信息。")
    
#     def postprocess_answer(self, answer: str, retrieved_docs: List[RetrievedDocument], operations: List[str]) -> str:
#         """后处理生成的回答"""
#         processed_answer = answer
        
#         if "add_citations" in operations:
#             citations = "\n\n参考文献:\n"
#             for i, doc in enumerate(retrieved_docs):
#                 citations += f"{i+1}. {doc.title}\n"
#                 if doc.metadata.url:
#                     citations += f"   URL: {doc.metadata.url}\n"
#             processed_answer += citations
        
#         if "format_response" in operations:
#             processed_answer = processed_answer.replace("\n", "\n\n").strip()
        
#         return processed_answer
    
#     async def query(self, rag_query: RAGQuery) -> RAGResponse:
#         """处理RAG查询"""
#         query_id = rag_query.query_id
#         logger.info(f"Processing RAG query {query_id}")
        
#         start_time = time.time()
#         metrics = {
#             "retrieval_time": 0,
#             "generation_time": 0,
#             "total_time": 0,
#             "tokens_used": 0,
#             "estimated_cost": 0,
#             "documents_processed": 0,
#             "chunks_generated": 0,
#             "api_calls": 0,
#             "cache_hits": 0
#         }
        
#         try:
#             # 1. 检索阶段
#             retrieval_start = time.time()
            
#             # 检查缓存
#             cache_key = hashlib.md5(rag_query.query.encode()).hexdigest()
#             if rag_query.enable_semantic_cache and cache_key in self.cache:
#                 retrieved_docs = self.cache[cache_key]
#                 metrics["cache_hits"] = 1
#                 logger.info(f"Using cached results for query: {rag_query.query}")
#             else:
#                 retrieved_pairs = self.retriever.retrieve(
#                     rag_query.query,
#                     top_k=rag_query.top_k,
#                     score_threshold=rag_query.score_threshold
#                 )
#                 retrieved_docs = [
#                     RetrievedDocument(
#                         id=doc.id,
#                         title=doc.metadata.title or f"文档 {i+1}",
#                         content=doc.text,
#                         metadata=doc.metadata,
#                         score=score
#                     )
#                     for i, (doc, score) in enumerate(retrieved_pairs)
#                 ]
#                 if rag_query.enable_semantic_cache:
#                     self.cache[cache_key] = retrieved_docs
            
#             metrics["retrieval_time"] = time.time() - retrieval_start
#             metrics["documents_processed"] = len(retrieved_docs)
            
#             if not retrieved_docs and rag_query.fallback_strategy == "inform_user":
#                 return RAGResponse(
#                     answer="抱歉，没有找到相关信息。",
#                     retrieved_documents=[],
#                     metrics=metrics,
#                     citations=[],
#                     generated_queries=[],
#                     related_concepts=[],
#                     confidence_score=0,
#                     warnings=["没有检索到相关文档"],
#                     query_id=query_id
#                 )
            
#             # 2. 生成阶段
#             generation_start = time.time()
            
#             context = [doc.content for doc in retrieved_docs]
#             prompt = self.generate_prompt(rag_query.query, context)
            
#             answer = self.llm_call(
#                 prompt,
#                 model=rag_query.model,
#                 temperature=rag_query.temperature,
#                 max_tokens=rag_query.max_tokens
#             )
            
#             # 后处理
#             processed_answer = self.postprocess_answer(
#                 answer,
#                 retrieved_docs,
#                 rag_query.postprocessing
#             )
            
#             metrics["generation_time"] = time.time() - generation_start
#             metrics["tokens_used"] = len(answer.split())  # 简化估算
#             metrics["estimated_cost"] = metrics["tokens_used"] * 0.000002  # 模拟成本
#             metrics["api_calls"] = 1
            
#             # 3. 生成相关查询和概念
#             related_queries = [
#                 "RAG系统如何工作?",
#                 "检索增强生成的优势",
#                 "RAG与传统语言模型的区别"
#             ]
            
#             related_concepts = [
#                 {"name": "向量检索", "score": 0.92},
#                 {"name": "语言模型", "score": 0.89}
#             ]
            
#             # 4. 准备响应
#             metrics["total_time"] = time.time() - start_time
            
#             return RAGResponse(
#                 answer=processed_answer,
#                 retrieved_documents=retrieved_docs,
#                 metrics=metrics,
#                 citations=[{"id": doc.id, "title": doc.title, "url": doc.metadata.url or ""} for doc in retrieved_docs],
#                 generated_queries=related_queries,
#                 related_concepts=related_concepts,
#                 confidence_score=0.87,
#                 warnings=["部分内容基于模拟数据"] if rag_query.enable_debug else [],
#                 query_id=query_id
#             )
        
#         except Exception as e:
#             logger.error(f"Error processing RAG query {query_id}: {e}")
#             return RAGResponse(
#                 answer=f"处理查询时出错: {str(e)}",
#                 retrieved_documents=[],
#                 metrics=metrics,
#                 citations=[],
#                 generated_queries=[],
#                 related_concepts=[],
#                 confidence_score=0,
#                 warnings=[f"处理错误: {str(e)}"],
#                 status=TaskStatus.FAILED,
#                 query_id=query_id
#             )

# # ====================== FastAPI 应用 ======================

# app = FastAPI(
#     title="RAG 后台服务",
#     description="检索增强生成系统的后台实现",
#     version="0.1.0"
# )

# # 配置CORS
# app.add_middleware(
#     CORSMiddleware,
#     allow_origins=["*"],
#     allow_credentials=True,
#     allow_methods=["*"],
#     allow_headers=["*"],
# )

# # 全局RAG系统实例
# rag_system = None

# @app.on_event("startup")
# async def startup_event():
#     """初始化RAG系统"""
#     global rag_system
#     config = RAGConfig(
#         knowledge_sources=[
#             KnowledgeSourceConfig(
#                 type=KnowledgeSourceType.PRELOADED,
#                 name="默认知识库",
#                 config={"preloaded_name": "default"}
#             )
#         ]
#     )
#     rag_system = RAGGenerator(config)
#     logger.info("RAG system initialized")

# @app.post("/query", response_model=RAGResponse)
# async def process_query(query: RAGQuery):
#     """处理RAG查询"""
#     try:
#         if not rag_system:
#             raise HTTPException(status_code=503, detail="RAG system not initialized")
        
#         response = await rag_system.query(query)
#         return response
#     except Exception as e:
#         logger.error(f"Error in /query endpoint: {e}")
#         raise HTTPException(status_code=500, detail=str(e))

# @app.post("/upload")
# async def upload_file(file: UploadFile = File(...)):
#     """上传文件到知识库"""
#     try:
#         contents = await file.read()
#         file_path = f"uploads/{file.filename}"
        
#         os.makedirs("uploads", exist_ok=True)
#         with open(file_path, "wb") as f:
#             f.write(contents)
        
#         return JSONResponse(
#             content={
#                 "filename": file.filename,
#                 "size": len(contents),
#                 "saved_path": file_path
#             }
#         )
#     except Exception as e:
#         logger.error(f"Error uploading file: {e}")
#         raise HTTPException(status_code=500, detail=str(e))

# @app.get("/status")
# async def get_status():
#     """获取系统状态"""
#     return {
#         "status": "running",
#         "version": "0.1.0",
#         "knowledge_sources": len(rag_system.config.knowledge_sources) if rag_system else 0,
#         "cache_size": len(rag_system.cache) if rag_system else 0
#     }

# # ====================== 测试代码 ======================

# def test_document_processor():
#     """测试文档处理器"""
#     print("=== Testing DocumentProcessor ===")
#     text = "<p>This is a <b>test</b> document. It contains some special characters!@#$</p>"
    
#     # 清理HTML
#     cleaned = DocumentProcessor.clean_html(text)
#     print(f"After clean_html: {cleaned}")
    
#     # 移除特殊字符
#     no_special = DocumentProcessor.remove_special_chars(cleaned)
#     print(f"After remove_special_chars: {no_special}")
    
#     # 分块
#     chunks = DocumentProcessor.split_documents(no_special, chunk_size=10, overlap=0.2)
#     print(f"After split_documents: {chunks}")
    
#     # 小写转换
#     lower = DocumentProcessor.lowercase(no_special)
#     print(f"After lowercase: {lower}")

# def test_retriever():
#     """测试检索器"""
#     print("\n=== Testing Retriever ===")
    
#     # 创建一些测试文档
#     docs = [
#         DocumentChunk(
#             id=str(uuid.uuid4()),
#             text="检索增强生成(RAG)是一种将大型语言模型与外部知识源相结合的技术",
#             metadata=DocumentMetadata(source="测试"),
#             tokens=15
#         ),
#         DocumentChunk(
#             id=str(uuid.uuid4()),
#             text="RAG通过检索相关信息来增强LLM的回答能力",
#             metadata=DocumentMetadata(source="测试"),
#             tokens=10
#         ),
#         DocumentChunk(
#             id=str(uuid.uuid4()),
#             text="语言模型如GPT-3可以生成流畅的文本",
#             metadata=DocumentMetadata(source="测试"),
#             tokens=8
#         )
#     ]
    
#     # 初始化检索器
#     retriever = Retriever(RetrieverType.HYBRID)
#     retriever.add_documents(docs)
    
#     # 测试查询
#     query = "什么是RAG?"
#     results = retriever.retrieve(query, top_k=2)
    
#     print(f"Query: {query}")
#     for doc, score in results:
#         print(f"Score: {score:.2f} - Text: {doc.text[:50]}...")

# def test_rag_system():
#     """测试RAG系统"""
#     print("\n=== Testing RAG System ===")
    
#     # 创建配置
#     config = RAGConfig(
#         knowledge_sources=[
#             KnowledgeSourceConfig(
#                 type=KnowledgeSourceType.PRELOADED,
#                 name="测试知识库",
#                 config={}
#             )
#         ]
#     )
    
#     # 初始化RAG系统
#     rag = RAGGenerator(config)
    
#     # 创建查询
#     query = RAGQuery(
#         query="什么是RAG系统?",
#         retriever=RetrieverType.HYBRID,
#         top_k=2
#     )
    
#     # 处理查询
#     response = rag.query(query)
    
#     print(f"Question: {query.query}")
#     print(f"Answer: {response.answer[:100]}...")
#     print(f"Retrieved documents: {len(response.retrieved_documents)}")
#     print(f"Metrics: {response.metrics}")

# if __name__ == "__main__":
#     # 运行测试
#     test_document_processor()
#     test_retriever()
#     test_rag_system()
    
#     # 启动FastAPI应用
#     import uvicorn
#     uvicorn.run(app, host="0.0.0.0", port=8000)