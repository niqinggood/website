#!/usr/bin/env python
# -*- coding: UTF-8 -*-
'''
@Project ：computational_finance 
@File    ：deep_time_series.py
@IDE     ：PyCharm 
@Author  ：patrick
@Date    ：2022/4/16 10:24 
'''
import torch
import torch.nn as nn
import torch.nn.functional as F

class DeepAR(nn.Module):
    """DeepAR 模型"""
    def __init__(self, lstm_units):
        super().__init__()
        self.lstm = nn.LSTM(input_size=1, hidden_size=lstm_units, batch_first=True)
        self.dense_mu = nn.Linear(lstm_units, 1)
        self.dense_sigma = nn.Linear(lstm_units, 1)

    def forward(self, inputs, initial_state=None):
        # LSTM 前向传播
        outputs, (state_h, state_c) = self.lstm(inputs, initial_state)

        # 计算 mu 和 sigma
        mu = self.dense_mu(outputs)
        sigma = F.softplus(self.dense_sigma(outputs))  # 使用 softplus 激活函数

        return mu, sigma, (state_h, state_c)


def log_gaussian_loss(mu, sigma, y_true):
    """
    Gaussian 损失函数
    """
    # 计算高斯分布的负对数似然
    dist = torch.distributions.Normal(mu, sigma)
    return -dist.log_prob(y_true).mean()


class LSTNet(nn.Module):
    def __init__(self, dense_last_idx, sparse_fea_dim,
                 dense_hidden_units, dense_output_dim, dense_hidden_activation,
                 cross_layer_num, reg_w=1e-4, reg_b=1e-4):
        super().__init__()
        # 这里可以根据需要定义具体的层
        self.dense_last_idx = dense_last_idx
        self.sparse_fea_dim = sparse_fea_dim
        self.dense_hidden_units = dense_hidden_units
        self.dense_output_dim = dense_output_dim
        self.dense_hidden_activation = dense_hidden_activation
        self.cross_layer_num = cross_layer_num
        self.reg_w = reg_w
        self.reg_b = reg_b

        # 示例：定义一个简单的全连接层
        self.fc = nn.Linear(dense_last_idx, dense_output_dim)

    def forward(self, inputs):
        # 示例：前向传播逻辑
        output = self.fc(inputs)
        return output


if __name__ == '__main__':
    # 示例：测试 DeepAR 模型
    model = DeepAR(lstm_units=64)
    inputs = torch.randn(32, 10, 1)  # (batch_size, seq_len, input_size)
    mu, sigma, (state_h, state_c) = model(inputs)
    print("mu shape:", mu.shape)
    print("sigma shape:", sigma.shape)

    # 示例：测试 LSTNet 模型
    lstnet = LSTNet(dense_last_idx=10, sparse_fea_dim=5,
                    dense_hidden_units=64, dense_output_dim=1,
                    dense_hidden_activation='relu', cross_layer_num=2)
    inputs = torch.randn(32, 10)  # (batch_size, dense_last_idx)
    output = lstnet(inputs)
    print("LSTNet output shape:", output.shape)


# import tensorflow as tf
# import tensorflow_probability as tfp
#
#
# class DeepAR(tf.keras.models.Model):
#     """    DeepAR 模型     """
#     def __init__(self, lstm_units):
#         super().__init__()
#         self.lstm = tf.keras.layers.LSTM(lstm_units, return_sequences=True, return_state=True)
#         self.dense_mu = tf.keras.layers.Dense(1)
#         self.dense_sigma = tf.keras.layers.Dense(1, activation='softplus')
#
#     def call(self, inputs, initial_state=None):
#         outputs, state_h, state_c = self.lstm(inputs, initial_state=initial_state)
#
#         mu = self.dense_mu(outputs)
#         sigma = self.dense_sigma(outputs)
#         state = [state_h, state_c]
#
#         return [mu, sigma, state]
#
#
# def log_gaussian_loss(mu, sigma, y_true):
#     """
#     Gaussian 损失函数
#     """
#
# from tensorflow.keras import Model
# class LSTNet(Model):
#     def __init__(self,dense_last_idx,sparse_fea_dim,
#                  dense_hidden_units, dense_output_dim, dense_hidden_activation,
#                  cross_layer_num, reg_w=1e-4, reg_b=1e-4,): #'sigmoid'
#         super().__init__()
#
#     def build(self, input_shape):
#         self.built = True
#
#     def call(self, inputs):
#         return output
#
#
# if __name__ == '__main__':
#     exit()
    
  
  