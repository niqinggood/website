export const themeConfigs = {
  // 默认主题（保持不变）
  default: {
    palette: {
      primary: { main: '#1976d2', light: '#64b5f6',  dark: '#0d47a1' },
      secondary: { main: '#94BFFF', light: '#bdb4d1ff',  dark: '#c2b6ddff',    contrastText: '#ffffff'   },  //#dc004e
      background: { default: '#f5f5f5' },
    },
    typography: { fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif' },
    components: {
      MuiAppBar: {
        styleOverrides: { root: { background: 'linear-gradient(135deg, #1976d2 0%, #0d47a1 100%)' } }
      }
    },
    displayName: '默认'
  },

  

  // 优化后的字节跳动主题（低饱和度科技蓝）
  bytedance: {
    palette: {
      primary: { main: '#2d7ff9' }, // 降低亮度，更沉稳
      secondary: { main: '#94BFFF',light:'#bdb4d1ff',dark: '#cec1ebff' }, // 青绿色降低饱和度
      background: { default: '#f5f7fa' }, // 浅灰蓝背景，更柔和
    },
    typography: { fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif' },
    components: {
      MuiAppBar: {
        styleOverrides: { 
          root: { background: 'linear-gradient(135deg, #2d7ff9 0%, #1a66e0 100%)' } // 渐变更平缓
        }
      }
    },
    displayName: '科技蓝'
  },
  aotake: {
  palette: {
    primary: { main: '#8AA899' }, // 青竹色，低饱和绿
    secondary: { main: '#769687ff' }, // 浅竹绿，似新叶
    background: {
      default: '#F4F7F5', // 浅灰绿背景，似竹林光斑
      paper: '#FFFFFF'
    },
  },
  typography: {
    fontFamily: '"Noto Sans JP", "Roboto", sans-serif',
    h6: { fontWeight: 500 } // 轻量标题，不张扬
  },
  components: {
    MuiAppBar: {
      styleOverrides: {
        root: {
          background: 'linear-gradient(135deg, #8AA899 0%, #7A9889 100%)',
          boxShadow: '0 1px 3px rgba(138, 168, 153, 0.1)',
          color: '#FFFFFF'
        }
      }
    },
    MuiButton: {
      styleOverrides: {
        root: {
          borderRadius: 0, // 直角按钮，日式简约
          textTransform: 'none'
        },
        containedPrimary: {
          '&:hover': { background: '#7A9889' }
        }
      }
    }
  },
  displayName: '青竹绿'
},
mizuhai: {
  palette: {
    primary: { main: '#B9D7E3' }, // 水缥色，似浅海蓝
    secondary: { main: '#94B9CC' }, // 深一点的水色
    background: {
      default: '#F7FAFC', // 极浅蓝白背景，似水边雾
      paper: '#FFFFFF'
    },
  },
  typography: {
    fontFamily: '"Noto Sans JP", "Roboto", sans-serif',
    body1: { color: '#4A6572' }
  },
  components: {
    MuiAppBar: {
      styleOverrides: {
        root: {
          background: 'linear-gradient(135deg, #B9D7E3 0%, #A4C7D9 100%)',
          boxShadow: 'none',
          color: '#4A6572'
        }
      }
    },
    MuiDivider: {
      styleOverrides: {
        root: {
          borderColor: 'rgba(148, 185, 204, 0.15)',
          margin: '16px 0'
        }
      }
    }
  },
  displayName: '水缥蓝'
},
fjordBlue: {
  palette: {
    primary: { main: '#2D5D7B' }, // 深峡湾蓝，似挪威峡湾
    secondary: { main: '#F2C94C' }, // 亮黄色，似北欧阳光
    background: {
      default: '#F8F9FA', // 纯白背景，最大化光线感
      paper: '#FFFFFF'
    },
    text: {
      primary: '#212529', // 近黑色文字，高对比度
      secondary: '#6C757D'
    }
  },
  typography: {
    fontFamily: '"Inter", "Roboto", sans-serif',
    h1: { fontWeight: 700, letterSpacing: '-0.5px' } // 紧凑标题，几何感
  },
  components: {
    MuiAppBar: {
      styleOverrides: {
        root: {
          background: '#2D5D7B', // 纯实色，不渐变
          boxShadow: '0 2px 4px rgba(45, 93, 123, 0.1)',
          color: '#FFFFFF'
        }
      }
    },
    MuiButton: {
      styleOverrides: {
        containedSecondary: { // 亮色按钮作为点缀
          background: '#F2C94C',
          color: '#212529',
          '&:hover': { background: '#E6BD42' }
        }
      }
    }
  },
  displayName: '峡湾蓝'
},
meteorBlue: {
  palette: {
    primary: { main: '#2574F5' }, // 亮调流星蓝，似夜空流星
    secondary: { main: '#94BFFF' }, // 浅蓝，似流星尾迹
    background: {
      default: '#F0F5FF', // 浅蓝背景，似夜空
      paper: '#FFFFFF'
    },
  },
  typography: {
    fontFamily: '"Inter", "Roboto", sans-serif',
    h1: { color: '#1A365D' }
  },
  components: {
    MuiAppBar: {
      styleOverrides: {
        root: {
          background: 'linear-gradient(135deg, #2574F5 0%, #1A64E3 100%)',
          boxShadow: '0 2px 10px rgba(37, 116, 245, 0.2)'
        }
      }
    },
    MuiButton: {
      styleOverrides: {
        containedPrimary: {
          '&:hover': {
            background: '#3580FF',
            boxShadow: '0 4px 12px rgba(37, 116, 245, 0.3)'
          }
        }
      }
    }
  },
  displayName: '流星蓝'
},
  // 银行金融主题（保持不变）
  bank: {
    palette: {
      primary: { main: '#003366' },
      secondary: { main: '#0091d5' },
      background: { default: '#f5f7fa' },
    },
    typography: { fontFamily: '"Noto Sans SC", "Roboto", sans-serif' },
    components: {
      MuiAppBar: {
        styleOverrides: { root: { background: 'linear-gradient(135deg, #003366 0%, #002244 100%)' } }
      },
      MuiButton: {
        styleOverrides: { root: { borderRadius: 4 } }
      }
    },
    displayName: '银行蓝'
  },

  // 深色主题（保持不变）
  dark: {
    palette: {
      mode: 'dark',
      primary: { main: '#494a4bff' },
      secondary: { main: '#f48fb1' },
      background: { default: '#121212', paper: '#1e1e1e' },
    },
    typography: { fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif' },
    components: {
      MuiAppBar: {
        styleOverrides: { root: { background: 'linear-gradient(135deg, #333 0%, #111 100%)' } }
      }
    },
    displayName: '静谧黑'
  },

  // 优化后的紫色主题（浅色调）
  purple: {
    palette: {
      primary: { main: '#9c27b0' }, // 浅紫色，提高亮度
      secondary: { main: '#C4A5F7' },
      background: { default: '#faf5fc' }, // 极浅紫背景，更柔和
    },
    typography: { fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif' },
    components: {
      MuiAppBar: {
        styleOverrides: {
          root: { background: 'linear-gradient(135deg, #9c27b0 0%, #7b1fa2 100%)' } // 渐变更轻盈
        }
      }
    },
    displayName: '绚丽紫'
  },
  sunsetPurple: {
  palette: {
    primary: { main: '#8A5CF7' }, // 霞光紫，带粉调的柔和紫色
    secondary: { main: '#C4A5F7' }, // 浅紫，似余晖
    background: {
      default: '#FAF5FF', // 极浅紫背景，似晚霞余光
      paper: '#FFFFFF'
    },
  },
  typography: {
    fontFamily: '"Montserrat", "Roboto", sans-serif',
    body1: { color: '#4A3A66' }
  },
  components: {
    MuiAppBar: {
      styleOverrides: {
        root: {
          background: 'linear-gradient(135deg, #8A5CF7 0%, #7A4CE6 100%)',
          boxShadow: '0 2px 8px rgba(138, 92, 247, 0.15)'
        }
      }
    },
    MuiButton: {
      styleOverrides: {
        containedPrimary: {
          '&:hover': { background: '#9A6CFF' }
        }
      }
    }
  },
  displayName: '霞光紫'
},
  // 新增：高级感主题（以#3F6F76为主色调）
  // 新增：天青色主题（#90caf9）
  skyblue: {
    palette: {
      primary: { main: '#90caf9' },
      secondary: { main: '#64b5f6' }, // 稍深的蓝色作为辅助色
      background: { 
        default: '#f0f7ff', // 极浅蓝背景
        paper: '#ffffff' 
      },
    },
    typography: { fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif' },
    components: {
      MuiAppBar: {
        styleOverrides: { 
          root: { 
            background: 'linear-gradient(135deg, #90caf9 0%, #64b5f6 100%)',
            boxShadow: '0 2px 4px rgba(144, 202, 249, 0.3)',
            color: '#ffffff'
          } 
        }
      },
      MuiButton: {
        styleOverrides: {
          containedPrimary: {
            '&:hover': { background: '#7cbef0' }
          }
        }
      }
    },
    displayName: '天青色'
  },

  // 新增：草绿灰主题（#91AA9D）
  grassgreen: {
    palette: {
      primary: { main: '#91AA9D' },
      secondary: { main: '#778a74' }, // 深绿色作为辅助色
      background: { 
        default: '#f5f7f5', // 浅灰绿背景
        paper: '#ffffff' 
      },
    },
    typography: { fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif' },
    components: {
      MuiAppBar: {
        styleOverrides: { 
          root: { 
            background: 'linear-gradient(135deg, #91AA9D 0%, #778a74 100%)',
            boxShadow: '0 2px 4px rgba(145, 170, 157, 0.3)',
            color: '#ffffff'
          } 
        }
      },
      MuiButton: {
        styleOverrides: {
          containedPrimary: {
            '&:hover': { background: '#80998a' }
          }
        }
      }
    },
    displayName: '草绿灰'
  },

  // 新增：卡其色主题（#A7A37E）
  khaki: {
    palette: {
      primary: { main: '#A7A37E' },
      secondary: { main: '#8f8b67' }, // 深卡其色作为辅助色
      background: { 
        default: '#f8f7f0', // 浅卡其背景
        paper: '#ffffff' 
      },
    },
    typography: { fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif' },
    components: {
      MuiAppBar: {
        styleOverrides: { 
          root: { 
            background: 'linear-gradient(135deg, #A7A37E 0%, #8f8b67 100%)',
            boxShadow: '0 2px 4px rgba(167, 163, 126, 0.3)',
            color: '#ffffff'
          } 
        }
      },
      MuiButton: {
        styleOverrides: {
          containedPrimary: {
            '&:hover': { background: '#98946d' }
          }
        }
      }
    },
    displayName: '卡其色'
  },

  // 新增：瓦尔登蓝主题（#B9E3FB）
  waldenblue: {
    palette: {
      primary: { main: '#B9E3FB' },
      secondary: { main: '#90caf9' }, // 稍深的天蓝色作为辅助色
      background: { 
        default: '#f7fbff', // 极浅蓝背景
        paper: '#ffffff' 
      },
    },
    typography: { fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif' },
    components: {
      MuiAppBar: {
        styleOverrides: { 
          root: { 
            background: 'linear-gradient(135deg, #B9E3FB 0%, #90caf9 100%)',
            boxShadow: '0 2px 4px rgba(185, 227, 251, 0.3)',
            color: '#4d58a9ff'
          } 
        }
      },
      MuiButton: {
        styleOverrides: {
          containedPrimary: {
            '&:hover': { background: '#a8d9f7' }
          }
        }
      }
    },
    displayName: '瓦尔登蓝'
  },
pearlWhite: {
  palette: {
    primary: { main: '#E8EAED' }, // 珍珠白，带细腻光泽
    secondary: { main: '#C9CDD4' }, // 浅灰，似珍珠纹理
    accent: { main: '#F5F7FA' }, // 极浅白，似珍珠反光
    background: {
      default: '#FFFFFF', // 纯白背景，最大化珍珠质感
      paper: '#F9FAFC'
    },
    text: {
      primary: '#2D3035', // 深灰文字，避免纯黑
      secondary: '#6B7078'
    }
  },
  typography: {
    fontFamily: '"Helvetica Neue", "Roboto", sans-serif',
    h1: { fontWeight: 300 } // 轻盈标题，增强珍珠的柔和感
  },
  components: {
    MuiAppBar: {
      styleOverrides: {
        root: {
          background: 'linear-gradient(135deg, #FFFFFF 0%, #F5F7FA 100%)',
          boxShadow: '0 2px 4px rgba(0,0,0,0.05)',
          color: '#2D3035'
        }
      }
    },
    MuiPaper: {
      styleOverrides: {
        root: {
          border: '1px solid rgba(201, 205, 212, 0.2)',
          backgroundImage: 'linear-gradient(to bottom, #FFFFFF, #F9FAFC)'
        }
      }
    }
  },
  displayName: '珍珠白'
},
  // 新增：粉色世家主题（#DBC1D4）
  pink: {
    palette: {
      primary: { main: '#DBC1D4' },
      secondary: { main: '#c7a0c0' }, // 深粉色作为辅助色
      background: { 
        default: '#fcf8fc', // 浅粉背景
        paper: '#ffffff' 
      },
    },
    typography: { fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif' },
    components: {
      MuiAppBar: {
        styleOverrides: { 
          root: { 
            background: 'linear-gradient(135deg, #DBC1D4 0%, #c7a0c0 100%)',
            boxShadow: '0 2px 4px rgba(219, 193, 212, 0.3)',
            color: '#f2eaeaff'
          } 
        }
      },
      MuiButton: {
        styleOverrides: {
          containedPrimary: {
            '&:hover': { background: '#cbb0c7' }
          }
        }
      }
    },
    displayName: '淡紫粉'
  },

  // 新增：蜜桃色主题（#E0B198）
  peach: {
    palette: {
      primary: { main: '#E0B198' },
      secondary: { main: '#d09a7f' }, // 深蜜桃色作为辅助色
      background: { 
        default: '#fff8f3', // 浅橙背景
        paper: '#ffffff' 
      },
    },
    typography: { fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif' },
    components: {
        
      MuiAppBar: {
        styleOverrides: { 
          root: { 
            background: 'linear-gradient(135deg, #E0B198 0%, #d09a7f 100%)',
            boxShadow: '0 2px 4px rgba(224, 177, 152, 0.3)',
            color: '#ffffffff'
          } 
        }
      },
      MuiButton: {
        styleOverrides: {
          containedPrimary: {
            '&:hover': { background: '#d4a48b' }
          }
        }
      }
    },
    displayName: '蜜桃'
  },
  wabisabi: {
  palette: {
    primary: { main: '#E8E2D9' }, // 米白色，似粗陶质感
    secondary: { main: '#B8A99E' }, // 浅棕灰色，似旧木
    accent: { main: '#D2C6B2' }, // 淡茶褐色，似亚麻
    background: {
      default: '#F9F7F4', // 极浅米白背景，留白感
      paper: '#FFFFFF'
    },
    text: {
      primary: '#5A544A', // 深棕灰色文字，柔和不刺眼
      secondary: '#8A8275'
    }
  },
  typography: {
    fontFamily: '"Noto Sans JP", "Roboto", sans-serif',
    body1: { lineHeight: 1.6 } // 宽松行距，增强呼吸感
  },
  components: {
    MuiAppBar: {
      styleOverrides: {
        root: {
          background: 'linear-gradient(135deg, #E8E2D9 0%, #D9CEC3 100%)',
          boxShadow: 'none', // 无阴影，强调简洁
          color: '#5A544A'
        }
      }
    },
    MuiPaper: {
      styleOverrides: {
        root: {
          border: '1px solid rgba(184, 169, 158, 0.15)', // 细边框增强质感
          borderRadius: 2 // 微圆角，柔和不尖锐
        }
      }
    }
  },
  displayName: '侘寂白'
},
lavaOrange: {
  palette: {
    primary: { main: '#FF7D3B' }, // 熔岩橙，带炽热感
    secondary: { main: '#FFB48F' }, // 浅橙，似熔岩边缘
    background: {
      default: '#FFF8F5', // 浅橙背景，似熔岩周围环境
      paper: '#FFFFFF'
    },
    text: {
      primary: '#5D3A25' // 深棕文字，与橙色形成和谐对比
    }
  },
  typography: {
    fontFamily: '"Poppins", "Roboto", sans-serif',
    body1: { fontWeight: 400 }
  },
  components: {
    MuiAppBar: {
      styleOverrides: {
        root: {
          background: 'linear-gradient(135deg, #FF7D3B 0%, #F56A2C 100%)',
          boxShadow: '0 2px 8px rgba(255, 125, 59, 0.2)'
        }
      }
    },
    MuiCard: {
      styleOverrides: {
        root: { boxShadow: '0 4px 12px rgba(255, 125, 59, 0.08)' }
      }
    }
  },
  displayName: '熔岩橙'
},
// 优化后的平安集团主题（柔和橘色）
  pingan: {
    palette: {
      primary: { main: '#e08000' }, // 更柔和的橙色，降低饱和度
      secondary: { main: '#e9cfabff',light:'#bdb4d1ff',dark: '#cec1ebff' }, // 深灰调整为偏暖色调
      background: { default: '#fffbf5' }, // 浅米色背景，更柔和
    },
    typography: { fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif' },
    components: {
      MuiAppBar: {
        styleOverrides: { 
          root: { background: 'linear-gradient(135deg, #ff9500 0%, #e08000 100%)',color: '#ffffff'}// 渐变更自然
           
        }
      }
    },
    displayName: '平安橙'
  },

  clear: {
  palette: {
    primary: { main: '#8A7FFF', light: '#B3AFFF', dark: '#5C4DCC' }, // 浅柔蓝紫（主色调，降低饱和度、提高亮度）
    secondary: { main: '#b7b1faff', light: '#d5d2fbff', dark: '#9f98faff' }, // 浅霓虹青（辅助色，更通透）
    accent: { main: '#E6B3FF', light: '#F0D9FF', dark: '#CC80DD' }, // 浅迷幻粉紫（强调色，更轻盈）
    background: {
      default: '#F5F7FF', // 极浅紫蓝背景，营造轻透感
      paper: '#FFFFFF', // 纯白卡片，增强层次感
    },
    text: {
      primary: '#333366', // 深紫文字，提升可读性且契合主题
      secondary: '#666699', // 浅紫文字
    },
  },
  typography: {
    fontFamily: '"Inter", "Roboto", sans-serif',
    h1: { fontWeight: 700, color: '#333366' },
    h2: { fontWeight: 600, color: '#333366' },
    body1: { color: '#4D4D80' },
  },
  components: {
    MuiAppBar: {
      styleOverrides: {
        root: {
          background: 'linear-gradient(135deg, rgba(138, 127, 255, 0.8) 0%, rgba(92, 77, 204, 0.6) 100%)', // 透明渐变，更轻飘
          backdropFilter: 'blur(10px)', // 背景模糊，增强玄幻感
          boxShadow: '0 0 30px rgba(153, 240, 255, 0.3)', // 淡霓虹光晕
        },
      },
    },
    MuiButton: {
      styleOverrides: {
        containedPrimary: {
          background: 'rgba(153, 240, 255, 0.8)',
          color: '#333366',
          '&:hover': {
            background: 'rgba(153, 240, 255, 1)',
            boxShadow: '0 0 15px rgba(153, 240, 255, 0.6)',
          },
        },
        containedSecondary: {
          background: 'rgba(230, 179, 255, 0.8)',
          color: '#333366',
          '&:hover': {
            background: 'rgba(230, 179, 255, 1)',
            boxShadow: '0 0 15px rgba(230, 179, 255, 0.6)',
          },
        },
      },
    },
    MuiCard: {
      styleOverrides: {
        root: {
          background: 'rgba(255, 255, 255, 0.9)',
          boxShadow: '0 0 20px rgba(230, 179, 255, 0.2)',
          border: '1px solid rgba(138, 127, 255, 0.2)',
          backdropFilter: 'blur(5px)', // 卡片也带模糊，更统一
        },
      },
    },
    MuiTooltip: {
      styleOverrides: {
        tooltip: {
          background: 'rgba(138, 127, 255, 0.9)',
          color: '#FFFFFF',
          boxShadow: '0 0 15px rgba(153, 240, 255, 0.4)',
          backdropFilter: 'blur(3px)',
        },
      },
    },
    MuiPaper: {
      styleOverrides: {
        root: {
          backgroundImage: 'radial-gradient(circle at 10% 20%, rgba(153, 240, 255, 0.1) 0%, rgba(230, 179, 255, 0.1) 100%)', // 背景径向渐变，增加玄幻层次
        },
      },
    },
  },
  displayName: '轻透',
},
cyberpunk: {
  palette: {
    primary: { main: '#5e7575ff', light: 'rgba(78, 112, 112, 0.8)', dark: 'rgba(24, 109, 109, 0.6)' }, // 降低饱和度，增加透明变体
    secondary: { main: 'rgba(22, 105, 124, 0.32)', light: 'rgba(0, 208, 255, 0.9)', dark: 'rgba(0, 180, 220, 0.8)' }, // 荧光蓝带透明度
    accent: { main: 'rgba(255, 45, 255, 0.6)', light: 'rgba(255, 45, 255, 0.8)', dark: 'rgba(220, 0, 220, 0.7)' }, // 霓虹粉带透明度
    background: {
      default: 'hsla(225, 51%, 29%, 0.60)', // 深黑紫背景带透明度，更通透
      paper: 'rgba(18, 18, 42, 0.9)', // 卡片背景也带透明
    },
    text: {
      primary: 'rgba(224, 247, 250, 0.9)', // 浅青文字带透明度
      secondary: 'rgba(178, 235, 242, 0.8)', // 更浅文字带透明度
    },
  },
  typography: {
    fontFamily: '"Orbitron", "Roboto", sans-serif',
    h1: { 
      fontWeight: 800, 
      color: 'rgba(224, 247, 250, 0.9)', 
      textShadow: '0 0 8px rgba(0, 208, 255, 0.3)' // 文字阴影降低饱和度和透明度
    },
    h2: { 
      fontWeight: 700, 
      color: 'rgba(224, 247, 250, 0.9)', 
      textShadow: '0 0 6px rgba(0, 208, 255, 0.2)' 
    },
    body1: { color: 'rgba(178, 235, 242, 0.8)' },
  },
  components: {
    MuiAppBar: {
      styleOverrides: {
        root: {
          background: 'linear-gradient(90deg,  rgba(0, 100, 100, 0.5) 0%,rgba(43, 64, 221, 0.5) 100%)', // 渐变带透明
          boxShadow: '0 0 25px rgba(0, 208, 255, 0.2)', // 光晕降低饱和度和透明度
          borderBottom: '2px solid rgba(0, 208, 255, 0.5)', // 底部线条带透明
        },
      },
    },
    MuiButton: {
      styleOverrides: {
        containedPrimary: {
          background: 'rgba(0, 208, 255, 0.6)',
          color: 'rgba(10, 10, 26, 0.9)',
          '&:hover': {
            background: 'rgba(0, 208, 255, 0.8)',
            boxShadow: '0 0 15px rgba(0, 208, 255, 0.5)', // hover光晕降低饱和度和透明度
          },
        },
        containedSecondary: {
          background: 'rgba(255, 45, 255, 0.5)',
          color: 'rgba(255, 255, 255, 0.9)',
          '&:hover': {
            background: 'rgba(255, 45, 255, 0.7)',
            boxShadow: '0 0 15px rgba(255, 45, 255, 0.5)',
          },
        },
      },
    },
    MuiCard: {
      styleOverrides: {
        root: {
          background: 'rgba(18, 18, 42, 0.85)',
          boxShadow: '0 0 20px rgba(0, 208, 255, 0.15), 0 0 10px rgba(255, 45, 255, 0.1)', // 光晕降低饱和度和透明度
          border: '1px solid rgba(0, 208, 255, 0.2)',
        },
      },
    },
    MuiTooltip: {
      styleOverrides: {
        tooltip: {
          background: 'rgba(0, 133, 132, 0.8)',
          color: 'rgba(224, 247, 250, 0.9)',
          boxShadow: '0 0 12px rgba(0, 208, 255, 0.4)', // 降低饱和度和透明度
        },
      },
    },
    MuiTextField: {
      styleOverrides: {
        root: {
          '& .MuiOutlinedInput-root': {
            '& fieldset': {
              borderColor: 'rgba(0, 208, 255, 0.4)',
            },
            '&:hover fieldset': {
              borderColor: 'rgba(0, 208, 255, 0.6)',
            },
            '&.Mui-focused fieldset': {
              borderColor: 'rgba(0, 208, 255, 0.7)',
              boxShadow: '0 0 8px rgba(0, 208, 255, 0.3)', // 降低饱和度和透明度
            },
          },
        },
      },
    },
  },
  displayName: '赛博朋克',
},

// 新增：鎏金棕主题（复古奢华感）
goldenBrown: {
  palette: {
    primary: { main: '#8B5A2B' }, // 深棕褐色，似檀木
    secondary: { main: '#D4AF37' }, // 鎏金色，提亮整体
    background: {
      default: '#F5F1E9', // 浅棕米色背景
      paper: '#FFFFFF'
    },
    text: {
      primary: '#3A2E1F', // 深棕文字，提升质感
    }
  },
  typography: {
    fontFamily: '"Playfair Display", "Times New Roman", serif',
    h1: { fontWeight: 600 },
  },
  components: {
    MuiAppBar: {
      styleOverrides: {
        root: {
          background: 'linear-gradient(135deg, #8B5A2B 0%, #6B4423 100%)',
          boxShadow: '0 2px 8px rgba(139, 90, 43, 0.2)'
        }
      }
    },
    MuiDivider: {
      styleOverrides: {
        root: { borderColor: 'rgba(212, 175, 55, 0.2)' }
      }
    }
  },
  displayName: '鎏金棕'
},

// 新增：雾蓝灰主题（现代简约风）
mistyBlue: {
  palette: {
    primary: { main: '#6B8E9E' }, // 雾蓝色，低饱和度
    secondary: { main: '#9DB4C0', light: '#bed5e2ff', dark: '#9fb1bbff' }, // 浅蓝灰色
    background: {
      default: '#F0F4F7', // 极浅蓝灰背景
      paper: '#FFFFFF'
    },
  },
  typography: {
    fontFamily: '"Inter", "Roboto", sans-serif',
    body1: { color: '#3A4A54' }
  },
  components: {
    MuiAppBar: {
      styleOverrides: {
        root: {
          background: 'linear-gradient(135deg, #6B8E9E 0%, #5A7A8C 100%)',
          boxShadow: '0 2px 6px rgba(107, 142, 158, 0.15)'
        }
      }
    },
    MuiCard: {
      styleOverrides: {
        root: { boxShadow: '0 4px 12px rgba(107, 142, 158, 0.08)' }
      }
    }
  },
  displayName: '雾蓝灰'
},

// 新增：绛红色主题（典雅中国风）
crimson: {
  palette: {
    primary: { main: '#9E2A2B' }, // 深红色，似绛色
    secondary: { main: '#C94C4C' }, // 浅红色，提亮
    background: {
      default: '#FCF7F7', // 极浅红背景
      paper: '#FFFFFF'
    },
  },
  typography: {
    fontFamily: '"Noto Serif SC", "Georgia", serif',
    body1: { color: '#5C2121' }
  },
  components: {
    MuiAppBar: {
      styleOverrides: {
        root: {
          background: 'linear-gradient(135deg, #9E2A2B 0%, #7D2021 100%)',
          boxShadow: '0 2px 6px rgba(158, 42, 43, 0.15)'
        }
      }
    },
    MuiButton: {
      styleOverrides: {
        containedPrimary: {
          '&:hover': { background: '#AE3A3B' }
        }
      }
    }
  },
  displayName: '绛红色'
},

// 新增：藤黄色主题（自然清新感）
rattanYellow: {
  palette: {
    primary: { main: '#A67C52' }, // 藤黄色，温暖自然
    secondary: { main: '#D9B99B' }, // 浅藤色
    accent: { main: '#739072' }, // 草木绿，点缀用
    background: {
      default: '#FFFDF7', // 米白色背景
      paper: '#FFFFFF'
    },
  },
  typography: {
    fontFamily: '"Source Serif Pro", "Georgia", serif',
    body1: { color: '#5C4A36' }
  },
  components: {
    MuiAppBar: {
      styleOverrides: {
        root: {
          background: 'linear-gradient(135deg, #A67C52 0%, #8B6742 100%)',
          boxShadow: '0 2px 6px rgba(166, 124, 82, 0.15)'
        }
      }
    },
    MuiChip: {
      styleOverrides: {
        root: {
          '&.MuiChip-colorSecondary': {
            background: 'rgba(115, 144, 114, 0.15)',
            color: '#5A6B59'
          }
        }
      }
    }
  },
  displayName: '藤黄色'
},



gulfBlue: {
  palette: {
    primary: { main: '#1E6BA5' }, // 深邃海湾蓝，带轻微灰度
    secondary: { main: '#7FB0D4' }, // 浅滩蓝，似海水反光
    background: {
      default: '#F0F7FC', // 极浅蓝灰背景，似晴空
      paper: '#FFFFFF'
    },
  },
  typography: {
    fontFamily: '"Inter", "Roboto", sans-serif',
    body1: { color: '#2A3A47' }
  },
  components: {
    MuiAppBar: {
      styleOverrides: {
        root: {
          background: 'linear-gradient(135deg, #1E6BA5 0%, #165282 100%)',
          boxShadow: '0 2px 8px rgba(30, 107, 165, 0.15)'
        }
      }
    },
    MuiButton: {
      styleOverrides: {
        containedPrimary: {
          '&:hover': { background: '#287DC8' }
        }
      }
    }
  },
  displayName: '海湾蓝'
},
oliveGreen: {
  palette: {
    primary: { main: '#5A6B46' }, // 军感橄榄绿，低饱和度
    secondary: { main: '#A0A990' }, // 浅橄榄色，似嫩叶
    accent: { main: '#D4C8A8' }, // 米褐色，似树皮
    background: {
      default: '#F5F5F0', // 浅灰绿背景，似林间光影
      paper: '#FFFFFF'
    },
  },
  typography: {
    fontFamily: '"Roboto Slab", "Georgia", serif',
    body1: { color: '#3A442F' }
  },
  components: {
    MuiAppBar: {
      styleOverrides: {
        root: {
          background: 'linear-gradient(135deg, #5A6B46 0%, #4A593A 100%)',
          boxShadow: '0 2px 6px rgba(90, 107, 70, 0.1)'
        }
      }
    },
    MuiCard: {
      styleOverrides: {
        root: { boxShadow: '0 4px 12px rgba(90, 107, 70, 0.05)' }
      }
    }
  },
  displayName: '橄榄绿'
},


cambrianGray: {
  palette: {
    primary: { main: '#646970' }, // 岩石灰，带矿物质感
    secondary: { main: '#A3A8AD' }, // 浅岩灰，似岩石反光面
    accent: { main: '#D9DDE2' }, // 极浅灰，似岩石纹理
    background: {
      default: '#F2F3F5', // 浅灰背景，似岩石风化面
      paper: '#FFFFFF'
    },
  },
  typography: {
    fontFamily: '"Source Sans Pro", "Roboto", sans-serif',
    body1: { color: '#2D3035' }
  },
  components: {
    MuiAppBar: {
      styleOverrides: {
        root: {
          background: 'linear-gradient(135deg, #646970 0%, #54595F 100%)',
          boxShadow: '0 2px 6px rgba(100, 105, 112, 0.15)'
        }
      }
    },
    MuiPaper: {
      styleOverrides: {
        root: {
          backgroundImage: 'linear-gradient(to bottom, rgba(255,255,255,0.8), rgba(255,255,255,0.95))',
          border: '1px solid rgba(163, 168, 173, 0.15)'
        }
      }
    }
  },
  displayName: '寒武岩灰'
},
elegantGray: {
  palette: {
    primary: { main: '#8A9099' }, // 雅致中灰色，不偏冷也不偏暖
    secondary: { main: '#C9CDD2' }, // 浅灰色，似磨砂质感
    background: {
      default: '#F7F8FA', // 极浅灰背景，似雾面效果
      paper: '#FFFFFF'
    },
    text: {
      primary: '#33363B', // 深灰文字，避免纯黑的生硬
      secondary: '#6B7078'
    }
  },
  typography: {
    fontFamily: '"Helvetica Neue", "Roboto", sans-serif',
    h1: { fontWeight: 500 } // 轻量标题，增强雅致感
  },
  components: {
    MuiAppBar: {
      styleOverrides: {
        root: {
          background: 'linear-gradient(135deg, #8A9099 0%, #7A8089 100%)',
          boxShadow: '0 2px 4px rgba(138, 144, 153, 0.1)'
        }
      }
    },
    MuiDivider: {
      styleOverrides: {
        root: { borderColor: 'rgba(201, 205, 210, 0.3)' }
      }
    }
  },
  displayName: '雅灰'
},



};



// 提取所有主题的ID和名称，供SkinSelector生成选择列表
export const allThemes = Object.entries(themeConfigs).map(([id, config]) => ({
  id,
  name:   config.displayName,
  color: config.palette.primary.main // 主题主色（用于预览）
})); 