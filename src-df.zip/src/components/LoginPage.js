import React, { useState } from 'react';
import axios from 'axios';
import { 
  Box, 
  Typography, 
  TextField, 
  Button, 
  Paper, 
  Avatar, 
  Link, 
  Grid, 
  Divider, 
  CircularProgress,
  Alert,
  Tabs,
  Tab
} from '@mui/material';
import { Lock, Email, Person, GitHub, Google } from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';

const LoginPage = ({ setUser, showNotification }) => {
  const [loginId, setLoginId] = useState(''); // 可以是用户名或邮箱
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [loginMethod, setLoginMethod] = useState('username'); // 'username' 或 'email'
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const response = await axios.post('/api/login', {
        [loginMethod]: loginId, // 动态属性名
        password
      },{   withCredentials: true  // 关键！允许接收/发送Cookie
        });
      const role = response.data.role; // 获取角色信息

      setUser(response.data.user);
      console.info('######role:',role)
      localStorage.setItem('userRole', role);
      showNotification('登录成功', 'success');
      navigate('/');
    } catch (err) {
      console.error("登录失败:", err);
      setError(err.response?.data?.message || '登录失败，请重试');
    } finally {
      setLoading(false);
    }
  };

  const handleOAuthLogin = (provider) => {
    window.location.href = `/api/auth/${provider}`;
  };

  const handleTabChange = (event, newValue) => {
    setLoginMethod(newValue);
    setLoginId('');
    setError('');
  };
  console.info("run login")

  return (
    <Box
      sx={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        minHeight: '80vh',
        p: 2
      }}
    >
      <Paper
        elevation={3}
        sx={{
          p: 4,
          width: '100%',
          maxWidth: 500,
          borderRadius: '16px',
          background: 'linear-gradient(145deg, #ffffff, #f5f5f5)'
        }}
      >
        <Box sx={{ textAlign: 'center', mb: 3 }}>
          <Avatar
            sx={{
              width: 60,
              height: 60,
              bgcolor: 'primary.main',
              mb: 2,
              mx: 'auto'
            }}
          >
            <Lock fontSize="large" />
          </Avatar>
          <Typography variant="h5" component="h1" gutterBottom>
            欢迎回来
          </Typography>
          <Typography variant="body2" color="text.secondary">
            请登录您的账户继续
          </Typography>
        </Box>

        <Tabs
          value={loginMethod}
          onChange={handleTabChange}
          centered
          sx={{ mb: 2 }}
        >
          <Tab label="用户名登录" value="username" />
          <Tab label="邮箱登录" value="email" />
        </Tabs>

        {error && (
          <Alert severity="error" sx={{ mb: 2 }}>
            {error}
          </Alert>
        )}

        <form onSubmit={handleSubmit}>
          <TextField
            fullWidth
            label={loginMethod === 'username' ? '用户名' : '邮箱'}
            type={loginMethod === 'email' ? 'email' : 'text'}
            value={loginId}
            onChange={(e) => setLoginId(e.target.value)}
            margin="normal"
            required
            InputProps={{
              startAdornment: loginMethod === 'username'
                ? <Person sx={{ color: 'action.active', mr: 1 }} />
                : <Email sx={{ color: 'action.active', mr: 1 }} />
            }}
          />
          <TextField
            fullWidth
            label="密码"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            margin="normal"
            required
            InputProps={{
              startAdornment: <Lock sx={{ color: 'action.active', mr: 1 }} />
            }}
          />
          <Button
            fullWidth
            type="submit"
            variant="contained"
            disabled={loading}
            sx={{ mt: 3, mb: 2, py: 1.5 }}
          >
            {loading ? <CircularProgress size={24} /> : '登录'}
          </Button>
        </form>

        <Divider sx={{ my: 3 }}>
          <Typography variant="body2" color="text.secondary">
            或使用以下方式登录
          </Typography>
        </Divider>

        <Grid container spacing={2}>
          <Grid item xs={6}>
            <Button
              fullWidth
              variant="outlined"
              startIcon={<Google />}
              onClick={() => handleOAuthLogin('google')}
              sx={{ py: 1.5 }}
            >
              Google
            </Button>
          </Grid>
          <Grid item xs={6}>
            <Button
              fullWidth
              variant="outlined"
              startIcon={<GitHub />}
              onClick={() => handleOAuthLogin('github')}
              sx={{ py: 1.5 }}
            >
              GitHub
            </Button>
          </Grid>
        </Grid>

        <Box sx={{ textAlign: 'center', mt: 3 }}>
          <Typography variant="body2">
            还没有账户?{' '}
            <Link href="/register" underline="hover">
              注册
            </Link>
          </Typography>
          <Typography variant="body2" sx={{ mt: 1 }}>
            <Link href="/forgot-password" underline="hover">
              忘记密码?
            </Link>
          </Typography>
        </Box>
      </Paper>
    </Box>
  );
};

export default LoginPage;