import { REPORT_TEMPLATE_SCHEMA } from './reportTemplateSchema';

/**
 * 简易JSON Schema验证器（轻量级实现）
 * 用于验证报告模板是否符合预定义的Schema规范
 * @param {object} data - 待验证的数据
 * @param {object} schema - JSON Schema规则
 * @returns {boolean} 验证是否通过
 */
const validateSchema = (data, schema, path = '') => {
  // 基本类型验证
  if (schema.type && typeof data !== schema.type) {
    console.error(`类型验证失败：期望${schema.type}，实际${typeof data}`);
    return false;
  }

  // 对象属性验证
  if (schema.type === 'object' && schema.properties) {
    for (const [prop, propSchema] of Object.entries(schema.properties)) {
      const currentPath = path ? `${path}.${prop}` : prop; // 拼接子字段路径
      // 必需属性检查
      if (schema.required && schema.required.includes(prop) && !(prop in data)) {
        console.error(`缺少必需属性：路径=${currentPath}`);
        return false;
      }
      // 存在的属性需要验证格式：传递currentPath
      if (prop in data) {
        if (!validateSchema(data[prop], propSchema, currentPath)) {
          return false;
        }
      }
    }
    return true;
  }

  // 数组验证
  if (schema.type === 'array' && schema.items) {
    if (!Array.isArray(data)) {
      console.error(`类型验证失败：路径=${path}，期望array，实际${typeof data}`);
      return false;
    }
    for (let i = 0; i < data.length; i++) {
      const currentPath = `${path}[${i}]`; // 数组项路径，比如 "structure[0]"
      if (!validateSchema(data[i], schema.items, currentPath)) {
        return false;
      }
    }
    return true;
  }

  // 枚举值验证
  if (schema.enum && !schema.enum.includes(data)) {
    console.error(`枚举值验证失败：${data}不在${schema.enum}中`);
    return false;
  }

  // 数值范围验证
  if (typeof data === 'number') {
    if (schema.minimum !== undefined && data < schema.minimum) {
      console.error(`数值小于最小值：${data} < ${schema.minimum}`);
      return false;
    }
    if (schema.maximum !== undefined && data > schema.maximum) {
      console.error(`数值大于最大值：${data} > ${schema.maximum}`);
      return false;
    }
  }

  return true;
};

/**
 * 验证报告模板是否符合规范
 * @param {object} template - 待验证的报告模板
 * @returns {boolean} 验证通过返回true，否则返回false
 */
export const validateTemplate = (template) => {
  try {
    // 基本格式检查
    if (!template || typeof template !== 'object') {
      console.error('模板必须是一个对象');
      return false;
    }

    // 应用完整Schema验证
    return validateSchema(template, REPORT_TEMPLATE_SCHEMA);
  } catch (error) {
    console.error('模板验证过程出错：', error);
    return false;
  }
};

/**
 * 生成详细的模板验证报告（用于调试）
 * @param {object} template - 待验证的报告模板
 * @returns {object} 包含验证结果和错误信息的报告
 */
/**
 * 生成详细的模板验证报告（用于调试）
 * @param {object} template - 待验证的报告模板
 * @returns {object} 包含验证结果和错误信息的报告
 */
/**
 * 生成详细的模板验证报告（用于调试）
 * @param {object} template - 待验证的报告模板
 * @returns {object} 包含验证结果和错误信息的报告
 */
export const getTemplateValidationReport = (template) => {
  const errors = [];

  // 收集错误信息的验证函数（修复 integer 类型判断和数组类型判断）
  const validateWithErrors = (data, schema, path = '') => {
    let isValid = true;

    // 1. 优先处理数组类型验证（解决 typeof [] === 'object' 导致的误判）
    if (schema.type === 'array') {
      // 验证是否为数组
      if (!Array.isArray(data)) {
        errors.push(`路径 ${path}：期望array类型，实际${typeof data}（值：${JSON.stringify(data)}）`);
        return false;
      }
      // 验证数组内每一项是否符合 items 规范
      if (schema.items) {
        data.forEach((item, index) => {
          const currentPath = `${path}[${index}]`; // 数组项路径（如 structure[0]）
          if (!validateWithErrors(item, schema.items, currentPath)) {
            isValid = false;
          }
        });
      }
      return isValid;
    }

    // 2. 处理 integer 类型验证（解决 JavaScript 无 integer 类型导致的误判）
    if (schema.type === 'integer') {
      // 第一步：验证是否为数字类型
      if (typeof data !== 'number') {
        errors.push(`路径 ${path}：期望integer类型，实际${typeof data}（值：${JSON.stringify(data)}）`);
        return false;
      }
      // 第二步：验证是否为整数（排除小数）
      if (!Number.isInteger(data)) {
        errors.push(`路径 ${path}：期望integer类型，实际为非整数（值：${data}）`);
        return false;
      }
      // 第三步：验证数值范围（若 schema 有配置 minimum/maximum）
      if (schema.minimum !== undefined && data < schema.minimum) {
        // 修复：完整的字符串模板语法（反引号 + ${} 包裹变量）
        errors.push(`路径 ${path}：数值${data}小于最小值${schema.minimum}`);
        return false;
      }
      if (schema.maximum !== undefined && data > schema.maximum) {
        errors.push(`路径 ${path}：数值${data}大于最大值${schema.maximum}`);
        return false;
      }
      // 第四步：验证是否为指定枚举值（若 schema 有配置 enum）
      if (schema.enum && !schema.enum.includes(data)) {
        errors.push(`路径 ${path}：值${data}不在允许的枚举列表中${JSON.stringify(schema.enum)}`);
        return false;
      }
      return isValid;
    }

    // 3. 处理其他基础类型验证（string/object/boolean 等）
    if (schema.type && typeof data !== schema.type) {
      errors.push(`路径 ${path}：期望${schema.type}类型，实际${typeof data}（值：${JSON.stringify(data)}）`);
      return false;
    }

    // 4. 处理对象类型验证（验证属性是否符合 properties 规范）
    if (schema.type === 'object' && schema.properties) {
      // 遍历 schema 定义的所有属性
      for (const [prop, propSchema] of Object.entries(schema.properties)) {
        const currentPath = path ? `${path}.${prop}` : prop; // 对象属性路径（如 metadata.templateId）

        // 验证必需属性是否存在
        if (schema.required && schema.required.includes(prop) && !(prop in data)) {
          errors.push(`路径 ${currentPath}：缺少必需属性`);
          isValid = false;
        }

        // 若属性存在，验证属性值是否符合子 schema 规范
        if (prop in data) {
          if (!validateWithErrors(data[prop], propSchema, currentPath)) {
            isValid = false;
          }
        }
      }
      return isValid;
    }

    // 5. 处理枚举值验证（适用于非 integer 类型的枚举，如 string 枚举）
    if (schema.enum && !schema.enum.includes(data)) {
      errors.push(`路径 ${path}：值${JSON.stringify(data)}不在允许的枚举列表中${JSON.stringify(schema.enum)}`);
      return false;
    }

    // 6. 处理数值范围验证（适用于 number 类型，非 integer）
    if (typeof data === 'number' && schema.type === 'number') {
      if (schema.minimum !== undefined && data < schema.minimum) {
        errors.push(`路径 ${path}：数值${data}小于最小值${schema.minimum}`);
        return false;
      }
      if (schema.maximum !== undefined && data > schema.maximum) {
        errors.push(`路径 ${path}：数值${data}大于最大值${schema.maximum}`);
        return false;
      }
    }

    return isValid;
  };

  // 执行验证逻辑
  const isValid = validateWithErrors(template, REPORT_TEMPLATE_SCHEMA);

  // 返回完整的验证报告
  return {
    isValid, // 是否通过验证（true/false）
    errors,  // 错误信息列表（数组）
    errorCount: errors.length, // 错误数量
    message: isValid 
      ? '模板验证通过' 
      : `模板验证失败，共发现${errors.length}个问题（详情：${errors.join('；')}）`
  };
};