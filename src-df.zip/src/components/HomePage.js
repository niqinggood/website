import React, { useState, useEffect, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Box,
  Container,
  Grid,
  Paper,
  Typography,
  Button,
  Card,
  CardContent,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Divider,
  Chip,
  Tabs,
  Tab,
  useTheme,
  CircularProgress,
  alpha,
  useMediaQuery,
} from '@mui/material';
import {
  Insights as InsightsIcon,
  ImportExport as ImportExportIcon,
  Schedule as ScheduleIcon,
  Settings as SettingsIcon,
  AdminPanelSettings as AdminIcon,
  BarChart as BarChartIcon,
  Help as HelpIcon,
  BugReport as BugReportIcon,
  Key as KeyIcon,
  TableChart as TableChartIcon,
  Security as SecurityIcon,
  Menu as MenuIcon,
  CheckCircle as CheckCircleIcon,
  People as PeopleIcon,
  Description as TemplateIcon,
} from '@mui/icons-material';
import { styled } from '@mui/material/styles';

// 样式组件
const StyledPaper = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(4),
  borderRadius: theme.shape.borderRadius * 2,
  transition: theme.transitions.create(['box-shadow', 'transform']),
  '&:hover': {
    boxShadow: theme.shadows[8],
    transform: 'translateY(-4px)'
  }
}));

const FeatureCard = styled(Card)(({ theme }) => ({
  minWidth: 280,
  maxWidth: 280,
  height: '100%',
  display: 'flex',
  flexDirection: 'column',
  transition: theme.transitions.create(['box-shadow', 'transform']),
  '&:hover': {
    boxShadow: theme.shadows[6],
    transform: 'translateY(-3px) scale(1.02)'
  },
  border: `1px solid ${theme.palette.divider}`,
  margin: theme.spacing(0, 1),
  background: `linear-gradient(145deg, ${theme.palette.background.paper} 0%, ${alpha(theme.palette.primary.light, 0.05)} 100%)`
}));

const StatBox = styled(Box)(({ theme }) => ({
  backgroundColor: theme.palette.background.paper,
  borderRadius: theme.shape.borderRadius * 2,
  padding: theme.spacing(2.5),
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
  boxShadow: theme.shadows[1],
  cursor: 'pointer',
  transition: theme.transitions.create(['box-shadow', 'transform']),
  border: `1px solid ${alpha(theme.palette.divider, 0.1)}`,
  '&:hover': {
    boxShadow: theme.shadows[4],
    transform: 'translateY(-2px)'
  }
}));

const HeroSection = styled(Box)(({ theme }) => ({
  background: `linear-gradient(135deg, ${theme.palette.primary.main} 0%, ${theme.palette.primary.dark} 100%)`,
  // color: theme.palette.primary.contrastText,
  borderRadius: theme.shape.borderRadius * 3,
  padding: theme.spacing(8, 4),
  marginBottom: theme.spacing(6),
  textAlign: 'center',
  position: 'relative',
  overflow: 'hidden',
  '&::before': {
    content: '""',
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    background: 'radial-gradient(circle at 30% 50%, rgba(255,255,255,0.1) 0%, transparent 60%)',
    pointerEvents: 'none'
  }
}));

// 功能卡片图标容器样式
const FeatureIconContainer = styled(Box)(({ theme }) => ({
  background: `linear-gradient(135deg, ${alpha(theme.palette.primary.light, 0.2)} 0%, ${alpha(theme.palette.primary.main, 0.1)} 100%)`,
  borderRadius: theme.shape.borderRadius * 2,
  height: 80,
  width: 80,
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  margin: theme.spacing(2, 'auto'),
  '& > svg': {
    fontSize: '2.5rem',
    color: theme.palette.primary.main
  }
}));

// 轮播容器样式
const CarouselContainer = styled(Box)(({ theme }) => ({
  overflow: 'hidden',
  position: 'relative',
  width: '100%',
  padding: theme.spacing(2, 0)
}));

const CarouselTrack = styled(Box)(({ theme, translateX }) => ({
  display: 'flex',
  transition: 'transform 0.5s ease-in-out',
  transform: `translateX(${translateX}px)`,
  padding: theme.spacing(2, 0)
}));

const HomePage = () => {
  const theme = useTheme();
  const navigate = useNavigate();
  const isSmallScreen = useMediaQuery(theme.breakpoints.down('md'));
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [tabValue, setTabValue] = useState(0);
  const [carouselPosition, setCarouselPosition] = useState(0);
  const [currentSlide, setCurrentSlide] = useState(0);
  const carouselRef = useRef(null);
  const trackRef = useRef(null);
  

  // 判断是否为管理员
  const isAdmin = localStorage.getItem('userRole') === 'admin';
  const user = JSON.parse(localStorage.getItem('user')) || null;

  // 模拟获取用户工作统计数据
  useEffect(() => {
    const fetchStats = async () => {
      try {
        await new Promise(resolve => setTimeout(resolve, 1000));
        // 模拟统计数据
        setStats({
          fetchCount: 128,
          templateCount: 45,
          biAnalysisCount: 73,
          reportCount: 29,
          scheduledTasks: 12,
          recentActivity: [
            { action: '创建了取数任务', time: '10分钟前', target: '用户增长分析' },
            { action: '生成了BI报告', time: '1小时前', target: '季度销售总结' },
            { action: '配置了定时任务', time: '昨天', target: '每日活跃用户报表' }
          ]
        });
      } catch (error) {
        console.error('获取统计数据失败:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchStats();
  }, []);

  // 自动轮播效果
  useEffect(() => {
    const interval = setInterval(() => {
      handleNext();
    }, 5000);
    return () => clearInterval(interval);
  }, [carouselPosition, currentSlide]);

  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  // 统计项点击跳转处理
  const handleStatClick = (path) => {
    navigate(path);
  };

  // 轮播控制
  const handleNext = () => {
    const containerWidth = carouselRef.current?.offsetWidth || 0;
    const trackWidth = trackRef.current?.offsetWidth || 0;
    const maxScroll = trackWidth - containerWidth;
    const slideCount = Math.ceil(features.length / (isSmallScreen ? 1 : 3));

    if (Math.abs(carouselPosition) + 300 > maxScroll - 100) {
      // 到达终点时跳转到开始
      setCarouselPosition(0);
      setCurrentSlide(0);
    } else {
      setCarouselPosition(prev => Math.max(prev - 300, -maxScroll));
      setCurrentSlide(prev => (prev + 1) % slideCount);
    }
  };

  const goToSlide = (index) => {
    const containerWidth = carouselRef.current?.offsetWidth || 0;
    setCarouselPosition(-index * 300);
    setCurrentSlide(index);
  };

  // 功能导航数据
  const features = [
    {
      title: 'BI & 数据分析',
      description: '强大的数据分析工具，支持数据探索、下钻分析和时间序列分析，帮助您发现数据价值。',
      icon: <InsightsIcon />,
      path: '/analysis'
    },
    {
      title: '模板定制',
      description: '通过预制模板快速生成取数配置，无需编写SQL，点击即可触发后台取数流程。',
      icon: <TemplateIcon />,
      path: '/config'
    },
    {
      title: '数据直通车',
      description: '直接对接数据集市，支持编写SQL查询语句，灵活统计和抽取所需数据。',
      icon: <ImportExportIcon />,
      path: '/dataexpress'
    },
    {
      title: '日常报表与定时任务',
      description: '自动生成各类报表，配置定时任务解放人工，提升数据处理效率。',
      icon: <ScheduleIcon />,
      path: '/custom-task'
    },
    {
      title: '调试及查询',
      description: '便捷的调试工具，帮助验证数据准确性，快速定位和解决问题。',
      icon: <BugReportIcon />,
      path: '/InferenceDebugPage'
    },
    {
      title: '个性化设置',
      description: '自定义页面样式和颜色主题，打造符合个人审美的工作环境。',
      icon: <SettingsIcon />,
      path: '/skin'
    }
  ];

  // 管理员功能
  const adminFeatures = [
    {
      title: 'SSO登录配置',
      description: '集成单点登录系统，统一用户认证入口，提升安全性和用户体验。',
      icon: <KeyIcon />
    },
    {
      title: '菜单与导航配置',
      description: '自定义顶部导航和功能菜单，根据组织需求调整系统结构。',
      icon: <MenuIcon />
    },
    {
      title: '取数模板管理',
      description: '创建和维护取数模板库，规范取数流程，提高团队效率。',
      icon: <TemplateIcon />
    },
    {
      title: '数据集市管理',
      description: '添加数据表并进行结构解析，维护数据字典，确保数据可追溯。',
      icon: <TableChartIcon />
    },
    {
      title: '用户权限管控',
      description: '精细化管理用户操作权限，确保数据安全，符合合规要求。',
      icon: <SecurityIcon />
    },
    {
      title: '用户与角色管理',
      description: '管理系统用户账户和角色分配，控制不同用户的访问权限。',
      icon: <PeopleIcon />
    }
  ];

  const slideCount = Math.ceil(features.length / (isSmallScreen ? 1 : 3));
  const heroContentPairs = [
    {
      title: "高效数据处理，赋能业务决策",
      subtitle: "整合数据获取、分析和自动化报表功能，提升工作效率，让数据驱动决策成为可能"
    },
    {
      title: "数据驱动增长，洞察创造价值",
      subtitle: "从复杂数据中挖掘商业洞察，优化业务流程，实现可持续增长"
    },
    {
      title: "智能分析平台，简化数据工作流",
      subtitle: "一站式数据处理解决方案，降低技术门槛，让每个人都能轻松使用数据"
    },
    {
      title: "连接数据，释放业务潜能",
      subtitle: "整合多源信息，为业务决策提供全方位支持"
    },
    {
      title: "自动化报表系统，聚焦核心决策",
      subtitle: "减少重复劳动，让团队专注于数据分析和业务决策，提升工作价值"
    },
    {
    title: "全链路数据整合，驱动智能决策",
    subtitle: "打通数据采集、处理、分析全流程，为业务提供实时、精准的决策依据"
  },
  {
    title: "可视化数据分析，洞察一目了然",
    subtitle: "通过直观图表呈现复杂数据，让隐藏趋势清晰可见，降低分析门槛"
  },
  {
    title: "定制化数据模板，高效复用流程",
    subtitle: "基于业务场景构建专属模板，一键复用分析流程，提升团队协作效率"
  },
  {
    title: "实时数据监控，把握业务动态",
    subtitle: "实时追踪关键指标变化，及时预警异常情况，抢占业务先机"
  },
  {
    title: "轻量化数据工具，随时随地办公",
    subtitle: "无需复杂配置，简单操作即可完成数据分析，支持多终端灵活使用"
  },
  {
    title: "安全合规数据管理，保障信息价值",
    subtitle: "严格遵循数据安全规范，在合规前提下充分释放数据资产价值"
  },
  {
    title: "自助式数据分析，赋能业务一线",
    subtitle: "无需专业技术背景，业务人员可自主完成数据查询与分析，快速响应需求"
  },
  {
    title: "趋势预测模型，前瞻业务走向",
    subtitle: "基于历史数据构建预测模型，提前洞察市场趋势，辅助战略规划"
  },
  {
    title: "跨部门数据协同，打破信息壁垒",
    subtitle: "统一数据标准与共享机制，促进跨团队协作，提升组织整体效率"
  },
  {
    title: "数据资产沉淀，加速数字化转型",
    subtitle: "系统沉淀分析经验与数据资产，为企业数字化转型提供坚实支撑"
  }, {
      title: "Talk is cheap, Show me the data",
      subtitle: "Data speaks louder than words. Make decisions based on facts, not assumptions."
    },
    {
      title: "Data is the new oil",
      subtitle: "Extract value from your data assets, refine insights, and fuel business growth."
    },
    {
      title: "In God we trust, all others bring data",
      subtitle: "Data-driven decision making reduces uncertainty and increases success rates."
    },
    {
      title: "Without data, you're just another person with an opinion",
      subtitle: "Turn subjective views into objective decisions through data analysis."
    },
    {
      title: "Data drives innovation",
      subtitle: "Discover patterns, predict trends, and create new opportunities with data insights."
    },
    {
      title: "What gets measured gets managed",
      subtitle: "Quantify your business performance to optimize processes and achieve goals."
    },
    {
      title: "Data never lies, but people do",
      subtitle: "Leverage accurate data to cut through biases and get to the truth."
    },
    {
      title: "The goal is to turn data into information, and information into insight",
      subtitle: "Transform raw data into actionable knowledge that drives better decisions."
    },
    {
      title: "Data is the lifeblood of modern business",
      subtitle: "Flow it, analyze it, optimize it – sustain and scale your competitive advantage"
    },
    {
      title: "Numbers don't lie, but they whisper",
      subtitle: "Amplify their voice through advanced analytics and uncover hidden truths"
    },
    {
      title: "Data without analysis is just noise",
      subtitle: "Transform raw information into strategic signals that guide your next move"
    },
    {
      title: "The future belongs to data-driven organizations",
      subtitle: "Outthink, outmaneuver, and outperform with actionable intelligence"
    },
    {
      title: "Analytics is seeing what others don't",
      subtitle: "Turn patterns into predictions and insights into irreversible market advantages"
    },
    {
      title: "Data is power when you know how to use it",
      subtitle: "Unleash its full potential with tools that turn complexity into clarity"
    },
    {
      title: "In data we trust, in action we thrive",
      subtitle: "From insight to implementation – close the loop between analysis and results"
    },
    {
      title: "Good decisions come from experience. Experience comes from bad decisions. Data prevents both.",
      subtitle: "Shortcut the learning curve with predictive analytics and evidence-based strategies"
    },
    {
      title: "Data is the new currency; analytics is the bank",
      subtitle: "Deposit raw information, withdraw strategic value, compound competitive advantage"
    },
    {
      title: "What you measure, you can improve. What you improve, you can master.",
      subtitle: "Master your business landscape through precision measurement and targeted optimization"
    }
  ];
  const [heroContent, setHeroContent] = useState(heroContentPairs[0]);
  useEffect(() => {
    const randomIndex = Math.floor(Math.random() * heroContentPairs.length);
    setHeroContent(heroContentPairs[randomIndex]);
  }, []);

  return (
    <Container maxWidth="xl" sx={{ mt: 4, mb: 8 }}>
      {/* 英雄区域 */}
      <HeroSection>
        <Typography variant="h3" component="h2" gutterBottom sx={{ fontWeight: 700, position: 'relative',color: '#ffffff',textShadow: '0 1px 2px rgba(0,0,0,0.1)' }}>
           {heroContent['title']}
        </Typography>
        <Typography variant="h6" sx={{ maxWidth: 900, margin: '0 auto', mb: 6, opacity: 0.9, position: 'relative',color: '#f0f0f0', }}>
          {heroContent['subtitle']}
        </Typography>
        {/* <Button
          variant="contained"
          color="secondary"
          size="large"
          component={Link}
          to="/analysis"
          startIcon={<BarChartIcon />}
          sx={{
            position: 'relative',
            borderRadius: theme.shape.borderRadius * 4,
            px: 4,
            py: 1.5,
            fontSize: '1.1rem',
            background: `linear-gradient(45deg, ${theme.palette.secondary.main} 0%, ${theme.palette.secondary.dark} 100%)`,
            color : theme.palette.primary.main, // 文字使用主题主色
            boxShadow: `0 4px 15px 0 ${alpha(theme.palette.secondary.main, 0.5)}`,
            '&:hover': {
              background: `linear-gradient(45deg, ${theme.palette.secondary.dark} 0%, ${theme.palette.secondary.main} 100%)`,
              boxShadow: `0 6px 20px 0 ${alpha(theme.palette.secondary.main, 0.7)}`,
              color: '#f0f0f0',
            }
          }}
        >
          开始数据分析
        </Button> */}
<Button
  variant="contained"
  size="large"
  component={Link}
  to="/analysis"
  startIcon={<BarChartIcon sx={{ 
    color: theme.palette.primary.main,
    transition: 'transform 0.3s ease',
    '&:hover': {
      transform: 'scale(1.1) rotate(5deg)'
    }
  }} />}
  sx={{
    position: 'relative',
    borderRadius: theme.shape.borderRadius * 4,
    px: 4,
    py: 1.5,
    fontSize: '1.1rem',
    fontWeight: 600,
    letterSpacing: 0.8,
    textTransform: 'none',
    overflow: 'hidden',
    isolation: 'isolate',
    
    background: `linear-gradient(115deg, 
      ${theme.palette.secondary.main} 0%, 
      ${theme.palette.secondary.dark} 50%, 
      ${theme.palette.secondary.main} 100%)`,
    color:  theme.palette.primary.main, // 文字使用主题主色
    backgroundSize: '200% 100%',
    backgroundPosition: '100% 0',
    boxShadow: `0 6px 20px ${alpha(theme.palette.secondary.main, 0.4)},
                0 2px 8px ${alpha(theme.palette.secondary.dark, 0.2)}`,
    transition: 'all 0.5s cubic-bezier(0.4, 0, 0.2, 1)',
    
    // 光泽效果层
    '&::before': {
      content: '""',
      position: 'absolute',
      top: 0,
      left: '-100%',
      width: '100%',
      height: '100%',
      background: `linear-gradient(90deg, 
        transparent 0%, 
        ${alpha('#fff', 0.2)} 50%, 
        transparent 100%)`,
      transition: 'left 0.7s ease',
      zIndex: 1
    },
    
    // 悬浮效果
    '&:hover': {
      backgroundPosition: '0 0',
      transform: 'translateY(-2px) scale(1.02)',
      boxShadow: `0 12px 30px ${alpha(theme.palette.secondary.main, 0.6)},
                  0 4px 12px ${alpha(theme.palette.secondary.dark, 0.3)}`,
      color: theme.palette.primary.light,
      
      '&::before': {
        left: '100%'
      },
      
      '& .button-sparkle': {
        opacity: 1,
        transform: 'translateY(0)'
      }
    },
    
    // 点击效果
    '&:active': {
      transform: 'translateY(0) scale(0.98)',
      boxShadow: `0 4px 12px ${alpha(theme.palette.secondary.main, 0.4)}`
    }
  }}
>
  {/* 文字容器 */}
  <Box component="span" sx={{ position: 'relative', zIndex: 2 }}>
    开始数据分析
    
    {/* 微妙的粒子效果 */}
    <Box 
      className="button-sparkle"
      sx={{
        position: 'absolute',
        top: -8,
        right: -15,
        fontSize: '1.2rem',
        opacity: 0,
        transform: 'translateY(10px)',
        transition: 'all 0.5s ease',
        color: alpha('#fff', 0.8)
      }}
    >
    </Box>
  </Box>
  {/* 边框光泽效果 */}
  <Box sx={{
    position: 'absolute',
    inset: 0,
    borderRadius: theme.shape.borderRadius * 4,
    padding: '2px',
    background: `linear-gradient(45deg, 
      ${alpha(theme.palette.primary.main, 0.3)}, 
      ${alpha(theme.palette.secondary.main, 0.3)}, 
      ${alpha(theme.palette.primary.main, 0.3)})`,
    WebkitMask: 'linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0)',
    WebkitMaskComposite: 'xor',
    maskComposite: 'exclude',
    opacity: 0,
    transition: 'opacity 0.3s ease',
    
    '&:hover': {
      opacity: 1
    }
  }} />
</Button>
        
      </HeroSection>

      {/* 功能导航区 */}
      <Box sx={{ position: 'relative' }}>
        <Typography variant="h5" component="h2" gutterBottom sx={{ mb: 4, fontWeight: 600, display: 'flex', alignItems: 'center' }}>
          <InsightsIcon sx={{ mr: 1, color: theme.palette.primary.main }} />
          核心功能
        </Typography>

        {/* 轮播容器 */}
        <CarouselContainer ref={carouselRef}>
          {/* 轮播轨道 */}
          <CarouselTrack ref={trackRef} translateX={carouselPosition}>
            {features.map((feature, index) => (
              <Box key={index} sx={{ textDecoration: 'none', color: 'inherit' }}>
                <FeatureCard sx={{
                  cursor: 'pointer',
                  '&:hover': {
                    borderColor: theme.palette.primary.main,
                  }
                }} onClick={() => navigate(feature.path)}>
                  <FeatureIconContainer>
                    {feature.icon}
                  </FeatureIconContainer>

                  <CardContent sx={{ flexGrow: 1, p: 3, pt: 2, textAlign: 'center' }}>
                    <Typography gutterBottom variant="h6" component="div" sx={{ fontWeight: 600, mb: 1,color:theme.palette.primary.dark }}  >
                      {feature.title}
                    </Typography>
                    <Typography variant="body2" color="text.secondary" sx={{ lineHeight: 1.6 }}>
                      {feature.description}
                    </Typography>
                  </CardContent>

                  {/* 底部装饰性指示器 */}
                  <Box sx={{
                    height: 2,
                    width: '60%',
                    margin: '0 auto 16px',
                    backgroundColor: theme.palette.primary.light,
                    borderRadius: 1,
                    transition: 'width 0.3s ease',
                  }} />
                </FeatureCard>
              </Box>
            ))}
          </CarouselTrack>

          {/* 轮播指示器 */}
          <Box sx={{ display: 'flex', justifyContent: 'center', mt: 2 }}>
            {Array.from({ length: slideCount }).map((_, index) => (
              <Box
                key={index}
                sx={{
                  width: 8,
                  height: 8,
                  borderRadius: '50%',
                  margin: '0 4px',
                  cursor: 'pointer',
                  transition: 'all 0.3s ease',
                  backgroundColor: index === currentSlide
                    ? theme.palette.primary.main
                    : theme.palette.action.disabledBackground
                }}
                onClick={() => goToSlide(index)}
              />
            ))}
          </Box>
        </CarouselContainer>
      </Box>

      {/* 统计和活动区域 */}
      <Typography variant="h5" component="h2" gutterBottom sx={{ mt: 8, mb: 4, fontWeight: 600, display: 'flex', alignItems: 'center' }}>
        <BarChartIcon sx={{ mr: 1, color: theme.palette.primary.main }} />
        工作概览
      </Typography>
      <Box sx={{ mb: 8 }}>
        <Tabs 
          value={tabValue} 
          onChange={handleTabChange} 
          sx={{ mb: 4 }}
          TabIndicatorProps={{
            style: {
              height: 4,
              borderRadius: 2
            }
          }}
        >
          <Tab label="数据统计" />
          <Tab label="最近活动" />
        </Tabs>

        {loading ? (
          <Box sx={{ display: 'flex', justifyContent: 'center', p: 8 }}>
            <CircularProgress />
          </Box>
        ) : tabValue === 0 ? (
          <Grid container spacing={3}>
            <Grid item xs={12} sm={6} md={4} lg={2}>
              <StatBox onClick={() => handleStatClick('/dataexpress')}>
                <Box>
                  <Typography variant="body2" color="text.secondary" gutterBottom>取数次数</Typography>
                  <Typography variant="h4" component="div" sx={{ fontWeight: 700 }}>{stats.fetchCount}</Typography>
                </Box>
                <ImportExportIcon color="primary" fontSize="large" />
              </StatBox>
            </Grid>
            <Grid item xs={12} sm={6} md={4} lg={2}>
              <StatBox onClick={() => handleStatClick('/config')}>
                <Box>
                  <Typography variant="body2" color="text.secondary" gutterBottom>模板使用</Typography>
                  <Typography variant="h4" component="div" sx={{ fontWeight: 700 }}>{stats.templateCount}</Typography>
                </Box>
                <TemplateIcon color="primary" fontSize="large" />
              </StatBox>
            </Grid>
            <Grid item xs={12} sm={6} md={4} lg={2}>
              <StatBox onClick={() => handleStatClick('/analysis')}>
                <Box>
                  <Typography variant="body2" color="text.secondary" gutterBottom>BI分析</Typography>
                  <Typography variant="h4" component="div" sx={{ fontWeight: 700 }}>{stats.biAnalysisCount}</Typography>
                </Box>
                <InsightsIcon color="primary" fontSize="large" />
              </StatBox>
            </Grid>
            <Grid item xs={12} sm={6} md={4} lg={2}>
              <StatBox onClick={() => handleStatClick('/list')}>
                <Box>
                  <Typography variant="body2" color="text.secondary" gutterBottom>报表生成</Typography>
                  <Typography variant="h4" component="div" sx={{ fontWeight: 700 }}>{stats.reportCount}</Typography>
                </Box>
                <BarChartIcon color="primary" fontSize='large' />
              </StatBox>
            </Grid>
            <Grid item xs={12} sm={6} md={4} lg={2}>
              <StatBox onClick={() => handleStatClick('/list')}>
                <Box>
                  <Typography variant="body2" color="text.secondary" gutterBottom>定时任务</Typography>
                  <Typography variant="h4" component="div" sx={{ fontWeight: 700 }}>{stats.scheduledTasks}</Typography>
                </Box>
                <ScheduleIcon color="primary" fontSize="large" />
              </StatBox>
            </Grid>
            <Grid item xs={12} sm={6} md={4} lg={2}>
              <StatBox onClick={() => handleStatClick('/skin')}>
                <Box>
                  <Typography variant="body2" color="text.secondary" gutterBottom>当前样式</Typography>
                  <Typography variant="h4" component="div" sx={{ fontWeight: 700 }}>
                    { localStorage.getItem('appTheme') }
                  </Typography>
                </Box>
                <SettingsIcon color="primary" fontSize="large" />
              </StatBox>
            </Grid>
          </Grid>
        ) : (
          <Paper sx={{ p: 3, borderRadius: theme.shape.borderRadius * 2 }}>
            <Typography variant="subtitle1" sx={{ mb: 2, fontWeight: 600 }}>最近操作</Typography>
            <List>
              {stats.recentActivity.map((activity, index) => (
                <React.Fragment key={index}>
                  <ListItem>
                    <ListItemIcon>
                      <CheckCircleIcon color="success" />
                    </ListItemIcon>
                    <ListItemText
                      primary={`您${activity.action}`}
                      secondary={
                        <>
                          <Typography component="span" variant="body2" sx={{ fontWeight: 500 }}>
                            {activity.target}
                          </Typography>
                          {' · '}{activity.time}
                        </>
                      }
                    />
                  </ListItem>
                  {index < stats.recentActivity.length - 1 && <Divider />}
                </React.Fragment>
              ))}
            </List>
            <Button
              component={Link}
              to="/list"
              variant="outlined"
              size="small"
              sx={{ mt: 2, borderRadius: theme.shape.borderRadius * 2 }}
            >
              查看所有活动
            </Button>
          </Paper>
        )}
      </Box>

      {/* 管理员专区 */}
      {isAdmin && (
        <Box sx={{ mb: 8 }}>
          <StyledPaper sx={{ background: `linear-gradient(135deg, ${alpha(theme.palette.primary.light, 0.05)} 0%, ${alpha(theme.palette.primary.main, 0.1)} 100%)` }}>
            <Box sx={{ display: 'flex', alignItems: 'center', mb: 4 }}>
              <AdminIcon color="primary" fontSize="large" sx={{ mr: 2 }} />
              <Typography variant="h5" component="h2" sx={{ fontWeight: 600 }}>
                管理员功能
              </Typography>
            </Box>

            <Grid container spacing={4}>
              {adminFeatures.map((feature, index) => (
                <Grid item xs={12} sm={6} md={4} key={index}>
                  <Box
                    sx={{
                      p: 3,
                      border: `1px solid ${theme.palette.divider}`,
                      borderRadius: theme.shape.borderRadius * 2,
                      height: '100%',
                      display: 'flex',
                      flexDirection: 'column',
                      transition: theme.transitions.create(['box-shadow']),
                      '&:hover': {
                        boxShadow: theme.shadows[3]
                      },
                      background: theme.palette.background.paper
                    }}
                  >
                    <Box sx={{
                      background: `linear-gradient(135deg, ${alpha(theme.palette.primary.light, 0.2)} 0%, ${alpha(theme.palette.primary.main, 0.1)} 100%)`,
                      borderRadius: '50%',
                      p: 1.5,
                      width: 'fit-content',
                      mb: 2,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center'
                    }}>
                      {React.cloneElement(feature.icon, { 
                        sx: { color: theme.palette.primary.main, fontSize: '1.8rem' } 
                      })}
                    </Box>
                    <Typography variant="h6" sx={{ mb: 1, fontWeight: 600 }}>
                      {feature.title}
                    </Typography>
                    <Typography variant="body2" color="text.secondary" sx={{ flexGrow: 1, lineHeight: 1.6 }}>
                      {feature.description}
                    </Typography>
                    <Button
                      variant="contained"
                      color="primary"
                      size="small"
                      sx={{ mt: 2, alignSelf: 'flex-start', borderRadius: theme.shape.borderRadius * 2 }}
                      onClick={() => navigate('/admin')}
                    >
                      管理设置
                    </Button>
                  </Box>
                </Grid>
              ))}
            </Grid>
          </StyledPaper>
        </Box>
      )}

      {/* 帮助与支持 */}
      <Box>
        <Paper sx={{ 
          p: 4, 
          borderRadius: theme.shape.borderRadius * 2,
          background: `linear-gradient(135deg, ${alpha(theme.palette.primary.light, 0.05)} 0%, ${alpha(theme.palette.primary.main, 0.1)} 100%)`
        }}>
          <Box sx={{ display: 'flex', alignItems: 'center', mb: 3 }}>
            <HelpIcon color="primary" fontSize="large" sx={{ mr: 2 }} />
            <Typography variant="h6" sx={{ fontWeight: 600 }}>需要帮助？</Typography>
          </Box>
          <Typography variant="body1" sx={{ mb: 3 }}>
            查看平台使用文档，了解更多功能细节和最佳实践。
          </Typography>
          <Button
            component={Link}
            to="/help"
            variant="contained"
            startIcon={<HelpIcon />}
            sx={{ borderRadius: theme.shape.borderRadius * 2 }}
          >
            前往帮助中心
          </Button>
        </Paper>
      </Box>
    </Container>
  );
};

export default HomePage;