import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  Box,
  Typography,
  Card,
  CardContent,
  Grid,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Button,
  Chip,
  CircularProgress,
  Divider,
  List,
  ListItem,
  ListItemText,
  ListItemSecondaryAction,
  IconButton,
  Tooltip,
  Paper
} from '@mui/material';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, Legend,
  ResponsiveContainer, PieChart, Pie, Cell
} from 'recharts';
import { ArrowBack, ArrowForward, Refresh, Delete, BarChart as BarChartIcon, PieChart as PieChartIcon } from '@mui/icons-material';
import axios from 'axios';

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8', '#82ca9d'];

const DrillDownAnalysis = ({ data, fileName, columns, onLoading }) => {
  // 状态管理
  const [loading, setLoading] = useState(false);
  const [analysisData, setAnalysisData] = useState({
    dimensions: [],
    measures: [],
    drillData: [],
    total: 0,
    currentLevel: 0,
    availableDimensions: []
  });
  
  // 配置状态
  const [dimension, setDimension] = useState('');
  const [measure, setMeasure] = useState('');
  const [aggregation, setAggregation] = useState('count');
  const [chartType, setChartType] = useState('bar');
  const [drillPath, setDrillPath] = useState([]);
  const [filters, setFilters] = useState([]);

  // 提取数值型列作为度量
  const measureColumns = useMemo(() => {
    if (!data || data.length === 0) return [];
    return columns.filter(col => {
      const sampleValue = data[0][col];
      return !isNaN(parseFloat(sampleValue)) && isFinite(sampleValue);
    });
  }, [data, columns]);

  // 提取非数值型列作为维度
  const dimensionColumns = useMemo(() => {
    if (!data || data.length === 0) return [];
    return columns.filter(col => !measureColumns.includes(col));
  }, [data, measureColumns]);

  // 执行下钻分析
  const executeDrillDown = useCallback(async (action = 'init', drillValue = null) => {
  if (!fileName || !dimension) return;

  // 重置状态（初始化时）
  if (action === 'init') {
    setAnalysisData(prev => ({
      ...prev,
      drillData: [],
      totalGroups: 0,
      loadedGroups: 0,
      isFinished: false,
      currentChunk: 0
    }));
  }

  setLoading(true);
  onLoading(true);
  
  try {
    let currentChunk = 0;
    let isFinished = false;
    const allGroups = [];

    // 如果是继续加载下一分片，从已有状态获取当前分片索引
    if (action === 'continue' && analysisData.currentChunk) {
      currentChunk = analysisData.currentChunk;
    }

    // 循环加载所有分片
    while (!isFinished) {
      const payload = {
        file_name: fileName,
        dimension: dimension,
        measure: measure,
        aggregation: aggregation,
        drill_path: drillPath,
        filters: filters,
        action: action,
        drill_value: drillValue,
        // 新增：传递当前分片索引
        chunk_index: currentChunk
      };

      const response = await axios.post('/api/bi/drilldown', payload);

      if (!response.data.success) {
        throw new Error(response.data.error || '下钻分析失败');
      }

      // 累计所有分片数据
      allGroups.push(...response.data.data || []);
      
      // 更新状态
      setAnalysisData(prev => ({
        ...prev,
        drillData: allGroups,
        totalGroups: response.data.total_groups || 0,
        loadedGroups: response.data.loaded_groups || 0,
        isFinished: response.data.is_finished || false,
        currentChunk: currentChunk,
        currentLevel: response.data.current_level || 0,
        availableDimensions: response.data.available_dimensions || []
      }));

      // 检查是否需要继续加载下一分片
      isFinished = response.data.is_finished || false;
      if (!isFinished) {
        currentChunk++;
      }
    }

  } catch (error) {
    console.error('下钻分析错误:', error);
    alert('获取下钻数据失败: ' + (error.response?.data?.error || error.message));
    // 错误状态处理
    setAnalysisData(prev => ({
      ...prev,
      isFinished: true
    }));
  } finally {
    setLoading(false);
    onLoading(false);
  }
}, [fileName, dimension, measure, aggregation, drillPath, filters, onLoading, analysisData.currentChunk]);

// 进度展示组件（配合分片加载）
const DrillDownProgress = () => {
  const { totalGroups, loadedGroups, isFinished, loading } = analysisData;
  
  if (!loading || isFinished) return null;
  
  return (
    <div className="drilldown-progress">
      <CircularProgress size={20} />
      <span className="progress-text">
        加载中 {loadedGroups}/{totalGroups} 分组
      </span>
    </div>
  );
};

// 下钻控制按钮（支持手动触发继续加载）
const DrillDownControls = () => {
  const { isFinished, loading } = analysisData;
  
  return (
    <div className="drilldown-controls">
      <Button 
        variant="outlined" 
        onClick={() => executeDrillDown('continue')}
        disabled={loading || isFinished}
      >
        加载更多
      </Button>
    </div>
  );
};

  // 初始化分析
  useEffect(() => {
    if (dimension) {
      executeDrillDown('init');
    }
  }, [dimension, measure, aggregation, executeDrillDown]);

  // 处理下钻操作
  const handleDrillDown = (item) => {
    if (analysisData.availableDimensions.length === 0) return;
    
    const nextDimension = analysisData.availableDimensions[0];
    const newDrillPath = [...drillPath, { 
      dimension: dimension, 
      value: item.dimensionValue,
      nextDimension: nextDimension
    }];
    
    setDrillPath(newDrillPath);
    setDimension(nextDimension);
    executeDrillDown('drill', item.dimensionValue);
  };

  // 处理返回上一级
  const handleDrillUp = () => {
    if (drillPath.length === 0) return;
    
    const lastStep = drillPath[drillPath.length - 1];
    const newDrillPath = drillPath.slice(0, -1);
    
    setDrillPath(newDrillPath);
    setDimension(lastStep.dimension);
    executeDrillDown('rollup', lastStep.value);
  };

  // 处理重置分析
  const handleResetAnalysis = () => {
    setDrillPath([]);
    setDimension('');
    setMeasure('');
    setAnalysisData({
      dimensions: [],
      measures: [],
      drillData: [],
      total: 0,
      currentLevel: 0,
      availableDimensions: []
    });
  };

  // 准备图表数据
  const prepareChartData = () => {
    return analysisData.drillData.map(item => ({
      name: item.dimensionValue,
      value: item.measureValue,
      count: item.count,
      rawValue: item.rawValue
    }));
  };

  // 获取聚合类型显示名称
  const getAggregationName = () => {
    const names = {
      'count': '计数',
      'sum': '求和',
      'avg': '平均值',
      'min': '最小值',
      'max': '最大值',
      'std': '标准差',
      'var': '方差'
    };
    return names[aggregation] || aggregation;
  };

  // 渲染钻取路径
  const renderDrillPath = () => (
    <Box sx={{ display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: 1, mb: 2 }}>
      <Chip label="根节点" size="small" color="primary" />
      
      {drillPath.map((step, index) => (
        <React.Fragment key={index}>
          <ArrowForward fontSize="small" color="action" />
          <Chip 
            label={`${step.dimension}: ${step.value}`}
            size="small"
            onDelete={() => {
              // 回滚到指定层级
              setDrillPath(drillPath.slice(0, index));
              setDimension(step.dimension);
              executeDrillDown('rollup', step.value);
            }}
          />
        </React.Fragment>
      ))}
    </Box>
  );

  // 渲染图表
  const renderChart = () => {
    const chartData = prepareChartData();
    
    return (
      <Box sx={{ height: 400, mb: 3 }}>
        <ResponsiveContainer width="100%" height="100%">
          {chartType === 'bar' ? (
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis 
                dataKey="name" 
                angle={-45} 
                textAnchor="end" 
                height={60}
                tick={{ fontSize: 12 }}
              />
              <YAxis tick={{ fontSize: 12 }} />
              <RechartsTooltip
                formatter={(value, name) => [
                  value.toLocaleString(),
                  name === 'value' ? getAggregationName() : '样本数'
                ]}
                labelFormatter={(label) => `维度值: ${label}`}
              />
              <Legend />
              <Bar 
                dataKey="value" 
                name={getAggregationName()}
                fill={COLORS[0]}
                onClick={(data) => analysisData.availableDimensions.length > 0 && handleDrillDown(data)}
              />
            </BarChart>
          ) : (
            <PieChart>
              <Pie
                data={chartData}
                cx="50%"
                cy="50%"
                labelLine={false}
                outerRadius={150}
                fill="#8884d8"
                dataKey="value"
                nameKey="name"
                label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(1)}%`}
                onClick={(data) => analysisData.availableDimensions.length > 0 && handleDrillDown(data)}
              >
                {chartData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <RechartsTooltip
                formatter={(value, name, props) => [
                  value.toLocaleString(),
                  `${getAggregationName()} (${props.payload.count}条数据)`
                ]}
              />
              <Legend />
            </PieChart>
          )}
        </ResponsiveContainer>
      </Box>
    );
  };

  // 渲染数据列表
  const renderDataList = () => (
    <Paper elevation={0} sx={{ maxHeight: 300, overflow: 'auto', border: '1px solid #e0e0e0' }}>
      <List dense>
        {analysisData.drillData.map((item, index) => (
          <ListItem 
            key={index}
            button={analysisData.availableDimensions.length > 0}
            onClick={() => analysisData.availableDimensions.length > 0 && handleDrillDown(item)}
            secondaryAction={
              analysisData.availableDimensions.length > 0 && (
                <ListItemSecondaryAction>
                  <Tooltip title="下钻分析">
                    <IconButton edge="end" size="small">
                      <ArrowForward />
                    </IconButton>
                  </Tooltip>
                </ListItemSecondaryAction>
              )
            }
          >
            <ListItemText
              primary={item.dimensionValue}
              secondary={`${getAggregationName()}: ${item.measureValue.toLocaleString()} (样本数: ${item.count})`}
            />
          </ListItem>
        ))}
      </List>
    </Paper>
  );

  return (
    <Card>
      <CardContent>
        <Typography variant="h6" gutterBottom>下钻分析</Typography>
        
        {/* 配置区域 */}
        <Grid container spacing={2} mb={3}>
          {/* 维度选择 */}
          <Grid item xs={12} md={4}>
            <FormControl fullWidth size="small">
              <InputLabel>分析维度</InputLabel>
              <Select
                value={dimension}
                label="分析维度"
                onChange={(e) => setDimension(e.target.value)}
                sx={{ width: 200 }} 
                disabled={loading}
              >
                {dimensionColumns.map(col => (
                  <MenuItem key={col} value={col}>{col}</MenuItem>
                ))}
              </Select>
            </FormControl>
          </Grid>
          
          {/* 度量选择 */}
          <Grid item xs={12} md={3}>
            <FormControl fullWidth size="small">
              <InputLabel>分析度量</InputLabel>
              <Select
                value={measure}
                label="分析度量"
                sx={{ width: 200 }} 
                onChange={(e) => setMeasure(e.target.value)}
                disabled={loading}
              >
                <MenuItem value="">无度量(仅计数)</MenuItem>
                {measureColumns.map(col => (
                  <MenuItem key={col} value={col}>{col}</MenuItem>
                ))}
              </Select>
            </FormControl>
          </Grid>
          
          {/* 聚合方式 */}
          <Grid item xs={12} md={3}>
            <FormControl fullWidth size="small">
              <InputLabel>聚合方式</InputLabel>
              <Select
                value={aggregation}
                label="聚合方式"
                sx={{ width: 200 }} 
                onChange={(e) => setAggregation(e.target.value)}
                disabled={loading || !measure}
              >
                {measure ? [
                  <MenuItem key="sum" value="sum">求和</MenuItem>,
                  <MenuItem key="avg" value="avg">平均值</MenuItem>,
                  <MenuItem key="min" value="min">最小值</MenuItem>,
                  <MenuItem key="max" value="max">最大值</MenuItem>,
                  <MenuItem key="std" value="std">标准差</MenuItem>,
                  <MenuItem key="var" value="var">方差</MenuItem>
                ] : (
                  <MenuItem key="count" value="count">计数</MenuItem>
                )}
              </Select>
            </FormControl>
          </Grid>
          
          {/* 图表类型 */}
          <Grid item xs={12} md={2}>
            <Box display="flex" gap={1}>
              <Tooltip title="柱状图">
                <IconButton
                  size="small"
                  color={chartType === 'bar' ? 'primary' : 'default'}
                  onClick={() => setChartType('bar')}
                >
                  <BarChartIcon />
                </IconButton>
              </Tooltip>
              <Tooltip title="饼图">
                <IconButton
                  size="small"
                  color={chartType === 'pie' ? 'primary' : 'default'}
                  onClick={() => setChartType('pie')}
                >
                  <PieChartIcon />
                </IconButton>
              </Tooltip>
              <Tooltip title="刷新数据">
                <IconButton
                  size="small"
                  onClick={() => executeDrillDown('refresh')}
                  disabled={loading}
                >
                  <Refresh />
                </IconButton>
              </Tooltip>
            </Box>
          </Grid>
        </Grid>
        
        <Divider sx={{ my: 2 }} />
        
        {/* 钻取路径 */}
        {dimension && (
          <Box mb={3}>
            <Box display="flex" justifyContent="space-between" alignItems="center" mb={1}>
              <Typography variant="subtitle2">当前钻取路径:</Typography>
              <Box>
                <Button
                  startIcon={<ArrowBack />}
                  size="small"
                  disabled={drillPath.length === 0 || loading}
                  onClick={handleDrillUp}
                  sx={{ mr: 1 }}
                >
                  返回上一级
                </Button>
                <Button
                  startIcon={<Delete />}
                  size="small"
                  disabled={drillPath.length === 0 || loading}
                  onClick={handleResetAnalysis}
                >
                  重置分析
                </Button>
              </Box>
            </Box>
            {renderDrillPath()}
          </Box>
        )}
        
        {/* 加载状态 */}
        {loading ? (
          <Box display="flex" justifyContent="center" alignItems="center" minHeight="300px">
            <CircularProgress />
            <Typography variant="body1" sx={{ ml: 2 }}>正在分析数据...</Typography>
          </Box>
        ) : !dimension ? (
          <Box display="flex" justifyContent="center" alignItems="center" minHeight="300px">
            <Typography variant="body1" color="text.secondary">
              请选择分析维度开始下钻分析
            </Typography>
          </Box>
        ) : analysisData.drillData.length === 0 ? (
          <Box display="flex" justifyContent="center" alignItems="center" minHeight="300px">
            <Typography variant="body1" color="text.secondary">
              没有找到数据，请尝试调整分析条件
            </Typography>
          </Box>
        ) : (
          <>
            {/* 统计信息 */}
            <Grid container spacing={2} mb={3}>
              <Grid item xs={12} sm={4}>
                <Typography variant="body2">
                  <strong>数据总量:</strong> {analysisData.total.toLocaleString()}
                </Typography>
              </Grid>
              <Grid item xs={12} sm={4}>
                <Typography variant="body2">
                  <strong>当前维度:</strong> {dimension}
                </Typography>
              </Grid>
              <Grid item xs={12} sm={4}>
                <Typography variant="body2">
                  <strong>聚合方式:</strong> {getAggregationName()}
                </Typography>
              </Grid>
            </Grid>
            
            {/* 图表展示 */}
            {renderChart()}
            
            {/* 数据列表 */}
            {renderDataList()}
            
            {/* 下钻提示 */}
            {analysisData.availableDimensions.length > 0 && (
              <Typography variant="body2" color="text.secondary" sx={{ mt: 2, textAlign: 'center' }}>
                点击数据项可继续下钻到 {analysisData.availableDimensions.join(', ')} 维度
              </Typography>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );
};

export default DrillDownAnalysis;


// import React, { useState, useEffect, useCallback, useMemo } from 'react';
// import {
//   Box,
//   Typography,
//   Card,
//   CardContent,
//   Grid,
//   FormControl,
//   InputLabel,
//   Select,
//   MenuItem,
//   Button,
//   Chip,
//   CircularProgress,
//   Divider,
//   List,
//   ListItem,
//   ListItemText,
//   ListItemSecondaryAction,
//   IconButton,
//   Tooltip,
//   Paper
// } from '@mui/material';
// import {
//   BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, Legend,
//   ResponsiveContainer, PieChart, Pie, Cell
// } from 'recharts';
// import { ArrowBack, ArrowForward, Refresh, Delete, BarChart as BarChartIcon, PieChart as PieChartIcon } from '@mui/icons-material';
// import axios from 'axios';

// const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8', '#82ca9d'];

// const DrillDownAnalysis = ({ data, fileName, columns, onLoading }) => {
//   // 状态管理
//   const [loading, setLoading] = useState(false);
//   const [analysisData, setAnalysisData] = useState({
//     drillData: [],
//     total: 0,
//     totalGroups: 0,
//     loadedGroups: 0,
//     isFinished: false,
//     currentChunk: 0,
//     currentLevel: 0,
//     availableDimensions: []
//   });
  
//   // 配置状态
//   const [dimension, setDimension] = useState('');
//   const [measure, setMeasure] = useState('');
//   const [aggregation, setAggregation] = useState('count');
//   const [chartType, setChartType] = useState('bar');
//   const [drillPath, setDrillPath] = useState([]); // 钻取路径：[{dimension, value}]
//   const [filters, setFilters] = useState([]);
  

//   // 提取数值型列作为度量
//   const measureColumns = useMemo(() => {
//     if (!data || data.length === 0) return [];
//     return columns.filter(col => {
//       const sampleValue = data[0][col];
//       return !isNaN(parseFloat(sampleValue)) && isFinite(sampleValue);
//     });
//   }, [data, columns]);

//   // 提取非数值型列作为维度
//   const dimensionColumns = useMemo(() => {
//     if (!data || data.length === 0) return [];
//     return columns.filter(col => !measureColumns.includes(col));
//   }, [data, measureColumns]);

//   // 执行下钻分析（核心函数）
//   const executeDrillDown = useCallback(async (action = 'init', drillValue = null) => {
//     if (!fileName || !dimension) return;

//     // 初始化时重置状态
//     if (action === 'init') {
//       setAnalysisData(prev => ({
//         ...prev,
//         drillData: [],
//         totalGroups: 0,
//         loadedGroups: 0,
//         isFinished: false,
//         currentChunk: 0
//       }));
//     }

//     setLoading(true);
//     onLoading(true);
    
//     try {
//       let currentChunk = analysisData.currentChunk || 0;
//       let isFinished = false;
//       const allGroups = [...analysisData.drillData]; // 保留已有数据

//       // 循环加载所有分片
//       while (!isFinished) {
//         const payload = {
//           file_name: fileName,
//           dimension: dimension,
//           measure: measure,
//           aggregation: aggregation,
//           drill_path: drillPath, // 与后端DrillStep结构匹配：{dimension, value}
//           filters: filters,      // 与后端Filter结构匹配：{column, type, value, value2}
//           action: action,
//           drill_value: drillValue,
//           chunk_index: currentChunk
//         };

//         const response = await axios.post('/api/bi/drilldown', payload);

//         if (!response.data.success) {
//           throw new Error(response.data.error || '下钻分析失败');
//         }

//         // 累计分片数据
//         allGroups.push(...response.data.data || []);
        
//         // 更新状态
//         setAnalysisData(prev => ({
//           ...prev,
//           drillData: allGroups,
//           total: response.data.total || 0,
//           totalGroups: response.data.total_groups || 0,
//           loadedGroups: response.data.loaded_groups || 0,
//           isFinished: response.data.is_finished || false,
//           currentChunk: currentChunk,
//           currentLevel: response.data.current_level || 0,
//           availableDimensions: response.data.available_dimensions || []
//         }));

//         // 检查是否需要继续加载
//         isFinished = response.data.is_finished || false;
//         if (!isFinished) {
//           currentChunk++;
//         }
//       }

//     } catch (error) {
//       console.error('下钻分析错误:', error);
//       alert('获取下钻数据失败: ' + (error.response?.data?.error || error.message));
//       setAnalysisData(prev => ({ ...prev, isFinished: true }));
//     } finally {
//       setLoading(false);
//       onLoading(false);
//     }
//   }, [fileName, dimension, measure, aggregation, drillPath, filters, onLoading, analysisData]);

//   // 进度展示组件
//   const DrillDownProgress = () => {
//     const { totalGroups, loadedGroups, isFinished, loading } = analysisData;
//     if (!loading || isFinished) return null;
    
//     return (
//       <Box display="flex" alignItems="center" gap={1} sx={{ mt: 2, justifyContent: 'center' }}>
//         <CircularProgress size={20} />
//         <Typography variant="body2">
//           加载中 {loadedGroups}/{totalGroups} 分组
//         </Typography>
//       </Box>
//     );
//   };

//   // 加载更多按钮
// const DrillDownControls = () => {
//   const { isFinished, loading, totalGroups, loadedGroups } = analysisData;
//   if (totalGroups <= loadedGroups) return null;
  
//   return (
//     <Box sx={{ mt: 2, textAlign: 'center' }}>
//       <Button 
//         variant="outlined" 
//         onClick={() => executeDrillDown('continue')}
//         disabled={loading || isFinished}
//         size="small"
//       >
//         加载更多
//       </Button>
//     </Box>
//   );
// };

//   // 初始化分析
//   useEffect(() => {
//     if (dimension) {
//       executeDrillDown('init');
//     }
//   }, [dimension, measure, aggregation, executeDrillDown]);

//   // 下钻操作
//   const handleDrillDown = (item) => {
//     if (analysisData.availableDimensions.length === 0) return;
    
//     const nextDimension = analysisData.availableDimensions[0];
//     const newDrillPath = [...drillPath, { 
//       dimension: dimension, 
//       value: item.dimensionValue
//     }];
    
//     setDrillPath(newDrillPath);
//     setDimension(nextDimension);
//     executeDrillDown('drill', item.dimensionValue);
//   };

//   // 回滚操作
//   const handleDrillUp = () => {
//     if (drillPath.length === 0) return;
    
//     const lastStep = drillPath[drillPath.length - 1];
//     const newDrillPath = drillPath.slice(0, -1);
    
//     setDrillPath(newDrillPath);
//     setDimension(lastStep.dimension);
//     executeDrillDown('rollup', lastStep.value);
//   };

//   // 重置分析
//   const handleResetAnalysis = () => {
//     setDrillPath([]);
//     setDimension('');
//     setMeasure('');
//     setAnalysisData({
//       drillData: [],
//       total: 0,
//       totalGroups: 0,
//       loadedGroups: 0,
//       isFinished: false,
//       currentChunk: 0,
//       currentLevel: 0,
//       availableDimensions: []
//     });
//   };

//   // 准备图表数据
//   const prepareChartData = () => {
//     return analysisData.drillData.map(item => ({
//       name: item.dimensionValue,
//       value: item.measureValue,
//       count: item.count
//     }));
//   };

//   // 聚合方式显示名称
//   const getAggregationName = () => {
//     const names = {
//       'count': '计数',
//       'sum': '求和',
//       'avg': '平均值',
//       'min': '最小值',
//       'max': '最大值',
//       'std': '标准差',
//       'var': '方差'
//     };
//     return names[aggregation] || aggregation;
//   };

//   // 渲染钻取路径
//   const renderDrillPath = () => (
//     <Box sx={{ display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: 1, mb: 2 }}>
//       <Chip label="根节点" size="small" color="primary" />
      
//       {drillPath.map((step, index) => (
//         <React.Fragment key={index}>
//           <ArrowForward fontSize="small" color="action" />
//           <Chip 
//             label={`${step.dimension}: ${step.value}`}
//             size="small"
//             onDelete={() => {
//               // 回滚到指定层级
//               setDrillPath(drillPath.slice(0, index));
//               setDimension(step.dimension);
//               executeDrillDown('rollup', step.value);
//             }}
//           />
//         </React.Fragment>
//       ))}
//     </Box>
//   );

//   // 渲染图表
//   const renderChart = () => {
//     const chartData = prepareChartData();
//     if (chartData.length === 0) return null;
    
//     return (
//       <Box sx={{ height: 400, mb: 3 }}>
//         <ResponsiveContainer width="100%" height="100%">
//           {chartType === 'bar' ? (
//             <BarChart data={chartData}>
//               <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
//               <XAxis 
//                 dataKey="name" 
//                 angle={-45} 
//                 textAnchor="end" 
//                 height={60}
//                 tick={{ fontSize: 12 }}
//               />
//               <YAxis tick={{ fontSize: 12 }} />
//               <RechartsTooltip
//                 formatter={(value, name) => [
//                   value.toLocaleString(),
//                   name === 'value' ? getAggregationName() : '样本数'
//                 ]}
//               />
//               <Bar 
//                 dataKey="value" 
//                 name={getAggregationName()}
//                 fill={COLORS[0]}
//                 onClick={(data) => handleDrillDown(data)}
//               />
//             </BarChart>
//           ) : (
//             <PieChart>
//               <Pie
//                 data={chartData}
//                 cx="50%"
//                 cy="50%"
//                 labelLine={false}
//                 outerRadius={150}
//                 dataKey="value"
//                 nameKey="name"
//                 label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(1)}%`}
//                 onClick={(data) => handleDrillDown(data)}
//               >
//                 {chartData.map((entry, index) => (
//                   <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
//                 ))}
//               </Pie>
//               <RechartsTooltip />
//             </PieChart>
//           )}
//         </ResponsiveContainer>
//       </Box>
//     );
//   };

//   // 渲染数据列表
//   const renderDataList = () => (
//     <Paper elevation={0} sx={{ maxHeight: 300, overflow: 'auto', border: '1px solid #e0e0e0', mt: 2 }}>
//       <List dense>
//         {analysisData.drillData.map((item, index) => (
//           <ListItem 
//             key={index}
//             button={analysisData.availableDimensions.length > 0}
//             onClick={() => handleDrillDown(item)}
//             secondaryAction={
//               analysisData.availableDimensions.length > 0 && (
//                 <ListItemSecondaryAction>
//                   <Tooltip title="下钻分析">
//                     <IconButton edge="end" size="small">
//                       <ArrowForward />
//                     </IconButton>
//                   </Tooltip>
//                 </ListItemSecondaryAction>
//               )
//             }
//           >
//             <ListItemText
//               primary={item.dimensionValue}
//               secondary={`${getAggregationName()}: ${item.measureValue.toLocaleString()} (样本数: ${item.count})`}
//             />
//           </ListItem>
//         ))}
//       </List>
//     </Paper>
//   );

//   return (
//     <Card>
//       <CardContent>
//         <Typography variant="h6" gutterBottom>下钻分析</Typography>
        
//         {/* 配置区域 */}
//         <Grid container spacing={2} mb={3}>
//           <Grid item xs={12} md={3}>
//             <FormControl fullWidth size="small">
//               <InputLabel>分析维度</InputLabel>
//               <Select
//                 value={dimension}
//                 label="分析维度"
//                 onChange={(e) => setDimension(e.target.value)}
//                 disabled={loading}
//               >
//                 {dimensionColumns.map(col => (
//                   <MenuItem key={col} value={col}>{col}</MenuItem>
//                 ))}
//               </Select>
//             </FormControl>
//           </Grid>
          
//           <Grid item xs={12} md={3}>
//             <FormControl fullWidth size="small">
//               <InputLabel>分析度量</InputLabel>
//               <Select
//                 value={measure}
//                 label="分析度量"
//                 onChange={(e) => setMeasure(e.target.value)}
//                 disabled={loading}
//               >
//                 <MenuItem value="">无度量(仅计数)</MenuItem>
//                 {measureColumns.map(col => (
//                   <MenuItem key={col} value={col}>{col}</MenuItem>
//                 ))}
//               </Select>
//             </FormControl>
//           </Grid>
          
//           <Grid item xs={12} md={3}>
//             <FormControl fullWidth size="small">
//               <InputLabel>聚合方式</InputLabel>
//               <Select
//                 value={aggregation}
//                 label="聚合方式"
//                 onChange={(e) => setAggregation(e.target.value)}
//                 disabled={loading || !measure}
//               >
//                 {measure ? [
//                   <MenuItem key="sum" value="sum">求和</MenuItem>,
//                   <MenuItem key="avg" value="avg">平均值</MenuItem>,
//                   <MenuItem key="min" value="min">最小值</MenuItem>,
//                   <MenuItem key="max" value="max">最大值</MenuItem>,
//                 ] : (
//                   <MenuItem key="count" value="count">计数</MenuItem>
//                 )}
//               </Select>
//             </FormControl>
//           </Grid>
          
//           <Grid item xs={12} md={3}>
//             <Box display="flex" gap={1} alignItems="center" height="100%">
//               <Tooltip title="柱状图">
//                 <IconButton size="small" color={chartType === 'bar' ? 'primary' : 'default'} onClick={() => setChartType('bar')}>
//                   <BarChartIcon />
//                 </IconButton>
//               </Tooltip>
//               <Tooltip title="饼图">
//                 <IconButton size="small" color={chartType === 'pie' ? 'primary' : 'default'} onClick={() => setChartType('pie')}>
//                   <PieChartIcon />
//                 </IconButton>
//               </Tooltip>
//               <Tooltip title="刷新">
//                 <IconButton size="small" onClick={() => executeDrillDown('refresh')} disabled={loading}>
//                   <Refresh />
//                 </IconButton>
//               </Tooltip>
//             </Box>
//           </Grid>
//         </Grid>
        
//         <Divider sx={{ my: 2 }} />
        
//         {/* 钻取路径和控制按钮 */}
//         {dimension && (
//           <Box mb={3}>
//             <Box display="flex" justifyContent="space-between" alignItems="center" mb={1}>
//               <Typography variant="subtitle2">当前钻取路径:</Typography>
//               <Box>
//                 <Button
//                   startIcon={<ArrowBack />}
//                   size="small"
//                   disabled={drillPath.length === 0 || loading}
//                   onClick={handleDrillUp}
//                   sx={{ mr: 1 }}
//                 >
//                   返回上一级
//                 </Button>
//                 <Button
//                   startIcon={<Delete />}
//                   size="small"
//                   disabled={drillPath.length === 0 || loading}
//                   onClick={handleResetAnalysis}
//                 >
//                   重置
//                 </Button>
//               </Box>
//             </Box>
//             {renderDrillPath()}
//           </Box>
//         )}
        
//         {/* 加载状态 */}
//         {loading ? (
//           <Box display="flex" justifyContent="center" alignItems="center" minHeight="300px">
//             <CircularProgress />
//             <Typography variant="body1" sx={{ ml: 2 }}>正在分析数据...</Typography>
//           </Box>
//         ) : !dimension ? (
//           <Box display="flex" justifyContent="center" alignItems="center" minHeight="300px">
//             <Typography variant="body1" color="text.secondary">请选择分析维度开始下钻</Typography>
//           </Box>
//         ) : analysisData.drillData.length === 0 ? (
//           <Box display="flex" justifyContent="center" alignItems="center" minHeight="300px">
//             <Typography variant="body1" color="text.secondary">未找到数据，请调整条件</Typography>
//           </Box>
//         ) : (
//           <>
//             {/* 统计信息 */}
//             <Grid container spacing={2} mb={3}>
//               <Grid item xs={12} sm={4}>
//                 <Typography variant="body2"><strong>数据总量:</strong> {analysisData.total.toLocaleString()}</Typography>
//               </Grid>
//               <Grid item xs={12} sm={4}>
//                 <Typography variant="body2"><strong>当前维度:</strong> {dimension}</Typography>
//               </Grid>
//               <Grid item xs={12} sm={4}>
//                 <Typography variant="body2"><strong>聚合方式:</strong> {getAggregationName()}</Typography>
//               </Grid>
//             </Grid>
            
//             {/* 图表和数据 */}
//             {renderChart()}
//             {renderDataList()}
//             <DrillDownProgress />
//             <DrillDownControls />
            
//             {/* 下钻提示 */}
//             {analysisData.availableDimensions.length > 0 && (
//               <Typography variant="body2" color="text.secondary" sx={{ mt: 2, textAlign: 'center' }}>
//                 点击数据项可继续下钻到 {analysisData.availableDimensions.join(', ')}
//               </Typography>
//             )}
//           </>
//         )}
//       </CardContent>
//     </Card>
//   );
// };

// export default DrillDownAnalysis;
