import React, { useState } from 'react';
import { 
  Box, Card, CardContent, CardHeader, Typography, Button, 
  TextField, Grid, Divider, IconButton, Snackbar, Alert 
} from '@mui/material';
import { 
  Add as PlusOutlined,  // 正确的Plus图标是Add
  Delete as MinusOutlined, 
  Save as SaveOutlined, 
  Visibility as EyeOutlined,
  ArrowBack as ArrowBackOutlined
} from '@mui/icons-material';
import axios from 'axios';

const CustomReportPage = () => {
  // 表单状态
  const [formData, setFormData] = useState({
    subject: '',
    summary: '',
    recipients: ''
  });
  
  // 存储成对的结构说明和SQL
  const [structures, setStructures] = useState([
    { id: '1', description: '', sql: '' }
  ]);
  
  // 预览相关状态
  const [previewData, setPreviewData] = useState(null);
  const [isPreview, setIsPreview] = useState(false);
  const [notification, setNotification] = useState({
    open: false,
    message: '',
    severity: 'success'
  });

  // 处理表单字段变化
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  // 处理结构字段变化
  const handleStructureChange = (id, field, value) => {
    setStructures(structures.map(item => 
      item.id === id ? { ...item, [field]: value } : item
    ));
  };

  // 添加新的结构对
  const addStructure = () => {
    const newId = (structures.length + 1).toString();
    setStructures([...structures, { id: newId, description: '', sql: '' }]);
  };

  // 删除结构对
  const removeStructure = (id) => {
    if (structures.length <= 1) {
      showNotification('至少保留一个结构', 'warning');
      return;
    }
    setStructures(structures.filter(item => item.id !== id));
  };

  // 显示通知
  const showNotification = (message, severity = 'success') => {
    setNotification({ open: true, message, severity });
  };

  // 关闭通知
  const handleCloseNotification = () => {
    setNotification(prev => ({ ...prev, open: false }));
  };

  // 验证表单
  const validateForm = () => {
    if (!formData.subject.trim()) {
      showNotification('请输入主题', 'error');
      return false;
    }
    
    if (!formData.recipients.trim()) {
      showNotification('请输入接收人', 'error');
      return false;
    }
    
    for (const structure of structures) {
      if (!structure.description.trim() || !structure.sql.trim()) {
        showNotification('请完善所有结构信息', 'error');
        return false;
      }
    }
    
    return true;
  };

  // 预览功能
  const handlePreview = () => {
    if (!validateForm()) return;
    
    setPreviewData({
      ...formData,
      structures: [...structures]
    });
    setIsPreview(true);
  };

  // 保存功能
  const handleSave = async () => {
    if (!validateForm()) return;
    
    try {
      // 准备提交的数据，符合统一的任务结构
      const taskData = {
        taskName: formData.subject,
        taskType: 'report', // 报表类型任务
        taskDetail: {
          summary: formData.summary,
          recipients: formData.recipients.split(',').map(r => r.trim()),
          structures: structures
        },
        // 其他默认值，由后端补充或留空
        result: '',
        detail: '',
        status: 'pending'
      };
      
      // 发送API请求保存任务
      const response = await axios.post('/api/tasks', taskData, {
        withCredentials: true
      });
      
      if (response.data.success) {
        showNotification('报表已保存');
        // 可以重置表单或跳转到任务列表
      } else {
        showNotification('保存失败: ' + (response.data.message || '未知错误'), 'error');
      }
    } catch (error) {
      console.error('保存报表失败:', error);
      showNotification('保存失败，请稍后重试', 'error');
    }
  };

  // 渲染表单
  const renderForm = () => (
    <Box>
      <Grid container spacing={3}>
        {/* 主题 */}
        <Grid item xs={12}>
          <TextField
            fullWidth
            label="主题"
            name="subject"
            value={formData.subject}
            onChange={handleInputChange}
            variant="outlined"
            required
          />
        </Grid>

        {/* 摘要 */}
        <Grid item xs={12}>
          <TextField
            fullWidth
            label="摘要"
            name="summary"
            value={formData.summary}
            onChange={handleInputChange}
            variant="outlined"
            multiline
            rows={2}
          />
        </Grid>

        {/* 接收人 */}
        <Grid item xs={12}>
          <TextField
            fullWidth
            label="接收人（逗号分隔）"
            name="recipients"
            value={formData.recipients}
            onChange={handleInputChange}
            variant="outlined"
            placeholder="例如：张三,李四,王五"
            required
          />
        </Grid>

        {/* 结构区域标题 */}
        <Grid item xs={12}>
          <Typography variant="h6" gutterBottom>
            数据结构
          </Typography>
          <Divider sx={{ mb: 2 }} />
        </Grid>

        {/* 结构区域 */}
        {structures.map((item, index) => (
          <Grid item xs={12} key={item.id}>
            <Card sx={{ mb: 3 }}>
              <CardContent>
                <Grid container spacing={2}>
                  <Grid item xs={12}>
                    <Typography variant="subtitle1" gutterBottom>
                      结构 {index + 1}
                    </Typography>
                  </Grid>
                  <Grid item xs={12}>
                    <TextField
                      fullWidth
                      label="结构说明"
                      value={item.description}
                      onChange={(e) => handleStructureChange(item.id, 'description', e.target.value)}
                      variant="outlined"
                      required
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <TextField
                      fullWidth
                      label="取数SQL/数据依赖"
                      value={item.sql}
                      onChange={(e) => handleStructureChange(item.id, 'sql', e.target.value)}
                      variant="outlined"
                      multiline
                      rows={3}
                      required
                    />
                  </Grid>
                  <Grid item xs={12} sx={{ display: 'flex', justifyContent: 'flex-end' }}>
                    <IconButton 
                      color="error" 
                      onClick={() => removeStructure(item.id)}
                      size="small"
                    >
                      <MinusOutlined />
                      <Typography variant="body2" sx={{ ml: 1 }}>删除此结构</Typography>
                    </IconButton>
                  </Grid>
                </Grid>
              </CardContent>
            </Card>
          </Grid>
        ))}

        {/* 添加结构按钮 */}
        <Grid item xs={12}>
          <Button
            variant="outlined"
            startIcon={<PlusOutlined />}
            onClick={addStructure}
            fullWidth
            sx={{ mb: 3 }}
          >
            添加结构
          </Button>
        </Grid>

        {/* 操作按钮 */}
        <Grid item xs={12} sx={{ display: 'flex', gap: 2, justifyContent: 'flex-end' }}>
          <Button
            variant="outlined"
            startIcon={<SaveOutlined />}
            onClick={handleSave}
          >
            保存
          </Button>
          <Button
            variant="contained"
            startIcon={<EyeOutlined />}
            onClick={handlePreview}
          >
            预览
          </Button>
        </Grid>
      </Grid>
    </Box>
  );

  // 渲染预览
  const renderPreview = () => (
    <Box>
      <Button 
        startIcon={<ArrowBackOutlined />} 
        onClick={() => setIsPreview(false)} 
        sx={{ mb: 2 }}
      >
        返回编辑
      </Button>
      
      <Card sx={{ mb: 2 }}>
        <CardHeader title="报表预览" />
        <CardContent>
          <Grid container spacing={3}>
            <Grid item xs={12}>
              <Typography variant="subtitle1" color="text.secondary">主题</Typography>
              <Typography variant="body1" sx={{ mb: 2 }}>{previewData.subject}</Typography>
            </Grid>
            
            <Grid item xs={12}>
              <Typography variant="subtitle1" color="text.secondary">摘要</Typography>
              <Typography variant="body1" sx={{ mb: 2 }}>{previewData.summary}</Typography>
            </Grid>
            
            <Grid item xs={12}>
              <Typography variant="subtitle1" color="text.secondary">接收人</Typography>
              <Typography variant="body1" sx={{ mb: 2 }}>{previewData.recipients}</Typography>
            </Grid>
            
            <Grid item xs={12}>
              <Typography variant="subtitle1" color="text.secondary">数据结构</Typography>
              {previewData.structures.map((item, index) => (
                <Card key={item.id} sx={{ mb: 2, p: 2 }} variant="outlined">
                  <Typography variant="body1" fontWeight="bold">
                    结构 {index + 1} 说明：
                  </Typography>
                  <Typography variant="body2" sx={{ mb: 2 }}>
                    {item.description}
                  </Typography>
                  
                  <Typography variant="body1" fontWeight="bold">
                    取数信息：
                  </Typography>
                  <Typography 
                    variant="body2" 
                    sx={{ 
                      fontFamily: 'monospace', 
                      whiteSpace: 'pre-wrap',
                      backgroundColor: '#f5f5f5',
                      p: 2,
                      borderRadius: 1
                    }}
                  >
                    {item.sql}
                  </Typography>
                </Card>
              ))}
            </Grid>
          </Grid>
        </CardContent>
      </Card>
    </Box>
  );

  return (
    <Box sx={{ maxWidth: 1000, margin: '0 auto', p: 3 }}>
      <Card>
        <CardHeader title="定制报表" />
        <CardContent>
          {isPreview ? renderPreview() : renderForm()}
        </CardContent>
      </Card>
      
      <Snackbar
        open={notification.open}
        autoHideDuration={6000}
        onClose={handleCloseNotification}
        anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
      >
        <Alert
          onClose={handleCloseNotification}
          severity={notification.severity}
        >
          {notification.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default CustomReportPage;

// import React, { useState } from 'react';
// import { Form, Input, Button, Card, Row, Col, message, Space } from 'antd';
// import { PlusOutlined, MinusOutlined, SaveOutlined, EyeOutlined } from '@ant-design/icons';

// const { TextArea } = Input;

// const CustomReportPage = () => {
//   // 表单实例
//   const [form] = Form.useForm();
  
//   // 存储成对的结构说明和SQL
//   const [structures, setStructures] = useState([
//     { id: '1', description: '', sql: '' }
//   ]);
  
//   // 预览相关状态
//   const [previewData, setPreviewData] = useState(null);
//   const [isPreview, setIsPreview] = useState(false);

//   // 添加新的结构对
//   const addStructure = () => {
//     const newId = (structures.length + 1).toString();
//     setStructures([...structures, { id: newId, description: '', sql: '' }]);
//   };

//   // 删除结构对
//   const removeStructure = (id) => {
//     if (structures.length <= 1) {
//       message.warning('至少保留一个结构');
//       return;
//     }
//     setStructures(structures.filter(item => item.id !== id));
//   };

//   // 处理输入变化
//   const handleInputChange = (id, field, value) => {
//     setStructures(structures.map(item => 
//       item.id === id ? { ...item, [field]: value } : item
//     ));
//   };

//   // 预览功能
//   const handlePreview = () => {
//     form.validateFields()
//       .then(values => {
//         setPreviewData({
//           ...values,
//           structures: [...structures]
//         });
//         setIsPreview(true);
//       })
//       .catch(() => {
//         message.error('请填写所有必填项');
//       });
//   };

//   // 保存功能
//   const handleSave = () => {
//     form.validateFields()
//       .then(values => {
//         // 这里可以添加实际保存逻辑，如调用API
//         const fullData = {
//           ...values,
//           structures: [...structures]
//         };
//         console.log('保存的数据:', fullData);
//         message.success('报表已保存');
//       })
//       .catch(() => {
//         message.error('请填写所有必填项');
//       });
//   };

//   // 渲染表单
//   const renderForm = () => (
//     <Form
//       form={form}
//       layout="vertical"
//       initialValues={{
//         subject: '',
//         summary: '',
//         recipients: ''
//       }}
//     >
//       {/* 主题 */}
//       <Form.Item
//         name="subject"
//         label="主题"
//         rules={[{ required: true, message: '请输入主题' }]}
//       >
//         <Input placeholder="请输入报表主题" />
//       </Form.Item>

//       {/* 摘要 */}
//       <Form.Item
//         name="summary"
//         label="摘要"
//         rules={[{ required: false, message: '请输入摘要' }]}
//       >
//         <TextArea rows={1} placeholder="请输入报表摘要" />
//       </Form.Item>

//       {/* 接收人 */}
//       <Form.Item
//         name="recipients"
//         label="接收人（逗号分隔）"
//         rules={[{ required: true, message: '请输入接收人' }]}
//       >
//         <Input placeholder="例如：张三,李四,王五" />
//       </Form.Item>

//       {/* 结构区域 */}
//       <div style={{ margin: '16px 0' }}>
//         {structures.map((item, index) => (
//           <Card key={item.id} style={{ marginBottom: 16 }}>
//             <Row gutter={16}>
//               <Col span={24}>
//                 <Form.Item
//                   label={`结构${index + 1}说明`}
//                   rules={[{ required: true, message: '请输入说明' }]}
//                 >
//                   <TextArea
//                     rows={1}
//                     placeholder="请输入结构说明"
//                     value={item.description}
//                     onChange={(e) => handleInputChange(item.id, 'description', e.target.value)}
//                   />
//                 </Form.Item>
//               </Col>
//               <Col span={24}>
//                 <Form.Item
//                   label={`结构 ${index + 1} 取数SQL/数据依赖`}
//                   rules={[{ required: true, message: '请输入SQL或数据依赖' }]}
//                 >
//                   <TextArea
//                     rows={3}
//                     placeholder="请输入取数SQL或数据依赖说明"
//                     value={item.sql}
//                     onChange={(e) => handleInputChange(item.id, 'sql', e.target.value)}
//                   />
//                 </Form.Item>
//               </Col>
//               <Col span={24} style={{ textAlign: 'right' }}>
//                 <Button
//                   type="text"
//                   danger
//                   icon={<MinusOutlined />}
//                   onClick={() => removeStructure(item.id)}
//                 >
//                   删除此结构
//                 </Button>
//               </Col>
//             </Row>
//           </Card>
//         ))}

//         <Button
//           type="dashed"
//           icon={<PlusOutlined />}
//           onClick={addStructure}
//           style={{ width: '100%' }}
//         >
//           添加结构
//         </Button>
//       </div>

//       {/* 操作按钮 */}
//       <Space>
//         <Button onClick={handleSave} icon={<SaveOutlined />}>
//           保存
//         </Button>
//         <Button type="primary" onClick={handlePreview} icon={<EyeOutlined />}>
//           预览
//         </Button>
//       </Space>
//     </Form>
//   );

//   // 渲染预览
//   const renderPreview = () => (
//     <div>
//       <Button onClick={() => setIsPreview(false)} style={{ marginBottom: 16 }}>
//         返回编辑
//       </Button>
      
//       <Card title="报表预览" style={{ marginBottom: 16 }}>
//         <div style={{ marginBottom: 16 }}>
//           <strong>主题：</strong>
//           <div>{previewData.subject}</div>
//         </div>
        
//         <div style={{ marginBottom: 16 }}>
//           <strong>摘要：</strong>
//           <div>{previewData.summary}</div>
//         </div>
        
//         <div style={{ marginBottom: 16 }}>
//           <strong>接收人：</strong>
//           <div>{previewData.recipients}</div>
//         </div>
        
//         <div>
//           <strong>数据结构：</strong>
//           {previewData.structures.map((item, index) => (
//             <Card key={item.id} style={{ margin: '10px 0', padding: '10px' }}>
//               <div style={{ marginBottom: 8 }}>
//                 <strong>结构 {index + 1} 说明：</strong>
//                 <div>{item.description}</div>
//               </div>
//               <div>
//                 <strong>结构 {index + 1} 取数信息：</strong>
//                 <div style={{ whiteSpace: 'pre-wrap', fontFamily: 'monospace' }}>{item.sql}</div>
//               </div>
//             </Card>
//           ))}
//         </div>
//       </Card>
//     </div>
//   );

//   return (
//     <div style={{ maxWidth: 800, margin: '20px auto', padding: '0 16px' }}>
//       <Card title="定制报表">
//         {isPreview ? renderPreview() : renderForm()}
//       </Card>
//     </div>
//   );
// };

// export default CustomReportPage;
    