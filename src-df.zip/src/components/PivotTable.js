import React, { useState, useEffect, useCallback } from 'react';
import {
  Box,
  Typography,
  Card,
  CardContent,
  Grid,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Button,
  Checkbox,
  FormGroup,
  FormControlLabel,
  Chip,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  CircularProgress,
  Divider
} from '@mui/material';
import axios from 'axios';

const PivotTable = ({ data, fileName, columns, onLoading }) => {
  // 状态管理
  const [loading, setLoading] = useState(false);
  const [pivotData, setPivotData] = useState(null);
  const [rowLabels, setRowLabels] = useState([]);
  const [colLabels, setColLabels] = useState([]);
  const [metrics, setMetrics] = useState([]);
  
  // 配置状态
  const [rowCols, setRowCols] = useState([]);
  const [colCols, setColCols] = useState([]);
  const [valueCols, setValueCols] = useState([]);
  const [aggregations, setAggregations] = useState({});
  const [filters, setFilters] = useState([]);
  const [selectedFilterColumn, setSelectedFilterColumn] = useState('');
  const [filterValues, setFilterValues] = useState([]);

  // 提取所有可用列
  const availableColumns = columns || [];
  
  // 获取筛选值
  const getFilterValues = useCallback((column) => {
    if (!data || !column) return [];
    const values = new Set();
    data.forEach(item => {
      if (item[column] !== undefined) {
        values.add(item[column]);
      }
    });
    return Array.from(values);
  }, [data]);

  // 当选择筛选列变化时更新筛选值
  useEffect(() => {
    if (selectedFilterColumn) {
      const values = getFilterValues(selectedFilterColumn);
      setFilterValues(values.map(v => ({ value: v, checked: false })));
    }
  }, [selectedFilterColumn, getFilterValues]);

  // 添加筛选条件
  const handleAddFilter = () => {
    if (!selectedFilterColumn) return;

    const selectedValues = filterValues
      .filter(fv => fv.checked)
      .map(fv => fv.value);

    if (selectedValues.length === 0) return;

    // 添加新筛选条件，替换同列的旧筛选
    setFilters([
      ...filters.filter(f => f.column !== selectedFilterColumn),
      { column: selectedFilterColumn, values: selectedValues }
    ]);
  };

  // 移除筛选条件
  const handleRemoveFilter = (column) => {
    setFilters(filters.filter(f => f.column !== column));
  };

  // 处理行/列选择变化
  const handleDimensionChange = (type, value) => {
    if (type === 'row') {
      setRowCols(value);
    } else if (type === 'column') {
      setColCols(value);
    } else if (type === 'value') {
      setValueCols(value);
      // 为新选中的值列设置默认聚合方式
      const newAggs = { ...aggregations };
      value.forEach(col => {
        if (newAggs[col] === undefined) {
          newAggs[col] = 'sum';
        }
      });
      setAggregations(newAggs);
    }
  };

  // 处理聚合方式变化
  const handleAggregationChange = (column, value) => {
    setAggregations({
      ...aggregations,
      [column]: value
    });
  };

  // 执行透视分析
  const runPivotAnalysis = useCallback(async () => {
    if (!fileName || valueCols.length === 0) return;

    setLoading(true);
    onLoading(true);
    
    try {
      const response = await axios.post('/analysis/bi/pivot', {
        file_name: fileName,
        rows: rowCols,
        columns: colCols,
        values: valueCols,
        filters: filters,
        aggregations: aggregations
      });

      if (response.data.success) {
        setPivotData(response.data.Data);
        setRowLabels(response.data.row_labels);
        setColLabels(response.data.col_labels);
        setMetrics(response.data.metrics);
      }
    } catch (error) {
      console.error('透视分析错误:', error);
      alert('获取透视表数据失败: ' + (error.response?.data?.error || error.message));
    } finally {
      setLoading(false);
      onLoading(false);
    }
  }, [fileName, rowCols, colCols, valueCols, filters, aggregations, onLoading]);

  // 手动刷新按钮点击事件
  const handleRefreshClick = () => {
    runPivotAnalysis();
  };

  return (
    <Card>
      <CardContent>
        <Typography variant="h6" gutterBottom>透视表分析</Typography>
        
        {/* 配置区域 */}
        <Grid container spacing={2} mb={3}>
          {/* 行维度选择 */}
          <Grid item xs={12} sm={3}>
            <FormControl fullWidth>
              <InputLabel>行维度</InputLabel>
              <Select
                multiple
                value={rowCols}
                label="行维度"
                onChange={(e) => handleDimensionChange('row', e.target.value)}
                renderValue={(selected) => selected.join(', ')}
              >
                {availableColumns.map(col => (
                  <MenuItem key={col} value={col}>{col}</MenuItem>
                ))}
              </Select>
            </FormControl>
          </Grid>
          
          {/* 列维度选择 */}
          <Grid item xs={12} sm={3}>
            <FormControl fullWidth>
              <InputLabel>列维度</InputLabel>
              <Select
                multiple
                value={colCols}
                label="列维度"
                onChange={(e) => handleDimensionChange('column', e.target.value)}
                renderValue={(selected) => selected.join(', ')}
              >
                {availableColumns.map(col => (
                  <MenuItem key={col} value={col}>{col}</MenuItem>
                ))}
              </Select>
            </FormControl>
          </Grid>
          
          {/* 值列选择 */}
          <Grid item xs={12} sm={3}>
            <FormControl fullWidth>
              <InputLabel>值列</InputLabel>
              <Select
                multiple
                value={valueCols}
                label="值列"
                onChange={(e) => handleDimensionChange('value', e.target.value)}
                renderValue={(selected) => selected.join(', ')}
              >
                {availableColumns.map(col => (
                  <MenuItem key={col} value={col}>{col}</MenuItem>
                ))}
              </Select>
            </FormControl>
          </Grid>
          
          {/* 刷新按钮 */}
          <Grid item xs={12} sm={3} display="flex" alignItems="flex-end">
            <Button
              variant="contained"
              color="primary"
              fullWidth
              onClick={handleRefreshClick}
            >
              生成透视表
            </Button>
          </Grid>
        </Grid>
        
        {/* 聚合方式选择 */}
        {valueCols.length > 0 && (
          <Grid container spacing={2} mb={3}>
            <Grid item xs={12}>
              <Typography variant="subtitle2">聚合方式:</Typography>
            </Grid>
            {valueCols.map(col => (
              <Grid item xs={12} sm={3} key={col}>
                <FormControl fullWidth>
                  <InputLabel>{col}</InputLabel>
                  <Select
                    value={aggregations[col] || 'sum'}
                    label={col}
                    onChange={(e) => handleAggregationChange(col, e.target.value)}
                  >
                    <MenuItem value="sum">求和</MenuItem>
                    <MenuItem value="avg">平均值</MenuItem>
                    <MenuItem value="count">计数</MenuItem>
                    <MenuItem value="min">最小值</MenuItem>
                    <MenuItem value="max">最大值</MenuItem>
                  </Select>
                </FormControl>
              </Grid>
            ))}
          </Grid>
        )}
        
        <Divider sx={{ my: 2 }} />
        
        {/* 筛选条件区域 */}
        <Box mb={3} p={2} border="1px solid #e0e0e0" borderRadius={1}>
          <Typography variant="subtitle2" gutterBottom>数据筛选:</Typography>

          <Grid container spacing={2} alignItems="center">
            <Grid item xs={12} sm={3}>
              <FormControl fullWidth>
                <InputLabel>选择筛选列</InputLabel>
                <Select
                  value={selectedFilterColumn}
                  label="选择筛选列"
                  onChange={(e) => setSelectedFilterColumn(e.target.value)}
                >
                  {availableColumns.map(col => (
                    <MenuItem key={col} value={col}>{col}</MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>

            {selectedFilterColumn && (
              <>
                <Grid item xs={12} sm={6}>
                  <Box
                    maxHeight={100}
                    overflow="auto"
                    border="1px solid #e0e0e0"
                    borderRadius={1}
                    p={1}
                  >
                    <FormGroup>
                      {filterValues.map(fv => (
                        <FormControlLabel
                          key={fv.value}
                          control={
                            <Checkbox
                              checked={fv.checked}
                              onChange={(e) => {
                                setFilterValues(filterValues.map(v =>
                                  v.value === fv.value ? { ...v, checked: e.target.checked } : v
                                ));
                              }}
                            />
                          }
                          label={fv.value}
                        />
                      ))}
                    </FormGroup>
                  </Box>
                </Grid>
                <Grid item xs={12} sm={3}>
                  <Button
                    variant="contained"
                    size="medium"
                    fullWidth
                    onClick={handleAddFilter}
                  >
                    添加筛选
                  </Button>
                </Grid>
              </>
            )}
          </Grid>

          {/* 已选筛选条件 */}
          {filters.length > 0 && (
            <Box mt={2}>
              {filters.map((filter, idx) => (
                <Chip
                  key={idx}
                  label={`${filter.column}: ${filter.values.join(', ')}`}
                  size="small"
                  sx={{ mr: 1, mb: 1 }}
                  onDelete={() => handleRemoveFilter(filter.column)}
                />
              ))}
            </Box>
          )}
        </Box>
        
        {/* 加载状态 */}
        {loading ? (
          <Box display="flex" justifyContent="center" alignItems="center" minHeight="300px">
            <CircularProgress />
            <Typography variant="body1" sx={{ ml: 2 }}>正在生成透视表...</Typography>
          </Box>
        ) : pivotData && pivotData.length > 0 ? (
          <Box overflow="auto" maxHeight="600px">
            <TableContainer component={Paper}>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell><strong>行/列</strong></TableCell>
                    {colLabels.map((col, idx) => (
                      <TableCell key={idx} align="right"><strong>{col}</strong></TableCell>
                    ))}
                  </TableRow>
                </TableHead>
                <TableBody>
                  {rowLabels.map((row, rowIdx) => {
                    // 找到当前行的所有数据
                    const rowData = pivotData.filter(item => item.row === row);
                    
                    return (
                      <TableRow key={rowIdx}>
                        <TableCell><strong>{row}</strong></TableCell>
                        {colLabels.map((col, colIdx) => {
                          // 找到当前单元格的数据
                          const cellData = rowData.find(item => item.col === col);
                          
                          if (!cellData) return <TableCell key={colIdx} align="right">-</TableCell>
                          
                          // 如果有多个指标，合并显示
                          if (metrics.length > 1) {
                            return (
                              <TableCell key={colIdx} align="right">
                                {metrics.map((metric, mIdx) => (
                                  <div key={mIdx}>
                                    {metric}: {cellData[metric].toFixed(2)}
                                  </div>
                                ))}
                              </TableCell>
                            );
                          }
                          
                          // 单个指标直接显示
                          const metric = metrics[0];
                          return (
                            <TableCell key={colIdx} align="right">
                              {cellData[metric].toFixed(2)}
                            </TableCell>
                          );
                        })}
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </TableContainer>
          </Box>
        ) : (
          <Box display="flex" justifyContent="center" alignItems="center" minHeight="300px">
            <Typography variant="body1" color="text.secondary">
              请选择行、列维度和值列，然后点击"生成透视表"按钮
            </Typography>
          </Box>
        )}
      </CardContent>
    </Card>
  );
};

export default PivotTable;
