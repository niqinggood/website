import React, { useMemo, useState } from "react";
import { scaleSequential } from "d3-scale";
import { interpolateTurbo } from "d3-scale-chromatic";
import { Card, CardContent, Typography, Tooltip, Select, MenuItem } from "@mui/material";

/**
 * WaferMap Component
 * @param {Array} data - 数据数组 [{ waferId, x, y, measurement, defect }]
 * @param {String} colorScheme - D3 色带 (默认 interpolateTurbo)
 */
export default function WaferMap({
  data = [],
  colorScheme = interpolateTurbo,
  size = 500, // SVG 尺寸
}) {
  const [activeWaferId, setActiveWaferId] = useState(
    data.length > 0 ? data[0].waferId : null
  );

  // 筛选当前 wafer 数据
  const waferData = useMemo(
    () => data.filter((d) => d.waferId === activeWaferId),
    [data, activeWaferId]
  );

  // 计算 die 坐标范围
  const [xMin, xMax, yMin, yMax] = useMemo(() => {
    if (waferData.length === 0) return [0, 1, 0, 1];
    return [
      Math.min(...waferData.map((d) => d.x)),
      Math.max(...waferData.map((d) => d.x)),
      Math.min(...waferData.map((d) => d.y)),
      Math.max(...waferData.map((d) => d.y)),
    ];
  }, [waferData]);

  // 颜色比例尺
  const colorScale = useMemo(() => {
    const values = waferData.map((d) => d.measurement).filter((v) => v != null);
    if (values.length === 0) return () => "#ccc";
    return scaleSequential([Math.min(...values), Math.max(...values)], colorScheme);
  }, [waferData, colorScheme]);

  // 坐标缩放
  const scaleX = (x) => ((x - xMin) / (xMax - xMin)) * size;
  const scaleY = (y) => ((y - yMin) / (yMax - yMin)) * size;

  return (
    <Card sx={{ p: 2, maxWidth: size + 100 }}>
      <Typography variant="h6" gutterBottom>
        Wafer Map
      </Typography>

      {/* Wafer 切换器 */}
      <Select
        value={activeWaferId || ""}
        onChange={(e) => setActiveWaferId(e.target.value)}
        size="small"
        sx={{ mb: 2 }}
      >
        {[...new Set(data.map((d) => d.waferId))].map((id) => (
          <MenuItem key={id} value={id}>
            Wafer {id}
          </MenuItem>
        ))}
      </Select>

      {/* SVG Wafer Map */}
      <svg width={size} height={size} style={{ border: "1px solid #eee" }}>
        {/* 硅片边界 */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={size / 2 - 2}
          fill="#fafafa"
          stroke="#333"
        />
        {/* die 绘制 */}
        {waferData.map((d, i) => {
          const cx = scaleX(d.x);
          const cy = scaleY(d.y);
          const dieSize = size / (xMax - xMin + 5); // 自适应 die 大小
          const fillColor =
            d.measurement != null ? colorScale(d.measurement) : "#ccc";
          return (
            <Tooltip
              key={i}
              title={
                <div>
                  <b>Die ({d.x},{d.y})</b>
                  <br />
                  Value: {d.measurement}
                  <br />
                  Defect: {d.defect ? "Yes" : "No"}
                </div>
              }
            >
              <rect
                x={cx - dieSize / 2}
                y={cy - dieSize / 2}
                width={dieSize}
                height={dieSize}
                fill={d.defect ? "red" : fillColor}
                stroke="#555"
                strokeWidth={0.3}
              />
            </Tooltip>
          );
        })}
      </svg>

      {/* 图例 */}
      <CardContent sx={{ mt: 2 }}>
        <Typography variant="subtitle2">Legend (Measurement)</Typography>
        <svg width={size * 0.8} height={20}>
          {Array.from({ length: 100 }).map((_, i) => (
            <rect
              key={i}
              x={(i / 100) * (size * 0.8)}
              y={0}
              width={(size * 0.8) / 100}
              height={20}
              fill={colorScale(
                (i / 100) *
                  (Math.max(...waferData.map((d) => d.measurement || 0)) -
                    Math.min(...waferData.map((d) => d.measurement || 0))) +
                  Math.min(...waferData.map((d) => d.measurement || 0))
              )}
            />
          ))}
        </svg>
      </CardContent>
    </Card>
  );
}
