import React, { useState, useEffect, useCallback } from 'react';
import {
  Box,
  Typography,
  Paper,
  Tabs,
  Tab,
  Button,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Grid,
  Card,
  CardContent,
  Chip,
  CircularProgress,
  Checkbox,
  FormGroup,
  FormControlLabel,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  IconButton,
  Divider,
  Menu,
  MenuItem as MuiMenuItem
} from'@mui/material';
import {
  FilterList,
  Layers,
  TrendingUp    as LineChartIcon,
  TableChart,
  Add,
  Remove,
  MoreVert
} from '@mui/icons-material';

import axios from 'axios';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend,
  LineChart, Line, PieChart, Pie, Cell, ResponsiveContainer
} from 'recharts';

import SPCChart from "./SPCChart"
import DrillDownAnalysis from "./DrillDownAnalysis"
import CustomReportBuilder from "./CustomReportBuilder"
// 工具函数：生成随机颜色
const generateColors = (count) => {
  const colors = [];
  for (let i = 0; i < count; i++) {
    const color = `#${Math.floor(Math.random() * 16777215).toString(16)}`;
    colors.push(color);
  }
  return colors;
};

// 筛选条件类型
const FILTER_TYPES = {
  EQUALS: 'equals',
  NOT_EQUALS: 'not_equals',
  GREATER_THAN: 'greater_than',
  LESS_THAN: 'less_than',
  GREATER_EQUALS: 'greater_equals',
  LESS_EQUALS: 'less_equals',
  BETWEEN: 'between',
  CONTAINS: 'contains'
};

// 筛选条件选项
const filterTypeOptions = [
  { value: FILTER_TYPES.EQUALS, label: '等于' },
  { value: FILTER_TYPES.NOT_EQUALS, label: '不等于' },
  { value: FILTER_TYPES.GREATER_THAN, label: '大于' },
  { value: FILTER_TYPES.LESS_THAN, label: '小于' },
  { value: FILTER_TYPES.GREATER_EQUALS, label: '大于等于' },
  { value: FILTER_TYPES.LESS_EQUALS, label: '小于等于' },
  { value: FILTER_TYPES.BETWEEN, label: '在区间内' },
  { value: FILTER_TYPES.CONTAINS, label: '包含' }
];

// 聚合类型
const AGGREGATION_TYPES = {
  SUM: 'sum',
  AVG: 'avg',
  COUNT: 'count',
  MIN: 'min',
  MAX: 'max',
  STD: 'std',
  VAR: 'var'
};

// 聚合选项
const aggregationOptions = [
  { value: AGGREGATION_TYPES.SUM, label: '求和' },
  { value: AGGREGATION_TYPES.AVG, label: '平均值' },
  { value: AGGREGATION_TYPES.COUNT, label: '计数' },
  { value: AGGREGATION_TYPES.MIN, label: '最小值' },
  { value: AGGREGATION_TYPES.MAX, label: '最大值' },
  { value: AGGREGATION_TYPES.STD, label: '标准差' },
  { value: AGGREGATION_TYPES.VAR, label: '方差' }
];

// 透视分析组件




const BIAnalysis = ({ analysisResult }) => {
  const [activeTab, setActiveTab] = useState(2);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedProcessVariables, setSelectedProcessVariables] = useState([]);
  const fileName = analysisResult?.file_name;
  const data = analysisResult?.preview_data || [];
  const columns = analysisResult && data.length > 0 ? Object.keys(data[0] || {}) : [];
  
  // 筛选出数值型列作为过程变量
  const numericColumns = columns.filter(col => {
    if (!data[0]) return false;
    const value = data[0][col];
    return !isNaN(parseFloat(value));
  });
  
  // 添加过程变量
  const handleAddProcessVariable = (col) => {
    if (!selectedProcessVariables.includes(col)) {
      setSelectedProcessVariables(prev => [...prev, col]);
    }
  };
  
  // 移除过程变量
  const handleRemoveProcessVariable = (col) => {
    setSelectedProcessVariables(prev => prev.filter(v => v !== col));
  };

  if (!analysisResult || !fileName) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="300px">
        <Typography variant="h6" color="text.secondary">
          请先上传数据文件以进行BI分析
        </Typography>
      </Box>
    );
  }

  return (
    <Box>
      {isLoading && (
        <Box display="flex" justifyContent="center" p={2}>
          <CircularProgress size={24} />
          <Typography variant="body2" sx={{ ml: 2 }}>处理中...</Typography>
        </Box>
      )}

      <Tabs value={activeTab} onChange={(e, newValue) => setActiveTab(newValue)} sx={{ mb: 3 }}>
        {/*<Tab label="透视分析" icon={<FilterList />} /> */}
        <Tab label="下钻分析" icon={<Layers />} />
        <Tab label="SPC统计" icon={<LineChartIcon />} />
        <Tab label="图表分析" icon={<TableChart />} />
      </Tabs>

  

      {activeTab === 0 && (
        <DrillDownAnalysis
          data={data}
          columns={columns}
          fileName={fileName}
          onLoading={setIsLoading}
        />
      )}

      {activeTab === 1 && (
        <Box>
          <Card sx={{ mb: 3 }}>
            <CardContent>
              <Typography variant="subtitle1" gutterBottom>选择过程变量</Typography>
              
              <Grid container spacing={2} alignItems="flex-end">
                <Grid item xs={12} md={6}>
                  <FormControl fullWidth size="small">
                    <InputLabel>添加过程变量</InputLabel>
                    <Select
                      value=""
                      label="添加过程变量"
                      sx={{ width: 200 }} 
                      onChange={(e) => {
                        handleAddProcessVariable(e.target.value);
                        e.target.value = "";
                      }}
                    >
                      {numericColumns
                        .filter(col => !selectedProcessVariables.includes(col))
                        .map(col => (
                          <MenuItem key={col} value={col}>{col}</MenuItem>
                        ))}
                    </Select>
                  </FormControl>
                </Grid>
              </Grid>
              
              {selectedProcessVariables.length > 0 && (
                <Box mt={2}>
                  <Typography variant="body2" color="text.secondary" gutterBottom>已选过程变量:</Typography>
                  {selectedProcessVariables.map((col) => (
                    <Chip
                      key={col}
                      label={col}
                      size="small"
                      sx={{ mr: 1, mb: 1 }}
                      onDelete={() => handleRemoveProcessVariable(col)}
                    />
                  ))}
                </Box>
              )}
            </CardContent>
          </Card>

          <div id="spc-container">
            <SPCChart
              data={data}
              processVariables={selectedProcessVariables}
              fileName={fileName}
              onLoading={setIsLoading}
            />
          </div>
        </Box>
      )}

      {activeTab === 2 && (
        <Box>
          <div id="reporter-container">
            <CustomReportBuilder
              data={data}
              fileName={fileName}
              onLoading={setIsLoading}
            />
          </div>
        </Box>
      )}

      
    </Box>
  );
};

export default BIAnalysis;