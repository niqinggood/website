import React from 'react';
import { Form, Input, Select, Button, InputNumber, Slider, Collapse, Divider, Row, Col, Alert, Tabs, Switch, Radio, Checkbox } from 'antd';
import { QuestionCircleOutlined } from '@ant-design/icons';

const { Option } = Select;
const { Panel } = Collapse;
const { TabPane } = Tabs;
const { TextArea } = Input;

const OptimizationConfig = ({ form }) => {
  const formValues = Form.useWatch([], form);
  const [showAdvanced, setShowAdvanced] = React.useState(false);
  const [activeTab, setActiveTab] = React.useState('training');
  const [variableType, setVariableType] = React.useState('continuous');

  const handleTabChange = (key) => {
    setActiveTab(key);
  };

  const toggleAdvanced = () => {
    setShowAdvanced(!showAdvanced);
  };

  const addVariable = () => {
    const variables = form.getFieldValue('variables') || [];
    form.setFieldsValue({
      variables: [...variables, {
        name: `var_${variables.length + 1}`,
        type: 'continuous',
        bounds: [0, 1],
        categories: []
      }]
    });
  };

  const removeVariable = (index) => {
    const variables = form.getFieldValue('variables') || [];
    variables.splice(index, 1);
    form.setFieldsValue({ variables: [...variables] });
  };

  const renderVariableInputs = (item, index) => {
    const type = form.getFieldValue(['variables', index, 'type']) || 'continuous';
    
    return (
      <Row gutter={16} key={index} style={{ marginBottom: 16, padding: 16, background: '#f9f9f9', borderRadius: 4 }}>
        <Col span={6}>
          <Form.Item
            name={[index, 'name']}
            label="变量名称"
            rules={[{ required: true, message: '请输入变量名称' }]}
          >
            <Input placeholder="例如: 温度" />
          </Form.Item>
        </Col>
        
        <Col span={4}>
          <Form.Item
            name={[index, 'type']}
            label="变量类型"
            rules={[{ required: true }]}
          >
            <Select onChange={(value) => form.setFieldsValue({ variables: [...form.getFieldValue('variables')] })}>
              <Option value="continuous">连续型</Option>
              <Option value="categorical">类别型</Option>
              <Option value="ordinal">有序型</Option>
            </Select>
          </Form.Item>
        </Col>
        
        {type === 'continuous' && (
          <Col span={8}>
            <Form.Item
              name={[index, 'bounds']}
              label="取值范围"
              rules={[{ required: true, message: '请设置取值范围' }]}
            >
              <InputNumber.Group compact style={{ width: '100%' }}>
                <Form.Item name={[index, 'bounds', 0]} noStyle>
                  <InputNumber placeholder="最小值" style={{ width: '50%' }} />
                </Form.Item>
                <Form.Item name={[index, 'bounds', 1]} noStyle>
                  <InputNumber placeholder="最大值" style={{ width: '50%' }} />
                </Form.Item>
              </InputNumber.Group>
            </Form.Item>
          </Col>
        )}
        
        {type === 'categorical' && (
          <Col span={8}>
            <Form.Item
              name={[index, 'bounds']}
              label="类别选项"
              tooltip="多个类别用逗号分隔"
              rules={[{ required: true, message: '请输入至少一个类别' }]}
            >
              <Select mode="tags" tokenSeparators={[',']} style={{ width: '100%' }} />
            </Form.Item>
          </Col>
        )}
        
        {type === 'ordinal' && (
          <Col span={8}>
            <Form.Item
              name={[index, 'bounds']}
              label="有序选项"
              tooltip="按顺序排列，从低到高"
              rules={[{ required: true, message: '请输入至少一个有序值' }]}
            >
              <Select mode="tags" tokenSeparators={[',']} style={{ width: '100%' }} />
            </Form.Item>
          </Col>
        )}
        
        <Col span={2}>
          <Button danger onClick={() => removeVariable(index)} style={{ marginTop: 30 }}>
            删除
          </Button>
        </Col>
      </Row>
    );
  };

  return (
    <Form form={form} layout="vertical">
      <Tabs activeKey={activeTab} onChange={handleTabChange}>
        <TabPane tab="训练配置" key="training">
          <Form.Item
            name="objective"
            label="优化目标"
            rules={[{ required: true, message: '请选择优化目标' }]}
          >
            <Radio.Group>
              <Radio.Button value="minimize">最小化</Radio.Button>
              <Radio.Button value="maximize">最大化</Radio.Button>
            </Radio.Group>
          </Form.Item>
          
          <Divider orientation="left">变量配置</Divider>
          <Form.List name="variables">
            {(fields, { add, remove }) => (
              <>
                {fields.map((field, index) => renderVariableInputs(field, index))}
                <Form.Item>
                  <Button type="dashed" onClick={addVariable} block>
                    添加变量
                  </Button>
                </Form.Item>
              </>
            )}
          </Form.List>
          
          <Divider orientation="left">数据配置</Divider>
          <Form.Item
            name="dataPath"
            label="训练数据路径"
            tooltip="CSV或JSON格式，包含变量和目标值"
            rules={[{ required: true, message: '请输入训练数据路径' }]}
          >
            <Input placeholder="例如: ./data/train.csv" />
          </Form.Item>
          
          <Form.Item
            name="targetColumn"
            label="目标列名"
            rules={[{ required: true, message: '请输入目标列名' }]}
          >
            <Input placeholder="例如: y" />
          </Form.Item>
          
          <Divider orientation="left">模型配置</Divider>
          <Form.Item
            name="surrogateModel"
            label="代理模型"
            initialValue="lightgbm"
            rules={[{ required: true }]}
          >
            <Select>
              <Option value="lightgbm">LightGBM</Option>
              <Option value="gaussian_process">高斯过程</Option>
              <Option value="random_forest">随机森林</Option>
              <Option value="xgboost">XGBoost</Option>
              <Option value="mlp">多层感知机</Option>
            </Select>
          </Form.Item>
          
          <Collapse>
            <Panel header="高级模型配置" key="model-advanced">
              {formValues?.surrogateModel === 'lightgbm' && (
                <Row gutter={16}>
                  <Col span={6}>
                    <Form.Item
                      name={['modelParams', 'num_leaves']}
                      label="叶子数量"
                      initialValue={31}
                    >
                      <InputNumber min={2} max={128} style={{ width: '100%' }} />
                    </Form.Item>
                  </Col>
                  <Col span={6}>
                    <Form.Item
                      name={['modelParams', 'learning_rate']}
                      label="学习率"
                      initialValue={0.1}
                    >
                      <InputNumber min={0.001} max={1} step={0.01} style={{ width: '100%' }} />
                    </Form.Item>
                  </Col>
                  <Col span={6}>
                    <Form.Item
                      name={['modelParams', 'n_estimators']}
                      label="树数量"
                      initialValue={100}
                    >
                      <InputNumber min={10} max={1000} style={{ width: '100%' }} />
                    </Form.Item>
                  </Col>
                  <Col span={6}>
                    <Form.Item
                      name={['modelParams', 'max_depth']}
                      label="最大深度"
                      initialValue={-1}
                    >
                      <InputNumber min={-1} max={20} style={{ width: '100%' }} />
                    </Form.Item>
                  </Col>
                </Row>
              )}
              
              {formValues?.surrogateModel === 'gaussian_process' && (
                <Row gutter={16}>
                  <Col span={8}>
                    <Form.Item
                      name={['modelParams', 'kernel']}
                      label="核函数"
                      initialValue="rbf"
                    >
                      <Select>
                        <Option value="rbf">RBF</Option>
                        <Option value="matern">Matern</Option>
                        <Option value="rational_quadratic">Rational Quadratic</Option>
                        <Option value="dot_product">Dot Product</Option>
                      </Select>
                    </Form.Item>
                  </Col>
                  <Col span={8}>
                    <Form.Item
                      name={['modelParams', 'alpha']}
                      label="Alpha"
                      initialValue={1e-10}
                    >
                      <InputNumber min={1e-20} max={1} step={1e-10} style={{ width: '100%' }} />
                    </Form.Item>
                  </Col>
                  <Col span={8}>
                    <Form.Item
                      name={['modelParams', 'n_restarts']}
                      label="优化重启次数"
                      initialValue={10}
                    >
                      <InputNumber min={1} max={50} style={{ width: '100%' }} />
                    </Form.Item>
                  </Col>
                </Row>
              )}
            </Panel>
          </Collapse>
        </TabPane>
        
        <TabPane tab="优化配置" key="optimization">
          <Form.Item
            name="optimizer"
            label="优化算法"
            initialValue="pso"
            rules={[{ required: true }]}
          >
            <Select>
              <Option value="pso">粒子群优化(PSO)</Option>
              <Option value="genetic">遗传算法</Option>
              <Option value="scipy_minimize">Scipy Minimize</Option>
              <Option value="cvxpy">CVXPY(凸优化)</Option>
              <Option value="bayesian">贝叶斯优化</Option>
            </Select>
          </Form.Item>
          
          {formValues?.optimizer === 'pso' && (
            <>
              <Row gutter={16}>
                <Col span={6}>
                  <Form.Item
                    name={['optimizerParams', 'swarmsize']}
                    label="粒子数量"
                    initialValue={50}
                  >
                    <InputNumber min={10} max={500} style={{ width: '100%' }} />
                  </Form.Item>
                </Col>
                <Col span={6}>
                  <Form.Item
                    name={['optimizerParams', 'maxiter']}
                    label="最大迭代次数"
                    initialValue={100}
                  >
                    <InputNumber min={10} max={1000} style={{ width: '100%' }} />
                  </Form.Item>
                </Col>
                <Col span={6}>
                  <Form.Item
                    name={['optimizerParams', 'omega']}
                    label="惯性权重"
                    initialValue={0.5}
                  >
                    <InputNumber min={0.1} max={1} step={0.1} style={{ width: '100%' }} />
                  </Form.Item>
                </Col>
                <Col span={6}>
                  <Form.Item
                    name={['optimizerParams', 'phip']}
                    label="个体最优权重"
                    initialValue={0.5}
                  >
                    <InputNumber min={0.1} max={2} step={0.1} style={{ width: '100%' }} />
                  </Form.Item>
                </Col>
              </Row>
              <Row gutter={16}>
                <Col span={6}>
                  <Form.Item
                    name={['optimizerParams', 'phig']}
                    label="全局最优权重"
                    initialValue={0.5}
                  >
                    <InputNumber min={0.1} max={2} step={0.1} style={{ width: '100%' }} />
                  </Form.Item>
                </Col>
                <Col span={6}>
                  <Form.Item
                    name={['optimizerParams', 'minstep']}
                    label="最小步长阈值"
                    initialValue={1e-8}
                  >
                    <InputNumber min={1e-20} max={1} step={1e-8} style={{ width: '100%' }} />
                  </Form.Item>
                </Col>
                <Col span={6}>
                  <Form.Item
                    name={['optimizerParams', 'minfunc']}
                    label="最小函数变化"
                    initialValue={1e-8}
                  >
                    <InputNumber min={1e-20} max={1} step={1e-8} style={{ width: '100%' }} />
                  </Form.Item>
                </Col>
              </Row>
            </>
          )}
          
          {formValues?.optimizer === 'genetic' && (
            <Row gutter={16}>
              <Col span={6}>
                <Form.Item
                  name={['optimizerParams', 'population_size']}
                  label="种群大小"
                  initialValue={50}
                >
                  <InputNumber min={10} max={500} style={{ width: '100%' }} />
                </Form.Item>
              </Col>
              <Col span={6}>
                <Form.Item
                  name={['optimizerParams', 'generations']}
                  label="代数"
                  initialValue={100}
                >
                  <InputNumber min={10} max={1000} style={{ width: '100%' }} />
                </Form.Item>
              </Col>
              <Col span={6}>
                <Form.Item
                  name={['optimizerParams', 'mutation_rate']}
                  label="变异率"
                  initialValue={0.1}
                >
                  <InputNumber min={0} max={1} step={0.01} style={{ width: '100%' }} />
                </Form.Item>
              </Col>
              <Col span={6}>
                <Form.Item
                  name={['optimizerParams', 'crossover_rate']}
                  label="交叉率"
                  initialValue={0.7}
                >
                  <InputNumber min={0} max={1} step={0.1} style={{ width: '100%' }} />
                </Form.Item>
              </Col>
            </Row>
          )}
          
          {formValues?.optimizer === 'scipy_minimize' && (
            <Row gutter={16}>
              <Col span={8}>
                <Form.Item
                  name={['optimizerParams', 'method']}
                  label="优化方法"
                  initialValue="L-BFGS-B"
                >
                  <Select>
                    <Option value="L-BFGS-B">L-BFGS-B</Option>
                    <Option value="SLSQP">SLSQP</Option>
                    <Option value="trust-constr">Trust-Constr</Option>
                    <Option value="Nelder-Mead">Nelder-Mead</Option>
                    <Option value="Powell">Powell</Option>
                    <Option value="CG">CG</Option>
                    <Option value="BFGS">BFGS</Option>
                    <Option value="TNC">TNC</Option>
                    <Option value="COBYLA">COBYLA</Option>
                  </Select>
                </Form.Item>
              </Col>
              <Col span={8}>
                <Form.Item
                  name={['optimizerParams', 'tol']}
                  label="容差"
                  initialValue={1e-6}
                >
                  <InputNumber min={1e-20} max={1} step={1e-6} style={{ width: '100%' }} />
                </Form.Item>
              </Col>
              <Col span={8}>
                <Form.Item
                  name={['optimizerParams', 'options']}
                  label="最大迭代"
                  initialValue={100}
                >
                  <InputNumber min={10} max={10000} style={{ width: '100%' }} />
                </Form.Item>
              </Col>
            </Row>
          )}
          
          {formValues?.optimizer === 'cvxpy' && (
            <Row gutter={16}>
              <Col span={8}>
                <Form.Item
                  name={['optimizerParams', 'solver']}
                  label="求解器"
                  initialValue="ECOS"
                >
                  <Select>
                    <Option value="ECOS">ECOS</Option>
                    <Option value="SCS">SCS</Option>
                    <Option value="CVXOPT">CVXOPT</Option>
                    <Option value="OSQP">OSQP</Option>
                    <Option value="MOSEK">MOSEK</Option>
                  </Select>
                </Form.Item>
              </Col>
              <Col span={8}>
                <Form.Item
                  name={['optimizerParams', 'max_iters']}
                  label="最大迭代"
                  initialValue={100}
                >
                  <InputNumber min={10} max={10000} style={{ width: '100%' }} />
                </Form.Item>
              </Col>
              <Col span={8}>
                <Form.Item
                  name={['optimizerParams', 'verbose']}
                  label="详细输出"
                  valuePropName="checked"
                  initialValue={false}
                >
                  <Switch />
                </Form.Item>
              </Col>
            </Row>
          )}
          
          <Divider orientation="left">约束条件</Divider>
          <Form.List name="constraints">
            {(fields, { add, remove }) => (
              <>
                {fields.map((field, index) => (
                  <Row gutter={16} key={field.key} style={{ marginBottom: 16 }}>
                    <Col span={8}>
                      <Form.Item
                        name={[index, 'expression']}
                        label="约束表达式"
                        rules={[{ required: true }]}
                      >
                        <Input placeholder="例如: x1 + x2 <= 10" />
                      </Form.Item>
                    </Col>
                    <Col span={4}>
                      <Form.Item
                        name={[index, 'type']}
                        label="类型"
                        initialValue="ineq"
                      >
                        <Select>
                          <Option value="ineq">不等式</Option>
                          <Option value="eq">等式</Option>
                        </Select>
                      </Form.Item>
                    </Col>
                    <Col span={2}>
                      <Button danger onClick={() => remove(index)} style={{ marginTop: 30 }}>
                        删除
                      </Button>
                    </Col>
                  </Row>
                ))}
                <Form.Item>
                  <Button type="dashed" onClick={() => add()} block>
                    添加约束
                  </Button>
                </Form.Item>
              </>
            )}
          </Form.List>
        </TabPane>
        
        <TabPane tab="逆向优化" key="inverse">
          <Alert
            message="逆向优化配置"
            description="通过指定部分变量和目标值，优化其他变量"
            type="info"
            showIcon
            style={{ marginBottom: 16 }}
          />
          
          <Form.Item
            name="inverseTarget"
            label="目标值"
            rules={[{ required: true }]}
          >
            <InputNumber style={{ width: '100%' }} />
          </Form.Item>
          
          <Form.Item
            name="inverseTolerance"
            label="容差"
            initialValue={0.01}
            tooltip="允许的目标值偏差"
          >
            <InputNumber min={0} max={1} step={0.001} style={{ width: '100%' }} />
          </Form.Item>
          
          <Divider orientation="left">固定变量</Divider>
          <Form.List name="fixedVariables">
            {(fields, { add, remove }) => (
              <>
                {fields.map((field, index) => (
                  <Row gutter={16} key={field.key} style={{ marginBottom: 16 }}>
                    <Col span={8}>
                      <Form.Item
                        name={[index, 'name']}
                        label="变量名"
                        rules={[{ required: true }]}
                      >
                        <Select placeholder="选择变量">
                          {(formValues?.variables || []).map((varItem, i) => (
                            <Option key={i} value={varItem.name}>{varItem.name}</Option>
                          ))}
                        </Select>
                      </Form.Item>
                    </Col>
                    <Col span={8}>
                      <Form.Item
                        name={[index, 'value']}
                        label="值"
                        rules={[{ required: true }]}
                      >
                        <Input placeholder="输入固定值" />
                      </Form.Item>
                    </Col>
                    <Col span={2}>
                      <Button danger onClick={() => remove(index)} style={{ marginTop: 30 }}>
                        删除
                      </Button>
                    </Col>
                  </Row>
                ))}
                <Form.Item>
                  <Button 
                    type="dashed" 
                    onClick={() => add()} 
                    block
                    disabled={!formValues?.variables || formValues.variables.length === 0}
                  >
                    添加固定变量
                  </Button>
                </Form.Item>
              </>
            )}
          </Form.List>
        </TabPane>
      </Tabs>
      
      <Divider />
      
      <Form.Item
        name="outputDir"
        label="输出目录"
        rules={[{ required: true }]}
      >
        <Input placeholder="例如: ./output/optimization" />
      </Form.Item>
    </Form>
  );
};

export default OptimizationConfig;