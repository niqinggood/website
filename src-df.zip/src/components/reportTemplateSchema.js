/**
 * 报告模板JSON Schema规范
 * 用于确保前端导出的模板与Python后端解析的格式一致
 * 遵循JSON Schema Draft 07标准
 */
export const REPORT_TEMPLATE_SCHEMA = {
  $schema: "http://json-schema.org/draft-07/schema#",
  type: "object",
  title: "自定义报告模板规范",
  description: "用于前后端互通的报告模板格式标准",

  properties: {
    // 模板元数据
    metadata: {
      type: "object",
      description: "模板的基本信息",
      properties: {
        templateId: {
          type: "string",
          description: "模板唯一标识，建议使用UUID或时间戳+随机数"
        },
        createdAt: {
          type: "string",
          format: "date-time",
          description: "模板创建时间，ISO 8601格式"
        },
        version: {
          type: "string",
          default: "1.0.0",
          description: "模板版本号，遵循语义化版本"
        },
        author: {
          type: "string",
          description: "模板创建者"
        },
        description: {
          type: "string",
          description: "模板描述信息"
        }
      },
      required: ["templateId", "createdAt"], // 必需的元数据字段
      additionalProperties: false // 不允许额外的元数据字段
    },

    // 报告结构定义
    structure: {
      type: "array",
      description: "报告的行-块结构定义",
      items: {
        type: "array", // 每一项是一行，包含多个块
        description: "报告中的一行，由多个块组成",
        items: {
          type: "object", // 每个块的配置
          description: "报告中的一个图表或表格块",
          properties: {
            id: {
              type: "string",
              description: "块的唯一标识"
            },
            type: {
              type: "string",
              enum: ["bar", "line", "pie", "table","radar","quadrant","kline","wafermap","gantt"],
              description: "块的类型：柱状图、折线图、饼图或表格"
            },
            title: {
              type: "string",
              description: "块的标题"
            },
            width: {
              type: "integer",
              enum: [1, 2, 3],
              description: "块的宽度占比：1=1/3，2=2/3，3=100%"
            },
            isConfigured: {
              type: "boolean",
              default: false,
              description: "块是否已完成配置"
            },
            config: {
              type: "object",
              description: "块的详细配置",
              properties: {
                xAxis: {
                  type: "string",
                  description: "X轴字段名"
                },
                yAxis: {
                  type: "array",
                  items: { type: "string" },
                  description: "Y轴字段名列表"
                },
                aggregations: {
                  type: "object",
                  additionalProperties: {
                    type: "string",
                    enum: ["count", "sum", "mean", "std", "min", "max", "median", "first", "last", "unique"]
                  },
                  description: "Y轴字段的聚合方式，键为字段名，值为聚合函数"
                },
                sampling: {
                  type: "boolean",
                  default: true,
                  description: "是否启用数据抽样"
                },
                sampleSize: {
                  type: "integer",
                  minimum: 10,
                  maximum: 5000,
                  default: 1000,
                  description: "抽样大小"
                }
              },
              additionalProperties: false
            }
          },
          required: ["id", "type", "width"], // 块的必需字段
          additionalProperties: false // 不允许块有额外字段
        }
      }
    }
  },

  required: ["metadata", "structure"], // 模板必须包含的顶级字段
  additionalProperties: false // 不允许模板有额外的顶级字段
};