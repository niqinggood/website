import React, { useState, useEffect, useRef } from 'react';
import { Card, Tabs, Table, Button, Input, Typography, Form, Upload, message, Popover, Tag, Tooltip, Divider } from 'antd';
import { UploadOutlined, DatabaseOutlined, QuestionCircleOutlined, SettingOutlined, EditOutlined } from '@ant-design/icons';
import axios from 'axios';
import SqlQueryComponent from './SqlQueryComponent';
import { useLocation } from 'react-router-dom';

const { Text } = Typography;
const { TabPane } = Tabs;

const DataExpress = () => {
  const [tables, setTables] = useState([]);
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('sql');
  const [uploadForm] = Form.useForm();
  const sqlComponentRef = useRef(null);
  const location = useLocation();

  // Load config from URL params
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const configName = params.get('edit');
    if (configName) {
      loadConfigToSqlComponent(configName);
    }
  }, [location.search]);

  // Load config to SQL component
  const loadConfigToSqlComponent = async (configName) => {
    try {
      const response = await axios.get(`/api/configurations/${configName}`,{ withCredentials: true });
      if (response.data) {
        console.info("in data express loadConfigToSqlComponent:",response.data)
        if (sqlComponentRef.current) {
            const configData = Array.isArray(response.data) ? response.data[0] : response.data;
            sqlComponentRef.current.loadConfig(configData);
            //sqlComponentRef.current.loadConfig(response.data);
            setActiveTab('sql');
        }
      }
    } catch (error) {
      message.error(`加载配置失败: ${error.response?.data?.error || error.message}`);
    }
  };

  // Fetch tables
  const fetchTables = async () => {
    setLoading(true);
    try {
      const response = await axios.get('/api/data/tables',{ withCredentials: true });
      setTables(Array.isArray(response.data) ? response.data : []);
    } catch (error) {
      message.error('获取数据表失败');
      setTables([]);
    } finally {
      setLoading(false);
    }
  };

  // Handle file upload
  const handleUpload = async (file) => {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('tableName', uploadForm.getFieldValue('tableName') || `temp_${Date.now()}`);

    setLoading(true);
    try {
      const response = await axios.post('/api/data/upload2db', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
        withCredentials:true
      });
      message.success(`${response.data.message}，表名: ${response.data.table}`);
      fetchTables();
    } catch (error) {
      message.error(`上传失败: ${error.response?.data?.error || error.message}`);
    } finally {
      setLoading(false);
    }
    return false;
  };

  // Render schema popover
  const renderSchemaPopover = (schemaJSON) => {
    if (!schemaJSON) return '无结构信息';
    try {
      const schema = JSON.parse(schemaJSON);
      return (
        <div style={{ width: 300 }}>
          <Table
            dataSource={schema}
            columns={[
              { title: '字段名', dataIndex: 'columnName', key: 'columnName' },
              { title: '类型', dataIndex: 'dataType', key: 'dataType' }
            ]}
            size="small"
            pagination={false}
          />
        </div>
      );
    } catch (e) {
      return '解析结构信息失败';
    }
  };

  // Table columns
  const tableColumns = [
    {
      title: '表名',
      dataIndex: 'tableName',
      key: 'tableName',
      render: (text, record) => (
        <Popover content={renderSchemaPopover(record.schemaJSON)} title="表结构">
          <Button type="link">{text}</Button>
        </Popover>
      )
    },
    { title: '显示名称', dataIndex: 'displayName', key: 'displayName' },
    { title: '描述', dataIndex: 'description', key: 'description', ellipsis: true },
    {
      title: '类型',
      dataIndex: 'isView',
      key: 'isView',
      render: (isView) => (
        <Tag color={isView ? 'blue' : 'green'}>{isView ? '视图' : '表'}</Tag>
      )
    }
  ];

  useEffect(() => {
    fetchTables();
  }, []);

  return (
    <Card title="数据直通车">
      <Tabs activeKey={activeTab} onChange={setActiveTab}>
        <TabPane tab="SQL查询" key="sql">
          <SqlQueryComponent ref={sqlComponentRef} />
        </TabPane>
        <TabPane tab="数据表浏览" key="tables">
          <Table
            dataSource={tables}
            columns={tableColumns}
            rowKey="tableName"
            loading={loading}
            onRow={(record) => ({
              onDoubleClick: () => {
                setActiveTab('sql');
                if (sqlComponentRef.current) {
                  sqlComponentRef.current.setSampleSql(`SELECT * FROM ${record.tableName} LIMIT 10`);
                }
              }
            })}
          />
        </TabPane>
        <TabPane tab="数据上传" key="upload">
          <Form form={uploadForm} layout="vertical">
            <Form.Item
              name="tableName"
              label="目标表名"
              rules={[
                { required: true, message: '请输入表名' },
                { pattern: /^[a-zA-Z_][a-zA-Z0-9_]*$/, message: '表名只能包含字母、数字和下划线' }
              ]}
            >
              <Input placeholder="输入新表名，如: sales_data" />
            </Form.Item>

            <Form.Item>
              <Upload
                accept=".csv"
                beforeUpload={handleUpload}
                showUploadList={false}
                disabled={loading}
              >
                <Button icon={<UploadOutlined />} loading={loading}>
                  {loading ? '上传中...' : '上传CSV文件'}
                </Button>
              </Upload>
              <div style={{ marginTop: 8, color: '#666' }}>
                <p>• 支持标准CSV格式(UTF-8编码)</p>
                <p>• 第一行将作为列名</p>
                <p>• 文件大小限制: 50MB</p>
              </div>
            </Form.Item>
          </Form>
        </TabPane>
      </Tabs>
    </Card>
  );
};

export default DataExpress;