import React from 'react';
import { Form, Input, Select, Button, Tabs, Radio, Slider, Switch, InputNumber, Card, Row, Col, Divider, Tooltip, Space, Tag, Badge, Collapse, message, Upload } from 'antd';
import { InfoCircleOutlined, FileTextOutlined, RobotOutlined, SettingOutlined, DatabaseOutlined, CodeOutlined, PlusOutlined, DeleteOutlined, EditOutlined, PictureOutlined, AudioOutlined, VideoCameraOutlined } from '@ant-design/icons';
import AceEditor from 'react-ace';
import 'ace-builds/src-noconflict/mode-python';
import 'ace-builds/src-noconflict/theme-monokai';
import { marked } from 'marked';


const { TextArea } = Input;
const { TabPane } = Tabs;
const { Panel } = Collapse;

// 模态类型
const ModalityType = {
  TEXT: "text",
  IMAGE: "image",
  AUDIO: "audio",
  VIDEO: "video",
  MULTIMODAL: "multimodal"
};

// 输出类型
const OutputType = {
  TEXT: "text",
  JSON: "json",
  IMAGE: "image",
  AUDIO: "audio",
  MARKDOWN: "markdown",
  HTML: "html"
};

// Prompt Types
const PromptType = {
  SIMPLE: "simple",
  CHAT: "chat",
  FEW_SHOT: "few_shot",
  MMR_FEW_SHOT: "mmr_few_shot",
  CHAT_WITH_HISTORY: "chat_with_history",
  FEW_SHOT_CHAT: "few_shot_chat"
};

// Model Types Configuration
const MODEL_TYPES = {
  openai: {
    name: "OpenAI",
    required: ["api_key"],
    optional: ["model_name", "temperature", "max_tokens", "top_p", "frequency_penalty"],
    endpointType: "post",
    params: { prompt: "messages", temperature: "temperature" },
    supports: [ModalityType.TEXT]
  },
  openai_multimodal: {
    name: "OpenAI Multimodal",
    required: ["api_key"],
    optional: ["model_name", "temperature", "max_tokens", "image_understanding", "image_generation"],
    endpointType: "post",
    params: { prompt: "messages", temperature: "temperature" },
    supports: [ModalityType.TEXT, ModalityType.IMAGE]
  },
  chatglm: {
    name: "ChatGLM",
    required: ["api_base"],
    optional: ["model_name", "temperature", "top_p"],
    endpointType: "post",
    params: { prompt: "prompt", temperature: "temperature" },
    supports: [ModalityType.TEXT]
  },
  wenxin: {
    name: "文心一言",
    required: ["api_key", "secret_key"],
    optional: ["model_name", "temperature", "top_k"],
    endpointType: "post",
    params: { prompt: "messages", temperature: "temperature" },
    supports: [ModalityType.TEXT]
  },
  tongyi: {
    name: "通义千问",
    required: ["api_key"],
    optional: ["model_name", "temperature", "top_p"],
    endpointType: "post",
    params: { prompt: "input.messages", temperature: "parameters.temperature" },
    supports: [ModalityType.TEXT]
  },
  local: {
    name: "本地模型",
    required: ["model_path"],
    optional: ["device", "quantization", "temperature", "max_length"],
    endpointType: "post",
    params: { prompt: "inputs", temperature: "parameters.temperature" },
    supports: [ModalityType.TEXT]
  },
  whisper: {
    name: "Whisper (语音)",
    required: ["api_key"],
    optional: ["model_name", "temperature", "language"],
    endpointType: "post",
    params: { prompt: "audio", temperature: "temperature" },
    supports: [ModalityType.AUDIO]
  },
  dalle: {
    name: "DALL-E (图像生成)",
    required: ["api_key"],
    optional: ["model_name", "size", "quality"],
    endpointType: "post",
    params: { prompt: "prompt", temperature: "temperature" },
    supports: [ModalityType.IMAGE]
  }
};

// Preset Prompts
const PRESET_PROMPTS = [
  {
    id: 'general',
    name: '通用助手',
    config: {
      prompt_type: PromptType.CHAT,
      system_message: '你是一个专业助手，需要根据用户问题提供准确、简洁的回答。可使用工具获取必要信息，回答需基于事实。',
      human_template: '{question}'
    }
  },
  {
    id: 'multimodal',
    name: '多模态助手',
    config: {
      prompt_type: PromptType.CHAT,
      system_message: '你是一个多模态助手，可以处理文本、图像和音频输入。对于图像，请详细描述内容；对于音频，请先转写为文本再处理。',
      human_template: '{input}'
    }
  },
  {
    id: 'analyst',
    name: '数据分析',
    config: {
      prompt_type: PromptType.CHAT,
      system_message: '你是数据分析师，用户问题涉及数据计算、趋势分析时，需使用计算工具验证结果，用图表化语言描述结论。',
      human_template: '请分析以下数据问题：{question}'
    }
  },
  {
    id: 'researcher',
    name: '学术研究',
    config: {
      prompt_type: PromptType.FEW_SHOT_CHAT,
      system_message: '你是科研助手，需优先使用文献工具检索最新研究，回答需包含引用格式，对争议观点需说明不同立场。',
      human_template: '研究问题：{question}',
      examples: [
        { input: "量子计算的最新进展", output: "近年来量子计算领域取得了显著进展，特别是在量子纠错和量子算法方面..." }
      ]
    }
  },
  {
    id: 'code',
    name: '代码开发',
    config: {
      prompt_type: PromptType.CHAT,
      system_message: '你是编程助手，生成代码需包含注释，优先使用代码工具验证语法，回答需分步骤说明实现思路。',
      human_template: '编程需求：{question}'
    }
  }
];

// Predefined Tools
const PREDEFINED_TOOLS = [
  { name: 'arxiv_search', description: 'Arxiv论文搜索工具', parameters: [{ name: 'query', type: 'string', required: true }] },
  { name: 'shell_exec', description: '安全执行Shell命令', parameters: [{ name: 'command', type: 'string', required: true }] },
  { name: 'math_solver', description: '符号数学求解', parameters: [{ name: 'problem', type: 'string', required: true }] },
  { name: 'code_generator', description: '代码生成工具', parameters: [{ name: 'requirement', type: 'string', required: true }] }
];

// Multimodal Tools
const MULTIMODAL_TOOLS = [
  { 
    name: 'image_processor', 
    description: '图像处理工具', 
    parameters: [
      { name: 'operation', type: 'string', required: true, enum: ['analyze', 'edit', 'generate'] },
      { name: 'image_data', type: 'string', required: false, format: 'base64' },
      { name: 'width', type: 'number', required: false },
      { name: 'height', type: 'number', required: false },
      { name: 'text', type: 'string', required: false }
    ],
    output_types: [OutputType.IMAGE, OutputType.JSON]
  },
  { 
    name: 'audio_processor', 
    description: '音频处理工具', 
    parameters: [
      { name: 'operation', type: 'string', required: true, enum: ['transcribe', 'generate'] },
      { name: 'audio_data', type: 'string', required: false, format: 'base64' },
      { name: 'text', type: 'string', required: false },
      { name: 'voice', type: 'string', required: false, enum: ['alloy', 'echo', 'fable', 'onyx', 'nova', 'shimmer'] }
    ],
    output_types: [OutputType.AUDIO, OutputType.TEXT]
  }
];

// Vector Store Options
const VECTOR_STORES = [
  { value: 'faiss', label: 'FAISS' },
  { value: 'chroma', label: 'Chroma' },
  { value: 'milvus', label: 'Milvus' },
  { value: 'pinecone', label: 'Pinecone' }
];

// 模型配置表单组件
const ModelConfigForm = ({ modelType, form, namePrefix }) => {
  const modelConfig = MODEL_TYPES[modelType] || MODEL_TYPES.openai;

  return (
    <div>
      <Row gutter={16}>
        {modelConfig.required.map(param => (
          <Col span={12} key={param}>
            <Form.Item
              name={[...namePrefix, param]}
              label={param.replace('_', ' ')}
              rules={[{ required: true, message: `请输入${param}` }]}
            >
              {param === 'api_key' || param === 'secret_key' ? (
                <Input.Password placeholder={`请输入${param}`} />
              ) : (
                <Input placeholder={`请输入${param}`} />
              )}
            </Form.Item>
          </Col>
        ))}
      </Row>

      <Collapse ghost>
        <Panel header="高级参数" key="advanced">
          <Row gutter={16}>
            {modelConfig.optional.map(param => (
              <Col span={12} key={param}>
                <Form.Item
                  name={[...namePrefix, param]}
                  label={param.replace('_', ' ')}
                >
                  {param === 'temperature' ? (
                    <Slider min={0} max={2} step={0.1} />
                  ) : param === 'quantization' ? (
                    <Select>
                      <Select.Option value="int8">INT8</Select.Option>
                      <Select.Option value="int4">INT4</Select.Option>
                    </Select>
                  ) : param === 'image_understanding' || param === 'image_generation' ? (
                    <Switch />
                  ) : (
                    <Input placeholder={`请输入${param}`} />
                  )}
                </Form.Item>
              </Col>
            ))}
          </Row>
        </Panel>
      </Collapse>
    </div>
  );
};

// 多模型融合配置组件
const MultiModelConfig = ({ models, form }) => {
  return (
    <div>
      <Form.List name="multiModelConfigs">
        {(fields, { add, remove }) => (
          <>
            {fields.map(({ key, name, ...restField }) => {
              const modelId = form.getFieldValue(['multiModelConfigs', name, 'modelType']);
              return (
                <Card 
                  key={key} 
                  title={`模型 ${name + 1} 配置`}
                  style={{ marginBottom: 16 }}
                  extra={
                    <Button
                      type="link"
                      danger
                      icon={<DeleteOutlined />}
                      onClick={() => remove(name)}
                    >
                      移除
                    </Button>
                  }
                >
                  <Form.Item
                    {...restField}
                    name={[name, 'modelType']}
                    label="模型类型"
                    rules={[{ required: true, message: '请选择模型类型' }]}
                  >
                    <Select placeholder="选择模型类型">
                      {Object.keys(MODEL_TYPES).map(key => (
                        <Select.Option key={key} value={key}>
                          {MODEL_TYPES[key].name}
                        </Select.Option>
                      ))}
                    </Select>
                  </Form.Item>

                  {modelId && (
                    <ModelConfigForm 
                      modelType={modelId} 
                      form={form}
                      namePrefix={['multiModelConfigs', name, 'config']}
                    />
                  )}

                  <Form.Item
                    {...restField}
                    name={[name, 'weight']}
                    label="模型权重"
                    initialValue={1.0}
                  >
                    <InputNumber min={0.1} max={1.0} step={0.1} />
                  </Form.Item>
                </Card>
              );
            })}

            <Button
              type="dashed"
              onClick={() => add()}
              block
              icon={<PlusOutlined />}
            >
              添加模型配置
            </Button>
          </>
        )}
      </Form.List>
    </div>
  );
};

// 输入上传预览组件
const ImageUploadPreview = ({ onImageUpload }) => {
  const [previewImage, setPreviewImage] = React.useState('');

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const base64 = event.target.result.split(',')[1];
        setPreviewImage(event.target.result);
        onImageUpload(base64);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div>
      <input type="file" accept="image/*" onChange={handleImageUpload} />
      {previewImage && (
        <img 
          src={previewImage} 
          alt="预览" 
          style={{ maxWidth: '100%', maxHeight: '300px', marginTop: '16px' }} 
        />
      )}
    </div>
  );
};

const AudioUploadPreview = ({ onAudioUpload }) => {
  const [audioUrl, setAudioUrl] = React.useState('');

  const handleAudioUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const base64 = event.target.result.split(',')[1];
        setAudioUrl(event.target.result);
        onAudioUpload(base64);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div>
      <input type="file" accept="audio/*" onChange={handleAudioUpload} />
      {audioUrl && (
        <audio controls src={audioUrl} style={{ marginTop: '16px', width: '100%' }} />
      )}
    </div>
  );
};

// 输出预览组件
const OutputPreview = ({ outputType, outputData }) => {
  if (!outputData) {
    return <div style={{ padding: '16px', textAlign: 'center', color: '#666' }}>暂无输出数据</div>;
  }

  switch (outputType) {
    case OutputType.IMAGE:
      return (
        <img 
          src={`data:image/jpeg;base64,${outputData}`} 
          alt="生成图像" 
          style={{ maxWidth: '100%', maxHeight: '300px', display: 'block', margin: '0 auto' }} 
        />
      );
    case OutputType.AUDIO:
      return (
        <audio 
          controls 
          src={`data:audio/wav;base64,${outputData}`} 
          style={{ width: '100%', marginTop: '16px' }} 
        />
      );
    case OutputType.JSON:
      return (
        <pre style={{ 
          background: '#f5f5f5', 
          padding: '16px', 
          borderRadius: '4px',
          maxHeight: '300px',
          overflow: 'auto'
        }}>
          {JSON.stringify(JSON.parse(outputData), null, 2)}
        </pre>
      );
    case OutputType.MARKDOWN:
      return (
        <div 
          style={{ 
            border: '1px solid #e8e8e8', 
            padding: '16px', 
            borderRadius: '4px',
            maxHeight: '300px',
            overflow: 'auto'
          }}
          dangerouslySetInnerHTML={{ __html: marked(outputData) }}
        />
      );
    case OutputType.HTML:
      return (
        <div 
          style={{ 
            border: '1px solid #e8e8e8', 
            padding: '16px', 
            borderRadius: '4px',
            maxHeight: '300px',
            overflow: 'auto'
          }}
          dangerouslySetInnerHTML={{ __html: outputData }}
        />
      );
    default:
      return <div style={{ whiteSpace: 'pre-wrap', padding: '16px' }}>{outputData}</div>;
  }
};

// 提示词配置表单组件
const PromptConfigForm = ({ promptType, form }) => {
  const renderPromptConfigForm = () => {
    switch (promptType) {
      case PromptType.SIMPLE:
        return (
          <div>
            <Form.Item
              name={['promptConfig', 'template']}
              label="提示模板"
              rules={[{ required: true, message: '请输入提示模板' }]}
            >
              <TextArea rows={6} placeholder="例如：给我写一个关于{topic}的{type}文章" />
            </Form.Item>
            <Form.Item
              name={['promptConfig', 'input_variables']}
              label="输入变量"
              rules={[{ required: true, message: '请输入变量列表' }]}
            >
              <Select
                mode="tags"
                placeholder="输入变量名后按回车添加"
                tokenSeparators={[',']}
                dropdownStyle={{ display: 'none' }}
              />
            </Form.Item>
          </div>
        );

      case PromptType.CHAT:
        return (
          <div>
            <Form.Item
              name={['promptConfig', 'system_message']}
              label="系统消息"
              rules={[{ required: true, message: '请输入系统消息' }]}
            >
              <TextArea rows={4} placeholder="定义AI的角色和行为" />
            </Form.Item>
            <Form.Item
              name={['promptConfig', 'human_template']}
              label="人类消息模板"
              rules={[{ required: true, message: '请输入人类消息模板' }]}
            >
              <TextArea rows={3} placeholder="例如：请回答关于{topic}的问题" />
            </Form.Item>
            <Form.Item
              name={['promptConfig', 'input_variables']}
              label="输入变量"
            >
              <Select
                mode="tags"
                placeholder="输入变量名后按回车添加"
                tokenSeparators={[',']}
                dropdownStyle={{ display: 'none' }}
              />
            </Form.Item>
          </div>
        );

      case PromptType.FEW_SHOT:
        return (
          <div>
            <Form.Item
              name={['promptConfig', 'examples']}
              label="示例"
              rules={[{ required: true, message: '请输入示例' }]}
            >
              <TextArea
                rows={6}
                placeholder='JSON格式的示例列表，例如：[{"input":"开心","output":"伤心"},...]'
              />
            </Form.Item>
            <Form.Item
              name={['promptConfig', 'example_template']}
              label="示例模板"
              rules={[{ required: true, message: '请输入示例模板' }]}
            >
              <TextArea rows={2} placeholder="例如：输入: {input}\n输出: {output}" />
            </Form.Item>
            <Row gutter={16}>
              <Col span={12}>
                <Form.Item
                  name={['promptConfig', 'prefix']}
                  label="前缀"
                >
                  <TextArea rows={2} placeholder="示例前的文本" />
                </Form.Item>
              </Col>
              <Col span={12}>
                <Form.Item
                  name={['promptConfig', 'suffix']}
                  label="后缀"
                  rules={[{ required: true, message: '请输入后缀' }]}
                >
                  <TextArea rows={2} placeholder="示例后的文本，例如：输入: {input}\n输出:" />
                </Form.Item>
              </Col>
            </Row>
            <Form.Item
              name={['promptConfig', 'input_variables']}
              label="输入变量"
              rules={[{ required: true, message: '请输入变量列表' }]}
            >
              <Select
                mode="tags"
                placeholder="输入变量名后按回车添加"
                tokenSeparators={[',']}
                dropdownStyle={{ display: 'none' }}
              />
            </Form.Item>
          </div>
        );

      case PromptType.MMR_FEW_SHOT:
        return (
          <div>
            <Form.Item
              name={['promptConfig', 'examples']}
              label="示例"
              rules={[{ required: true, message: '请输入示例' }]}
            >
              <TextArea
                rows={6}
                placeholder='JSON格式的示例列表，例如：[{"input":"开心","output":"伤心"},...]'
              />
            </Form.Item>
            <Form.Item
              name={['promptConfig', 'example_template']}
              label="示例模板"
              rules={[{ required: true, message: '请输入示例模板' }]}
            >
              <TextArea rows={2} placeholder="例如：输入: {input}\n输出: {output}" />
            </Form.Item>
            <Row gutter={16}>
              <Col span={12}>
                <Form.Item
                  name={['promptConfig', 'prefix']}
                  label="前缀"
                >
                  <TextArea rows={2} placeholder="示例前的文本" />
                </Form.Item>
              </Col>
              <Col span={12}>
                <Form.Item
                  name={['promptConfig', 'suffix']}
                  label="后缀"
                  rules={[{ required: true, message: '请输入后缀' }]}
                >
                  <TextArea rows={2} placeholder="示例后的文本，例如：输入: {input}\n输出:" />
                </Form.Item>
              </Col>
            </Row>
            <Form.Item
              name={['promptConfig', 'input_variables']}
              label="输入变量"
              rules={[{ required: true, message: '请输入变量列表' }]}
            >
              <Select
                mode="tags"
                placeholder="输入变量名后按回车添加"
                tokenSeparators={[',']}
                dropdownStyle={{ display: 'none' }}
              />
            </Form.Item>
            <Row gutter={16}>
              <Col span={12}>
                <Form.Item
                  name={['promptConfig', 'embeddings_model_path']}
                  label="嵌入模型路径"
                  rules={[{ required: true, message: '请输入嵌入模型路径' }]}
                >
                  <Input placeholder="例如：sentence-transformers/all-mpnet-base-v2" />
                </Form.Item>
              </Col>
              <Col span={12}>
                <Form.Item
                  name={['promptConfig', 'k']}
                  label="选择示例数量"
                  initialValue={4}
                >
                  <InputNumber min={1} max={20} />
                </Form.Item>
              </Col>
            </Row>
          </div>
        );

      case PromptType.CHAT_WITH_HISTORY:
        return (
          <div>
            <Form.Item
              name={['promptConfig', 'system_message']}
              label="系统消息"
              rules={[{ required: true, message: '请输入系统消息' }]}
            >
              <TextArea rows={4} placeholder="定义AI的角色和行为" />
            </Form.Item>
            <Form.Item
              name={['promptConfig', 'human_template']}
              label="人类消息模板"
              rules={[{ required: true, message: '请输入人类消息模板' }]}
            >
              <TextArea rows={3} placeholder="例如：请回答关于{topic}的问题" />
            </Form.Item>
            <Form.Item
              name={['promptConfig', 'history_variable']}
              label="历史记录变量名"
              initialValue="history"
            >
              <Input placeholder="存储历史记录的变量名" />
            </Form.Item>
            <Form.Item
              name={['promptConfig', 'input_variables']}
              label="输入变量"
            >
              <Select
                mode="tags"
                placeholder="输入变量名后按回车添加"
                tokenSeparators={[',']}
                dropdownStyle={{ display: 'none' }}
              />
            </Form.Item>
          </div>
        );

      case PromptType.FEW_SHOT_CHAT:
        return (
          <div>
            <Form.Item
              name={['promptConfig', 'system_message']}
              label="系统消息"
              rules={[{ required: true, message: '请输入系统消息' }]}
            >
              <TextArea rows={4} placeholder="定义AI的角色和行为" />
            </Form.Item>
            <Form.Item
              name={['promptConfig', 'examples']}
              label="示例对话"
              rules={[{ required: true, message: '请输入示例对话' }]}
            >
              <TextArea
                rows={6}
                placeholder='JSON格式的示例列表，例如：[{"input":"开心的反义词是什么？","output":"伤心"},...]'
              />
            </Form.Item>
            <Form.Item
              name={['promptConfig', 'human_template']}
              label="人类消息模板"
              rules={[{ required: true, message: '请输入人类消息模板' }]}
            >
              <TextArea rows={3} placeholder="例如：{question}" />
            </Form.Item>
            <Form.Item
              name={['promptConfig', 'input_variables']}
              label="输入变量"
            >
              <Select
                mode="tags"
                placeholder="输入变量名后按回车添加"
                tokenSeparators={[',']}
                dropdownStyle={{ display: 'none' }}
              />
            </Form.Item>
          </div>
        );

      default:
        return <div>请选择提示词类型</div>;
    }
  };

  return renderPromptConfigForm();
};

// 自定义工具表单组件
const CustomToolForm = ({ 
  tool, 
  onSave, 
  onCancel, 
  onAddParam,
  onDeleteParam,
  onChange
}) => {
  return (
    <Card title={tool ? "编辑工具" : "添加工具"}>
      <Form layout="vertical">
        <Form.Item label="工具名称" required>
          <Input
            value={tool?.name || ''}
            onChange={(e) => onChange('name', e.target.value)}
          />
        </Form.Item>

        <Form.Item label="工具描述" required>
          <TextArea
            rows={2}
            value={tool?.description || ''}
            onChange={(e) => onChange('description', e.target.value)}
          />
        </Form.Item>

        <Form.Item label="参数列表">
          <div style={{ marginBottom: 8 }}>
            {tool?.parameters?.map((param, index) => (
              <Row gutter={8} key={index} align="middle" style={{ marginBottom: 8 }}>
                <Col span={6}>
                  <Input
                    placeholder="参数名"
                    value={param.name}
                    onChange={(e) => onChange('paramName', e.target.value, index)}
                  />
                </Col>
                <Col span={5}>
                  <Select
                    value={param.type}
                    onChange={(value) => onChange('paramType', value, index)}
                    style={{ width: '100%' }}
                  >
                    <Select.Option value="string">字符串</Select.Option>
                    <Select.Option value="number">数字</Select.Option>
                    <Select.Option value="boolean">布尔值</Select.Option>
                    <Select.Option value="array">数组</Select.Option>
                    <Select.Option value="object">对象</Select.Option>
                  </Select>
                </Col>
                <Col span={5}>
                  <Select
                    value={param.format}
                    onChange={(value) => onChange('paramFormat', value, index)}
                    style={{ width: '100%' }}
                    placeholder="格式"
                  >
                    <Select.Option value="base64">Base64</Select.Option>
                    <Select.Option value="url">URL</Select.Option>
                  </Select>
                </Col>
                <Col span={4}>
                  <Switch
                    checked={param.required}
                    onChange={(checked) => onChange('paramRequired', checked, index)}
                  />
                  <span style={{ marginLeft: 8 }}>必填</span>
                </Col>
                <Col span={2}>
                  <Button
                    icon={<DeleteOutlined />}
                    danger
                    size="small"
                    onClick={() => onDeleteParam(index)}
                  />
                </Col>
              </Row>
            ))}
            <Button
              type="dashed"
              icon={<PlusOutlined />}
              onClick={onAddParam}
              style={{ marginTop: 8 }}
            >
              添加参数
            </Button>
          </div>
        </Form.Item>

        <Form.Item label="输出类型" required>
          <Select
            mode="multiple"
            value={tool?.output_types || []}
            onChange={(values) => onChange('output_types', values)}
          >
            {Object.values(OutputType).map(type => (
              <Select.Option key={type} value={type}>{type}</Select.Option>
            ))}
          </Select>
        </Form.Item>

        <Form.Item label="工具代码实现" required>
          <AceEditor
            mode="python"
            theme="monokai"
            name="tool-code-editor"
            value={tool?.code || ''}
            onChange={(value) => onChange('code', value)}
            fontSize={14}
            showGutter={true}
            height="200px"
            width="100%"
            showPrintMargin={false}
            showLineNumbers={true}
            highlightActiveLine={true}
            setOptions={{
              enableBasicAutocompletion: true,
              enableLiveAutocompletion: true,
              enableSnippets: true
            }}
          />
        </Form.Item>

        <Form.Item>
          <Space>
            <Button type="primary" onClick={onSave}>
              保存
            </Button>
            <Button onClick={onCancel}>
              取消
            </Button>
          </Space>
        </Form.Item>
      </Form>
    </Card>
  );
};

// 主Agent配置组件
const AgentConfig = ({
  form: parentForm,
  availableModels = Object.keys(MODEL_TYPES).map(key => ({
    id: key,
    name: MODEL_TYPES[key].name,
    type: '大语言模型'
  })),
  onSave
}) => {
  const [localForm] = Form.useForm();
  const form = parentForm || localForm;

  // State management
  const [execStrategy, setExecStrategy] = React.useState('single');
  const [modelMode, setModelMode] = React.useState('single');
  const [selectedPromptId, setSelectedPromptId] = React.useState('general');
  const [customTools, setCustomTools] = React.useState([]);
  const [showAddToolForm, setShowAddToolForm] = React.useState(false);
  const [currentToolIndex, setCurrentToolIndex] = React.useState(-1);
  const [formValues, setFormValues] = React.useState({});
  const [promptType, setPromptType] = React.useState(PromptType.CHAT);
  const [inputModality, setInputModality] = React.useState(ModalityType.TEXT);
  const [outputType, setOutputType] = React.useState(OutputType.TEXT);
  const [inputImage, setInputImage] = React.useState('');
  const [inputAudio, setInputAudio] = React.useState('');
  const [outputData, setOutputData] = React.useState(null);

  // 使用 useMemo 缓存预设提示词配置
  const presetPromptConfig = React.useMemo(() => {
    const prompt = PRESET_PROMPTS.find(p => p.id === selectedPromptId);
    return prompt ? prompt.config : PRESET_PROMPTS[0].config;
  }, [selectedPromptId]);

  // 初始化表单值
  React.useEffect(() => {
    if (!form) return;

    const initialValues = {
      agentName: 'SmartAgent',
      execStrategy: 'single',
      promptConfig: presetPromptConfig,
      modelMode: 'single',
      modelType: 'openai',
      temperature: 0.7,
      maxTokens: 1024,
      outputMergeStrategy: 'takeFirst',
      memoryEnabled: true,
      memorySize: 10,
      maxIterations: 5,
      enabledTools: PREDEFINED_TOOLS.map(tool => tool.name),
      vectorStore: 'faiss',
      multiModelConfigs: [],
      supportsMultimodal: false,
      inputModality: ModalityType.TEXT,
      defaultOutputType: OutputType.TEXT,
      multimodalTools: []
    };

    form.setFieldsValue(initialValues);
    setFormValues(initialValues);
    setPromptType(presetPromptConfig.prompt_type || PromptType.CHAT);
  }, [form, presetPromptConfig]);

  // 监听表单值变化
  const handleValuesChange = (changedValues, allValues) => {
    setFormValues(allValues);
    
    // 当 promptConfig.prompt_type 变化时更新状态
    if (changedValues.promptConfig?.prompt_type) {
      setPromptType(changedValues.promptConfig.prompt_type);
    }
    
    // 当输入模态变化时更新状态
    if (changedValues.inputModality) {
      setInputModality(changedValues.inputModality);
    }
    
    // 当输出类型变化时更新状态
    if (changedValues.defaultOutputType) {
      setOutputType(changedValues.defaultOutputType);
    }
  };

  const handleModelModeChange = (e) => {
    const mode = e.target.value;
    setModelMode(mode);
    
    if (mode === 'single') {
      form.setFieldsValue({
        multiModels: undefined,
        multiModelConfigs: [],
        modelWeightStrategy: undefined,
        modelWeights: undefined
      });
    } else {
      form.setFieldsValue({
        modelType: undefined,
        modelConfig: undefined
      });
    }
  };

  const renderSingleModelConfig = () => (
    <>
      <Form.Item
        name="modelType"
        label="模型类型"
        rules={[{ required: true, message: '请选择模型类型' }]}
      >
        <Select placeholder="选择模型类型">
          {Object.keys(MODEL_TYPES).map(key => (
            <Select.Option key={key} value={key}>
              {MODEL_TYPES[key].name}
            </Select.Option>
          ))}
        </Select>
      </Form.Item>

      {formValues.modelType && (
        <ModelConfigForm 
          modelType={formValues.modelType} 
          form={form}
          namePrefix={['modelConfig']}
        />
      )}
    </>
  );

  const renderMultiModelConfig = () => (
    <>
      <Form.Item
        name="modelWeightStrategy"
        label="融合策略"
        initialValue="weighted"
      >
        <Select>
          <Select.Option value="weighted">加权融合（手动设置权重）</Select.Option>
          <Select.Option value="average">平均融合</Select.Option>
          <Select.Option value="rank">按性能排序（取Top2）</Select.Option>
        </Select>
      </Form.Item>

      <MultiModelConfig 
        models={availableModels} 
        form={form} 
      />

      {formValues.modelWeightStrategy === 'weighted' && (
        <Form.Item label="模型权重">
          <Form.List name="modelWeights">
            {(fields) => (
              <Row gutter={16}>
                {fields.map(({ key, name, ...restField }) => {
                  const modelId = form.getFieldValue(['multiModelConfigs', name, 'modelType']);
                  const modelName = modelId ? MODEL_TYPES[modelId]?.name || modelId : '未知模型';
                  
                  return (
                    <Col span={8} key={key}>
                      <Form.Item
                        {...restField}
                        name={[name]}
                        label={modelName}
                        rules={[
                          { required: true, message: '请输入权重' },
                          { type: 'number', min: 0.1, max: 0.9, message: '权重必须在0.1到0.9之间' }
                        ]}
                        initialValue={1 / (formValues.multiModelConfigs?.length || 1)}
                      >
                        <InputNumber
                          min={0.1}
                          max={0.9}
                          step={0.1}
                          formatter={value => `${(value * 100).toFixed(0)}%`}
                          parser={value => value.replace('%', '') / 100}
                        />
                      </Form.Item>
                    </Col>
                  );
                })}
              </Row>
            )}
          </Form.List>
        </Form.Item>
      )}
    </>
  );

  const handlePromptTypeChange = (value) => {
    setPromptType(value);
    form.setFieldsValue({
      promptConfig: {
        ...form.getFieldValue('promptConfig'),
        prompt_type: value
      }
    });
  };

  const handlePresetPromptChange = (id) => {
    setSelectedPromptId(id);
    const prompt = PRESET_PROMPTS.find(p => p.id === id);
    if (prompt && form) {
      form.setFieldsValue({ 
        promptConfig: prompt.config 
      });
      setPromptType(prompt.config.prompt_type);
    }
  };

  const handleDeleteToolParam = (paramIndex) => {
    if (currentToolIndex === -1) return;

    const updatedTools = [...customTools];
    updatedTools[currentToolIndex].parameters.splice(paramIndex, 1);

    setCustomTools(updatedTools);
    if (form) {
      form.setFieldsValue({ customTools: updatedTools });
    }
  };

  const handleDeleteTool = (index) => {
    const updatedTools = [...customTools];
    updatedTools.splice(index, 1);
    setCustomTools(updatedTools);
    if (form) {
      form.setFieldsValue({ customTools: updatedTools });
    }

    if (currentToolIndex === index) {
      setShowAddToolForm(false);
      setCurrentToolIndex(-1);
    }
  };

  const handleEditTool = (index) => {
    setCurrentToolIndex(index);
    setShowAddToolForm(true);
  };

  const handleSaveTool = (toolData) => {
    const updatedTools = [...customTools];
    if (currentToolIndex === -1) {
      updatedTools.push(toolData);
    } else {
      updatedTools[currentToolIndex] = toolData;
    }

    setCustomTools(updatedTools);
    if (form) {
      form.setFieldsValue({ customTools: updatedTools });
    }
    setShowAddToolForm(false);
    setCurrentToolIndex(-1);
  };

  const handleAddToolParam = () => {
    const updatedTools = [...customTools];
    const toolIndex = currentToolIndex === -1 ? updatedTools.length : currentToolIndex;
    
    if (currentToolIndex === -1) {
      updatedTools.push({
        name: `tool_${Date.now().toString().slice(-4)}`,
        description: '',
        parameters: [],
        code: 'def tool_function():\n    # 工具函数实现\n    return "结果"',
        output_types: [OutputType.TEXT],
        is_custom: true
      });
    }
    
    updatedTools[toolIndex].parameters = [
      ...updatedTools[toolIndex].parameters,
      { name: `param_${updatedTools[toolIndex].parameters.length}`, type: 'string', required: false }
    ];
    
    setCustomTools(updatedTools);
    setCurrentToolIndex(toolIndex);
  };

  const handleToolChange = (field, value, paramIndex = null) => {
    const updatedTools = [...customTools];
    const toolIndex = currentToolIndex === -1 ? updatedTools.length - 1 : currentToolIndex;
    
    if (paramIndex !== null) {
      // 更新参数
      if (field === 'paramName') {
        updatedTools[toolIndex].parameters[paramIndex].name = value;
      } else if (field === 'paramType') {
        updatedTools[toolIndex].parameters[paramIndex].type = value;
      } else if (field === 'paramFormat') {
        updatedTools[toolIndex].parameters[paramIndex].format = value;
      } else if (field === 'paramRequired') {
        updatedTools[toolIndex].parameters[paramIndex].required = value;
      }
    } else {
      // 更新工具属性
      if (field === 'name') {
        updatedTools[toolIndex].name = value;
      } else if (field === 'description') {
        updatedTools[toolIndex].description = value;
      } else if (field === 'code') {
        updatedTools[toolIndex].code = value;
      } else if (field === 'output_types') {
        updatedTools[toolIndex].output_types = value;
      }
    }
    
    setCustomTools(updatedTools);
  };

  const renderToolForm = () => {
    const tool = currentToolIndex !== -1 ? customTools[currentToolIndex] : null;
    
    return (
      <CustomToolForm
        tool={tool}
        onSave={() => handleSaveTool( customTools[currentToolIndex] === -1 ? customTools[customTools.length - 1] :customTools[currentToolIndex] ) }
        onCancel={() => {
          setShowAddToolForm(false);
          setCurrentToolIndex(-1);
        }}
        onAddParam={handleAddToolParam}
        onDeleteParam={handleDeleteToolParam}
        onChange={handleToolChange}
      />
    );
  };

  const renderVariablesSection = () => {
    const defaultVariables = [
      { name: 'agentName', description: '当前Agent名称' },
      { name: 'currentTime', description: '当前时间' },
      { name: 'userId', description: '用户ID' },
      { name: 'tools', description: '可用工具列表' },
      { name: 'historySummary', description: '历史对话摘要' },
      { name: 'question', description: '用户输入' }
    ];

    return (
      <div>
        <Divider orientation="left">可用变量</Divider>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginBottom: 16 }}>
          {defaultVariables.map(v => (
            <Tooltip key={v.name} title={v.description}>
              <Tag color="blue">{v.name}</Tag>
            </Tooltip>
          ))}
        </div>
      </div>
    );
  };

  const renderModelConfig = () => {
    const modelType = formValues.modelType || 'openai';
    const modelConfig = MODEL_TYPES[modelType] || MODEL_TYPES.openai;

    return (
      <div>
        <Row gutter={16}>
          {modelConfig.required.map(param => (
            <Col span={12} key={param}>
              <Form.Item
                name={['modelConfig', param]}
                label={param.replace('_', ' ')}
                rules={[{ required: true, message: `请输入${param}` }]}
              >
                {param === 'api_key' || param === 'secret_key' ? (
                  <Input.Password placeholder={`请输入${param}`} />
                ) : (
                  <Input placeholder={`请输入${param}`} />
                )}
              </Form.Item>
            </Col>
          ))}
        </Row>

        <Collapse ghost>
          <Panel header="高级参数" key="advanced">
            <Row gutter={16}>
              {modelConfig.optional.map(param => (
                <Col span={12} key={param}>
                  <Form.Item
                    name={['modelConfig', param]}
                    label={param.replace('_', ' ')}
                  >
                    {param === 'temperature' ? (
                      <Slider min={0} max={2} step={0.1} />
                    ) : param === 'quantization' ? (
                      <Select>
                        <Select.Option value="int8">INT8</Select.Option>
                        <Select.Option value="int4">INT4</Select.Option>
                      </Select>
                    ) : param === 'image_understanding' || param === 'image_generation' ? (
                      <Switch />
                    ) : (
                      <Input placeholder={`请输入${param}`} />
                    )}
                  </Form.Item>
                </Col>
              ))}
            </Row>
          </Panel>
        </Collapse>
      </div>
    );
  };

  const renderMultimodalPreview = () => {
    return (
      <Card title="多模态预览" style={{ marginTop: 16 }}>
        <Tabs>
          <TabPane tab="输入预览" key="input">
            {inputModality === ModalityType.IMAGE && (
              <ImageUploadPreview
                onImageUpload={(base64) => {
                  setInputImage(base64);
                }}
              />
            )}
            {inputModality === ModalityType.AUDIO && (
              <AudioUploadPreview
                onAudioUpload={(base64) => {
                  setInputAudio(base64);
                }}
              />
            )}
            {inputModality === ModalityType.TEXT && (
              <div style={{ padding: '16px', textAlign: 'center', color: '#666' }}>
                文本输入不需要预览
              </div>
            )}
          </TabPane>
          <TabPane tab="输出预览" key="output">
            <OutputPreview 
              outputType={outputType}
              outputData={outputData}
            />
          </TabPane>
        </Tabs>
      </Card>
    );
  };

  const handleTestRun = async () => {
    try {
      const values = await form.validateFields();
      
      let input;
      if (values.inputModality === ModalityType.IMAGE && inputImage) {
        input = {
          text: "请描述这张图片的内容",
          image: inputImage
        };
      } else if (values.inputModality === ModalityType.AUDIO && inputAudio) {
        input = {
          audio: inputAudio
        };
      } else {
        input = "这是一个测试请求，请回复'Hello World'";
      }
      
      // 这里应该是调用后端API执行Agent
      // 模拟返回结果
      const mockResults = {
        [OutputType.TEXT]: { output_type: OutputType.TEXT, data: "Hello World! 这是来自Agent的文本回复。" },
        [OutputType.JSON]: { output_type: OutputType.JSON, data: JSON.stringify({ result: "success", message: "Hello World" }) },
        [OutputType.IMAGE]: { 
          output_type: OutputType.IMAGE, 
          data: "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==" 
        },
        [OutputType.AUDIO]: { 
          output_type: OutputType.AUDIO, 
          data: "UklGRiQAAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQAAAAA=" 
        }
      };
      
      setOutputData(mockResults[values.defaultOutputType].data);
      message.success("测试运行成功");
    } catch (error) {
      console.error('Error:', error);
      message.error("配置验证失败，请检查表单");
    }
  };

  const handleSaveConfig = () => {
    form.validateFields()
      .then(values => {
        if (onSave) {
          onSave(values);
        } else {
          console.log('Agent配置:', values);
          message.success('配置保存成功');
        }
      })
      .catch(info => {
        console.log('验证失败:', info);
        message.error('配置验证失败，请检查表单');
      });
  };

  return (
    <Form 
      form={form} 
      layout="vertical" 
      initialValues={{
        agentName: 'SmartAgent',
        execStrategy: 'single',
        promptConfig: PRESET_PROMPTS[0].config,
        modelMode: 'single',
        modelType: 'openai',
        temperature: 0.7,
        maxTokens: 1024,
        outputMergeStrategy: 'takeFirst',
        memoryEnabled: true,
        memorySize: 10,
        maxIterations: 5,
        enabledTools: PREDEFINED_TOOLS.map(tool => tool.name),
        vectorStore: 'faiss',
        multiModelConfigs: [],
        supportsMultimodal: false,
        inputModality: ModalityType.TEXT,
        defaultOutputType: OutputType.TEXT,
        multimodalTools: []
      }}
      onValuesChange={handleValuesChange}
    >
      <Tabs defaultActiveKey="basic" style={{ marginBottom: 20 }}>
        {/* 1. Basic Configuration */}
        <TabPane tab={<span><SettingOutlined /> 基础配置</span>} key="basic">
          <Card title="Agent基本信息">
            <Form.Item
              name="agentName"
              label="Agent名称"
              rules={[{ required: true, message: '请输入Agent名称' }]}
            >
              <Input placeholder="例如：财务分析Agent、客服助手" />
            </Form.Item>

            <Divider orientation="left">执行策略</Divider>
            <Form.Item
              name="execStrategy"
              label="决策模式"
              rules={[{ required: true }]}
            >
              <Radio.Group onChange={(e) => setExecStrategy(e.target.value)}>
                <Radio value="single">单Agent执行</Radio>
                <Radio value="parallel">多Agent并行决策</Radio>
                <Radio value="sequential">多Agent串行决策</Radio>
                <Radio value="vote">投票决策（共识机制）</Radio>
              </Radio.Group>
            </Form.Item>

            {execStrategy !== 'single' && (
              <>
                <Form.Item
                  name="participatingAgents"
                  label="参与Agent"
                  rules={[{ required: true, message: '请选择参与的Agent' }]}
                >
                  <Select mode="multiple" placeholder="选择需要协同的Agent">
                    {availableModels.map(agent => (
                      <Select.Option key={agent.id} value={agent.id}>
                        {agent.name}（{agent.type}）
                      </Select.Option>
                    ))}
                  </Select>
                </Form.Item>

                {execStrategy === 'sequential' && (
                  <Form.Item
                    name="executionOrder"
                    label="执行顺序"
                    rules={[{ required: true, message: '请输入执行顺序' }]}
                  >
                    <Input placeholder="用逗号分隔的Agent ID，例如：agent1,agent2,agent3" />
                  </Form.Item>
                )}

                {execStrategy === 'vote' && (
                  <Form.Item
                    name="voteThreshold"
                    label="投票通过阈值"
                    tooltip={<span><InfoCircleOutlined /> 达到该比例的Agent同意时，视为通过</span>}
                    initialValue={0.7}
                  >
                    <Slider
                      min={0.5}
                      max={1}
                      step={0.05}
                      marks={{ 0.5: '50%', 0.7: '70%', 0.9: '90%', 1: '100%' }}
                    />
                  </Form.Item>
                )}
              </>
            )}
          </Card>
        </TabPane>

        {/* 2. Prompt Configuration */}
        <TabPane tab={<span><FileTextOutlined /> 提示词配置</span>} key="prompt">
          <Card title="提示词模板配置">
            <Row gutter={16}>
              <Col span={6}>
                <div style={{ border: '1px solid #e8e8e8', borderRadius: 4, padding: 12, height: '100%' }}>
                  <p style={{ fontWeight: 'bold', marginBottom: 12 }}>预设模板</p>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                    {PRESET_PROMPTS.map(prompt => (
                      <Button
                        key={prompt.id}
                        type={selectedPromptId === prompt.id ? 'primary' : 'default'}
                        onClick={() => handlePresetPromptChange(prompt.id)}
                        block
                        size="small"
                      >
                        {prompt.name}
                      </Button>
                    ))}
                  </div>

                  <Divider style={{ margin: '16px 0' }} />

                  <p style={{ fontWeight: 'bold', marginBottom: 12 }}>提示词类型</p>
                  <Radio.Group
                    value={promptType}
                    onChange={(e) => handlePromptTypeChange(e.target.value)}
                    style={{ display: 'flex', flexDirection: 'column', gap: 8 }}
                  >
                    <Radio.Button value={PromptType.SIMPLE}>简单提示</Radio.Button>
                    <Radio.Button value={PromptType.CHAT}>聊天提示</Radio.Button>
                    <Radio.Button value={PromptType.FEW_SHOT}>少样本提示</Radio.Button>
                    <Radio.Button value={PromptType.MMR_FEW_SHOT}>MMR少样本</Radio.Button>
                    <Radio.Button value={PromptType.CHAT_WITH_HISTORY}>带历史聊天</Radio.Button>
                    <Radio.Button value={PromptType.FEW_SHOT_CHAT}>少样本聊天</Radio.Button>
                  </Radio.Group>
                </div>
              </Col>

              <Col span={18}>
                <PromptConfigForm promptType={promptType} form={form} />
                {renderVariablesSection()}
              </Col>
            </Row>
          </Card>
        </TabPane>

        {/* 3. Model Configuration */}
        <TabPane tab={<span><RobotOutlined /> 模型配置</span>} key="model">
          <Card title="模型设置">
            <Form.Item
              name="modelMode"
              label="模型模式"
              rules={[{ required: true }]}
            >
              <Radio.Group onChange={handleModelModeChange}>
                <Radio value="single">单模型</Radio>
                <Radio value="multiple">多模型融合</Radio>
              </Radio.Group>
            </Form.Item>

            {modelMode === 'single' ? renderSingleModelConfig() : renderMultiModelConfig()}

            <Divider orientation="left">多模态支持</Divider>
            <Form.Item
              name="supportsMultimodal"
              label="启用多模态支持"
              valuePropName="checked"
            >
              <Switch />
            </Form.Item>

            {formValues.supportsMultimodal && (
              <>
                <Form.Item
                  name="inputModality"
                  label="输入模态"
                  initialValue={ModalityType.TEXT}
                >
                  <Select>
                    {Object.values(ModalityType).map(modality => (
                      <Select.Option key={modality} value={modality}>
                        {modality}
                      </Select.Option>
                    ))}
                  </Select>
                </Form.Item>

                <Form.Item
                  name="defaultOutputType"
                  label="默认输出类型"
                  initialValue={OutputType.TEXT}
                >
                  <Select>
                    {Object.values(OutputType).map(type => (
                      <Select.Option key={type} value={type}>
                        {type}
                      </Select.Option>
                    ))}
                  </Select>
                </Form.Item>
              </>
            )}

            <Divider orientation="left">模型参数</Divider>
            <Row gutter={16}>
              <Col span={12}>
                <Form.Item
                  name="temperature"
                  label="温度值"
                  tooltip={<span><InfoCircleOutlined /> 0=确定性输出，2=高度随机</span>}
                >
                  <Slider min={0} max={2} step={0.1} marks={{ 0: '0', 1: '1', 2: '2' }} />
                </Form.Item>
              </Col>
              <Col span={12}>
                <Form.Item
                  name="maxTokens"
                  label="最大输出长度"
                >
                  <InputNumber min={256} max={8192} step={256} />
                </Form.Item>
              </Col>
            </Row>

            <Row gutter={16}>
              <Col span={12}>
                <Form.Item
                  name="topP"
                  label="Top P"
                  tooltip={<span><InfoCircleOutlined /> 控制输出的多样性，0.5表示只从累积概率50%的候选词中选择</span>}
                  initialValue={0.7}
                >
                  <Slider min={0} max={1} step={0.1} marks={{ 0: '0', 0.5: '0.5', 1: '1' }} />
                </Form.Item>
              </Col>
              <Col span={12}>
                <Form.Item
                  name="frequencyPenalty"
                  label="频率惩罚"
                  tooltip={<span><InfoCircleOutlined /> 减少重复内容的生成，值越高惩罚越强</span>}
                  initialValue={0}
                >
                  <Slider min={-2} max={2} step={0.1} marks={{ '-2': '-2', '0': '0', '2': '2' }} />
                </Form.Item>
              </Col>
            </Row>
          </Card>
        </TabPane>

        {/* 4. Action Configuration */}
        <TabPane tab={<span><CodeOutlined /> 动作配置</span>} key="action">
          <Card title="工具与动作配置">
            <Form.Item
              name="enabledTools"
              label="启用的工具"
            >
              <Select mode="multiple" placeholder="选择Agent可使用的工具">
                {PREDEFINED_TOOLS.map(tool => (
                  <Select.Option key={tool.name} value={tool.name}>
                    {tool.name} - {tool.description}
                  </Select.Option>
                ))}
                {MULTIMODAL_TOOLS.map(tool => (
                  <Select.Option key={tool.name} value={tool.name}>
                    {tool.name} - {tool.description}
                  </Select.Option>
                ))}
                {customTools.map((tool, index) => (
                  <Select.Option key={`custom_${index}`} value={`custom_${tool.name}`}>
                    <Badge status="processing" text="自定义" /> {tool.name} - {tool.description}
                  </Select.Option>
                ))}
              </Select>
            </Form.Item>

            <Divider orientation="left">预定义工具详情</Divider>
            <div style={{ marginBottom: 24 }}>
              {formValues.enabledTools?.map(toolName => {
                const predefinedTool = PREDEFINED_TOOLS.find(t => t.name === toolName);
                const multimodalTool = MULTIMODAL_TOOLS.find(t => t.name === toolName);
                const tool = predefinedTool || multimodalTool;
                
                if (tool) {
                  return (
                    <Card key={toolName} title={tool.name} style={{ marginBottom: 12 }}>
                      <p><strong>描述：</strong>{tool.description}</p>
                      {tool.output_types && (
                        <p><strong>支持输出：</strong>{tool.output_types.join(', ')}</p>
                      )}
                      {tool.parameters.length > 0 && (
                        <>
                          <p><strong>参数：</strong></p>
                          <ul>
                            {tool.parameters.map((param, idx) => (
                              <li key={idx}>
                                {param.name} ({param.type}) 
                                {param.required ? <Tag color="red">必填</Tag> : ''}
                                {param.enum && (
                                  <span> 可选值: {param.enum.join(', ')}</span>
                                )}
                                {param.format && (
                                  <span> 格式: {param.format}</span>
                                )}
                              </li>
                            ))}
                          </ul>
                        </>
                      )}
                    </Card>
                  );
                }
                return null;
              })}
            </div>

            <Divider orientation="left">自定义工具</Divider>
            <Space style={{ marginBottom: 16 }}>
              <Button
                type="primary"
                icon={<PlusOutlined />}
                onClick={() => {
                  setCurrentToolIndex(-1);
                  setShowAddToolForm(true);
                }}
              >
                添加自定义工具
              </Button>
            </Space>

            {showAddToolForm ? (
              renderToolForm()
            ) : (
              <div>
                {customTools.length === 0 ? (
                  <p style={{ textAlign: 'center', color: '#666', padding: 16 }}>
                    暂无自定义工具，点击"添加自定义工具"按钮创建
                  </p>
                ) : (
                  <div>
                    {customTools.map((tool, index) => (
                      <Card key={index} title={tool.name} style={{ marginBottom: 12 }}>
                        <Row justify="space-between" align="middle">
                          <Col flex="auto">
                            <p><strong>描述：</strong>{tool.description}</p>
                            {tool.output_types && (
                              <p><strong>支持输出：</strong>{tool.output_types.join(', ')}</p>
                            )}
                            {tool.parameters.length > 0 && (
                              <>
                                <p><strong>参数：</strong></p>
                                <ul>
                                  {tool.parameters.map((param, idx) => (
                                    <li key={idx}>
                                      {param.name} ({param.type}) 
                                      {param.required ? <Tag color="red">必填</Tag> : ''}
                                      {param.enum && (
                                        <span> 可选值: {param.enum.join(', ')}</span>
                                      )}
                                      {param.format && (
                                        <span> 格式: {param.format}</span>
                                      )}
                                    </li>
                                  ))}
                                </ul>
                              </>
                            )}
                          </Col>
                          <Col flex="none">
                            <Space>
                              <Button
                                icon={<EditOutlined />}
                                onClick={() => handleEditTool(index)}
                              >
                                编辑
                              </Button>
                              <Button
                                icon={<DeleteOutlined />}
                                danger
                                onClick={() => handleDeleteTool(index)}
                              >
                                删除
                              </Button>
                            </Space>
                          </Col>
                        </Row>
                      </Card>
                    ))}
                  </div>
                )}
              </div>
            )}

            <Divider orientation="left">动作控制</Divider>
            <Row gutter={16}>
              <Col span={12}>
                <Form.Item
                  name="actionTimeout"
                  label="动作超时时间（秒）"
                  initialValue={30}
                >
                  <InputNumber min={5} max={300} />
                </Form.Item>
              </Col>
              <Col span={12}>
                <Form.Item
                  name="actionRateLimit"
                  label="动作频率限制（次/分钟）"
                  initialValue={60}
                >
                  <InputNumber min={1} max={300} />
                </Form.Item>
              </Col>
            </Row>

            <Form.Item
              name="actionSafetyCheck"
              label="动作安全检查"
              initialValue="medium"
            >
              <Select>
                <Select.Option value="off">关闭（不检查）</Select.Option>
                <Select.Option value="medium">中等（检查高危动作）</Select.Option>
                <Select.Option value="strict">严格（检查所有动作）</Select.Option>
              </Select>
            </Form.Item>

            {formValues.actionSafetyCheck !== 'off' && (
              <Form.Item
                name="forbiddenActions"
                label="禁止执行的动作"
              >
                <Select mode="multiple" placeholder="选择禁止执行的动作类型">
                  <Select.Option value="file_write">文件写入</Select.Option>
                  <Select.Option value="network_request">外部网络请求</Select.Option>
                  <Select.Option value="system_command">系统命令执行</Select.Option>
                  <Select.Option value="code_execution">代码执行</Select.Option>
                </Select>
              </Form.Item>
            )}
          </Card>
        </TabPane>

        {/* 5. Advanced Configuration */}
        <TabPane tab={<span><DatabaseOutlined /> 高级配置</span>} key="advanced">
          <Card title="记忆配置">
            <Form.Item
              name="memoryEnabled"
              label="启用对话记忆"
              valuePropName="checked"
              initialValue={true}
            >
              <Switch />
            </Form.Item>

            {formValues.memoryEnabled && (
              <>
                <Form.Item
                  name="memorySize"
                  label="记忆轮数"
                  initialValue={10}
                >
                  <InputNumber min={1} max={50} />
                </Form.Item>

                <Form.Item
                  name="memoryType"
                  label="记忆类型"
                  initialValue="full"
                >
                  <Select>
                    <Select.Option value="full">完整记忆（存储所有对话）</Select.Option>
                    <Select.Option value="summary">摘要记忆（仅存储摘要）</Select.Option>
                    <Select.Option value="relevant">相关记忆（仅存储相关内容）</Select.Option>
                  </Select>
                </Form.Item>

                <Form.Item
                  name="memoryPersist"
                  label="持久化记忆"
                  valuePropName="checked"
                  initialValue={false}
                >
                  <Switch />
                  <span style={{ marginLeft: 8 }}>将对话记忆保存到持久化存储</span>
                </Form.Item>
              </>
            )}
          </Card>

          <Card title="向量存储配置" style={{ marginTop: 16 }}>
            <Form.Item
              name="vectorStore"
              label="向量数据库"
              initialValue="faiss"
            >
              <Select>
                {VECTOR_STORES.map(store => (
                  <Select.Option key={store.value} value={store.value}>
                    {store.label}
                  </Select.Option>
                ))}
              </Select>
            </Form.Item>

            {formValues.vectorStore && (
              <>
                <Form.Item
                  name={['vectorStoreConfig', 'path']}
                  label="存储路径"
                  rules={[{ required: true, message: '请输入存储路径' }]}
                >
                  <Input placeholder="例如：./vector_store" />
                </Form.Item>

                {formValues.vectorStore !== 'faiss' && (
                  <Form.Item
                    name={['vectorStoreConfig', 'url']}
                    label="数据库URL"
                    rules={[{ required: true, message: '请输入数据库URL' }]}
                  >
                    <Input placeholder="例如：http://localhost:6333" />
                  </Form.Item>
                )}

                {formValues.vectorStore === 'pinecone' && (
                  <Form.Item
                    name={['vectorStoreConfig', 'apiKey']}
                    label="API密钥"
                    rules={[{ required: true, message: '请输入API密钥' }]}
                  >
                    <Input.Password placeholder="请输入Pinecone API密钥" />
                  </Form.Item>
                )}
              </>
            )}
          </Card>

          <Card title="执行控制" style={{ marginTop: 16 }}>
            <Form.Item
              name="maxIterations"
              label="最大迭代次数"
              initialValue={5}
              tooltip={<span><InfoCircleOutlined /> Agent最多思考/调用工具的次数</span>}
            >
              <InputNumber min={1} max={20} />
            </Form.Item>

            <Form.Item
              name="earlyStopping"
              label="启用早停机制"
              valuePropName="checked"
              initialValue={true}
            >
              <Switch />
              <span style={{ marginLeft: 8 }}>Agent认为完成任务时自动停止</span>
            </Form.Item>

            <Form.Item
              name="verbose"
              label="详细日志输出"
              valuePropName="checked"
              initialValue={false}
            >
              <Switch />
              <span style={{ marginLeft: 8 }}>输出Agent思考过程和工具调用详情</span>
            </Form.Item>
          </Card>
        </TabPane>
      </Tabs>

      {/* 多模态预览区域 */}
      {formValues.supportsMultimodal && renderMultimodalPreview()}

      {/* Action Buttons */}
      <div style={{ textAlign: 'right', marginTop: 24 }}>
        <Space size="middle">
          <Button type="default" onClick={() => form.resetFields()}>重置</Button>
          {formValues.supportsMultimodal && (
            <Button type="primary" ghost onClick={handleTestRun}>
              测试运行
            </Button>
          )}
          <Button type="primary" onClick={handleSaveConfig}>
            保存配置
          </Button>
        </Space>
      </div>
    </Form>
  );
};

export default AgentConfig;




// import React from 'react';
// import { Form, Input, Select, Button, Tabs, Radio, Slider, Switch, InputNumber, Card, Row, Col, Divider, Tooltip, Space, Tag, Badge, Collapse, message } from 'antd';
// import { InfoCircleOutlined, FileTextOutlined, RobotOutlined, SettingOutlined, DatabaseOutlined, CodeOutlined, PlusOutlined, DeleteOutlined, EditOutlined } from '@ant-design/icons';
// import AceEditor from 'react-ace';
// import 'ace-builds/src-noconflict/mode-python';
// import 'ace-builds/src-noconflict/theme-monokai';

// const { TextArea } = Input;
// const { TabPane } = Tabs;
// const { Panel } = Collapse;


// // 在常量定义部分添加新的枚举
// const ModalityType = {
//   TEXT: "text",
//   IMAGE: "image",
//   AUDIO: "audio",
//   VIDEO: "video",
//   MULTIMODAL: "multimodal"
// };

// const OutputType = {
//   TEXT: "text",
//   JSON: "json",
//   IMAGE: "image",
//   AUDIO: "audio",
//   MARKDOWN: "markdown",
//   HTML: "html"
// };
// // Prompt Types (aligned with Python enum)
// const PromptType = {
//   SIMPLE: "simple",
//   CHAT: "chat",
//   FEW_SHOT: "few_shot",
//   MMR_FEW_SHOT: "mmr_few_shot",
//   CHAT_WITH_HISTORY: "chat_with_history",
//   FEW_SHOT_CHAT: "few_shot_chat"
// };

// // Model Types Configuration
// const MODEL_TYPES = {
//   openai: {
//     name: "OpenAI",
//     required: ["api_key"],
//     optional: ["model_name", "temperature", "max_tokens", "top_p", "frequency_penalty"],
//     endpointType: "post",
//     params: { prompt: "messages", temperature: "temperature" }
//   },
//   chatglm: {
//     name: "ChatGLM",
//     required: ["api_base"],
//     optional: ["model_name", "temperature", "top_p"],
//     endpointType: "post",
//     params: { prompt: "prompt", temperature: "temperature" }
//   },
//   wenxin: {
//     name: "文心一言",
//     required: ["api_key", "secret_key"],
//     optional: ["model_name", "temperature", "top_k"],
//     endpointType: "post",
//     params: { prompt: "messages", temperature: "temperature" }
//   },
//   tongyi: {
//     name: "通义千问",
//     required: ["api_key"],
//     optional: ["model_name", "temperature", "top_p"],
//     endpointType: "post",
//     params: { prompt: "input.messages", temperature: "parameters.temperature" }
//   },
//   local: {
//     name: "本地模型",
//     required: ["model_path"],
//     optional: ["device", "quantization", "temperature", "max_length"],
//     endpointType: "post",
//     params: { prompt: "inputs", temperature: "parameters.temperature" }
//   },
//   openai_multimodal: {
//     name: "OpenAI Multimodal",
//     required: ["api_key"],
//     optional: ["model_name", "temperature", "max_tokens", "image_understanding", "image_generation"],
//     endpointType: "post",
//     params: { prompt: "messages", temperature: "temperature" },
//     supports: [ModalityType.TEXT, ModalityType.IMAGE]
//   },
//   whisper: {
//     name: "Whisper (语音)",
//     required: ["api_key"],
//     optional: ["model_name", "temperature", "language"],
//     endpointType: "post",
//     params: { prompt: "audio", temperature: "temperature" },
//     supports: [ModalityType.AUDIO]
//   },
//   dalle: {
//     name: "DALL-E (图像生成)",
//     required: ["api_key"],
//     optional: ["model_name", "size", "quality"],
//     endpointType: "post",
//     params: { prompt: "prompt", temperature: "temperature" },
//     supports: [ModalityType.IMAGE]
//   }
// };

// // 新增多模态工具
// const MULTIMODAL_TOOLS = [
//   { 
//     name: 'image_processor', 
//     description: '图像处理工具', 
//     parameters: [
//       { name: 'operation', type: 'string', required: true, enum: ['analyze', 'edit', 'generate'] },
//       { name: 'image_data', type: 'string', required: false, format: 'base64' },
//       { name: 'edit_instructions', type: 'string', required: false }
//     ],
//     output_type: [OutputType.IMAGE, OutputType.JSON]
//   },
//   { 
//     name: 'audio_processor', 
//     description: '音频处理工具', 
//     parameters: [
//       { name: 'operation', type: 'string', required: true, enum: ['transcribe', 'generate'] },
//       { name: 'audio_data', type: 'string', required: false, format: 'base64' },
//       { name: 'text', type: 'string', required: false },
//       { name: 'voice', type: 'string', required: false, enum: ['alloy', 'echo', 'fable', 'onyx', 'nova', 'shimmer'] }
//     ],
//     output_type: [OutputType.AUDIO, OutputType.TEXT]
//   }
// ];


// // Preset Prompts
// const PRESET_PROMPTS = [
//   {
//     id: 'general',
//     name: '通用助手',
//     config: {
//       prompt_type: PromptType.CHAT,
//       system_message: '你是一个专业助手，需要根据用户问题提供准确、简洁的回答。可使用工具获取必要信息，回答需基于事实。',
//       human_template: '{question}'
//     }
//   },
//   {
//     id: 'analyst',
//     name: '数据分析',
//     config: {
//       prompt_type: PromptType.CHAT,
//       system_message: '你是数据分析师，用户问题涉及数据计算、趋势分析时，需使用计算工具验证结果，用图表化语言描述结论。',
//       human_template: '请分析以下数据问题：{question}'
//     }
//   },
//   {
//     id: 'researcher',
//     name: '学术研究',
//     config: {
//       prompt_type: PromptType.FEW_SHOT_CHAT,
//       system_message: '你是科研助手，需优先使用文献工具检索最新研究，回答需包含引用格式，对争议观点需说明不同立场。',
//       human_template: '研究问题：{question}',
//       examples: [
//         { input: "量子计算的最新进展", output: "近年来量子计算领域取得了显著进展，特别是在量子纠错和量子算法方面..." }
//       ]
//     }
//   },
//   {
//     id: 'code',
//     name: '代码开发',
//     config: {
//       prompt_type: PromptType.CHAT,
//       system_message: '你是编程助手，生成代码需包含注释，优先使用代码工具验证语法，回答需分步骤说明实现思路。',
//       human_template: '编程需求：{question}'
//     }
//   }
// ];

// // Predefined Tools
// const PREDEFINED_TOOLS = [
//   { name: 'arxiv_search', description: 'Arxiv论文搜索工具', parameters: [{ name: 'query', type: 'string', required: true }] },
//   { name: 'shell_exec', description: '安全执行Shell命令', parameters: [{ name: 'command', type: 'string', required: true }] },
//   { name: 'math_solver', description: '符号数学求解', parameters: [{ name: 'problem', type: 'string', required: true }] },
//   { name: 'code_generator', description: '代码生成工具', parameters: [{ name: 'requirement', type: 'string', required: true }] }
// ];

// // Vector Store Options
// const VECTOR_STORES = [
//   { value: 'faiss', label: 'FAISS' },
//   { value: 'chroma', label: 'Chroma' },
//   { value: 'milvus', label: 'Milvus' },
//   { value: 'pinecone', label: 'Pinecone' }
// ];

// const ModelConfigForm = ({ modelType, form, namePrefix }) => {
//   const modelConfig = MODEL_TYPES[modelType] || MODEL_TYPES.openai;

//   return (
//     <div>
//       <Row gutter={16}>
//         {modelConfig.required.map(param => (
//           <Col span={12} key={param}>
//             <Form.Item
//               name={[...namePrefix, param]}
//               label={param.replace('_', ' ')}
//               rules={[{ required: true, message: `请输入${param}` }]}
//             >
//               {param === 'api_key' || param === 'secret_key' ? (
//                 <Input.Password placeholder={`请输入${param}`} />
//               ) : (
//                 <Input placeholder={`请输入${param}`} />
//               )}
//             </Form.Item>
//           </Col>
//         ))}
//       </Row>

//       <Collapse ghost>
//         <Panel header="高级参数" key="advanced">
//           <Row gutter={16}>
//             {modelConfig.optional.map(param => (
//               <Col span={12} key={param}>
//                 <Form.Item
//                   name={[...namePrefix, param]}
//                   label={param.replace('_', ' ')}
//                 >
//                   {param === 'temperature' ? (
//                     <Slider min={0} max={2} step={0.1} />
//                   ) : param === 'quantization' ? (
//                     <Select>
//                       <Select.Option value="int8">INT8</Select.Option>
//                       <Select.Option value="int4">INT4</Select.Option>
//                     </Select>
//                   ) : (
//                     <Input placeholder={`请输入${param}`} />
//                   )}
//                 </Form.Item>
//               </Col>
//             ))}
//           </Row>
//         </Panel>
//       </Collapse>
//     </div>
//   );
// };

// // 多模型融合配置组件
// const MultiModelConfig = ({ models, form }) => {
//   return (
//     <div>
//       <Form.List name="multiModelConfigs">
//         {(fields, { add, remove }) => (
//           <>
//             {fields.map(({ key, name, ...restField }) => {
//               const modelId = form.getFieldValue(['multiModelConfigs', name, 'modelType']);
//               return (
//                 <Card 
//                   key={key} 
//                   title={`模型 ${name + 1} 配置`}
//                   style={{ marginBottom: 16 }}
//                   extra={
//                     <Button
//                       type="link"
//                       danger
//                       icon={<DeleteOutlined />}
//                       onClick={() => remove(name)}
//                     >
//                       移除
//                     </Button>
//                   }
//                 >
//                   <Form.Item
//                     {...restField}
//                     name={[name, 'modelType']}
//                     label="模型类型"
//                     rules={[{ required: true, message: '请选择模型类型' }]}
//                   >
//                     <Select placeholder="选择模型类型">
//                       {models.map(model => (
//                         <Select.Option key={model.id} value={model.id}>
//                           {model.name}（{model.type}）
//                         </Select.Option>
//                       ))}
//                     </Select>
//                   </Form.Item>

//                   {modelId && (
//                     <ModelConfigForm 
//                       modelType={modelId} 
//                       form={form}
//                       namePrefix={['multiModelConfigs', name, 'config']}
//                     />
//                   )}
//                 </Card>
//               );
//             })}

//             <Button
//               type="dashed"
//               onClick={() => add()}
//               block
//               icon={<PlusOutlined />}
//             >
//               添加模型配置
//             </Button>
//           </>
//         )}
//       </Form.List>
//     </div>
//   );
// };

// // 提取提示词配置表单为独立组件
// const PromptConfigForm = ({ promptType, form }) => {
//   const renderPromptConfigForm = () => {
//     switch (promptType) {
//       case PromptType.SIMPLE:
//         return (
//           <div>
//             <Form.Item
//               name={['promptConfig', 'template']}
//               label="提示模板"
//               rules={[{ required: true, message: '请输入提示模板' }]}
//             >
//               <TextArea rows={6} placeholder="例如：给我写一个关于{topic}的{type}文章" />
//             </Form.Item>
//             <Form.Item
//               name={['promptConfig', 'input_variables']}
//               label="输入变量"
//               rules={[{ required: true, message: '请输入变量列表' }]}
//             >
//               <Select
//                 mode="tags"
//                 placeholder="输入变量名后按回车添加"
//                 tokenSeparators={[',']}
//                 dropdownStyle={{ display: 'none' }}
//               />
//             </Form.Item>
//             <Form.Item
//               name={['promptConfig', 'format_args']}
//               label="格式化参数"
//             >
//               <TextArea rows={3} placeholder='JSON格式的默认参数，例如：{"topic": "科技", "type": "说明文"}' />
//             </Form.Item>
//           </div>
//         );

//       case PromptType.CHAT:
//         return (
//           <div>
//             <Form.Item
//               name={['promptConfig', 'system_message']}
//               label="系统消息"
//               rules={[{ required: true, message: '请输入系统消息' }]}
//             >
//               <TextArea rows={4} placeholder="定义AI的角色和行为" />
//             </Form.Item>
//             <Form.Item
//               name={['promptConfig', 'human_template']}
//               label="人类消息模板"
//               rules={[{ required: true, message: '请输入人类消息模板' }]}
//             >
//               <TextArea rows={3} placeholder="例如：请回答关于{topic}的问题" />
//             </Form.Item>
//             <Form.Item
//               name={['promptConfig', 'input_variables']}
//               label="输入变量"
//             >
//               <Select
//                 mode="tags"
//                 placeholder="输入变量名后按回车添加"
//                 tokenSeparators={[',']}
//                 dropdownStyle={{ display: 'none' }}
//               />
//             </Form.Item>
//           </div>
//         );

//       case PromptType.FEW_SHOT:
//         return (
//           <div>
//             <Form.Item
//               name={['promptConfig', 'examples']}
//               label="示例"
//               rules={[{ required: true, message: '请输入示例' }]}
//             >
//               <TextArea
//                 rows={6}
//                 placeholder='JSON格式的示例列表，例如：[{"input":"开心","output":"伤心"},...]'
//               />
//             </Form.Item>
//             <Form.Item
//               name={['promptConfig', 'example_template']}
//               label="示例模板"
//               rules={[{ required: true, message: '请输入示例模板' }]}
//             >
//               <TextArea rows={2} placeholder="例如：输入: {input}\n输出: {output}" />
//             </Form.Item>
//             <Row gutter={16}>
//               <Col span={12}>
//                 <Form.Item
//                   name={['promptConfig', 'prefix']}
//                   label="前缀"
//                 >
//                   <TextArea rows={2} placeholder="示例前的文本" />
//                 </Form.Item>
//               </Col>
//               <Col span={12}>
//                 <Form.Item
//                   name={['promptConfig', 'suffix']}
//                   label="后缀"
//                   rules={[{ required: true, message: '请输入后缀' }]}
//                 >
//                   <TextArea rows={2} placeholder="示例后的文本，例如：输入: {input}\n输出:" />
//                 </Form.Item>
//               </Col>
//             </Row>
//             <Form.Item
//               name={['promptConfig', 'input_variables']}
//               label="输入变量"
//               rules={[{ required: true, message: '请输入变量列表' }]}
//             >
//               <Select
//                 mode="tags"
//                 placeholder="输入变量名后按回车添加"
//                 tokenSeparators={[',']}
//                 dropdownStyle={{ display: 'none' }}
//               />
//             </Form.Item>
//           </div>
//         );

//       case PromptType.MMR_FEW_SHOT:
//         return (
//           <div>
//             <Form.Item
//               name={['promptConfig', 'examples']}
//               label="示例"
//               rules={[{ required: true, message: '请输入示例' }]}
//             >
//               <TextArea
//                 rows={6}
//                 placeholder='JSON格式的示例列表，例如：[{"input":"开心","output":"伤心"},...]'
//               />
//             </Form.Item>
//             <Form.Item
//               name={['promptConfig', 'example_template']}
//               label="示例模板"
//               rules={[{ required: true, message: '请输入示例模板' }]}
//             >
//               <TextArea rows={2} placeholder="例如：输入: {input}\n输出: {output}" />
//             </Form.Item>
//             <Row gutter={16}>
//               <Col span={12}>
//                 <Form.Item
//                   name={['promptConfig', 'prefix']}
//                   label="前缀"
//                 >
//                   <TextArea rows={2} placeholder="示例前的文本" />
//                 </Form.Item>
//               </Col>
//               <Col span={12}>
//                 <Form.Item
//                   name={['promptConfig', 'suffix']}
//                   label="后缀"
//                   rules={[{ required: true, message: '请输入后缀' }]}
//                 >
//                   <TextArea rows={2} placeholder="示例后的文本，例如：输入: {input}\n输出:" />
//                 </Form.Item>
//               </Col>
//             </Row>
//             <Form.Item
//               name={['promptConfig', 'input_variables']}
//               label="输入变量"
//               rules={[{ required: true, message: '请输入变量列表' }]}
//             >
//               <Select
//                 mode="tags"
//                 placeholder="输入变量名后按回车添加"
//                 tokenSeparators={[',']}
//                 dropdownStyle={{ display: 'none' }}
//               />
//             </Form.Item>
//             <Row gutter={16}>
//               <Col span={12}>
//                 <Form.Item
//                   name={['promptConfig', 'embeddings_model_path']}
//                   label="嵌入模型路径"
//                   rules={[{ required: true, message: '请输入嵌入模型路径' }]}
//                 >
//                   <Input placeholder="例如：sentence-transformers/all-mpnet-base-v2" />
//                 </Form.Item>
//               </Col>
//               <Col span={12}>
//                 <Form.Item
//                   name={['promptConfig', 'k']}
//                   label="选择示例数量"
//                   initialValue={4}
//                 >
//                   <InputNumber min={1} max={20} />
//                 </Form.Item>
//               </Col>
//             </Row>
//           </div>
//         );

//       case PromptType.CHAT_WITH_HISTORY:
//         return (
//           <div>
//             <Form.Item
//               name={['promptConfig', 'system_message']}
//               label="系统消息"
//               rules={[{ required: true, message: '请输入系统消息' }]}
//             >
//               <TextArea rows={4} placeholder="定义AI的角色和行为" />
//             </Form.Item>
//             <Form.Item
//               name={['promptConfig', 'human_template']}
//               label="人类消息模板"
//               rules={[{ required: true, message: '请输入人类消息模板' }]}
//             >
//               <TextArea rows={3} placeholder="例如：请回答关于{topic}的问题" />
//             </Form.Item>
//             <Form.Item
//               name={['promptConfig', 'history_variable']}
//               label="历史记录变量名"
//               initialValue="history"
//             >
//               <Input placeholder="存储历史记录的变量名" />
//             </Form.Item>
//             <Form.Item
//               name={['promptConfig', 'input_variables']}
//               label="输入变量"
//             >
//               <Select
//                 mode="tags"
//                 placeholder="输入变量名后按回车添加"
//                 tokenSeparators={[',']}
//                 dropdownStyle={{ display: 'none' }}
//               />
//             </Form.Item>
//           </div>
//         );

//       case PromptType.FEW_SHOT_CHAT:
//         return (
//           <div>
//             <Form.Item
//               name={['promptConfig', 'system_message']}
//               label="系统消息"
//               rules={[{ required: true, message: '请输入系统消息' }]}
//             >
//               <TextArea rows={4} placeholder="定义AI的角色和行为" />
//             </Form.Item>
//             <Form.Item
//               name={['promptConfig', 'examples']}
//               label="示例对话"
//               rules={[{ required: true, message: '请输入示例对话' }]}
//             >
//               <TextArea
//                 rows={6}
//                 placeholder='JSON格式的示例列表，例如：[{"input":"开心的反义词是什么？","output":"伤心"},...]'
//               />
//             </Form.Item>
//             <Form.Item
//               name={['promptConfig', 'human_template']}
//               label="人类消息模板"
//               rules={[{ required: true, message: '请输入人类消息模板' }]}
//             >
//               <TextArea rows={3} placeholder="例如：{question}" />
//             </Form.Item>
//             <Form.Item
//               name={['promptConfig', 'input_variables']}
//               label="输入变量"
//             >
//               <Select
//                 mode="tags"
//                 placeholder="输入变量名后按回车添加"
//                 tokenSeparators={[',']}
//                 dropdownStyle={{ display: 'none' }}
//               />
//             </Form.Item>
//           </div>
//         );

//       default:
//         return <div>请选择提示词类型</div>;
//     }
//   };

//   return renderPromptConfigForm();
// };

// const AgentConfig = ({
//   form: parentForm,
//   availableModels = Object.keys(MODEL_TYPES).map(key => ({
//     id: key,
//     name: MODEL_TYPES[key].name,
//     type: '大语言模型'
//   }))
// }) => {
//   const [localForm] = Form.useForm();
//   const form = parentForm || localForm;

//   // State management
//   const [execStrategy, setExecStrategy] = React.useState('single');
//   const [modelMode, setModelMode] = React.useState('single');
//   const [selectedPromptId, setSelectedPromptId] = React.useState('general');
//   const [customTools, setCustomTools] = React.useState([]);
//   const [showAddToolForm, setShowAddToolForm] = React.useState(false);
//   const [currentToolIndex, setCurrentToolIndex] = React.useState(-1);
//   const [customVariables, setCustomVariables] = React.useState([]);
//   const [newVariableName, setNewVariableName] = React.useState('');
//   const [formValues, setFormValues] = React.useState({});
//   const [promptType, setPromptType] = React.useState(PromptType.CHAT);
  
//   const [inputModality, setInputModality] = React.useState(ModalityType.TEXT);
//   const [outputType, setOutputType] = React.useState(OutputType.TEXT);

//   // 使用 useMemo 缓存预设提示词配置
//   const presetPromptConfig = React.useMemo(() => {
//     const prompt = PRESET_PROMPTS.find(p => p.id === selectedPromptId);
//     return prompt ? prompt.config : PRESET_PROMPTS[0].config;
//   }, [selectedPromptId]);

//   // 初始化表单值
//   React.useEffect(() => {
//     if (!form) return;

//     form.setFieldsValue({
//       promptConfig: presetPromptConfig,
//       enabledTools: PREDEFINED_TOOLS.map(tool => tool.name),
//       customTools: [],
//       modelType: 'openai',
//       multiModelConfigs: []
//     });

//     setPromptType(presetPromptConfig.prompt_type || PromptType.CHAT);
//   }, [form, presetPromptConfig]);

//   // 监听表单值变化
//   const handleValuesChange = (changedValues, allValues) => {
//     setFormValues(allValues);
    
//     // 当 promptConfig.prompt_type 变化时更新状态
//     if (changedValues.promptConfig?.prompt_type) {
//       setPromptType(changedValues.promptConfig.prompt_type);
//     }
//   };

//    const handleModelModeChange = (e) => {
//     const mode = e.target.value;
//     setModelMode(mode);
    
//     if (mode === 'single') {
//       form.setFieldsValue({
//         multiModels: undefined,
//         multiModelConfigs: [],
//         modelWeightStrategy: undefined,
//         modelWeights: undefined
//       });
//     } else {
//       form.setFieldsValue({
//         modelType: undefined,
//         modelConfig: undefined
//       });
//     }
//   };

//    const renderSingleModelConfig = () => (
//     <>
//       <Form.Item
//         name="modelType"
//         label="模型类型"
//         rules={[{ required: true, message: '请选择模型类型' }]}
//       >
//         <Select placeholder="选择模型类型">
//           {Object.keys(MODEL_TYPES).map(key => (
//             <Select.Option key={key} value={key}>
//               {MODEL_TYPES[key].name}
//             </Select.Option>
//           ))}
//         </Select>
//       </Form.Item>

//       {formValues.modelType && (
//         <ModelConfigForm 
//           modelType={formValues.modelType} 
//           form={form}
//           namePrefix={['modelConfig']}
//         />
//       )}
//     </>
//   );

//   // 渲染多模型融合配置
//   const renderMultiModelConfig = () => (
//     <>
//       <Form.Item
//         name="modelWeightStrategy"
//         label="融合策略"
//         initialValue="weighted"
//       >
//         <Select>
//           <Select.Option value="weighted">加权融合（手动设置权重）</Select.Option>
//           <Select.Option value="average">平均融合</Select.Option>
//           <Select.Option value="rank">按性能排序（取Top2）</Select.Option>
//         </Select>
//       </Form.Item>

//       <MultiModelConfig 
//         models={availableModels} 
//         form={form} 
//       />

//       {formValues.modelWeightStrategy === 'weighted' && (
//         <Form.Item label="模型权重">
//           <Form.List name="modelWeights">
//             {(fields) => (
//               <Row gutter={16}>
//                 {fields.map(({ key, name, ...restField }) => {
//                   const modelId = form.getFieldValue(['multiModelConfigs', name, 'modelType']);
//                   const modelName = modelId ? MODEL_TYPES[modelId]?.name || modelId : '未知模型';
                  
//                   return (
//                     <Col span={8} key={key}>
//                       <Form.Item
//                         {...restField}
//                         name={[name]}
//                         label={modelName}
//                         rules={[
//                           { required: true, message: '请输入权重' },
//                           { type: 'number', min: 0.1, max: 0.9, message: '权重必须在0.1到0.9之间' }
//                         ]}
//                         initialValue={1 / (formValues.multiModelConfigs?.length || 1)}
//                       >
//                         <InputNumber
//                           min={0.1}
//                           max={0.9}
//                           step={0.1}
//                           formatter={value => `${(value * 100).toFixed(0)}%`}
//                           parser={value => value.replace('%', '') / 100}
//                         />
//                       </Form.Item>
//                     </Col>
//                   );
//                 })}
//               </Row>
//             )}
//           </Form.List>
//         </Form.Item>
//       )}
//     </>
//   );

//   // 监听 prompt_type 变化的处理函数
//   const handlePromptTypeChange = (value) => {
//     setPromptType(value);
//     form.setFieldsValue({
//       promptConfig: {
//         ...form.getFieldValue('promptConfig'),
//         prompt_type: value
//       }
//     });
//   };

//   // 预设提示词选择处理
//   const handlePresetPromptChange = (id) => {
//     setSelectedPromptId(id);
//     const prompt = PRESET_PROMPTS.find(p => p.id === id);
//     if (prompt && form) {
//       form.setFieldsValue({ 
//         promptConfig: prompt.config 
//       });
//       setPromptType(prompt.config.prompt_type);
//     }
//   };

//   // Add custom variable
//   const handleAddVariable = () => {
//     if (!newVariableName.trim()) {
//       message.warning('请输入变量名');
//       return;
//     }

//     if (customVariables.some(v => v.name === newVariableName)) {
//       message.warning('变量名已存在');
//       return;
//     }

//     setCustomVariables([...customVariables, { name: newVariableName, description: '' }]);
//     setNewVariableName('');
//   };

//   const handleDeleteToolParam = (paramIndex) => {
//     if (currentToolIndex === -1) return;

//     const updatedTools = [...customTools];
//     updatedTools[currentToolIndex].parameters.splice(paramIndex, 1);

//     setCustomTools(updatedTools);
//     if (form) {
//       form.setFieldsValue({ customTools: updatedTools });
//     }
//   };

//   // 删除工具
//   const handleDeleteTool = (index) => {
//     const updatedTools = [...customTools];
//     updatedTools.splice(index, 1);
//     setCustomTools(updatedTools);
//     if (form) {
//       form.setFieldsValue({ customTools: updatedTools });
//     }

//     // 如果正在编辑的工具被删除，关闭编辑表单
//     if (currentToolIndex === index) {
//       setShowAddToolForm(false);
//       setCurrentToolIndex(-1);
//     }
//   };

//   // 编辑工具
//   const handleEditTool = (index) => {
//     setCurrentToolIndex(index);
//     setShowAddToolForm(true);
//   };

//   const handleSaveTool = (toolData) => {
//     const updatedTools = [...customTools];
//     if (currentToolIndex === -1) {
//       // 新增工具
//       updatedTools.push(toolData);
//     } else {
//       // 更新现有工具
//       updatedTools[currentToolIndex] = toolData;
//     }

//     setCustomTools(updatedTools);
//     if (form) {
//       form.setFieldsValue({ customTools: updatedTools });
//     }
//     setShowAddToolForm(false);
//     setCurrentToolIndex(-1);
//   };

//   // 添加工具参数
//   const handleAddToolParam = () => {
//     if (currentToolIndex === -1) return;

//     const updatedTools = [...customTools];
//     const newParam = { name: `param_${updatedTools[currentToolIndex].parameters.length}`, type: 'string', required: false };
//     updatedTools[currentToolIndex].parameters = [...updatedTools[currentToolIndex].parameters, newParam];

//     setCustomTools(updatedTools);
//     if (form) {
//       form.setFieldsValue({ customTools: updatedTools });
//     }
//   };
//   // 在表单中添加输入/输出预览区域
//   const renderPreviewSection = () => {
//     return (
//       <Card title="多模态预览" style={{ marginTop: 16 }}>
//         <Tabs>
//           <TabPane tab="输入预览" key="input">
//             {inputModality === ModalityType.IMAGE && (
//               <ImageUploadPreview
//                 onImageUpload={(base64) => {
//                   form.setFieldsValue({ inputImage: base64 });
//                 }}
//               />
//             )}
//             {inputModality === ModalityType.AUDIO && (
//               <AudioUploadPreview
//                 onAudioUpload={(base64) => {
//                   form.setFieldsValue({ inputAudio: base64 });
//                 }}
//               />
//             )}
//           </TabPane>
//           <TabPane tab="输出预览" key="output">
//             <OutputPreview 
//               outputType={outputType}
//               outputData={formValues.outputData}
//             />
//           </TabPane>
//         </Tabs>
//       </Card>
//     );
//   };

// const ImageUploadPreview = ({ onImageUpload }) => {
//   const [previewImage, setPreviewImage] = React.useState('');
  
//   const handleImageUpload = (e) => {
//     const file = e.target.files[0];
//     if (file) {
//       const reader = new FileReader();
//       reader.onload = (event) => {
//         const base64 = event.target.result.split(',')[1];
//         setPreviewImage(event.target.result);
//         onImageUpload(base64);
//       };
//       reader.readAsDataURL(file);
//     }
//   };
  
//   return (
//     <div>
//       <input type="file" accept="image/*" onChange={handleImageUpload} />
//       {previewImage && (
//         <img 
//           src={previewImage} 
//           alt="预览" 
//           style={{ maxWidth: '100%', maxHeight: '300px', marginTop: '16px' }} 
//         />
//       )}
//     </div>
//   );
// };

// const AudioUploadPreview = ({ onAudioUpload }) => {
//   const [audioUrl, setAudioUrl] = React.useState('');
  
//   const handleAudioUpload = (e) => {
//     const file = e.target.files[0];
//     if (file) {
//       const reader = new FileReader();
//       reader.onload = (event) => {
//         const base64 = event.target.result.split(',')[1];
//         setAudioUrl(event.target.result);
//         onAudioUpload(base64);
//       };
//       reader.readAsDataURL(file);
//     }
//   };
  
//   return (
//     <div>
//       <input type="file" accept="audio/*" onChange={handleAudioUpload} />
//       {audioUrl && (
//         <audio controls src={audioUrl} style={{ marginTop: '16px', width: '100%' }} />
//       )}
//     </div>
//   );
// };

// const OutputPreview = ({ outputType, outputData }) => {
//   if (!outputData) {
//     return <div>暂无输出数据</div>;
//   }
  
//   switch (outputType) {
//     case OutputType.IMAGE:
//       return (
//         <img 
//           src={`data:image/jpeg;base64,${outputData}`} 
//           alt="生成图像" 
//           style={{ maxWidth: '100%', maxHeight: '300px' }} 
//         />
//       );
//     case OutputType.AUDIO:
//       return (
//         <audio 
//           controls 
//           src={`data:audio/wav;base64,${outputData}`} 
//           style={{ width: '100%' }} 
//         />
//       );
//     case OutputType.JSON:
//       return (
//         <pre style={{ 
//           background: '#f5f5f5', 
//           padding: '16px', 
//           borderRadius: '4px',
//           maxHeight: '300px',
//           overflow: 'auto'
//         }}>
//           {JSON.stringify(outputData, null, 2)}
//         </pre>
//       );
//     case OutputType.MARKDOWN:
//       return (
//         <div 
//           style={{ 
//             border: '1px solid #e8e8e8', 
//             padding: '16px', 
//             borderRadius: '4px',
//             maxHeight: '300px',
//             overflow: 'auto'
//           }}
//           dangerouslySetInnerHTML={{ __html: marked(outputData) }}
//         />
//       );
//     case OutputType.HTML:
//       return (
//         <div 
//           style={{ 
//             border: '1px solid #e8e8e8', 
//             padding: '16px', 
//             borderRadius: '4px',
//             maxHeight: '300px',
//             overflow: 'auto'
//           }}
//           dangerouslySetInnerHTML={{ __html: outputData }}
//         />
//       );
//     default:
//       return <div style={{ whiteSpace: 'pre-wrap' }}>{outputData}</div>;
//   }
// };

//   const renderToolForm = () => {
//     const tool = currentToolIndex !== -1 && customTools[currentToolIndex]
//       ? { ...customTools[currentToolIndex] }
//       : { name: `tool_${Date.now().toString().slice(-4)}`, description: '', parameters: [], code: 'def tool_function():\n    # 工具函数实现\n    return "结果"' };

//     return (
//       <Card title={currentToolIndex === -1 ? "添加自定义工具" : "编辑工具"}>
//         <Form layout="vertical">
//           <Form.Item
//             label="工具名称"
//             rules={[{ required: true, message: '请输入工具名称' }]}
//           >
//             <Input
//               value={tool.name}
//               onChange={(e) => {
//                 const updatedTools = [...customTools];
//                 if (currentToolIndex === -1) {
//                   tool.name = e.target.value;
//                 } else {
//                   updatedTools[currentToolIndex].name = e.target.value;
//                   setCustomTools(updatedTools);
//                   if (form) {
//                     form.setFieldsValue({ customTools: updatedTools });
//                   }
//                 }
//               }}
//             />
//           </Form.Item>

//           <Form.Item
//             label="工具描述"
//             rules={[{ required: true, message: '请输入工具描述' }]}
//           >
//             <TextArea
//               rows={2}
//               value={tool.description}
//               onChange={(e) => {
//                 const updatedTools = [...customTools];
//                 if (currentToolIndex === -1) {
//                   tool.description = e.target.value;
//                 } else {
//                   updatedTools[currentToolIndex].description = e.target.value;
//                   setCustomTools(updatedTools);
//                   if (form) {
//                     form.setFieldsValue({ customTools: updatedTools });
//                   }
//                 }
//               }}
//             />
//           </Form.Item>

//           <Form.Item label="参数列表">
//             <div style={{ marginBottom: 8 }}>
//               {tool.parameters.map((param, index) => (
//                 <Row gutter={8} key={index} align="middle">
//                   <Col span={8}>
//                     <Input
//                       placeholder="参数名称"
//                       value={param.name}
//                       onChange={(e) => {
//                         const updatedTools = [...customTools];
//                         const paramValue = e.target.value;
//                         if (currentToolIndex === -1) {
//                           tool.parameters[index].name = paramValue;
//                         } else {
//                           updatedTools[currentToolIndex].parameters[index].name = paramValue;
//                           setCustomTools(updatedTools);
//                           if (form) {
//                             form.setFieldsValue({ customTools: updatedTools });
//                           }
//                         }
//                       }}
//                     />
//                   </Col>
//                   <Col span={6}>
//                     <Select
//                       value={param.type}
//                       onChange={(value) => {
//                         const updatedTools = [...customTools];
//                         if (currentToolIndex === -1) {
//                           tool.parameters[index].type = value;
//                         } else {
//                           updatedTools[currentToolIndex].parameters[index].type = value;
//                           setCustomTools(updatedTools);
//                           if (form) {
//                             form.setFieldsValue({ customTools: updatedTools });
//                           }
//                         }
//                       }}
//                     >
//                       <Select.Option value="string">字符串</Select.Option>
//                       <Select.Option value="number">数字</Select.Option>
//                       <Select.Option value="boolean">布尔值</Select.Option>
//                       <Select.Option value="array">数组</Select.Option>
//                       <Select.Option value="object">对象</Select.Option>
//                     </Select>
//                   </Col>
//                   <Col span={6}>
//                     <Switch
//                       checked={param.required}
//                       onChange={(checked) => {
//                         const updatedTools = [...customTools];
//                         if (currentToolIndex === -1) {
//                           tool.parameters[index].required = checked;
//                         } else {
//                           updatedTools[currentToolIndex].parameters[index].required = checked;
//                           setCustomTools(updatedTools);
//                           if (form) {
//                             form.setFieldsValue({ customTools: updatedTools });
//                           }
//                         }
//                       }}
//                     />
//                     <span style={{ marginLeft: 8 }}>必填</span>
//                   </Col>
//                   <Col span={2}>
//                     <Button
//                       icon={<DeleteOutlined />}
//                       danger
//                       size="small"
//                       onClick={() => handleDeleteToolParam(index)}
//                     />
//                   </Col>
//                 </Row>
//               ))}
//               <Button
//                 type="dashed"
//                 icon={<PlusOutlined />}
//                 onClick={handleAddToolParam}
//                 style={{ marginTop: 8 }}
//               >
//                 添加参数
//               </Button>
//             </div>
//           </Form.Item>

//           <Form.Item
//             label="工具代码实现"
//             rules={[{ required: true, message: '请输入工具代码' }]}
//           >
//             <AceEditor
//               mode="python"
//               theme="monokai"
//               name="tool-code-editor"
//               value={tool.code}
//               onChange={(value) => {
//                 const updatedTools = [...customTools];
//                 if (currentToolIndex === -1) {
//                   tool.code = value;
//                 } else {
//                   updatedTools[currentToolIndex].code = value;
//                   setCustomTools(updatedTools);
//                   if (form) {
//                     form.setFieldsValue({ customTools: updatedTools });
//                   }
//                 }
//               }}
//               fontSize={14}
//               showGutter={true}
//               height="200px"
//               width="100%"
//               showPrintMargin={false}
//               showLineNumbers={true}
//               highlightActiveLine={true}
//             />
//           </Form.Item>

//           <Form.Item>
//             <Space>
//               <Button
//                 type="primary"
//                 onClick={() => handleSaveTool(tool)}
//               >
//                 保存
//               </Button>
//               <Button
//                 onClick={() => {
//                   setShowAddToolForm(false);
//                   setCurrentToolIndex(-1);
//                 }}
//               >
//                 取消
//               </Button>
//             </Space>
//           </Form.Item>
//         </Form>
//       </Card>
//     );
//   };

//   // Remove custom variable
//   const handleRemoveVariable = (name) => {
//     setCustomVariables(customVariables.filter(v => v.name !== name));
//   };

//   // Update variable description
//   const handleUpdateVariableDesc = (name, description) => {
//     setCustomVariables(customVariables.map(v =>
//       v.name === name ? { ...v, description } : v
//     ));
//   };

//   // Render available variables section
//   const renderVariablesSection = () => {
//     const defaultVariables = [
//       { name: 'agentName', description: '当前Agent名称' },
//       { name: 'currentTime', description: '当前时间' },
//       { name: 'userId', description: '用户ID' },
//       { name: 'tools', description: '可用工具列表' },
//       { name: 'historySummary', description: '历史对话摘要' },
//       { name: 'question', description: '用户输入' }
//     ];

//     return (
//       <div>
//         <Divider orientation="left">可用变量</Divider>
//         <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginBottom: 16 }}>
//           {defaultVariables.map(v => (
//             <Tooltip key={v.name} title={v.description}>
//               <Tag color="blue">{v.name}</Tag>
//             </Tooltip>
//           ))}
//           {customVariables.map(v => (
//             <Tooltip key={v.name} title={v.description || '无描述'}>
//               <Tag
//                 color="purple"
//                 closable
//                 onClose={() => handleRemoveVariable(v.name)}
//               >
//                 {v.name}
//               </Tag>
//             </Tooltip>
//           ))}
//         </div>

//         <div style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
//           <Input
//             placeholder="输入新变量名"
//             value={newVariableName}
//             onChange={(e) => setNewVariableName(e.target.value)}
//             style={{ width: 200 }}
//           />
//           <Button type="primary" onClick={handleAddVariable}>添加变量</Button>
//         </div>

//         {customVariables.length > 0 && (
//           <div style={{ marginBottom: 16 }}>
//             {customVariables.map(v => (
//               <div key={v.name} style={{ marginBottom: 8 }}>
//                 <span style={{ marginRight: 8 }}>{v.name}:</span>
//                 <Input
//                   placeholder="变量描述"
//                   value={v.description}
//                   onChange={(e) => handleUpdateVariableDesc(v.name, e.target.value)}
//                   style={{ width: 300 }}
//                 />
//               </div>
//             ))}
//           </div>
//         )}
//       </div>
//     );
//   };

//   // Render model configuration based on selected type
//   const renderModelConfig = () => {
//     const modelType = formValues.modelType || 'openai';
//     const modelConfig = MODEL_TYPES[modelType] || MODEL_TYPES.openai;

//     return (
//       <div>
//         <Row gutter={16}>
//           {modelConfig.required.map(param => (
//             <Col span={12} key={param}>
//               <Form.Item
//                 name={['modelConfig', param]}
//                 label={param.replace('_', ' ')}
//                 rules={[{ required: true, message: `请输入${param}` }]}
//               >
//                 {param === 'api_key' || param === 'secret_key' ? (
//                   <Input.Password placeholder={`请输入${param}`} />
//                 ) : (
//                   <Input placeholder={`请输入${param}`} />
//                 )}
//               </Form.Item>
//             </Col>
//           ))}
//         </Row>

//         <Collapse ghost>
//           <Panel header="高级参数" key="advanced">
//             <Row gutter={16}>
//               {modelConfig.optional.map(param => (
//                 <Col span={12} key={param}>
//                   <Form.Item
//                     name={['modelConfig', param]}
//                     label={param.replace('_', ' ')}
//                   >
//                     {param === 'temperature' ? (
//                       <Slider min={0} max={2} step={0.1} />
//                     ) : param === 'quantization' ? (
//                       <Select>
//                         <Select.Option value="int8">INT8</Select.Option>
//                         <Select.Option value="int4">INT4</Select.Option>
//                       </Select>
//                     ) : (
//                       <Input placeholder={`请输入${param}`} />
//                     )}
//                   </Form.Item>
//                 </Col>
//               ))}
//             </Row>
//           </Panel>
//         </Collapse>

//         {/* 添加多模态支持选项 */}
//         <Form.Item
//           name="supportsMultimodal"
//           label="多模态支持"
//           valuePropName="checked"
//         >
//           <Switch 
//             checked={formValues.supportsMultimodal}
//             onChange={checked => {
//               form.setFieldsValue({ supportsMultimodal: checked });
//               if (!checked) {
//                 form.setFieldsValue({
//                   inputModality: ModalityType.TEXT,
//                   outputType: OutputType.TEXT
//                 });
//               }
//             }}
//           />
//         </Form.Item>
        
//         {formValues.supportsMultimodal && (
//           <>
//             <Form.Item
//               name="inputModality"
//               label="输入模态"
//               initialValue={ModalityType.TEXT}
//             >
//               <Select>
//                 {Object.values(ModalityType).map(modality => (
//                   <Select.Option key={modality} value={modality}>
//                     {modality}
//                   </Select.Option>
//                 ))}
//               </Select>
//             </Form.Item>
            
//             <Form.Item
//               name="outputType"
//               label="输出类型"
//               initialValue={OutputType.TEXT}
//             >
//               <Select>
//                 {Object.values(OutputType).map(type => (
//                   <Select.Option key={type} value={type}>
//                     {type}
//                   </Select.Option>
//                 ))}
//               </Select>
//             </Form.Item>
//           </>
//         )}
//       </div>
//     );
//   };

//   return (
//     <Form 
//       form={form} 
//       layout="vertical" 
//       initialValues={{
//         agentName: 'SmartAgent',
//         execStrategy: 'single',
//         promptConfig: presetPromptConfig,
//         modelMode: 'single',
//         modelType: 'openai',
//         temperature: 0.7,
//         maxTokens: 1024,
//         outputMergeStrategy: 'takeFirst',
//         memoryEnabled: true,
//         memorySize: 10,
//         maxIterations: 5,
//         enabledTools: PREDEFINED_TOOLS.map(tool => tool.name),
//         vectorStore: 'faiss',
//         multiModelConfigs: []
//       }}
//       onValuesChange={handleValuesChange}
//     >
//       <Tabs defaultActiveKey="basic" style={{ marginBottom: 20 }}>
//         {/* 1. Basic Configuration */}
//         <TabPane tab={<span><SettingOutlined /> 基础配置</span>} key="basic">
//           <Card title="Agent基本信息">
//             <Form.Item
//               name="agentName"
//               label="Agent名称"
//               rules={[{ required: true, message: '请输入Agent名称' }]}
//             >
//               <Input placeholder="例如：财务分析Agent、客服助手" />
//             </Form.Item>

//             <Divider orientation="left">执行策略</Divider>
//             <Form.Item
//               name="execStrategy"
//               label="决策模式"
//               rules={[{ required: true }]}
//             >
//               <Radio.Group onChange={(e) => setExecStrategy(e.target.value)}>
//                 <Radio value="single">单Agent执行</Radio>
//                 <Radio value="parallel">多Agent并行决策</Radio>
//                 <Radio value="sequential">多Agent串行决策</Radio>
//                 <Radio value="vote">投票决策（共识机制）</Radio>
//               </Radio.Group>
//             </Form.Item>

//             {execStrategy !== 'single' && (
//               <>
//                 <Form.Item
//                   name="participatingAgents"
//                   label="参与Agent"
//                   rules={[{ required: true, message: '请选择参与的Agent' }]}
//                 >
//                   <Select mode="multiple" placeholder="选择需要协同的Agent">
//                     {availableModels.map(agent => (
//                       <Select.Option key={agent.id} value={agent.id}>
//                         {agent.name}（{agent.type}）
//                       </Select.Option>
//                     ))}
//                   </Select>
//                 </Form.Item>

//                 {execStrategy === 'sequential' && (
//                   <Form.Item
//                     name="executionOrder"
//                     label="执行顺序"
//                     rules={[{ required: true, message: '请输入执行顺序' }]}
//                   >
//                     <Input placeholder="用逗号分隔的Agent ID，例如：agent1,agent2,agent3" />
//                   </Form.Item>
//                 )}

//                 {execStrategy === 'vote' && (
//                   <Form.Item
//                     name="voteThreshold"
//                     label="投票通过阈值"
//                     tooltip={<span><InfoCircleOutlined /> 达到该比例的Agent同意时，视为通过</span>}
//                     initialValue={0.7}
//                   >
//                     <Slider
//                       min={0.5}
//                       max={1}
//                       step={0.05}
//                       marks={{ 0.5: '50%', 0.7: '70%', 0.9: '90%', 1: '100%' }}
//                     />
//                   </Form.Item>
//                 )}
//               </>
//             )}
//           </Card>
//         </TabPane>

//         {/* 2. Prompt Configuration */}
//         <TabPane tab={<span><FileTextOutlined /> 提示词配置</span>} key="prompt">
//           <Card title="提示词模板配置">
//             <Row gutter={16}>
//               <Col span={6}>
//                 <div style={{ border: '1px solid #e8e8e8', borderRadius: 4, padding: 12, height: '100%' }}>
//                   <p style={{ fontWeight: 'bold', marginBottom: 12 }}>预设模板</p>
//                   <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
//                     {PRESET_PROMPTS.map(prompt => (
//                       <Button
//                         key={prompt.id}
//                         type={selectedPromptId === prompt.id ? 'primary' : 'default'}
//                         onClick={() => handlePresetPromptChange(prompt.id)}
//                         block
//                         size="small"
//                       >
//                         {prompt.name}
//                       </Button>
//                     ))}
//                   </div>

//                   <Divider style={{ margin: '16px 0' }} />

//                   <p style={{ fontWeight: 'bold', marginBottom: 12 }}>提示词类型</p>
//                   <Radio.Group
//                     value={promptType}
//                     onChange={(e) => handlePromptTypeChange(e.target.value)}
//                     style={{ display: 'flex', flexDirection: 'column', gap: 8 }}
//                   >
//                     <Radio.Button value={PromptType.SIMPLE}>简单提示</Radio.Button>
//                     <Radio.Button value={PromptType.CHAT}>聊天提示</Radio.Button>
//                     <Radio.Button value={PromptType.FEW_SHOT}>少样本提示</Radio.Button>
//                     <Radio.Button value={PromptType.MMR_FEW_SHOT}>MMR少样本</Radio.Button>
//                     <Radio.Button value={PromptType.CHAT_WITH_HISTORY}>带历史聊天</Radio.Button>
//                     <Radio.Button value={PromptType.FEW_SHOT_CHAT}>少样本聊天</Radio.Button>
//                   </Radio.Group>
//                 </div>
//               </Col>

//               <Col span={18}>
//                 <PromptConfigForm promptType={promptType} form={form} />
//                 {renderVariablesSection()}
//               </Col>
//             </Row>
//           </Card>
//         </TabPane>

//         {/* 3. Model Configuration */}
//         <TabPane tab={<span><RobotOutlined /> 模型配置</span>} key="model">
//           <Card title="模型设置">
//             <Form.Item
//               name="modelMode"
//               label="模型模式"
//               rules={[{ required: true }]}
//             >
//               <Radio.Group onChange={(e) => setModelMode(e.target.value)}>
//                 <Radio value="single">单模型</Radio>
//                 <Radio value="multiple">多模型融合</Radio>
//               </Radio.Group>
//             </Form.Item>

//             {modelMode === 'single' ? renderSingleModelConfig() : renderMultiModelConfig()}

//             <Divider orientation="left">模型参数</Divider>
//             <Row gutter={16}>
//               <Col span={12}>
//                 <Form.Item
//                   name="temperature"
//                   label="温度值"
//                   tooltip={<span><InfoCircleOutlined /> 0=确定性输出，2=高度随机</span>}
//                 >
//                   <Slider min={0} max={2} step={0.1} marks={{ 0: '0', 1: '1', 2: '2' }} />
//                 </Form.Item>
//               </Col>
//               <Col span={12}>
//                 <Form.Item
//                   name="maxTokens"
//                   label="最大输出长度"
//                 >
//                   <InputNumber min={256} max={8192} step={256} />
//                 </Form.Item>
//               </Col>
//             </Row>

//             <Row gutter={16}>
//               <Col span={12}>
//                 <Form.Item
//                   name="topP"
//                   label="Top P"
//                   tooltip={<span><InfoCircleOutlined /> 控制输出的多样性，0.5表示只从累积概率50%的候选词中选择</span>}
//                   initialValue={0.7}
//                 >
//                   <Slider min={0} max={1} step={0.1} marks={{ 0: '0', 0.5: '0.5', 1: '1' }} />
//                 </Form.Item>
//               </Col>
//               <Col span={12}>
//                 <Form.Item
//                   name="frequencyPenalty"
//                   label="频率惩罚"
//                   tooltip={<span><InfoCircleOutlined /> 减少重复内容的生成，值越高惩罚越强</span>}
//                   initialValue={0}
//                 >
//                   <Slider min={-2} max={2} step={0.1} marks={{ '-2': '-2', '0': '0', '2': '2' }} />
//                 </Form.Item>
//               </Col>
//             </Row>
//           </Card>
//         </TabPane>

//         {/* 4. Action Configuration */}
//         <TabPane tab={<span><CodeOutlined /> 动作配置</span>} key="action">
//           <Card title="工具与动作配置">
//             <Form.Item
//               name="enabledTools"
//               label="启用的工具"
//               rules={[{ required: true, message: '请至少选择一个工具' }]}
//             >
//               <Select mode="multiple" placeholder="选择Agent可使用的工具">
//                 {PREDEFINED_TOOLS.map(tool => (
//                   <Select.Option key={tool.name} value={tool.name}>
//                     {tool.name} - {tool.description}
//                   </Select.Option>
//                 ))}
//                 {customTools.map((tool, index) => (
//                   <Select.Option key={`custom_${index}`} value={`custom_${tool.name}`}>
//                     <Badge status="processing" text="自定义" /> {tool.name} - {tool.description}
//                   </Select.Option>
//                 ))}
//               </Select>
//             </Form.Item>

//             <Divider orientation="left">预定义工具详情</Divider>
//             <div style={{ marginBottom: 24 }}>
//               {formValues.enabledTools?.map(toolName => {
//                 const predefinedTool = PREDEFINED_TOOLS.find(t => t.name === toolName);
//                 if (predefinedTool) {
//                   return (
//                     <Card key={toolName} title={predefinedTool.name} style={{ marginBottom: 12 }}>
//                       <p><strong>描述：</strong>{predefinedTool.description}</p>
//                       {predefinedTool.parameters.length > 0 && (
//                         <>
//                           <p><strong>参数：</strong></p>
//                           <ul>
//                             {predefinedTool.parameters.map((param, idx) => (
//                               <li key={idx}>
//                                 {param.name} ({param.type}) {param.required ? <Badge status="error" text="必填" /> : ''}
//                               </li>
//                             ))}
//                           </ul>
//                         </>
//                       )}
//                     </Card>
//                   );
//                 }
//                 return null;
//               })}
//             </div>

//             <Divider orientation="left">自定义工具</Divider>
//             <Space style={{ marginBottom: 16 }}>
//               <Button
//                 type="primary"
//                 icon={<PlusOutlined />}
//                 onClick={() => {
//                   setCurrentToolIndex(-1);
//                   setShowAddToolForm(true);
//                 }}
//               >
//                 添加自定义工具
//               </Button>
//             </Space>

//             {showAddToolForm ? (
//               renderToolForm()
//             ) : (
//               <div>
//                 {customTools.length === 0 ? (
//                   <p style={{ textAlign: 'center', color: '#666', padding: 16 }}>
//                     暂无自定义工具，点击"添加自定义工具"按钮创建
//                   </p>
//                 ) : (
//                   <div>
//                     {customTools.map((tool, index) => (
//                       <Card key={index} title={tool.name} style={{ marginBottom: 12 }}>
//                         <Row justify="space-between" align="middle">
//                           <Col flex="auto">
//                             <p><strong>描述：</strong>{tool.description}</p>
//                             {tool.parameters.length > 0 && (
//                               <>
//                                 <p><strong>参数：</strong></p>
//                                 <ul>
//                                   {tool.parameters.map((param, idx) => (
//                                     <li key={idx}>
//                                       {param.name} ({param.type}) {param.required ? <Badge status="error" text="必填" /> : ''}
//                                     </li>
//                                   ))}
//                                 </ul>
//                               </>
//                             )}
//                           </Col>
//                           <Col flex="none">
//                             <Space>
//                               <Button
//                                 icon={<EditOutlined />}
//                                 onClick={() => handleEditTool(index)}
//                               >
//                                 编辑
//                               </Button>
//                               <Button
//                                 icon={<DeleteOutlined />}
//                                 danger
//                                 onClick={() => handleDeleteTool(index)}
//                               >
//                                 删除
//                               </Button>
//                             </Space>
//                           </Col>
//                         </Row>
//                       </Card>
//                     ))}
//                   </div>
//                 )}
//               </div>
//             )}

//             <Divider orientation="left">动作控制</Divider>
//             <Row gutter={16}>
//               <Col span={12}>
//                 <Form.Item
//                   name="actionTimeout"
//                   label="动作超时时间（秒）"
//                   initialValue={30}
//                 >
//                   <InputNumber min={5} max={300} />
//                 </Form.Item>
//               </Col>
//               <Col span={12}>
//                 <Form.Item
//                   name="actionRateLimit"
//                   label="动作频率限制（次/分钟）"
//                   initialValue={60}
//                 >
//                   <InputNumber min={1} max={300} />
//                 </Form.Item>
//               </Col>
//             </Row>

//             <Form.Item
//               name="actionSafetyCheck"
//               label="动作安全检查"
//               initialValue="medium"
//             >
//               <Select>
//                 <Select.Option value="off">关闭（不检查）</Select.Option>
//                 <Select.Option value="medium">中等（检查高危动作）</Select.Option>
//                 <Select.Option value="strict">严格（检查所有动作）</Select.Option>
//               </Select>
//             </Form.Item>

//             {formValues.actionSafetyCheck !== 'off' && (
//               <Form.Item
//                 name="forbiddenActions"
//                 label="禁止执行的动作"
//               >
//                 <Select mode="multiple" placeholder="选择禁止执行的动作类型">
//                   <Select.Option value="file_write">文件写入</Select.Option>
//                   <Select.Option value="network_request">外部网络请求</Select.Option>
//                   <Select.Option value="system_command">系统命令执行</Select.Option>
//                   <Select.Option value="code_execution">代码执行</Select.Option>
//                 </Select>
//               </Form.Item>
//             )}
//           </Card>
//         </TabPane>

//         {/* 5. Advanced Configuration */}
//         <TabPane tab={<span><DatabaseOutlined /> 高级配置</span>} key="advanced">
//           <Card title="记忆配置">
//             <Form.Item
//               name="memoryEnabled"
//               label="启用对话记忆"
//               valuePropName="checked"
//               initialValue={true}
//             >
//               <Switch />
//             </Form.Item>

//             {formValues.memoryEnabled && (
//               <>
//                 <Form.Item
//                   name="memorySize"
//                   label="记忆轮数"
//                   initialValue={10}
//                 >
//                   <InputNumber min={1} max={50} />
//                 </Form.Item>

//                 <Form.Item
//                   name="memoryType"
//                   label="记忆类型"
//                   initialValue="full"
//                 >
//                   <Select>
//                     <Select.Option value="full">完整记忆（存储所有对话）</Select.Option>
//                     <Select.Option value="summary">摘要记忆（仅存储摘要）</Select.Option>
//                     <Select.Option value="relevant">相关记忆（仅存储相关内容）</Select.Option>
//                   </Select>
//                 </Form.Item>

//                 <Form.Item
//                   name="memoryPersist"
//                   label="持久化记忆"
//                   valuePropName="checked"
//                   initialValue={false}
//                 >
//                   <Switch />
//                   <span style={{ marginLeft: 8 }}>将对话记忆保存到持久化存储</span>
//                 </Form.Item>
//               </>
//             )}
//           </Card>

//           <Card title="向量存储配置" style={{ marginTop: 16 }}>
//             <Form.Item
//               name="vectorStore"
//               label="向量数据库"
//               initialValue="faiss"
//             >
//               <Select>
//                 {VECTOR_STORES.map(store => (
//                   <Select.Option key={store.value} value={store.value}>
//                     {store.label}
//                   </Select.Option>
//                 ))}
//               </Select>
//             </Form.Item>

//             {formValues.vectorStore && (
//               <>
//                 <Form.Item
//                   name={['vectorStoreConfig', 'path']}
//                   label="存储路径"
//                   rules={[{ required: true, message: '请输入存储路径' }]}
//                 >
//                   <Input placeholder="例如：./vector_store" />
//                 </Form.Item>

//                 {formValues.vectorStore !== 'faiss' && (
//                   <Form.Item
//                     name={['vectorStoreConfig', 'url']}
//                     label="数据库URL"
//                     rules={[{ required: true, message: '请输入数据库URL' }]}
//                   >
//                     <Input placeholder="例如：http://localhost:6333" />
//                   </Form.Item>
//                 )}

//                 {formValues.vectorStore === 'pinecone' && (
//                   <Form.Item
//                     name={['vectorStoreConfig', 'apiKey']}
//                     label="API密钥"
//                     rules={[{ required: true, message: '请输入API密钥' }]}
//                   >
//                     <Input.Password placeholder="请输入Pinecone API密钥" />
//                   </Form.Item>
//                 )}
//               </>
//             )}
//           </Card>

//           <Card title="执行控制" style={{ marginTop: 16 }}>
//             <Form.Item
//               name="maxIterations"
//               label="最大迭代次数"
//               initialValue={5}
//               tooltip={<span><InfoCircleOutlined /> Agent最多思考/调用工具的次数</span>}
//             >
//               <InputNumber min={1} max={20} />
//             </Form.Item>

//             <Form.Item
//               name="earlyStopping"
//               label="启用早停机制"
//               valuePropName="checked"
//               initialValue={true}
//             >
//               <Switch />
//               <span style={{ marginLeft: 8 }}>Agent认为完成任务时自动停止</span>
//             </Form.Item>

//             <Form.Item
//               name="verbose"
//               label="详细日志输出"
//               valuePropName="checked"
//               initialValue={false}
//             >
//               <Switch />
//               <span style={{ marginLeft: 8 }}>输出Agent思考过程和工具调用详情</span>
//             </Form.Item>
//           </Card>
//         </TabPane>

//         {formValues.supportsMultimodal && renderPreviewSection()}
//       </Tabs>

//       {/* Action Buttons */}
//       <div style={{ textAlign: 'right', marginTop: 24 }}>
//         <Space size="middle">
//           <Button type="default" onClick={() => form.resetFields()}>重置</Button>
//           <Button type="primary" onClick={() => {
//             form.validateFields()
//               .then(values => {
//                 console.log('Agent配置:', values);
//                 message.success('配置保存成功');
//               })
//               .catch(info => {
//                 console.log('验证失败:', info);
//                 message.error('配置验证失败，请检查表单');
//               });
//           }}>保存配置</Button>
//         </Space>
//       </div>
//     </Form>
//   );
// };

// export default AgentConfig;