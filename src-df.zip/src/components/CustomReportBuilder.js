import {
  Box,
  Typography,
  Button,
  Paper,
  Grid,
  Card,
  CardContent,
  CardHeader,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  DialogContentText,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  TextField,
  Chip,
  Divider,
  Checkbox,
  FormControlLabel,
  Snackbar,
  Alert,
  TableContainer,
  Table,
  TableHead,
  TableRow,
  TableBody,
  TableCell,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  useTheme,
  FormHelperText, // 添加这个
  Tooltip, // 添加这个

} from '@mui/material';
import {
  Add as AddIcon,
  Delete as DeleteIcon,
  Edit as SettingsIcon,
  Save as SaveIcon,
  Download as DownloadIcon,
  PieChart as PieChartIcon,
  BarChart as BarChartIcon,
  TrendingUp as LineChartIcon,
  TableChart as TableChartIcon,
  FileUpload as FileUploadIcon,
  FilterList as FilterIcon,
  HelpOutline as HelpIcon,
  ExpandMore as ExpandMoreIcon,
  DragIndicator as DragIcon,
  Radar as RadarChartIcon,      // 雷达图图标（原名称RadarChart → 重命名为RadarChartIcon）
  TableChart as TableIcon,                 // 表格图标（原名称Table → 重命名为TableIcon）
  CandlestickChart as CandlestickChartIcon, // K线图图标（原名称CandlestickChart → 重命名为CandlestickChartIcon）
  ScatterPlot as ScatterPlotIcon,     // 风险象限图图标（原名称ScatterPlot → 重命名为ScatterPlotIcon）
  GridView  as GridIcon,                   // Wafer Map图图标（原名称Grid → 重命名为GridIcon）
  HelpOutline as HelpOutlineIcon, // 添加这个
  ViewTimeline  as TimelineIcon,


} from '@mui/icons-material';

import axios from 'axios';
import { InputAdornment } from '@mui/material';
import React, { useState, useEffect } from 'react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Legend, ResponsiveContainer,
  LineChart, Line, PieChart, Pie, Cell,RadarChart,PolarGrid,PolarAngleAxis,PolarRadiusAxis,Radar,ScatterChart,ReferenceLine,Scatter,
} from 'recharts';

import { validateTemplate, getTemplateValidationReport } from './schemaValidator';
import { REPORT_TEMPLATE_SCHEMA } from './reportTemplateSchema';
import html2pdf from 'html2pdf.js';
import ReactECharts from 'echarts-for-react';
import * as echarts from 'echarts';
// 引入拖拽库
import { DragDropContext, Droppable, Draggable } from 'react-beautiful-dnd';
import  WaferMap  from './WaferMap'
import ProfessionalWaferMap from './ProfessionalWaferMap';

import { ThemeProvider, createTheme } from '@mui/material/styles';

export const FIELD_TYPES = {
  NUMERIC: 'numeric',     // 数值型
  CATEGORICAL: 'categorical', // 类别型
  DATETIME: 'datetime',   // 时间型
  UNKNOWN: 'unknown'      // 未知类型
};

const getNumericColumns = (columns, data) => {
  return columns.filter(col => getFieldType(data, col) === FIELD_TYPES.NUMERIC);
};

const getTextColumns = (columns, data) => {
  // 排除数值型、时间型和类别型，剩余视为文本型
  return columns.filter(col => {
    const fieldType = getFieldType(data, col);
    return [
      FIELD_TYPES.NUMERIC,
      FIELD_TYPES.DATETIME,

    ].includes(fieldType) === false;
  });
};


/**
 * 检测数据字段的类型
 * @param {Array} data - 原始数据集
 * @param {string} field - 待检测的字段名
 * @returns {string} 字段类型
 */
export const getFieldType = (data, field) => {
  if (!Array.isArray(data) || data.length === 0 || !field || !data[0].hasOwnProperty(field)) {
    return FIELD_TYPES.UNKNOWN;
  }

  const SAMPLE_SIZE = 50;
  const sampleData = data.slice(0, SAMPLE_SIZE);
  const fieldValues = sampleData.map(item => item[field]).filter(value => value !== undefined && value !== null);

  if (fieldValues.length === 0) {
    return FIELD_TYPES.UNKNOWN;
  }

  // 检测时间型
  const isDatetime = fieldValues.every(value => {
    if (typeof value === 'number') return false;
    const date = new Date(value);
    return !isNaN(date.getTime()) && isNaN(Number(value));
  });
  if (isDatetime) {
    return FIELD_TYPES.DATETIME;
  }

  // 检测数值型
  const isNumeric = fieldValues.every(value => {
    if (typeof value === 'number') return !isNaN(value);
    if (typeof value === 'string') {
      const trimmedValue = value.trim();
      return trimmedValue !== '' && !isNaN(Number(trimmedValue));
    }
    return false;
  });
  if (isNumeric) {
    return FIELD_TYPES.NUMERIC;
  }

  // 检测类别型
  const uniqueValues = new Set(fieldValues);
  const isCategorical =
    fieldValues.every(value => typeof value === 'string') &&
    uniqueValues.size <= fieldValues.length;
  if (isCategorical) {
    return FIELD_TYPES.CATEGORICAL;
  }

  return FIELD_TYPES.UNKNOWN;
};

export const BIN_MODES = {
  EQUAL_WIDTH: "equalWidth", // 系统默认：等距分箱
  EQUAL_FREQ: "equalFreq",   // 系统默认：等频分箱
  CUSTOM_INTERVAL: "customInterval", // 用户自定义：仅输入区间边界
  CUSTOM_RULE: "customRule"  // 用户自定义：带标签的规则（如 0-5:低,5-10:中）
};
export const DEFAULT_BIN_CONFIG = {
  enable: false,          // 是否启用分箱
  mode: BIN_MODES.EQUAL_WIDTH, // 默认分箱模式
  count: 5,               // 系统模式：分箱数量（等距/等频用）
  customInterval: [],     // 自定义区间：边界数组（如 [0,5,10,20]）
  customRule: "",         // 自定义规则：字符串（如 "0-5:低,5-10:中,10-∞:高"）
  ruleList: [],           // 解析后的规则列表（供前端预览、后端渲染用）
  displayMode: "sideBySide" // Y轴分箱展示：并列/堆积（仅柱状图）
};

export const formatBinLabel = (interval) => {
  if (interval.length === 2) {
    const [min, max] = interval;
    return min === max ? `${min}` : `${min}-${max}`;
  }
  return interval.join("-");
};

export const binNumericField = (data, field, binConfig) => {
  // 未启用分箱或非数值字段，直接返回原数据
  if (!binConfig.enable || !data.length || getFieldType(data, field) !== FIELD_TYPES.NUMERIC) {
    return data.map(item => ({
      ...item,
      [`${field}_binned`]: item[field], // 分箱后的值（原数值）
      [`${field}_binned_label`]: item[field].toString(), // 分箱标签（原数值字符串）
      [`${field}_binned_config`]: binConfig // 分箱配置（供后端渲染用）
    }));
  }

  const values = data.map(item => item[field]).filter(Number.isFinite);
  const minValue = Math.min(...values);
  const maxValue = Math.max(...values);
  let binnedData = [];

    // 1. 系统默认模式：等距/等频分箱
  if (binConfig.mode === BIN_MODES.EQUAL_WIDTH || binConfig.mode === BIN_MODES.EQUAL_FREQ) {
    const binCount = Math.max(2, binConfig.count || 5);
    let intervals = [];

    // 等距分箱：按固定间隔拆分
    if (binConfig.mode === BIN_MODES.EQUAL_WIDTH) {
      const step = (maxValue - minValue) / binCount;
      intervals = Array.from({ length: binCount + 1 }, (_, i) => {
        const val = minValue + i * step;
        return Number(val.toFixed(4)); // 保留4位小数，避免浮点数精度问题
      });
    }
    // 等频分箱：按数据分布拆分（每个区间数据量相近）
    else {
      const sortedValues = [...values].sort((a, b) => a - b);
      const step = Math.ceil(sortedValues.length / binCount);
      intervals = Array.from({ length: binCount + 1 }, (_, i) => {
        const idx = Math.min(i * step, sortedValues.length - 1);
        return sortedValues[idx];
      });
      intervals[intervals.length - 1] = maxValue; // 确保覆盖最大值
    }

    // 为每条数据分配分箱标签
    binnedData = data.map(item => {
      const value = item[field];
      let binnedLabel = "未知";
      // 匹配数据所在区间
      for (let i = 0; i < intervals.length - 1; i++) {
        const start = intervals[i];
        const end = intervals[i + 1];
        // 处理边界：左闭右开（如 [0,5)、[5,10)）
        if (value >= start && value < end) {
          binnedLabel = `${start}-${end}`;
          break;
        }
        // 最后一个区间：左闭右闭（覆盖最大值）
        if (i === intervals.length - 2 && value >= start && value <= end) {
          binnedLabel = `${start}-${end}`;
          break;
        }
      }
      return {
        ...item,
        [`${field}_binned`]: binnedLabel, // 分箱后的值（区间字符串）
        [`${field}_binned_label`]: binnedLabel, // 分箱标签（与值一致）
        [`${field}_binned_config`]: { ...binConfig, intervals } // 携带区间信息
      };
    });
  }

  // 2. 自定义模式1：仅区间边界（如 0,5,10,20）
  else if (binConfig.mode === BIN_MODES.CUSTOM_INTERVAL) {
    const intervals = binConfig.customInterval;
    if (intervals.length < 2) {
      console.warn("自定义区间边界不足2个，分箱无效");
      return data.map(item => ({ ...item, [`${field}_binned`]: item[field] }));
    }

    binnedData = data.map(item => {
      const value = item[field];
      let binnedLabel = "未知";
      for (let i = 0; i < intervals.length - 1; i++) {
        const start = intervals[i];
        const end = intervals[i + 1];
        if (value >= start && value <= end) {
          binnedLabel = `${start}-${end}`;
          break;
        }
      }
      return {
        ...item,
        [`${field}_binned`]: binnedLabel,
        [`${field}_binned_label`]: binnedLabel,
        [`${field}_binned_config`]: { ...binConfig, intervals }
      };
    });
  }

  // 3. 自定义模式2：带标签的规则（如 0-5:低,5-10:中）
  else if (binConfig.mode === BIN_MODES.CUSTOM_RULE) {
    const ruleList = binConfig.ruleList;
    if (ruleList.length === 0) {
      console.warn("自定义分箱规则未解析，分箱无效");
      return data.map(item => ({ ...item, [`${field}_binned`]: item[field] }));
    }

    binnedData = data.map(item => {
      const value = item[field];
      let binnedValue = "未知";
      let binnedLabel = "未知";

      // 遍历规则，匹配数据所在区间
      for (const rule of ruleList) {
        const { min, max, isMinOpen, isMaxOpen, intervalStr, label } = rule;
        let isMatch = false;

        // 处理各种区间场景
        if (min === undefined && max !== undefined) {
          // 左无界（如 <3、-∞-3）
          isMatch = isMaxOpen ? value < max : value <= max;
        } else if (max === undefined && min !== undefined) {
          // 右无界（如 >10、10-∞）
          isMatch = isMinOpen ? value > min : value >= min;
        } else if (min !== undefined && max !== undefined) {
          // 有界区间（如 0-5、(0,5]）
          const minMatch = isMinOpen ? value > min : value >= min;
          const maxMatch = isMaxOpen ? value < max : value <= max;
          isMatch = minMatch && maxMatch;
        }

        if (isMatch) {
          binnedValue = intervalStr; // 分箱值（原始区间字符串，如 "0-5"）
          binnedLabel = label;       // 分箱标签（如 "低"，带业务含义）
          break;
        }
      }

      return {
        ...item,
        [`${field}_binned`]: binnedValue,
        [`${field}_binned_label`]: binnedLabel,
        [`${field}_binned_config`]: { ...binConfig, ruleList } // 携带规则信息
      };
    });
  }

  return binnedData;
};

// 图表类型定义
const CHART_TYPES = {
  BAR: 'bar',
  LINE: 'line',
  PIE: 'pie',
  TABLE: 'table',
  RADAR: "radar",          // 雷达图
  KLINE: "kline",          // K线图
  QUADRANT: "quadrant", // 风险象限图
  WAFERMAP: "wafermap",   // Wafer Map图
  GANTT:   "gantt",
};

// 图表类型选项
const chartTypeOptions = [
  { value: CHART_TYPES.BAR, label: '柱状图', icon: <BarChartIcon /> },
  { value: CHART_TYPES.LINE, label: '折线图', icon: <LineChartIcon /> },
  { value: CHART_TYPES.PIE, label: '饼图', icon: <PieChartIcon /> },
  { value: CHART_TYPES.TABLE, label: '表格', icon: <TableChartIcon /> },
  { value: CHART_TYPES.GANTT, label: '甘特图', icon: <TimelineIcon  /> },
  { value: CHART_TYPES.RADAR, label: '雷达图', icon: <RadarChartIcon /> },
  { value: CHART_TYPES.QUADRANT, label: '象限图/散点图', icon: <ScatterPlotIcon /> },
  { value: CHART_TYPES.KLINE, label: 'K线图', icon: <CandlestickChartIcon /> },
  { value: CHART_TYPES.WAFERMAP, label: 'wafermap', icon: <GridIcon /> },

];

//{ value: CHART_TYPES.KLINE, label: 'K线图', icon: <CandlestickChartIcon /> },
// 图表类型元数据（关联图标和配置）
export const CHART_TYPE_METADATA = {
  // 原有图表类型
  [CHART_TYPES.BAR]: {
    label: "柱状图",
    icon: <BarChartIcon />,
    needX: true,
    needY: true
  },
  [CHART_TYPES.LINE]: {
    label: "折线图",
    icon: <LineChartIcon />,
    needX: true,
    needY: true
  },
  [CHART_TYPES.PIE]: {
    label: "饼图",
    icon: <PieChartIcon />,
    needX: true,
    needY: true
  },
  [CHART_TYPES.TABLE]: {
    label: "表格",
    icon: <TableIcon />,  // 使用导入的 TableIcon
    needX: false,
    needY: false
  },
  // 新增图表类型（关联对应图标）
  [CHART_TYPES.RADAR]: {
    label: "雷达图",
    icon: <RadarChartIcon />,  // 使用导入的 RadarChartIcon
    needX: false,
    needY: false,
    needDimensions: true  // 雷达图专属配置：维度字段
  },
  [CHART_TYPES.KLINE]: {
    label: "K线图",
    icon: <CandlestickChartIcon />,  // 使用导入的 CandlestickChartIcon
    needX: true,
    needY: false,
    needKlineFields: true  // K线图专属配置：开/高/低/收字段
  },
  [CHART_TYPES.QUADRANT]: {
    label: "象限图",
    icon: <ScatterPlotIcon />,  // 使用导入的 ScatterPlotIcon
    needX: true,  // X轴：风险字段
    needY: true,  // Y轴：收益字段
    needLabelField: true  // 专属配置：象限点标签字段
  },
  [CHART_TYPES.WAFERMAP]: {
    label: "WaferMap图",
    icon: <GridIcon />,  // 使用导入的 GridIcon
    needX: false,
    needY: false,
    needWaferFields: true  // Wafer Map专属配置：X/Y坐标、缺陷类型字段
  }
};

// 列宽度选项
const COLUMN_WIDTHS = [
  { value: 1, label: '1/3 宽度' },
  { value: 2, label: '2/3 宽度' },
  { value: 3, label: '100% 宽度' }
];

// 生成专业的图表颜色
const generateProfessionalColors = (count) => {
  const professionalColors = [
    '#2D82B7', '#34A853', '#FBBC05', '#EA4335', '#9C27B0',
    '#00ACC1', '#FF6D00', '#5E35B1', '#F06292', '#4DB6AC'
  ];
  return count <= professionalColors.length
    ? professionalColors.slice(0, count)
    : professionalColors.concat(Array(count - professionalColors.length).fill('#90A4AE'));
};



// 数据抽样函数
const sampleData = (data, maxSize = 1000) => {
  if (data.length <= maxSize) return data;

  const sampleSize = maxSize;
  const sampled = [];
  const indices = new Set();

  while (indices.size < sampleSize) {
    const index = Math.floor(Math.random() * data.length);
    if (!indices.has(index)) {
      indices.add(index);
      sampled.push(data[index]);
    }
  }

  return sampled;
};

// 生成唯一ID（包含时间戳确保顺序）
const generateUniqueId = () => {
  // 使用更简单、更可靠的ID生成方式
  return `chart-${Date.now()}-${Math.floor(Math.random() * 10000)}`;
};

// 聚合函数配置
export const AGGREGATION_FUNCTIONS = {
  count: { label: '计数', func: (arr) => arr.filter(Boolean).length, type: 'number' },
  sum: { label: '求和', func: (arr) => arr.reduce((a, b) => Number(a) + Number(b), 0), type: 'number' },
  mean: { label: '均值', func: (arr) => {
    const nums = arr.filter(v => !isNaN(Number(v))).map(Number);
    return nums.length ? nums.reduce((a, b) => a + b, 0) / nums.length : 0;
  }, type: 'number' },
  variance: { label: '方差', func: (arr) => {
    const nums = arr.filter(v => !isNaN(Number(v))).map(Number);
    if (nums.length < 2) return 0;
    const avg = nums.reduce((a, b) => a + b, 0) / nums.length;
    return nums.reduce((a, b) => a + Math.pow(b - avg, 2), 0) / (nums.length - 1);
  }, type: 'number' },
  std: { label: '标准差', func: (arr) => Math.sqrt(AGGREGATION_FUNCTIONS.variance.func(arr)), type: 'number' },
  min: { label: '最小值', func: (arr) => Math.min(...arr.filter(v => !isNaN(Number(v))).map(Number)), type: 'number' },
  max: { label: '最大值', func: (arr) => Math.max(...arr.filter(v => !isNaN(Number(v))).map(Number)), type: 'number' },
  median: { label: '中位数', func: (arr) => {
    const nums = arr.filter(v => !isNaN(Number(v))).map(Number).sort((a, b) => a - b);
    const mid = Math.floor(nums.length / 2);
    return nums.length % 2 === 1 ? nums[mid] : (nums[mid - 1] + nums[mid]) / 2;
  }, type: 'number' },
  first: { label: '首个值', func: (arr) => arr.filter(Boolean)[0] || '', type: 'any' },
  last: { label: '最后一个值', func: (arr) => arr.filter(Boolean).pop() || '', type: 'any' },
  unique: { label: '唯一值数量', func: (arr) => new Set(arr.filter(Boolean)).size, type: 'number' }
};

// 按数据类型推荐聚合函数
export const RECOMMENDED_AGGS = {
  numeric: ['count', 'sum', 'mean', 'std', 'min', 'max', 'median'],
  categorical: ['count', 'unique', 'first', 'last'],
  datetime: ['count', 'min', 'max', 'first', 'last']
};

// 功能使用说明组件
const FeatureGuide = () => {
  const [expanded, setExpanded] = useState(false);
  const theme = useTheme();

  const handleChange = (panel) => (event, isExpanded) => {
    setExpanded(isExpanded ? panel : false);
  };

  return (
    <Box mb={4}>
      <Accordion
        expanded={expanded === 'guide'}
        onChange={handleChange('guide')}
        sx={{
          border: `1px solid ${theme.palette.divider}`,
          borderRadius: '4px !important',
          boxShadow: '0 2px 4px rgba(0,0,0,0.05)',
          '&:before': { display: 'none' },
          backgroundColor: theme.palette.background.paper
        }}
      >
        <AccordionSummary
          expandIcon={<ExpandMoreIcon sx={{ color: theme.palette.primary.main }} />}
          aria-controls="guide-content"
          id="guide-header"
        >
          <Box display="flex" alignItems="center" gap={2}>
            <HelpIcon sx={{ color: theme.palette.primary.main, fontSize: 20 }} />
            <Typography variant="h6" sx={{ color: theme.palette.text.primary, fontWeight: 500 }}>
              报告使用指南
            </Typography>
          </Box>
        </AccordionSummary>
        <AccordionDetails sx={{ padding: '0 24px 24px' }}>
          <Grid container spacing={3} sx={{ marginTop: 2 }}>
            <Grid item xs={12} md={4}>
              <Paper sx={{
                padding: 2,
                borderRadius: '4px',
                backgroundColor: theme.palette.background.default,
                border: `1px solid ${theme.palette.divider}`
              }}>
                <Typography variant="subtitle1" sx={{ color: theme.palette.primary.main, fontWeight: 500, mb: 1 }}>
                  1️⃣ 加载数据
                </Typography>
                <Typography variant="body2" sx={{ color: theme.palette.text.secondary, lineHeight: 1.6 }}>
                  点击「加载数据文件」按钮，上传CSV或JSON格式的数据文件。上传后会显示文件名称和数据行数。
                </Typography>
              </Paper>
            </Grid>
            <Grid item xs={12} md={4}>
              <Paper sx={{
                padding: 2,
                borderRadius: '4px',
                backgroundColor: theme.palette.background.default,
                border: `1px solid ${theme.palette.divider}`
              }}>
                <Typography variant="subtitle1" sx={{ color: theme.palette.primary.main, fontWeight: 500, mb: 1 }}>
                  2️⃣ 添加与调整
                </Typography>
                <Typography variant="body2" sx={{ color: theme.palette.text.secondary, lineHeight: 1.6 }}>
                  点击「添加新行」按钮创建图表，可通过图表左上角的拖拽图标调整图表在行内或跨行间的顺序。
                </Typography>
              </Paper>
            </Grid>
            <Grid item xs={12} md={4}>
              <Paper sx={{
                padding: 2,
                borderRadius: '4px',
                backgroundColor: theme.palette.background.default,
                border: `1px solid ${theme.palette.divider}`
              }}>
                <Typography variant="subtitle1" sx={{ color: theme.palette.primary.main, fontWeight: 500, mb: 1 }}>
                  3️⃣ 配置与导出
                </Typography>
                <Typography variant="body2" sx={{ color: theme.palette.text.secondary, lineHeight: 1.6 }}>
                  可通过图表右上角的「设置」按钮修改配置，完成后点击「导出报告」保存你的可视化结果。
                </Typography>
              </Paper>
            </Grid>
          </Grid>
        </AccordionDetails>
      </Accordion>
    </Box>
  );
};

// 聚合数据处理函数
const processAggregatedData = (rawData, xAxis, yAxisList, aggregations, yDataMode) => {
  if (yDataMode === 'original' || !xAxis || !yAxisList.length) {
    return rawData;
  }

  const groupedData = rawData.reduce((groups, row) => {
    const groupKey = row[xAxis];
    if (!groups[groupKey]) {
      groups[groupKey] = { [xAxis]: groupKey };
      yAxisList.forEach(yField => {
        groups[groupKey][`${yField}_raw`] = [];
      });
    }

    yAxisList.forEach(yField => {
      const value = row[yField];
      if (value !== undefined && value !== null) {
        groups[groupKey][`${yField}_raw`].push(value);
      }
    });

    return groups;
  }, {});

  return Object.values(groupedData).map(group => {
    const aggregatedRow = { [xAxis]: group[xAxis] };
    yAxisList.forEach(yField => {
      const rawValues = group[`${yField}_raw`];
      const aggKey = aggregations?.[yField] || 'mean';
      aggregatedRow[yField] = AGGREGATION_FUNCTIONS[aggKey].func(rawValues);
    });
    return aggregatedRow;
  });
};

// 图表配置对话框
const ChartConfigDialog = ({
  open,
  onClose,
  onSave,
  block,
  availableColumns,
  data
}) => {
  const theme = useTheme();

  // 按图表类型获取 Y 轴默认处理方式
  const getDefaultYDataMode = (chartType) => {
    if (chartType === CHART_TYPES.PIE) return 'aggregate';
    if (chartType === CHART_TYPES.LINE) return 'original';
    return 'aggregate';
  };

  // 按字段类型获取默认聚合函数
  const getDefaultAggByType = (fieldType) => {
    switch (fieldType) {
      case FIELD_TYPES.NUMERIC:
        return 'mean';
      case FIELD_TYPES.CATEGORICAL:
        return 'count';
      case FIELD_TYPES.DATETIME:
        return 'count';
      default:
        return 'count';
    }
  };

  // 初始化配置
  const [config, setConfig] = useState(() => {
    const safeBlock = block || {
      title: '',
      type: CHART_TYPES.BAR,
      width: 3,
      config: {
         filters: [],  // 初始化空数组,
         xBinConfig: { ...DEFAULT_BIN_CONFIG }, // 关键：初始化 xBinConfig
         yBinConfig: { ...DEFAULT_BIN_CONFIG }  // 若有 Y 轴分箱，同样初始化
      }
    };

    return {
      title: safeBlock.title || '',
      type: safeBlock.type || CHART_TYPES.BAR,
      width: safeBlock.width || 3,
      xAxis: safeBlock.config?.xAxis || '',
      yAxis: safeBlock.config?.yAxis || [],
      radarDimFields:safeBlock.config?.radarDimFields || [],
      yDataMode: safeBlock.config?.yDataMode || getDefaultYDataMode(safeBlock.type || CHART_TYPES.BAR),
      sampling: safeBlock.config?.sampling !== undefined ? safeBlock.config.sampling : true,
      sampleSize: safeBlock.config?.sampleSize || 1000,
      aggregations: safeBlock.config?.aggregations || {}
    };
  });

  useEffect(() => {
  const safeBlock = block || { config: {} };
  // 从 block.config 中读取分箱配置（若有），无则用默认配置
  const safeXBinConfig = safeBlock.config?.xBinConfig || { ...DEFAULT_BIN_CONFIG };
  const safeYBinConfig = safeBlock.config?.yBinConfig || { ...DEFAULT_BIN_CONFIG };

  setConfig({
    title: safeBlock.title || '',
    type: safeBlock.type || CHART_TYPES.BAR,
    width: safeBlock.width || 1,
    xAxis: safeBlock.config?.xAxis || '',
    radarDimFields:safeBlock.config?.radarDimFields || [],
    yAxis: safeBlock.config?.yAxis || [],
    yDataMode: safeBlock.config?.yDataMode || getDefaultYDataMode(safeBlock.type || CHART_TYPES.BAR),
    sampling: safeBlock.config?.sampling !== undefined ? safeBlock.config.sampling : true,
    sampleSize: safeBlock.config?.sampleSize || 1000,
    aggregations: safeBlock.config?.aggregations || {},
    // 新增：初始化 X/Y 轴分箱配置
    xBinConfig: safeXBinConfig,
    yBinConfig: safeYBinConfig,

     // ============ Wafer Map 特有配置 ============

    waferXField: safeBlock.config?.waferXField || '',
    waferYField: safeBlock.config?.waferYField || '',
    waferValueField: safeBlock.config?.waferValueField || '',
    waferIdField: safeBlock.config?.waferIdField || '',
    defectTypeField:safeBlock.config?.defectTypeField || '',
    waferDiameter: safeBlock.config?.waferDiameter || 150,
    waferShowGrid: safeBlock.config?.waferShowGrid !== undefined ? safeBlock.config.waferShowGrid : true,
    waferShowAxis: safeBlock.config?.waferShowAxis !== undefined ? safeBlock.config.waferShowAxis : true,
    waferShowLegend: safeBlock.config?.waferShowLegend !== undefined ? safeBlock.config.waferShowLegend : true,
    waferColorScheme: safeBlock.config?.waferColorScheme || 'blue-red',
    waferValueRange: safeBlock.config?.waferValueRange || 'auto',
    waferMinValue: safeBlock.config?.waferMinValue || undefined,
    waferMaxValue: safeBlock.config?.waferMaxValue || undefined,
    waferBinConfig: safeBlock.config?.waferBinConfig || {
        mode: BIN_MODES.AUTO,
        binCount: 10
    },

    // ============ K线图 特有配置 ============
    klineTimeField: safeBlock.config?.klineTimeField || '',
    klineOpen: safeBlock.config?.klineOpen || '',
    klineClose: safeBlock.config?.klineClose || '',
    klineHigh: safeBlock.config?.klineHigh || '',
    klineLow: safeBlock.config?.klineLow || '',

    // ============ 甘特图 特有配置 ============
    ganttTaskField: safeBlock.config?.ganttTaskField || '',
    ganttStartField: safeBlock.config?.ganttStartField || '',
    ganttEndField: safeBlock.config?.ganttEndField || '',
    ganttProgressField: safeBlock.config?.ganttProgressField || '',
    ganttShowProgress: safeBlock.config?.ganttShowProgress !== undefined ? safeBlock.config.ganttShowProgress : true,
    ganttShowLabels: safeBlock.config?.ganttShowLabels !== undefined ? safeBlock.config.ganttShowLabels : true,
    ganttBarHeight: safeBlock.config?.ganttBarHeight || 20,
    ganttColorMode: safeBlock.config?.ganttColorMode || 'progress',
    ganttTimeRange: safeBlock.config?.ganttTimeRange || 'auto',
    ganttStartDate: safeBlock.config?.ganttStartDate || undefined,
    ganttEndDate: safeBlock.config?.ganttEndDate || undefined,

    // ============ 象限图 特有配置 ============
    quadrantXField: safeBlock.config?.quadrantXField || '',
    quadrantYField: safeBlock.config?.quadrantYField || '',
    quadrantValueField: safeBlock.config?.quadrantValueField || '',
    quadrantGroupField: safeBlock.config?.quadrantGroupField || '',
    quadrantShowReferenceLines: safeBlock.config?.quadrantShowReferenceLines !== undefined ? safeBlock.config.quadrantShowReferenceLines : true,
    quadrantReferenceMode: safeBlock.config?.quadrantReferenceMode || 'mean',

  });
}, [block, open]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setConfig(prev => ({ ...prev, [name]: value }));
  };

  const handleYAxisToggle = (column) => {
    setConfig(prev => {
      const yAxis = [...prev.yAxis];
      const index = yAxis.indexOf(column);

      if (index === -1) {
        yAxis.push(column);
        const fieldType = getFieldType(data, column);
        const defaultAgg = getDefaultAggByType(fieldType);
        return {
          ...prev,
          yAxis,
          aggregations: { ...prev.aggregations, [column]: defaultAgg }
        };
      } else {
        yAxis.splice(index, 1);
        const { [column]: _, ...restAggregations } = prev.aggregations;
        return { ...prev, yAxis, aggregations: restAggregations };
      }
    });
  };
//
  const specialChartTypes = [
    CHART_TYPES.QUADRANT, // 风险象限图
    CHART_TYPES.KLINE,    // K线图
    CHART_TYPES.WAFERMAP, // Wafer Map图
    CHART_TYPES.GANTT,
  ];
  //CHART_TYPES.RADAR,    // 雷达图

   const handleSave = () => {

    // 1. 定义“不需要传统X/Y轴”的特殊图表类型

    // 2. 仅对“非特殊图表”校验X/Y轴；特殊图表校验专属配置
  if (!specialChartTypes.includes(config.type)) {
    // 传统图表校验（原有逻辑）
    if ( (config.type !== CHART_TYPES.TABLE) &&(config.type !== CHART_TYPES.RADAR)
      &&  (!config.xAxis || config.yAxis.length === 0)) {
      alert('请选择X轴和至少一个Y轴');
      return;
    }
  } else {
    // 特殊图表专属校验（按类型判断）
  if (  specialChartTypes.includes(config.type) && config.type !== CHART_TYPES.KLINE  &&(  config.type !== CHART_TYPES.GANTT)
        &&( config.type !== CHART_TYPES.WAFERMAP ) ) {
      // 雷达图：校验“维度字段”是否存在
      console.info("config.radarDimFields:",config.radarDimFields)
      if (  config.radarDimFields.length < 2) {
        alert('需选择至少2个维度字段');
        return;
      }

    }
  }
 if (config.type === CHART_TYPES.KLINE) {
    if (!config.klineTimeField || !config.klineOpen ||
        !config.klineClose || !config.klineHigh || !config.klineLow) {
      alert('请配置K线图所需的所有字段（时间字段和四个价格字段）');
      return;
    }
  }

  // if (config.type !== CHART_TYPES.TABLE && (!config.xAxis || config.yAxis.length === 0)) {
  //   alert('请选择X轴和至少一个Y轴');
  //   return;
  // }
  // 1. 处理X轴分箱：若启用，使用分箱后的字段名（如 "carat_binned"）
  const xAxisFinal = config.xBinConfig.enable ? `${config.xAxis}_binned` : config.xAxis;
  // 2. 处理Y轴分箱：若启用，生成分箱后的字段名（支持多Y轴）
  const yAxisFinal = config.yBinConfig.enable
    ? config.yAxis.map(yField => `${yField}_binned`)
    : config.yAxis;

  // 3. 构造最终配置：携带完整分箱信息
  const finalConfig = {
    xAxis: xAxisFinal,
    yAxis: yAxisFinal,
    radarDimFields:config.radarDimFields,
    yDataMode: config.yDataMode,
    sampling: config.sampling,
    sampleSize: config.sampleSize,
    aggregations: config.aggregations,
    // 新增：X/Y轴分箱配置（供后端解析）
    xBinConfig: config.xBinConfig,
    yBinConfig: config.yBinConfig,
    // 若有自定义规则，携带解析后的规则列表
    xBinRuleList: config.xBinConfig.mode === BIN_MODES.CUSTOM_RULE ? config.xBinConfig.ruleList : [],
    yBinRuleList: config.yBinConfig.mode === BIN_MODES.CUSTOM_RULE ? config.yBinConfig.ruleList : [],

    klineTimeField: config.klineTimeField,
    klineOpen: config.klineOpen,
    klineClose: config.klineClose,
    klineHigh: config.klineHigh,
    klineLow: config.klineLow,

     // 甘特图特有配置
    ganttTaskField: config.ganttTaskField,
    ganttStartField: config.ganttStartField,
    ganttEndField: config.ganttEndField,
    ganttProgressField: config.ganttProgressField,

    // 甘特图样式配置（可选）
    ganttShowProgress: config.ganttShowProgress || true,
    ganttShowLabels: config.ganttShowLabels || true,
    ganttBarHeight: config.ganttBarHeight || 20,
    ganttColorMode: config.ganttColorMode || 'progress', // 'progress', 'status', 'assignee'

    // 甘特图时间范围配置
    ganttTimeRange: config.ganttTimeRange || 'auto', // 'auto', 'custom'
    ganttStartDate: config.ganttStartDate, // 自定义开始时间
    ganttEndDate: config.ganttEndDate, // 自定义结束时间

    // WaferMap特有配置
    waferIdField:config.waferIdField,
    waferXField: config.waferXField,
    waferYField: config.waferYField,
    waferValueField: config.waferValueField,
    defectTypeField: config.defectTypeField,
    waferDiameter: config.waferDiameter || 150,

    // WaferMap显示配置
    waferShowGrid: config.waferShowGrid || true,
    waferShowAxis: config.waferShowAxis || true,
    waferShowLegend: config.waferShowLegend || true,

    // WaferMap颜色配置
    waferColorScheme: config.waferColorScheme || 'blue-red', // 'blue-red', 'green-red', 'rainbow'
    waferValueRange: config.waferValueRange || 'auto', // 'auto', 'custom'
    waferMinValue: config.waferMinValue, // 自定义最小值
    waferMaxValue: config.waferMaxValue, // 自定义最大值

    // WaferMap分箱配置（如果需要）
    waferBinConfig: config.waferBinConfig || {
        mode: BIN_MODES.AUTO,
        binCount: 10
    },

  };

  onSave({
    ...block,
    id: block.id,
    title: config.title,
    type: config.type,
    width: config.width,
    config: finalConfig
  });
  onClose();
};

return (
  <Dialog
    open={open}
    onClose={onClose}
    maxWidth="md"
    fullWidth
  >
    <DialogTitle sx={{
      backgroundColor: theme.palette.background.default,
      color: theme.palette.primary.main,
      fontWeight: 500
    }}>
      配置{chartTypeOptions.find(ct => ct.value === config.type)?.label}
      <Typography variant="caption" display="block" sx={{ color: theme.palette.text.secondary, mt: 0.5 }}>
        根据您的数据和分析需求配置图表
      </Typography>
    </DialogTitle>

    <DialogContent dividers sx={{ padding: '24px', maxHeight: '70vh', overflowY: 'auto' }}>
      <Grid container spacing={3}>

        {/* 基础配置区域 */}
        <Grid item xs={12}>
          <Box sx={{
            p: 2,
            mb: 2,
            backgroundColor: theme.palette.background.default,
            borderRadius: 1,
            borderLeft: `4px solid ${theme.palette.primary.main}`
          }}>
            <Typography variant="h6" gutterBottom sx={{ color: theme.palette.primary.main }}>
              基础配置
            </Typography>

            <Grid container spacing={2}>
              {/* 图表标题 */}
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="图表标题（可选，建议填写）"
                  name="title"
                  value={config.title}
                  onChange={handleChange}
                  helperText="为图表设置一个描述性标题，便于识别"
                  sx={{
                    '& .MuiOutlinedInput-root': {
                      '& fieldset': { borderColor: theme.palette.divider },
                      '&:hover fieldset': { borderColor: theme.palette.primary.main },
                      '&.Mui-focused fieldset': { borderColor: theme.palette.primary.main }
                    }
                  }}
                />
              </Grid>

              {/* 图表类型和宽度 */}
              <Grid item xs={12} sm={6}>
                <FormControl fullWidth>
                  <InputLabel sx={{ color: theme.palette.text.secondary }}>图表类型</InputLabel>
                  <Select
                    name="type"
                    value={config.type}
                    label="图表类型"
                    onChange={handleChange}
                    sx={{
                      '& .MuiOutlinedInput-root': {
                        '& fieldset': { borderColor: theme.palette.divider },
                        '&:hover fieldset': { borderColor: theme.palette.primary.main },
                        '&.Mui-focused fieldset': { borderColor: theme.palette.primary.main }
                      }
                    }}
                  >
                    {chartTypeOptions.map(option => (
                      <MenuItem key={option.value} value={option.value} sx={{ color: theme.palette.text.primary }}>
                        {option.icon}
                        <span style={{ marginLeft: 8 }}>{option.label}</span>
                      </MenuItem>
                    ))}
                  </Select>
                  <FormHelperText>选择最适合展示您数据的图表类型</FormHelperText>
                </FormControl>
              </Grid>

              <Grid item xs={12} sm={6}>
                <FormControl fullWidth>
                  <InputLabel sx={{ color: theme.palette.text.secondary }}>宽度占比</InputLabel>
                  <Select
                    name="width"
                    value={config.width}
                    label="宽度占比"
                    onChange={handleChange}
                    sx={{
                      '& .MuiOutlinedInput-root': {
                        '& fieldset': { borderColor: theme.palette.divider },
                        '&:hover fieldset': { borderColor: theme.palette.primary.main },
                        '&.Mui-focused fieldset': { borderColor: theme.palette.primary.main }
                      }
                    }}
                  >
                    <MenuItem value={1} sx={{ color: theme.palette.text.primary }}>1/3 宽度</MenuItem>
                    <MenuItem value={2} sx={{ color: theme.palette.text.primary }}>2/3 宽度</MenuItem>
                    <MenuItem value={3} sx={{ color: theme.palette.text.primary }}>100% 宽度</MenuItem>
                  </Select>
                  <FormHelperText>控制图表在仪表板中的显示宽度</FormHelperText>
                </FormControl>
              </Grid>
            </Grid>
          </Box>
        </Grid>

        {/* 数据配置区域 */}
        <Grid item xs={12}>
  <Accordion
    defaultExpanded={false} // 默认折叠
    sx={{
      mb: 2,
      borderLeft: `4px solid ${theme.palette.warning.main}`,
      '&:before': { display: 'none' } // 移除默认的边框
    }}
  >
    <AccordionSummary
      expandIcon={<ExpandMoreIcon />}
      sx={{
        backgroundColor: theme.palette.background.default,
        borderRadius: 1,
        minHeight: '48px !important',
        '& .MuiAccordionSummary-content': {
          alignItems: 'center',
          margin: '12px 0'
        }
      }}
    >
      <Typography variant="h6" sx={{ color: theme.palette.warning.main }}>
        数据配置
      </Typography>
    </AccordionSummary>

    <AccordionDetails sx={{ p: 2 }}>
      {/* 数据过滤条件 */}
      {config.type !== CHART_TYPES.TABLE &&
       config.type !== CHART_TYPES.KLINE &&
       config.type !== CHART_TYPES.GANTT && (
        <Box sx={{ mb: 3 }}>
          <Typography variant="subtitle2" gutterBottom>
            数据过滤条件
            <Tooltip title="设置条件过滤数据，仅显示符合条件的数据记录">
              <IconButton size="small" sx={{ ml: 1 }}>
                <HelpOutlineIcon fontSize="small" />
              </IconButton>
            </Tooltip>
          </Typography>

          <Box mb={2}>
            <Button
              variant="outlined"
              size="small"
              onClick={() => {
                setConfig(prev => {
                  const prevInnerConfig = prev.config || {};
                  const prevFilters = prevInnerConfig.filters || [];
                  return {
                    ...prev,
                    config: {
                      ...prevInnerConfig,
                      filters: [...prevFilters, { field: '', operator: '=', value: '' }]
                    }
                  };
                });
              }}
              sx={{ mb: 1 }}
            >
              <AddIcon fontSize="small" /> 添加过滤条件
            </Button>
          </Box>

          {((config.config || {}).filters || []).map((filter, idx) => (
            <Box key={idx} display="flex" gap={2} alignItems="center" mb={1}>
              {/* 字段选择器 */}
              <FormControl size="small" sx={{ minWidth: 120 }}>
                <InputLabel>字段</InputLabel>
                <Select
                  value={filter.field}
                  label="字段"
                  onChange={(e) => {
                    setConfig(prev => {
                      const prevInnerConfig = prev.config || {};
                      const prevFilters = prevInnerConfig.filters || [];
                      const newFilters = [...prevFilters];
                      newFilters[idx].field = e.target.value;
                      return {
                        ...prev,
                        config: { ...prevInnerConfig, filters: newFilters }
                      };
                    });
                  }}
                >
                  {availableColumns.map(col => (
                    <MenuItem key={col} value={col}>{col}</MenuItem>
                  ))}
                </Select>
              </FormControl>

              {/* 运算符选择器 */}
              <FormControl size="small" sx={{ minWidth: 100 }}>
                <InputLabel>运算符</InputLabel>
                <Select
                  value={filter.operator}
                  label="运算符"
                  onChange={(e) => {
                    setConfig(prev => {
                      const prevInnerConfig = prev.config || {};
                      const prevFilters = prevInnerConfig.filters || [];
                      const newFilters = [...prevFilters];
                      newFilters[idx].operator = e.target.value;
                      return {
                        ...prev,
                        config: { ...prevInnerConfig, filters: newFilters }
                      };
                    });
                  }}
                >
                  <MenuItem value="=">等于</MenuItem>
                  <MenuItem value="!=">不等于</MenuItem>
                  <MenuItem value=">">大于</MenuItem>
                  <MenuItem value="<">小于</MenuItem>
                  <MenuItem value=">=">大于等于</MenuItem>
                  <MenuItem value="<=">小于等于</MenuItem>
                  <MenuItem value="in">包含</MenuItem>
                  <MenuItem value="notIn">不包含</MenuItem>
                </Select>
              </FormControl>

              {/* 值输入框 */}
              <TextField
                size="small"
                label="值"
                value={filter.value}
                onChange={(e) => {
                  setConfig(prev => {
                    const prevInnerConfig = prev.config || {};
                    const prevFilters = prevInnerConfig.filters || [];
                    const newFilters = [...prevFilters];
                    newFilters[idx].value = e.target.value;
                    return {
                      ...prev,
                      config: { ...prevInnerConfig, filters: newFilters }
                    };
                  });
                }}
                sx={{ minWidth: 150 }}
              />

              {/* 删除按钮 */}
              <IconButton
                size="small"
                onClick={() => {
                  setConfig(prev => {
                    const prevInnerConfig = prev.config || {};
                    const prevFilters = prevInnerConfig.filters || [];
                    const newFilters = [...prevFilters];
                    newFilters.splice(idx, 1);
                    return {
                      ...prev,
                      config: { ...prevInnerConfig, filters: newFilters }
                    };
                  });
                }}
                sx={{ color: theme.palette.error.main }}
              >
                <DeleteIcon fontSize="small" />
              </IconButton>
            </Box>
          ))}
        </Box>
      )}

      {/* 数据抽样配置 */}
      {data && data.length > 0 && (
        <Box>
          <FormControlLabel
            control={
              <Checkbox
                checked={config.sampling}
                onChange={(e) => setConfig(prev => ({ ...prev, sampling: e.target.checked }))}
                name="sampling"
              />
            }
            label={
              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                <span>启用数据抽样（数据>1000行时推荐开启，避免卡顿）</span>
                <Tooltip title="当数据量较大时，抽样可以提高图表渲染性能">
                  <IconButton size="small" sx={{ ml: 1 }}>
                    <HelpOutlineIcon fontSize="small" />
                  </IconButton>
                </Tooltip>
              </Box>
            }
            sx={{ color: theme.palette.text.secondary }}
          />

          {config.sampling && (
            <TextField
              type="number"
              label="抽样大小（10-5000）"
              name="sampleSize"
              value={config.sampleSize}
              onChange={handleChange}
              sx={{
                mt: 1,
                maxWidth: 200,
                '& .MuiOutlinedInput-root': {
                  '& fieldset': { borderColor: theme.palette.divider },
                  '&:hover fieldset': { borderColor: theme.palette.primary.main },
                  '&.Mui-focused fieldset': { borderColor: theme.palette.primary.main }
                }
              }}
              inputProps={{ min: 10, max: 5000 }}
              helperText="设置抽样数据行数（10-5000）"
            />
          )}
        </Box>
      )}
    </AccordionDetails>
  </Accordion>
</Grid>


   {config.type === CHART_TYPES.WAFERMAP && (
  <Box sx={{
    mt: 2,
    p: 3,
    border: 1,
    borderColor: theme.palette.divider,
    borderRadius: 1,
    backgroundColor: theme.palette.background.default
  }}>
    <Typography variant="h6" sx={{ color: theme.palette.primary.main, mb: 3 }}>
      🧪 WaferMap字段配置
      <Tooltip title="WaferMap需要X坐标、Y坐标和测试值字段">
        <IconButton size="small" sx={{ ml: 1 }}>
          <HelpOutlineIcon fontSize="small" />
        </IconButton>
      </Tooltip>
    </Typography>

    <Grid container spacing={3}>
      <Grid item xs={12} md={6}>
          <FormControl fullWidth size="medium">
            {/* 标签：背景色、内边距与X坐标字段一致 */}
            <InputLabel sx={{
              backgroundColor: theme.palette.background.paper,
              px: 1
            }}>
              晶圆ID字段
            </InputLabel>

            {/* 下拉选择器：绑定waferIdField配置， onChange逻辑与X坐标字段一致 */}
            <Select
              value={config.waferIdField || ''}
              onChange={(e) => setConfig(prev => ({ ...prev, waferIdField: e.target.value }))}
              label="晶圆ID字段"
              // 下拉菜单样式：最大高度、菜单项间距与X坐标字段完全匹配
              MenuProps={{
                PaperProps: {
                  sx: {
                    maxHeight: 300,
                    '& .MuiMenuItem-root': {
                      minHeight: 48,
                      padding: '8px 16px'
                    }
                  }
                }
              }}
              // 输入框内边距与X坐标字段一致
              sx={{
                '& .MuiOutlinedInput-input': {
                  padding: '12px 14px'
                }
              }}
            >
              {/* 默认空选项：文字样式、颜色与X坐标字段一致 */}
              <MenuItem value="" sx={{ color: theme.palette.text.disabled }}>
                <em>选择晶圆ID字段</em>
              </MenuItem>

              {/* 渲染可选字段：优先显示字符串类型（晶圆ID通常为字符串，如W001） */}
              {/* 若你的晶圆ID是数值类型，可替换为getNumericColumns，与X坐标字段逻辑一致 */}
              {getTextColumns(availableColumns, data).map(col => (
                <MenuItem key={col} value={col} sx={{ minHeight: 48 }}>
                  <Box>
                    {/* 字段名：字体大小与X坐标字段一致 */}
                    <Typography variant="body2">{col}</Typography>
                    {/* 字段类型说明：与X坐标字段的"数值类型"对应，显示"字符串类型" */}
                    <Typography variant="caption" color="text.secondary">
                      字符串类型
                    </Typography>
                  </Box>
                </MenuItem>
              ))}
            </Select>

            {/* 辅助说明文字：明确字段用途，与X坐标字段的提示风格一致 */}
            <FormHelperText>
              选择表示晶圆唯一标识的字段（如W001、W002）
            </FormHelperText>
          </FormControl>
      </Grid>
      {/* X坐标字段 */}
      <Grid item xs={12} md={6}>
        <FormControl fullWidth size="medium">
          <InputLabel sx={{
            backgroundColor: theme.palette.background.paper,
            px: 1
          }}>
            X坐标字段
          </InputLabel>
          <Select
            value={config.waferXField || ''}
            onChange={(e) => setConfig(prev => ({ ...prev, waferXField: e.target.value }))}
            label="X坐标字段"
            MenuProps={{
              PaperProps: {
                sx: {
                  maxHeight: 300,
                  '& .MuiMenuItem-root': {
                    minHeight: 48,
                    padding: '8px 16px'
                  }
                }
              }
            }}
            sx={{
              '& .MuiOutlinedInput-input': {
                padding: '12px 14px'
              }
            }}
          >
            <MenuItem value="" sx={{ color: theme.palette.text.disabled }}>
              <em>选择X坐标字段</em>
            </MenuItem>
            {getNumericColumns(availableColumns, data).map(col => (
              <MenuItem key={col} value={col} sx={{ minHeight: 48 }}>
                <Box>
                  <Typography variant="body2">{col}</Typography>
                  <Typography variant="caption" color="text.secondary">
                    数值类型
                  </Typography>
                </Box>
              </MenuItem>
            ))}
          </Select>
          <FormHelperText>
            选择表示晶圆X坐标的数值字段
          </FormHelperText>
        </FormControl>
      </Grid>

      {/* Y坐标字段 */}
      <Grid item xs={12} md={6}>
        <FormControl fullWidth size="medium">
          <InputLabel sx={{
            backgroundColor: theme.palette.background.paper,
            px: 1
          }}>
            Y坐标字段
          </InputLabel>
          <Select
            value={config.waferYField || ''}
            onChange={(e) => setConfig(prev => ({ ...prev, waferYField: e.target.value }))}
            label="Y坐标字段"
            MenuProps={{
              PaperProps: {
                sx: {
                  maxHeight: 300,
                  '& .MuiMenuItem-root': {
                    minHeight: 48,
                    padding: '8px 16px'
                  }
                }
              }
            }}
            sx={{
              '& .MuiOutlinedInput-input': {
                padding: '12px 14px'
              }
            }}
          >
            <MenuItem value="" sx={{ color: theme.palette.text.disabled }}>
              <em>选择Y坐标字段</em>
            </MenuItem>
            {getNumericColumns(availableColumns, data).map(col => (
              <MenuItem key={col} value={col} sx={{ minHeight: 48 }}>
                <Box>
                  <Typography variant="body2">{col}</Typography>
                  <Typography variant="caption" color="text.secondary">
                    数值类型
                  </Typography>
                </Box>
              </MenuItem>
            ))}
          </Select>
          <FormHelperText>
            选择表示晶圆Y坐标的数值字段
          </FormHelperText>
        </FormControl>
      </Grid>

      {/* 测试值字段 */}
      <Grid item xs={12} md={6}>
        <FormControl fullWidth size="medium">
          <InputLabel sx={{
            backgroundColor: theme.palette.background.paper,
            px: 1
          }}>
            测试值字段
          </InputLabel>
          <Select
            value={config.waferValueField || ''}
            onChange={(e) => setConfig(prev => ({ ...prev, waferValueField: e.target.value }))}
            label="测试值字段"
            MenuProps={{
              PaperProps: {
                sx: {
                  maxHeight: 300,
                  '& .MuiMenuItem-root': {
                    minHeight: 48,
                    padding: '8px 16px'
                  }
                }
              }
            }}
            sx={{
              '& .MuiOutlinedInput-input': {
                padding: '12px 14px'
              }
            }}
          >
            <MenuItem value="" sx={{ color: theme.palette.text.disabled }}>
              <em>选择测试值字段</em>
            </MenuItem>
            {getNumericColumns(availableColumns, data).map(col => (
              <MenuItem key={col} value={col} sx={{ minHeight: 48 }}>
                <Box>
                  <Typography variant="body2">{col}</Typography>
                  <Typography variant="caption" color="text.secondary">
                    数值类型
                  </Typography>
                </Box>
              </MenuItem>
            ))}
          </Select>
          <FormHelperText>
            选择表示测试值的数值字段
          </FormHelperText>
        </FormControl>
      </Grid>
      {/* 缺陷类型字段选择器 */}
<Grid item xs={12} md={6}>
  <FormControl fullWidth size="medium">
    <InputLabel sx={{
      backgroundColor: theme.palette.background.paper,
      px: 1
    }}>
      缺陷类型字段
    </InputLabel>
    <Select
      value={config.defectTypeField || ''}
      onChange={(e) => setConfig(prev => ({ ...prev, defectTypeField: e.target.value }))}
      label="缺陷类型字段"
      MenuProps={{
        PaperProps: {
          sx: {
            maxHeight: 300,
            '& .MuiMenuItem-root': {
              minHeight: 48,
              padding: '8px 16px'
            }
          }
        }
      }}
      sx={{
        '& .MuiOutlinedInput-input': {
          padding: '12px 14px'
        }
      }}
    >
      <MenuItem value="" sx={{ color: theme.palette.text.disabled }}>
        <em>选择缺陷类型字段</em>
      </MenuItem>
      {/* 缺陷类型通常为数值编码（0/1/2/3），使用数值字段筛选器 */}
      {getNumericColumns(availableColumns, data).map(col => (
        <MenuItem key={col} value={col} sx={{ minHeight: 48 }}>
          <Box>
            <Typography variant="body2">{col}</Typography>
            <Typography variant="caption" color="text.secondary">
              数值类型（编码值）
            </Typography>
          </Box>
        </MenuItem>
      ))}
    </Select>
    <FormHelperText>
      选择表示缺陷类型的编码字段（如0=无缺陷，1=电气缺陷）
    </FormHelperText>
  </FormControl>
</Grid>


      {/* 晶圆直径配置 */}
      <Grid item xs={12} md={6}>
        <TextField
          fullWidth
          label="晶圆直径"
          type="number"
          value={config.waferDiameter || 150}
          onChange={(e) => setConfig(prev => ({
            ...prev,
            waferDiameter: Math.max(1, parseInt(e.target.value) || 150)
          }))}
          InputProps={{
            endAdornment: <InputAdornment position="end">mm</InputAdornment>,
          }}
          helperText="设置晶圆的直径（毫米）"
        />
      </Grid>
    </Grid>

    {/* 配置状态提示 */}
    {config.waferXField && config.waferYField && config.waferValueField && (
      <Box sx={{
        mt: 2,
        p: 2,
        backgroundColor: theme.palette.success.light,
        borderRadius: 1,
        border: `1px solid ${theme.palette.success.main}`
      }}>
        <Typography variant="body2" sx={{ color: theme.palette.success.dark }}>
          ✅ WaferMap配置完整，可以生成图表
        </Typography>
      </Box>
    )}
  </Box>
)}

   {config.type === CHART_TYPES.GANTT && (
  <Box sx={{
    mt: 2,
    p: 3,
    border: 1,
    borderColor: theme.palette.divider,
    borderRadius: 1,
    backgroundColor: theme.palette.background.default
  }}>
    <Typography variant="h6" sx={{ color: theme.palette.primary.main, mb: 3 }}>
      📅 甘特图字段配置
      <Tooltip title="甘特图需要任务名称、开始时间和结束时间">
        <IconButton size="small" sx={{ ml: 1 }}>
          <HelpOutlineIcon fontSize="small" />
        </IconButton>
      </Tooltip>
    </Typography>

    <Grid container spacing={3}>
      {/* 任务名字段 */}
      <Grid item xs={12} md={6}>
        <FormControl fullWidth size="medium">
          <InputLabel sx={{
            backgroundColor: theme.palette.background.paper,
            px: 1
          }}>
            任务名称字段
          </InputLabel>
          <Select
            value={config.ganttTaskField || ''}
            onChange={(e) => setConfig(prev => ({ ...prev, ganttTaskField: e.target.value }))}
            label="任务名称字段"
            MenuProps={{
              PaperProps: {
                sx: {
                  maxHeight: 300,
                  '& .MuiMenuItem-root': {
                    minHeight: 48,
                    padding: '8px 16px'
                  }
                }
              }
            }}
            sx={{
              '& .MuiOutlinedInput-input': {
                padding: '12px 14px'
              }
            }}
          >
            <MenuItem value="" sx={{ color: theme.palette.text.disabled }}>
              <em>选择任务名称字段</em>
            </MenuItem>
            {availableColumns.map(col => (
              <MenuItem key={col} value={col} sx={{ minHeight: 48 }}>
                <Box>
                  <Typography variant="body2">{col}</Typography>
                  <Typography variant="caption" color="text.secondary">
                    {getFieldType(data, col)}
                  </Typography>
                </Box>
              </MenuItem>
            ))}
          </Select>
          <FormHelperText>
            选择作为任务名称的字段
          </FormHelperText>
        </FormControl>
      </Grid>

      {/* 开始时间字段 */}
      <Grid item xs={12} md={6}>
        <FormControl fullWidth size="medium">
          <InputLabel sx={{
            backgroundColor: theme.palette.background.paper,
            px: 1
          }}>
            开始时间字段
          </InputLabel>
          <Select
            value={config.ganttStartField || ''}
            onChange={(e) => setConfig(prev => ({ ...prev, ganttStartField: e.target.value }))}
            label="开始时间字段"
            MenuProps={{
              PaperProps: {
                sx: {
                  maxHeight: 300,
                  '& .MuiMenuItem-root': {
                    minHeight: 48,
                    padding: '8px 16px'
                  }
                }
              }
            }}
            sx={{
              '& .MuiOutlinedInput-input': {
                padding: '12px 14px'
              }
            }}
          >
            <MenuItem value="" sx={{ color: theme.palette.text.disabled }}>
              <em>选择开始时间字段</em>
            </MenuItem>
            {availableColumns
              .filter(col => getFieldType(data, col) === FIELD_TYPES.DATETIME)
              .map(col => (
                <MenuItem key={col} value={col} sx={{ minHeight: 48 }}>
                  <Box>
                    <Typography variant="body2">{col}</Typography>
                    <Typography variant="caption" color="text.secondary">
                      时间类型
                    </Typography>
                  </Box>
                </MenuItem>
              ))}
          </Select>
          <FormHelperText>
            选择作为开始时间的字段（日期时间类型）
          </FormHelperText>
        </FormControl>
      </Grid>

      {/* 结束时间字段 */}
      <Grid item xs={12} md={6}>
        <FormControl fullWidth size="medium">
          <InputLabel sx={{
            backgroundColor: theme.palette.background.paper,
            px: 1
          }}>
            结束时间字段
          </InputLabel>
          <Select
            value={config.ganttEndField || ''}
            onChange={(e) => setConfig(prev => ({ ...prev, ganttEndField: e.target.value }))}
            label="结束时间字段"
            MenuProps={{
              PaperProps: {
                sx: {
                  maxHeight: 300,
                  '& .MuiMenuItem-root': {
                    minHeight: 48,
                    padding: '8px 16px'
                  }
                }
              }
            }}
            sx={{
              '& .MuiOutlinedInput-input': {
                padding: '12px 14px'
              }
            }}
          >
            <MenuItem value="" sx={{ color: theme.palette.text.disabled }}>
              <em>选择结束时间字段</em>
            </MenuItem>
            {availableColumns
              .filter(col => getFieldType(data, col) === FIELD_TYPES.DATETIME)
              .map(col => (
                <MenuItem key={col} value={col} sx={{ minHeight: 48 }}>
                  <Box>
                    <Typography variant="body2">{col}</Typography>
                    <Typography variant="caption" color="text.secondary">
                      时间类型
                    </Typography>
                  </Box>
                </MenuItem>
              ))}
          </Select>
          <FormHelperText>
            选择作为结束时间的字段（日期时间类型）
          </FormHelperText>
        </FormControl>
      </Grid>

      {/* 进度字段（可选） */}
      <Grid item xs={12} md={6}>
        <FormControl fullWidth size="medium">
          <InputLabel sx={{
            backgroundColor: theme.palette.background.paper,
            px: 1
          }}>
            进度字段（可选）
          </InputLabel>
          <Select
            value={config.ganttProgressField || ''}
            onChange={(e) => setConfig(prev => ({ ...prev, ganttProgressField: e.target.value }))}
            label="进度字段（可选）"
            MenuProps={{
              PaperProps: {
                sx: {
                  maxHeight: 300,
                  '& .MuiMenuItem-root': {
                    minHeight: 48,
                    padding: '8px 16px'
                  }
                }
              }
            }}
            sx={{
              '& .MuiOutlinedInput-input': {
                padding: '12px 14px'
              }
            }}
          >
            <MenuItem value="" sx={{ color: theme.palette.text.disabled }}>
              <em>选择进度字段（可选）</em>
            </MenuItem>
            {getNumericColumns(availableColumns, data).map(col => (
              <MenuItem key={col} value={col} sx={{ minHeight: 48 }}>
                <Box>
                  <Typography variant="body2">{col}</Typography>
                  <Typography variant="caption" color="text.secondary">
                    数值类型
                  </Typography>
                </Box>
              </MenuItem>
            ))}
          </Select>
          <FormHelperText>
            选择表示进度的数值字段（0-100%）
          </FormHelperText>
        </FormControl>
      </Grid>
    </Grid>

    {/* 配置状态提示 */}
    {config.ganttTaskField && config.ganttStartField && config.ganttEndField && (
      <Box sx={{
        mt: 2,
        p: 2,
        backgroundColor: theme.palette.success.light,
        borderRadius: 1,
        border: `1px solid ${theme.palette.success.main}`
      }}>
        <Typography variant="body2" sx={{ color: theme.palette.success.dark }}>
          ✅ 甘特图配置完整，可以生成图表
        </Typography>
      </Box>
    )}
  </Box>
)}

       {config.type === CHART_TYPES.KLINE && (
  <Box sx={{
    mt: 2,
    p: 3,
    border: 1,
    borderColor: theme.palette.divider,
    borderRadius: 1,
    backgroundColor: theme.palette.background.default
  }}>
    <Typography variant="h6" sx={{ color: theme.palette.primary.main, mb: 3 }}>
      📊 K线图字段配置
      <Tooltip title="K线图需要时间序列数据和四个价格字段">
        <IconButton size="small" sx={{ ml: 1 }}>
          <HelpOutlineIcon fontSize="small" />
        </IconButton>
      </Tooltip>
    </Typography>

    <Grid container spacing={3}>
      {/* 时间字段配置 */}
      <Grid item xs={12} md={6}>
        <FormControl fullWidth size="medium">
          <InputLabel sx={{
            backgroundColor: theme.palette.background.paper,
            px: 1
          }}>
            时间字段（X轴）
          </InputLabel>
          <Select
            value={config.klineTimeField || ''}
            onChange={(e) => setConfig(prev => ({ ...prev, klineTimeField: e.target.value }))}
            label="时间字段（X轴）"
            MenuProps={{
              PaperProps: {
                sx: {
                  maxHeight: 300,
                  '& .MuiMenuItem-root': {
                    minHeight: 48,
                    padding: '8px 16px'
                  }
                }
              }
            }}
            sx={{
              '& .MuiOutlinedInput-input': {
                padding: '12px 14px'
              }
            }}
          >
            <MenuItem value="" sx={{ color: theme.palette.text.disabled }}>
              <em>选择时间字段</em>
            </MenuItem>
            {availableColumns
              .filter(col => getFieldType(data, col) === FIELD_TYPES.DATETIME)
              .map(col => (
                <MenuItem key={col} value={col} sx={{ minHeight: 48 }}>
                  <Box>
                    <Typography variant="body2">{col}</Typography>
                    <Typography variant="caption" color="text.secondary">
                      时间类型
                    </Typography>
                  </Box>
                </MenuItem>
              ))}
          </Select>
          <FormHelperText>
            选择作为X轴的时间字段（日期时间类型）
          </FormHelperText>
        </FormControl>
      </Grid>

      {/* 价格字段配置 */}
      {['开盘价', '收盘价', '最高价', '最低价'].map((field, index) => {
        const fieldKeys = ['klineOpen', 'klineClose', 'klineHigh', 'klineLow'];
        const fieldKey = fieldKeys[index];

        return (
          <Grid item xs={12} md={6} key={fieldKey}>
            <FormControl fullWidth size="medium">
              <InputLabel sx={{
                backgroundColor: theme.palette.background.paper,
                px: 1
              }}>
                {field}字段
              </InputLabel>
              <Select
                value={config[fieldKey] || ''}
                onChange={(e) => setConfig(prev => ({ ...prev, [fieldKey]: e.target.value }))}
                label={`${field}字段`}
                MenuProps={{
                  PaperProps: {
                    sx: {
                      maxHeight: 300,
                      '& .MuiMenuItem-root': {
                        minHeight: 48,
                        padding: '8px 16px'
                      }
                    }
                  }
                }}
                sx={{
                  '& .MuiOutlinedInput-input': {
                    padding: '12px 14px'
                  }
                }}
              >
                <MenuItem value="" sx={{ color: theme.palette.text.disabled }}>
                  <em>选择{field}字段</em>
                </MenuItem>
                {getNumericColumns(availableColumns, data).map(col => (
                  <MenuItem key={col} value={col} sx={{ minHeight: 48 }}>
                    <Box>
                      <Typography variant="body2">{col}</Typography>
                      <Typography variant="caption" color="text.secondary">
                        数值类型
                      </Typography>
                    </Box>
                  </MenuItem>
                ))}
              </Select>
              <FormHelperText>
                选择作为{field}的数值字段
              </FormHelperText>
            </FormControl>
          </Grid>
        );
      })}
    </Grid>

    {/* 配置状态提示 */}
    {config.klineTimeField && config.klineOpen && config.klineClose && config.klineHigh && config.klineLow && (
      <Box sx={{
        mt: 2,
        p: 2,
        backgroundColor: theme.palette.success.light,
        borderRadius: 1,
        border: `1px solid ${theme.palette.success.main}`
      }}>
        <Typography variant="body2" sx={{ color: theme.palette.success.dark }}>
          ✅ K线图配置完整，可以生成图表
        </Typography>
      </Box>
    )}
  </Box>
)}

        {/* X 轴或维度配置区域 */}
        {  config.type !== CHART_TYPES.TABLE &&
           config.type !== CHART_TYPES.KLINE &&
           config.type !== CHART_TYPES.GANTT && (
          <Grid item xs={12}>
            <Box sx={{
              p: 2,
              mb: 2,
              backgroundColor: theme.palette.background.default,
              borderRadius: 1,
              borderLeft: `4px solid ${theme.palette.info.main}`
            }}>
             <Typography variant="h6" gutterBottom sx={{ color:  theme.palette.info.main }}>
              {specialChartTypes.includes(config.type) ? "维度字段配置" : "X轴配置"}
              <Tooltip title={
                specialChartTypes.includes(config.type)
                  ? "选择标签型字段（如“指标类型”），其值将作为雷达图的坐标轴"
                  : "X轴通常用于放置分类或时间字段，作为数据的维度"
              }>
                <IconButton size="small" sx={{ ml: 1 }}>
                  <HelpOutlineIcon fontSize="small" />
                </IconButton>
              </Tooltip>
            </Typography>

              {/* X 轴选择 */}
              <FormControl fullWidth sx={{ mb: 2 }}>
                <InputLabel sx={{ color: theme.palette.text.secondary }}>
                  {specialChartTypes.includes(config.type)
                    ? "维度字段（标签型，至少选2个，如“指标类型”）"
                    : "X 轴（分类/时间字段，仅选1个）"
                  }
                </InputLabel>
                <Select
                  name=    {specialChartTypes.includes(config.type) ? "radarDimFields" : "xAxis"} //动态name，便于handleChange识别
                  value=   {specialChartTypes.includes(config.type) ? config.radarDimFields || [""] : config.xAxis}  // {config.xAxis}        //
                  label=   {specialChartTypes.includes(config.type)
                    ? "维度字段（标签型，选2个或多个）"
                    : "X 轴（分类/时间字段，仅选1个）"
                  }
                  multiple={specialChartTypes.includes(config.type)?true:false }
                  onChange={handleChange}
                  sx={{
                    '& .MuiOutlinedInput-root': {
                      '& fieldset': { borderColor: theme.palette.divider },
                      '&:hover fieldset': { borderColor: theme.palette.primary.main },
                      '&.Mui-focused fieldset': { borderColor: theme.palette.primary.main }
                    }
                  }}
                >
                  {availableColumns.map(column => {
                    const fieldType = getFieldType(data, column);
                    const typeLabel = {
                      [FIELD_TYPES.NUMERIC]: '（数值）',
                      [FIELD_TYPES.CATEGORICAL]: '（类别）',
                      [FIELD_TYPES.DATETIME]: '（时间）',
                      [FIELD_TYPES.UNKNOWN]: '（未知）'
                    }[fieldType];
                    const disabled = fieldType === FIELD_TYPES.UNKNOWN;
                    let tip = '';
                    if (fieldType === FIELD_TYPES.NUMERIC) {
                      if (config.type === CHART_TYPES.PIE) {
                        tip = '（饼图推荐类别型，数值型可能导致分组过多）';
                      } else if (config.type === CHART_TYPES.BAR) {
                        tip = '（柱状图推荐类别型，数值型建议先分组）';
                      } else {
                        tip = '（连续数值型，适合折线图）';
                      }
                    }

                    return (
                      <MenuItem
                        key={column}
                        value={column}
                        disabled={disabled}
                        sx={{
                          color: theme.palette.text.primary,
                          '& .tip': { color: '#f59e0b', fontSize: '0.85rem', marginLeft: 8 }
                        }}
                      >
                        {column} {typeLabel}
                        {fieldType === FIELD_TYPES.NUMERIC && <span className="tip">{tip}</span>}
                      </MenuItem>
                    );
                  })}
                </Select>
                <FormHelperText>
                  {config.type === CHART_TYPES.RADAR
                    ? "选择标签型字段（如“指标类型”），其每一个唯一值将成为雷达图的坐标轴（需至少2个值）"
                    : "选择作为分类或时间维度的字段（仅选1个）"
                  }
                </FormHelperText>
              </FormControl>

              {/* X轴分箱配置 */}
              {config.xAxis && getFieldType(data, config.xAxis) === FIELD_TYPES.NUMERIC && (
                <Box sx={{ mt: 2, p: 2, border: 1, borderColor: theme.palette.divider, borderRadius: 1 }}>
                  <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
                    <Typography variant="subtitle2" sx={{ color: theme.palette.text.primary }}>
                      X轴数值分箱
                      <Tooltip title="将连续数值分成几个区间，便于分析数据分布">
                        <IconButton size="small" sx={{ ml: 1 }}>
                          <HelpOutlineIcon fontSize="small" />
                        </IconButton>
                      </Tooltip>
                    </Typography>
                    <FormControlLabel
                      control={
                        <Checkbox
                          checked={config.xBinConfig?.enable}
                          onChange={(e) => setConfig(prev => ({
                            ...prev,
                            xBinConfig: { ...prev.xBinConfig, enable: e.target.checked }
                          }))}
                          sx={{ color: theme.palette.primary.main }}
                        />
                      }
                      label="启用分箱"
                    />
                  </Box>

                  {/* 分箱模式选择（核心：切换不同配置界面） */}
                  {config.xBinConfig?.enable && (
                    <>
                      <Grid container spacing={2} mb={2}>
                        <Grid item xs={12} sm={4}>
                          <FormControl fullWidth size="small">
                            <InputLabel>分箱模式</InputLabel>
                            <Select
                              value={config.xBinConfig.mode}
                              label="分箱模式"
                              onChange={(e) => {
                                const newMode = e.target.value;
                                // 切换模式时重置对应配置（避免混淆）
                                setConfig(prev => {
                                  const oldBinConfig = prev.xBinConfig;
                                  const resetConfig = {
                                    ...oldBinConfig,
                                    mode: newMode,
                                    // 重置非当前模式的配置
                                    count: newMode === BIN_MODES.EQUAL_WIDTH || newMode === BIN_MODES.EQUAL_FREQ ? oldBinConfig.count : 5,
                                    customInterval: newMode === BIN_MODES.CUSTOM_INTERVAL ? oldBinConfig.customInterval : [],
                                    customRule: newMode === BIN_MODES.CUSTOM_RULE ? oldBinConfig.customRule : "",
                                    ruleList: [] // 清空解析后的规则
                                  };
                                  // 若切换到自定义规则，可预填示例提示
                                  if (newMode === BIN_MODES.CUSTOM_RULE && !resetConfig.customRule) {
                                    resetConfig.customRule = "0-5:低,5-10:中,10-∞:高（示例）";
                                  }
                                  return { ...prev, xBinConfig: resetConfig };
                                });
                              }}
                            >
                              <MenuItem value={BIN_MODES.EQUAL_WIDTH}>系统默认 - 等距分箱</MenuItem>
                              <MenuItem value={BIN_MODES.EQUAL_FREQ}>系统默认 - 等频分箱</MenuItem>
                              <MenuItem value={BIN_MODES.CUSTOM_INTERVAL}>自定义 - 仅区间边界</MenuItem>
                              <MenuItem value={BIN_MODES.CUSTOM_RULE}>自定义 - 带标签规则</MenuItem>
                            </Select>
                          </FormControl>
                        </Grid>
                      </Grid>

                      {/* 1. 系统默认模式：等距/等频（原有逻辑，略作调整） */}
                      {(config.xBinConfig.mode === BIN_MODES.EQUAL_WIDTH || config.xBinConfig.mode === BIN_MODES.EQUAL_FREQ) && (
                        <Grid container spacing={2} mb={2}>
                          <Grid item xs={12} sm={4}>
                            <TextField
                              type="number"
                              label={`${config.xBinConfig.mode === BIN_MODES.EQUAL_WIDTH ? "等距" : "等频"}分箱数量`}
                              value={config.xBinConfig.count}
                              onChange={(e) => setConfig(prev => ({
                                ...prev,
                                xBinConfig: { ...prev.xBinConfig, count: Math.max(2, parseInt(e.target.value) || 5) }
                              }))}
                              inputProps={{ min: 2, max: 20 }} // 限制2-20箱，避免过多/过少
                              fullWidth
                              size="small"
                            />
                          </Grid>
                          <Grid item xs={12}>
                            <Typography variant="caption" sx={{ color: theme.palette.text.secondary }}>
                              提示：等距分箱按固定间隔拆分，等频分箱按数据分布拆分（每个区间数据量相近）
                            </Typography>
                          </Grid>
                        </Grid>
                      )}

                      {/* 2. 自定义模式1：仅输入区间边界（如 0,5,10,20） */}
                      {config.xBinConfig.mode === BIN_MODES.CUSTOM_INTERVAL && (
                        <Grid container spacing={2} mb={2}>
                          <Grid item xs={12}>
                            <TextField
                              label="区间边界（用逗号分隔，如 0,5,10,20）"
                              value={config.xBinConfig.customInterval.join(",")}
                              onChange={(e) => {
                                // 解析输入：仅保留有效数字，自动排序
                                const intervals = e.target.value.split(",")
                                  .map(item => item.trim())
                                  .filter(item => item !== "")
                                  .map(item => parseFloat(item))
                                  .filter(Number.isFinite)
                                  .sort((a, b) => a - b);
                                // 去重（避免重复边界）
                                const uniqueIntervals = [...new Set(intervals)];
                                setConfig(prev => ({
                                  ...prev,
                                  xBinConfig: { ...prev.xBinConfig, customInterval: uniqueIntervals }
                                }));
                              }}
                              fullWidth
                              size="small"
                              helperText="需输入2个及以上有效数字，系统自动按升序排序并去重"
                            />
                          </Grid>
                          {/* 区间预览：让用户直观看到分箱结果 */}
                          {config.xBinConfig.customInterval.length >= 2 && (
                            <Grid item xs={12}>
                              <Typography variant="subtitle2" sx={{ mb: 1 }}>区间预览：</Typography>
                              <Box display="flex" flexWrap="wrap" gap={1}>
                                {config.xBinConfig.customInterval.slice(0, -1).map((start, idx) => {
                                  const end = config.xBinConfig.customInterval[idx + 1];
                                  return (
                                    <Chip
                                      key={idx}
                                      label={`${start} - ${end}`}
                                      variant="outlined"
                                      sx={{ color: theme.palette.text.primary }}
                                    />
                                  );
                                })}
                              </Box>
                            </Grid>
                          )}
                        </Grid>
                      )}

                      {/* 3. 自定义模式2：带标签的规则（如 0-5:低,5-10:中,10-∞:高） */}
                      {config.xBinConfig.mode === BIN_MODES.CUSTOM_RULE && (
                        <Grid container spacing={2} mb={2}>
                          <Grid item xs={12}>
                            <TextField
                              label="分箱规则（用逗号分隔，如 0-5:低,5-10:中,10-∞:高）"
                              value={config.xBinConfig.customRule}
                              onChange={(e) => {
                                const ruleStr = e.target.value;
                                setConfig(prev => ({
                                  ...prev,
                                  xBinConfig: { ...prev.xBinConfig, customRule: ruleStr }
                                }));
                              }}
                              fullWidth
                              size="small"
                              multiline
                              rows={2}
                              helperText="格式说明：区间+冒号+标签，支持 ∞ 表示无穷大（如 10-∞:高），区间不允许重叠"
                            />
                          </Grid>
                          {/* 规则解析与预览：实时验证规则合法性，显示解析结果 */}
                          <Grid item xs={12}>
                            <Button
                              variant="outlined"
                              size="small"
                              onClick={() => {
                                setConfig(prev => {
                                  const binConfig = prev.xBinConfig;
                                  const ruleStr = binConfig.customRule;
                                  let ruleList = [];
                                  let errorMsg = "";

                                  try {
                                    // 解析规则：按逗号分割，处理每个区间-标签对
                                    const ruleItems = ruleStr.split(",")
                                      .map(item => item.trim())
                                      .filter(item => item !== "");

                                    if (ruleItems.length === 0) {
                                      throw new Error("请输入至少一条分箱规则");
                                    }

                                    // 解析每条规则（支持 0-5:低、5-∞:高、<3:极低、>20:极高 等格式）
                                    ruleList = ruleItems.map((item, idx) => {
                                      // 匹配格式：[区间][冒号][标签]（区间支持 0-5、<3、>20、10-∞）
                                      const ruleReg = /^([<>]?\d+(-∞)?|-∞|\d+-<\d+|\d+-∞):(.+)$/;
                                      const match = item.match(ruleReg);
                                      if (!match) {
                                        throw new Error(`第 ${idx+1} 条规则格式错误（示例：0-5:低）`);
                                      }

                                      const [_, intervalStr, label] = match;
                                      let min, max, isMinOpen = false, isMaxOpen = false;

                                      // 解析区间（处理各种灵活格式）
                                      if (intervalStr.startsWith("<")) {
                                        // 格式：<3 → 小于3（max=3，开区间）
                                        max = parseFloat(intervalStr.slice(1));
                                        isMaxOpen = true;
                                      } else if (intervalStr.startsWith(">")) {
                                        // 格式：>20 → 大于20（min=20，开区间）
                                        min = parseFloat(intervalStr.slice(1));
                                        isMinOpen = true;
                                      } else if (intervalStr === "-∞") {
                                        // 格式：-∞ → 负无穷（仅用于最小区间）
                                        max = parseFloat(ruleList[idx+1]?.min || 0);
                                        isMaxOpen = true;
                                      } else if (intervalStr.endsWith("∞")) {
                                        // 格式：10-∞ → 大于等于10（min=10，闭区间）
                                        min = parseFloat(intervalStr.split("-")[0]);
                                      } else {
                                        // 格式：0-5 → 0≤x≤5（闭区间）
                                        const [minStr, maxStr] = intervalStr.split("-");
                                        min = parseFloat(minStr);
                                        max = parseFloat(maxStr);
                                      }

                                      // 验证区间有效性（避免min>max）
                                      if (min !== undefined && max !== undefined && min >= max) {
                                        throw new Error(`第 ${idx+1} 条规则区间无效（min ≥ max）`);
                                      }

                                      return {
                                        intervalStr, // 原始区间字符串（如 "0-5"）
                                        label,       // 分箱标签（如 "低"）
                                        min,         // 区间最小值（undefined表示负无穷）
                                        max,         // 区间最大值（undefined表示正无穷）
                                        isMinOpen,   // 是否左开区间（如 >20 → isMinOpen=true）
                                        isMaxOpen    // 是否右开区间（如 <3 → isMaxOpen=true）
                                      };
                                    });

                                    // 验证区间是否重叠（避免重复覆盖）
                                    for (let i = 0; i < ruleList.length - 1; i++) {
                                      const curr = ruleList[i];
                                      const next = ruleList[i + 1];
                                      if (curr.max !== undefined && next.min !== undefined && curr.max > next.min) {
                                        throw new Error(`第 ${i+1} 条与第 ${i+2} 条规则区间重叠`);
                                      }
                                    }

                                  } catch (err) {
                                    errorMsg = err.message;
                                  }

                                  // 更新解析后的规则和错误信息
                                  return {
                                    ...prev,
                                    xBinConfig: {
                                      ...binConfig,
                                      ruleList,
                                      ruleError: errorMsg
                                    }
                                  };
                                });
                              }}
                              sx={{ mb: 1 }}
                            >
                              解析并预览规则
                            </Button>

                            {/* 显示解析错误 */}
                            {config.xBinConfig.ruleError && (
                              <Typography variant="caption" sx={{ color: theme.palette.error.main }}>
                                ❌ {config.xBinConfig.ruleError}
                              </Typography>
                            )}

                            {/* 显示解析成功的规则预览 */}
                            {config.xBinConfig.ruleList.length > 0 && !config.xBinConfig.ruleError && (
                              <Box mt={1}>
                                <Typography variant="subtitle2" sx={{ mb: 1 }}>规则预览：</Typography>
                                <Box display="flex" flexWrap="wrap" gap={1}>
                                  {config.xBinConfig.ruleList.map((rule, idx) => (
                                    <Chip
                                      key={idx}
                                      label={`${rule.intervalStr} → ${rule.label}`}
                                      variant="outlined"
                                      sx={{ color: theme.palette.text.primary }}
                                    />
                                  ))}
                                </Box>
                              </Box>
                            )}
                          </Grid>
                        </Grid>
                      )}
                    </>
                  )}
                </Box>
              )}
            </Box>
          </Grid>
        )}

        {/* Y轴配置区域 */}
        { config.type !== CHART_TYPES.TABLE &&
          config.type !== CHART_TYPES.KLINE &&
          config.type !== CHART_TYPES.GANTT && (
          <Grid item xs={12}>
            <Box sx={{
              p: 2,
              mb: 2,
              backgroundColor: theme.palette.background.default,
              borderRadius: 1,
              borderLeft: `4px solid ${theme.palette.success.main}`
            }}>
              <Typography variant="h6" gutterBottom sx={{ color: theme.palette.success.main }}>
                值配置或Y轴配置
                <Tooltip title="Y轴通常用于放置数值字段，作为数据的度量">
                  <IconButton size="small" sx={{ ml: 1 }}>
                    <HelpOutlineIcon fontSize="small" />
                  </IconButton>
                </Tooltip>
              </Typography>

              {/* Y 轴选择 */}
              <Typography variant="subtitle2" gutterBottom sx={{ color: theme.palette.text.secondary }}>
                Y 轴（数值字段，可多选）
                <Tooltip title="选择需要分析和展示的数值字段">
                  <IconButton size="small" sx={{ ml: 1 }}>
                    <HelpOutlineIcon fontSize="small" />
                  </IconButton>
                </Tooltip>
              </Typography>
              <Box display="flex" flexWrap="wrap" gap={1} sx={{ mb: 2 }}>
                {availableColumns.map(column => {
                  const fieldType = getFieldType(data, column);
                  const isSelected = config.yAxis.includes(column);
                  const disabled = ![FIELD_TYPES.NUMERIC, FIELD_TYPES.DATETIME].includes(fieldType);
                  const typeLabel = {
                    [FIELD_TYPES.NUMERIC]: '（数值）',
                    [FIELD_TYPES.DATETIME]: '（时间）',
                    [FIELD_TYPES.CATEGORICAL]: '（类别）',
                    [FIELD_TYPES.UNKNOWN]: '（未知）'
                  }[fieldType];

                  return (
                    <Tooltip
                      key={column}
                      title={disabled ? "仅支持数值和时间字段" : `点击选择 ${column} 作为Y轴`}
                    >
                      <span>
                        <Chip
                          label={`${column} ${typeLabel}`}
                          onClick={() => !disabled && handleYAxisToggle(column)}
                          color={isSelected ? "primary" : "default"}
                          variant={isSelected ? "filled" : "outlined"}
                          disabled={disabled}
                          sx={{
                            cursor: disabled ? 'not-allowed' : 'pointer',
                            '&.Mui-disabled': { color: theme.palette.text.disabled }
                          }}
                        />
                      </span>
                    </Tooltip>
                  );
                })}
              </Box>

              {/* Y 轴数据处理方式选择 */}
              {config.yAxis.length > 0 && (
                <FormControl fullWidth sx={{ mb: 2 }}>
                  <InputLabel sx={{ color: theme.palette.text.secondary }}>
                    Y 轴数据处理方式（根据图表类型推荐）
                  </InputLabel>
                  <Select
                    name="yDataMode"
                    value={config.yDataMode || getDefaultYDataMode(config.type)}
                    label="Y 轴数据处理方式"
                    onChange={handleChange}
                    sx={{
                      '& .MuiOutlinedInput-root': {
                        '& fieldset': { borderColor: theme.palette.divider },
                        '&:hover fieldset': { borderColor: theme.palette.primary.main },
                        '&.Mui-focused fieldset': { borderColor: theme.palette.primary.main }
                      }
                    }}
                    disabled={config.type === CHART_TYPES.PIE}
                  >
                    <MenuItem value="aggregate">
                      聚合处理（统计数值：如求和、均值，适合饼图/柱状图）
                    </MenuItem>
                    <MenuItem value="original">
                      显示原值（不聚合，适合折线图/时序图）
                    </MenuItem>
                  </Select>
                  <FormHelperText>
                    {config.type === CHART_TYPES.PIE
                      ? "饼图自动使用聚合方式"
                      : "选择如何处理Y轴数据值"}
                  </FormHelperText>
                </FormControl>
              )}

              {/* 数据聚合方式 */}
              {config.type !== CHART_TYPES.TABLE  &&
               config.type !== CHART_TYPES.KLINE  &&
               config.type !== CHART_TYPES.GANTT &&  config.yAxis.length > 0 && config.yDataMode === 'aggregate' && (
                <Grid item xs={12}>
                  <Typography variant="subtitle2" gutterBottom sx={{ color: theme.palette.text.secondary }}>
                    数据聚合方式（Y轴字段）
                    <Tooltip title="选择每个Y轴字段的聚合计算方法">
                      <IconButton size="small" sx={{ ml: 1 }}>
                        <HelpOutlineIcon fontSize="small" />
                      </IconButton>
                    </Tooltip>
                  </Typography>
                  <Grid container spacing={2}>
                    {config.yAxis.map((yField) => {
                      const fieldType = getFieldType(data, yField);
                      const typeLabel = {
                        [FIELD_TYPES.NUMERIC]: '数值型',
                        [FIELD_TYPES.DATETIME]: '时间型',
                        [FIELD_TYPES.CATEGORICAL]: '类别型',
                        [FIELD_TYPES.UNKNOWN]: '未知型'
                      }[fieldType];
                      const recommendedAggs = RECOMMENDED_AGGS[fieldType] || Object.keys(AGGREGATION_FUNCTIONS);
                      const defaultAgg = config.aggregations[yField] || getDefaultAggByType(fieldType);

                      return (
                        <Grid item xs={12} sm={6} key={yField}>
                          <FormControl fullWidth>
                            <InputLabel>{`${yField}（${typeLabel}）- 聚合方式`}</InputLabel>
                            <Select
                              value={defaultAgg}
                              onChange={(e) => {
                                setConfig(prev => ({
                                  ...prev,
                                  aggregations: {
                                    ...prev.aggregations,
                                    [yField]: e.target.value
                                  }
                                }));
                              }}
                              label={`${yField}（${typeLabel}）- 聚合方式`}
                              sx={{
                                '& .MuiOutlinedInput-root': {
                                  '& fieldset': { borderColor: theme.palette.divider },
                                  '&:hover fieldset': { borderColor: theme.palette.primary.main },
                                  '&.Mui-focused fieldset': { borderColor: theme.palette.primary.main }
                                }
                              }}
                            >
                              {recommendedAggs.map(aggKey => (
                                <MenuItem key={aggKey} value={aggKey}>
                                  {AGGREGATION_FUNCTIONS[aggKey].label}
                                </MenuItem>
                              ))}
                            </Select>
                            <FormHelperText>
                              {`${yField} 的推荐聚合方式`}
                            </FormHelperText>
                          </FormControl>
                        </Grid>
                      );
                    })}
                  </Grid>
                </Grid>
              )}
            </Box>
          </Grid>
        )}


      </Grid>
    </DialogContent>
    <DialogActions sx={{
      padding: '16px 24px',
      backgroundColor: theme.palette.background.default
    }}>
      <Button
        onClick={onClose}
        sx={{
          color: theme.palette.text.secondary,
          '&:hover': {
            backgroundColor: theme.palette.action.hover,
            color: theme.palette.text.primary
          }
        }}
      >
        取消
      </Button>
      <Button
        onClick={handleSave}
        sx={{
          backgroundColor: theme.palette.primary.main,
          color: 'white',
          '&:hover': {
            backgroundColor: theme.palette.primary.dark,
          }
        }}
      >
        保存配置
      </Button>
    </DialogActions>
  </Dialog>
);
};

// 计算单行的剩余空间
export const getRowRemainingWidth = (row) => {
  const ROW_MAX_WIDTH = 3;
  const usedWidth = row.reduce((sum, block) => sum + (block.width || 1), 0);
  return Math.max(0, ROW_MAX_WIDTH - usedWidth);
};

// 找到首个可容纳新图表的行
export const findAvailableRowIndex = (structure, requiredWidth = 1) => {
  for (let i = 0; i < structure.length; i++) {
    const row = structure[i];
    const usedWidth = row.reduce((sum, block) => sum + (block.width || 1), 0);
    const remainingSpace = 3 - usedWidth;

    if (remainingSpace >= requiredWidth) {
      return i;
    }
  }
  return -1;
};

// 重排单行
export const rearrangeRow = (row) => {
  const ROW_MAX_WIDTH = 3;
  const currentRow = [];
  let currentUsedWidth = 0;
  const overflowRow = [];

  row.forEach(block => {
    const blockWidth = block.width || 1;
    if (currentUsedWidth + blockWidth <= ROW_MAX_WIDTH) {
      currentRow.push(block);
      currentUsedWidth += blockWidth;
    } else {
      overflowRow.push(block);
    }
  });

  return [currentRow, overflowRow];
};

// 全局重排（保留原始顺序）
export const globalRearrangeStructure = (structure) => {
  const newStructure = [];
  // 创建所有块的浅拷贝数组，保持原始顺序
  const allBlocks = structure.flatMap(row => [...row]).filter(block => block?.width);

  let currentRow = [];
  let currentWidth = 0;

  // 按原始顺序重新分配块到行
  for (const block of allBlocks) {
    const blockWidth = block.width || 1;

    if (currentWidth + blockWidth <= 3) {
      currentRow.push(block);
      currentWidth += blockWidth;
    } else {
      // 当前行已满，添加到结构并开始新行
      newStructure.push(currentRow);
      currentRow = [block];
      currentWidth = blockWidth;
    }
  }

  // 添加最后一行
  if (currentRow.length > 0) {
    newStructure.push(currentRow);
  }

  return newStructure;
};

const theme = createTheme({
  palette: {
    primary: {
      main: '#3B82F6',
    },
    secondary: {
      main: '#10B981',
    },
  },
});

// 图表渲染组件
const ChartRenderer = ({ block, data }) => {
  const theme = useTheme();

  if (!block.config || !data || data.length === 0) {
    return (
      <Box
        height="100%"
        display="flex"
        justifyContent="center"
        alignItems="center"
        p={2}
        backgroundColor={theme.palette.background.default}
      >
        <Typography color={theme.palette.text.secondary} align="center" sx={{ lineHeight: 1.5 }}>
          请先在右上角「设置」中配置图表参数<br/>
          （需选择X轴和至少一个Y轴）
        </Typography>
      </Box>
    );
  }

  const sampledData = block.config.sampling
    ? sampleData(data, block.config.sampleSize)
    : data;

  // 应用聚合计算
  const processedData = block.config.xAxis && block.config.yAxis.length
    ? processAggregatedData(
        sampledData,
        block.config.xAxis,
        block.config.yAxis,
        block.config.aggregations || {},
        block.config.yDataMode || 'aggregate'
      )
    : sampledData;

  // 获取专业图表颜色
  const colors = generateProfessionalColors(block.config.yAxis?.length || 5);

  // 根据图表类型渲染不同内容
  switch (block.type) {

    case CHART_TYPES.WAFERMAP:
        const requiredWaferFields = [
      'waferIdField',       // 对应数据中的晶圆ID字段（如你的数据中的"wafer_id"）
      'waferXField',        // X坐标字段（如你的数据中的"x_coordinate"）
      'waferYField',        // Y坐标字段（如你的数据中的"y_coordinate"）
      'waferValueField',    // 测试值字段（如你的数据中的"measurement_value"）
      'defectTypeField'     // 缺陷类型字段（如你的数据中的"defect_type"）
    ];
    // 筛选缺失的字段
    const missingWaferFields = requiredWaferFields.filter(
      field => !block.config[field] // 检查block.config中是否配置了这些字段
    );

    console.info("block?.config:",block?.config)

    // 2. 缺失配置时：显示错误提示（与GANTT的错误提示风格完全一致）
    if (missingWaferFields.length > 0) {
      return (
        <Box
          height="100%"
          display="flex"
          justifyContent="center"
          alignItems="center"
          p={2}
          backgroundColor={theme.palette.background.default}
        >
          <Typography color={theme.palette.error.main} align="center">
            请配置WaferMap所需的所有字段<br/>
            （{missingWaferFields.join('、')}）
          </Typography>
        </Box>
      );
    }

    // 3. 配置完整时：渲染专业晶圆图（传递必要参数，与原有数据流转一致）
    return (
      <ThemeProvider theme={theme}> {/* 若项目已有全局ThemeProvider，可移除这层 */}
        <ProfessionalWaferMap
          // 传递原有block对象（包含title、config等，与GANTT图的block参数一致）
          block={block}
          // 传递原有采样数据（sampledData，与GANTT图使用的数据源一致）
          sampledData={sampledData}
          // 传递项目原有theme（确保样式统一，若有全局theme可省略）
          theme={theme}
        />
      </ThemeProvider>
    );
  case CHART_TYPES.GANTT:
  // 检查必要的字段是否配置
  if (!block.config.ganttTaskField || !block.config.ganttStartField || !block.config.ganttEndField) {
    return (
      <Box
        height="100%"
        display="flex"
        justifyContent="center"
        alignItems="center"
        p={2}
        backgroundColor={theme.palette.background.default}
      >
        <Typography color={theme.palette.error.main} align="center">
          请配置甘特图所需的所有字段<br/>
          （任务名称、开始时间和结束时间）
        </Typography>
      </Box>
    );
  }

  // 准备甘特图数据
  const ganttData = processedData
    .filter(item =>
      item[block.config.ganttTaskField] &&
      item[block.config.ganttStartField] &&
      item[block.config.ganttEndField]
    )
    .map(item => {
      const startTime = new Date(item[block.config.ganttStartField]);
      const endTime = new Date(item[block.config.ganttEndField]);
      const progress = item[block.config.ganttProgressField] || 0;

      return {
        name: item[block.config.ganttTaskField],
        value: [
          item[block.config.ganttTaskField], // 任务名称
          startTime,                         // 开始时间
          endTime,                           // 结束时间
          endTime - startTime,               // 持续时间(毫秒)
          progress                           // 进度百分比
        ],
        itemStyle: {
          color: progress >= 100 ? '#52c41a' :  // 完成-绿色
                 progress >= 50 ? '#faad14' :   // 进行中-黄色
                 '#1890ff'                      // 未开始-蓝色
        }
      };
    })
    .sort((a, b) => a.value[1] - b.value[1]); // 按开始时间排序

  if (ganttData.length === 0) {
    return (
      <Box
        height="100%"
        display="flex"
        justifyContent="center"
        alignItems="center"
        p={2}
        backgroundColor={theme.palette.background.default}
      >
        <Typography color={theme.palette.text.secondary} align="center">
          无有效的甘特图数据<br/>
          请检查数据格式和时间字段
        </Typography>
      </Box>
    );
  }

  const ganttOption = {
    title: {
      text: block.title || '甘特图',
      left: 'center',
      textStyle: {
        color: theme.palette.text.primary
      }
    },
    tooltip: {
      trigger: 'item',
      formatter: function (params) {
        const data = params.data;
        const taskName = data.value[0];
        const startTime = new Date(data.value[1]).toLocaleDateString();
        const endTime = new Date(data.value[2]).toLocaleDateString();
        const durationDays = Math.round(data.value[3] / (1000 * 60 * 60 * 24));
        const progress = data.value[4];

        return `
          <div style="font-weight: bold; margin-bottom: 8px; color: ${params.color}">${taskName}</div>
          <div>开始: ${startTime}</div>
          <div>结束: ${endTime}</div>
          <div>持续时间: ${durationDays} 天</div>
          <div>进度: ${progress}%</div>
        `;
      }
    },
    grid: {
      left: '15%',
      right: '5%',
      bottom: '10%',
      top: '15%',
      containLabel: false
    },
    xAxis: {
      type: 'time',
      name: '时间',
      nameLocation: 'end',
      axisLabel: {
        color: theme.palette.text.secondary,
        formatter: function(value) {
          return new Date(value).toLocaleDateString();
        }
      },
      axisLine: {
        lineStyle: {
          color: theme.palette.divider
        }
      },
      splitLine: {
        show: true,
        lineStyle: {
          color: theme.palette.divider,
          type: 'dashed'
        }
      }
    },
    yAxis: {
      type: 'category',
      data: ganttData.map(item => item.value[0]),
      axisLabel: {
        color: theme.palette.text.secondary
      },
      axisLine: {
        show: false
      },
      axisTick: {
        show: false
      }
    },
    series: [
      {
        name: '甘特图',
        type: 'custom',
        renderItem: function(params, api) {
          const taskIndex = api.value(0);
          const startTime = api.coord([api.value(1), taskIndex]);
          const endTime = api.coord([api.value(2), taskIndex]);
          const progress = api.value(4);

          const height = api.size([0, 1])[1] * 0.6;
          const y = startTime[1] - height / 2;

          // 主任务条
          const barWidth = endTime[0] - startTime[0];

          // 进度条（覆盖在主任务条上）
          const progressWidth = barWidth * (progress / 100);

          return {
            type: 'group',
            children: [
              {
                type: 'rect',
                shape: {
                  x: startTime[0],
                  y: y,
                  width: barWidth,
                  height: height
                },
                style: {
                  fill: api.value(4) >= 100 ? '#52c41a' :
                        api.value(4) >= 50 ? '#faad14' :
                        '#1890ff',
                  opacity: 0.3
                }
              },
              {
                type: 'rect',
                shape: {
                  x: startTime[0],
                  y: y,
                  width: progressWidth,
                  height: height
                },
                style: {
                  fill: api.value(4) >= 100 ? '#52c41a' :
                        api.value(4) >= 50 ? '#faad14' :
                        '#1890ff'
                }
              },
              {
                type: 'text',
                style: {
                  text: `${progress}%`,
                  x: startTime[0] + barWidth + 5,
                  y: y + height / 2,
                  fill: theme.palette.text.primary,
                  fontSize: 12,
                  textAlign: 'left',
                  textVerticalAlign: 'middle'
                }
              }
            ]
          };
        },
        encode: {
          x: [1, 2], // 开始和结束时间
          y: 0       // 任务名称
        },
        data: ganttData,
        z: 100
      }
    ],
    dataZoom: [
      {
        type: 'slider',
        show: true,
        xAxisIndex: 0,
        filterMode: 'filter',
        height: 20,
        bottom: 25,
        start: 0,
        end: 100
      },
      {
        type: 'slider',
        show: true,
        yAxisIndex: 0,
        filterMode: 'filter',
        width: 15,
        right: 5,
        start: 0,
        end: 100
      }
    ]
  };

  return (
    <ReactECharts
      option={ganttOption}
      style={{ height: '100%', width: '100%' }}
      opts={{
        renderer: 'canvas',
        theme: theme.palette.mode
      }}
    />
  );

    case CHART_TYPES.KLINE:
      // 检查必要的字段是否配置
      if (!block.config.klineTimeField || !block.config.klineOpen ||
          !block.config.klineClose || !block.config.klineHigh || !block.config.klineLow) {
        return (
          <Box
            height="100%"
            display="flex"
            justifyContent="center"
            alignItems="center"
            p={2}
            backgroundColor={theme.palette.background.default}
          >
            <Typography color={theme.palette.error.main} align="center">
              请配置K线图所需的所有字段<br/>
              （时间字段和四个价格字段）
            </Typography>
          </Box>
        );
      }

      // 准备K线图数据
      const klineData = processedData
        .filter(item =>
          item[block.config.klineTimeField] &&
          item[block.config.klineOpen] !== undefined &&
          item[block.config.klineClose] !== undefined &&
          item[block.config.klineHigh] !== undefined &&
          item[block.config.klineLow] !== undefined
        )
        .map(item => ({
          time: item[block.config.klineTimeField],
          value: [
            Number(item[block.config.klineOpen]),
            Number(item[block.config.klineClose]),
            Number(item[block.config.klineLow]),
            Number(item[block.config.klineHigh])
          ]
        }))
        .sort((a, b) => new Date(a.time) - new Date(b.time)); // 按时间排序

      if (klineData.length === 0) {
        return (
          <Box
            height="100%"
            display="flex"
            justifyContent="center"
            alignItems="center"
            p={2}
            backgroundColor={theme.palette.background.default}
          >
            <Typography color={theme.palette.text.secondary} align="center">
              无有效的K线图数据<br/>
              请检查数据格式和时间字段
            </Typography>
          </Box>
        );
      }

      const option = {
        title: {
          text: block.title || 'K线图',
          left: 'center',
          textStyle: {
            color: theme.palette.text.primary
          }
        },
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'cross'
          },
          formatter: function (params) {
            const data = params[0].data;
            return `
              <div style="font-weight: bold; margin-bottom: 5px;">${params[0].name}</div>
              <div>开盘: ${data[0]}</div>
              <div>收盘: ${data[1]}</div>
              <div>最低: ${data[2]}</div>
              <div>最高: ${data[3]}</div>
            `;
          }
        },
        xAxis: {
          type: 'category',
          data: klineData.map(item => {
            // 格式化时间显示
            const date = new Date(item.time);
            return date.toLocaleDateString();
          }),
          axisLabel: {
            rotate: 45,
            color: theme.palette.text.secondary
          },
          axisLine: {
            lineStyle: {
              color: theme.palette.divider
            }
          }
        },
        yAxis: {
          scale: true,
          axisLabel: {
            color: theme.palette.text.secondary
          },
          splitLine: {
            lineStyle: {
              type: 'dashed',
              color: theme.palette.divider
            }
          }
        },
        dataZoom: [
          {
            type: 'inside',
            start: 0,
            end: 100
          },
          {
            type: 'slider',
            show: true,
            top: '90%',
            start: 0,
            end: 100,
            handleStyle: {
              color: theme.palette.primary.main
            }
          }
        ],
        series: [
          {
            name: 'K线',
            type: 'candlestick',
            data: klineData.map(item => item.value),
            itemStyle: {
              color: '#ec0000',
              color0: '#00da3c',
              borderColor: '#ec0000',
              borderColor0: '#00da3c'
            },
            emphasis: {
              itemStyle: {
                borderWidth: 2
              }
            }
          }
        ],
        grid: {
          left: '3%',
          right: '3%',
          bottom: '15%',
          top: '15%',
          containLabel: true
        }
      };

      return (
        <ReactECharts
          option={option}
          style={{ height: '100%', width: '100%' }}
          opts={{
            renderer: 'canvas',
            theme: theme.palette.mode // 支持暗色主题
          }}
        />
      );


    case CHART_TYPES.BAR:
      return (
        <ResponsiveContainer width="100%" height="100%">
          <BarChart
            data={processedData}
            margin={{ top: 20, right: 20, left: 0, bottom: 30 }}
            barSize={30}
          >
            <CartesianGrid strokeDasharray="3 3" stroke={theme.palette.divider} />
            <XAxis
              dataKey={block.config.xAxis}
              angle={-45}
              textAnchor="end"
              height={60}
              tick={{ fill: theme.palette.text.secondary, fontSize: 12 }}
            />
            <YAxis tick={{ fill: theme.palette.text.secondary, fontSize: 12 }} />
            <Tooltip
              contentStyle={{
                borderRadius: '4px',
                border: `1px solid ${theme.palette.divider}`,
                boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
                backgroundColor: theme.palette.background.paper,
                color: theme.palette.text.primary
              }}
            />
            <Legend wrapperStyle={{ paddingTop: 10 }} />
            {block.config?.yAxis?.map((y, index) => (
              <Bar
                key={y}
                dataKey={y}
                fill={colors[index]}
                radius={[4, 4, 0, 0]}
                name={y}
              />
            ))}
          </BarChart>
        </ResponsiveContainer>
      );



    case CHART_TYPES.LINE:
      return (
        <ResponsiveContainer width="100%" height="100%">
          <LineChart
            data={processedData}
            margin={{ top: 20, right: 20, left: 0, bottom: 30 }}
          >
            <CartesianGrid strokeDasharray="3 3" stroke={theme.palette.divider} />
            <XAxis
              dataKey={block.config.xAxis}
              angle={-45}
              textAnchor="end"
              height={60}
              tick={{ fill: theme.palette.text.secondary, fontSize: 12 }}
            />
            <YAxis tick={{ fill: theme.palette.text.secondary, fontSize: 12 }} />
            <Tooltip
              contentStyle={{
                borderRadius: '4px',
                border: `1px solid ${theme.palette.divider}`,
                boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
                backgroundColor: theme.palette.background.paper,
                color: theme.palette.text.primary
              }}
            />
            <Legend wrapperStyle={{ paddingTop: 10 }} />
            {block.config.yAxis.map((y, index) => (
              <Line
                key={y}
                type="monotone"
                dataKey={y}
                stroke={colors[index]}
                strokeWidth={2}
                activeDot={{ r: 6, fill: colors[index] }}
                name={y}
              />
            ))}
          </LineChart>
        </ResponsiveContainer>
      );

    case CHART_TYPES.PIE:
      // 饼图需要聚合数据
      const pieData = processedData.reduce((acc, item) => {
        const key = item[block.config.xAxis];
        const value = parseFloat(item[block.config.yAxis[0]] || 0);

        if (acc[key]) {
          acc[key] += value;
        } else {
          acc[key] = value;
        }

        return acc;
      }, {});

      const formattedPieData = Object.entries(pieData).map(([name, value]) => ({
        name,
        value
      }));

      return (
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={formattedPieData}
              cx="50%"
              cy="50%"
              labelLine={false}
              label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
              outerRadius={80}
              fill="#8884d8"
              dataKey="value"
              tick={{ fill: theme.palette.text.secondary, fontSize: 12 }}
            >
              {formattedPieData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={colors[index % colors.length]} />
              ))}
            </Pie>
            <Tooltip
              contentStyle={{
                borderRadius: '4px',
                border: `1px solid ${theme.palette.divider}`,
                boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
                backgroundColor: theme.palette.background.paper,
                color: theme.palette.text.primary
              }}
            />
          </PieChart>
        </ResponsiveContainer>
      );



    case CHART_TYPES.TABLE:
      const tableColumns = block.config.xAxis
        ? [block.config.xAxis, ...block.config.yAxis]
        : Object.keys(processedData[0] || {});

      return (
        <Box height="100%" overflow="auto">
          <TableContainer sx={{ border: `1px solid ${theme.palette.divider}` }}>
            <Table size="small" sx={{ minWidth: 650 }}>
              <TableHead sx={{ backgroundColor: theme.palette.background.default }}>
                <TableRow>
                  {tableColumns.map((column) => (
                    <TableCell
                      key={column}
                      sx={{
                        color: theme.palette.text.secondary,
                        fontWeight: 500,
                        borderBottom: `1px solid ${theme.palette.divider}`
                      }}
                    >
                      {column}
                    </TableCell>
                  ))}
                </TableRow>
              </TableHead>
              <TableBody>
                {processedData.slice(0, 50).map((row, rowIndex) => (
                  <TableRow
                    key={rowIndex}
                    sx={{
                      '&:nth-of-type(even)': { backgroundColor: theme.palette.background.default },
                      '&:hover': { backgroundColor: theme.palette.action.hover }
                    }}
                  >
                    {tableColumns.map((column) => (
                      <TableCell
                        key={column}
                        sx={{
                          color: theme.palette.text.primary,
                          borderBottom: `1px solid ${theme.palette.divider}`
                        }}
                      >
                        {row[column]}
                      </TableCell>
                    ))}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
          {processedData.length > 50 && (
            <Typography variant="caption" align="center" sx={{
              p: 1,
              display: 'block',
              color: theme.palette.text.secondary,
              backgroundColor: theme.palette.background.default,
              borderTop: `1px solid ${theme.palette.divider}`
            }}>
              仅显示前50行，共{processedData.length}行
            </Typography>
          )}
        </Box>
      );

    // 新增：象限图case（贴合原有风格，修复bug）
    case CHART_TYPES.RADAR:
  // 处理雷达图数据：适配Recharts的数据格式要求
  const xAxisKey = block.config.xAxis;
  const xAxisValues = [...new Set(processedData.map(item => item[xAxisKey]))];

  // 转换数据格式：每个对象包含所有维度的值，使用统一的key
  const radarData = xAxisValues.map(xValue => {
    const baseData = { [xAxisKey]: xValue }; // 用xAxis作为维度的键
    block.config.yAxis.forEach(yField => {
      const record = processedData.find(item => item[xAxisKey] === xValue);
      baseData[yField] = record ? Number(record[yField]) || 0 : 0;
    });
    return baseData;
  });

  console.info("维度值:", xAxisValues);
  console.info("雷达图数据:", radarData);

  return (
    <ResponsiveContainer width="100%" height="100%">
      {radarData.length === 0 ? (
        <div style={{
          width: '100%',
          height: '100%',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          color: theme.palette.text.secondary
        }}>
          无雷达图数据（检查数据处理逻辑）
        </div>
      ) : (
        <RadarChart
          data={radarData}
          margin={{ top: 20, right: 20, left: 20, bottom: 20 }}
          cx="50%"
          cy="50%"
          outerRadius="80%"
        >
          <PolarGrid strokeDasharray="3 3" stroke={theme.palette.divider} />
          {/* 使用xAxis作为角度轴的数据键 */}
          <PolarAngleAxis
            dataKey={xAxisKey}
            tick={{ fill: theme.palette.text.secondary, fontSize: 12 }}
          />
          <PolarRadiusAxis angle={30} domain={[0, 'dataMax + 10%']} />
          <Tooltip
            contentStyle={{
              borderRadius: '4px',
              border: `1px solid ${theme.palette.divider}`,
              boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
              backgroundColor: theme.palette.background.paper,
              color: theme.palette.text.primary
            }}
          />
          <Legend wrapperStyle={{ paddingTop: 10 }} />
          {/* 为每个y轴字段绘制雷达线 */}
          {block.config.yAxis.map((yField, index) => (
            <Radar
              key={`radar-${yField}`}
              name={yField}
              dataKey={yField}  // 使用y轴字段作为数据键
              stroke={colors[index % colors.length]}
              fill={colors[index % colors.length]}
              fillOpacity={0.3}
            />
          ))}
        </RadarChart>
      )}
    </ResponsiveContainer>
  );

  case CHART_TYPES.QUADRANT:
  // 基础配置
  const xDim = block.config.radarDimFields[0];  // X轴维度
  const yDim = block.config.radarDimFields[1];  // Y轴维度
  const valueDims = block.config.yAxis || [];   // 值维度
  const isBubbleChart = block.config.isBubbleChart || false;  // 气泡图标志位（核心切换开关）

  // 小数格式化函数
  const formatNumber = (num) => {
    if (Number.isInteger(num)) return num.toString();
    return num.toFixed(2);
  };

  // 1. 数据验证和清洗
  const cleanedData = processedData.map(item => {
    // 基础维度处理
    const xValue = Number(item[xDim]) || 0;
    const yValue = Number(item[yDim]) || 0;

    // 气泡图特有处理：值维度标准化
    let valueData = {};
    if (isBubbleChart && valueDims.length > 0) {
      const sizeDim = valueDims[0];
      let rawSize = Number(item[sizeDim]) || 0;

      // 归一化到0-5级
      const allSizes = processedData.map(i => Number(i[sizeDim]) || 0);
      const minSize = Math.min(...allSizes);
      const maxSize = Math.max(...allSizes);
      const normalizedSize = maxSize > minSize
        ? ((rawSize - minSize) / (maxSize - minSize)) * 5
        : 2.5;

      valueData = {
        [sizeDim]: Math.max(0, Math.min(5, normalizedSize)),
        ...valueDims.reduce((acc, dim) => {
          acc[dim] = Number(item[dim]) || 0;
          return acc;
        }, {})
      };
    }

    return {
      ...item,
      [xDim]: xValue,
      [yDim]: yValue,
      ...valueData
    };
  }).filter(item => !isNaN(item[xDim]) && !isNaN(item[yDim]));

  // 2. 空数据处理
  if (cleanedData.length === 0) {
    return (
      <div style={{
        width: '100%',
        height: '100%',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        color: theme.palette.error.main
      }}>
        无有效数据，请检查数据或更换字段
      </div>
    );
  }

  // 3. 象限分割线（平均值）
  const defaultX = cleanedData.reduce((sum, item) => sum + item[xDim], 0) / cleanedData.length;
  const defaultY = cleanedData.reduce((sum, item) => sum + item[yDim], 0) / cleanedData.length;

  // 4. 气泡大小映射函数（仅气泡图使用）
  const getBubbleSize = (level) => {
    return 10 + (level / 5) * 140; // 10-150的大小范围
  };

  // 5. 分组逻辑
  const groupField = block.config.groupField;
  const groupedData = groupField
    ? cleanedData.reduce((groups, item) => {
        const groupKey = item[groupField] ?? '未分类';
        if (!groups[groupKey]) groups[groupKey] = [];
        groups[groupKey].push(item);
        return groups;
      }, {})
    : null;
  const groupEntries = groupedData ? Object.entries(groupedData) : [];

  // 6. 散点大小（普通散点图使用固定大小，气泡图使用动态大小）
  const getPointSize = (item) => {
    if (isBubbleChart && valueDims.length > 0) {
      return getBubbleSize(item[valueDims[0]]);
    }
    return block.config.scatterSize || 10; // 普通散点图固定大小
  };

  return (
    <ResponsiveContainer width="100%" height="100%">
      <ScatterChart
        data={cleanedData}
        margin={{ top: 20, right: isBubbleChart ? 100 : 30, left: 80, bottom: 80 }}
      >
        <CartesianGrid strokeDasharray="3 3" stroke={theme.palette.divider} />

        {/* X轴 */}
        <XAxis
          type="number"
          dataKey={xDim}
          angle={-45}
          textAnchor="end"
          height={60}
          tick={{ fill: theme.palette.text.secondary, fontSize: 12 }}
          domain={([min, max]) => [min - (max - min)*0.1, max + (max - min)*0.1]}
          axisLine={{ stroke: theme.palette.divider }}
          tickFormatter={formatNumber}
          label={{
            value: `X轴: ${xDim}`,
            position: 'bottom',
            offset: 30,
            style: { fill: theme.palette.text.primary, fontSize: 14, fontWeight: 500 }
          }}
        >
          <ReferenceLine
            x={block.config.quadrantX ?? defaultX}
            stroke={theme.palette.primary.main}
            strokeDasharray="3 3"
            label={`${formatNumber(block.config.quadrantX ?? defaultX)}`}
          />
        </XAxis>

        {/* Y轴 */}
        <YAxis
          type="number"
          dataKey={yDim}
          tick={{ fill: theme.palette.text.secondary, fontSize: 12 }}
          domain={([min, max]) => [min - (max - min)*0.1, max + (max - min)*0.1]}
          axisLine={{ stroke: theme.palette.divider }}
          tickFormatter={formatNumber}
          label={{
            value: `Y轴: ${yDim}`,
            angle: -90,
            position: 'left',
            offset: -60,
            style: { fill: theme.palette.text.primary, fontSize: 14, fontWeight: 500, textAnchor: 'middle' }
          }}
        >
          <ReferenceLine
            y={block.config.quadrantY ?? defaultY}
            stroke={theme.palette.primary.main}
            strokeDasharray="3 3"
            label={`${formatNumber(block.config.quadrantY ?? defaultY)}`}
          />
        </YAxis>

        {/* 提示框 */}
        <Tooltip
          contentStyle={{
            borderRadius: '4px',
            border: `1px solid ${theme.palette.divider}`,
            boxShadow: '0 4px 8px rgba(0,0,0,0.15)',
            backgroundColor: theme.palette.background.paper,
            color: theme.palette.text.primary,
            maxWidth: 300
          }}
          cursor={{ strokeDasharray: '3 3' }}
          formatter={(value, name) => [formatNumber(Number(value)), name]}
          labelFormatter={(label) => {
            const [xVal, yVal] = label.split(',').map(Number);
            let text = `${xDim}: ${formatNumber(xVal)}\n${yDim}: ${formatNumber(yVal)}\n`;

            // 气泡图显示额外信息
            if (isBubbleChart && valueDims.length > 0) {
              const dataPoint = cleanedData.find(item => item[xDim] === xVal && item[yDim] === yVal);
              if (dataPoint) {
                text += `\n气泡级别: ${dataPoint[valueDims[0]].toFixed(1)}/5`;
                valueDims.slice(1).forEach(dim => {
                  text += `\n${dim}: ${formatNumber(dataPoint[dim])}`;
                });
              }
            }
            return text;
          }}
        />

        {/* 气泡图图例（仅气泡图显示） */}
        {isBubbleChart && valueDims.length > 0 && (
          <Legend wrapperStyle={{ padding: '10px 20px', backgroundColor: 'rgba(255,255,255,0.8)', borderRadius: '4px' }}>
            <span style={{ marginRight: 15, fontWeight: 500 }}>气泡大小:</span>
            {[1, 2, 3, 4, 5].map(level => (
              <div key={`size-${level}`} style={{
                display: 'inline-flex',
                alignItems: 'center',
                margin: '0 10px'
              }}>
                <div style={{
                  width: getBubbleSize(level)/5,
                  height: getBubbleSize(level)/5,
                  borderRadius: '50%',
                  backgroundColor: 'rgba(54, 162, 235, 0.7)',
                  marginRight: 5,
                  border: '1px solid #36a2eb'
                }} />
                <span style={{ fontSize: 12 }}>{level}</span>
              </div>
            ))}
          </Legend>
        )}

        {/* 散点/气泡渲染（根据标志位切换行为） */}
        {groupEntries.length > 0 ? (
          groupEntries.map(([groupName, groupData], index) => (
            <Scatter
              key={groupName}
              name={groupName}
              data={groupData}
              symbol="circle"
              size={item => getPointSize(item)}  // 核心：根据类型决定大小
              fill={colors[index % colors.length]}
              fillOpacity={isBubbleChart ? 0.7 : 0.8}  // 气泡图用更低透明度
              stroke={theme.palette.common.black}
              strokeWidth={isBubbleChart ? 1.5 : 1}    // 气泡图用更粗边框
              animationDuration={1000}
            />
          ))
        ) : (
          <Scatter
            name={`${xDim} vs ${yDim}`}
            data={cleanedData}
            symbol="circle"
            size={item => getPointSize(item)}  // 核心：根据类型决定大小
            fill={colors[0]}
            fillOpacity={isBubbleChart ? 0.7 : 0.8}
            stroke={theme.palette.common.black}
            strokeWidth={isBubbleChart ? 1.5 : 1}
            animationDuration={1000}
          />
        )}
      </ScatterChart>
    </ResponsiveContainer>
  );
    default:
      return null;
  }
};

// 报告区块组件（支持拖拽）
const ReportBlock = ({
  block,
  rowIndex,
  blockIndex,
  onConfigure,
  onDelete,
  data,
  innerRef,
  draggableProps,
  dragHandleProps
}) => {
  const theme = useTheme();

  // 添加调试日志，验证ID是否存在
  useEffect(() => {
    if (!block.id) {
      console.warn('报告区块缺少ID:', block);
    }
  }, [block]);

  return (
    <Card
      ref={innerRef}
      {...draggableProps}
      sx={{
        height: block.type==="wafermap" ? 800:400,
        display: 'flex',
        flexDirection: 'column',
        border: block.isConfigured ? `1px solid ${theme.palette.divider}` : `2px dashed ${theme.palette.primary.main}`,
        borderRadius: '4px',
        transition: 'border 0.3s, box-shadow 0.3s',
        '&:hover': {
          boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
        }
      }}
    >
      <CardHeader
        title={
          <Box display="flex" alignItems="center" gap={1}>
            {/* 拖拽手柄 - 关键改进：将拖拽属性直接应用到手柄 */}
            <div {...dragHandleProps} style={{ cursor: 'grab' }}>
              <DragIcon
                fontSize="small"
                sx={{
                  color: theme.palette.text.secondary,
                  '&:active': { cursor: 'grabbing' }
                }}
              />
            </div>
            <span>{block.title || `未命名${chartTypeOptions.find(ct => ct.value === block.type)?.label}`}</span>
          </Box>
        }
        titleTypographyProps={{
          variant: 'subtitle1',
          sx: { color: theme.palette.text.primary, fontWeight: 500 }
        }}
        action={
          <Box>
            <IconButton
              size="small"
              onClick={(e) => {
                e.stopPropagation();
                onConfigure(rowIndex, blockIndex);
              }}
              sx={{
                color: theme.palette.text.secondary,
                '&:hover': { color: theme.palette.primary.main }
              }}
            >
              <SettingsIcon fontSize="small" />
            </IconButton>
            <IconButton
              size="small"
              onClick={(e) => {
                e.stopPropagation();
                onDelete(rowIndex, blockIndex);
              }}
              sx={{
                color: theme.palette.text.secondary,
                '&:hover': { color: theme.palette.error.main }
              }}
            >
              <DeleteIcon fontSize="small" />
            </IconButton>
          </Box>
        }
        sx={{
          backgroundColor: theme.palette.background.default
        }}
      />
      <Divider sx={{ backgroundColor: theme.palette.divider }} />
      <CardContent sx={{ flexGrow: 1, p: 2, paddingTop: 3 }}>
        <ChartRenderer block={block} data={data} />
      </CardContent>
    </Card>
  );
};

const formatDate = (date) => {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0'); // 月份从0开始，补0
  const day = String(date.getDate()).padStart(2, '0');
  const hours = String(date.getHours()).padStart(2, '0');
  const minutes = String(date.getMinutes()).padStart(2, '0');
  const seconds = String(date.getSeconds()).padStart(2, '0');
  return `${year}-${month}-${day}-${hours}${minutes}${seconds}`;
};


// 自定义报告构建器主组件
const CustomReportBuilder = ({ data: initialData, fileName: initialFileName }) => {
  const theme = useTheme();


  // 状态管理
  const [reportStructure, setReportStructure] = useState([
  // 初始行（外层数组的第1项），包含1个默认块（内层数组的第1项）
  [
    {
      id: `block-${Date.now()}`, // 唯一ID
      type: "bar", // 默认图表类型
      title: "未命名图表", // 默认标题
      width: 3, // 默认占满宽度（3代表100%）
      isConfigured: false, // 未配置状态
      config: { // 符合 Schema 的 config 结构
        xAxis: "", // 初始空X轴
        yAxis: [], // 初始空Y轴数组（关键：避免后续 map 报错）
        radarDimFields:[],
        aggregations: {}, // 初始空聚合配置
        sampling: true, // 默认启用抽样
        sampleSize: 1000 // 默认抽样大小
      }
    }
  ]
]); // 报告结构（二维数组）
  const [data, setData] = useState(initialData || []);
  const [fileName, setFileName] = useState(initialFileName || '');
  const [configDialogOpen, setConfigDialogOpen] = useState(false);
  const [currentBlockIndex, setCurrentBlockIndex] = useState({ row: -1, block: -1 });
  const [tempBlock, setTempBlock] = useState(null); // 临时存储新图表区块
  const [isLoading, setIsLoading] = useState(false);
  const [notification, setNotification] = useState({ open: false, message: '', severity: 'info' });
  // 新增模板保存相关状态
  const [saveTemplateDialogOpen, setSaveTemplateDialogOpen] = useState(false);
  const [templateName, setTemplateName] = useState(`report_${formatDate(new Date())}`);
  const [templateDescription, setTemplateDescription] = useState(''); // 新增描述字段
  const [downloadAfterSave, setDownloadAfterSave] = useState(true);


  const template = {
  metadata: {
    // ... 原有字段
    // 新增Jinja2适配元数据
    backend: {
      dataApi: "/api/v1/report/data", // 后端数据接口
      renderEngine: "jinja2@3.1.2",  // 渲染引擎版本
      cacheExpire: 300,              // 数据缓存时间（秒）
      authRequired: true             // 是否需要权限验证
    }
  },
  structure: reportStructure.map(row =>
  row.map(block => ({
    // ... 原有字段
    config: {
      // ... 原有配置
      // 新增Jinja2渲染配置
      jinja2: {
        // 模板文件路径（后端使用）
        templatePath: `templates/charts/${block.type}_chart.html`,
        // 数据格式化规则
        formatRules: {
          xAxis: {
            type: getFieldType(data, block.config.xAxis) || 'string',
            format: block.config.xAxisType === FIELD_TYPES.DATETIME ? "YYYY-MM-DD" : "auto"
          },
          // 关键修复：确保yAxis是数组后再调用map
          yAxis: (block.config.yAxis || []).map(yField => ({
            field: yField,
            type: getFieldType(data, yField) || 'string',
            format: getFieldType(data, yField) === FIELD_TYPES.NUMERIC ? "0,0.00" : "auto",
            unit: "" // 单位（如：元、件），可在前端配置时添加
          }))
        },
        // 后端参数映射
        params: {
          dataSource: block.config.dataSource || "default", // 数据源标识
          filters: block.config.filters || []               // 数据过滤条件
        }
      }
    }
  }))
),
  // 新增后端渲染全局配置
  renderConfig: {
    pageTitle: "{{ report_title }}", // Jinja2变量占位符
    css: [
      "/static/css/report.css",
      "/static/css/charts.css"
    ],
    js: [
      "/static/js/chart.js",
      "/static/js/report.js"
    ],
    // 页面布局模板
    layoutTemplate: "templates/layouts/main.html"
  }
};

  // 提取可用列
  const availableColumns = data.length > 0 ? Object.keys(data[0]) : [];
  // 关闭通知
const handleCloseNotification = () => {
  setNotification(prev => ({ ...prev, open: false }));
};
  // 处理添加新区块（保持顺序，新图表添加到最后）
  const handleAddBlock = () => {
    if (configDialogOpen) return;
    const newChartId = generateUniqueId();
    const newChart = {
      id: newChartId,
      title: '',
      type: CHART_TYPES.BAR,
      isConfigured: false,
      width: 1, // 新块默认1/3宽度
      config: {}
    };

    // 创建结构副本
    const newStructure = JSON.parse(JSON.stringify(reportStructure));

    // 尝试添加到最后一行
    if (newStructure.length > 0) {
      const lastRowIndex = newStructure.length - 1;
      const lastRow = newStructure[lastRowIndex];
      const remainingWidth = getRowRemainingWidth(lastRow);

      if (remainingWidth >= newChart.width) {
        // 最后一行有空间，直接添加到末尾
        newStructure[lastRowIndex].push(newChart);
      } else {
        // 最后一行空间不足，创建新行
        newStructure.push([newChart]);
      }
    } else {
      // 没有任何行，创建新行
      newStructure.push([newChart]);
    }

    // 应用重排（保持顺序）
    const rearranged = globalRearrangeStructure(newStructure);
    setReportStructure(rearranged);

    // 定位新块
    const newRowIndex = rearranged.findIndex(row => row.some(b => b.id === newChart.id));
    const newBlockIndex = rearranged[newRowIndex].findIndex(b => b.id === newChart.id);
    setCurrentBlockIndex({ row: newRowIndex, block: newBlockIndex });

    setTempBlock(newChart);
    setConfigDialogOpen(true);
    console.log('添加新图表，ID:', newChartId);
  };

  // 处理删除区块
  const handleDeleteBlock = (rowIndex, blockIndex) => {
    // 删除指定图表
    const newStructure = [...reportStructure];
    newStructure[rowIndex].splice(blockIndex, 1);

    // 若该行空了，直接删除该行
    if (newStructure[rowIndex].length === 0) {
      newStructure.splice(rowIndex, 1);
    }

    // 触发全局重排（保持顺序）
    const rearrangedStructure = globalRearrangeStructure(newStructure);
    setReportStructure(rearrangedStructure);

    // 重置选中行
    setCurrentBlockIndex({ row: -1, block: -1 });
    showNotification('图表已删除', 'info');
  };

  // 处理配置区块
  const handleConfigureBlock = (rowIndex, blockIndex) => {
    setCurrentBlockIndex({ row: rowIndex, block: blockIndex });
    setTempBlock(null);
    setConfigDialogOpen(true);
  };

  // 保存区块配置
  const handleSaveBlockConfig = (updatedBlock) => {
    const { row: originalRowIndex, block: originalBlockIndex } = currentBlockIndex;
    let newStructure = [...reportStructure];

    const blockWithId = {
      ...updatedBlock,
      id: updatedBlock.id || generateUniqueId(),
      isConfigured: true
    };

    // 更新图表配置
    if (originalRowIndex === -1) {
      newStructure.push([blockWithId]);
    } else {
      newStructure[originalRowIndex][originalBlockIndex] = blockWithId;
    }

    // 应用重排（保持顺序）
    const rearrangedStructure = globalRearrangeStructure(newStructure);
    setReportStructure(rearrangedStructure);

    // 重新定位当前选中的图表
    const chartId = blockWithId.id;
    let newRowIndex = -1;
    let newBlockIndex = -1;

    rearrangedStructure.forEach((row, rIdx) => {
      const bIdx = row.findIndex(block => block.id === chartId);
      if (bIdx !== -1) {
        newRowIndex = rIdx;
        newBlockIndex = bIdx;
      }
    });
    setCurrentBlockIndex({ row: newRowIndex, block: newBlockIndex });

    // 关闭对话框并提示
    setConfigDialogOpen(false);
    setTempBlock(null);
    showNotification(
      originalRowIndex === -1 ? '新图表已添加' : '图表配置已更新',
      'success'
    );
  };

  // 处理文件上传
  const handleFileUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setIsLoading(true);
    try {
      const reader = new FileReader();
      reader.onload = (event) => {
        try {
          const content = event.target.result;
          const lines = content.split('\n').filter(line => line.trim());
          if (lines.length === 0) throw new Error('文件内容为空');

          // 解析CSV头
          const headers = lines[0].split(',').map(h => h.trim());

          // 解析数据行
          const parsedData = lines.slice(1).map(line => {
            const values = line.split(',');
            return headers.reduce((obj, header, index) => {
              obj[header] = values[index]?.trim() || '';
              return obj;
            }, {});
          });

          setData(parsedData);
          setFileName(file.name);
          showNotification('文件加载成功', 'success');
        } catch (error) {
          showNotification(`文件解析错误: ${error.message}`, 'error');
        } finally {
          setIsLoading(false);
        }
      };
      reader.readAsText(file);
    } catch (error) {
      showNotification(`文件处理失败: ${error.message}`, 'error');
      setIsLoading(false);
    }
  };
  //filename: `${templateName || 'data_report'}_${new Date().getTime()}.pdf`,
  const openSaveTemplateDialog = () => {
    setTemplateName(`report_${new Date().getTime()}`);
    setDownloadAfterSave(true);
    setSaveTemplateDialogOpen(true);
  };


const gen_validateTemplate = () =>{
  return  Array.isArray(reportStructure)
  ? reportStructure.map(row => {
      if (!Array.isArray(row)) return [];

      return row.map(block => {
        const rawConfig = block.config || {};
        const blockType = block.type || "bar"; // 获取当前图表类型

        // 1. 优化dimFields处理逻辑，重点兼容象限图的radarDimFields
        const dimFields = (() => {
          // 优先使用新配置的dimFields（过滤空值）
          if (Array.isArray(rawConfig.dimFields)) {
            return rawConfig.dimFields.filter(Boolean);
          }

          // 特殊处理：象限图优先使用radarDimFields（历史遗留配置）
          if (blockType === "quadrant") {
            // 若radarDimFields存在，转换为数组格式（确保后续能取第一个元素）
            if (rawConfig.radarDimFields) {
              return Array.isArray(rawConfig.radarDimFields)
                ? rawConfig.radarDimFields.filter(Boolean) // 若已是数组，过滤空值
                : [rawConfig.radarDimFields]; // 若为字符串，转为单元素数组
            }
          }

          // 其他图表类型：兼容旧xAxis配置
          if (rawConfig.xAxis) {
            return Array.isArray(rawConfig.xAxis)
              ? rawConfig.xAxis.filter(Boolean)
              : [rawConfig.xAxis];
          }

          // 所有情况都为空时，返回空数组（后续映射会处理默认值）
          return [];
        })();

        // 2. valueFields处理逻辑保持不变
        const valueFields = Array.isArray(rawConfig.valueFields)
          ? rawConfig.valueFields.filter(Boolean)
          : (Array.isArray(rawConfig.yAxis) ? rawConfig.yAxis : (rawConfig.yAxis ? [rawConfig.yAxis] : []));

        // 3. 图表类型映射规则保持不变
        let chartSpecificConfig = {};
        switch (blockType) {
          case "line":
          case "bar":
            chartSpecificConfig = {
              xAxis: dimFields[0] || "",
              yAxis: valueFields.length ? valueFields : ["默认值字段"],
            };
            break;

          case "quadrant":
            chartSpecificConfig = {
              xAxis: dimFields[0] || "", // 现在会优先使用radarDimFields转换后的值
              yAxis: valueFields[0] ? [valueFields[0]] : ["默认值字段"],
            };
            break;

          case "pie":
            chartSpecificConfig = {
              categoryAxis: dimFields[0] || "默认分类",
              valueAxis: valueFields[0] || "默认数值",
            };
            break;

          case "table":
            chartSpecificConfig = {
              tableColumns: [...dimFields, ...valueFields],
            };
            break;

          case "kline":
            chartSpecificConfig = {
                klineTimeField: rawConfig.klineTimeField,
                klineOpen: rawConfig.klineOpen,
                klineClose: rawConfig.klineClose,
                klineHigh: rawConfig.klineHigh,
                klineLow: rawConfig.klineLow
               };
              break;

          case 'gantt':
              chartSpecificConfig = {
                // 甘特图特有配置
                ganttTaskField:  rawConfig.ganttTaskField,
                ganttStartField: rawConfig.ganttStartField,
                ganttEndField: rawConfig.ganttEndField,
                ganttProgressField: rawConfig.ganttProgressField,

                // 甘特图样式配置
                ganttShowProgress: rawConfig.ganttShowProgress !== undefined ? rawConfig.ganttShowProgress : true,
                ganttShowLabels: rawConfig.ganttShowLabels !== undefined ? rawConfig.ganttShowLabels : true,
                ganttBarHeight: rawConfig.ganttBarHeight || 20,
                ganttColorMode: rawConfig.ganttColorMode || 'progress',

                // 甘特图时间范围配置
                ganttTimeRange: rawConfig.ganttTimeRange || 'auto',
                ganttStartDate: rawConfig.ganttStartDate,
                ganttEndDate: rawConfig.ganttEndDate,
              };
              break;

          case 'wafermap':
              chartSpecificConfig = {
                // WaferMap特有配置
                waferIdField:rawConfig.waferIdField,
                waferXField: rawConfig.waferXField,
                waferYField: rawConfig.waferYField,
                waferValueField: rawConfig.waferValueField,
                waferDiameter: rawConfig.waferDiameter || 150,

                // WaferMap显示配置
                waferShowGrid: rawConfig.waferShowGrid !== undefined ? rawConfig.waferShowGrid : true,
                waferShowAxis: rawConfig.waferShowAxis !== undefined ? rawConfig.waferShowAxis : true,

                // WaferMap颜色配置
                waferColorScheme: rawConfig.waferColorScheme || 'blue-red',
                waferValueRange: rawConfig.waferValueRange || 'auto',
                waferMinValue: rawConfig.waferMinValue,
                waferMaxValue: rawConfig.waferMaxValue,

                // 通用配置
              };
              break;

          default:
            chartSpecificConfig = {
              xAxis: dimFields[0] || "",
              yAxis: valueFields.length ? valueFields : ["默认值字段"],
            };
        }

        // 4. 最终配置组装保持不变
        return {
          id: block.id || `block-${Date.now()}-${Math.random().toString(36).slice(-4)}`,
          type: blockType,
          title: block.title || `${blockType === "quadrant" ? "象限图" : blockType === "pie" ? "饼图" : "未命名图表"}`,
          width: block.width || 3,
          isConfigured: block.isConfigured ?? true,
          config: {
            dimFields: dimFields,
            valueFields: valueFields,
            ...chartSpecificConfig,
            aggregations: rawConfig.aggregations || valueFields.reduce((acc, field) => {
              acc[field] = rawConfig.aggregations?.[field] || (blockType === "pie" ? "sum" : "mean");
              return acc;
            }, {}),
            sampling: rawConfig.sampling ?? true,
            sampleSize: rawConfig.sampleSize || 1000,
          },
        };
      });
    })
  : [];
};

const gen_template_json = (templateName, templateDescription,fileName,reportStructure,validStructure)=>{
   return {
    metadata: {
      templateId: `template-${Date.now()}`,
      templateName: templateName.trim(),
      templateDescription: templateDescription.trim(), // 新增描述
      createdAt: new Date().toISOString(),
      version: "1.0.0",
      author: "Unknown",
      filePath: fileName.trim() || '/unknown_file_data.csv', // 默认为默认路径
      // 新增Jinja2适配字段
      jinja2: {
        compatible: true, // 标记为Jinja2兼容
        renderEngine: "jinja2@3.x",
        lastCompatibleVersion: "1.0.0"
      }
    },
    structure:validStructure ,
    // 新增模板预览和Jinja2渲染配置
    preview: {
      blockCount: reportStructure.flat().length,
      rowCount: reportStructure.length,
      hasConfiguredBlocks: reportStructure.flat().some(block => block.isConfigured),
      // Jinja2模板路径配置（后端使用）
      jinja2Config: {
        baseTemplatePath: "templates/base_report.html",
        chartTemplatePaths: {
          bar: "templates/charts/bar_chart.html",
          line: "templates/charts/line_chart.html",
          pie: "templates/charts/pie_chart.html",
          table: "templates/charts/table.html"
        }
      }
    }
  };
};


  // 保存报告模板
  // 核心：处理模板保存逻辑（无全局方法，无未定义变量）
  const handleSaveTemplate = () => {
  if (!templateName.trim()) {
    showNotification('模板名称不能为空', 'warning');
    return;
  }

  const validStructure = gen_validateTemplate( );
  const template = gen_template_json( templateName, templateDescription,fileName,reportStructure,validStructure );

  // 生成适合Jinja2渲染的模板结构

  // 调试：打印 validStructure 类型和值，确认是否为数组
  console.log("validStructure 类型：", typeof validStructure);
  console.log("validStructure 是否为数组：", Array.isArray(validStructure));
  console.log("validStructure 值：", validStructure);

  // 3. 验证模板（使用 schemaValidator.js 的 validateTemplate）
  const validationReport = getTemplateValidationReport(template);
  console.info("验证报告：", validationReport);

  if (!validationReport.isValid) {
    // 显示验证错误详情
    alert(`模板保存失败：\n${validationReport.errors.join("\n")}`);
    return;
  }

  // 验证模板

    // 保存到localStorage（支持多模板管理）
    const existingTemplates = JSON.parse(localStorage.getItem('reportTemplates') || '[]');
    const updatedTemplates = [...existingTemplates, template];
    localStorage.setItem('reportTemplates', JSON.stringify(updatedTemplates, null, 2));

    // 保存后下载
    if (downloadAfterSave) {
      const blob = new Blob(
        [JSON.stringify(template, null, 2)],
        { type: 'application/json' }
      );
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${template.metadata.templateName.replace(/\s+/g, '_')}_jinja2_compatible.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }
     const formData = {
      report_name: template.metadata.templateName,
      template_json: JSON.stringify(template),  // 将完整模板转为JSON字符串
      description: template.metadata.templateDescription,
      file_path: template.metadata.filePath
    };
    // 2. 显示保存中状态
    try {
        showNotification('正在保存模板...', 'info');
        // 3. 发送POST请求到后端接口
        const response =  axios.post('/api/report-template/save', formData,{ withCredentials: true } );
        console.log('模板保存到后端成功：', response.data);
    }catch (error) {
        // 5. 错误处理
        console.error('模板保存失败：', error);
        const errorMsg = error.response?.data?.message || '保存模板到服务器失败，请检查网络或后端服务';
        showNotification(errorMsg, 'error');
    }

    showNotification(`模板"${template.metadata.templateName}"已保存（支持Jinja2渲染）`, 'success');
    setSaveTemplateDialogOpen(false);

};

  // 导出报告
  const handleExportReport = () => {
    const exportData = {
      structure: reportStructure,
      data: data.length > 0 ? data : null,
      fileName,
      exportedAt: new Date().toISOString()
    };

    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `report_${new Date().getTime()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    showNotification('报告已导出', 'success');
  };

  // 导出模板
  const handleExportTemplate = () => {
    const template = {
      metadata: {
        templateId: `template-${Date.now()}`,
        createdAt: new Date().toISOString(),
        version: "1.0.0"
      },
      structure: reportStructure
    };

    const blob = new Blob([JSON.stringify(template, null, 2)], {
      type: 'application/json'
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `report_template_${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // 显示通知
  const showNotification = (message, severity = 'info') => {
    setNotification({
      open: true,
      message,
      severity
    });
  };

  // 处理拖拽结束
  // 处理拖拽结束
  const handleDragEnd = (result) => {
  console.log('拖拽结束:', result);
  const { destination, source, draggableId } = result;

  // 验证拖拽ID
  const idExists = reportStructure.some(row =>
    row.some(block => block.id === draggableId)
  );
  if (!idExists) {
    console.error('拖拽ID不存在:', draggableId);
    showNotification('拖拽失败：图表ID不存在', 'error');
    return;
  }

  // 拖拽取消或位置不变
  if (!destination ||
      (destination.droppableId === source.droppableId &&
       destination.index === source.index)) {
    return;
  }

  // 解析位置（修复索引解析逻辑）
  const sourceRowIndex = parseInt(source.droppableId.split('-')[0], 10);
  let destRowIndex = parseInt(destination.droppableId.split('-')[0], 10);

  // 创建结构副本
  const newStructure = JSON.parse(JSON.stringify(reportStructure));

  // 移除源图表
  const [movedBlock] = newStructure[sourceRowIndex].splice(source.index, 1);

  // 处理空行
  let rowRemoved = false;
  if (newStructure[sourceRowIndex].length === 0) {
    newStructure.splice(sourceRowIndex, 1);
    rowRemoved = true;
    // 调整目标行索引（仅当源行在目标行之前时）
    if (destRowIndex > sourceRowIndex) {
      destRowIndex -= 1;
    }
  }

  // 添加到目标位置
  if (destRowIndex < newStructure.length) {
    newStructure[destRowIndex].splice(destination.index, 0, movedBlock);
  } else {
    newStructure.push([movedBlock]);
  }

  // 重排并更新
  const finalStructure = globalRearrangeStructure(newStructure);
  setReportStructure(finalStructure);
  showNotification('图表位置已更新', 'info');
};

  // 获取当前选中的区块
  const currentBlock = currentBlockIndex.row !== -1 && currentBlockIndex.block !== -1
    ? reportStructure[currentBlockIndex.row]?.[currentBlockIndex.block] || {}
    : {};

// const handleExportHtml= async () => {
//    if (!templateName.trim()) {
//        showNotification('模板名称不能为空', 'warning');
//        return;
//    }
//    const validStructure = gen_validateTemplate( );
//    const template = gen_template_json( templateName, templateDescription,fileName,reportStructure,validStructure );
//
// }

const handleGenReport = async()=>{
       if (!templateName.trim()) {
        showNotification('模板名称不能为空', 'warning');
        return;
      }
      const validStructure = gen_validateTemplate( );
       // 生成适合Jinja2渲染的模板结构
      const template = gen_template_json( templateName, templateDescription,fileName,reportStructure,validStructure );
      const formData = {
          report_name: template.metadata.templateName,
          template_json: JSON.stringify(template),  // 将完整模板转为JSON字符串
      };
        // 2. 显示保存中状态
      try {
            showNotification('正在保存模板...', 'info');
            // 3. 发送POST请求到后端接口
          const response = await  axios.post('/api/report-template/gen_html', formData,{ withCredentials: true } );

          console.log('chufa :', response.data);
          let result =  response.data
          if (result.status==='success') {
          showNotification('报告生成成功，即将下载', 'success'); //&&
          let downloadURL = result.data?.HTMLDownloadURL
          const baseURL = axios.defaults.baseURL || '';
          // 触发下载
          const shouldPrependBaseURL = !downloadURL.startsWith('http') &&
                                 !downloadURL.startsWith('s3://') &&
                                 baseURL;

          if (shouldPrependBaseURL) {
            // 确保baseURL以斜杠结尾
            const adjustedBaseURL = baseURL.endsWith('/') ? baseURL : baseURL + '/';
            // 处理可能的重复斜杠问题
            downloadURL = adjustedBaseURL + downloadURL.replace(/^\//, '');
          }
          console.info("downloadURL:",downloadURL)
          const link = document.createElement('a');
          link.href = downloadURL
          link.download = `${template.metadata.templateName.replace(/\s+/g, '_')}.html`;
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
          console.log('报告下载链接：', result.data.HTMLDownloadURL);
    } else {
       console.info("special00000")
      throw new Error(response.message || '生成报告失败，未返回有效下载地址');
    }
       }catch (error) {
            // 5. 错误处理
            console.error('模板保存失败：', error);
            const errorMsg = error.response?.data?.message || '保存模板到服务器失败，请检查网络或后端服务';
            showNotification(errorMsg, 'error');
        }
  }

  const handleExportPdf = async () => {
  setIsLoading(true);
  showNotification('正在生成PDF报告...', 'info');

  try {
    // 1. 创建PDF内容容器
    const pdfContainer = document.createElement('div');
    pdfContainer.style.width = '100%';
    pdfContainer.style.padding = '20px';
    pdfContainer.style.fontFamily = 'Arial, sans-serif';

    // 2. 添加报告标题和元数据
    const reportHeader = document.createElement('div');
    reportHeader.style.marginBottom = '30px';
    reportHeader.innerHTML = `
      <h1 style="text-align: center; color: #2D82B7; margin-bottom: 10px;">${templateName || '自定义数据报告'}</h1>
      <div style="text-align: center; color: #666; font-size: 14px;">
        生成时间: ${new Date().toLocaleString()} | 数据来源: ${fileName || '未知文件'} | 图表数量: ${reportStructure.flat().length}
      </div>
      <hr style="border: 1px solid #eee; margin-top: 15px;" />
    `;
    pdfContainer.appendChild(reportHeader);

    // 3. 渲染每个图表到PDF容器
    for (let rowIndex = 0; rowIndex < reportStructure.length; rowIndex++) {
      const row = reportStructure[rowIndex];
      const rowContainer = document.createElement('div');
      rowContainer.style.display = 'flex';
      rowContainer.style.flexWrap = 'nowrap';
      rowContainer.style.gap = '20px';
      rowContainer.style.marginBottom = '30px';
      rowContainer.style.width = '100%';

      for (let blockIndex = 0; blockIndex < row.length; blockIndex++) {
        const block = row[blockIndex];
        const blockContainer = document.createElement('div');
        blockContainer.style.width = `${(block.width / 3) * 100}%`;
        blockContainer.style.border = '1px solid #eee';
        blockContainer.style.borderRadius = '4px';
        blockContainer.style.padding = '15px';
        blockContainer.style.boxSizing = 'border-box';

        // 添加图表标题
        const blockTitle = document.createElement('h3');
        blockTitle.style.fontSize = '16px';
        blockTitle.style.color = '#333';
        blockTitle.style.marginTop = '0';
        blockTitle.style.marginBottom = '15px';
        blockTitle.textContent = block.title || `未命名${chartTypeOptions.find(ct => ct.value === block.type)?.label}`;
        blockContainer.appendChild(blockTitle);

        // 渲染图表（使用ChartRenderer的逻辑，生成静态内容）
        const chartContainer = document.createElement('div');
        chartContainer.style.height = '300px';
        chartContainer.style.width = '100%';

        // 处理不同图表类型的静态渲染
        const sampledData = block.config?.sampling ? sampleData(data, block.config.sampleSize) : data;
        const processedData = block.config?.xAxis && block.config?.yAxis?.length
          ? processAggregatedData(sampledData, block.config.xAxis, block.config.yAxis, block.config.aggregations, block.config.yDataMode)
          : sampledData;

        if (block.type === CHART_TYPES.TABLE) {
          // 表格：生成HTML表格
          const tableColumns = block.config?.xAxis
            ? [block.config.xAxis, ...block.config.yAxis]
            : Object.keys(processedData[0] || {});

          const table = document.createElement('table');
          table.style.width = '100%';
          table.style.borderCollapse = 'collapse';
          table.style.fontSize = '12px';

          // 表头
          const thead = document.createElement('thead');
          thead.style.backgroundColor = '#f5f5f5';
          const headerRow = document.createElement('tr');
          tableColumns.forEach(col => {
            const th = document.createElement('th');
            th.style.border = '1px solid #ddd';
            th.style.padding = '8px';
            th.style.textAlign = 'left';
            th.textContent = col;
            headerRow.appendChild(th);
          });
          thead.appendChild(headerRow);
          table.appendChild(thead);

          // 表体
          const tbody = document.createElement('tbody');
          processedData.slice(0, 20).forEach((rowData, idx) => {
            const tr = document.createElement('tr');
            tr.style.backgroundColor = idx % 2 === 0 ? '#fff' : '#f9f9f9';
            tableColumns.forEach(col => {
              const td = document.createElement('td');
              td.style.border = '1px solid #ddd';
              td.style.padding = '8px';
              td.textContent = rowData[col] || '';
              tr.appendChild(td);
            });
            tbody.appendChild(tr);
          });
          table.appendChild(tbody);
          chartContainer.appendChild(table);

          // 数据量提示
          if (processedData.length > 20) {
            const hint = document.createElement('div');
            hint.style.fontSize = '11px';
            hint.style.color = '#666';
            hint.style.margin = '8px';
            hint.textContent = `仅显示前20行，共${processedData.length}行`;
            chartContainer.appendChild(hint);
          }
        } else {
          // 图表（柱状图/折线图/饼图）：生成SVG静态图（简化实现，实际可优化为Canvas转图片）
          const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
          svg.setAttribute("width", "100%");
          svg.setAttribute("height", "100%");
          svg.innerHTML = `<text x="50%" y="50%" text-anchor="middle" dominant-baseline="middle" font-size="14">
                            ${block.title || '图表'}（PDF静态渲染）
                          </text>
                          <text x="50%" y="65%" text-anchor="middle" dominant-baseline="middle" font-size="12" fill="#666">
                            数据来源：${fileName || '未知文件'}
                          </text>`;
          chartContainer.appendChild(svg);

          // （可选）高级优化：使用Chart.js生成Canvas再转图片（需额外处理）
          // 此处为简化版，实际项目可集成Chart.js生成静态图表
        }

        blockContainer.appendChild(chartContainer);
        rowContainer.appendChild(blockContainer);
      }

      pdfContainer.appendChild(rowContainer);
    }

    // 4. 添加报告尾注
    const reportFooter = document.createElement('div');
    reportFooter.style.marginTop = '40px';
    reportFooter.style.textAlign = 'center';
    reportFooter.style.color = '#999';
    reportFooter.style.fontSize = '12px';
    reportFooter.innerHTML = `
      <hr style="border: 1px solid #eee; margin-bottom: 15px;" />
      本报告由自定义BI系统生成 | 模板ID: ${reportStructure.flat()[0]?.id || 'unknown'} | 版本: 1.0.0
    `;
    pdfContainer.appendChild(reportFooter);

    // 5. 生成PDF
    const opt = {
      margin: 10,
      filename: `${templateName || 'data_report'}_${new Date().getTime()}.pdf`,
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: { scale: 2 },
      jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
    };

    // 将容器添加到文档（生成后移除）
    document.body.appendChild(pdfContainer);
    await html2pdf().set(opt).from(pdfContainer).save();
    document.body.removeChild(pdfContainer);

    showNotification('PDF报告生成成功', 'success');
  } catch (error) {
    console.error('PDF生成失败:', error);
    showNotification(`PDF生成失败: ${error.message}`, 'error');
  } finally {
    setIsLoading(false);
  }
};

  return (
    <Box p={3}>
      {/* 使用指南组件 */}
      <FeatureGuide />

      <Box mb={3} display="flex" justifyContent="space-between" alignItems="center" flexWrap="wrap" gap={2}>
        <Typography variant="h5" sx={{ color: theme.palette.text.primary, fontWeight: 500 }}>
          自定义报告/聚合图表
        </Typography>

        <Box display="flex" gap={2} flexWrap="wrap">
          <Button
            variant="outlined"
            component="label"
            startIcon={<FileUploadIcon sx={{ color: theme.palette.primary.main }} />}
            disabled={isLoading}
            sx={{
              borderColor: theme.palette.primary.main,
              color: theme.palette.primary.main,
              '&:hover': {
                borderColor: theme.palette.primary.dark,
                backgroundColor: `${theme.palette.primary.main}10`
              }
            }}
          >
            加载数据文件
            <input type="file" hidden onChange={handleFileUpload} accept=".csv,.json" />
          </Button>

          <Button
            variant="outlined"
            startIcon={<SaveIcon sx={{ color: theme.palette.primary.main }} />}
            onClick={openSaveTemplateDialog}
            sx={{
              borderColor: theme.palette.primary.main,
              color: theme.palette.primary.main,
              '&:hover': {
                borderColor: theme.palette.primary.dark,
                backgroundColor: `${theme.palette.primary.main}10`
              }
            }}
          >
            保存模板
          </Button>


          <Button
            variant="contained"
            startIcon={<DownloadIcon />}
            onClick={handleGenReport}
            sx={{
              backgroundColor: theme.palette.success.main,
              '&:hover': {
                backgroundColor: theme.palette.success.dark,
              },
              ml: 1
            }}
            disabled={reportStructure.length === 0 || data.length === 0}
          >
            生成报告
          </Button>
        </Box>
      </Box>

      {fileName && (
        <Box mb={3}>
          <Chip
            label={`当前数据文件: ${fileName} (${data.length}行)`}
            size="small"
            color={data.length > 1000 ? "warning" : "default"}
            icon={data.length > 1000 ? <FilterIcon fontSize="small" /> : null}
          />
          {data.length > 1000 && (
            <Typography variant="caption" color="warning.main" sx={{ ml: 1 }}>
              数据量较大，建议使用抽样功能
            </Typography>
          )}
        </Box>
      )}

      {/* 报告编辑区 */}
      <Typography variant="subtitle1" gutterBottom sx={{ color: theme.palette.text.primary, fontWeight: 500 }}>
        报告编辑区
      </Typography>

      {/* 报告结构渲染（支持拖拽） */}
      <DragDropContext onDragEnd={handleDragEnd}>
        <Box display="flex" flexDirection="column" gap={3}>
          {/* 空状态提示 */}
          {reportStructure.length === 0 ? (
            <Paper sx={{ p:6, flexDirection:'column', alignItems:'center', justifyContent:'center', border:'1px dashed', borderRadius:4, minHeight:300, display:'flex' }}>
              <AddIcon sx={{ color:'text.secondary', fontSize:48, mb:2 }} />
              <Typography variant="h6" sx={{ color:'text.primary', mb:1 }}>暂无图表</Typography>
              <Typography variant="body1" sx={{ color:'text.secondary', textAlign:'center' }}>点击下方「添加新行」按钮开始创建图表</Typography>
            </Paper>
          ) : (
            <Box display="flex" flexDirection="column" gap={3}>
              {reportStructure.map((row, rowIndex) => (
                <Droppable key={`droppable-${rowIndex}`} droppableId={`${rowIndex}-droppable`}  direction="horizontal" >
                  {(provided) => (
                    <Box
                      ref={provided.innerRef}
                      {...provided.droppableProps}
                      sx={{
                        display: 'flex',
                        flexWrap: 'nowrap',
                        width: '100%',
                        minHeight: 400,
                        mb: 3,
                        p: 2,
                        backgroundColor: theme.palette.background.default,
                        borderRadius: 2,
                        border: `1px solid ${theme.palette.divider}`,
                        overflowX: 'hidden',
                        gap: 2,
                      }}
                    >
                      {row.map((block, blockIndex) => (
                        <Draggable
                          key={block.id}
                          draggableId={block.id}
                          index={blockIndex}
                        >
                          {/* 在这里添加 snapshot 参数 */}
                          {(provided, snapshot) => (
                            <Box
                              // 使用 provided.innerRef 而不是普通的 ref
                              ref={provided.innerRef}
                              // 应用 draggableProps 到容器元素
                              {...provided.draggableProps}
                              key={block.id}
                              sx={{
                                width: `${(block.width / 3) * 100}%`,
                                flex: 1,
                                boxSizing: 'border-box',
                                // 拖拽时的视觉反馈
                                opacity: snapshot.isDragging ? 0.7 : 1,
                                transform: snapshot.isDragging ? 'scale(1.02)' : 'none',
                                transition: 'opacity 0.2s ease, transform 0.2s ease'
                              }}
                            >
                              <ReportBlock
                                block={block}
                                rowIndex={rowIndex}
                                blockIndex={blockIndex}
                                onConfigure={handleConfigureBlock}
                                onDelete={handleDeleteBlock}
                                data={data}
                                // 不需要再传递 innerRef 和 draggableProps 给 ReportBlock
                                // 这些应该应用在最外层容器上
                                dragHandleProps={provided.dragHandleProps}
                              />
                            </Box>
                          )}
                        </Draggable>
                      ))}
                      {provided.placeholder}
                    </Box>
                  )}
                </Droppable>
              ))}
            </Box>
          )}
        </Box>
      </DragDropContext>

      {/* 添加新行按钮 */}
      <Box display="flex" justifyContent="center" mt={2} mb={4}>
        <Button
          variant="outlined"
          startIcon={<AddIcon />}
          onClick={handleAddBlock}
          sx={{
            borderColor: theme.palette.primary.main,
            color: theme.palette.primary.main,
            '&:hover': {
              borderColor: theme.palette.primary.dark,
              backgroundColor: `${theme.palette.primary.main}10`
            }
          }}
        >
          添加新行
        </Button>
      </Box>

      <Dialog
  open={saveTemplateDialogOpen}
  onClose={() => setSaveTemplateDialogOpen(false)}
  maxWidth="sm"
  fullWidth
>
  <DialogTitle sx={{
    backgroundColor: theme.palette.background.default,
    color: theme.palette.primary.main,
    fontWeight: 500
  }}>
    保存报告模板
  </DialogTitle>
  <DialogContent dividers sx={{ padding: '24px' }}>
    <Grid container spacing={3}>
      <Grid item xs={12}>
        <TextField
          fullWidth
          label="模板名称（必填）"
          value={templateName}
          onChange={(e) => setTemplateName(e.target.value.trim())}
          required
          sx={{
            '& .MuiOutlinedInput-root': {
              '& fieldset': { borderColor: theme.palette.divider },
              '&:hover fieldset': { borderColor: theme.palette.primary.main },
              '&.Mui-focused fieldset': { borderColor: theme.palette.primary.main }
            }
          }}
          placeholder="例如：月度销售分析模板"
        />
      </Grid>
      <Grid item xs={12}>
        <TextField
          fullWidth
          multiline
          rows={3}
          label="模板描述（可选）"
          value={templateDescription}
          onChange={(e) => setTemplateDescription(e.target.value.trim())}
          sx={{
            '& .MuiOutlinedInput-root': {
              '& fieldset': { borderColor: theme.palette.divider },
              '&:hover fieldset': { borderColor: theme.palette.primary.main },
              '&.Mui-focused fieldset': { borderColor: theme.palette.primary.main }
            }
          }}
          placeholder="描述该模板的用途、适用场景等"
        />
      </Grid>
      <Grid item xs={12}>
        <FormControlLabel
          control={
            <Checkbox
              checked={downloadAfterSave}
              onChange={(e) => setDownloadAfterSave(e.target.checked)}
              name="downloadAfterSave"
              sx={{
                color: theme.palette.primary.main,
                '&.Mui-checked': { color: theme.palette.primary.main }
              }}
            />
          }
          label="保存后自动下载模板文件"
          sx={{ color: theme.palette.text.secondary }}
        />
      </Grid>
    </Grid>
  </DialogContent>
  <DialogActions sx={{
    padding: '16px 24px',
    backgroundColor: theme.palette.background.default
  }}>
    <Button
      onClick={() => setSaveTemplateDialogOpen(false)}
      sx={{
        color: theme.palette.text.secondary,
        '&:hover': {
          backgroundColor: theme.palette.action.hover,
          color: theme.palette.text.primary
        }
      }}
    >
      取消
    </Button>
    <Button
      onClick={handleSaveTemplate}
      sx={{
        backgroundColor: theme.palette.primary.main,
        color: 'white',
        '&:hover': { backgroundColor: theme.palette.primary.dark }
      }}
      disabled={!templateName.trim()} // 名称为空时禁用
    >
      确认保存
    </Button>
  </DialogActions>
</Dialog>

      {/* 图表配置对话框 */}
      <ChartConfigDialog
        open={configDialogOpen}
        onClose={() => {
          setConfigDialogOpen(false);
          setTempBlock(null);
        }}
        onSave={handleSaveBlockConfig}
        block={
          currentBlockIndex.row === -1
            ? (tempBlock || { config: {} })
            : (currentBlock || { config: {} })
        }
        availableColumns={availableColumns}
        data={data}
      />

      {/* 通知提示 */}
      <Snackbar
        open={notification.open}
        autoHideDuration={6000}
        onClose={handleCloseNotification}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
      >
        <Alert
          onClose={handleCloseNotification}
          severity={notification.severity}
          sx={{
            backgroundColor: theme.palette.background.paper,
            color: theme.palette.text.primary
          }}
        >
          {notification.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default CustomReportBuilder;