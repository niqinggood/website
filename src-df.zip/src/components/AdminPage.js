import React, { useState, useEffect } from 'react';
import { Card, Tabs, Table, Button, Form, Input, Select, message, Modal, Divider,Tag,Space,Descriptions, } from 'antd';
import { PlusOutlined, DeleteOutlined, EditOutlined, EyeOutlined, SaveOutlined,SearchOutlined } from '@ant-design/icons';
// import { CheckboxGroup } from 'antd';

// 正确写法
import { Checkbox } from 'antd';

import {
  // Material-UI 图标
  Dashboard, ShoppingCart, Insights, AdminPanelSettings,
  ListAlt, Settings, ExitToApp, AccountCircle,AutoFixHigh,
  // 添加更多常用图标
  Home, Group, Lock, Public, Code, Storage,
  Cloud, Security, Build, MenuBook, Assessment,
  // 系统管理相关
  People, PersonAdd, VpnKey, Api, Webhook
} from '@mui/icons-material'

import axios from 'axios';
const { Group: CheckboxGroup } = Checkbox; // 这样可以保持后续代码中使用 CheckboxGroup 这个名称
const { TabPane }  = Tabs;
const { Option }   = Select;
const { TextArea } = Input;

// 简化的图标映射
const iconMap = {
  // 基础图标
  'AutoFixHigh':<AutoFixHigh />,
  'Dashboard': <Dashboard />,
  'ShoppingCart': <ShoppingCart />,
  'Insights': <Insights />,
  'AdminPanelSettings': <AdminPanelSettings />,
  'ListAlt': <ListAlt />,
  'Home': <Home />,
  'Group': <Group />,
  'Lock': <Lock />,
  'Public': <Public />,
  'Code': <Code />,
  'Storage': <Storage />,
  'Cloud': <Cloud />,
  'Security': <Security />,
  'Build': <Build />,
  'MenuBook': <MenuBook />,
  'Assessment': <Assessment />,
  // 系统管理
  'People': <People />,
  'PersonAdd': <PersonAdd />,
  'VpnKey': <VpnKey />,
  'Api': <Api />,
  'Webhook': <Webhook />,
};

// 图标选择器组件
const IconSelector = ({ value, onChange }) => (
  <Select
    showSearch
    style={{ width: '100%' }}
    placeholder="选择图标"
    optionFilterProp="children"
    value={value}
    onChange={onChange}
    filterOption={(input, option) =>
      option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
    }
  >
    {Object.keys(iconMap).map(iconName => (
      <Option key={iconName} value={iconName}>
        <span style={{ display: 'flex', alignItems: 'center' }}>
          {iconMap[iconName]}
          <span style={{ marginLeft: 8 }}>{iconName}</span>
        </span>
      </Option>
    ))}
  </Select>
);

// 添加新的DataFetchManagement组件
const DataFetchManagement = () => {
  const [tables, setTables] = useState([]);
  const [isTableModalVisible, setIsTableModalVisible] = useState(false);
  const [editingTable, setEditingTable] = useState(null);
  const [analyzingTable, setAnalyzingTable] = useState(null);
  const [schemaPreview, setSchemaPreview] = useState(null);
  const [form] = Form.useForm();
  const [users, setUsers] = useState([]); // 假设已经有用户列表

  useEffect(() => {
    fetchTables();
    fetchUsers(); // 获取用户列表用于权限分配
  }, []);

  const fetchTables = async () => {
  try {
    const response = await axios.get('/api/data-fetch/tables',{withCredentials:true});
    // 确保设置的是数组
    if (Array.isArray(response.data)) {
      setTables(response.data);
    } else {
      setTables([]);
      console.warn('获取的数据不是数组格式', response.data);
    }
  } catch (error) {
    message.error('获取数据表失败');
    setTables([]); // 出错时也确保是数组
  }
};

  const fetchUsers = async () => {
  try {
    const response = await axios.get('/api/users');
    // 确保设置的是数组
    if (Array.isArray(response.data)) {
      setUsers(response.data);
    } else {
      setUsers([]);
      console.warn('获取的用户数据不是数组格式', response.data);
    }
  } catch (error) {
    message.error('获取用户列表失败');
    setUsers([]); // 出错时也确保是数组
  }
};



  const handleSaveTable = async () => {
    try {
      const values = await form.validateFields();

      console.info("editingTable:",editingTable)

      if (editingTable) {
        const payload = {
          
          id: editingTable.ID,  // 将 ID 改为小写 id（如果后端标签是 "id"）
          tableName: values.tableName,  // 确认后端标签是 "tableName" 而非 "table_name"
          // 移除后端自动维护的字段（如 CreatedAt、UpdatedAt 等）
          allowedUsers: typeof values.allowedUsers === 'string' 
              ? values.allowedUsers 
              : values.allowedUsers.join(',')
          // 只保留后端需要的字段，删除 CreatedAt、UpdatedAt、DeletedAt 等
      };
        console.info("editingTable:",editingTable)
        await axios.post(`/api/data-fetch/updatetable`, payload,{withCredentials:true});
        message.success('表更新成功');
      } else {
        const payload = {
           ...values,
          tableName: values.tableName,  // 确认后端标签是 "tableName" 而非 "table_name"
          // 移除后端自动维护的字段（如 CreatedAt、UpdatedAt 等）
          allowedUsers: typeof values.allowedUsers === 'string' 
              ? values.allowedUsers 
              : values.allowedUsers.join(',')
          // 只保留后端需要的字段，删除 CreatedAt、UpdatedAt、DeletedAt 等
      };
        await axios.post('/api/data-fetch/tables', payload,{withCredentials:true});
        message.success('表添加成功');
      }

      setIsTableModalVisible(false);
      fetchTables();
    } catch (error) {
      message.error('保存表失败');
    }
  };

  const handleDeleteTable = async (id) => {
    try {
      await axios.delete(`/api/data-fetch/tables/${id}`);
      message.success('表删除成功');
      fetchTables();
    } catch (error) {
      message.error('表删除失败');
    }
  };

  const handleAnalyzeTable = async (id) => {
    setAnalyzingTable(id);
    try {
      const response = await axios.post(`/api/data-fetch/tables/analyze/${id}`);
      message.success('表结构分析成功');
      setSchemaPreview(response.data.schema);
      fetchTables();
    } catch (error) {
      message.error('表结构分析失败');
    } finally {
      setAnalyzingTable(null);
    }
  };

  const columns = [
    {
      title: '表名',
      dataIndex: 'tableName',
      key: 'tableName',
    },
    {
      title: '显示名称',
      dataIndex: 'displayName',
      key: 'displayName',
    },
    {
      title: '数据源',
      dataIndex: 'dataSource',
      key: 'dataSource',
    },
    {
      title: '类型',
      dataIndex: 'isView',
      key: 'isView',
      render: (isView) => (isView ? '视图' : '表'),
    },
    {
      title: '状态',
      dataIndex: 'status',
      key: 'status',
      render: (status) => {
        let color = '';
        switch (status) {
          case 'active': color = 'green'; break;
          case 'error': color = 'red'; break;
          default: color = 'orange';
        }
        return <Tag color={color}>{status}</Tag>;
      },
    },
    {
      title: '最后分析时间',
      dataIndex: 'lastAnalyzedAt',
      key: 'lastAnalyzedAt',
      render: (time) => time ? new Date(time * 1000).toLocaleString() : '未分析',
    },
    {
      title: '操作',
      key: 'actions',
      render: (_, record) => (
        <Space>
          <Button
            icon={<EditOutlined />}
            onClick={() => {
              setEditingTable(record);
              form.setFieldsValue({
                  ...record,
                  allowedUsers: record.allowedUsers // Keep as string for TextArea
                });
              setIsTableModalVisible(true);
            }}
          />
          <Button
            icon={<DeleteOutlined />}
            danger
            onClick={() => handleDeleteTable(record.tableName)}
          />
          <Button
            icon={<SearchOutlined />}
            onClick={() => handleAnalyzeTable(record.tableName)}
            loading={analyzingTable === record.tableName}
          />
        </Space>
      ),
    },
  ];

  return (
    <div>
      <Button
        type="primary"
        icon={<PlusOutlined />}
        onClick={() => {
          setEditingTable(null);
          form.resetFields();
          setIsTableModalVisible(true);
        }}
        style={{ marginBottom: 16 }}
      >
        添加数据表
      </Button>

      <Table
          dataSource={tables || []}  // 确保是数组
          columns={columns}
          rowKey="id"
          pagination={false}
        />

      {/* 表结构预览 */}
      {schemaPreview && (
        <Card title="表结构预览" style={{ marginTop: 16 }}>
          <Table
              dataSource={schemaPreview || []}  // 确保是数组
              columns={[
                { title: '列名', dataIndex: 'columnName', key: 'columnName' },
                { title: '数据类型', dataIndex: 'dataType', key: 'dataType' },
                { title: '可为空', dataIndex: 'isNullable', key: 'isNullable', render: v => (v ? '是' : '否') },
                { title: '注释', dataIndex: 'comment', key: 'comment' },
              ]}
              size="small"
              pagination={false}
            />
        </Card>
      )}

      {/* 表编辑Modal */}
      <Modal
        title={editingTable ? '编辑数据表' : '添加数据表'}
        visible={isTableModalVisible}
        onOk={handleSaveTable}
        onCancel={() => setIsTableModalVisible(false)}
        width={800}
      >
        <Form form={form} layout="vertical">
          <Form.Item name="tableName" label="表名" rules={[{ required: true }]}>
            <Input placeholder="请输入表名" />
          </Form.Item>

          <Form.Item name="displayName" label="显示名称" rules={[{ required: true }]}>
            <Input placeholder="请输入显示名称" />
          </Form.Item>

          <Form.Item name="description" label="描述">
            <TextArea rows={3} placeholder="请输入表描述" />
          </Form.Item>

          <Form.Item name="dataSource" label="数据源" rules={[{ required: true }]}>
            <Input placeholder="例如: mysql.production" />
          </Form.Item>

          <Form.Item name="isView" label="类型" rules={[{ required: true }]}>
            <Select>
              <Option value={false}>表</Option>
              <Option value={true}>视图</Option>
            </Select>
          </Form.Item>

          <Form.Item name="sqlDefinition" label="SQL定义">
            <TextArea rows={5} placeholder="如果是视图，请输入视图定义SQL" />
          </Form.Item>

          <Form.Item name="allowedUsers" label="允许访问的用户">
            <TextArea
                placeholder="请输入允许访问的用户，多个用户用逗号分隔"
                rows={4} // 设置文本框高度（行数）
                maxLength={500} // 可选：限制最大输入长度
              />
          </Form.Item>
        </Form>
      </Modal>
    </div>
  );
};

const AdminPage = () => {
  const [users, setUsers] = useState([]);
  const [isModalVisible, setIsModalVisible] = useState(false); // 控制编辑弹窗
  const [editingUser, setEditingUser] = useState(null); // 当前编辑的用户
  const [groups, setGroups] = useState([]);
  const [ssoConfig, setSSOConfig] = useState(null);
  const [previewUser, setPreviewUser] = useState(null);
  const [isPreviewVisible, setIsPreviewVisible] = useState(false);
  const [requestExample, setRequestExample] = useState('');

  const [menuItems, setMenuItems] = useState([]);
  const [isMenuModalVisible, setIsMenuModalVisible] = useState(false);
  const [editingMenuItem, setEditingMenuItem] = useState(null);
  const [form4] = Form.useForm(); // 用于菜单项配置
  
  const [tables, setTables] = useState([]);
  const [form1] = Form.useForm(); // 用于账号权限管理
  const [form2] = Form.useForm(); // 用于所属组配置
  const [form3] = Form.useForm(); // 用于消息广播

  const [layouts, setLayouts] = useState([]);
  const [isLayoutModalVisible, setIsLayoutModalVisible] = useState(false);
  const [editingLayout, setEditingLayout] = useState(null);
  const [layoutForm] = Form.useForm();
  const [jsonEditorValue, setJsonEditorValue] = useState('{}');

// 权限管理核心状态
const [operations, setOperations] = useState([]); // 操作列表（初始化为数组）
const [editingOp, setEditingOp] = useState(null); // 当前编辑的操作
const [isOpModalVisible, setIsOpModalVisible] = useState(false); // 弹窗状态
const [opForm] = Form.useForm(); // 表单实例

// 初始化数据
useEffect(() => {
  const loadOperations = async () => {
    try {
      const res = await axios.get('/api/operations', { withCredentials: true });
      setOperations(Array.isArray(res.data) ? res.data : []);
    } catch (err) {
      console.error('加载操作列表失败:', err);
      setOperations([]);
    }
  };
  loadOperations();
}, []);
// 打开弹窗（新增/编辑）
const handleOpenOpModal = (op = null) => {
  setEditingOp(op);
  opForm.setFieldsValue(op || { key: '', name: '', users: op.users||'' }); // 直接设置表单值
  setIsOpModalVisible(true);
};

// 保存操作（新增/编辑）
const handleSaveOperation = async () => {
  try {
    const values = await opForm.validateFields();
    console.info("values:",values)
    if (editingOp) {
      // 更新操作
      await axios.put(`/api/operations/${values.key}`, values, { withCredentials: true });
      message.success('操作更新成功');
    } else {
      // 创建操作
      await axios.post('/api/operations', values, { withCredentials: true });
      message.success('操作创建成功');
    }
    // 刷新列表
    const res = await axios.get('/api/operations', { withCredentials: true });
    setOperations(Array.isArray(res.data) ? res.data : []);
    setIsOpModalVisible(false);
  } catch (err) {
    message.error(editingOp ? '更新失败' : '创建失败');
  }
};

// 删除操作
const handleDeleteOperation = async (key) => {
  try {
    await axios.delete(`/api/operations/${key}`, { withCredentials: true });
    message.success('操作删除成功');
    // 刷新列表
    const res = await axios.get('/api/operations', { withCredentials: true });
    setOperations(Array.isArray(res.data) ? res.data : []);
  } catch (err) {
    message.error('删除失败');
  }
};


  // 加载用户和组数据
  useEffect(() => {
    fetchMenuItems();
    fetchSSOConfig();
    fetchLayouts();
  }, []);
  
  const fetchLayouts = async () => {
    try {
      const response = await axios.get('/api/layouts');
      setLayouts(response.data || []);
    } catch (error) {
      console.error('获取布局配置失败:', error);
      message.error('获取布局配置失败');
      setLayouts( []);
    }
  };

  const handleSaveLayout = async () => {
    try {
      const values = await layoutForm.validateFields();
      
      // 验证JSON格式
      try {
        JSON.parse(jsonEditorValue);
      } catch (e) {
        message.error('JSON格式无效');
        return;
      }

      const payload = {
        LayoutName: values.LayoutName,
        LayoutJSON: jsonEditorValue,
        OptionsJSON: values.OptionsJSON || '{}'
      };

      if (editingLayout) {
        await axios.put(`/api/layouts/${editingLayout.LayoutName}`, payload);
        message.success('布局更新成功');
      } else {
        await axios.post('/api/layouts', payload);
        message.success('布局添加成功');
      }

      setIsLayoutModalVisible(false);
      fetchLayouts();
    } catch (error) {
      console.error('保存布局失败:', error);
      message.error('保存布局失败');
    }
  };

  const handleEditLayout = (layout) => {
    setEditingLayout(layout);
    setJsonEditorValue(layout.LayoutJSON);
    layoutForm.setFieldsValue({
      LayoutName: layout.LayoutName,
      OptionsJSON: layout.OptionsJSON
    });
    setIsLayoutModalVisible(true);
  };

  const handleDeleteLayout = async (layoutName) => {
    try {
      await axios.delete(`/api/layouts/${layoutName}`);
      message.success('布局删除成功');
      fetchLayouts();
    } catch (error) {
      message.error('布局删除失败');
    }
  };

   // 布局配置表格列
   const layoutColumns = [
    {
      title: '布局名称',
      dataIndex: 'LayoutName',
      key: 'LayoutName',
    },
    {
      title: '最后更新时间',
      dataIndex: 'UpdatedAt',
      key: 'UpdatedAt',
      render: (timestamp) => new Date(timestamp * 1000).toLocaleString(),
    },
    {
      title: '操作',
      key: 'actions',
      render: (_, record) => (
        <>
          <Button
            type="primary"
            icon={<EditOutlined />}
            onClick={() => handleEditLayout(record)}
            style={{ marginRight: 8 }}
          >
            编辑
          </Button>
          <Button 
            danger 
            icon={<DeleteOutlined />} 
            onClick={() => handleDeleteLayout(record.LayoutName)}
          >
            删除
          </Button>
        </>
      ),
    },
  ];

  const fetchMenuItems = async () => {
      try {
        const response = await axios.get('/api/menu-items');
        // 确保 response.data 是数组
        setMenuItems(Array.isArray(response.data) ? response.data : []);
      } catch (error) {
        console.error('获取菜单项失败:', error);
        setMenuItems([]); // 请求失败时设置为空数组
      }
  };

  // 添加或更新菜单项
const handleSaveMenuItem = async () => {
  try {
    const values = await form4.validateFields();

    // 转换数据类型
    const payload = {
      ...values,
      order: Number(values.order), // 将字符串转为数字
      isExternal: Boolean(values.isExternal) // 确保布尔值
    };

    if (editingMenuItem) {
      await axios.put(`/api/menu-items/${editingMenuItem.itemkey}`, payload);
      message.success('菜单项更新成功');
    } else {
      await axios.post('/api/menu-items', payload);
      message.success('菜单项添加成功');
    }

    setIsMenuModalVisible(false);
    fetchMenuItems();
  } catch (error) {
    console.error('保存菜单项失败:', error);
    message.error('保存菜单项失败');
  }
};

  // 编辑菜单项
  const handleEditMenuItem = (item) => {
    setEditingMenuItem(item);
    form4.setFieldsValue(item);
    setIsMenuModalVisible(true);
 };

  // 删除菜单项
  const handleDeleteMenuItem = async (id) => {
    try {
      await axios.delete(`/api/menu-items/${id}`);
      message.success('菜单项删除成功');
      fetchMenuItems();
    } catch (error) {
      message.error('菜单项删除失败');
    }
  };

  // 菜单项表格列
  const menuColumns = [
    {
      title: '键',
      dataIndex: 'key',
      key: 'key',
    },
    {
      title: '显示文本',
      dataIndex: 'text',
      key: 'text',
    },
    {
      title: '图标',
      dataIndex: 'icon',
      key: 'icon',
      render: (icon) => iconMap[icon] || icon,
    },
    {
      title: '链接',
      dataIndex: 'link',
      key: 'link',
    },
    {
      title: '是否外部链接',
      dataIndex: 'isExternal',
      key: 'isExternal',
      render: (isExternal) => (isExternal ? '是' : '否'),
    },
    {
      title: '排序',
      dataIndex: 'order',
      key: 'order',
    },
    {
      title: '操作',
      key: 'actions',
      render: (_, record) => (
        <>
          <Button
            type="primary"
            icon={<EditOutlined />}
            onClick={() => handleEditMenuItem(record)}
            style={{ marginRight: 8 }}
          >
            编辑
          </Button>
          <Button danger icon={<DeleteOutlined />} onClick={() => handleDeleteMenuItem(record.id)}>
            删除
          </Button>
        </>
      ),
    },
  ];

  const fetchSSOConfig = async () => {
  try {
    const response = await axios.get('/api/sso-config');
    if (response.data) {
      setSSOConfig(response.data);
    } else {
      console.error('SSO 配置数据为空');
      message.error('获取 SSO 配置失败，数据为空');
    }
  } catch (error) {
    console.error('获取 SSO 配置失败:', error);
    message.error('获取 SSO 配置失败，请稍后重试');
  }
};



  const handlePreviewUser = (values) => {
    setPreviewUser(values);
    setIsPreviewVisible(true);
  };

  // 编辑用户
  const handleEditUser = (user) => {
  setEditingUser(user); // 设置当前编辑的用户
  form1.setFieldsValue(user); // 将用户数据填充到表单
  setIsModalVisible(true); // 打开编辑弹窗
  };



    // 关闭弹窗
  const handleCancel = () => {
    setIsModalVisible(false);
  };

  const handleDeleteUser = async (userId) => {
    try {
      await axios.delete(`/api/users/${userId}`);
      message.success('用户删除成功');

    } catch (error) {
      message.error('用户删除失败');
    }
  };

  // 组配置
  const handleAddGroup = async (values) => {
    try {
      await axios.post('/api/groups', values);
      message.success('组添加成功');

      form2.resetFields();
    } catch (error) {
      message.error('组添加失败');
    }
  };


  // SSO 登录配置
  const handleSSOConfig = async (values) => {
    try {
      await axios.post('/api/sso-config', values);
      message.success('SSO 配置成功');
      fetchSSOConfig();
          // 示例用户和密码
        const username = 'zhangsan';
        const password = '123';

        // 对字段进行 URL 编码（如果需要）
        const encodedUsername = values.urlEncode ? encodeURIComponent(username) : username;
        const encodedPassword = values.urlEncode ? encodeURIComponent(password) : password;

        // 生成请求示例
        let example = '';
        if (values.method === 'GET') {
          const params = new URLSearchParams();
          params.append(values.userField, encodedUsername);
          params.append(values.passwordField, encodedPassword);
          example = `${values.ssoUrl}?${params.toString()}`;
        } else if (values.method === 'POST') {
          example = `请求地址: ${values.ssoUrl}\n请求体: ${JSON.stringify(
            {
              [values.userField]: encodedUsername,
              [values.passwordField]: encodedPassword,
            },
            null,
            2
          )}`;
        }


      // 补充登录成功判断逻辑
    let successCondition = '';
    switch (values.ssoSussJudge) {
      case 'text is "0"':
        successCondition = '响应文本为 "0" 表示登录成功';
        break;
      case 'text is "succ"':
        successCondition = '响应文本为 "succ" 表示登录成功';
        break;
      case 'ret json contain token&not nul':
        successCondition = '响应 JSON 包含 token 字段且不为空表示登录成功';
        break;
      case 'ret json contain code':
        successCondition = '响应 JSON 包含 code 字段表示登录成功';
        break;
      default:
        successCondition = '未指定登录成功判断方式';
    }

    // 设置请求示例和登录成功判断逻辑
    setRequestExample(`${example}\n\n登录成功判断方式: ${successCondition}`);

    } catch (error) {
      message.error('SSO 配置失败');
    }
  };

  // 用户权限管理表格列
  const userColumns = [
    {
      title: '用户名',
      dataIndex: 'Username',
      key: 'Username',
    },
    {
      title: '角色',
      dataIndex: 'Role',
      key: 'Role',
    },
    {
      title: '登录方式',
      dataIndex: 'LoginMethod',
      key: 'LoginMethod',
    },
    {
      title: '所属组',
      dataIndex: 'GroupName',
      key: 'GroupName',
    },
    {
      title: 'Email',
      dataIndex: 'Email',
      key: 'Email',
    },
    {
      title: '激活码',
      dataIndex: 'Activation',
      key: 'Activation',
    },
    {
      title: '操作',
      key: 'actions',
      render: (_, record) => (
        <>
          <Button
            type="primary"
            icon={<EditOutlined />}
            onClick={() => handleEditUser(record.Username)}
            style={{ marginRight: 8 }}
          >
            编辑
          </Button>
          <Button danger icon={<DeleteOutlined />} onClick={() => handleDeleteUser(record.Username)}>
            删除
          </Button>
        </>
      ),
    },
  ];

  
  return (
    <Card title="管理员面板" style={{ margin: '20px' }}>
      <Tabs defaultActiveKey="1">
        {/* SSO 登录配置 */}
        <TabPane tab="SSO 登录配置" key="4">
          
           {ssoConfig && (
            <Card 
              title="当前SSO配置" 
              style={{ marginBottom: 16 }}
              extra={
                <Space>
                  
                  <Button 
                    danger 
                    icon={<DeleteOutlined />}
                    onClick={async () => {
                      try {
                        await axios.delete('/api/sso-config');
                        message.success('SSO配置已删除');
                        setSSOConfig(null);
                        setRequestExample('');
                      } catch (error) {
                        message.error('删除SSO配置失败');
                      }
                    }}
                  >
                    删除
                  </Button>
                </Space>
              }
            >
              <Descriptions bordered column={1}>
                <Descriptions.Item label="SSO地址">{ssoConfig.ssoUrl}</Descriptions.Item>
                <Descriptions.Item label="请求方法">{ssoConfig.method}</Descriptions.Item>
                <Descriptions.Item label="用户名字段">{ssoConfig.userField}</Descriptions.Item>
                <Descriptions.Item label="密码字段">{ssoConfig.passwordField}</Descriptions.Item>
                <Descriptions.Item label="URL编码">{ssoConfig.urlEncode ? '是' : '否'}</Descriptions.Item>
                <Descriptions.Item label="登录成功判断">{ssoConfig.ssoSussJudge}</Descriptions.Item>
                <Descriptions.Item label="最后更新时间">
                  {new Date(ssoConfig.Timestamp).toLocaleString()}
                </Descriptions.Item>
              </Descriptions>
            </Card>
          )}

          <Form onFinish={handleSSOConfig} layout="vertical">
            <Form.Item name="ssoUrl" label="SSO 地址" rules={[{ required: true }]}>
              <Input placeholder="请输入 SSO 地址" />
            </Form.Item>
            <Form.Item name="method" label="请求方法" rules={[{ required: true }]}>
              <Select placeholder="请选择请求方法">
                <Option value="GET">GET</Option>
                <Option value="POST">POST</Option>
              </Select>
            </Form.Item>
            <Form.Item name="userField" label="用户名字段" rules={[{ required: true }]}>
              <Input placeholder="请输入用户名字段" />
            </Form.Item>
            <Form.Item name="passwordField" label="密码字段" rules={[{ required: true }]}>
              <Input placeholder="请输入密码字段" />
            </Form.Item>
             <Form.Item name="urlEncode" label="是否进行 URL 编码" valuePropName="checked">
              <Select placeholder="请选择是否进行 URL 编码">
                <Option value={true}>是</Option>
                <Option value={false}>否</Option>
              </Select>
            </Form.Item>
            <Form.Item name="ssoSussJudge" label="返回确认登录方式" valuePropName="checked">
              <Select placeholder="选择密码正确方式">
                <Option value='text is "0"'>text is "0"</Option>
                <Option value='text is "succ"'>text is "succ"</Option>
                <Option value='ret json contain token&not nul'>ret json contain token&not nul</Option>
                <Option value='ret json contain code'>ret json contain code</Option>
              </Select>
            </Form.Item>
            <Form.Item>
              <Button type="primary" htmlType="submit">
                保存配置
              </Button>
            </Form.Item>

          </Form>

          {/* 请求测试样例 */}
          {requestExample && (
            <div style={{ marginTop: '24px' }}>
              <h3>请求测试样例</h3>
              <pre style={{ background: '#f5f5f5', padding: '12px', borderRadius: '4px' }}>
                {requestExample}
              </pre>
            </div>
          )}

        </TabPane>

        <TabPane tab="顶部和LIST菜单配置" key="6">
          <Button
            type="primary"
            icon={<PlusOutlined />}
            onClick={() => {
              setEditingMenuItem(null);
              form4.resetFields();
              setIsMenuModalVisible(true);
            }}
            style={{ marginBottom: 16 }}
          >
            添加菜单项
          </Button>

          <Table
            dataSource={menuItems}
            columns={menuColumns}
            rowKey="id"
            pagination={false}
          />
        </TabPane>
        
        {/* 新增的Layout配置Tab */}
        <TabPane tab="页面布局配置" key="7">
            <Button
              type="primary"
              icon={<PlusOutlined />}
              onClick={() => {
                setEditingLayout(null);
                layoutForm.resetFields();
                setJsonEditorValue('{}');
                setIsLayoutModalVisible(true);
              }}
              style={{ marginBottom: 16 }}
            >
              添加布局配置
            </Button>

            <Table
              dataSource={layouts}
              columns={layoutColumns}
              rowKey="LayoutName"
              pagination={false}
            />
        </TabPane>
      
      <TabPane tab="数据集市管理" key="8">
        <DataFetchManagement />
      </TabPane>

       <TabPane tab="权限管控" key="9">
          <Card title="操作与用户权限管理">
            <Button
              type="primary"
              icon={<PlusOutlined />}
              onClick={() => handleOpenOpModal()}
              style={{ marginBottom: 16 }}
            >
              添加操作
            </Button>

            <Table
              dataSource={operations}
              columns={[
                { title: '操作标识', dataIndex: 'key', key: 'key' },
                { title: '操作名称', dataIndex: 'name', key: 'name' },
                {
                  title: '授权用户ID',
                  dataIndex: 'users',
                  key: 'users',
                  render: (users) => users || '无', // 直接显示用户ID字符串
                },
                {
                  title: '操作',
                  key: 'action',
                  render: (_, record) => (
                    <Space>
                      <Button
                        icon={<EditOutlined />}
                        onClick={() => handleOpenOpModal(record)}
                      >
                        编辑
                      </Button>
                      <Button
                        danger
                        icon={<DeleteOutlined />}
                        onClick={() => handleDeleteOperation(record.key)}
                      >
                        删除
                      </Button>
                    </Space>
                  )
                }
              ]}
              rowKey="key"
              pagination={false}
              locale={{ emptyText: '暂无操作，请点击"添加操作"创建' }}
            />
          </Card>

          {/* 操作编辑弹窗（简化版） */}
          <Modal
            title={editingOp ? `编辑操作: ${editingOp.key}` : '添加新操作'}
            visible={isOpModalVisible}
            onOk={handleSaveOperation}
            onCancel={() => setIsOpModalVisible(false)}
            width={500}
          >
            <Form form={opForm} layout="vertical">
              <Form.Item
                name="key"
                label="操作标识"
                rules={[{ required: true }]}
                disabled={!!editingOp}
              >
                <Input placeholder="例如：data-express-sql" />
              </Form.Item>

              <Form.Item
                name="name"
                label="操作名称"
                rules={[{ required: true }]}
              >
                <Input placeholder="例如：SQL查询功能" />
              </Form.Item>

              {/* 核心简化：用多行输入框直接填写用户ID（逗号分隔） */}
              <Form.Item
                name="users"
                label="授权用户ID（逗号分隔）"
                rules={[{ required: true }]}
              >
                
                  <TextArea
                    rows={4}
                    placeholder="例如：1001,1002,1003（多个用户ID用逗号分隔）"
                    valuePropName="value"  // 明确绑定值属性
                    // 可选：添加 onChange 调试，查看输入是否被捕获
                    onChange={(e) => console.log("用户输入:", e.target.value)}
                  />
              </Form.Item>
            </Form>
          </Modal>
        </TabPane>

      </Tabs>
      
      
      
      {/* 菜单项编辑 Modal */}
      <Modal
        title={editingMenuItem ? '编辑菜单项' : '添加菜单项'}
        visible={isMenuModalVisible}
        onOk={handleSaveMenuItem}
        onCancel={() => setIsMenuModalVisible(false)}
        okText="保存"
        cancelText="取消"
      >
        <Form form={form4} layout="vertical">
          <Form.Item
            name="itemkey"
            label="键"
            rules={[{ required: true, message: '请输入键名' }]}
          >
            <Input placeholder="例如: home, projects, deploy" />
          </Form.Item>

          <Form.Item
            name="text"
            label="显示文本"
            rules={[{ required: true, message: '请输入显示文本' }]}
          >
            <Input placeholder="例如: 首页, 项目, 部署" />
          </Form.Item>

          <Form.Item
            name="icon"
            label="图标"
            rules={[{ required: true, message: '请选择图标' }]}
          >
           <IconSelector />
          </Form.Item>

          <Form.Item
            name="link"
            label="链接"
            rules={[{ required: true, message: '请输入链接' }]}
          >
            <Input placeholder="例如: /home, /projects, https://external.com" />
          </Form.Item>

          <Form.Item
            name="isExternal"
            label="是否外部链接"
            valuePropName="checked"
          >
            <Select>
              <Option value={true}>是</Option>
              <Option value={false}>否</Option>
            </Select>
          </Form.Item>

          <Form.Item
            name="useplace"
            label="使用位置"
            valuePropName="checked"
             rules={[{ required: true, message: 'choose' }]}
          >
            <Select>
              <Option value="navigation">导航栏</Option>
              <Option value="list">列表栏</Option>
            </Select>
          </Form.Item>

          <Form.Item
            name="order"
            label="排序"
            rules={[{ required: true, message: '请输入排序数字' }]}
          >
            <Input type="number" placeholder="数字越小越靠前" />
          </Form.Item>
        </Form>
      </Modal>
    
    {/* 布局配置Modal */}
    <Modal
        title={editingLayout ? '编辑布局配置' : '添加布局配置'}
        visible={isLayoutModalVisible}
        onOk={handleSaveLayout}
        onCancel={() => setIsLayoutModalVisible(false)}
        width={800}
        okText="保存"
        cancelText="取消"
      >
        <Form form={layoutForm} layout="vertical">
          <Form.Item
            name="LayoutName"
            label="布局名称"
            rules={[{ required: true, message: '请输入布局名称' }]}
          >
            <Input placeholder="例如: 首页布局, 管理页布局" />
          </Form.Item>

          <Divider orientation="left">布局JSON配置</Divider>
          <Form.Item
            label="布局JSON"
            required
          >
            <TextArea
              rows={10}
              value={jsonEditorValue}
              onChange={(e) => setJsonEditorValue(e.target.value)}
              placeholder={`例如: {
                "header": true,
                "sidebar": true,
                "footer": false,
                "components": [...]
              }`}
            />
          </Form.Item>

          <Divider orientation="left">选项配置</Divider>
          <Form.Item
            name="OptionsJSON"
            label="选项JSON"
          >
            <TextArea
              rows={4}
              placeholder={`例如: {
              "theme": "dark",
              "collapsible": true
            }`}
            />
          </Form.Item>
        </Form>
      </Modal>


    </Card>
  );
};

export default AdminPage;