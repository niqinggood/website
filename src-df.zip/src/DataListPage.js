import React, { useState, useEffect } from 'react';
import {
  Box,  Typography,  Paper,  Table,  TableBody,  TableCell,TableContainer,DialogTitle,DialogContent,DialogContentText,DialogActions,
  TableHead,  TableRow,  Button,  IconButton,  Chip,  Avatar,  TextField,  InputAdornment,Tooltip,  Badge,  CircularProgress,  Divider,  Grid,  Link,Dialog} from '@mui/material';
import {
  ListAlt,
  ShoppingCart,
  AdminPanel,
  Settings,
  Dashboard,
  AdminPanelSettings,
  Search,
  Refresh,
  FileDownload,
  Edit,
  Delete,
  Visibility,
  DataObject,
  CalendarToday
} from '@mui/icons-material';
import { People,PersonAdd,Api,Webhook,VpnKey,Assessment,AutoFixHigh,Insights,AccountCircle,ExitToApp,Home,Group,Lock,Public,Storage,Code,Cloud,Security,Build,MenuBook, } from '@mui/icons-material';

//import { AccountCircle, Settings, ExitToApp, ShoppingCart,  ListAlt, DataObject,Insights ,AdminPanelSettings  , Dashboard } from '@mui/icons-material';

import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { format } from 'date-fns';

const DataListPage = () => {
  const [configurations, setConfigurations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedTab, setSelectedTab] = useState('all');
  const navigate = useNavigate();
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [configToDelete, setConfigToDelete] = useState(null);
  const [listItems, setListItems ] = useState([])

 useEffect(() => {
    const fetchMenuItems = async () => {
      try {
        const response = await axios.get('/api/menu-items');
        // 合并默认菜单项和后台返回的菜单项
        let  mergedItems = [  ...response.data];
        mergedItems = mergedItems.filter(item => item.useplace === "list");
        setListItems(mergedItems);
        console.info('mergedItems:',mergedItems)
      } catch (error) {
        console.error('获取菜单项失败，使用默认菜单:', error);
        // 如果获取失败，使用默认菜单
        setListItems([]);
      } finally {
        setLoading(false);
      }
    };

    fetchMenuItems();
    fetchConfigurations();
  }, []);
  // 解析配置数据

 // 判断是否应该使用外部链接
const shouldUseExternalLink = (url) => {
  return (
    url.startsWith('http://') ||
    url.startsWith('https://') ||
    url.startsWith('www.') ||
    url.startsWith('mailto:') ||
    url.startsWith('tel:')
  );  };

// 格式化外部URL
const formatExternalUrl = (url) => {
  if (url.startsWith('www.')) {
    return `https://${url}`;
  }
  return url;
};

const getIconComponent = (iconName) => {
  const icons = {
    'ListAlt': ListAlt,
    'ShoppingCart': ShoppingCart,
    'Insights': Insights,
    'AdminPanelSettings': AdminPanelSettings,
    'Dashboard': Dashboard,
    'AutoFixHigh':AutoFixHigh,
  'Group': Group,
  'Lock': Lock,
  'Public': Public,
  'Code': Code,
  'Storage': Storage,
  'Cloud': Cloud,
  'Security': Security,
  'Build': Build,
  'MenuBook': MenuBook,
  'Assessment': Assessment,
  // 系统管理
  'People': People,
  'PersonAdd': PersonAdd,
  'VpnKey': VpnKey,
  'Api': Api ,
  'Webhook': Webhook,


  };

  return icons[iconName] || ListAlt; // 默认返回ListAlt图标
};

  const parseConfigurations = (configs) => {

    // 检查 configs 是否为数组，如果不是则返回空数组
    if (!Array.isArray(configs)) {
        console.error('获取的配置数据不是数组类型:', configs);
        return [];
    }
    return configs.map(config => {
        try {
            let configData = config.configurations;
            if (typeof configData === 'string') {
                // 替换单引号为双引号
                console.info("configData:",configData )
                configData = configData.replace(/'/g, '"');
                // 处理 NaN
                configData = configData.replace(/"index": NaN/g, '"index": null');
                // 处理可能的多余逗号
                configData = configData.replace(/,\s*([}\]])/g, '$1');
                // 解析 JSON 字符串
                configData = JSON.parse(configData);
            }
            // 处理数组情况（API 可能返回数组或对象）
            const configArray = Array.isArray(configData) ? configData : [configData];

            return {
                ...config,
                configData: configArray[0] || {}, // 取第一个配置
                parsed: true
            };
        } catch (error) {
            console.error('解析配置失败:', error);
            console.log('待解析的字符串:', config.configurations);
            return {
                ...config,
                configData: {},
                parsed: false
            };
        }
    });
};


  const fetchConfigurations = async () => {
    setLoading(true);
    try {
      const response = await axios.get('/api/configurations');
      let data = response.data;
        // 检查数据是否为字符串，如果是则进行解析
      if (typeof data === 'string') {
            // 替换 NaN 为 null
            data = data.replace(/"index": NaN/g, '"index": null');
            try {
                data = JSON.parse(data);
            } catch (parseError) {
                console.error('解析 JSON 数据失败:', parseError);
                return;
            }
        }
      const parsedConfigs = parseConfigurations(data);
      setConfigurations(parsedConfigs);
    } catch (error) {
      console.error("获取配置列表失败:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteClick = (config) => {
    setConfigToDelete(config);
    setDeleteDialogOpen(true);
  };

  // 关闭对话框
  const handleCloseDeleteDialog = () => {
    setDeleteDialogOpen(false);
    setConfigToDelete(null);
  };

  // 确认删除
  const handleConfirmDelete = async () => {
    if (!configToDelete) return;

    try {
      await axios.delete(`/api/configurations/${configToDelete.configname}`);
      setConfigurations(configurations.filter(config => config.configname !== configToDelete.configname));
      handleCloseDeleteDialog();
    } catch (error) {
      console.error("删除配置失败:", error);
      handleCloseDeleteDialog();
    }
  };


  const handleDelete = async (id) => {
    try {
      await axios.delete(`/api/configurations/${id}`);
      setConfigurations(configurations.filter(config => config.id !== id));
    } catch (error) {
      console.error("删除配置失败:", error);
    }
  };

  const filteredConfigurations = configurations.filter(config => {
    const configName = config.configname || '';
    const description = config.description || '';
    const configType = config.configData?.type || '';

    const matchesSearch = configName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesTab = selectedTab === 'all' || configType === selectedTab;

    return matchesSearch && matchesTab;
  });

  const getStatusColor = (status) => {
    switch (status) {
      case 'succ': return 'success';
      case 'pending': return 'warning';
      case 'failed': return 'error';
      default: return 'default';
    }
  };

  const getLatestDataInfo = (config) => {
    if (!config.configData?.fetchResults || config.configData.fetchResults.length === 0) {
      return { text: '无数据', color: 'default' };
    }

    const latestResult = config.recentTask;
    return {
      text: latestResult.statusDetails, //success ? '数据就绪' : '取数失败',
      color: latestResult.status        //==="success" ? 'success' : 'error'
    };
  };

  // 获取所有配置类型（去重）
  const getAllConfigTypes = () => {
    const types = new Set();
    configurations.forEach(config => {
      if (config.configData?.type) {
        types.add(config.configData.type);
      }
    });
    return Array.from(types);
  };

  return (
    <Box sx={{ p: 2 }}>
      <Typography variant="h4" gutterBottom sx={{ mb: 3, fontWeight: 600 }}>
        数据配置列表
      </Typography>

      <Paper sx={{ p: 3, mb: 3, borderRadius: '12px' }}>
        <Grid container spacing={2} alignItems="center">
          <Grid item xs={12} md={6}>
            <TextField
              fullWidth
              placeholder="搜索配置..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <Search />
                  </InputAdornment>
                ),
              }}
            />
          </Grid>
          <Grid item xs={6} md={3}>
            <Button
              fullWidth
              variant="outlined"
              startIcon={<Refresh />}
              onClick={fetchConfigurations}
            >
              刷新
            </Button>
          </Grid>
          <Grid item xs={6} md={3}>
            <Button
              fullWidth
              variant="contained"
              startIcon={<DataObject />}
              onClick={() => navigate('/config')}
            >
              新建配置
            </Button>
          </Grid>
        </Grid>
      </Paper>

      <Paper sx={{ p: 2, mb: 2, borderRadius: '12px' }}>
        <Box sx={{ display: 'flex', overflowX: 'auto', py: 1 }}>
          <Chip
            label="全部"
            variant={selectedTab === 'all' ? 'filled' : 'outlined'}
            color={selectedTab === 'all' ? 'primary' : 'default'}
            onClick={() => setSelectedTab('all')}
            sx={{ mx: 0.5 }}
          />
          {getAllConfigTypes().map(type => (
            <Chip
              key={type}
              label={type}
              variant={selectedTab === type ? 'filled' : 'outlined'}
              color={selectedTab === type ? 'primary' : 'default'}
              onClick={() => setSelectedTab(type)}
              sx={{ mx: 0.5 }}
            />
          ))}
        </Box>
      </Paper>

      {loading ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', mt: 4 }}>
          <CircularProgress />
        </Box>
      ) : filteredConfigurations.length === 0 ? (
        <Paper sx={{ p: 4, textAlign: 'center', borderRadius: '12px' }}>
          <Typography variant="h6" color="textSecondary">
            没有找到匹配的配置
          </Typography>
          <Button
            variant="contained"
            sx={{ mt: 2 }}
            onClick={() => navigate('/config')}
          >
            创建新配置
          </Button>
        </Paper>
      ) : (
        <TableContainer component={Paper} sx={{ borderRadius: '12px' }}>
          <Table>
            <TableHead>
              <TableRow sx={{ backgroundColor: 'action.hover' }}>
                <TableCell sx={{ fontWeight: 600 }}>配置名称</TableCell>
                <TableCell sx={{ fontWeight: 600 }}>所用界面模板</TableCell>
                <TableCell sx={{ fontWeight: 600 }}>状态</TableCell>
                <TableCell sx={{ fontWeight: 600 }}>数据文件</TableCell>
                <TableCell sx={{ fontWeight: 600 }}>创建时间</TableCell>
                <TableCell sx={{ fontWeight: 600 }}>修改者</TableCell>
                <TableCell sx={{ fontWeight: 600 }}>操作</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {filteredConfigurations.map((config) => {
                const dataInfo    = getLatestDataInfo(config);
                const configData  = config.recentTask || {};

                return (
                  <TableRow key={config.id} hover>
                    <TableCell>
                      <Box sx={{ display: 'flex', alignItems: 'center' }}>
                        <Avatar
                          sx={{
                            bgcolor: 'primary.main',
                            color: 'white',
                            width: 32,
                            height: 32,
                            mr: 2,
                            fontSize: '0.875rem'
                          }}
                        >
                          {(config.configname || '').charAt(0).toUpperCase()}
                        </Avatar>
                        <Box>
                          <Typography sx={{ fontWeight: 500 }}>{config.configname}</Typography>
                          <Typography variant="body2" color="textSecondary">
                            {config.description || '无描述'}
                          </Typography>
                        </Box>
                      </Box>
                    </TableCell>
                    <TableCell>
                      <Chip
                        label={config.layoutconfig?.appTitle || '未知'}
                        size="small"
                        variant="outlined"
                      />
                    </TableCell>
                    <TableCell>
                      <Chip
                        label={config.recentTask.status } //=== 'active' ? '活跃' : '禁用'
                        color={getStatusColor(config.recentTask.status)}
                        size="small"
                      />
                    </TableCell>
                    <TableCell>
                      {config.recentTask.downloadInfo && (
                        <Box display="flex" flexWrap="wrap" gap={1}>
                          {(() => {
                            try {
                              const infoObj = JSON.parse(config.recentTask.downloadInfo);
                              return Object.entries(infoObj).map(([key, filePath]) => {
                                const fileName = filePath.split('\\').pop() || key;
                                const baseURL = axios.defaults.baseURL || '';

                                // 检查是否需要添加baseURL
                                const shouldPrependBaseURL = !filePath.startsWith('http') &&
                                                            !filePath.startsWith('s3://') &&
                                                            baseURL;
                                //  !filePath.startsWith('/') &&
                                // 生成最终下载URL
                                let downloadURL = filePath;
                                if (shouldPrependBaseURL) {
                                  // 确保baseURL以斜杠结尾
                                  const adjustedBaseURL = baseURL.endsWith('/') ? baseURL : baseURL + '/';
                                  downloadURL = adjustedBaseURL + filePath;
                                }

                                return (
                                  <a
                                    key={key}
                                    href={downloadURL}
                                    download={fileName}
                                    style={{ textDecoration: 'none' }}
                                  >
                                    <Chip
                                      label={fileName}
                                      size="small"
                                      variant="outlined"
                                      color="primary"
                                      component="span"
                                    />
                                  </a>
                                );
                              });
                            } catch (error) {
                              return (
                                <Chip
                                  label={config.recentTask.downloadInfo}
                                  size="small"
                                  variant="outlined"
                                  color="error"
                                />
                              );
                            }
                          })()}
                        </Box>
                      )}
                    </TableCell>

                    <TableCell>
                      <Box sx={{ display: 'flex', alignItems: 'center' }}>
                        <CalendarToday
                          fontSize="small"
                          color="action"
                          sx={{ mr: 1 }}
                        />
                        {format(new Date(config.savedat), 'yyyy-MM-dd HH:mm')}
                      </Box>
                    </TableCell>
                    <TableCell>
                      <Chip
                        label={config.modifier || '未知'}
                        size="small"
                        variant="outlined"
                      />
                    </TableCell>
                    <TableCell>
                      <Box sx={{ display: 'flex' }}>

                         <Tooltip title="删除配置">
                          <IconButton
                            onClick={() => handleDeleteClick(config)}
                            size="small"
                            color="error"
                          >
                            <Delete />
                          </IconButton>
                        </Tooltip>
                        <Tooltip title="编辑配置">
                          <IconButton
                            onClick={() => navigate(`/config?edit=${config.configname}`)}
                            size="small"
                            color="secondary"
                          >
                            <Edit />
                          </IconButton>
                        </Tooltip>

                        <Tooltip title="BI分析">
                          <IconButton
                            onClick={() => navigate(`/analysis/${config.configname}`)}
                            size="small"
                            color="primary"
                          >
                            <Insights />
                          </IconButton>
                        </Tooltip>
                        {listItems.map((item) => {
                          console.info( "item*****::**:",item )
                          const IconComponent = getIconComponent(item.icon);
                          // 判断是否是外部链接
                          const isExternalLink = shouldUseExternalLink(item.link);
                          // 格式化外部链接（如果是 www. 开头，补全 https://）
                          const formattedUrl = isExternalLink ? formatExternalUrl(item.link) : item.link;

                          return (
                            <Tooltip key={item.id || item.configname} title={item.name || "快捷操作"}>
                              <IconButton
                                onClick={() => {
                                  if (isExternalLink) {
                                    // 外部链接：新窗口打开
                                    window.open(formattedUrl, "_blank");
                                  } else {
                                    // 内部路由：使用 navigate 跳转
                                    navigate(`/modeling/${item.configname}`);
                                  }
                                }}
                                size="small"
                                color="info"
                              >
                               {IconComponent && <IconComponent  />}
                              </IconButton>
                            </Tooltip>
                          );
                        })}
                        {configData.fetchResults?.length > 0 && (
                          <Tooltip title="下载最新数据">
                            <IconButton
                              onClick={() => window.open(configData.fetchResults[configData.fetchResults.length - 1].url, '_blank')}
                              size="small"
                              color="success"
                            >
                              <FileDownload />
                            </IconButton>
                          </Tooltip>
                        )}
                         <Dialog
                            open={deleteDialogOpen}
                            onClose={handleCloseDeleteDialog}
                            aria-labelledby="alert-dialog-title"
                            aria-describedby="alert-dialog-description"
                          >
                            <DialogTitle id="alert-dialog-title">
                              确认删除配置
                            </DialogTitle>
                            <DialogContent>
                              <DialogContentText id="alert-dialog-description">
                                您确定要删除配置 <strong>{configToDelete?.configname}</strong> 吗？
                                <br />
                                此操作将会在后台删除您名下的所有相关数据，且不可恢复。
                              </DialogContentText>
                            </DialogContent>
                            <DialogActions>
                              <Button onClick={handleCloseDeleteDialog} color="primary">
                                取消
                              </Button>
                              <Button
                                onClick={handleConfirmDelete}
                                color="error"
                                autoFocus
                              >
                                确认删除
                              </Button>
                            </DialogActions>
                          </Dialog>

                      </Box>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </TableContainer>
      )}
    </Box>
  );
};
export default DataListPage;