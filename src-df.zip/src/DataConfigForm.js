import React, { useState, useEffect,useRef,useCallback } from 'react';
import { DeleteForever } from '@mui/icons-material';
import {  Box, Typography, TextField, Button, Grid, Paper, Divider,  Tabs, Tab, Select, MenuItem, FormControl, InputLabel,
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow,  IconButton, Snackbar, Alert, Dialog, DialogTitle, DialogContent,
  DialogActions, Chip, Collapse, Tooltip, CircularProgress,Checkbox,ListItemText,  Avatar, Badge, useTheme, styled} from '@mui/material';
import { Edit,AddCircle, Delete, Save, PlayArrow, Close,Visibility, ExpandMore, ExpandLess, CalendarToday,CheckCircle, Error, Info, Warning, HelpOutline,ArrowUpward,ArrowDownward } from '@mui/icons-material';
import DataFetch from './DataFetch';
import { debounce } from 'lodash';
// 导入 Link 组件（来自 @mui/material）
import Link from '@mui/material/Link';
// 导入 Download 图标（来自 @mui/icons-material）
import Download from '@mui/icons-material/Download';
import CloseIcon from '@mui/icons-material/Close';
import ErrorOutlineIcon from '@mui/icons-material/ErrorOutline';
import CheckCircleOutlineIcon from '@mui/icons-material/CheckCircleOutline';
import DownloadIcon from '@mui/icons-material/Download';
import RefreshIcon  from '@mui/icons-material/Refresh';

import axios from 'axios';
import { format, parseISO } from 'date-fns';
import History from '@mui/icons-material/History';
const debouncedChangeHandler = debounce((handler, fieldName, value) => {
  handler(fieldName, value);
}, 100); // 300ms延迟


function getCookie(name) { const value = `; ${document.cookie}`; const parts = value.split(`; ${name}=`); if (parts.length === 2) return parts.pop().split(';').shift(); return null; }

// ================ 样式组件 ================
const StyledPaper = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(3),
  marginBottom: theme.spacing(3),
  borderRadius: '12px',
  boxShadow: '0px 4px 20px rgba(0, 0, 0, 0.08)',
  transition: 'box-shadow 0.3s ease',
  '&:hover': {
    boxShadow: '0px 6px 24px rgba(0, 0, 0, 0.12)'
  }
}));

const SectionHeader = styled(Box)(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  cursor: 'pointer',
  padding: theme.spacing(1, 0),
  '&:hover': {
    backgroundColor: theme.palette.action.hover,
    borderRadius: '4px'
  }
}));

const ConfigTableRow = styled(TableRow)(({ theme }) => ({
  '&:nth-of-type(odd)': {
    backgroundColor: theme.palette.action.hover
  },
  '&:hover': {
    backgroundColor: theme.palette.action.selected
  },
  '& .MuiTableCell-root': {
    borderBottom: 'none'
  }
}));



const StatusChip = styled(Chip)(({ theme, status }) => {
  const statusColors = {
    active: theme.palette.success.main,
    pending: theme.palette.warning.main,
    error: theme.palette.error.main,
    inactive: theme.palette.text.disabled
  };
  return {
    backgroundColor: statusColors[status] || theme.palette.grey[300],
    color: theme.palette.getContrastText(statusColors[status] || theme.palette.grey[300]),
    fontWeight: 500,
    fontSize: '0.75rem'
  };
});

// ================ 主组件 ================
const DataConfigForm = () => {

  const fieldSelectionsRef = useRef({});
  const [showHistory, setShowHistory] = useState(false);
  const [templateDialogOpen, setTemplateDialogOpen] = useState(false);
  const [templates, setTemplates] = useState([]);
  const [selectedTemplate, setSelectedTemplate] = useState(null);
  const [loadingTemplates, setLoadingTemplates] = useState(false);
  const [loadingHistory,setLoadingHistory]  = useState(false);
  const [editingConfig, setEditingConfig] = useState(null);
  const [notification, setNotification] = useState({  open: false,type: '',  title: '',  message: '',  details: [] });
  const [historyDialogOpen, setHistoryDialogOpen] = useState(false);
  // 高亮通知函数
  const showHighlightedNotification = (type, title, message, details = []) => {
   setNotification({     open: true,     type,    title,    message,     details   });
  };

  const theme = useTheme();
  const initialConfigState = {
  name: '',
  description: '',
  timeRange: 'single',
  dates: {
    startDate: format(new Date(),       'yyyy-MM-dd'),
    endDate: format(new Date(),         'yyyy-MM-dd'),
    trainStartDate: format(new Date(),  'yyyy-MM-dd'),
    trainEndDate: format(new Date(),    'yyyy-MM-dd'),
    evalStartDate: format(new Date(),   'yyyy-MM-dd'),
    evalEndDate: format(new Date(),     'yyyy-MM-dd')
  },
  type: '',                         // 当前选中的tab类型
  globalDependencies: {},
  tabDependencies: {},
  fields: {}
};
 const [configurations, setConfigurations] = useState([]);
 const [activeConfig, setActiveConfig] = useState(null);  // 当前正在编辑的配置

  // ================ 状态管理 ================
  const [config, setConfig] = useState(null);             //config 是layout 配置页
  const [activeTab, setActiveTab] = useState('');
  const [fetchResults, setFetchResults] = useState([]);   // 存储所有取数结果

  const [selections, setSelections] = useState({
    global: {},
//    tabDepends: {},
//    fields: {},
    tabs:{}
  });
  const [options, setOptions] = useState({
    global: {},
    tabDepends: {},
    fields: {}
  });

//  const [notification, setNotification] = useState({
//    open: false,
//    message: '',
//    severity: 'success'
//  });
  const [detailConfig, setDetailConfig] = useState(null);
  const [loading, setLoading] = useState({
    global: false,
    tab: false,
    fields: false,
    saving: false,
    fetching: false,
    options: {} // 记录每个选项的加载状态
  });
  const [expandedSections, setExpandedSections] = useState({
    global: true,
    tabDepends: true,
    fields: true
  });
  const [openSelects, setOpenSelects] = useState({}); // 记录哪些下拉菜单是打开的

  // 新增状态
  const [configName, setConfigName] = useState('');       // layout web config
  const [timeRange, setTimeRange] = useState('single');   //
  const [dates, setDates] = useState({
    startDate: format(new Date(), 'yyyy-MM-dd'),        endDate: format(new Date(),      'yyyy-MM-dd'),
    trainStartDate: format(new Date(), 'yyyy-MM-dd'),   trainEndDate: format(new Date(), 'yyyy-MM-dd'),
    evalStartDate: format(new Date(), 'yyyy-MM-dd'),    evalEndDate: format(new Date(),  'yyyy-MM-dd')
  });
  const [configDescription, setConfigDescription] = useState('');

    const [configNameError, setConfigNameError] = useState(null);
    const [checkingName, setCheckingName] = useState(false);

    // 防抖函数
    const debounce = (func, delay) => {
      let timer;
      return (...args) => {
        clearTimeout(timer);
        timer = setTimeout(() => func(...args), delay);
      };
    };
  // 检查名称是否存在的API调用
  const checkConfigName = async (name) => {
      try {
        const response = await axios.get(`/api/check-configname?name=${encodeURIComponent(name)}`);
        return response.data.exists;
      } catch (error) {
        console.error("检查配置名称失败:", error);
        return false;
      }
    };

    // 防抖后的校验函数
    const debouncedCheckName = debounce(async (name) => {
      if (!name) return;

      setCheckingName(true);
      const exists = await checkConfigName(name);
      setCheckingName(false);

      if (exists) {
        setConfigNameError("该名称已存在，请使用其他名称");
      } else {
        setConfigNameError(null);
      }
    }, 500);

  // 处理名称变化
    const handleNameChange = (e) => {
      const newName = e.target.value;
      setConfigName(newName);
      debouncedCheckName(newName);
    };


  // ================ 工具函数 ================
  const handleDateChange = (e) => {
    const { name, value } = e.target;
    setDates(prev => ({ ...prev, [name]: value }));
  };

  const formatDateTime = (dateString) => {
    return format(parseISO(dateString), 'yyyy-MM-dd HH:mm:ss');
  };

  const showNotification = (message, severity = 'success') => {
    setNotification({ open: true, message, severity });
  };

  const handleCloseNotification = () => {
    setNotification(prev => ({ ...prev, open: false }));
  };

  function safeJsonParse(data) {
  // 如果是对象且不是null，直接返回
  if (typeof data === 'object' && data !== null) {
    return data;
  }

  // 如果不是字符串，返回空对象
  if (typeof data !== 'string') {
    return {};
  }

  try {
    // 预处理字符串
    let parsedString = data
      .replace(/'/g, '"')               // 替换单引号为双引号
      .replace(/"index": NaN/g, '"index": null')  // 处理NaN
      .replace(/,\s*([}\]])/g, '$1');   // 处理多余逗号

    // 尝试解析
    return JSON.parse(parsedString);
  } catch (error) {
    console.error('JSON 解析失败:', error);
    return {};
  }
}

  const loadTemplates = async () => {
      setLoadingTemplates(true);
      try {
        const response = await axios.get('/api/templates');
        setTemplates(response.data);
      } catch (error) {
        showNotification('加载模板列表失败', 'error');
        console.error("加载模板失败:", error);
      } finally {
        setLoadingTemplates(false);
      }
  };

  const loadTemplate = async (templateName) => {
      try {
        const layoutResponse = await axios.get(`/api/fetchweb_layout_config?template=${templateName}`);
        let configData = layoutResponse.data;
        if (typeof configData === 'string') {
          try {
            configData = JSON.parse(configData);
          } catch (parseError) {
            console.error("JSON解析失败:", parseError);
            showNotification('模板格式错误', 'error');
            return;
          }
        }
        setConfig(configData);
        const defaultTab = configData.tabs && configData.tabs.length > 0 ? configData.tabs[0].value : '';
        setActiveTab(defaultTab);
        showNotification(`模板 "${templateName}" 加载成功`);
      } catch (error) {
        showNotification('模板加载失败', 'error');
        console.error("加载模板失败:", error);
      }
  };

  const renderTemplateDialog = () => {
     console.log("renderTemplateDialog 被调用^^^^^^^^^^^^^^^^^^^^^"); // 调试日志
     return(
      <Dialog
        open={templateDialogOpen}
        onClose={() => setTemplateDialogOpen(false)}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle>选择配置模板</DialogTitle>
        <DialogContent>
          {loadingTemplates ? (
            <Box sx={{ display: 'flex', justifyContent: 'center', p: 4 }}>
              <CircularProgress />
            </Box>
          ) : (
            <TableContainer>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell>模板名称</TableCell>
                    <TableCell>描述</TableCell>
                    <TableCell>操作</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {templates.map(template => (
                    <TableRow key={template.name}>
                      <TableCell>{template.name}</TableCell>
                      <TableCell>{template.description || '无描述'}</TableCell>
                      <TableCell>
                        <Button
                          variant="outlined"
                          onClick={() => {
                            setSelectedTemplate(template.name);
                            setTemplateDialogOpen(false);
                            loadTemplate(template.name);
                          }}
                        >
                          选择
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setTemplateDialogOpen(false)}>取消</Button>
        </DialogActions>
      </Dialog>
  )};

  // 添加 useEffect 来监听依赖变化后的状态恢复
useEffect(() => {
  // 当tab依赖或全局依赖变化时，恢复不依赖的字段状态
  const currentTabConfig = config.tabs.find(tab => tab.value === activeTab) || {};

  if (currentTabConfig.fields) {
    const savedFields = fieldSelectionsRef.current[activeTab] || {};
    const currentFields = selections.tabs?.[activeTab]?.fields || {};

    // 找出需要恢复的字段（不依赖已改变字段的字段）
    const fieldsToRestore = {};
    let needsRestore = false;

    currentTabConfig.fields.forEach(field => {
      const dependsOnChanged = field.depends_on?.some(dep => {
        // 检查这个字段是否依赖于最近改变的依赖
        const globalChanged = selections.global[dep] !== fieldSelectionsRef.current.lastGlobal?.[dep];
        const tabDependsChanged = selections.tabs?.[activeTab]?.tabDepends?.[dep] !== fieldSelectionsRef.current.lastTabDepends?.[dep];
        return globalChanged || tabDependsChanged;
      });

      if (!dependsOnChanged && savedFields[field.name] !== undefined && !currentFields[field.name]) {
        fieldsToRestore[field.name] = savedFields[field.name];
        needsRestore = true;
      }
    });

    if (needsRestore) {
      console.log('恢复字段状态:', fieldsToRestore);
      setSelections(prev => ({
        ...prev,
        tabs: {
          ...prev.tabs,
          [activeTab]: {
            ...prev.tabs[activeTab],
            fields: {
              ...prev.tabs[activeTab]?.fields,
              ...fieldsToRestore
            }
          }
        }
      }));
    }

    // 更新最后一次的依赖状态
    fieldSelectionsRef.current.lastGlobal = { ...selections.global };
    fieldSelectionsRef.current.lastTabDepends = { ...selections.tabs?.[activeTab]?.tabDepends };
  }
}, [selections.global, selections.tabs?.[activeTab]?.tabDepends, activeTab, config]);

   useEffect(() => {
      const loadConfig = async () => {
        try {

          const params = new URLSearchParams(window.location.search);
          const editId = params.get('edit');
          console.info("editId********",editId)

          if (editId) {
            let layoutResponse = await axios.get('/api/fetchweb_layout_config_list');
            console.info("In dataconfigform useEffect")
            //loadTemplate()
            setTemplateDialogOpen(false); // 弹出选择对话框
          }
          else{
            const listResponse = await axios.get('/api/fetchweb_layout_config_list');
            console.info("listResponse:::",listResponse )
            setTemplates(listResponse.data);
            setTemplateDialogOpen(true); // 弹出选择对话框
            console.log("templateDialogOpen 应变为 true");
          }
          if (editId) {
            console.info("editId",editId)
            const savedResponse = await axios.get('/api/configurations');
            const configToEdit = savedResponse.data.find(c => c.configname === editId);
            console.info("configToEdit:####",typeof configToEdit,configToEdit )

           if (configToEdit ) {

              setConfig( configToEdit.Layoutconfig );
              console.info("has use setConfig base on editId")
              let configData;
                  try {
                    configData = safeJsonParse(configToEdit);

                    const selectionsData   = safeJsonParse(configToEdit.selections || '{}');
                    const layoutConfigData = safeJsonParse(configToEdit.layoutconfig || '{}');
                    const tmp_date         = safeJsonParse(configToEdit.dates || {} )
                    const configurations_table = safeJsonParse(configToEdit.detail || [] )
                    setConfigName( configData.configname );
                    setTimeRange(  configData.timerange  );
                    setDates({
                        startDate:      tmp_date.startDate || format(new Date(), 'yyyy-MM-dd'),
                        endDate:        tmp_date.endDate || format(new Date(), 'yyyy-MM-dd'),
                        trainStartDate: tmp_date.dates?.trainStartDate || format(new Date(), 'yyyy-MM-dd'),
                        trainEndDate:   tmp_date.dates?.trainEndDate || format(new Date(), 'yyyy-MM-dd'),
                        evalStartDate:  tmp_date.dates?.evalStartDate || format(new Date(), 'yyyy-MM-dd'),
                        evalEndDate:    tmp_date.evalEndDate || format(new Date(), 'yyyy-MM-dd')
                      });
                    setSelections({
                        global: selectionsData.global || {},
                        tabDepends: selectionsData.tabDepends || {},
                        fields: selectionsData.fields || {}
                      });

                    setConfig(prev => ({
                        ...prev,
                        ...layoutConfigData
                      }));
                    setConfigurations( configurations_table  )

                  } catch (error) {
                    console.error("配置解析错误:", error);
                    showNotification("配置数据格式错误", "error");
                  }

            }
          } else {
            setConfigurations([]);
          }
        } catch (error) {
          showNotification('配置加载失败', 'error');
          console.error("加载配置失败:", error);
        }
      };
      loadConfig();
    }, []);

    // 添加状态监听
    useEffect(() => {
      console.log("templateDialogOpen 当前值:", templateDialogOpen);
    }, [templateDialogOpen]);

    //loadDependentOptions( configData );
    useEffect(() => {
      if (config) {
        const params = new URLSearchParams(window.location.search);
        const editId = params.get('edit');
        if (editId) {
          loadDependentOptions(selections);
        }
      }
    }, [config, selections]); // 当config或selections变化时触发

    // 加载依赖选项  selections.global
    const loadDependentOptions = async (selections) => {
      console.info("selections", selections);
      for (const [field, value] of Object.entries(selections.global || {})) {
        const fieldDef = config.global_depends?.find(d => d.name === field);
        if (fieldDef) {
          await loadOptions(fieldDef, 'global', {
            global: selections.global || {},
            tabs: selections.tabs || {}
          });
        }
      }
    };

  // 处理下拉菜单打开事件
  const handleSelectOpen = (field, level) => {
    const fieldKey = `${level}_${field.name}`;
    setOpenSelects(prev => ({ ...prev, [fieldKey]: true }));
    // 如果选项为空或需要刷新，则加载选项
    if (!options[level][field.name] || options[level][field.name].length === 0) {
      loadOptions(field, level);
    }
  };

  // 处理下拉菜单关闭事件
  const handleSelectClose = (field, level) => {
    const fieldKey = `${level}_${field.name}`;
    setOpenSelects(prev => ({ ...prev, [fieldKey]: false }));
  };

  // ================ 事件处理 ================
  const handleGlobalChange = (fieldName, value) => {
      console.info("in handleGlobalChange fieldName:", fieldName, "value:", value);

        // 确保当前activeTab的状态存在
      setSelections(prev => {
        const newSelections = {
          ...prev,
          global: { ...prev.global, [fieldName]: value },
          tabs: {
            ...prev.tabs,
            [activeTab]: prev.tabs[activeTab] || { tabDepends: {}, fields: {} }
          }
      };

      // 找出所有依赖此字段的后续字段并重新加载
      reloadDependentFields(fieldName, 'global', newSelections);
      return newSelections;
      });
  };

  const handleTabDependChange = (fieldName, value) => {
      setSelections(prev => {

        const currentTabSelections = prev.tabs?.[activeTab] || { tabDepends: {}, fields: {} };

        // 保存当前字段状态到ref
        fieldSelectionsRef.current = {
          ...fieldSelectionsRef.current,
          [activeTab]: currentTabSelections.fields
        };

        const newSelections = {
          ...prev,
          tabs: {
            ...prev.tabs,
            [activeTab]: {
              ...(prev.tabs[activeTab] || { tabDepends: {}, fields: {} }),
              tabDepends: {
                ...(prev.tabs[activeTab]?.tabDepends || {}),
                [fieldName]: value
              },
               // 重置字段选择 fields: {}
            }
          }
        };

        reloadDependentFields(fieldName, 'tabDepends', newSelections);
        return newSelections;
      });
    };


    const reloadDependentFields = (changedField, level, currentSelections) => {
      console.info(`changedField "${changedField}" "${level}"`, currentSelections);
      // 确保 currentSelections 有值
       const effectiveSelections = {
        global: currentSelections?.global || {},
        tabs: {
          ...currentSelections?.tabs,
          [activeTab]: currentSelections?.tabs?.[activeTab] || { tabDepends: {}, fields: {} }
        }
      };
      config.global_depends?.forEach(field => {
        if (field.depends_on?.includes(changedField)) {
          loadOptions(field, 'global', effectiveSelections);
        }
      });
      const currentTabConfig = config.tabs.find(tab => tab.value === activeTab) || {};

      currentTabConfig.depends?.forEach(field => {
        if (field.depends_on?.includes(changedField)) {
          // 只清空依赖这个changedField的字段
          setSelections(prev => ({
            ...prev,
            tabs: {
              ...prev.tabs,
              [activeTab]: {
                ...prev.tabs[activeTab],
                fields: {
                  ...prev.tabs[activeTab]?.fields,
                  [field.name]: field.input_type === 'multi-select' ? [] : '' // 根据类型清空
                }
              }
            }
          }));

          // 重新加载这个字段的选项
          loadOptions(field, 'fields', {
            ...effectiveSelections,
            fields: effectiveSelections.tabs?.[activeTab]?.fields || {}
          });
        }
      });

      currentTabConfig.fields?.forEach(field => {
        if (field.depends_on?.includes(changedField)) {
          loadOptions(field, 'fields', {
            ...effectiveSelections,
            fields: effectiveSelections.tabs?.[activeTab]?.fields || {}
          });
        }
      });
    };
  const handleTabChange = (e, newValue) => {
      setActiveTab(newValue);

      // 确保新tab有初始化的状态
      setSelections(prev => {
        const newTabs = { ...prev.tabs };
        if (!newTabs[newValue]) {
          newTabs[newValue] = { tabDepends: {}, fields: {} };
        }
        return { ...prev, tabs: newTabs };
      });

      // 加载新tab的依赖选项
      if (config && config.tabs) {
        const newTabConfig = config.tabs.find(tab => tab.value === newValue);
        if (newTabConfig) {
          // 初始化加载新tab的依赖选项
          newTabConfig.depends?.forEach(field => {
            loadOptions(field, 'tabDepends', {
              global: selections.global,
              tabs: {
                [newValue]: {
                  tabDepends: {},
                  fields: {}
                }
              }
            });
          });
        }
      }
  };
  const handleFieldChange = (fieldName, value) => {
      setSelections(prev => ({
        ...prev,
        tabs: {
          ...prev.tabs,
          [activeTab]: {
            ...prev.tabs[activeTab],
            fields: {
              ...(prev.tabs[activeTab]?.fields || {}),
              [fieldName]: value
            }
          }
        }
      }));
  };
  // 4. 创建历史记录表格组件
const HistoryTable = ({ configName }) => {
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(false);
  const [openDeleteDialog, setOpenDeleteDialog] = useState(false); // 删除确认对话框
  const [deleteTaskId, setDeleteTaskId] = useState(''); // 待删除的任务ID
  const [openClearDialog, setOpenClearDialog] = useState(false); // 清空确认对话框
  const [snackbarOpen, setSnackbarOpen] = useState(false); // 操作结果提示
  const [snackbarMessage, setSnackbarMessage] = useState('');
  // ----------------------
  const handleDeleteTask = (taskId) => {
    setDeleteTaskId(taskId);
    setOpenDeleteDialog(true);
  };

  const confirmDeleteTask = async () => {
    try {
      setLoading(true);
      const response = await axios.delete(`/api/fetch-history/${deleteTaskId}`); // 调用删除单个任务接口
      if (response.data.success) {
        setSnackbarMessage('任务删除成功');
        setSnackbarOpen(true);
        // 刷新列表
        fetchHistory();
      } else {
        setSnackbarMessage(`删除失败：${response.data.error}`);
        setSnackbarOpen(true);
      }
    } catch (error) {
      console.error('删除任务失败:', error);
      setSnackbarMessage('删除任务时发生网络错误');
      setSnackbarOpen(true);
    } finally {
      setOpenDeleteDialog(false);
      setLoading(false);
    }
  };

      // ----------------------
      // 清空所有任务
      // ----------------------
      const handleClearHistory = () => {
        setOpenClearDialog(true);
      };

      const confirmClearHistory = async () => {
        try {
          setLoading(true);
          // 调用清空接口（按configName删除所有任务）
          const response = await axios.delete('/api/fetch-history', {
            params: { configName } // 传递配置名称
          });
          if (response.data.success) {
            setSnackbarMessage('历史记录已全部清空');
            setSnackbarOpen(true);
            // 刷新列表
            fetchHistory();
          } else {
            setSnackbarMessage(`清空失败：${response.data.error}`);
            setSnackbarOpen(true);
          }
        } catch (error) {
          console.error('清空历史记录失败:', error);
          setSnackbarMessage('清空历史记录时发生网络错误');
          setSnackbarOpen(true);
        } finally {
          setOpenClearDialog(false);
          setLoading(false);
        }
      };

  // 加载历史数据
  const fetchHistory =  useCallback( async () => {
    if (!configName) return; // 检查是否有效
    setLoading(true);
    try {
      // 拼接参数到 URL
      const response = await axios.get('/api/fetch-history', {
        params: { configName } // 传递参数
      });

      if (response.data.success) {
        setHistory(response.data.tasks);
      } else {
        console.error("获取历史记录失败:", response.data.error);
        // 可选：显示错误提示
        // showNotification(response.data.error, 'error');
      }
    } catch (error) {
      console.error("axios 请求失败:", error);
      // 处理网络错误（如超时、连接失败等）
      if (error.response) {
        console.error("响应错误:", error.response.data);
      } else {
        console.error("请求失败:", error.message);
      }
    } finally {
      setLoading(false);
    }
  },[configName]);


  useEffect(() => {
      if (!configName) return;

      const timer = setTimeout(() => {
        fetchHistory();
      }, 500); // 500ms 防抖

      return () => clearTimeout(timer); // 清除旧的定时器
    }, [configName, fetchHistory]);

  // 刷新历史记录
  const handleRefresh = () => {
    fetchHistory();
  };

  return (
    <Box sx={{ width: '100%', py: 3 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
        <Button
          variant="outlined"
          startIcon={<DeleteForever />}
          onClick={handleClearHistory}
          color="error"
          sx={{ mr: 2 }}
        >
          清空所有记录
        </Button>
        <Typography variant="h6" sx={{ fontWeight: 500 }}>
          数据取数历史记录
        </Typography>
        <Tooltip title="刷新记录">
          <IconButton onClick={handleRefresh} color="primary">
            <RefreshIcon />
          </IconButton>
        </Tooltip>
      </Box>

      {loading ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
          <CircularProgress />
        </Box>
      ) : history.length === 0 ? (
        <Typography variant="body1" sx={{ py: 3, textAlign: 'center' }}>
          暂无取数历史
        </Typography>
      ) : (
        <TableContainer component={Paper} sx={{ maxHeight: 600 }}>
          <Table stickyHeader>
            <TableHead>
              <TableRow>
                <TableCell width="18%">取数时间</TableCell>
                <TableCell width="12%">项目名称</TableCell>
                <TableCell width="10%">状态</TableCell>
                <TableCell width="25%">运行detail</TableCell>
                <TableCell width="25%">download</TableCell>
                <TableCell width="35%">操作</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {history.map((task) => (
                <TableRow key={task.id} hover>
                  <TableCell>
                    {new Date(task.triggeredAt).toLocaleString()}
                    {task.completedAt && (
                      <Typography variant="body2" color="text.secondary">
                        完成: {new Date(task.completedAt).toLocaleTimeString()}
                      </Typography>
                    )}
                  </TableCell>
                  <TableCell>{task.configname}</TableCell>
                  <TableCell>
                    <Typography color={statusColors[task.status]}>
                      {statusTexts[task.status] || task.status}
                    </Typography>
                  </TableCell>
                  <TableCell>
                    <Typography variant="body2">{task.statusDetails}</Typography>
                    {task.status === 'failed' && (
                      <Typography variant="body2" color="error">
                        原因: {task.statusDetails}
                      </Typography>
                    )}
                  </TableCell>

                  <TableCell>
                      { task.downloadInfo && (
                        <Box display="flex" flexWrap="wrap" gap={1}>
                          {(() => {
                            try {
                              const infoObj = JSON.parse(task.downloadInfo);
                              return Object.entries(infoObj).map(([key, filePath]) => {
                                const fileName = filePath.split('\\').pop() || key;
                                const baseURL = axios.defaults.baseURL || '';

                                // 检查是否需要添加baseURL
                                const shouldPrependBaseURL = !filePath.startsWith('http') &&
                                                            !filePath.startsWith('s3://') &&
                                                            baseURL;
                                //  !filePath.startsWith('/') &&
                                // 生成最终下载URL
                                let downloadURL = filePath;
                                if (shouldPrependBaseURL) {
                                  // 确保baseURL以斜杠结尾
                                  const adjustedBaseURL = baseURL.endsWith('/') ? baseURL : baseURL + '/';
                                  downloadURL = adjustedBaseURL + filePath;
                                }

                                return (
                                  <a
                                    key={key}
                                    href={downloadURL}
                                    download={fileName}z
                                    style={{ textDecoration: 'none' }}
                                  >
                                    <Chip
                                      label={fileName}
                                      size="small"
                                      variant="outlined"
                                      color="primary"
                                      component="span"
                                    />
                                  </a>
                                );
                              });
                            } catch (error) {
                              return (
                                <Chip
                                  label={task.downloadInfo}
                                  size="small"
                                  variant="outlined"
                                  color="error"
                                />
                              );
                            }
                          })()}
                        </Box>
                      )}
                    </TableCell>

                  <TableCell>
                     {task.status !== 'processing' && ( // 避免删除正在处理的任务
                      <Tooltip title="删除任务">
                        <Button
                          variant="outlined"
                          color="error"
                          size="small"
                          startIcon={<DeleteForever />}
                          onClick={() => handleDeleteTask(task.id)}
                        >
                          删除
                        </Button>
                      </Tooltip>
                    )}
                    {/* 下载按钮保持不变 */}
                    {task.status === 'success' && task.downloadInfo && (
                      <Button
                        variant="outlined"
                        startIcon={<DownloadIcon />}
                        onClick={() => window.open(task.downloadInfo, '_blank')}
                        size="small"
                        sx={{ ml: 2 }}
                      >
                        下载数据
                      </Button>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}
    {/* 删除任务确认对话框 */}
      <Dialog open={openDeleteDialog} onClose={() => setOpenDeleteDialog(false)}>
        <DialogTitle>确认删除</DialogTitle>
        <DialogContent>是否确认删除该任务？</DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenDeleteDialog(false)}>取消</Button>
          <Button onClick={confirmDeleteTask} color="error">
            删除
          </Button>
        </DialogActions>
      </Dialog>

      {/* 清空历史记录确认对话框 */}
      <Dialog open={openClearDialog} onClose={() => setOpenClearDialog(false)}>
        <DialogTitle>确认清空</DialogTitle>
        <DialogContent>是否确认清空该配置的所有取数历史？</DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenClearDialog(false)}>取消</Button>
          <Button onClick={confirmClearHistory} color="error">
            清空
          </Button>
        </DialogActions>
      </Dialog>

      {/* 操作结果提示 */}
      <Snackbar
        open={snackbarOpen}
        message={snackbarMessage}
        autoHideDuration={3000}
        onClose={() => setSnackbarOpen(false)}
      />
    </Box>


  );
};

// 状态文本和颜色映射
const statusColors = {
  pending: 'text.secondary',
  processing: 'info.main',
  success: 'success.main',
  failed: 'error.main'
};

const statusTexts = {
  pending: '等待中',
  processing: '处理中',
  success: '成功',
  failed: '失败'
};


  const toggleSection = (section) => {
    setExpandedSections(prev => ({
      ...prev,
      [section]: !prev[section]
    }));
  };
  // 处理选项加载
  const loadOptions = async (field, level, currentSelections) => {
      console.info(`begin loadOptions ${field}  ${level}  ${currentSelections}`)
      const effectiveSelections = currentSelections || {
        global: selections.global,
        tabs: {
          [activeTab]: selections.tabs[activeTab] || { tabDepends: {}, fields: {} }
        }
      };
      const fieldKey = `${level}_${field.name}`;
      setLoading(prev => ({
        ...prev,
        options: { ...prev.options, [fieldKey]: true }
      }));

      try {
        console.info("activeTab: ",activeTab )
        const tabConfig = config.tabs.find(tab => tab.value === activeTab) || {}; // config is layout config
        const dependsOn = field.depends_on || [];
        console.info("effectiveSelections:",effectiveSelections )
        // 使用传入的 currentSelections 而不是闭包中的 selections
        const dependsValues = dependsOn.map(dep => {
          if (level === 'global') return effectiveSelections.global[dep];
          if (level === 'tabDepends') return effectiveSelections.global[dep] || effectiveSelections.tabs?.[activeTab]?.tabDepends?.[dep];
          return effectiveSelections.global[dep] ||
             effectiveSelections.tabs?.[activeTab]?.tabDepends?.[dep] ||
             effectiveSelections.tabs?.[activeTab]?.fields?.[dep];
        });

        // 如果有依赖但依赖值不完整，则清空选项
        if (dependsOn.length > 0 && dependsValues.some(v => !v)) {
          setOptions(prev => ({
            ...prev,
            [level]: { ...prev[level], [field.name]: [] }
          }));
          return;
        }

        // 构造请求数据
        const requestData = {
          layout_name: selectedTemplate,
          field: field.name,
          level,
          tab: activeTab,
          depends: Array.isArray(dependsValues)
            ? dependsValues.flat()
            : [dependsValues].filter(Boolean),
        };

        const defaultApi = level === 'global_dependas' ? `/api/options/global/${field.name}` : `/api/options/${activeTab}/${field.name}`;
        const external_option_baseurl = config.external_option_baseurl
        const targetApi = field.optionsApi || defaultApi;
        let finalUrl;
        if (external_option_baseurl && !targetApi.startsWith('http://') && !targetApi.startsWith('https://')) {
            // 如果 external_option_baseurl 存在，且 targetApi 不是完整 URL，才拼接
            finalUrl = external_option_baseurl + targetApi;
        } else {
            // 否则直接用 targetApi（可能是完整 URL 或相对路径）
            finalUrl = targetApi;
        }
        const response       = await axios.post(  finalUrl  , requestData);
        const normalizedData = Array.isArray(response.data)
        ? response.data.map(item =>
            typeof item === 'boolean' ? (item ? "true" : "false") : String(item)
          )
        : [];
        setOptions(prev => ({
          ...prev,
          [level]: { ...prev[level], [field.name]: normalizedData }
        }));
      } catch (error) {
        console.error({field})
        console.error(`加载${field.label}选项失败:`, error);
        showNotification(`${field.label}选项加载失败`, 'error');
      } finally {
        setLoading(prev => ({
          ...prev,
          options: { ...prev.options, [fieldKey]: false }
        }));
      }
};

  const addOrUpdateConfiguration = () => {
      const tabConfig = config.tabs.find(tab => tab.value === activeTab);
      if (!tabConfig) return;

      // 获取当前tab的依赖和字段选择
      const currentTabSelections = selections.tabs?.[activeTab] || { tabDepends: {}, fields: {} };

      const newConfig = {
        id: activeConfig?.id || Date.now().toString(),
        type: activeTab,
        globalDependencies: { ...selections.global },
        tabDependencies: { ...currentTabSelections.tabDepends }, // 更新为新结构
        fields: { ...currentTabSelections.fields }, // 更新为新结构
        createdAt: activeConfig?.createdAt || new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        status: 'active',
        tabLabel: tabConfig.label,
        // 确保这些字段总是数组
        globalFields: config.global_depends?.map(dep => ({
          name: dep.name,
          label: dep.label,
          value: selections.global[dep.name] || ''
        })) || [],
        tabDependFields: tabConfig.depends?.map(dep => ({
          name: dep.name,
          label: dep.label,
          value: currentTabSelections.tabDepends[dep.name] || ''
        })) || [],
        fieldConfigs: tabConfig.fields?.map(field => ({
          name: field.name,
          label: field.label,
          value: Array.isArray(currentTabSelections.fields[field.name])
                ? currentTabSelections.fields[field.name].join(', ')
                : currentTabSelections.fields[field.name] || ''
        })) || []
      };

      if (activeConfig) {
        setConfigurations(configurations.map(c =>
          c.id === activeConfig.id ? newConfig : c
        ));
        showNotification('配置更新成功');
      } else {
        setConfigurations([...configurations, newConfig]);
        showNotification('配置添加成功');
      }

      setActiveConfig(null);
    };
  const deleteConfiguration = async (id) => {
    try {
      // await axios.delete(`/api/configurations/${id}`);
      setConfigurations(configurations.filter(config => config.id !== id));
      showNotification('配置删除成功');
    } catch (error) {
      showNotification('删除失败', 'error');
      console.error("删除失败:", error);
    }
  };

  const saveConfigurations = async () => {
  setLoading(prev => ({ ...prev, saving: true }));

  try {

    const token = getCookie('auth_token'); // 或者从localStorage获取
    // 添加token到请求头
    const headers = token
      ? { 'Authorization': `Bearer ${token}` }
      : {};

    await axios.post('/api/saveconfigurations', {
      configname: configName,
      timerange: timeRange,
      dates:  dates,
      selections,
      detail: configurations,
      savedat: new Date().toISOString(),
      layoutconfig:config
    } ,{ headers: {
        'Content-Type': 'application/json',
      },withCredentials: true} );

    showNotification(`${configurations.length} 条配置保存成功`);
  } catch (error) {
     let errorMessage   =  error.response.data.error;
     let shouldRedirect = false;
     if (error.response.status === 401) {
        errorMessage = '会话已过期，请重新登录';
        shouldRedirect = true;
      }
    showNotification('保存失败:'+errorMessage, 'error');
    console.error("保存失败:" , error);
//    if (shouldRedirect) {
//      setTimeout(() => {
//        // 使用React Router的导航或window.location
//        window.location.href = '/login';
//        // 或者如果使用React Router: navigate('/login');
//      }, 1000); // 2秒后跳转让用户看到消息
//    }
//    if (error.response.status === 401) {
//        errorMessage = '会话已过期，请重新登录';
//        shouldRedirect = true;
//      }


  } finally {
    setLoading(prev => ({ ...prev, saving: false }));
  }
};
const validateInputs = () => {
  const errors = [];

  // 验证配置名称
  if (!configName || configName.trim() === "") {
    errors.push('配置名称不能为空');
  }

  // 验证时间范围选择
  if (!timeRange || (timeRange !== 'single' && timeRange !== 'trainEval')) {
    errors.push('请选择有效的时间范围类型');
  }

  // 验证时间范围配置
  if (!dates) {
    errors.push('时间范围配置不能为空');
  }

  // 单个文件的时间范围验证
  if (timeRange === 'single') {
    if (!dates.startDate || !dates.endDate) {
      errors.push('单个文件需要设置开始日期和结束日期');
    } else if (new Date(dates.startDate) >= new Date(dates.endDate)) {
      errors.push('开始日期必须在结束日期之前');
    }
  }

  // 训练/验证数据集的时间范围验证
  if (timeRange === 'trainEval') {
    const requiredFields = [
      'trainStartDate', 'trainEndDate',
      'evalStartDate', 'evalEndDate'
    ];

    const missingFields = requiredFields.filter(field => !dates[field]);

    if (missingFields.length > 0) {
      errors.push(`缺少以下日期字段: ${missingFields.join(', ')}`);
    } else {
      // 检查训练日期范围
      if (new Date(dates.trainStartDate) >= new Date(dates.trainEndDate)) {
        errors.push('训练开始日期必须在训练结束日期之前');
      }

      // 检查评估日期范围
      if (new Date(dates.evalStartDate) >= new Date(dates.evalEndDate)) {
        errors.push('评估开始日期必须在评估结束日期之前');
      }

      // 检查训练和评估日期是否有重叠
      if (new Date(dates.trainEndDate) > new Date(dates.evalStartDate)) {
        errors.push('训练结束日期不能晚于评估开始日期');
      }
    }
  }

  // 验证配置项
  if (!configurations || configurations.length === 0) {
    errors.push('请至少添加一个配置项');
  }
  // 验证每个配置项
    //  const invalidConfigs = configurations.filter(config =>
    //    !config.id || !config.name
    //  );  // || !config.timeRange
    //
    //  if (invalidConfigs.length > 0) {
    //    errors.push(`${invalidConfigs.length}个配置项缺少必要信息(ID、名称或时间范围)`);
    //  }

  return errors;
};

const triggerDataFetch = async () => {
  const validationErrors = validateInputs();

  if (validationErrors.length > 0) {
    showHighlightedNotification(   'error',   '表单验证失败',  '请检查并修正以下问题:', validationErrors );
    return;
  }
  setLoading(prev => ({ ...prev, fetching: true }));
  try {
    const response = await axios.post('/api/fetch-data', { configName :configName,
                                                           timeRange,dates ,
                                                           configurations,
                                                           savedAt: new Date().toISOString(),
                                                           layoutconfig:config }  );
    console.info(" 取数失败 response data:",response.data  )
    if (response.data.success) {
      setFetchResults(response.data?.results||[]);  // 存储结果
      showNotification( `成功触发 ${response.data.results.length} 个配置取数`,'success');

    } else {
      console.info(" 取数失败 data:",response.data  )
      showNotification( '取数失败: ' + (response.data.error || '未知错误') ,'error');
    }
  } catch (error) {
     console.info("取数失败 error:", error);
     showNotification( '请求失败: ' +   error ,'error');
  } finally {
    setLoading(prev => ({ ...prev, fetching: false }));
  }
};

  const renderSelectField = (field, level, value, onChange, isDisabled) => {
      const fieldKey = `${level}_${field.name}`;
      // const fieldOptions = field.options || options[level][field.name] || [];
     const fieldOptions = Array.isArray(field.options)
        ? field.options
        : Array.isArray(options[level]?.[field.name])
          ? options[level][field.name]
          : [];

      const isLoading = loading.options[fieldKey] || false;
      const isOpen = openSelects[fieldKey] || false;

      return (
        <FormControl fullWidth sx={{ mt: 2, minWidth: 280 }}>
          <InputLabel>{field.label}</InputLabel>
          <Select
            value={value || ''}
            onChange={(e) => onChange(field.name, e.target.value)}
            onOpen={() => handleSelectOpen(field, level)}
            onClose={() => handleSelectClose(field, level)}
            open={isOpen}
            label={field.label}
            disabled={isDisabled}
          >
            {/* 选项渲染逻辑保持不变 */}
            {isLoading ? (
                <MenuItem disabled>
                  <Box sx={{ display: 'flex', justifyContent: 'center', width: '100%' }}>
                    <CircularProgress size={24} />
                  </Box>
                </MenuItem>
              ) : fieldOptions.length === 0 ? (
                <MenuItem disabled>
                  <Box sx={{
                    display: 'flex',
                    alignItems: 'center',
                    color: theme.palette.text.secondary
                  }}>
                    <HelpOutline sx={{ mr: 1 }} />
                    {isDisabled ? '请先选择依赖项' : '无可用选项'}
                  </Box>
                </MenuItem>
              ) : (
                fieldOptions.map(option => (
                  <MenuItem
                    key={option}
                    value={option}
                    sx={{
                      whiteSpace: 'normal',
                      wordBreak: 'break-word',
                      minHeight: '48px',
                      display: 'flex',
                      alignItems: 'center'
                    }}
                  >
                    {option}
                  </MenuItem>
                ))
              )}
          </Select>
        </FormControl>
      );
    };

    const renderMultiSelectField = (field, level, value, onChange, isDisabled) => {

      // 处理字符串值，按逗号分割为数组
      const processedValue = typeof value === 'string'
        ? value.split(',').map(item => item.trim()).filter(Boolean)
        : (Array.isArray(value) ? value : []);

      const fieldKey = `${level}_${field.name}`;
      const fieldOptions = field.options || options[level][field.name] || [];
      const isLoading = loading.options[fieldKey] || false;
      const isOpen = openSelects[fieldKey] || false;

      return (
        <FormControl fullWidth sx={{ mt: 2, minWidth: 280 }}>
          <InputLabel>{field.label}</InputLabel>
          <Select
            multiple
            value={processedValue || []}
            onChange={(e) => onChange(field.name, e.target.value)}
            onOpen={() => handleSelectOpen(field, level)}
            onClose={() => handleSelectClose(field, level)}
            open={isOpen}
            label={field.label}
            disabled={isDisabled}
            renderValue={(selected) => selected.join(', ')}
          >
            {fieldOptions.map(option => (
              <MenuItem key={option} value={option}>
                <Checkbox checked={value?.includes(option) || false} />
                <ListItemText primary={option} />
              </MenuItem>
            ))}
          </Select>
        </FormControl>
      );
    };

const SmartTextArea = React.forwardRef(({ field, value = '', onChange, isDisabled }, ref) => {
  const [rows, setRows] = useState(2);
  const textareaRef = useRef(null);
  const isComposing = useRef(false);
  const lastValue = useRef(value);

  const adjustRows = useCallback(() => {
    if (!textareaRef.current) return;
    const textarea = textareaRef.current.querySelector('textarea');
    if (!textarea) return;

    const lineHeight = 24;
    const padding = 26;
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;

    textarea.style.height = 'auto';
    const scrollHeight = textarea.scrollHeight;
    const newRows = Math.max(1, Math.min(10, Math.floor((scrollHeight - padding) / lineHeight)));

    if (newRows !== rows) {
      setRows(newRows);
    }
    textarea.style.height = '';

    requestAnimationFrame(() => {
      if (textarea.selectionStart !== start || textarea.selectionEnd !== end) {
        textarea.setSelectionRange(start, end);
      }
    });
  }, [rows]);

  useEffect(() => {
    if (value !== lastValue.current) {
      adjustRows();
      lastValue.current = value;
    }
  }, [value, adjustRows]);

  const handleChange = useCallback((e) => {
    const newValue = e.target.value;
    if (newValue !== value) {
      onChange(field.name, newValue);
    }
  }, [value, onChange, field.name]);

  const handleKeyDown = useCallback((e) => {
    if (e.key === 'Enter' && !isComposing.current && !e.shiftKey) {
      e.preventDefault();
      const newValue = value + '\n';
      onChange(field.name, newValue);
    }
  }, [value, onChange, field.name]);

  const setRefs = useCallback((node) => {
    textareaRef.current = node;
    if (ref) {
      if (typeof ref === 'function') {
        ref(node);
      } else {
        ref.current = node;
      }
    }
  }, [ref]);

  return (
    <TextField
      ref={setRefs}
      fullWidth
      label={field.label}
      value={value}
      onChange={handleChange}
      onKeyDown={handleKeyDown}
      onCompositionStart={() => (isComposing.current = true)}
      onCompositionEnd={() => (isComposing.current = false)}
      variant="outlined"
      disabled={isDisabled}
      multiline
      rows={rows}
      sx={{
        mt: 2,
        width: '100%',       // 确保填满父容器
        maxWidth: '800px',    // 限制最大宽度
        '& .MuiInputBase-root': {
          alignItems: 'flex-start'
        },
        '& textarea': {
          width: '100%',      // 文本区域填满
          minWidth: '300px',  // 最小宽度
          whiteSpace: 'pre-wrap',
          overflowWrap: 'break-word',
          resize: 'none'
        }
      }}
      placeholder={field.placeholder || ''}
      inputProps={{
        style: {
          lineHeight: '24px'
        }
      }}
    />
  );
});

const renderInputField = React.useCallback((field, level, value, onChange, isDisabled) => {
  return (
    <SmartTextArea
      field={field}
      value={value}
      onChange={onChange}
      isDisabled={isDisabled}
    />
  );
}, []);

// ================ 渲染工具函数 ================
const renderField = React.useCallback((field, level, onChange) => {
  const displayLabel = field.label || field.name;
  const fieldWithLabel = {
    ...field,
    label: displayLabel
  };

  // 根据 level 和 activeTab 获取对应的值
  const value = level === 'global'
    ? selections.global[field.name]
    : level === 'tabDepends'
      ? selections.tabs?.[activeTab]?.tabDepends?.[field.name]
      : selections.tabs?.[activeTab]?.fields?.[field.name];

  const fieldKey = `${level}_${field.name}`;
  const isDisabled = field.depends_on?.some(dep => {
    if (level === 'global') return false;
    if (level === 'tabDepends') return !selections.global[dep] && !selections.tabs?.[activeTab]?.tabDepends?.[dep];
    return !selections.global[dep] && !selections.tabs?.[activeTab]?.tabDepends?.[dep] && !selections.tabs?.[activeTab]?.fields?.[dep];
  });

  switch (field.input_type) {
    case 'select':
      return renderSelectField(fieldWithLabel, level, value, onChange, isDisabled);
    case 'multi-select':
      return renderMultiSelectField(fieldWithLabel, level, value, onChange, isDisabled);
    case 'input':
      return renderInputField(fieldWithLabel, level, value, onChange, isDisabled);
    default:
      return renderSelectField(fieldWithLabel, level, value, onChange, isDisabled);
  }
}, [selections, activeTab, renderSelectField, renderMultiSelectField, renderInputField]);

  // 其他渲染函数保持不变...
  // (renderDateFields, renderConfigDetail等函数保持不变)
  const renderDateFields = () => {
    if (timeRange === 'single') {
      return (
        <>
          <Grid item xs={12} md={6}>
            <TextField
              fullWidth
              label="开始日期"
              type="date"
              name="startDate"
              value={dates.startDate}
              onChange={handleDateChange}
              InputLabelProps={{ shrink: true }}
              InputProps={{
                startAdornment: (
                  <CalendarToday
                    color="action"
                    sx={{ mr: 1, color: theme.palette.text.secondary }}
                  />
                )
              }}
            />
          </Grid>
          <Grid item xs={12} md={6}>
            <TextField
              fullWidth
              label="结束日期"
              type="date"
              name="endDate"
              value={dates.endDate}
              onChange={handleDateChange}
              InputLabelProps={{ shrink: true }}
              InputProps={{
                startAdornment: (
                  <CalendarToday
                    color="action"
                    sx={{ mr: 1, color: theme.palette.text.secondary }}
                  />
                )
              }}
            />
          </Grid>
        </>
      );
    }
    return (
      <>
        <Grid item xs={12} md={3}>
          <TextField
            fullWidth
            label="训练开始"
            type="date"
            name="trainStartDate"
            value={dates.trainStartDate}
            onChange={handleDateChange}
            InputLabelProps={{ shrink: true }}
            InputProps={{
              startAdornment: (
                <CalendarToday
                  color="action"
                  sx={{ mr: 1, color: theme.palette.text.secondary }}
                />
              )
            }}
          />
        </Grid>
        <Grid item xs={12} md={3}>
          <TextField
            fullWidth
            label="训练结束"
            type="date"
            name="trainEndDate"
            value={dates.trainEndDate}
            onChange={handleDateChange}
            InputLabelProps={{ shrink: true }}
            InputProps={{
              startAdornment: (
                <CalendarToday
                  color="action"
                  sx={{ mr: 1, color: theme.palette.text.secondary }}
                />
              )
            }}
          />
        </Grid>
        <Grid item xs={12} md={3}>
          <TextField
            fullWidth
            label="评估开始"
            type="date"
            name="evalStartDate"
            value={dates.evalStartDate}
            onChange={handleDateChange}
            InputLabelProps={{ shrink: true }}
            InputProps={{
              startAdornment: (
                <CalendarToday
                  color="action"
                  sx={{ mr: 1, color: theme.palette.text.secondary }}
                />
              )
            }}
          />
        </Grid>
        <Grid item xs={12} md={3}>
          <TextField
            fullWidth
            label="评估结束"
            type="date"
            name="evalEndDate"
            value={dates.evalEndDate}
            onChange={handleDateChange}
            InputLabelProps={{ shrink: true }}
            InputProps={{
              startAdornment: (
                <CalendarToday
                  color="action"
                  sx={{ mr: 1, color: theme.palette.text.secondary }}
                />
              )
            }}
          />
        </Grid>
      </>
    );
  };

  const renderConfigDetail = (config) => {
    if (!config) return null;

    return (
      <Dialog
        open={!!config}
        onClose={() => setDetailConfig(null)}
        maxWidth="md"
        fullWidth
        PaperProps={{
          sx: {
            borderRadius: '16px'
          }
        }}
      >
        <DialogTitle sx={{
          backgroundColor: theme.palette.primary.main,
          color: theme.palette.primary.contrastText,
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center'
        }}>
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <Avatar sx={{
              bgcolor: theme.palette.primary.contrastText,
              color: theme.palette.primary.main,
              mr: 2,
              width: 32,
              height: 32
            }}>
              {config.name.charAt(0).toUpperCase()}
            </Avatar>
            <Typography variant="h6">{config.name}</Typography>
          </Box>
          <IconButton
            onClick={() => setDetailConfig(null)}
            sx={{ color: theme.palette.primary.contrastText }}
          >
            <Close />
          </IconButton>
        </DialogTitle>
        <DialogContent dividers sx={{ p: 3 }}>
          <Grid container spacing={3}>
            <Grid item xs={12} md={6}>
              <Typography variant="subtitle1" gutterBottom sx={{
                color: theme.palette.text.secondary,
                display: 'flex',
                alignItems: 'center'
              }}>
                <Info color="inherit" sx={{ mr: 1 }} />
                基本信息
              </Typography>

              <Box sx={{
                backgroundColor: theme.palette.action.hover,
                borderRadius: '8px',
                p: 2,
                mb: 2
              }}>
                <Grid container spacing={2}>
                  <Grid item xs={6}>
                    <Typography variant="body2"><strong>类型:</strong></Typography>
                    <Typography>{config.tabLabel}</Typography>
                  </Grid>
                  <Grid item xs={6}>
                    <Typography variant="body2"><strong>状态:</strong></Typography>
                    <Box>
                      <StatusChip
                        label={config.status === 'active' ? '活跃' :
                              config.status === 'error' ? '错误' : '待定'}
                        status={config.status}
                        size="small"
                      />
                    </Box>
                  </Grid>
                  <Grid item xs={6}>
                    <Typography variant="body2"><strong>创建时间:</strong></Typography>
                    <Typography>{formatDateTime(config.createdAt)}</Typography>
                  </Grid>
                  <Grid item xs={6}>
                    <Typography variant="body2"><strong>最后取数时间:</strong></Typography>
                    <Typography>
                      {config.lastFetchTime ? formatDateTime(config.lastFetchTime) : '未执行'}
                    </Typography>
                  </Grid>
                </Grid>
              </Box>

              {config.description && (
                <>
                  <Typography variant="subtitle1" gutterBottom sx={{
                    color: theme.palette.text.secondary,
                    display: 'flex',
                    alignItems: 'center'
                  }}>
                    <Info color="inherit" sx={{ mr: 1 }} />
                    描述
                  </Typography>
                  <Paper variant="outlined" sx={{ p: 2, borderRadius: '8px' }}>
                    <Typography>{config.description}</Typography>
                  </Paper>
                </>
              )}
            </Grid>

            <Grid item xs={12} md={6}>
              <Typography variant="subtitle1" gutterBottom sx={{
                color: theme.palette.text.secondary,
                display: 'flex',
                alignItems: 'center'
              }}>
                <Info color="inherit" sx={{ mr: 1 }} />
                时间范围
              </Typography>

              <Paper variant="outlined" sx={{ p: 2, borderRadius: '8px' }}>
                {config.timeRange === 'single' ? (
                  <Grid container spacing={2}>
                    <Grid item xs={6}>
                      <Typography variant="body2"><strong>开始日期:</strong></Typography>
                      <Typography>{config.dates.startDate}</Typography>
                    </Grid>
                    <Grid item xs={6}>
                      <Typography variant="body2"><strong>结束日期:</strong></Typography>
                      <Typography>{config.dates.endDate}</Typography>
                    </Grid>
                  </Grid>
                ) : (
                  <Grid container spacing={2}>
                    <Grid item xs={12}>
                      <Typography variant="body2"><strong>训练周期:</strong></Typography>
                      <Typography>

                        {config.dates.trainStartDate} 至 {config.dates.trainEndDate}
                      </Typography>
                    </Grid>
                    <Grid item xs={12}>
                      <Typography variant="body2"><strong>评估周期:</strong></Typography>
                      <Typography>
                        {config.dates.evalStartDate} 至 {config.dates.evalEndDate}
                      </Typography>
                    </Grid>
                  </Grid>
                )}
              </Paper>
            </Grid>
          </Grid>

          <Divider sx={{ my: 3 }} />

          <Typography variant="subtitle1" gutterBottom sx={{
            color: theme.palette.text.secondary,
            display: 'flex',
            alignItems: 'center'
          }}>
            <Info color="inherit" sx={{ mr: 1 }} />
            配置详情
          </Typography>

          <Grid container spacing={3}>
            <Grid item xs={12} md={4}>
              <Typography variant="subtitle2" gutterBottom>全局依赖</Typography>
              <TableContainer component={Paper} variant="outlined">
                <Table size="small">
                  <TableHead>
                    <TableRow>
                      <TableCell>字段</TableCell>
                      <TableCell>值</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {config.globalFields.map(field => (
                      <TableRow key={field.name}>
                        <TableCell>{field.label}</TableCell>
                        <TableCell>{field.value || '-'}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            </Grid>

            {config.tabDependFields.length > 0 && (
              <Grid item xs={12} md={4}>
                <Typography variant="subtitle2" gutterBottom>Tab依赖</Typography>
                <TableContainer component={Paper} variant="outlined">
                  <Table size="small">
                    <TableHead>
                      <TableRow>
                        <TableCell>字段</TableCell>
                        <TableCell>值</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {config.tabDependFields.map(field => (
                        <TableRow key={field.name}>
                          <TableCell>{field.label}</TableCell>
                          <TableCell>{field.value || '-'}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </TableContainer>
              </Grid>
            )}

            <Grid item xs={12} md={4}>
              <Typography variant="subtitle2" gutterBottom>字段配置</Typography>
              <TableContainer component={Paper} variant="outlined">
                <Table size="small">
                  <TableHead>
                    <TableRow>
                      <TableCell>字段</TableCell>
                      <TableCell>值</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {config.fieldConfigs.map(field => (
                      <TableRow key={field.name}>
                        <TableCell>{field.label}</TableCell>
                        <TableCell>{field.value || '-'}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions sx={{ p: 2 }}>
          <Button
            onClick={() => setDetailConfig(null)}
            variant="outlined"
            sx={{ mr: 1 }}
          >
            关闭
          </Button>
          <Button
            variant="contained"
            color="error"
            startIcon={<Delete />}
            onClick={() => {
              deleteConfiguration(config.id);
              setDetailConfig(null);
            }}
          >
            删除配置
          </Button>
        </DialogActions>
      </Dialog>
    );
  };

  // ================ 主渲染逻辑 ================
  if(templateDialogOpen){
    return(
    <>
        {renderTemplateDialog()}
    </>
    )
  }

  if (!config) {
    return (
      <Box sx={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        height: '80vh'
      }}>
        <CircularProgress size={60} />
      </Box>
    );
  }
    // 获取配置项的索引位置
    const getConfigIndex = (id) => configurations.findIndex(config => config.id === id);
    // 检查是否可以移动
    const canMoveUp = (id) => {
      const index = getConfigIndex(id);
      return index > 0;
    };

    const canMoveDown = (id) => {
      const index = getConfigIndex(id);
      return index >= 0 && index < configurations.length - 1;
    };
    // 上移配置项
    const moveConfigurationUp = (id) => {
      const index = getConfigIndex(id);
      if (index <= 0) return;

      setConfigurations(prev => {
        const newConfigurations = [...prev];
        [newConfigurations[index], newConfigurations[index - 1]] =
          [newConfigurations[index - 1], newConfigurations[index]];
        return newConfigurations;
      });
    };

    // 下移配置项
    const moveConfigurationDown = (id) => {
      const index = getConfigIndex(id);
      if (index < 0 || index >= configurations.length - 1) return;

      setConfigurations(prev => {
        const newConfigurations = [...prev];
        [newConfigurations[index], newConfigurations[index + 1]] =
          [newConfigurations[index + 1], newConfigurations[index]];
        return newConfigurations;
      });
    };
  const startEditing = (config) => {
  setEditingConfig(JSON.parse(JSON.stringify(config)));

  // 转换多选字段的字符串值为数组
  const processedFields = {};
  Object.entries(config.fields || {}).forEach(([key, value]) => {
    if (typeof value === 'string') {
      processedFields[key] = value.split(',').map(item => item.trim()).filter(Boolean);
    } else {
      processedFields[key] = value;
    }
  });

  setSelections({
    global: config.globalDependencies || {},
    tabs: {
      [config.type]: {
        tabDepends: config.tabDependencies || {},
        fields: processedFields
      }
    }
  });
  setActiveTab(config.type);
};
  const saveEditing = () => {
      if (!editingConfig) return;

      setConfigurations(prev =>
        prev.map(config =>
          config.id === editingConfig.id ? editingConfig : config
        )
      );
      setEditingConfig(null);
      showNotification('配置修改成功');
  };

  const cancelEditing = () => {
      setEditingConfig(null);
  };
  console.log("config:",config)
  const currentTabConfig = config.tabs.find(tab => tab.value === activeTab) || {};
  console.log("currentTabConfig:",currentTabConfig)
  return (
  <>

    <Box sx={{ p: 3, maxWidth: '1800px', margin: '0 auto' }}>
      <Typography variant="h4" gutterBottom sx={{
        fontWeight: 600,
        color: theme.palette.text.primary,
        mb: 4,
        display: 'flex',
        alignItems: 'center'
      }}>
        {config.appTitle || "高级数据配置平台"}
      </Typography>

      {/* 通知 */}
      <Snackbar
        open={notification.open}
        autoHideDuration={6000}
        onClose={handleCloseNotification}
        anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
      >
        <Alert
          onClose={handleCloseNotification}
          severity={notification.severity}
          sx={{ width: '100%' }}
          iconMapping={{
            success: <CheckCircle fontSize="inherit" />,
            error: <Error fontSize="inherit" />,
            warning: <Warning fontSize="inherit" />,
            info: <Info fontSize="inherit" />
          }}
        >
          {notification.message}
        </Alert>
      </Snackbar>

      {/* 案例配置部分 */}
      <StyledPaper>
        <Typography variant="h6" gutterBottom sx={{
          fontWeight: 500,
          display: 'flex',
          alignItems: 'center'
        }}>
          <Badge color="primary" variant="dot" sx={{ mr: 1 }} />
          案例配置
        </Typography>
        <Grid container spacing={2}>
          <Grid item xs={12} md={6}>
            <TextField
              fullWidth
              label="配置名称"
              value={configName}
              onChange={handleNameChange}
              variant="outlined"
              placeholder="请输入有意义的配置名称"
              error={!!configNameError}
              helperText={configNameError || "建议使用有意义的名称便于后续查找"}
              InputProps={{
              endAdornment: checkingName ? (
                <CircularProgress size={20} />
              ) : null
            }}
            sx={{
              // 可选：自定义错误状态下的样式
              '& .MuiOutlinedInput-root.Mui-error': {
                '& fieldset': {
                  borderWidth: '2px'  // 错误状态下边框加粗
                }
              }
            }}
            />
          </Grid>
          <Grid item xs={12} md={6}>
            <FormControl fullWidth>
              <InputLabel>时间范围</InputLabel>
              <Select
                value={timeRange}
                onChange={(e) => setTimeRange(e.target.value)}
                label="时间范围"
              >
                <MenuItem value="single">单文件</MenuItem>
                <MenuItem value="trainEval">训练和评估</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          {renderDateFields()}
        </Grid>
      </StyledPaper>

      {/* 全局依赖配置 */}
      <StyledPaper>
        <SectionHeader onClick={() => toggleSection('global')}>
          <Typography variant="h6" sx={{ flexGrow: 1, fontWeight: 500 }}>
            <Badge color="secondary" variant="dot" sx={{ mr: 1 }} />
            全局依赖配置
          </Typography>
           <Tooltip
            title="多个全局变量是且的关系，所有选项必须被选择才能生效"
            arrow
            placement="top"
          >
            <Typography
              component="span"
              variant="caption"
              sx={{
                ml: 1,
                color: 'text.secondary',
                cursor: 'help'
              }}
            >
              (取数后:全局依赖字段为必有列且非空)
            </Typography>
          </Tooltip>

          {expandedSections.global ? <ExpandLess /> : <ExpandMore />}
        </SectionHeader>

        <Collapse in={expandedSections.global}>
          <Grid container spacing={3}>
            {config.global_depends?.map(dep => (
              <Grid item xs={12} md={6} lg={4} key={dep.name}>
                {renderField(
                  dep,
                  'global',
                  handleGlobalChange
                )}
              </Grid>
            ))}
          </Grid>
        </Collapse>
      </StyledPaper>

      {/* Tab选择 */}
      <Paper sx={{
        p: 1,
        mb: 3,
        borderRadius: '12px',
        position: 'sticky',
        top: 0,
        zIndex: 10,
        backgroundColor: theme.palette.background.default
      }}>
        <Tabs
          value={activeTab}
          onChange={handleTabChange}
          variant="scrollable"
          scrollButtons="auto"
          sx={{
            '& .MuiTab-root': {
              minHeight: 48,
              textTransform: 'none',
              fontWeight: 500
            }
          }}
        >
        {
           config.tabs.map(tab => (
            <Tab
              key       ={tab.value}
              label     ={tab.label}
              value     ={tab.value}
              disabled  ={config.global_depends?.some(
                    dep => !selections.global[dep.name]
              )}
              icon={
                <Badge
                  color="primary"
                  badgeContent={configurations.filter(c => c.type === tab.value).length}
                  max={99}
                  sx={{ '& .MuiBadge-badge': { transform: 'scale(1) translate(50%, -50%)' } }}
                />
              }
              iconPosition="end"
            />
          ))}
        </Tabs>
      </Paper>

      {/* Tab依赖配置 */}
      {currentTabConfig.depends?.length > 0 && (
        <StyledPaper>
          <SectionHeader onClick={() => toggleSection('tabDepends')}>
            <Typography variant="h6" sx={{ flexGrow: 1, fontWeight: 500 }}>
              <Badge color="secondary" variant="dot" sx={{ mr: 1 }} />
              {currentTabConfig.label} 依赖配置
            </Typography>
            {expandedSections.tabDepends ? <ExpandLess /> : <ExpandMore />}
          </SectionHeader>

          <Collapse in={expandedSections.tabDepends}>
            <Grid container spacing={3}>
              {currentTabConfig.depends.map(dep => (
                <Grid item xs={12} md={6} lg={4} key={dep.name}>
                  {renderField(
                    dep,
                    'tabDepends',
                    handleTabDependChange
                  )}
                </Grid>
              ))}
            </Grid>
          </Collapse>
        </StyledPaper>
      )}

      {/* 字段配置 */}
      {currentTabConfig.fields?.length > 0 && (
        <StyledPaper>
          <SectionHeader onClick={() => toggleSection('fields')}>
            <Typography variant="h6" sx={{ flexGrow: 1, fontWeight: 500 }}>
              <Badge color="secondary" variant="dot" sx={{ mr: 1 }} />
              {currentTabConfig.label} 字段配置
            </Typography>
            {expandedSections.fields ? <ExpandLess /> : <ExpandMore />}
          </SectionHeader>

          <Collapse in={expandedSections.fields}>
            <Grid container spacing={3}>
              {currentTabConfig.fields.map(field => (
                  <Grid item xs={12} md={6} lg={4} key={field.name}>
                    {renderField(
                      field,
                      'fields',
                      handleFieldChange
                    )}
                  </Grid>
                ))}
            </Grid>

            <Box sx={{
              mt: 4,
              display: 'flex',
              justifyContent: 'flex-end',
              gap: 2
            }}>
              <Button
                variant="outlined"
                onClick={() => {
                  setSelections(prev => ({
                    ...prev,
                    tabs: {
                      ...prev.tabs,
                      [activeTab]: {
                        ...prev.tabs[activeTab],
                        fields: {}
                      }
                    }
                  }));
                }}
                disabled={!Object.values(selections.tabs?.[activeTab]?.fields || {}).some(v => v)}
              >
                清空字段
              </Button>
              
              <Button
                variant="contained"
                startIcon={<AddCircle />}
                onClick={addOrUpdateConfiguration }
                disabled={!Object.values(selections.tabs?.[activeTab]?.fields || {}).some(v => v)}
                sx={{ minWidth: 150 }}
              >
                添加配置
              </Button>
            </Box>
          </Collapse>
        </StyledPaper>
      )}

      {/* 已配置字段 */}
      {configurations.length > 0 && (
        <StyledPaper>
          <Box sx={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            mb: 2
          }}>
            <Typography variant="h6" sx={{ fontWeight: 500 }}>
              <Badge
                badgeContent={configurations.filter(c => c.type === activeTab).length}
                color="primary"
                max={999}
                sx={{ mr: 1 }}
              />
              已配置字段
            </Typography>

            <Box sx={{ display: 'flex', alignItems: 'center', gap: 3 }}>
                <Box>
                  <Typography variant="subtitle2" color="textSecondary" sx={{ mb: 0.5 }}>
                    当前配置名称
                  </Typography>
                  <Tooltip title={configDescription || '无描述'}>
                    <Typography
                      noWrap
                      sx={{
                        fontWeight: 600,
                        color: theme.palette.primary.main,
                        maxWidth: 200
                      }}
                    >
                      {configName}
                    </Typography>
                  </Tooltip>
                </Box>

                <Divider orientation="vertical" flexItem />

                <Box>
                  <Typography variant="subtitle2" color="textSecondary" sx={{ mb: 0.5 }}>
                    时间范围
                  </Typography>
                  {timeRange === 'single' ? (
                    <Typography variant="body2">
                      {dates.startDate} 至 {dates.endDate}
                    </Typography>
                  ) : (
                    <Box>
                      <Typography variant="body2">
                        训练: {dates.trainStartDate} - {dates.trainEndDate}
                      </Typography>
                      <Typography variant="body2">
                        评估: {dates.evalStartDate} - {dates.evalEndDate}
                      </Typography>
                    </Box>
                  )}
                </Box>
              </Box>

            <Typography variant="body2" color="textSecondary">
              最后更新: {format(new Date(), 'yyyy-MM-dd HH:mm')}
            </Typography>
            <Typography variant="body2" color="textSecondary">
               字段取数会从上到下依次获取
            </Typography>
          </Box>


          <TableContainer>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>配置类型</TableCell>
                  <TableCell>字段配置</TableCell>
                  <TableCell>依赖路径</TableCell>
                  <TableCell>操作</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {configurations
                  .map(config => (
                    <ConfigTableRow key={config.id}>
                      <TableCell>
                        <Tooltip title={config.tabLabel}>
                          <Chip
                            label={config.type}
                            size="small"
                            variant="outlined"
                          />
                        </Tooltip>
                      </TableCell>

                      <TableCell sx={{ maxWidth: 250 }}>
                        <Box sx={{ maxHeight: 120, overflow: 'auto' }}>
                          {config.fieldConfigs?.map(field => (
                            <div key={field.name}>
                              <Typography variant="body2">
                                <strong>{field.label}:</strong> {field.value || '-'}
                              </Typography>
                            </div>
                          ))}
                        </Box>
                      </TableCell>

                      <TableCell sx={{ maxWidth: 300 }}>
                        <Box sx={{ maxHeight: 120, overflow: 'auto' }}>
                          {[...config.globalFields, ...config.tabDependFields].map(field => (
                            <div key={field.name}>
                              <Typography variant="body2">
                                <strong>{field.label}:</strong> {field.value || '-'}
                              </Typography>
                            </div>
                          ))}
                        </Box>
                      </TableCell>
                      <TableCell sx={{ minWidth: 120 }}>
                        <Box sx={{ display: 'flex' }}>
                           <Tooltip title="上移">
                              <span> {/* 包装span解决禁用按钮tooltip问题 */}
                                <IconButton
                                  onClick={() => moveConfigurationUp(config.id)}
                                  size="small"
                                  disabled={!canMoveUp(config.id)}
                                  sx={{
                                    color: theme.palette.primary.main,
                                    '&:disabled': { opacity: 0.3 }
                                  }}
                                >
                                  <ArrowUpward fontSize="small" />
                                </IconButton>
                              </span>
                           </Tooltip>
                           <Tooltip title="下移">
                              <span>
                                <IconButton
                                  onClick={() => moveConfigurationDown(config.id)}
                                  size="small"
                                  disabled={!canMoveDown(config.id)}
                                  sx={{
                                    color: theme.palette.primary.main,
                                    '&:disabled': { opacity: 0.3 }
                                  }}
                                >
                                  <ArrowDownward fontSize="small" />
                                </IconButton>
                              </span>
                           </Tooltip>
                          <Tooltip title="修改配置">
                              <IconButton
                                onClick={() => startEditing(config)}
                                size="small"
                                color="primary"
                              >
                                <Edit fontSize="small" />
                              </IconButton>
                          </Tooltip>
                          <Tooltip title="删除配置">
                            <IconButton
                              onClick={() => deleteConfiguration(config.id)}
                              size="small"
                              color="error"
                            >
                              <Delete fontSize="small" />
                            </IconButton>
                          </Tooltip>
                        </Box>
                      </TableCell>
                    </ConfigTableRow>
                  ))}
              </TableBody>
            </Table>
          </TableContainer>
        </StyledPaper>
      )}

      {/* 操作按钮 */}
      <Box sx={{
        display: 'flex',
        justifyContent: 'flex-end',
        gap: 2,
        position: 'sticky',
        bottom: 20,
        zIndex: 10,
        backgroundColor: 'background.paper',
        p: 2,
        borderRadius: '12px',
        boxShadow: '0px 4px 20px rgba(0, 0, 0, 0.12)'
      }}>


        <Button
          variant="outlined"
          color="primary"
          startIcon={<Save />}
          onClick={saveConfigurations}
          disabled={configurations.length === 0 || loading.saving}
          sx={{ minWidth: 120 }}
        >
          {loading.saving ? <CircularProgress size={24} /> : '保存配置'}
        </Button>
        <Button
          variant="contained"
          color="success"
          startIcon={<PlayArrow />}
          onClick={triggerDataFetch}
          disabled={configurations.length === 0 || loading.fetching}
          sx={{ minWidth: 120 }}
        >
          {loading.fetching ? <CircularProgress size={24} /> : '触发取数'}
        </Button>
        <Button
          variant="contained"
          color="info"
          startIcon={<History />}
          onClick={() => setHistoryDialogOpen(true)}
          sx={{ minWidth: 120 }}
        >
          历史取数
        </Button>

      </Box>

      {/* 详情弹窗 */}
      {renderConfigDetail(detailConfig)}
    
    {showHistory && (
      <Box sx={{ mt: 3 }}>
        <DataFetch />
      </Box>
    )}
    
    {/* {historyDialogOpen && (
      <Dialog open onClose={() => setHistoryDialogOpen(false)}>
        <DataFetch configName={onfigName} />
      </Dialog>
    )} */}
    <HistoryTable configName={configName} />

    </Box>

    <Dialog
      open={notification.open}
      onClose={() => setNotification(prev => ({ ...prev, open: false }))}
      PaperProps={{
        sx: {
          minWidth: 450,
          borderLeft: notification.type === 'error'
            ? '4px solid #d32f2f'
            : '4px solid #2e7d32'
        }
      }}
    >
      <DialogTitle sx={{ display: 'flex', alignItems: 'center', pt: 2 }}>
        {notification.type === 'error' ? (
          <ErrorOutlineIcon color="error" sx={{ fontSize: 30, mr: 1.5 }} />
        ) : (
          <CheckCircleOutlineIcon color="success" sx={{ fontSize: 30, mr: 1.5 }} />
        )}
        <Typography variant="h6" component="span" fontWeight="bold">
          {notification.title || ''} {/* 确保不会显示 undefined */}
        </Typography>
        <IconButton
          aria-label="close"
          onClick={() => setNotification(prev => ({ ...prev, open: false }))}
          sx={{ position: 'absolute', right: 8, top: 8 }}
        >
          <CloseIcon />
        </IconButton>
      </DialogTitle>

      <DialogContent sx={{ pt: 0, pb: 2 }}>
        <Typography variant="body1" color="text.primary" sx={{ mb: 1 }}>
          {notification.message || ''} {/* 确保不会显示 undefined */}
        </Typography>

        {notification.details && Array.isArray(notification.details) && notification.details.length > 0 ? ( // 添加保护措施
          <Collapse in={true} sx={{ mt: 2, borderTop: '1px solid rgba(0, 0, 0, 0.12)', pt: 2 }}>
            <Typography variant="subtitle2" fontWeight="bold" sx={{ mb: 1 }}>
              详细说明:
            </Typography>
            <ul style={{ margin: 0, paddingLeft: 24 }}>
              {notification.details.map((detail, index) => (
                <li key={index}>
                  <Typography
                    variant="body2"
                    color={notification.type === 'error' ? 'error' : 'text.primary'}
                    component="span"
                    sx={{ fontWeight: 500 }}
                  >
                    {detail}
                  </Typography>
                </li>
              ))}
            </ul>
          </Collapse>
        ) : null}
      </DialogContent>

      <DialogActions sx={{ px: 3, pb: 2 }}>
        <Button
          variant="contained"
          onClick={() => setNotification(prev => ({ ...prev, open: false }))}
          color={notification.type === 'error' ? 'error' : 'success'}
          autoFocus
          fullWidth
        >
          确认
        </Button>
      </DialogActions>
    </Dialog>
  </>
  );
};
export default DataConfigForm;