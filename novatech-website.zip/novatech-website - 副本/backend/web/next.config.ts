import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  /* config options here */
  output: 'export',
  
  // 静态环境下需要禁用图片优化
  images: {
    unoptimized: true,
  }
};

export default nextConfig;
