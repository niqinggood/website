import Head from 'next/head';
import { Layout } from '../components/AllComponents';
import { GetStaticProps } from 'next';

export const getStaticProps = async () => {
  const config = require('../public/config/site-config.json');
  return { props: { config } };
};

// 密码重置组件 - 优化用户体验
export const ResetPasswordForm = () => {
  const [email, setEmail] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const router = useRouter(); // 使用Next.js路由

  // 创建主题
  const theme = createTheme({
    palette: {
      primary: {
        main: '#165DFF',
      },
      secondary: {
        main: '#0A2463',
      },
    }
  });

  const handleReset = async () => {
    try {
      setIsLoading(true);
      // 模拟API请求延迟
      await new Promise(resolve => setTimeout(resolve, 1000));
      // 实际项目中使用Firebase或其他认证服务
      console.log('重置密码:', { email });
      alert("密码重置链接已发送！");
      router.push("/login"); // 使用Next.js路由导航
    } catch (error) {
      alert("发送失败: " + error.message);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <ThemeProvider theme={theme}>
      <Container maxWidth="sm" sx={{ py: { xs: 8, md: 12 } }}>
        <Paper
          elevation={3}
          sx={{
            p: 5,
            borderRadius: 2,
            boxShadow: 4,
            transition: 'box-shadow 0.3s ease',
            '&:hover': {
              boxShadow: 6,
            }
          }}
        >
          <Typography variant="h5" component="h1" gutterBottom align="center" sx={{ color: theme.palette.secondary.main }}>
            重置密码
          </Typography>

          <Box component="form" noValidate sx={{ mt: 1 }}>
            <TextField
              margin="normal"
              required
              fullWidth
              label="输入您的邮箱"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              sx={{
                '& .MuiOutlinedInput-root': {
                  '& fieldset': {
                    borderColor: 'rgba(0, 0, 0, 0.1)',
                  },
                  '&:hover fieldset': {
                    borderColor: theme.palette.primary.main,
                  },
                  '&.Mui-focused fieldset': {
                    borderColor: theme.palette.primary.main,
                  }
                }
              }}
            />

            <Button
              fullWidth
              variant="contained"
              sx={{
                mt: 4,
                mb: 2,
                py: 1.2,
                borderRadius: 2,
                textTransform: 'none',
                fontSize: 16,
                backgroundColor: theme.palette.primary.main,
                '&:hover': {
                  backgroundColor: theme.palette.primary.dark,
                },
                transition: 'all 0.3s ease',
              }}
              onClick={handleReset}
              disabled={isLoading}
            >
              {isLoading ? (
                <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  发送中...
                </Box>
              ) : '发送重置邮件'}
            </Button>
          </Box>
        </Paper>
      </Container>
    </ThemeProvider>
  );
};
export default function ResetPassword({ config }) {
  return (
    <Layout config={config}>
      <Head>
        <title>重置密码 - {config.site?.name}</title>
      </Head>
      
      <ResetPasswordForm />
    </Layout>
  );
}
