import { useState, useEffect, useCallback } from 'react';
import {
  Box, Typography, Paper, Card, Button,
  TextField, Alert, CircularProgress, Chip,
  Dialog, DialogTitle, DialogContent, DialogActions,
  IconButton, Menu, MenuItem, Snackbar,
  InputAdornment, Select, FormControl, InputLabel
} from '@mui/material';
import {
  Add, MoreVert, Delete, Edit,
  ThumbUp, Comment, Person, Visibility,
  CloudUpload, Clear, Image as ImageIcon,
  InsertDriveFile as FileIcon, AttachFile,
  Search, Category, CheckCircle,
  Code, Lightbulb, FlashOn
} from '@mui/icons-material';
import LinearProgress from '@mui/material/LinearProgress';
import { styled } from '@mui/material/styles';
import { Layout } from '../components/AllComponents';
import api from '../components/axiosConfig';
import { useAuth } from '../components/AuthContext';

// 样式组件 - 科技感配色调整（深蓝科技感）
const PostCard = styled(Card)(({ theme }) => ({
  padding: theme.spacing(2.5),
  marginBottom: theme.spacing(2),
  borderRadius: 16,
  boxShadow: '0 4px 20px rgba(0,0,0,0.08)',
  transition: 'all 0.3s ease',
  border: '1px solid rgba(0,0,0,0.06)',
  background: 'white',
  '&:hover': {
    boxShadow: '0 8px 30px rgba(0,0,0,0.12)',
    transform: 'translateY(-2px)'
  }
}));

// 扁宽卡片设计 - 更宽的宽高比
const CompactPostCard = styled(Card)(({ theme }) => ({
  width: 320, // 固定宽度，类似B站视频卡片
  height: 220, // 适当高度，保持宽高比
  display: 'flex',
  flexDirection: 'column', // 改回纵向布局
  borderRadius: 12,
  boxShadow: '0 2px 12px rgba(0,0,0,0.06)',
  transition: 'all 0.3s ease',
  border: '1px solid rgba(0,0,0,0.04)',
  background: 'white',
  overflow: 'hidden',
  cursor: 'pointer',
  '&:hover': {
    boxShadow: '0 6px 20px rgba(30, 136, 229, 0.15)',
    transform: 'translateY(-2px)',
    borderColor: 'rgba(30, 136, 229, 0.3)'
  }
}));

const ActionSection = styled(Box)(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
  marginTop: theme.spacing(2),
  paddingTop: theme.spacing(2),
  borderTop: '1px solid rgba(0,0,0,0.08)'
}));

// 列表视图容器
const ListViewContainer = styled(Box)(({ theme }) => ({
  display: 'flex',
  flexDirection: 'column',
  gap: theme.spacing(2),
}));

// 文件URL处理函数
const getFileUrl = (filePath, base_api) => {
  if (!filePath) return '';

  if (filePath.startsWith('http')) {
    return filePath;
  }

  if (filePath.startsWith('/')) {
    return `${base_api}${filePath}`;
  }

  if (filePath.startsWith('uploads')) {
    return `${base_api}/${filePath}`;
  }

  return `${base_api}/uploads/${filePath}`;
};

// 文件上传组件
const FileUploader = ({ onFilesUploaded }) => {
  const [files, setFiles] = useState([]);
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [uploadError, setUploadError] = useState('');

  const handleFileChange = (e) => {
    const selectedFiles = Array.from(e.target.files);
    if (selectedFiles.length) {
      setFiles(prev => [...prev, ...selectedFiles]);
      setUploadError('');
      e.target.value = '';
    }
  };

  const removeFile = (index) => {
    setFiles(prev => prev.filter((_, i) => i !== index));
  };

  const handleUpload = async () => {
    if (!files.length) return;

    setUploading(true);
    setProgress(0);
    setUploadError('');

    try {
      const uploadedAttachments = [];

      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const formData = new FormData();
        formData.append('file', file);

        try {
          const response = await api.post('/api/forum/posts/upload', formData, {
            headers: {
              'Content-Type': 'multipart/form-data'
            },
            onUploadProgress: (progressEvent) => {
              const percent = Math.round(
                ((progressEvent.loaded / progressEvent.total) * 100) / files.length
              );
              setProgress(prev => Math.min(prev + percent, 100));
            }
          });

          const uploadedData = response.data.data || response.data;
          if (Array.isArray(uploadedData)) {
            uploadedAttachments.push(...uploadedData);
          } else {
            uploadedAttachments.push(uploadedData);
          }
        } catch (fileError) {
          console.error(`文件 ${file.name} 上传失败:`, fileError);
          throw fileError;
        }
      }

      if (onFilesUploaded) {
        onFilesUploaded(uploadedAttachments);
      }

      setFiles([]);
      return uploadedAttachments;
    } catch (error) {
      console.error('文件上传失败:', error);
      const errorMessage = error.response?.data?.error ||
        error.response?.data?.message ||
        '文件上传失败，请重试';
      setUploadError(errorMessage);
      throw error;
    } finally {
      setUploading(false);
      setProgress(0);
    }
  };

  return (
    <Box sx={{ mt: 2 }}>
      <input
        accept="*"
        id="file-upload"
        type="file"
        multiple
        onChange={handleFileChange}
        style={{ display: 'none' }}
      />
      <label htmlFor="file-upload">
        <Button
          variant="outlined"
          component="span"
          startIcon={<CloudUpload />}
          disabled={uploading}
          sx={{ mb: 2 }}
        >
          选择文件
        </Button>
      </label>

      {uploadError && (
        <Alert severity="error" sx={{ mb: 2, fontSize: '0.875rem', p: 1.5 }}>
          {uploadError}
        </Alert>
      )}

      {progress > 0 && (
        <Box sx={{ mb: 2 }}>
          <Typography variant="caption" sx={{ display: 'block', mb: 0.5 }}>
            上传进度: {progress}%
          </Typography>
          <LinearProgress
            variant="determinate"
            value={progress}
            sx={{ height: 4, borderRadius: 2 }}
          />
        </Box>
      )}

      {files.length > 0 && (
        <Box sx={{ mb: 2 }}>
          <Typography variant="subtitle2" sx={{ mb: 1, display: 'flex', alignItems: 'center' }}>
            <AttachFile sx={{ mr: 0.5, fontSize: 16 }} />
            待上传文件 ({files.length})
          </Typography>
          <Box>
            {files.map((file, index) => (
              <Box
                key={index}
                sx={{
                  display: 'flex',
                  alignItems: 'center',
                  mb: 1,
                  p: 1,
                  borderRadius: 1,
                  backgroundColor: 'background.default',
                  border: '1px solid rgba(0,0,0,0.08)'
                }}
              >
                <FileIcon sx={{ mr: 1, color: 'text.secondary', fontSize: 18 }} />
                <Typography
                  variant="body2"
                  sx={{
                    flexGrow: 1,
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                    whiteSpace: 'nowrap'
                  }}
                >
                  {file.name}
                </Typography>
                <Typography variant="caption" color="text.secondary" sx={{ mr: 2 }}>
                  {(file.size / 1024).toFixed(1)} KB
                </Typography>
                <IconButton
                  size="small"
                  onClick={() => removeFile(index)}
                  disabled={uploading}
                  sx={{ color: 'text.secondary' }}
                >
                  <Clear fontSize="small" />
                </IconButton>
              </Box>
            ))}
          </Box>

          <Button
            variant="contained"
            onClick={handleUpload}
            disabled={uploading || files.length === 0}
            size="small"
            sx={{ mt: 1 }}
          >
            {uploading ? '上传中...' : '上传文件'}
          </Button>
        </Box>
      )}
    </Box>
  );
};

// 发布帖子对话框
const CreatePostDialog = ({ open, onClose, onSubmit }) => {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [category, setCategory] = useState('general');
  const [featuredImage, setFeaturedImage] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [attachments, setAttachments] = useState([]);
  const [submitError, setSubmitError] = useState('');

  const handleFeaturedImageChange = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setSubmitError('请选择图片文件');
      return;
    }

    const formData = new FormData();
    formData.append('file', file);

    try {
      const response = await api.post('/api/forum/posts/upload', formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      });

      const uploadedData = response.data.data || response.data;
      setFeaturedImage(uploadedData);
    } catch (error) {
      console.error('首页图片上传失败:', error);
      setSubmitError('首页图片上传失败');
    }
  };

  const handleFilesUploaded = (uploadedFiles) => {
    setAttachments(prev => [...prev, ...uploadedFiles]);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!title.trim()) {
      setSubmitError('请输入帖子标题');
      return;
    }
    if (!content.trim()) {
      setSubmitError('请输入帖子内容');
      return;
    }

    setIsSubmitting(true);
    setSubmitError('');

    try {
      const postData = {
        title: title.trim(),
        content: content.trim(),
        category: category,
        tags: [],
        excerpt: content.trim().substring(0, 100) + (content.length > 100 ? '...' : ''),
        featured_image_id: featuredImage?.ID || featuredImage?.id || null
      };

      const result = await onSubmit(postData);
      const postId = result?.post_id || result?.data?.post_id || result?.ID;

      if (postId && attachments.length > 0) {
        const attachmentIds = attachments.map(att => att.ID || att.id).filter(id => id);
        if (attachmentIds.length > 0) {
          try {
            await api.post('/api/forum/attachments/link-to-post', {
              post_id: postId,
              attachment_ids: attachmentIds
            });
          } catch (linkError) {
            console.error('附件关联失败:', linkError);
          }
        }
      }

      setTitle('');
      setContent('');
      setCategory('general');
      setFeaturedImage(null);
      setAttachments([]);
      onClose();

    } catch (error) {
      console.error('发布失败:', error);
      setSubmitError(
        error.response?.data?.error ||
        error.response?.data?.message ||
        '帖子发布失败，请重试'
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleClose = () => {
    if (!isSubmitting) {
      setTitle('');
      setContent('');
      setCategory('general');
      setFeaturedImage(null);
      setAttachments([]);
      setSubmitError('');
      onClose();
    }
  };

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      maxWidth="md"
      fullWidth
      PaperProps={{
        sx: { borderRadius: 2, maxHeight: '90vh', overflowY: 'auto' }
      }}
    >
      <DialogTitle sx={{
        borderBottom: '1px solid rgba(0,0,0,0.08)',
        pb: 2,
        fontWeight: 600
      }}>
        发布新帖子
      </DialogTitle>

      <form onSubmit={handleSubmit}>
        <DialogContent sx={{ pt: 3 }}>
          {submitError && (
            <Alert severity="error" sx={{ mb: 3 }} onClose={() => setSubmitError('')}>
              {submitError}
            </Alert>
          )}

          <TextField
            fullWidth
            label="帖子标题"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            margin="normal"
            required
            placeholder="请输入清晰的帖子标题"
            sx={{ mb: 2 }}
          />

          <FormControl fullWidth sx={{ mb: 2 }}>
            <InputLabel>分类</InputLabel>
            <Select
              value={category}
              label="分类"
              onChange={(e) => setCategory(e.target.value)}
            >
              <MenuItem value="general">通用</MenuItem>
              <MenuItem value="technology">技术</MenuItem>
              <MenuItem value="question">问答</MenuItem>
              <MenuItem value="share">分享</MenuItem>
              <MenuItem value="news">新闻</MenuItem>
            </Select>
          </FormControl>

          <Box sx={{ mb: 2 }}>
            <Typography variant="subtitle2" sx={{ mb: 1 }}>
              首页图片（可选）
            </Typography>
            <input
              accept="image/*"
              id="featured-image-upload"
              type="file"
              onChange={handleFeaturedImageChange}
              style={{ display: 'none' }}
            />
            <label htmlFor="featured-image-upload">
              <Button
                variant="outlined"
                component="span"
                startIcon={<ImageIcon />}
                sx={{ mb: 1 }}
              >
                选择首页图片
              </Button>
            </label>
            {featuredImage && (
              <Box sx={{ mt: 1 }}>
                <img
                  src={getFileUrl(featuredImage.FilePath || featuredImage.file_path, api.defaults.baseURL)}
                  alt="首页图片预览"
                  style={{
                    maxWidth: '100%',
                    maxHeight: 200,
                    borderRadius: 8,
                    objectFit: 'cover'
                  }}
                />
                <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 0.5 }}>
                  {featuredImage.Filename || featuredImage.filename}
                </Typography>
                <Button
                  size="small"
                  onClick={() => setFeaturedImage(null)}
                  sx={{ mt: 0.5 }}
                >
                  移除图片
                </Button>
              </Box>
            )}
          </Box>

          <TextField
            fullWidth
            label="帖子内容"
            value={content}
            onChange={(e) => setContent(e.target.value)}
            multiline
            rows={6}
            margin="normal"
            required
            placeholder="请详细描述你的问题或分享内容"
          />

          <FileUploader onFilesUploaded={handleFilesUploaded} />

          {attachments.length > 0 && (
            <Box sx={{ mt: 2 }}>
              <Typography variant="subtitle2" sx={{ mb: 1, display: 'flex', alignItems: 'center' }}>
                <CheckCircle sx={{ mr: 0.5, fontSize: 16, color: 'success.main' }} />
                已上传附件 ({attachments.length})
              </Typography>
              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                {attachments.map((attachment, index) => {
                  const fileName = attachment.Filename || attachment.filename || '未命名文件';
                  return (
                    <Chip
                      key={index}
                      icon={<FileIcon />}
                      label={fileName}
                      variant="outlined"
                      size="small"
                      onDelete={() => {
                        const newAttachments = [...attachments];
                        newAttachments.splice(index, 1);
                        setAttachments(newAttachments);
                      }}
                      sx={{ maxWidth: 200 }}
                    />
                  );
                })}
              </Box>
            </Box>
          )}
        </DialogContent>

        <DialogActions sx={{ px: 3, pb: 3, borderTop: '1px solid rgba(0,0,0,0.05)' }}>
          <Button
            onClick={handleClose}
            disabled={isSubmitting}
            variant="outlined"
          >
            取消
          </Button>
          <Button
            type="submit"
            variant="contained"
            disabled={isSubmitting || !title.trim() || !content.trim()}
            sx={{ minWidth: 100 }}
          >
            {isSubmitting ? <CircularProgress size={20} /> : '发布帖子'}
          </Button>
        </DialogActions>
      </form>
    </Dialog>
  );
};

// 热门推荐组件 - 深蓝科技感
const RecommendedPosts = ({ posts, onPostClick }) => {
  const recommended = posts
    .sort((a, b) => (b.likes || 0) - (a.likes || 0))
    .slice(0, 5);

  if (recommended.length === 0) return null;

  return (
    <Paper sx={{
      p: 2.5,
      borderRadius: 3,
      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)', // 更清透的紫色渐变
      color: 'white',
      boxShadow: '0 8px 30px rgba(102, 126, 234, 0.25)',
      transition: 'transform 0.3s ease, box-shadow 0.3s ease',
      '&:hover': {
        transform: 'translateY(-2px)',
        boxShadow: '0 12px 40px rgba(102, 126, 234, 0.35)',
      }
    }}>
      <Typography variant="h6" sx={{ mb: 2, fontWeight: 600, display: 'flex', alignItems: 'center' }}>
        <FlashOn sx={{ mr: 1, fontSize: 20 }} />
        热门推荐
      </Typography>
      <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
        {recommended.map(post => (
          <Box
            key={post.ID || post.id}
            sx={{
              p: 1.5,
              borderRadius: 2,
              cursor: 'pointer',
              backgroundColor: 'rgba(255,255,255,0.15)',
              border: '1px solid rgba(255,255,255,0.25)',
              transition: 'all 0.2s ease',
              '&:hover': {
                backgroundColor: 'rgba(255,255,255,0.2)',
                transform: 'translateX(4px)'
              }
            }}
            onClick={() => onPostClick(post)}
          >
            <Typography variant="subtitle2" sx={{ fontWeight: 500, lineHeight: 1.3, mb: 0.5 }}>
              {post.title}
            </Typography>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <Typography variant="caption" sx={{ opacity: 0.9 }}>
                {post.author}
              </Typography>
              <Box sx={{ display: 'flex', gap: 1, alignItems: 'center' }}>
                <ThumbUp sx={{ fontSize: 12 }} />
                <Typography variant="caption" sx={{ opacity: 0.9 }}>
                  {post.likes || 0}
                </Typography>
              </Box>
            </Box>
          </Box>
        ))}
      </Box>
    </Paper>
  );
};

// 搜索和筛选组件
const SearchFilterBar = ({ onSearch, onCategoryChange, categories, selectedCategory }) => {
  const [searchTerm, setSearchTerm] = useState('');

  const handleSearch = (value) => {
    setSearchTerm(value);
    onSearch(value);
  };

  return (
    <Box sx={{
      display: 'flex',
      gap: 2,
      mb: 3,
      flexWrap: 'wrap',
      alignItems: 'center'
    }}>
      <TextField
        placeholder="搜索帖子..."
        value={searchTerm}
        onChange={(e) => handleSearch(e.target.value)}
        sx={{
          flexGrow: 1,
          minWidth: 200,
          '& .MuiOutlinedInput-root': {
            borderRadius: 2,
            '& fieldset': {
              borderColor: 'rgba(30, 136, 229, 0.2)',
            },
            '&:hover fieldset': {
              borderColor: 'rgba(30, 136, 229, 0.5)',
            },
            '&.Mui-focused fieldset': {
              borderColor: '#1e88e5',
              boxShadow: '0 0 0 2px rgba(30, 136, 229, 0.2)',
            }
          }
        }}
        InputProps={{
          startAdornment: (
            <InputAdornment position="start">
              <Search sx={{ color: 'text.secondary' }} />
            </InputAdornment>
          ),
        }}
      />

      <FormControl sx={{ minWidth: 120 }} size="small">
        <InputLabel>分类</InputLabel>
        <Select
          value={selectedCategory}
          label="分类"
          onChange={(e) => onCategoryChange(e.target.value)}
          startAdornment={
            <InputAdornment position="start">
              <Category sx={{ color: 'text.secondary', mr: 1 }} />
            </InputAdornment>
          }
        >
          <MenuItem value="all">全部分类</MenuItem>
          {categories.map(category => (
            <MenuItem key={category} value={category}>
              {category}
            </MenuItem>
          ))}
        </Select>
      </FormControl>
    </Box>
  );
};

// 工具函数
const formatTime = (dateString) => {
  if (!dateString) return '未知时间';
  try {
    const date = new Date(dateString);
    const now = new Date();
    const diffInMs = now - date;
    const diffInHours = diffInMs / (1000 * 60 * 60);

    if (diffInHours < 1) {
      const minutes = Math.floor(diffInMs / (1000 * 60));
      return minutes < 1 ? '刚刚' : `${minutes}分钟前`;
    } else if (diffInHours < 24) {
      return `${Math.floor(diffInHours)}小时前`;
    } else {
      return date.toLocaleDateString('zh-CN', {
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
    }
  } catch (error) {
    return '未知时间';
  }
};

// 单个帖子组件 - 扁宽卡片设计
const PostItem = ({ post, currentUser, onDelete,onEdit, onViewDetail, viewMode = 'card' }) => {
  const [menuAnchor, setMenuAnchor] = useState(null);
  const [isDeleting, setIsDeleting] = useState(false);

  const isAuthor = currentUser && post.author === currentUser.username;

  const handleMenuOpen = (event) => {
    event.stopPropagation();
    setMenuAnchor(event.currentTarget);
  };

  const handleMenuClose = () => {
    setMenuAnchor(null);
  };

  const handleDelete = async (event) => {
    event.stopPropagation();
    if (!window.confirm('确定要删除这个帖子吗？此操作不可撤销。')) {
      return;
    }

    setIsDeleting(true);
    try {
      await onDelete(post.ID || post.id);
    } catch (error) {
      console.error('删除失败:', error);
      window.alert('删除失败，请重试');
    } finally {
      setIsDeleting(false);
      handleMenuClose();
    }
  };

  const handleEdit = (event) => {
    event.stopPropagation();
    // 编辑功能实现
    console.log("post:",post)
    if (onEdit) {
      onEdit(post);
    }
    console.log('编辑帖子:', post.id);
    handleMenuClose();
  };

  const handleViewDetail = () => {
    window.location.assign(`/forum/posts/${post.ID || post.id}`);
  };

  const getContentPreview = () => {
    const content = post.content || post.excerpt || '';
    if (content.length > (viewMode === 'card' ? 60 : 150)) {
      return content.substring(0, viewMode === 'card' ? 60 : 150) + '...';
    }
    return content;
  };

  if (viewMode === 'card') {
    return (
      <Box sx={{ width: '100%', mb: 2 }}>
        <CompactPostCard onClick={handleViewDetail}>
          {/* 图片区域 - 固定宽度 */}
          {post.featured_image && (
            <Box sx={{
              width: '100%', // 固定宽度
              height: 140,
              flexShrink: 0,
              overflow: 'hidden',
              position: 'relative'
            }}>
              <img
                src={getFileUrl(post.featured_image.FilePath || post.featured_image.file_path, api.defaults.baseURL)}
                alt={post.title}
                style={{
                  width: '100%',
                  height: '100%',
                  objectFit: 'cover',
                  transition: 'transform 0.5s ease'
                }}
                onMouseOver={(e) => e.currentTarget.style.transform = 'scale(1.05)'}
                onMouseOut={(e) => e.currentTarget.style.transform = 'scale(1)'}
              />
            </Box>
          )}

          {/* 内容区域 - 占据剩余空间 */}
          <Box sx={{
            flex: 1,
            p: 2,
            display: 'flex',
            flexDirection: 'column',
            minWidth: 0 // 防止内容溢出
          }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 1 }}>
              <Typography
                variant="h6"
                sx={{
                  fontWeight: 600,
                  lineHeight: 1.3,
                  fontSize: '1rem',
                  flex: 1,
                  overflow: 'hidden',
                  display: '-webkit-box',
                  WebkitLineClamp: 2,
                  WebkitBoxOrient: 'vertical'
                }}
              >
                {post.title || '无标题'}
              </Typography>

              {isAuthor && (
                <IconButton
                  size="small"
                  onClick={handleMenuOpen}
                  disabled={isDeleting}
                  sx={{
                    color: 'text.secondary',
                    ml: 1
                  }}
                >
                  <MoreVert />
                </IconButton>
              )}
            </Box>

            <Typography
              variant="body2"
              color="text.secondary"
              sx={{
                lineHeight: 1.4,
                flex: 1,
                overflow: 'hidden',
                display: '-webkit-box',
                WebkitLineClamp: 2,
                WebkitBoxOrient: 'vertical'
              }}
            >
              {getContentPreview()}
            </Typography>

            {/* 标签和信息区域 */}
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mt: 1 }}>
              <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
                {post.category && post.category !== 'general' && (
                  <Chip
                    label={post.category}
                    size="small"
                    color="primary"
                    variant="outlined"
                  />
                )}
                {post.attachments && post.attachments.length > 0 && (
                  <Chip
                    icon={<AttachFile sx={{ fontSize: 14 }} />}
                    label={post.attachments.length}
                    size="small"
                    variant="outlined"
                  />
                )}
              </Box>

              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, flexShrink: 0 }}>
                <Person sx={{ fontSize: 14, color: 'text.secondary' }} />
                <Typography variant="caption" color="text.secondary">
                  {post.author}
                </Typography>
                <Typography variant="caption" color="text.secondary" sx={{ ml: 1 }}>
                  {formatTime(post.created_at)}
                </Typography>
              </Box>
            </Box>
          </Box>
        </CompactPostCard>

        {/* 操作菜单 */}
        <Menu
          anchorEl={menuAnchor}
          open={Boolean(menuAnchor)}
          onClose={handleMenuClose}
          onClick={(e) => e.stopPropagation()}
        >
          <MenuItem onClick={handleEdit}>
            <Edit sx={{ mr: 1, fontSize: 18 }} />
            编辑
          </MenuItem>
          <MenuItem onClick={handleDelete} disabled={isDeleting}>
            <Delete sx={{ mr: 1, fontSize: 18 }} />
            {isDeleting ? '删除中...' : '删除'}
          </MenuItem>
        </Menu>
      </Box>
    );
  }

  // 列表视图
  return (
    <PostCard sx={{
      height: 'auto',
      maxHeight: '180px',
      overflow: 'hidden',
      display: 'flex',
      flexDirection: 'column',
    }}>
      <Box sx={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'flex-start',
        mb: 1
      }}>
        <Typography
          variant="h6"
          sx={{
            fontWeight: 600,
            lineHeight: 1.4,
            flex: 1,
            cursor: 'pointer',
            '&:hover': { color: 'primary.main' },
            transition: 'color 0.2s ease'
          }}
          onClick={handleViewDetail}
        >
          {post.title || '无标题'}
        </Typography>

        {isAuthor && (
          <>
            <IconButton
              size="small"
              onClick={handleMenuOpen}
              disabled={isDeleting}
              sx={{ color: 'text.secondary' }}
            >
              <MoreVert />
            </IconButton>
            <Menu
              anchorEl={menuAnchor}
              open={Boolean(menuAnchor)}
              onClose={handleMenuClose}
            >
              <MenuItem onClick={handleEdit}>
                <Edit sx={{ mr: 1, fontSize: 18 }} />
                编辑
              </MenuItem>
              <MenuItem onClick={handleDelete} disabled={isDeleting}>
                <Delete sx={{ mr: 1, fontSize: 18 }} />
                {isDeleting ? '删除中...' : '删除'}
              </MenuItem>
            </Menu>
          </>
        )}
      </Box>

      <Box sx={{ cursor: 'pointer', flexGrow: 1 }} onClick={handleViewDetail}>
        <Typography
          variant="body1"
          color="text.secondary"
          sx={{
            lineHeight: 1.6,
            mb: 1,
            overflow: 'hidden',
            display: '-webkit-box',
            WebkitLineClamp: 2,
            WebkitBoxOrient: 'vertical'
          }}
        >
          {getContentPreview()}
        </Typography>

        <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mb: 1 }}>
          {post.category && post.category !== 'general' && (
            <Chip
              label={post.category}
              size="small"
              color="primary"
              variant="outlined"
            />
          )}
          {post.attachments && post.attachments.length > 0 && (
            <Chip
              icon={<AttachFile sx={{ fontSize: 16 }} />}
              label={`${post.attachments.length} 个附件`}
              size="small"
              variant="outlined"
            />
          )}
        </Box>
      </Box>

      <ActionSection sx={{
        paddingTop: 1,
        marginTop: 1
      }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
          <Button
            size="small"
            startIcon={<ThumbUp />}
            sx={{
              color: 'text.secondary',
              minWidth: 'auto',
              '&:hover': {
                backgroundColor: 'rgba(25, 118, 210, 0.04)',
                color: 'primary.main'
              }
            }}
          >
            {post.likes || 0}
          </Button>

          <Button
            size="small"
            startIcon={<Comment />}
            sx={{
              color: 'text.secondary',
              minWidth: 'auto',
              '&:hover': {
                backgroundColor: 'rgba(0, 0, 0, 0.04)',
                color: 'text.primary'
              }
            }}
          >
            {post.comments || 0}
          </Button>

          <Button
            size="small"
            startIcon={<Visibility />}
            onClick={handleViewDetail}
            sx={{
              color: 'primary.main',
              minWidth: 'auto',
              '&:hover': {
                backgroundColor: 'rgba(25, 118, 210, 0.04)',
              }
            }}
          >
            查看详情
          </Button>
        </Box>

        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, flexWrap: 'wrap' }}>
          <Person sx={{ color: 'text.secondary', fontSize: 16 }} />
          <Typography variant="caption" color="text.secondary">
            {post.author || '匿名用户'}
          </Typography>
          <Typography variant="caption" color="text.secondary">
            ·
          </Typography>
          <Typography variant="caption" color="text.secondary">
            {post.views || 0} 阅读
          </Typography>
          <Typography variant="caption" color="text.secondary">
            · {formatTime(post.created_at)}
          </Typography>
        </Box>
      </ActionSection>
    </PostCard>
  );
};

// 论坛API服务
const forumService = {
  getPosts: async () => {
    try {
      const response = await api.get('/api/forum/posts');
      return response.data.data || response.data;
    } catch (error) {
      console.error('获取帖子列表失败:', error);
      throw error;
    }
  },

  createPost: async (postData) => {
    try {
      console.log('📤 发送创建帖子请求:', postData);
      const response = await api.post('/api/forum/posts', postData);
      return response.data.data || response.data;
    } catch (error) {
      console.error('创建帖子失败:', error);
      throw error;
    }
  },

  deletePost: async (postId) => {
    try {
      const response = await api.delete(`/api/forum/posts/${postId}`);
      return response.data.data || response.data;
    } catch (error) {
      console.error('删除帖子失败:', error);
      throw error;
    }
  }
};

// 主论坛组件
const ForumSection = ({ config }) => {
  const { user: currentUser } = useAuth();
  const [posts, setPosts] = useState([]);
  const [filteredPosts, setFilteredPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [editDialogOpen, setEditDialogOpen] = useState(false); // 新增：编辑对话框状态
  const [editingPost, setEditingPost] = useState(null); // 新增：正在编辑的帖
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: '',
    severity: 'success'
  });

  const categories = ['technology', 'question', 'share', 'news'];
  const viewMode = config?.forum?.viewMode || 'card';

  const loadPosts = useCallback(async () => {
    setLoading(true);
    try {
      const result = await forumService.getPosts();
      const postsData = result.posts || result.Posts || result || [];
      setPosts(postsData);
      setFilteredPosts(postsData);
      setError('');
    } catch (err) {
      console.error('❌ 加载帖子失败:', err);
      setError('加载帖子失败，请刷新页面重试');
      setPosts([]);
      setFilteredPosts([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    let filtered = posts;

    if (selectedCategory !== 'all') {
      filtered = filtered.filter(post => post.category === selectedCategory);
    }

    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      filtered = filtered.filter(post =>
        post.title?.toLowerCase().includes(term) ||
        post.content?.toLowerCase().includes(term) ||
        post.author?.toLowerCase().includes(term)
      );
    }

    setFilteredPosts(filtered);
  }, [posts, searchTerm, selectedCategory]);

  // 新增：编辑帖子函数
  const handleEditPost = async (postData) => {
    if (!editingPost) return;

    try {
      const response = await api.put(`/api/forum/posts/${editingPost.ID || editingPost.id}`, postData);
      showSnackbar('帖子更新成功！');
      await loadPosts();
      return response.data.data || response.data;
    } catch (error) {
      console.error('❌ 更新帖子错误:', error);
      showSnackbar(
        error.response?.data?.message || error.response?.data?.error || '更新失败，请重试',
        'error'
      );
      throw error;
    }
  };

  // 新增：打开编辑对话框
  const handleOpenEditDialog = (post) => {
    setEditingPost(post);
    setEditDialogOpen(true);
  };

  // 新增：关闭编辑对话框
  const handleCloseEditDialog = () => {
    setEditingPost(null);
    setEditDialogOpen(false);
  };
  // 新增编辑帖子对话框组件
const EditPostDialog = ({ open, onClose, onSubmit, post }) => {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [category, setCategory] = useState('general');
  const [featuredImage, setFeaturedImage] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [attachments, setAttachments] = useState([]);
  const [submitError, setSubmitError] = useState('');
  const [loadingAttachments, setLoadingAttachments] = useState(false);

  // 获取帖子附件
  const fetchAttachments = useCallback(async (postId) => {
    if (!postId) return;

    setLoadingAttachments(true);
    try {
      const response = await api.get(`/api/forum/posts/${postId}/attachments`);
      const attachmentsData = response.data.data || response.data || [];
      setAttachments(attachmentsData);
    } catch (error) {
      console.error('获取附件失败:', error);
      // 不显示错误，因为附件可能不存在
    } finally {
      setLoadingAttachments(false);
    }
  }, []);

  // 初始化表单数据
  useEffect(() => {
    if (post) {
      setTitle(post.title || '');
      setContent(post.content || '');
      setCategory(post.category || 'general');
      setFeaturedImage(post.featured_image || null);

      // 如果有帖子ID，获取附件
      const postId = post.ID || post.id;
      if (postId) {
        fetchAttachments(postId);
      } else {
        setAttachments(post.attachments || []);
      }
    }
  }, [post, fetchAttachments]);

  const handleFeaturedImageChange = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setSubmitError('请选择图片文件');
      return;
    }

    const formData = new FormData();
    formData.append('file', file);

    try {
      const response = await api.post('/api/forum/posts/upload', formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      });

      const uploadedData = response.data.data || response.data;
      setFeaturedImage(uploadedData);
    } catch (error) {
      console.error('首页图片上传失败:', error);
      setSubmitError('首页图片上传失败');
    }
  };

  const handleFilesUploaded = (uploadedFiles) => {
    setAttachments(prev => [...prev, ...uploadedFiles]);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!title.trim()) {
      setSubmitError('请输入帖子标题');
      return;
    }
    if (!content.trim()) {
      setSubmitError('请输入帖子内容');
      return;
    }

    setIsSubmitting(true);
    setSubmitError('');

    try {
      const postData = {
        title: title.trim(),
        content: content.trim(),
        category: category,
        tags: [],
        excerpt: content.trim().substring(0, 100) + (content.length > 100 ? '...' : ''),
        featured_image_id: featuredImage?.ID || featuredImage?.id || null
      };

      await onSubmit(postData);

      setTitle('');
      setContent('');
      setCategory('general');
      setFeaturedImage(null);
      setAttachments([]);
      onClose();

    } catch (error) {
      console.error('更新失败:', error);
      setSubmitError(
        error.response?.data?.error ||
        error.response?.data?.message ||
        '帖子更新失败，请重试'
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleClose = () => {
    if (!isSubmitting) {
      setTitle('');
      setContent('');
      setCategory('general');
      setFeaturedImage(null);
      setAttachments([]);
      setSubmitError('');
      onClose();
    }
  };

  const removeAttachment = (index) => {
    const newAttachments = [...attachments];
    newAttachments.splice(index, 1);
    setAttachments(newAttachments);
  };

  if (!post) return null;

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      maxWidth="md"
      fullWidth
      PaperProps={{
        sx: { borderRadius: 2, maxHeight: '90vh', overflowY: 'auto' }
      }}
    >
      <DialogTitle sx={{
        borderBottom: '1px solid rgba(0,0,0,0.08)',
        pb: 2,
        fontWeight: 600
      }}>
        编辑帖子
      </DialogTitle>

      <form onSubmit={handleSubmit}>
        <DialogContent sx={{ pt: 3 }}>
          {submitError && (
            <Alert severity="error" sx={{ mb: 3 }} onClose={() => setSubmitError('')}>
              {submitError}
            </Alert>
          )}

          <TextField
            fullWidth
            label="帖子标题"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            margin="normal"
            required
            placeholder="请输入清晰的帖子标题"
            sx={{ mb: 2 }}
          />

          <FormControl fullWidth sx={{ mb: 2 }}>
            <InputLabel>分类</InputLabel>
            <Select
              value={category}
              label="分类"
              onChange={(e) => setCategory(e.target.value)}
            >
              <MenuItem value="general">通用</MenuItem>
              <MenuItem value="technology">技术</MenuItem>
              <MenuItem value="question">问答</MenuItem>
              <MenuItem value="share">分享</MenuItem>
              <MenuItem value="news">新闻</MenuItem>
            </Select>
          </FormControl>

          <Box sx={{ mb: 2 }}>
            <Typography variant="subtitle2" sx={{ mb: 1 }}>
              首页图片
            </Typography>

            {/* 显示当前首页图片 */}
            {post.featured_image && !featuredImage && (
              <Box sx={{ mb: 2 }}>
                <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 1 }}>
                  当前首页图片
                </Typography>
                <img
                  src={getFileUrl(post.featured_image.FilePath || post.featured_image.file_path, api.defaults.baseURL)}
                  alt="当前首页图片"
                  style={{
                    maxWidth: '100%',
                    maxHeight: 200,
                    borderRadius: 8,
                    objectFit: 'cover'
                  }}
                />
                <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 0.5 }}>
                  {post.featured_image.Filename || post.featured_image.filename}
                </Typography>
              </Box>
            )}

            <input
              accept="image/*"
              id="edit-featured-image-upload"
              type="file"
              onChange={handleFeaturedImageChange}
              style={{ display: 'none' }}
            />
            <label htmlFor="edit-featured-image-upload">
              <Button
                variant="outlined"
                component="span"
                startIcon={<ImageIcon />}
                sx={{ mb: 1 }}
              >
                {featuredImage ? '更换图片' : '选择新图片'}
              </Button>
            </label>

            {featuredImage && (
              <Box sx={{ mt: 1 }}>
                <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 1 }}>
                  新选择的图片
                </Typography>
                <img
                  src={getFileUrl(featuredImage.FilePath || featuredImage.file_path, api.defaults.baseURL)}
                  alt="新首页图片预览"
                  style={{
                    maxWidth: '100%',
                    maxHeight: 200,
                    borderRadius: 8,
                    objectFit: 'cover'
                  }}
                />
                <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 0.5 }}>
                  {featuredImage.Filename || featuredImage.filename}
                </Typography>
                <Button
                  size="small"
                  onClick={() => setFeaturedImage(null)}
                  sx={{ mt: 0.5 }}
                >
                  移除新图片
                </Button>
              </Box>
            )}
          </Box>

          <TextField
            fullWidth
            label="帖子内容"
            value={content}
            onChange={(e) => setContent(e.target.value)}
            multiline
            rows={6}
            margin="normal"
            required
            placeholder="请详细描述你的问题或分享内容"
            sx={{ mb: 2 }}
          />

          <FileUploader onFilesUploaded={handleFilesUploaded} />

          {/* 显示现有附件 */}
          {attachments.length > 0 && (
            <Box sx={{ mt: 2 }}>
              <Typography variant="subtitle2" sx={{ mb: 1, display: 'flex', alignItems: 'center' }}>
                <CheckCircle sx={{ mr: 0.5, fontSize: 16, color: 'success.main' }} />
                现有附件 ({attachments.length})
                {loadingAttachments && (
                  <CircularProgress size={16} sx={{ ml: 1 }} />
                )}
              </Typography>
              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                {attachments.map((attachment, index) => {
                  const fileName = attachment.Filename || attachment.filename || '未命名文件';
                  const fileUrl = getFileUrl(attachment.FilePath || attachment.file_path, api.defaults.baseURL);
                  return (
                    <Chip
                      key={index}
                      icon={<FileIcon />}
                      label={fileName}
                      variant="outlined"
                      size="small"
                      onDelete={() => removeAttachment(index)}
                      onClick={() => window.open(fileUrl, '_blank')}
                      sx={{ maxWidth: 200, cursor: 'pointer' }}
                    />
                  );
                })}
              </Box>
            </Box>
          )}
        </DialogContent>

        <DialogActions sx={{ px: 3, pb: 3, borderTop: '1px solid rgba(0,0,0,0.05)' }}>
          <Button
            onClick={handleClose}
            disabled={isSubmitting}
            variant="outlined"
          >
            取消
          </Button>
          <Button
            type="submit"
            variant="contained"
            disabled={isSubmitting || !title.trim() || !content.trim()}
            sx={{ minWidth: 100 }}
          >
            {isSubmitting ? <CircularProgress size={20} /> : '更新帖子'}
          </Button>
        </DialogActions>
      </form>
    </Dialog>
  );
};

  useEffect(() => {
    loadPosts();
  }, [loadPosts]);

  const showSnackbar = (message, severity = 'success') => {
    setSnackbar({ open: true, message, severity });
  };

  const handleCreatePost = async (postData) => {
    try {
      const result = await forumService.createPost(postData);
      showSnackbar('帖子发布成功！');
      await loadPosts();
      return result;
    } catch (error) {
      console.error('❌ 发布帖子错误:', error);
      showSnackbar(
        error.response?.data?.message || error.response?.data?.error || '发布失败，请重试',
        'error'
      );
      throw error;
    }
  };

  const handleDeletePost = async (postId) => {
    try {
      await forumService.deletePost(postId);
      showSnackbar('帖子删除成功！');
      await loadPosts();
    } catch (error) {
      console.error('❌ 删除帖子错误:', error);
      showSnackbar('删除失败，请重试', 'error');
      throw error;
    }
  };

  const handleViewDetail = (post) => {
    window.location.assign(`/forum/posts/${post.ID || post.id}`);
  };

  return (
    <Box sx={{
      minHeight: '100vh',
      background: 'linear-gradient(135deg, #f5f7fa 0%, #e4e8f0 100%)',
      py: 4
    }}>
      {/* 主容器 - 使用 Flex 布局替代 Grid */}
      <Box sx={{
        maxWidth: '1400px',
        margin: '0 auto',
        px: { xs: 2, sm: 3, md: 4 },
        display: 'flex',
        gap: 4
      }}>
        {/* 主内容区 - 占据 3/4 宽度 */}
        <Box sx={{ flex: 7, minWidth: 0 }}>
          {/* 科技感头部 */}


          {/* 操作栏 */}
          <Box sx={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            mb: 4,
            flexWrap: 'wrap',
            gap: 2
          }}>
            <Typography variant="h5" fontWeight="600" sx={{ color: 'text.primary' }}>
              最新帖子 ({filteredPosts.length})
            </Typography>

            <Box sx={{ display: 'flex', gap: 2, alignItems: 'center' }}>
              <Button
                variant="contained"
                startIcon={<Add />}
                onClick={() => setCreateDialogOpen(true)}
                size="large"
                sx={{
                  borderRadius: 2,
                  px: 3,
                  py: 1,
                  background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                  '&:hover': {
                     transform: 'translateY(-2px)',
                    boxShadow: '0 12px 40px rgba(102, 126, 234, 0.35)',
                  },
                  transition: 'all 0.3s ease'
                }}
              >
                发布帖子
              </Button>
            </Box>
          </Box>

          {/* 搜索筛选栏 */}
          <SearchFilterBar
            onSearch={setSearchTerm}
            onCategoryChange={setSelectedCategory}
            categories={categories}
            selectedCategory={selectedCategory}
          />

          {/* 错误提示 */}
          {error && (
            <Alert
              severity="error"
              sx={{ mb: 3, borderRadius: 2 }}
              onClose={() => setError('')}
            >
              {error}
            </Alert>
          )}

          {/* 帖子列表 */}
          {loading ? (
            <Box sx={{ display: 'flex', justifyContent: 'center', my: 8 }}>
              <CircularProgress size={40} sx={{ color: '#1e3c72' }} />
            </Box>
          ) : filteredPosts.length === 0 ? (
            <Paper
              elevation={0}
              sx={{
                p: 8,
                textAlign: 'center',
                borderRadius: 3,
                backgroundColor: 'white',
                boxShadow: '0 4px 20px rgba(0,0,0,0.08)'
              }}
            >
              <Typography variant="h6" color="text.secondary" gutterBottom>
                {searchTerm || selectedCategory !== 'all' ? '没有找到匹配的帖子' : '暂无帖子'}
              </Typography>
              <Typography variant="body1" color="text.secondary" sx={{ mb: 3 }}>
                {searchTerm || selectedCategory !== 'all' ? '尝试调整搜索条件' : '快来发布第一个帖子吧！'}
              </Typography>
              <Button
                variant="contained"
                startIcon={<Add />}
                onClick={() => setCreateDialogOpen(true)}
              >
                发布帖子
              </Button>
            </Paper>
          ) : viewMode === 'card' ? (
            // 卡片视图 - 单列扁宽布局
             <Box sx={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))',
                gap: 3,
                alignItems: 'stretch'
              }}>
                {filteredPosts.map(post => (
                  <PostItem
                    key={post.ID || post.id}
                    post={post}
                    currentUser={currentUser}
                    onDelete={handleDeletePost}
                    onEdit={handleOpenEditDialog} // 新增：传入编辑函数
                    onViewDetail={handleViewDetail}
                    viewMode="card"
                  />
                ))}
              </Box>
          ) : (
            // 列表视图
            <ListViewContainer>
              {filteredPosts.map(post => (
                <PostItem
                  key={post.ID || post.id}
                  post={post}
                  currentUser={currentUser}
                  onDelete={handleDeletePost}
                  onEdit={handleOpenEditDialog} // 新增：传入编辑函数
                  onViewDetail={handleViewDetail}
                  viewMode="list"
                />
              ))}
            </ListViewContainer>
          )}
        </Box>

        {/* 侧边栏 - 占据 1/4 宽度 */}
        <Box sx={{ flex: 1, minWidth: 180 }}>
          <RecommendedPosts
            posts={posts}
            onPostClick={handleViewDetail}
          />
        </Box>
      </Box>

      {/* 发布帖子对话框 */}
      <CreatePostDialog
        open={createDialogOpen}
        onClose={() => setCreateDialogOpen(false)}
        onSubmit={handleCreatePost}
      />

       <EditPostDialog
      open={editDialogOpen}
      onClose={handleCloseEditDialog}
      onSubmit={handleEditPost}
      post={editingPost}
    />

      {/* 提示消息 */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={3000}
        onClose={() => setSnackbar(prev => ({ ...prev, open: false }))}
        message={snackbar.message}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
      />
    </Box>
  );
};

// 页面入口
export default function ForumPage() {
  const [config, setConfig] = useState(null);
  const [loadingConfig, setLoadingConfig] = useState(true);

  useEffect(() => {
    const loadData = async () => {
      try {
        const response = await fetch('/config/site-config.json');
        const data = await response.json();
        setConfig(data);
      } catch (err) {
        console.error('加载配置失败:', err);
        setConfig({
          site: { name: '技术论坛' },
          forum: { viewMode: 'card' }
        });
      } finally {
        setLoadingConfig(false);
      }
    };

    loadData();
  }, []);

  if (loadingConfig) {
    return (
      <Box sx={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        minHeight: '100vh',
        background: 'linear-gradient(135deg, #f5f7fa 0%, #e4e8f0 100%)'
      }}>
        <CircularProgress size={40} sx={{ color: '#1e3c72' }} />
      </Box>
    );
  }

  return (
    <Layout config={config}>
      <ForumSection config={config} />
    </Layout>
  );
}