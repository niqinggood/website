import { createContext, useContext, useState, useEffect } from 'react';
import axios from 'axios';

// ===================== 1. 初始化上下文时打印日志 =====================
console.log('📌 AuthContext 模块加载 - 创建初始上下文');
const AuthContext = createContext({
  token: null,
  user: null,
  loading: false,
  login: () => {},
  logout: () => {},
  isAuthenticated: false,
  checkAuth: () => {}
});

// 从 Cookie 中读取指定键的值
const getCookie = (name) => {
  console.log(`🍪 调用 getCookie 函数，读取键: ${name}`);
  if (typeof document === 'undefined') {
    console.log('🍪 文档未加载（服务端渲染），返回 null');
    return null;
  }
  const value = `; ${document.cookie}`;
  const parts = value.split(`; ${name}=`);
  const result = parts.length === 2 ? parts.pop().split(';').shift() : null;
  console.log(`🍪 getCookie 结果: ${result || '未找到'}`);
  return result;
};

// 新增：从 localStorage 强制提取用户信息（兜底用）
const getFallbackUserFromLocalStorage = () => {
  console.log('⚠️  调用 getFallbackUserFromLocalStorage 兜底函数');
  try {
    if (typeof localStorage === 'undefined') {
      console.log('⚠️  localStorage 不可用，返回 null');
      return null;
    }

    // 1. 尝试读取完整 user 对象
    const storedUserStr = localStorage.getItem('user');
    console.log(`⚠️  兜底读取 localStorage.user 原始值: ${storedUserStr || '无'}`);
    if (storedUserStr) {
      const storedUser = JSON.parse(storedUserStr);
      if (storedUser?.username) {
        console.log(`⚠️  兜底成功：从 user 对象获取 username: ${storedUser.username}`);
        return storedUser;
      } else {
        console.log('⚠️  user 对象无 username 字段');
      }
    }

    // 2. 尝试读取单独的 username 字段
    const storedUsername = localStorage.getItem('username');
    console.log(`⚠️  兜底读取 localStorage.username: ${storedUsername || '无'}`);
    if (storedUsername) {
      console.log(`⚠️  兜底成功：从 username 字段获取: ${storedUsername}`);
      return { username: storedUsername, role: 'user' };
    }

    console.log('⚠️  兜底函数无可用数据，返回 null');
    return null;
  } catch (e) {
    console.error('⚠️  兜底函数报错:', e.message);
    return null;
  }
};

// ===================== 2. Provider 组件全流程日志 =====================
export const AuthProvider = ({ children }) => {
  console.log('🚀 AuthProvider 组件创建 - 初始化状态');
  const [token, setToken] = useState(null);
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(false);

  // 初始化：优先从 localStorage 读取，其次从 Cookie 读取
  useEffect(() => {
    console.log('📝 初始化 useEffect 触发 - 开始读取用户信息');

    // 检查 localStorage 是否可用
    if (typeof localStorage === 'undefined') {
      console.error('❌ 初始化失败：localStorage 不可用');
      return;
    }

    // 1. 尝试从 localStorage 读取
    const storedToken = localStorage.getItem('token');
    const storedUserStr = localStorage.getItem('user');
    console.log(`📁 步骤1：读取 localStorage.token: ${storedToken || '无'}`);
    console.log(`📁 步骤1：读取 localStorage.user 原始值: ${storedUserStr || '无'}`);

    if (storedToken && storedUserStr) {
      try {
        const storedUser = JSON.parse(storedUserStr);
        console.log(`📁 步骤1：解析 user 对象:`, storedUser);
        if (storedUser?.username) {
          setToken(storedToken);
          setUser(storedUser);
          if (storedToken !== 'virtual-token') {
            axios.defaults.headers.common['Authorization'] = `Bearer ${storedToken}`;
            console.log(`📁 步骤1：设置请求头 Authorization: Bearer ${storedToken}`);
          }
          console.log(`✅ 步骤1 成功：从 localStorage 恢复用户: ${storedUser.username}`);
          return;
        } else {
          console.log('❌ 步骤1 失败：user 对象无 username 字段');
        }
      } catch (e) {
        console.error(`❌ 步骤1 失败：解析 user 报错: ${e.message}`);
        localStorage.removeItem('user');
        localStorage.removeItem('token');
        console.log('❌ 步骤1：已清除损坏的 localStorage 数据');
      }
    } else {
      console.log('❌ 步骤1 失败：token 或 user 数据缺失');
    }

    // 2. 尝试从 Cookie 读取 username
    const cookieUsername = getCookie('username');
    console.log(`🍪 步骤2：读取 Cookie.username 结果: ${cookieUsername || '无'}`);
    if (cookieUsername) {
      const cookieUser = { username: cookieUsername, role: 'user', fromCookie: true };
      setUser(cookieUser);
      setToken('cookie-token');
      localStorage.setItem('user', JSON.stringify(cookieUser));
      localStorage.setItem('token', 'cookie-token');
      console.log(`✅ 步骤2 成功：从 Cookie 恢复用户: ${cookieUsername}`);
      return;
    } else {
      console.log('❌ 步骤2 失败：Cookie 无 username 数据');
    }

    // 3. 强制从 localStorage 兜底读取
    const fallbackUser = getFallbackUserFromLocalStorage();
    console.log(`⚠️  步骤3：兜底函数返回结果:`, fallbackUser);
    if (fallbackUser) {
      setUser(fallbackUser);
      const fallbackToken = localStorage.getItem('token') || localStorage.getItem('auth_token') || 'fallback-token';
      setToken(fallbackToken);
      console.log(`✅ 步骤3 成功：兜底逻辑恢复用户: ${fallbackUser.username}`);
      return;
    } else {
      console.log('❌ 步骤3 失败：兜底函数无可用数据');
    }

    // 4. 所有方式都失败
    console.log('❌ 所有读取方式失败 - user 设为 null');
    setUser(null);
    setToken(null);
  }, []);

  // 监听 user 为 null 时的兜底
  useEffect(() => {
    console.log(`🔍 user 状态变化监听 - 当前 user:`, user);
    if (user === null) {
      console.log('🔍 检测到 user 为 null - 触发再次兜底');
      const fallbackUser = getFallbackUserFromLocalStorage();
      if (fallbackUser) {
        setUser(fallbackUser);
        const fallbackToken = localStorage.getItem('token') || localStorage.getItem('auth_token') || 'fallback-token';
        setToken(fallbackToken);
        console.log(`✅ 监听兜底成功：恢复用户: ${fallbackUser.username}`);
      } else {
        console.log('❌ 监听兜底失败：无可用数据');
      }
    }
  }, [user]);

  // 登录方法
  const login = async (newToken, newUser) => {
    console.log('🔐 调用 login 方法 - 新用户信息:', newUser);
    if (!newUser?.username) {
      console.error('❌ login 失败：新用户无 username 字段');
      return;
    }
    setToken(newToken);
    setUser(newUser);
    localStorage.setItem('token', newToken);
    localStorage.setItem('user', JSON.stringify(newUser));
    localStorage.setItem('username', newUser.username);
    console.log(`🔐 login：已保存到 localStorage`);

    if (newUser.username) {
      document.cookie = `username=${newUser.username}; path=/; max-age=${60 * 60 * 24 * 7}`;
      console.log(`🔐 login：已保存到 Cookie`);
    }
    if (newToken && newToken !== 'virtual-token') {
      axios.defaults.headers.common['Authorization'] = `Bearer ${newToken}`;
      console.log(`🔐 login：已设置请求头`);
    }
    console.log(`✅ login 成功 - 当前用户: ${newUser.username}`);
  };

  // 登出方法
  const logout = () => {
    console.log('🚪 调用 logout 方法');
    setToken(null);
    setUser(null);
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    localStorage.removeItem('username');
    document.cookie = 'username=; path=/; max-age=0';
    delete axios.defaults.headers.common['Authorization'];
    console.log('✅ logout 成功 - 已清除所有数据');
  };

  // 认证检查
  const checkAuth = async () => {
    const result = !!user;
    console.log(`🔍 调用 checkAuth - 结果: ${result}（当前 user:`, user, `）`);
    return result;
  };

  // 暴露上下文值（打印最终上下文）
  const value = {
    token,
    user,
    loading,
    login,
    logout,
    checkAuth,
    isAuthenticated: !!user
  };
  console.log('📤 AuthProvider 提供的上下文值:', value);

  return (
    <AuthContext.Provider value={value}>
      {console.log('📦 AuthProvider 渲染子组件')}
      {children}
    </AuthContext.Provider>
  );
};

// ===================== 3. useAuth 钩子异常日志 =====================
export const useAuth = () => {
  console.log('🔧 调用 useAuth 钩子 - 尝试获取上下文');
  const context = useContext(AuthContext);

  // 第一步：检查 context 是否存在（是否被 AuthProvider 包裹）
  if (context === undefined) {
    console.error('❌ useAuth 严重错误：组件未被 AuthProvider 包裹！');
    throw new Error('useAuth must be used within an AuthProvider');
  }

  // 第二步：如果 context.user 为 null，尝试从 localStorage 读取并补全
  let finalUser = context.user;
  let finalToken = context.token;
  if (finalUser === null) {
    console.warn('⚠️ useAuth 警告：context.user 为 null，尝试从 localStorage 兜底');
    try {
      // 1. 读取 localStorage 中的 user 数据
      const storedUserStr = localStorage.getItem('user');
      console.log(`🔧 兜底读取 localStorage.user: ${storedUserStr || '无'}`);

      if (storedUserStr) {
        const storedUser = JSON.parse(storedUserStr);
        if (storedUser?.username) {
          finalUser = storedUser; // 用 localStorage 的 user 覆盖 null
          console.log(`✅ 兜底成功：从 localStorage 拿到用户: ${storedUser.username}`);
        }
      }

      // 2. 如果还没拿到，读取单独的 username 字段
      if (!finalUser) {
        const storedUsername = localStorage.getItem('username');
        console.log(`🔧 兜底读取 localStorage.username: ${storedUsername || '无'}`);
        if (storedUsername) {
          finalUser = { username: storedUsername, role: 'user' }; // 构建基础用户
          console.log(`✅ 兜底成功：从 username 字段拿到用户: ${storedUsername}`);
        }
      }

      // 3. 同步补全 token
      if (finalUser && !finalToken) {
        finalToken = localStorage.getItem('token') || localStorage.getItem('auth_token') || 'fallback-token';
        console.log(`🔧 兜底补充 token: ${finalToken}`);
      }

    } catch (e) {
      console.error('⚠️ useAuth 兜底失败:', e.message);
    }
  }

  // 第三步：返回补全后的上下文（优先用兜底的 user/token）
  const finalContext = {
    ...context,
    user: finalUser,
    token: finalToken,
    isAuthenticated: !!finalUser // 同步更新登录状态
  };

  // 打印最终结果
  if (finalContext.user) {
    console.log('✅ useAuth 最终返回：', { username: finalContext.user.username, token: finalContext.token });
  } else {
    console.warn('⚠️ useAuth 最终仍无用户信息');
  }

  return finalContext;
};

// ===================== 4. 初始打印（确认模块加载） =====================
console.log('📌 AuthContext 模块加载完成 - 等待使用');