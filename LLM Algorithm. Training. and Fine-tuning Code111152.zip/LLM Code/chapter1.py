-----------------------------------------------------------------------------------------------------------------


import torch
import torch.nn as nn
import torch.optim as optim
import random

# 设置随机种子
random.seed(42)
torch.manual_seed(42)

# 定义编码器
class Encoder(nn.Module):
    def __init__(self, input_dim, emb_dim, hidden_dim, n_layers, dropout):
        super(Encoder, self).__init__()
        self.embedding = nn.Embedding(input_dim, emb_dim)
        self.rnn = nn.LSTM(emb_dim, hidden_dim, n_layers, dropout=dropout, batch_first=True)
        self.dropout = nn.Dropout(dropout)
        
    def forward(self, src):
        embedded = self.dropout(self.embedding(src))  # (batch_size, src_len, emb_dim)
        outputs, (hidden, cell) = self.rnn(embedded)  # outputs: (batch_size, src_len, hidden_dim)
        return hidden, cell

# 定义解码器
class Decoder(nn.Module):
    def __init__(self, output_dim, emb_dim, hidden_dim, n_layers, dropout):
        super(Decoder, self).__init__()
        self.embedding = nn.Embedding(output_dim, emb_dim)
        self.rnn = nn.LSTM(emb_dim, hidden_dim, n_layers, dropout=dropout, batch_first=True)
        self.fc_out = nn.Linear(hidden_dim, output_dim)
        self.dropout = nn.Dropout(dropout)
        
    def forward(self, trg, hidden, cell):
        trg = trg.unsqueeze(1)  # 增加时间步维度 (batch_size, 1)
        embedded = self.dropout(self.embedding(trg))  # (batch_size, 1, emb_dim)
        output, (hidden, cell) = self.rnn(embedded, (hidden, cell))  # output: (batch_size, 1, hidden_dim)
        prediction = self.fc_out(output.squeeze(1))  # (batch_size, output_dim)
        return prediction, hidden, cell

# 定义Seq2Seq模型
class Seq2Seq(nn.Module):
    def __init__(self, encoder, decoder, device):
        super(Seq2Seq, self).__init__()
        self.encoder = encoder
        self.decoder = decoder
        self.device = device
        
    def forward(self, src, trg, teacher_forcing_ratio=0.5):
        batch_size = trg.shape[0]
        trg_len = trg.shape[1]
        trg_vocab_size = self.decoder.fc_out.out_features
        
        outputs = torch.zeros(batch_size, trg_len, trg_vocab_size).to(self.device)
        
        # 编码器的输出作为解码器的初始隐藏状态
        hidden, cell = self.encoder(src)
        input = trg[:, 0]  # 解码器的第一个输入是<sos>标记

        # 逐步解码目标序列
        for t in range(1, trg_len):
            output, hidden, cell = self.decoder(input, hidden, cell)
            outputs[:, t] = output
            teacher_force = random.random() < teacher_forcing_ratio
            top1 = output.argmax(1)  # 获取预测的最高分值
            input = trg[:, t] if teacher_force else top1
        
        return outputs

# 超参数设置
INPUT_DIM = 10  # 输入词典大小
OUTPUT_DIM = 10  # 输出词典大小
ENC_EMB_DIM = 16  # 编码器嵌入维度
DEC_EMB_DIM = 16  # 解码器嵌入维度
HIDDEN_DIM = 32  # 隐藏层维度
N_LAYERS = 2  # 编码器和解码器层数
ENC_DROPOUT = 0.5  # 编码器dropout
DEC_DROPOUT = 0.5  # 解码器dropout
DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

# 实例化模型
encoder = Encoder(INPUT_DIM, ENC_EMB_DIM, HIDDEN_DIM, N_LAYERS, ENC_DROPOUT)
decoder = Decoder(OUTPUT_DIM, DEC_EMB_DIM, HIDDEN_DIM, N_LAYERS, DEC_DROPOUT)
model = Seq2Seq(encoder, decoder, DEVICE).to(DEVICE)

# 损失函数和优化器
optimizer = optim.Adam(model.parameters(), lr=0.001)
criterion = nn.CrossEntropyLoss()

# 训练模型
def train(model, iterator, optimizer, criterion, clip):
    model.train()
    epoch_loss = 0
    for src, trg in iterator:
        src = src.to(DEVICE)
        trg = trg.to(DEVICE)
        
        optimizer.zero_grad()
        output = model(src, trg)
        output_dim = output.shape[-1]
        output = output[:, 1:].reshape(-1, output_dim)
        trg = trg[:, 1:].reshape(-1)
        loss = criterion(output, trg)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), clip)
        optimizer.step()
        epoch_loss += loss.item()
    return epoch_loss / len(iterator)

# 模拟数据生成器
def generate_dummy_data(batch_size, seq_len, vocab_size):
    src = torch.randint(1, vocab_size, (batch_size, seq_len))
    trg = torch.randint(1, vocab_size, (batch_size, seq_len))
    return src, trg

# 模拟训练
BATCH_SIZE = 32
SEQ_LEN = 5
VOCAB_SIZE = 10
N_EPOCHS = 5
CLIP = 1

for epoch in range(N_EPOCHS):
    src, trg = generate_dummy_data(BATCH_SIZE, SEQ_LEN, VOCAB_SIZE)
    iterator = [(src, trg)]
train_loss = train(model, iterator, optimizer, criterion, CLIP)
    print(f'Epoch: {epoch+1}, Train Loss: {train_loss:.4f}')


-----------------------------------------------------------------------------------------------------------------


import torch
import torch.nn as nn
import torch.optim as optim
import random

# 设置随机种子
random.seed(42)
torch.manual_seed(42)

# 定义编码器
class Encoder(nn.Module):
    def __init__(self, input_dim, emb_dim, hidden_dim, n_layers, dropout):
        super(Encoder, self).__init__()
        self.embedding = nn.Embedding(input_dim, emb_dim)
        self.rnn = nn.LSTM(emb_dim, hidden_dim, n_layers, dropout=dropout, batch_first=True)
        self.dropout = nn.Dropout(dropout)
        
    def forward(self, src):
        embedded = self.dropout(self.embedding(src))  # (batch_size, src_len, emb_dim)
        outputs, (hidden, cell) = self.rnn(embedded)  # outputs: (batch_size, src_len, hidden_dim)
        return hidden, cell

# 定义解码器
class Decoder(nn.Module):
    def __init__(self, output_dim, emb_dim, hidden_dim, n_layers, dropout):
        super(Decoder, self).__init__()
        self.embedding = nn.Embedding(output_dim, emb_dim)
        self.rnn = nn.LSTM(emb_dim, hidden_dim, n_layers, dropout=dropout, batch_first=True)
        self.fc_out = nn.Linear(hidden_dim, output_dim)
        self.dropout = nn.Dropout(dropout)
        
    def forward(self, trg, hidden, cell):
        trg = trg.unsqueeze(1)  # 增加时间步维度 (batch_size, 1)
        embedded = self.dropout(self.embedding(trg))  # (batch_size, 1, emb_dim)
        output, (hidden, cell) = self.rnn(embedded, (hidden, cell))  # output: (batch_size, 1, hidden_dim)
        prediction = self.fc_out(output.squeeze(1))  # (batch_size, output_dim)
        return prediction, hidden, cell

# 定义Seq2Seq模型
class Seq2Seq(nn.Module):
    def __init__(self, encoder, decoder, device):
        super(Seq2Seq, self).__init__()
        self.encoder = encoder
        self.decoder = decoder
        self.device = device
        
    def forward(self, src, trg, teacher_forcing_ratio=0.5):
        batch_size = trg.shape[0]
        trg_len = trg.shape[1]
        trg_vocab_size = self.decoder.fc_out.out_features
        
        outputs = torch.zeros(batch_size, trg_len, trg_vocab_size).to(self.device)
        
        # 编码器的输出作为解码器的初始隐藏状态
        hidden, cell = self.encoder(src)
        input = trg[:, 0]  # 解码器的第一个输入是<sos>标记

        # 逐步解码目标序列
        for t in range(1, trg_len):
            output, hidden, cell = self.decoder(input, hidden, cell)
            outputs[:, t] = output
            teacher_force = random.random() < teacher_forcing_ratio
            top1 = output.argmax(1)  # 获取预测的最高分值
            input = trg[:, t] if teacher_force else top1
        
        return outputs

# 超参数设置
INPUT_DIM = 10  # 输入词典大小
OUTPUT_DIM = 10  # 输出词典大小
ENC_EMB_DIM = 16  # 编码器嵌入维度
DEC_EMB_DIM = 16  # 解码器嵌入维度
HIDDEN_DIM = 32  # 隐藏层维度
N_LAYERS = 2  # 编码器和解码器层数
ENC_DROPOUT = 0.5  # 编码器dropout
DEC_DROPOUT = 0.5  # 解码器dropout
DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

# 实例化模型
encoder = Encoder(INPUT_DIM, ENC_EMB_DIM, HIDDEN_DIM, N_LAYERS, ENC_DROPOUT)
decoder = Decoder(OUTPUT_DIM, DEC_EMB_DIM, HIDDEN_DIM, N_LAYERS, DEC_DROPOUT)
model = Seq2Seq(encoder, decoder, DEVICE).to(DEVICE)

# 损失函数和优化器
optimizer = optim.Adam(model.parameters(), lr=0.001)
criterion = nn.CrossEntropyLoss()

# 训练模型
def train(model, iterator, optimizer, criterion, clip):
    model.train()
    epoch_loss = 0
    for src, trg in iterator:
        src = src.to(DEVICE)
        trg = trg.to(DEVICE)
        
        optimizer.zero_grad()
        output = model(src, trg)
        output_dim = output.shape[-1]
        output = output[:, 1:].reshape(-1, output_dim)
        trg = trg[:, 1:].reshape(-1)
        loss = criterion(output, trg)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), clip)
        optimizer.step()
        epoch_loss += loss.item()
    return epoch_loss / len(iterator)

# 模拟数据生成器
def generate_dummy_data(batch_size, seq_len, vocab_size):
    src = torch.randint(1, vocab_size, (batch_size, seq_len))
    trg = torch.randint(1, vocab_size, (batch_size, seq_len))
    return src, trg

# 模拟训练
BATCH_SIZE = 32
SEQ_LEN = 5
VOCAB_SIZE = 10
N_EPOCHS = 5
CLIP = 1

for epoch in range(N_EPOCHS):
    src, trg = generate_dummy_data(BATCH_SIZE, SEQ_LEN, VOCAB_SIZE)
    iterator = [(src, trg)]
    train_loss = train(model, iterator, optimizer, criterion, CLIP)
    print(f'Epoch: {epoch+1}, Train Loss: {train_loss:.4f}')


-----------------------------------------------------------------------------------------------------------------


import torch
import torch.nn as nn
import re
from collections import Counter
import random

# 设置随机种子
random.seed(42)
torch.manual_seed(42)

# 构建分词器，将文本转换为词汇索引
class Tokenizer:
    def __init__(self, texts, min_freq=1, max_vocab_size=10000):
        self.texts = texts
        self.min_freq = min_freq
        self.max_vocab_size = max_vocab_size
        self.vocab = self.build_vocab()

    # 清洗并分割文本
    def preprocess(self, text):
        text = text.lower()
        text = re.sub(r"[^a-zA-Z0-9\s]", "", text)
        return text.split()

    # 构建词汇表
    def build_vocab(self):
        word_counts = Counter()
        for text in self.texts:
            tokens = self.preprocess(text)
            word_counts.update(tokens)
        # 保留频率高于 min_freq 的单词
        vocab = {"<pad>": 0, "<unk>": 1}
        for word, freq in word_counts.most_common(self.max_vocab_size - 2):
            if freq >= self.min_freq:
                vocab[word] = len(vocab)
        return vocab

    # 将文本转化为索引序列
    def text_to_sequence(self, text):
        tokens = self.preprocess(text)
        return [self.vocab.get(token, self.vocab["<unk>"]) for token in tokens]

# 定义文本数据
texts = [
    "The quick brown fox jumps over the lazy dog",
    "An example of text tokenization for NLP",
    "PyTorch is widely used for deep learning tasks",
    "Natural language processing enables complex interactions",
]

# 实例化分词器
tokenizer = Tokenizer(texts)

# 转换示例文本为索引序列
text_sequence = tokenizer.text_to_sequence("The quick brown fox")
print("分词器输出的索引序列:", text_sequence)

# 定义嵌入层，将词汇索引转化为嵌入向量
class TextEmbedding(nn.Module):
    def __init__(self, vocab_size, emb_dim):
        super(TextEmbedding, self).__init__()
        self.embedding = nn.Embedding(vocab_size, emb_dim)
        
    def forward(self, x):
        return self.embedding(x)

# 超参数设置
VOCAB_SIZE = len(tokenizer.vocab)
EMB_DIM = 8  # 嵌入维度
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# 创建嵌入层实例
embedding_layer = TextEmbedding(VOCAB_SIZE, EMB_DIM).to(DEVICE)

# 转换文本序列为张量并传递到嵌入层
text_tensor = torch.tensor([text_sequence], dtype=torch.long).to(DEVICE)
embedded_output = embedding_layer(text_tensor)

print("嵌入层输出的形状:", embedded_output.shape)
print("嵌入向量:\n", embedded_output)

# 训练循环示例（模拟训练嵌入）
optimizer = torch.optim.Adam(embedding_layer.parameters(), lr=0.01)
criterion = nn.MSELoss()

# 假设目标是另一个随机嵌入向量，模拟损失计算
target_embedding = torch.rand(embedded_output.shape).to(DEVICE)
loss = criterion(embedded_output, target_embedding)

# 反向传播和优化
optimizer.zero_grad()
loss.backward()
optimizer.step()

print("训练后的损失:", loss.item())

# 显示嵌入层权重的部分
print("嵌入层的权重矩阵:\n", embedding_layer.embedding.weight[:5])


-----------------------------------------------------------------------------------------------------------------


import torch
import torch.nn as nn
import torch.optim as optim
import re
from collections import Counter
import random

# 设置随机种子
random.seed(42)
torch.manual_seed(42)

# 分词器，将文本转换为词汇索引
class Tokenizer:
    def __init__(self, texts, min_freq=1, max_vocab_size=10000):
        self.texts = texts
        self.min_freq = min_freq
        self.max_vocab_size = max_vocab_size
        self.vocab = self.build_vocab()

    # 清洗并分割文本
    def preprocess(self, text):
        text = text.lower()
        text = re.sub(r"[^a-zA-Z0-9\s]", "", text)
        return text.split()

    # 构建词汇表
    def build_vocab(self):
        word_counts = Counter()
        for text in self.texts:
            tokens = self.preprocess(text)
            word_counts.update(tokens)
        vocab = {"<pad>": 0, "<unk>": 1}
        for word, freq in word_counts.most_common(self.max_vocab_size - 2):
            if freq >= self.min_freq:
                vocab[word] = len(vocab)
        return vocab

    # 将文本转化为索引序列
    def text_to_sequence(self, text):
        tokens = self.preprocess(text)
        return [self.vocab.get(token, self.vocab["<unk>"]) for token in tokens]

# 定义示例文本数据
texts = [
    "The quick brown fox jumps over the lazy dog",
    "PyTorch is widely used for deep learning tasks",
    "Natural language processing enables complex interactions",
    "This example demonstrates text embedding in PyTorch",
]

# 实例化分词器
tokenizer = Tokenizer(texts)

# 定义示例文本，并转为索引序列
text_sequence = tokenizer.text_to_sequence("The quick brown fox")
print("分词后的索引序列:", text_sequence)

# 嵌入层定义，将词汇索引转化为嵌入向量
class TextEmbedding(nn.Module):
    def __init__(self, vocab_size, emb_dim):
        super(TextEmbedding, self).__init__()
        self.embedding = nn.Embedding(vocab_size, emb_dim)
        
    def forward(self, x):
        return self.embedding(x)

# 超参数设置
VOCAB_SIZE = len(tokenizer.vocab)
EMB_DIM = 8  # 嵌入向量的维度
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# 创建嵌入层实例
embedding_layer = TextEmbedding(VOCAB_SIZE, EMB_DIM).to(DEVICE)

# 将索引序列转换为张量并传递到嵌入层
text_tensor = torch.tensor([text_sequence], dtype=torch.long).to(DEVICE)
embedded_output = embedding_layer(text_tensor)

print("嵌入层输出的形状:", embedded_output.shape)
print("嵌入向量:\n", embedded_output)

# 嵌入层的训练示例，使用随机生成的目标嵌入向量计算损失
optimizer = optim.Adam(embedding_layer.parameters(), lr=0.01)
criterion = nn.MSELoss()

# 假设目标是另一个随机生成的嵌入向量
target_embedding = torch.rand(embedded_output.shape).to(DEVICE)
loss = criterion(embedded_output, target_embedding)

# 反向传播和优化
optimizer.zero_grad()
loss.backward()
optimizer.step()

print("训练后的损失:", loss.item())

# 显示嵌入层权重的部分
print("嵌入层的权重矩阵:\n", embedding_layer.embedding.weight[:5])


-----------------------------------------------------------------------------------------------------------------


import torch
import torch.nn as nn
import torch.nn.functional as F

# 设置随机种子
torch.manual_seed(42)

# 自注意力机制的实现
class SelfAttention(nn.Module):
    def __init__(self, embed_size, heads):
        super(SelfAttention, self).__init__()
        self.embed_size = embed_size
        self.heads = heads
        self.head_dim = embed_size // heads

        assert (
            self.head_dim * heads == embed_size
        ), "Embedding size需要是heads的整数倍"

        # 线性变换用于生成Q、K、V矩阵
        self.values = nn.Linear(self.head_dim, self.head_dim, bias=False)
        self.keys = nn.Linear(self.head_dim, self.head_dim, bias=False)
        self.queries = nn.Linear(self.head_dim, self.head_dim, bias=False)
        self.fc_out = nn.Linear(heads * self.head_dim, embed_size)

    def forward(self, values, keys, query, mask):
        N = query.shape[0]
        value_len, key_len, query_len = values.shape[1], keys.shape[1], query.shape[1]

        # 分头计算Q, K, V矩阵
        values = values.view(N, value_len, self.heads, self.head_dim)
        keys = keys.view(N, key_len, self.heads, self.head_dim)
        queries = query.view(N, query_len, self.heads, self.head_dim)

        values = self.values(values)
        keys = self.keys(keys)
        queries = self.queries(queries)

        # 计算Q与K的点积除以缩放因子
        energy = torch.einsum("nqhd,nkhd->nhqk", [queries, keys]) / (self.head_dim ** 0.5)

        if mask is not None:
            energy = energy.masked_fill(mask == 0, float("-1e20"))

        # 计算注意力权重
        attention = torch.softmax(energy, dim=-1)

        # 注意力权重乘以V
        out = torch.einsum("nhql,nlhd->nqhd", [attention, values]).reshape(
            N, query_len, self.heads * self.head_dim
        )

        return self.fc_out(out)

# 设置参数
embed_size = 128  # 嵌入维度
heads = 8  # 多头数量
seq_length = 10  # 序列长度
batch_size = 2  # 批大小

# 创建随机输入
values = torch.rand((batch_size, seq_length, embed_size))
keys = torch.rand((batch_size, seq_length, embed_size))
queries = torch.rand((batch_size, seq_length, embed_size))

# 初始化自注意力层
self_attention_layer = SelfAttention(embed_size, heads)

# 前向传播
output = self_attention_layer(values, keys, queries, mask=None)

print("输出的形状:", output.shape)
print("自注意力机制的输出:\n", output)

# 进一步展示注意力权重计算
class SelfAttentionWithWeights(SelfAttention):
    def forward(self, values, keys, query, mask):
        N = query.shape[0]
        value_len, key_len, query_len = values.shape[1], keys.shape[1], query.shape[1]

        values = values.view(N, value_len, self.heads, self.head_dim)
        keys = keys.view(N, key_len, self.heads, self.head_dim)
        queries = query.view(N, query_len, self.heads, self.head_dim)

        values = self.values(values)
        keys = self.keys(keys)
        queries = self.queries(queries)

        energy = torch.einsum("nqhd,nkhd->nhqk", [queries, keys]) / (self.head_dim ** 0.5)
        if mask is not None:
            energy = energy.masked_fill(mask == 0, float("-1e20"))

        attention = torch.softmax(energy, dim=-1)
        out = torch.einsum("nhql,nlhd->nqhd", [attention, values]).reshape(
            N, query_len, self.heads * self.head_dim
        )

        return self.fc_out(out), attention

# 使用带有权重输出的自注意力层
self_attention_layer_with_weights = SelfAttentionWithWeights(embed_size, heads)
output, attention_weights = self_attention_layer_with_weights(values, keys, queries, mask=None)

print("注意力权重形状:", attention_weights.shape)
print("注意力权重:\n", attention_weights)


-----------------------------------------------------------------------------------------------------------------


import torch
import torch.nn as nn
import torch.nn.functional as F

# 设置随机种子
torch.manual_seed(42)

# 定义多头注意力机制
class MultiHeadAttention(nn.Module):
    def __init__(self, embed_size, heads):
        super(MultiHeadAttention, self).__init__()
        self.embed_size = embed_size
        self.heads = heads
        self.head_dim = embed_size // heads

        assert (
            self.head_dim * heads == embed_size
        ), "Embedding size需要是heads的整数倍"

        # 线性变换生成Q、K、V矩阵
        self.values = nn.Linear(self.head_dim, self.head_dim, bias=False)
        self.keys = nn.Linear(self.head_dim, self.head_dim, bias=False)
        self.queries = nn.Linear(self.head_dim, self.head_dim, bias=False)
        self.fc_out = nn.Linear(heads * self.head_dim, embed_size)

    def forward(self, values, keys, query, mask):
        N = query.shape[0]
        value_len, key_len, query_len = values.shape[1], keys.shape[1], query.shape[1]

        # 分头计算Q, K, V矩阵
        values = values.view(N, value_len, self.heads, self.head_dim)
        keys = keys.view(N, key_len, self.heads, self.head_dim)
        queries = query.view(N, query_len, self.heads, self.head_dim)

        values = self.values(values)
        keys = self.keys(keys)
        queries = self.queries(queries)

        # 计算Q与K的点积除以缩放因子
        energy = torch.einsum("nqhd,nkhd->nhqk", [queries, keys]) / (self.head_dim ** 0.5)

        if mask is not None:
            energy = energy.masked_fill(mask == 0, float("-1e20"))

        # 计算注意力权重
        attention = torch.softmax(energy, dim=-1)

        # 注意力权重乘以V
        out = torch.einsum("nhql,nlhd->nqhd", [attention, values]).reshape(
            N, query_len, self.heads * self.head_dim
        )

        return self.fc_out(out)

# 设置参数
embed_size = 128  # 嵌入维度
heads = 8  # 多头数量
seq_length = 10  # 序列长度
batch_size = 2  # 批大小

# 创建随机输入
values = torch.rand((batch_size, seq_length, embed_size))
keys = torch.rand((batch_size, seq_length, embed_size))
queries = torch.rand((batch_size, seq_length, embed_size))

# 初始化多头注意力层
multi_head_attention_layer = MultiHeadAttention(embed_size, heads)

# 前向传播
output = multi_head_attention_layer(values, keys, queries, mask=None)

print("输出的形状:", output.shape)
print("多头注意力机制的输出:\n", output)

# 进一步展示注意力权重
class MultiHeadAttentionWithWeights(MultiHeadAttention):
    def forward(self, values, keys, query, mask):
        N = query.shape[0]
        value_len, key_len, query_len = values.shape[1], keys.shape[1], query.shape[1]

        values = values.view(N, value_len, self.heads, self.head_dim)
        keys = keys.view(N, key_len, self.heads, self.head_dim)
        queries = query.view(N, query_len, self.heads, self.head_dim)

        values = self.values(values)
        keys = self.keys(keys)
        queries = self.queries(queries)

        energy = torch.einsum("nqhd,nkhd->nhqk", [queries, keys]) / (self.head_dim ** 0.5)
        if mask is not None:
            energy = energy.masked_fill(mask == 0, float("-1e20"))

        attention = torch.softmax(energy, dim=-1)
        out = torch.einsum("nhql,nlhd->nqhd", [attention, values]).reshape(
            N, query_len, self.heads * self.head_dim
        )

        return self.fc_out(out), attention

# 使用带有权重输出的多头注意力层
multi_head_attention_with_weights = MultiHeadAttentionWithWeights(embed_size, heads)
output, attention_weights = multi_head_attention_with_weights(values, keys, queries, mask=None)

print("注意力权重形状:", attention_weights.shape)
print("注意力权重:\n", attention_weights)


-----------------------------------------------------------------------------------------------------------------


import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F

# 设置随机种子
torch.manual_seed(42)

# 定义残差块
class ResidualBlock(nn.Module):
    def __init__(self, in_channels, out_channels, stride=1, downsample=None):
        super(ResidualBlock, self).__init__()
        # 第一个卷积层
        self.conv1 = nn.Conv2d(in_channels, out_channels, kernel_size=3, stride=stride, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(out_channels)
        # 第二个卷积层
        self.conv2 = nn.Conv2d(out_channels, out_channels, kernel_size=3, stride=1, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(out_channels)
        self.downsample = downsample
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        identity = x
        # 如果需要对维度进行调整
        if self.downsample is not None:
            identity = self.downsample(x)

        # 卷积操作并激活
        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        out = self.conv2(out)
        out = self.bn2(out)

        # 将输入添加到输出
        out += identity
        out = self.relu(out)
        
        return out

# 构建简单的网络模型，包含多个残差块
class ResNetLike(nn.Module):
    def __init__(self, num_classes=10):
        super(ResNetLike, self).__init__()
        self.layer1 = nn.Conv2d(3, 64, kernel_size=3, stride=1, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(64)
        self.relu = nn.ReLU(inplace=True)

        # 使用残差块构建网络
        self.layer2 = ResidualBlock(64, 64)
        self.layer3 = ResidualBlock(64, 128, stride=2, downsample=nn.Sequential(
            nn.Conv2d(64, 128, kernel_size=1, stride=2, bias=False),
            nn.BatchNorm2d(128)
        ))
        self.layer4 = ResidualBlock(128, 128)

        # 全局平均池化和全连接层
        self.avgpool = nn.AdaptiveAvgPool2d((1, 1))
        self.fc = nn.Linear(128, num_classes)

    def forward(self, x):
        x = self.layer1(x)
        x = self.bn1(x)
        x = self.relu(x)

        x = self.layer2(x)
        x = self.layer3(x)
        x = self.layer4(x)

        x = self.avgpool(x)
        x = torch.flatten(x, 1)
        x = self.fc(x)
        
        return x

# 模拟输入
input_data = torch.randn(1, 3, 32, 32)  # Batch size of 1, 3 channels (RGB), 32x32 image size

# 创建模型
model = ResNetLike(num_classes=10)

# 前向传播
output = model(input_data)
print("网络输出:", output)

# 损失和优化器
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)

# 模拟训练步骤
target = torch.tensor([1])  # 假设的目标类别
optimizer.zero_grad()
loss = criterion(output, target)
loss.backward()
optimizer.step()

print("训练损失:", loss.item())

# 检查残差块中的参数更新情况
for name, param in model.layer2.named_parameters():
    print(f"{name}: {param.grad}")


-----------------------------------------------------------------------------------------------------------------


import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F

# 设置随机种子
torch.manual_seed(42)

# 定义带层归一化的神经网络层
class LayerNormBlock(nn.Module):
    def __init__(self, embed_size):
        super(LayerNormBlock, self).__init__()
        self.layer_norm = nn.LayerNorm(embed_size)
        self.fc = nn.Linear(embed_size, embed_size)
        self.relu = nn.ReLU()

    def forward(self, x):
        # 层归一化后进行全连接和激活操作
        out = self.layer_norm(x)
        out = self.fc(out)
        out = self.relu(out)
        return out

# 构建包含层归一化的简单网络模型
class SimpleLayerNormModel(nn.Module):
    def __init__(self, input_dim, hidden_dim, num_classes=10):
        super(SimpleLayerNormModel, self).__init__()
        self.layer1 = LayerNormBlock(input_dim)
        self.layer2 = LayerNormBlock(hidden_dim)
        self.layer3 = LayerNormBlock(hidden_dim)
        self.fc_out = nn.Linear(hidden_dim, num_classes)

    def forward(self, x):
        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.fc_out(x)
        return x

# 模拟输入数据
input_data = torch.randn(4, 128)  # Batch size of 4, feature size 128

# 创建模型
model = SimpleLayerNormModel(input_dim=128, hidden_dim=128, num_classes=10)

# 前向传播
output = model(input_data)
print("网络输出:", output)

# 损失和优化器
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)

# 模拟训练步骤
target = torch.randint(0, 10, (4,))  # 随机生成目标类别
optimizer.zero_grad()
loss = criterion(output, target)
loss.backward()
optimizer.step()

print("训练损失:", loss.item())

# 检查层归一化块中的参数更新情况
for name, param in model.layer1.named_parameters():
    print(f"{name}: {param.grad}")

# 测试模型在不同输入分布下的稳定性
test_input = torch.randn(4, 128) * 2 + 5  # 生成不同分布的输入数据
test_output = model(test_input)
print("测试数据的网络输出:", test_output)


-----------------------------------------------------------------------------------------------------------------


import torch
import torch.nn as nn
import math

# 位置编码器的实现
class PositionalEncoding(nn.Module):
    def __init__(self, embed_size, max_len=5000):
        super(PositionalEncoding, self).__init__()
        # 创建位置编码矩阵
        position = torch.arange(0, max_len).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, embed_size, 2) * -(math.log(10000.0) / embed_size))
        
        pe = torch.zeros(max_len, embed_size)
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        
        pe = pe.unsqueeze(0)  # 增加批次维度
        self.register_buffer('pe', pe)  # 将pe存入缓冲区，不参与梯度更新

    def forward(self, x):
        # 将位置编码与输入嵌入相加
        x = x + self.pe[:, :x.size(1), :]
        return x

# 定义带位置编码的嵌入层
class EmbeddingWithPositionalEncoding(nn.Module):
    def __init__(self, vocab_size, embed_size, max_len=5000):
        super(EmbeddingWithPositionalEncoding, self).__init__()
        self.embedding = nn.Embedding(vocab_size, embed_size)
        self.positional_encoding = PositionalEncoding(embed_size, max_len)
    
    def forward(self, x):
        x = self.embedding(x)
        x = self.positional_encoding(x)
        return x

# 超参数设置
vocab_size = 100  # 词汇量大小
embed_size = 64  # 嵌入维度
max_len = 50  # 最大序列长度
batch_size = 2  # 批次大小

# 模拟输入数据
input_data = torch.randint(0, vocab_size, (batch_size, max_len))  # 随机生成词汇索引

# 初始化带位置编码的嵌入层
embedding_layer = EmbeddingWithPositionalEncoding(vocab_size, embed_size, max_len)

# 前向传播计算位置编码
output = embedding_layer(input_data)
print("输出的形状:", output.shape)
print("带位置编码的嵌入输出:\n", output)

# 检查位置编码的具体值
print("位置编码矩阵的部分内容:\n", embedding_layer.positional_encoding.pe[0, :10, :10])

# 测试位置编码在不同序列长度下的稳定性
test_input_data = torch.randint(0, vocab_size, (batch_size, 30))  # 较短序列
test_output = embedding_layer(test_input_data)
print("不同长度序列的输出形状:", test_output.shape)
print("带位置编码的嵌入输出（短序列）:\n", test_output)


-----------------------------------------------------------------------------------------------------------------


import torch
import torch.nn as nn
import math
import random

# 位置编码器的实现，生成位置编码矩阵
class PositionalEncoding(nn.Module):
    def __init__(self, embed_size, max_len=5000):
        super(PositionalEncoding, self).__init__()
        position = torch.arange(0, max_len).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, embed_size, 2) * -(math.log(10000.0) / embed_size))
        
        pe = torch.zeros(max_len, embed_size)
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        
        pe = pe.unsqueeze(0)
        self.register_buffer('pe', pe)

    def forward(self, x):
        x = x + self.pe[:, :x.size(1), :]
        return x

# 定义带位置编码的嵌入层
class EmbeddingWithPositionalEncoding(nn.Module):
    def __init__(self, vocab_size, embed_size, max_len=5000):
        super(EmbeddingWithPositionalEncoding, self).__init__()
        self.embedding = nn.Embedding(vocab_size, embed_size)
        self.positional_encoding = PositionalEncoding(embed_size, max_len)
    
    def forward(self, x):
        x = self.embedding(x)
        x = self.positional_encoding(x)
        return x

# 模拟无序的输入数据生成器
def generate_shuffled_input(vocab_size, seq_length, batch_size):
    input_data = torch.randint(0, vocab_size, (batch_size, seq_length))
    shuffled_data = input_data.clone()
    for i in range(batch_size):
        idx = list(range(seq_length))
        random.shuffle(idx)
        shuffled_data[i] = input_data[i, idx]
    return input_data, shuffled_data

# 参数设置
vocab_size = 100  # 词汇量大小
embed_size = 64  # 嵌入维度
seq_length = 10  # 序列长度
batch_size = 2  # 批大小

# 初始化带位置编码的嵌入层
embedding_layer = EmbeddingWithPositionalEncoding(vocab_size, embed_size, max_len=seq_length)

# 生成原始和无序输入数据
input_data, shuffled_data = generate_shuffled_input(vocab_size, seq_length, batch_size)

# 前向传播原始输入数据
original_output = embedding_layer(input_data)
print("原始输入的带位置编码嵌入输出:\n", original_output)

# 前向传播无序输入数据
shuffled_output = embedding_layer(shuffled_data)
print("无序输入的带位置编码嵌入输出:\n", shuffled_output)

# 比较原始与无序输入的嵌入输出差异
difference = torch.mean(torch.abs(original_output - shuffled_output))
print("原始与无序输入输出的平均差异:", difference.item())

# 进一步展示位置编码在生成语义上如何保持一致性
class SimpleTransformerModel(nn.Module):
    def __init__(self, vocab_size, embed_size, num_heads, max_len):
        super(SimpleTransformerModel, self).__init__()
        self.embedding = EmbeddingWithPositionalEncoding(vocab_size, embed_size, max_len)
        self.attention = nn.MultiheadAttention(embed_dim=embed_size, num_heads=num_heads, batch_first=True)
        self.fc = nn.Linear(embed_size, vocab_size)
        
    def forward(self, x):
        x = self.embedding(x)
        attn_output, _ = self.attention(x, x, x)
        output = self.fc(attn_output)
        return output

# 设置模型参数
num_heads = 4  # 多头数量

# 初始化模型
model = SimpleTransformerModel(vocab_size, embed_size, num_heads, max_len=seq_length)

# 前向传播原始和无序输入数据
original_output = model(input_data)
shuffled_output = model(shuffled_data)

print("模型原始输入的输出:\n", original_output)
print("模型无序输入的输出:\n", shuffled_output)

# 比较模型在无序和原始输入下的语义差异
semantic_difference = torch.mean(torch.abs(original_output - shuffled_output))
print("模型在原始与无序输入下输出的平均语义差异:", semantic_difference.item())
