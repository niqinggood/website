-----------------------------------------------------------------------------------------------------------------


import torch
import torch.nn as nn
import torch.optim as optim
from transformers import BertModel, BertTokenizer
from torch.utils.data import DataLoader, TensorDataset

# Adapter模块的定义
class Adapter(nn.Module):
    def __init__(self, input_dim, bottleneck_dim=64):
        super(Adapter, self).__init__()
        self.down_project = nn.Linear(input_dim, bottleneck_dim)
        self.activation = nn.ReLU()
        self.up_project = nn.Linear(bottleneck_dim, input_dim)
    
    def forward(self, x):
        x_down = self.down_project(x)
        x_activated = self.activation(x_down)
        x_up = self.up_project(x_activated)
        return x + x_up  # 残差连接使模型更稳定

# Transformer层集成Adapter
class BertWithAdapter(nn.Module):
    def __init__(self, adapter_dim=64):
        super(BertWithAdapter, self).__init__()
        self.bert = BertModel.from_pretrained("bert-base-uncased")
        self.adapter_modules = nn.ModuleList([Adapter(self.bert.config.hidden_size, adapter_dim) for _ in range(self.bert.config.num_hidden_layers)])
    
    def forward(self, input_ids, attention_mask):
        outputs = self.bert(input_ids=input_ids, attention_mask=attention_mask, output_hidden_states=True)
        hidden_states = outputs.hidden_states
        
        # 遍历每层并应用Adapter模块
        for i, adapter in enumerate(self.adapter_modules):
            hidden_states[i + 1] = adapter(hidden_states[i + 1])
        
        return hidden_states[-1]

# 加载BERT分词器
tokenizer = BertTokenizer.from_pretrained("bert-base-uncased")

# 模拟数据加载
def prepare_data(texts, labels, tokenizer, max_length=128):
    encodings = tokenizer(texts, truncation=True, padding=True, max_length=max_length, return_tensors="pt")
    input_ids, attention_mask = encodings["input_ids"], encodings["attention_mask"]
    labels = torch.tensor(labels)
    return TensorDataset(input_ids, attention_mask, labels)

# 准备示例数据
texts = ["The model is effective for tuning.", "Adapters enable efficient fine-tuning."]
labels = [1, 0]
dataset = prepare_data(texts, labels, tokenizer)
dataloader = DataLoader(dataset, batch_size=2)

# 实例化模型与训练组件
model = BertWithAdapter(adapter_dim=64)
optimizer = optim.Adam(model.adapter_modules.parameters(), lr=1e-4)
criterion = nn.CrossEntropyLoss()

# 训练过程
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model.to(device)

def train_one_epoch(dataloader, model, criterion, optimizer):
    model.train()
    total_loss, correct_predictions = 0, 0
    
    for batch in dataloader:
        input_ids, attention_mask, labels = [x.to(device) for x in batch]
        
        # 前向传播
        outputs = model(input_ids=input_ids, attention_mask=attention_mask)
        logits = outputs[:, 0, :]  # 取出[CLS]标记的输出用于分类
        
        loss = criterion(logits, labels)
        
        # 反向传播
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        
        # 记录损失
        total_loss += loss.item()
        _, preds = torch.max(logits, dim=1)
        correct_predictions += torch.sum(preds == labels)
    
    avg_loss = total_loss / len(dataloader)
    accuracy = correct_predictions.double() / len(dataloader.dataset)
    return avg_loss, accuracy

# 运行训练
for epoch in range(3):
    avg_loss, accuracy = train_one_epoch(dataloader, model, criterion, optimizer)
    print(f"Epoch {epoch+1} - Loss: {avg_loss:.4f}, Accuracy: {accuracy:.4f}")


-----------------------------------------------------------------------------------------------------------------


import torch
import torch.nn as nn
import torch.optim as optim
from transformers import BertModel, BertTokenizer
from torch.utils.data import DataLoader, TensorDataset

# LoRA模块定义
class LoRA(nn.Module):
    def __init__(self, input_dim, rank=4):
        super(LoRA, self).__init__()
        self.rank = rank
        self.down_proj = nn.Linear(input_dim, rank, bias=False)  # 低秩分解的降维矩阵
        self.up_proj = nn.Linear(rank, input_dim, bias=False)  # 低秩分解的升维矩阵

    def forward(self, x):
        return self.up_proj(self.down_proj(x))

# 将LoRA集成到BERT的自注意力模块中
class BertWithLoRA(nn.Module):
    def __init__(self, lora_rank=4):
        super(BertWithLoRA, self).__init__()
        self.bert = BertModel.from_pretrained("bert-base-uncased")
        # 为每层自注意力模块增加LoRA
        self.lora_modules = nn.ModuleList([LoRA(self.bert.config.hidden_size, lora_rank) for _ in range(self.bert.config.num_hidden_layers)])

    def forward(self, input_ids, attention_mask):
        outputs = self.bert(input_ids=input_ids, attention_mask=attention_mask, output_hidden_states=True)
        hidden_states = outputs.hidden_states
        
        # 在每层应用LoRA模块进行微调
        for i, lora in enumerate(self.lora_modules):
            hidden_states[i + 1] = hidden_states[i + 1] + lora(hidden_states[i + 1])

        return hidden_states[-1]  # 返回最后一层输出作为分类特征

# 加载BERT分词器
tokenizer = BertTokenizer.from_pretrained("bert-base-uncased")

# 模拟数据加载
def prepare_data(texts, labels, tokenizer, max_length=128):
    encodings = tokenizer(texts, truncation=True, padding=True, max_length=max_length, return_tensors="pt")
    input_ids, attention_mask = encodings["input_ids"], encodings["attention_mask"]
    labels = torch.tensor(labels)
    return TensorDataset(input_ids, attention_mask, labels)

# 准备示例数据
texts = ["LoRA efficiently adapts large models.", "This technique uses low-rank updates."]
labels = [1, 0]
dataset = prepare_data(texts, labels, tokenizer)
dataloader = DataLoader(dataset, batch_size=2)

# 实例化模型与训练组件
model = BertWithLoRA(lora_rank=4)
optimizer = optim.Adam(model.lora_modules.parameters(), lr=1e-4)
criterion = nn.CrossEntropyLoss()

# 训练过程
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model.to(device)

def train_one_epoch(dataloader, model, criterion, optimizer):
    model.train()
    total_loss, correct_predictions = 0, 0
    
    for batch in dataloader:
        input_ids, attention_mask, labels = [x.to(device) for x in batch]
        
        # 前向传播
        outputs = model(input_ids=input_ids, attention_mask=attention_mask)
        logits = outputs[:, 0, :]  # 取出[CLS]标记的输出用于分类
        
        loss = criterion(logits, labels)
        
        # 反向传播
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        
        # 记录损失
        total_loss += loss.item()
        _, preds = torch.max(logits, dim=1)
        correct_predictions += torch.sum(preds == labels)
    
    avg_loss = total_loss / len(dataloader)
    accuracy = correct_predictions.double() / len(dataloader.dataset)
    return avg_loss, accuracy

# 运行训练
for epoch in range(3):
    avg_loss, accuracy = train_one_epoch(dataloader, model, criterion, optimizer)
    print(f"Epoch {epoch+1} - Loss: {avg_loss:.4f}, Accuracy: {accuracy:.4f}")


-----------------------------------------------------------------------------------------------------------------


import torch
import torch.nn as nn
import torch.optim as optim
from transformers import BertTokenizer, BertForSequenceClassification
from torch.utils.data import DataLoader, TensorDataset

# 定义Prompt Tuning模块，用于动态调整输入Prompt
class PromptTuning(nn.Module):
    def __init__(self, prompt_length, embed_dim):
        super(PromptTuning, self).__init__()
        self.prompt_embeddings = nn.Parameter(torch.randn(prompt_length, embed_dim))
    
    def forward(self, embedded_input):
        batch_size = embedded_input.size(0)
        prompt_embed = self.prompt_embeddings.unsqueeze(0).expand(batch_size, -1, -1)
        return torch.cat((prompt_embed, embedded_input), dim=1)

# 加载BERT模型和分词器
tokenizer = BertTokenizer.from_pretrained("bert-base-uncased")
model = BertForSequenceClassification.from_pretrained("bert-base-uncased", num_labels=2)

# 数据准备函数
def prepare_data(texts, labels, tokenizer, max_length=128):
    encodings = tokenizer(texts, truncation=True, padding=True, max_length=max_length, return_tensors="pt")
    input_ids, attention_mask = encodings["input_ids"], encodings["attention_mask"]
    labels = torch.tensor(labels)
    return TensorDataset(input_ids, attention_mask, labels)

# 定义示例数据
texts = ["The model performs well with prompt tuning.", "Prompt-based learning enhances performance."]
labels = [1, 0]
dataset = prepare_data(texts, labels, tokenizer)
dataloader = DataLoader(dataset, batch_size=2)

# Prompt Tuning参数
prompt_length = 5  # 自定义Prompt长度
embed_dim = model.config.hidden_size

# Prompt Tuning集成到BERT模型中
class BertWithPromptTuning(nn.Module):
    def __init__(self, prompt_length, model):
        super(BertWithPromptTuning, self).__init__()
        self.bert = model
        self.prompt_tuning = PromptTuning(prompt_length, embed_dim)
    
    def forward(self, input_ids, attention_mask):
        embedded_input = self.bert.bert.embeddings(input_ids)
        embedded_input_with_prompt = self.prompt_tuning(embedded_input)
        
        # 扩展注意力掩码以匹配Prompt长度
        extended_attention_mask = torch.cat([torch.ones((attention_mask.size(0), prompt_length), device=attention_mask.device), attention_mask], dim=1)
        outputs = self.bert(inputs_embeds=embedded_input_with_prompt, attention_mask=extended_attention_mask)
        
        return outputs.logits

# 实例化模型与训练组件
prompt_tuned_model = BertWithPromptTuning(prompt_length, model)
optimizer = optim.Adam([{'params': prompt_tuned_model.prompt_tuning.parameters()}], lr=1e-4)
criterion = nn.CrossEntropyLoss()

# 训练过程
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
prompt_tuned_model.to(device)

def train_one_epoch(dataloader, model, criterion, optimizer):
    model.train()
    total_loss, correct_predictions = 0, 0
    
    for batch in dataloader:
        input_ids, attention_mask, labels = [x.to(device) for x in batch]
        
        # 前向传播
        logits = model(input_ids=input_ids, attention_mask=attention_mask)
        
        loss = criterion(logits, labels)
        
        # 反向传播
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        
        # 记录损失
        total_loss += loss.item()
        _, preds = torch.max(logits, dim=1)
        correct_predictions += torch.sum(preds == labels)
    
    avg_loss = total_loss / len(dataloader)
    accuracy = correct_predictions.double() / len(dataloader.dataset)
    return avg_loss, accuracy

# 运行训练
for epoch in range(3):
    avg_loss, accuracy = train_one_epoch(dataloader, prompt_tuned_model, criterion, optimizer)
    print(f"Epoch {epoch+1} - Loss: {avg_loss:.4f}, Accuracy: {accuracy:.4f}")


-----------------------------------------------------------------------------------------------------------------


import torch
import torch.nn as nn
import torch.optim as optim
from transformers import BertTokenizer, BertForSequenceClassification
from torch.utils.data import DataLoader, TensorDataset

# 定义P-Tuning模块，用于生成可训练的Prompt嵌入
class PTuning(nn.Module):
    def __init__(self, prompt_length, embed_dim):
        super(PTuning, self).__init__()
        self.prompt_embeddings = nn.Parameter(torch.randn(prompt_length, embed_dim))
    
    def forward(self, embedded_input):
        batch_size = embedded_input.size(0)
        prompt_embed = self.prompt_embeddings.unsqueeze(0).expand(batch_size, -1, -1)
        return torch.cat((prompt_embed, embedded_input), dim=1)

# 加载BERT模型和分词器
tokenizer = BertTokenizer.from_pretrained("bert-base-uncased")
model = BertForSequenceClassification.from_pretrained("bert-base-uncased", num_labels=2)

# 数据准备函数
def prepare_data(texts, labels, tokenizer, max_length=128):
    encodings = tokenizer(texts, truncation=True, padding=True, max_length=max_length, return_tensors="pt")
    input_ids, attention_mask = encodings["input_ids"], encodings["attention_mask"]
    labels = torch.tensor(labels)
    return TensorDataset(input_ids, attention_mask, labels)

# 定义示例数据
texts = ["The model performs well with prompt tuning.", "Prompt-based learning enhances performance."]
labels = [1, 0]
dataset = prepare_data(texts, labels, tokenizer)
dataloader = DataLoader(dataset, batch_size=2)

# P-Tuning参数
prompt_length = 5  # 自定义Prompt长度
embed_dim = model.config.hidden_size

# 将P-Tuning集成到BERT模型中
class BertWithPTuning(nn.Module):
    def __init__(self, prompt_length, model):
        super(BertWithPTuning, self).__init__()
        self.bert = model
        self.p_tuning = PTuning(prompt_length, embed_dim)
    
    def forward(self, input_ids, attention_mask):
        embedded_input = self.bert.bert.embeddings(input_ids)
        embedded_input_with_prompt = self.p_tuning(embedded_input)
        
        # 扩展注意力掩码以匹配Prompt长度
        extended_attention_mask = torch.cat([torch.ones((attention_mask.size(0), prompt_length), device=attention_mask.device), attention_mask], dim=1)
        outputs = self.bert(inputs_embeds=embedded_input_with_prompt, attention_mask=extended_attention_mask)
        
        return outputs.logits

# 实例化模型与训练组件
p_tuned_model = BertWithPTuning(prompt_length, model)
optimizer = optim.Adam([{'params': p_tuned_model.p_tuning.parameters()}], lr=1e-4)
criterion = nn.CrossEntropyLoss()

# 训练过程
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
p_tuned_model.to(device)

def train_one_epoch(dataloader, model, criterion, optimizer):
    model.train()
    total_loss, correct_predictions = 0, 0
    
    for batch in dataloader:
        input_ids, attention_mask, labels = [x.to(device) for x in batch]
        
        # 前向传播
        logits = model(input_ids=input_ids, attention_mask=attention_mask)
        
        loss = criterion(logits, labels)
        
        # 反向传播
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        
        # 记录损失
        total_loss += loss.item()
        _, preds = torch.max(logits, dim=1)
        correct_predictions += torch.sum(preds == labels)
    
    avg_loss = total_loss / len(dataloader)
    accuracy = correct_predictions.double() / len(dataloader.dataset)
    return avg_loss, accuracy

# 运行训练
for epoch in range(3):
    avg_loss, accuracy = train_one_epoch(dataloader, p_tuned_model, criterion, optimizer)
    print(f"Epoch {epoch+1} - Loss: {avg_loss:.4f}, Accuracy: {accuracy:.4f}")


-----------------------------------------------------------------------------------------------------------------


import torch
import torch.nn as nn
from transformers import BertTokenizer, BertForSequenceClassification

# 定义Prompt Tuning模块
class PromptTuning(nn.Module):
    def __init__(self, prompt_length, embed_dim):
        super(PromptTuning, self).__init__()
        self.prompt_embeddings = nn.Parameter(torch.randn(prompt_length, embed_dim))
    
    def forward(self, embedded_input):
        batch_size = embedded_input.size(0)
        prompt_embed = self.prompt_embeddings.unsqueeze(0).expand(batch_size, -1, -1)
        return torch.cat((prompt_embed, embedded_input), dim=1)

# 定义P-Tuning模块
class PTuning(nn.Module):
    def __init__(self, prompt_length, embed_dim):
        super(PTuning, self).__init__()
        self.prompt_embeddings = nn.Parameter(torch.randn(prompt_length, embed_dim))
    
    def forward(self, embedded_input):
        batch_size = embedded_input.size(0)
        prompt_embed = self.prompt_embeddings.unsqueeze(0).expand(batch_size, -1, -1)
        return torch.cat((prompt_embed, embedded_input), dim=1)

# 将Prompt Tuning和P-Tuning集成到BERT模型中
class BertWithPromptAndPTuning(nn.Module):
    def __init__(self, prompt_length, model):
        super(BertWithPromptAndPTuning, self).__init__()
        self.bert = model
        self.prompt_tuning = PromptTuning(prompt_length, self.bert.config.hidden_size)
        self.p_tuning = PTuning(prompt_length, self.bert.config.hidden_size)
    
    def forward(self, input_ids, attention_mask):
        # 使用BERT嵌入层
        embedded_input = self.bert.bert.embeddings(input_ids)
        
        # 先进行Prompt Tuning
        embedded_input_with_prompt = self.prompt_tuning(embedded_input)
        
        # 然后再进行P-Tuning
        embedded_input_with_prompt_p = self.p_tuning(embedded_input_with_prompt)
        
        # 扩展注意力掩码以匹配Prompt长度
        extended_attention_mask = torch.cat([torch.ones((attention_mask.size(0), embedded_input_with_prompt_p.size(1) - attention_mask.size(1)), device=attention_mask.device), attention_mask], dim=1)
        
        outputs = self.bert(inputs_embeds=embedded_input_with_prompt_p, attention_mask=extended_attention_mask)
        
        return outputs.logits

# 初始化BERT模型和分词器
tokenizer = BertTokenizer.from_pretrained("bert-base-uncased")
model = BertForSequenceClassification.from_pretrained("bert-base-uncased", num_labels=2)

# 实例化组合微调模型
prompt_length = 5  # 自定义Prompt长度
tuned_model = BertWithPromptAndPTuning(prompt_length, model)

# 示例文本
texts = ["BERT模型在这篇文章中有显著提升。", "Prompt Tuning和P-Tuning在实际任务中表现很好。"]
encodings = tokenizer(texts, truncation=True, padding=True, max_length=128, return_tensors="pt")
input_ids, attention_mask = encodings["input_ids"], encodings["attention_mask"]

# 前向传播获取模型输出
logits = tuned_model(input_ids=input_ids, attention_mask=attention_mask)
predictions = torch.argmax(logits, dim=-1)

# 打印每条文本的预测结果
for i, text in enumerate(texts):
    label = "Positive" if predictions[i].item() == 1 else "Negative"
    print(f"Text: {text}\nPrediction: {label}\n")


-----------------------------------------------------------------------------------------------------------------


import torch
import torch.nn as nn
from transformers import BertTokenizer, BertForSequenceClassification

# 定义Prompt Tuning模块
class PromptTuning(nn.Module):
    def __init__(self, prompt_length, embed_dim):
        super(PromptTuning, self).__init__()
        self.prompt_embeddings = nn.Parameter(torch.randn(prompt_length, embed_dim))
    
    def forward(self, embedded_input):
        batch_size = embedded_input.size(0)
        prompt_embed = self.prompt_embeddings.unsqueeze(0).expand(batch_size, -1, -1)
        return torch.cat((prompt_embed, embedded_input), dim=1)

# 定义P-Tuning模块
class PTuning(nn.Module):
    def __init__(self, prompt_length, embed_dim):
        super(PTuning, self).__init__()
        self.prompt_embeddings = nn.Parameter(torch.randn(prompt_length, embed_dim))
    
    def forward(self, embedded_input):
        batch_size = embedded_input.size(0)
        prompt_embed = self.prompt_embeddings.unsqueeze(0).expand(batch_size, -1, -1)
        return torch.cat((prompt_embed, embedded_input), dim=1)

# 将Prompt Tuning和P-Tuning集成到BERT模型中
class BertWithPromptAndPTuning(nn.Module):
    def __init__(self, prompt_length, model):
        super(BertWithPromptAndPTuning, self).__init__()
        self.bert = model
        self.prompt_tuning = PromptTuning(prompt_length, self.bert.config.hidden_size)
        self.p_tuning = PTuning(prompt_length, self.bert.config.hidden_size)
    
    def forward(self, input_ids, attention_mask):
        # 使用BERT嵌入层
        embedded_input = self.bert.bert.embeddings(input_ids)
        
        # 先进行Prompt Tuning
        embedded_input_with_prompt = self.prompt_tuning(embedded_input)
        
        # 然后再进行P-Tuning
        embedded_input_with_prompt_p = self.p_tuning(embedded_input_with_prompt)
        
        # 扩展注意力掩码以匹配Prompt长度
        extended_attention_mask = torch.cat([torch.ones((attention_mask.size(0), embedded_input_with_prompt_p.size(1) - attention_mask.size(1)), device=attention_mask.device), attention_mask], dim=1)
        
        outputs = self.bert(inputs_embeds=embedded_input_with_prompt_p, attention_mask=extended_attention_mask)
        
        return outputs.logits

# 初始化BERT模型和分词器
tokenizer = BertTokenizer.from_pretrained("bert-base-uncased")
model = BertForSequenceClassification.from_pretrained("bert-base-uncased", num_labels=2)

# 实例化组合微调模型
prompt_length = 5  # 自定义Prompt长度
tuned_model = BertWithPromptAndPTuning(prompt_length, model)

# 示例长文本
long_text = """
这是一段关于自然语言处理的长文本。近年来，随着人工智能和机器学习技术的发展，自然语言处理逐渐成为热门领域，特别是在深度学习和神经网络的支持下，NLP取得了显著的进展。研究人员不断提出新模型、新算法，使得机器可以更好地理解、生成和处理人类语言。基于Transformer架构的模型（如BERT、GPT等）在文本分类、情感分析、机器翻译等任务中表现优异。即使是面对复杂的上下文，现代模型依然能够保持较高的准确率。这种进步让NLP在各行各业中都得到了广泛应用，从智能客服、舆情监控到文本生成、自动摘要，NLP技术逐步渗透到人们的日常生活中。
"""

# 数据编码
encodings = tokenizer(long_text, truncation=True, padding=True, max_length=512, return_tensors="pt")
input_ids, attention_mask = encodings["input_ids"], encodings["attention_mask"]

# 前向传播获取模型输出
logits = tuned_model(input_ids=input_ids, attention_mask=attention_mask)
predictions = torch.argmax(logits, dim=-1)

# 打印长文本的预测结果
label = "Positive" if predictions.item() == 1 else "Negative"
print(f"Text: {long_text[:100]}...")  # 打印部分文本内容
print(f"Prediction: {label}")
