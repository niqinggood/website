-----------------------------------------------------------------------------------------------------------------


# Step 1: 导入所需的库
import torch  # 导入PyTorch库
import torch.nn as nn  # 导入神经网络模块
import torch.optim as optim  # 导入优化器模块
import matplotlib.pyplot as plt  # 导入Matplotlib进行绘图

# Step 2: 定义一个简单的线性回归模型
class LinearRegressionModel(nn.Module):
    def __init__(self):
        super(LinearRegressionModel, self).__init__()  # 初始化父类
        self.linear = nn.Linear(1, 1)  # 定义一个线性层，输入和输出维度均为1

    def forward(self, x):
        return self.linear(x)  # 前向传播：计算输入x的线性输出

# Step 3: 生成一些示例数据（输入x_train和目标输出y_train）
torch.manual_seed(0)  # 设置随机种子，保证结果可重复
x_train = torch.linspace(0, 10, 100).view(-1, 1)  # 生成100个均匀分布的点作为输入数据
y_train = 2 * x_train + 3 + torch.randn(x_train.size()) * 2  # 生成对应的y数据，加上噪声模拟真实情况

# Step 4: 初始化模型
model = LinearRegressionModel()  # 创建模型实例

# Step 5: 定义AdamW优化器
optimizer = optim.AdamW(model.parameters(), lr=0.01, weight_decay=0.01)  # 学习率为0.01，权重衰减为0.01

# Step 6: 定义损失函数（均方误差损失）
criterion = nn.MSELoss()  # 使用均方误差（MSE）作为损失函数

# Step 7: 准备存储训练损失值的列表
losses = []  # 用于记录每个epoch的损失值

# Step 8: 训练模型
num_epochs = 200  # 设定训练的迭代次数

for epoch in range(num_epochs):
    # 前向传播
    y_pred = model(x_train)  # 使用模型计算预测值
    loss = criterion(y_pred, y_train)  # 计算预测值与真实值的损失

    # 记录损失值
    losses.append(loss.item())  # 将损失值添加到列表中

    # 后向传播与优化步骤
    optimizer.zero_grad()  # 清除上一步的梯度信息
    loss.backward()  # 计算当前损失对参数的梯度
    optimizer.step()  # 更新模型参数

    # 每隔20个epoch打印一次当前的损失值
    if (epoch + 1) % 20 == 0:
        print(f'Epoch [{epoch + 1}/{num_epochs}], Loss: {loss.item():.4f}')

# Step 9: 绘制训练损失曲线
plt.plot(range(num_epochs), losses)
plt.xlabel('Epoch')  # 横轴标签
plt.ylabel('Loss')  # 纵轴标签
plt.title('Training Loss with AdamW Optimizer')  # 图的标题
plt.show()  # 显示图像

# Step 10: 输出模型的最终参数
print("\n模型参数（权重和偏置）：")
for name, param in model.named_parameters():
    print(f"{name}: {param.data}")


-----------------------------------------------------------------------------------------------------------------


# Step 1: 导入所需库
import torch
import torch.nn as nn
import torch.optim as optim
import math
import matplotlib.pyplot as plt

# Step 2: 定义LAMB优化器
class LAMB(optim.Optimizer):
    def __init__(self, params, lr=0.01, betas=(0.9, 0.999), eps=1e-6, weight_decay=0.01):
        defaults = dict(lr=lr, betas=betas, eps=eps, weight_decay=weight_decay)
        super(LAMB, self).__init__(params, defaults)
    
    def step(self, closure=None):
        loss = None if closure is None else closure()
        for group in self.param_groups:
            for p in group['params']:
                if p.grad is None:
                    continue
                grad = p.grad.data
                state = self.state[p]

                # 初始化状态字典
                if len(state) == 0:
                    state['step'] = 0
                    state['exp_avg'] = torch.zeros_like(p.data)
                    state['exp_avg_sq'] = torch.zeros_like(p.data)

                # 更新一阶、二阶动量
                exp_avg, exp_avg_sq = state['exp_avg'], state['exp_avg_sq']
                beta1, beta2 = group['betas']
                state['step'] += 1
                exp_avg.mul_(beta1).add_(1 - beta1, grad)
                exp_avg_sq.mul_(beta2).addcmul_(1 - beta2, grad, grad)

                # 计算自适应学习率
                bias_correction1 = 1 - beta1 ** state['step']
                bias_correction2 = 1 - beta2 ** state['step']
                step_size = group['lr'] * math.sqrt(bias_correction2) / bias_correction1

                r1 = p.data.pow(2).sum().sqrt()
                r2 = exp_avg.pow(2).sum().sqrt()
                if r1 != 0 and r2 != 0:
                    trust_ratio = r1 / r2
                else:
                    trust_ratio = 1.0
                step_size = step_size * trust_ratio

                # 权重衰减项
                if group['weight_decay'] != 0:
                    p.data.add_(-group['weight_decay'] * group['lr'], p.data)

                # 更新参数
                p.data.add_(-step_size, exp_avg)
        return loss

# Step 3: 定义一个简单的模型和数据集
class SimpleLinearModel(nn.Module):
    def __init__(self):
        super(SimpleLinearModel, self).__init__()
        self.linear = nn.Linear(1, 1)

    def forward(self, x):
        return self.linear(x)

# 生成数据
torch.manual_seed(42)
x_train = torch.linspace(0, 10, 100).view(-1, 1)
y_train = 3 * x_train + 2 + torch.randn(x_train.size()) * 2

# Step 4: 初始化模型、LAMB优化器和损失函数
model = SimpleLinearModel()
optimizer = LAMB(model.parameters(), lr=0.01)
criterion = nn.MSELoss()

# Step 5: 训练模型
losses = []
num_epochs = 200

for epoch in range(num_epochs):
    # 前向传播
    y_pred = model(x_train)
    loss = criterion(y_pred, y_train)
    losses.append(loss.item())

    # 后向传播和参数更新
    optimizer.zero_grad()
    loss.backward()
    optimizer.step()

    if (epoch + 1) % 20 == 0:
        print(f'Epoch [{epoch + 1}/{num_epochs}], Loss: {loss.item():.4f}')

# Step 6: 绘制损失值
plt.plot(range(num_epochs), losses)
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.title('Training Loss with LAMB Optimizer')
plt.show()

# Step 7: 输出模型的参数
print("\n模型的权重和偏置：")
for name, param in model.named_parameters():
    print(f"{name}: {param.data}")


-----------------------------------------------------------------------------------------------------------------


import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset

# 设置随机种子以确保结果一致
torch.manual_seed(0)

# 创建示例数据
data_size, input_dim, output_dim, batch_size = 1000, 20, 2, 16
x = torch.randn(data_size, input_dim)
y = torch.randint(0, output_dim, (data_size,))
dataset = TensorDataset(x, y)
dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=True)

# 定义简单的线性模型
class SimpleModel(nn.Module):
    def __init__(self, input_dim, output_dim):
        super(SimpleModel, self).__init__()
        self.fc = nn.Linear(input_dim, output_dim)

    def forward(self, x):
        return self.fc(x)

model = SimpleModel(input_dim, output_dim)
criterion = nn.CrossEntropyLoss()
optimizer = optim.AdamW(model.parameters(), lr=0.001)

# 设置累积步数
accumulation_steps = 4  # 指定梯度累积的步数，模拟4倍批量训练

# 开始训练
for epoch in range(2):  # 假设训练2个epoch
    running_loss = 0.0
    optimizer.zero_grad()  # 初始化梯度
    
    for i, (inputs, labels) in enumerate(dataloader):
        # 前向传播
        outputs = model(inputs)
        loss = criterion(outputs, labels) / accumulation_steps  # 将损失值均分
        
        # 反向传播（累积梯度）
        loss.backward()
        
        # 当达到累积步数时，更新模型参数
        if (i + 1) % accumulation_steps == 0:
            optimizer.step()          # 执行参数更新
            optimizer.zero_grad()     # 清除累积的梯度

        # 记录损失
        running_loss += loss.item() * accumulation_steps
        if (i + 1) % (accumulation_steps * 5) == 0:
            print(f"Epoch [{epoch+1}], Step [{i+1}], Loss: {running_loss / (accumulation_steps * 5):.4f}")
            running_loss = 0.0

print("训练完成")


-----------------------------------------------------------------------------------------------------------------


import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
# 生成随机数据
input_size = 10
num_classes = 2
num_samples = 1000

X = torch.randn(num_samples, input_size)
y = torch.randint(0, num_classes, (num_samples,))

# 创建数据集和数据加载器
dataset = TensorDataset(X, y)
dataloader = DataLoader(dataset, batch_size=32, shuffle=True)
class SimpleModel(nn.Module):
    def __init__(self, input_size, num_classes):
        super(SimpleModel, self).__init__()
        self.fc = nn.Linear(input_size, num_classes)
    
    def forward(self, x):
        return self.fc(x)

model = SimpleModel(input_size, num_classes)
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)
# 设置梯度累积步数
accumulation_steps = 4
num_epochs = 5

for epoch in range(num_epochs):
    running_loss = 0.0
    for i, (inputs, labels) in enumerate(dataloader):
        # 前向传播
        outputs = model(inputs)
        loss = criterion(outputs, labels)
        
        # 反向传播 (计算梯度)
        loss = loss / accumulation_steps  # 梯度缩放
        loss.backward()
        
        # 每 accumulation_steps 执行一次梯度更新
        if (i + 1) % accumulation_steps == 0:
            optimizer.step()
            optimizer.zero_grad()
        
        running_loss += loss.item()
    
    print(f"Epoch [{epoch + 1}/{num_epochs}], Loss: {running_loss / len(dataloader):.4f}")


-----------------------------------------------------------------------------------------------------------------


import torch
import torch.optim as optim
import torch.nn as nn
import numpy as np

# 简单的模型
class SimpleModel(nn.Module):
    def __init__(self):
        super(SimpleModel, self).__init__()
        self.fc = nn.Linear(10, 1)

    def forward(self, x):
        return self.fc(x)

# 模型实例化
model = SimpleModel()
# 使用随机梯度下降优化器
optimizer = optim.SGD(model.parameters(), lr=0.1)

# 自定义线性衰减学习率调度器
def linear_decay(epoch, total_epochs, initial_lr, final_lr):
    # 根据线性衰减公式，计算当前的学习率
    return initial_lr - (initial_lr - final_lr) * (epoch / total_epochs)

# 超参数定义
total_epochs = 20
initial_lr = 0.1
final_lr = 0.01

# 记录学习率变化
lr_history = []

# 训练循环
for epoch in range(total_epochs):
    # 动态调整学习率
    lr = linear_decay(epoch, total_epochs, initial_lr, final_lr)
    for param_group in optimizer.param_groups:
        param_group['lr'] = lr
    lr_history.append(lr)
    
    # 模拟训练过程
    model.train()
    inputs = torch.randn(5, 10)
    labels = torch.randn(5, 1)
    
    optimizer.zero_grad()
    outputs = model(inputs)
    loss = nn.MSELoss()(outputs, labels)
    loss.backward()
    optimizer.step()
    
    # 打印当前的epoch和学习率
    print(f"Epoch {epoch+1}/{total_epochs}, Learning Rate: {lr:.6f}, Loss: {loss.item():.6f}")

# 显示学习率随epoch的变化
print("\nLearning rate schedule:")
for epoch, lr in enumerate(lr_history):
    print(f"Epoch {epoch+1}: Learning Rate = {lr:.6f}")


-----------------------------------------------------------------------------------------------------------------


import torch
import torch.nn as nn
import torch.optim as optim
import matplotlib.pyplot as plt

# 创建简单模型
model = nn.Linear(10, 2)

# 设置优化器
optimizer = optim.SGD(model.parameters(), lr=0.1)

# 设置余弦退火学习率调度器
scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=50, eta_min=0)

# 记录学习率变化
lr_history = []

# 模拟训练过程
for epoch in range(100):
    # 模拟一个训练步骤
    optimizer.zero_grad()
    output = model(torch.randn(32, 10))
    loss = output.sum()
    loss.backward()
    optimizer.step()
    
    # 调度器更新学习率
    scheduler.step()
    
    # 记录当前学习率
    current_lr = scheduler.get_last_lr()[0]
    lr_history.append(current_lr)
    print(f"Epoch {epoch+1}: Learning Rate = {current_lr:.5f}")

# 可视化学习率变化
plt.plot(range(1, 101), lr_history)
plt.xlabel("Epoch")
plt.ylabel("Learning Rate")
plt.title("Cosine Annealing Learning Rate Schedule")
plt.grid(True)
plt.show()


-----------------------------------------------------------------------------------------------------------------


import torch
import torch.nn as nn
import torch.optim as optim

# 定义一个简单的线性模型
class SimpleModel(nn.Module):
    def __init__(self):
        super(SimpleModel, self).__init__()
        self.linear = nn.Linear(10, 1)

    def forward(self, x):
        return self.linear(x)

model = SimpleModel()
optimizer = optim.Adam(model.parameters(), lr=0.001)  # 初始学习率
class WarmupScheduler(optim.lr_scheduler._LRScheduler):
    def __init__(self, optimizer, warmup_steps, final_lr, last_epoch=-1):
        self.warmup_steps = warmup_steps
        self.final_lr = final_lr
        super(WarmupScheduler, self).__init__(optimizer, last_epoch)

    def get_lr(self):
        # 计算学习率，前warmup_steps个step逐渐增大学习率，之后固定为final_lr
        if self._step_count < self.warmup_steps:
            return [self.final_lr * (self._step_count / self.warmup_steps) for _ in self.base_lrs]
        else:
            return [self.final_lr for _ in self.base_lrs]

# 设置Warmup调度器
warmup_steps = 100  # Warmup阶段的步数
final_lr = 0.01     # 最终学习率
scheduler = WarmupScheduler(optimizer, warmup_steps=warmup_steps, final_lr=final_lr)
# 模拟训练数据
data = torch.randn(32, 10)
target = torch.randn(32, 1)
criterion = nn.MSELoss()

# 开始训练，逐步更新学习率
for epoch in range(5):  # 训练5个epoch
    for batch in range(50):  # 每个epoch内包含50个批次
        optimizer.zero_grad()
        output = model(data)
        loss = criterion(output, target)
        loss.backward()
        optimizer.step()
        scheduler.step()  # 更新学习率

        # 打印当前学习率
        current_lr = scheduler.get_last_lr()[0]
        print(f"Epoch: {epoch + 1}, Batch: {batch + 1}, Learning Rate: {current_lr:.6f}, Loss: {loss.item():.6f}")


-----------------------------------------------------------------------------------------------------------------


import torch
import torch.nn as nn
import torch.optim as optim
from torch.optim.lr_scheduler import CyclicLR
import matplotlib.pyplot as plt

# 构建一个简单的神经网络
class SimpleModel(nn.Module):
    def __init__(self):
        super(SimpleModel, self).__init__()
        self.fc1 = nn.Linear(10, 50)
        self.fc2 = nn.Linear(50, 1)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = self.fc2(x)
        return x

# 初始化模型、损失函数和优化器
model = SimpleModel()
criterion = nn.MSELoss()
optimizer = optim.SGD(model.parameters(), lr=0.01)

# 设置循环学习率调度器
scheduler = CyclicLR(
    optimizer, 
    base_lr=0.001,  # 最小学习率
    max_lr=0.01,    # 最大学习率
    step_size_up=5, # 上升阶段的步数
    mode='triangular' # 循环模式
)

# 创建数据模拟训练过程
data = torch.randn(20, 10)
target = torch.randn(20, 1)

# 记录每个step的学习率变化
lr_list = []

# 模拟训练过程
num_epochs = 30
for epoch in range(num_epochs):
    for batch in range(len(data)):
        inputs = data[batch].unsqueeze(0)  # 单个样本
        labels = target[batch].unsqueeze(0)

        # 前向传播
        outputs = model(inputs)
        loss = criterion(outputs, labels)

        # 反向传播和优化
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        # 更新学习率
        scheduler.step()

        # 记录当前学习率
        lr_list.append(optimizer.param_groups[0]['lr'])

# 可视化学习率变化情况
plt.plot(lr_list)
plt.xlabel("Training Step")
plt.ylabel("Learning Rate")
plt.title("Cyclic Learning Rate Schedule")
plt.show()


-----------------------------------------------------------------------------------------------------------------


from torch.optim.lr_scheduler import StepLR

# 初始化优化器和StepLR
optimizer = optim.SGD(model.parameters(), lr=0.1)
scheduler = StepLR(optimizer, step_size=10, gamma=0.1)  # 每10个epoch将学习率乘以0.1

# 使用StepLR进行学习率调整
for epoch in range(50):
    # 训练步骤
    # ...
    scheduler.step()  # 更新学习率
    print(f"Epoch {epoch+1}: Learning Rate = {optimizer.param_groups[0]['lr']}")
from torch.optim.lr_scheduler import ExponentialLR

# 初始化优化器和ExponentialLR
optimizer = optim.SGD(model.parameters(), lr=0.1)
scheduler = ExponentialLR(optimizer, gamma=0.95)  # 每个epoch学习率衰减为原来的95%

# 使用ExponentialLR进行学习率调整
for epoch in range(50):
    # 训练步骤
    # ...
    scheduler.step()  # 更新学习率
    print(f"Epoch {epoch+1}: Learning Rate = {optimizer.param_groups[0]['lr']}")


from torch.optim.lr_scheduler import ReduceLROnPlateau

# 初始化优化器和ReduceLROnPlateau
optimizer = optim.SGD(model.parameters(), lr=0.1)
scheduler = ReduceLROnPlateau(optimizer, mode='min', factor=0.5, patience=5)

# 使用ReduceLROnPlateau进行学习率调整
for epoch in range(50):
    # 训练和验证步骤
    # ...
    val_loss = ...  # 计算验证集上的损失
    scheduler.step(val_loss)  # 根据验证集损失调整学习率
    print(f"Epoch {epoch+1}: Learning Rate = {optimizer.param_groups[0]['lr']}")


from torch.optim.lr_scheduler import CosineAnnealingLR

# 初始化优化器和CosineAnnealingLR
optimizer = optim.SGD(model.parameters(), lr=0.1)
scheduler = CosineAnnealingLR(optimizer, T_max=50)  # T_max是一个周期的长度

# 使用CosineAnnealingLR进行学习率调整
for epoch in range(50):
    # 训练步骤
    # ...
    scheduler.step()  # 更新学习率
    print(f"Epoch {epoch+1}: Learning Rate = {optimizer.param_groups[0]['lr']}")
from torch.optim.lr_scheduler import CosineAnnealingWarmRestarts

# 初始化优化器和CosineAnnealingWarmRestarts
optimizer = optim.SGD(model.parameters(), lr=0.1)
scheduler = CosineAnnealingWarmRestarts(optimizer, T_0=10, T_mult=2)

# 使用CosineAnnealingWarmRestarts进行学习率调整
for epoch in range(50):
    # 训练步骤
    # ...
    scheduler.step()  # 更新学习率
    print(f"Epoch {epoch+1}: Learning Rate = {optimizer.param_groups[0]['lr']}")
