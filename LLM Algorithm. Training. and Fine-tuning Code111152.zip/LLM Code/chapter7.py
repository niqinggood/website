-----------------------------------------------------------------------------------------------------------------


import torch
import torch.nn as nn
import torch.optim as optim
from torch.cuda.amp import autocast, GradScaler
from torchvision import models, datasets, transforms
from torch.utils.data import DataLoader

# 数据预处理
transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor()
])

# 使用CIFAR-10数据集
train_dataset = datasets.CIFAR10(root="./data", train=True, download=True, transform=transform)
train_loader = DataLoader(train_dataset, batch_size=32, shuffle=True)

# 使用预训练的ResNet模型
model = models.resnet18(pretrained=True).cuda()
model.train()

# 定义损失函数和优化器
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)

# 混合精度训练需要使用GradScaler
scaler = GradScaler()

# 混合精度训练循环
for epoch in range(1):  # 示意性地使用一个epoch
    running_loss = 0.0
    for inputs, labels in train_loader:
        inputs, labels = inputs.cuda(), labels.cuda()
        
        optimizer.zero_grad()
        
        # autocast上下文管理器
        with autocast():
            outputs = model(inputs)
            loss = criterion(outputs, labels)
        
        # 使用缩放器管理梯度缩放
        scaler.scale(loss).backward()
        scaler.step(optimizer)
        scaler.update()
        
        running_loss += loss.item()
    
    print(f"Epoch {epoch+1}, Loss: {running_loss/len(train_loader)}")


-----------------------------------------------------------------------------------------------------------------


import os
import torch
import torch.distributed as dist
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, DistributedSampler
from torchvision import datasets, transforms
from torch.nn.parallel import DistributedDataParallel as DDP

# 初始化分布式环境
def setup(rank, world_size):
    os.environ['MASTER_ADDR'] = 'localhost'
    os.environ['MASTER_PORT'] = '12355'
    dist.init_process_group("nccl", rank=rank, world_size=world_size)
    torch.cuda.set_device(rank)

# 清理分布式环境
def cleanup():
    dist.destroy_process_group()

# 模型定义
class SimpleModel(nn.Module):
    def __init__(self):
        super(SimpleModel, self).__init__()
        self.fc = nn.Linear(28 * 28, 10)

    def forward(self, x):
        x = x.view(-1, 28 * 28)
        return self.fc(x)

# 分布式训练过程
def train(rank, world_size):
    setup(rank, world_size)

    transform = transforms.Compose([transforms.ToTensor()])
    dataset = datasets.MNIST(root='./data', train=True, download=True, transform=transform)
    sampler = DistributedSampler(dataset, num_replicas=world_size, rank=rank)
    dataloader = DataLoader(dataset, batch_size=64, sampler=sampler)

    model = SimpleModel().cuda(rank)
    model = DDP(model, device_ids=[rank])

    criterion = nn.CrossEntropyLoss()
    optimizer = optim.SGD(model.parameters(), lr=0.01)

    for epoch in range(2):  # 使用2个epoch示例
        sampler.set_epoch(epoch)
        running_loss = 0.0
        for batch_idx, (data, target) in enumerate(dataloader):
            data, target = data.cuda(rank), target.cuda(rank)
            optimizer.zero_grad()
            output = model(data)
            loss = criterion(output, target)
            loss.backward()
            optimizer.step()

            running_loss += loss.item()
        print(f"Rank {rank}, Epoch {epoch+1}, Loss: {running_loss/len(dataloader)}")

    cleanup()

# 多进程启动
def main():
    world_size = 2  # 示例设置为2个进程
    torch.multiprocessing.spawn(train, args=(world_size,), nprocs=world_size, join=True)

if __name__ == "__main__":
    main()


-----------------------------------------------------------------------------------------------------------------


import torch
import torch.nn as nn
import torch.optim as optim
from torchvision import datasets, transforms, models
from torch.utils.data import DataLoader

# 数据预处理
transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor()
])

# 使用CIFAR-10数据集
train_dataset = datasets.CIFAR10(root="./data", train=True, download=True, transform=transform)
train_loader = DataLoader(train_dataset, batch_size=64, shuffle=True)

# 模型加载
model = models.resnet18(pretrained=True)
model.fc = nn.Linear(model.fc.in_features, 10)  # 调整输出层用于CIFAR-10
model = model.cuda()

# 使用DataParallel包装模型
model = nn.DataParallel(model)

# 损失函数和优化器
criterion = nn.CrossEntropyLoss()
optimizer = optim.SGD(model.parameters(), lr=0.001, momentum=0.9)

# 训练过程
num_epochs = 2
for epoch in range(num_epochs):
    running_loss = 0.0
    for i, (inputs, labels) in enumerate(train_loader):
        inputs, labels = inputs.cuda(), labels.cuda()
        
        optimizer.zero_grad()
        
        # 前向传播
        outputs = model(inputs)
        loss = criterion(outputs, labels)
        
        # 反向传播与优化
        loss.backward()
        optimizer.step()
        
        running_loss += loss.item()
    
    print(f"Epoch {epoch+1}, Loss: {running_loss/len(train_loader)}")


-----------------------------------------------------------------------------------------------------------------


import torch
import torch.nn as nn
import torch.optim as optim
from torchvision import datasets, transforms, models
from torch.utils.data import DataLoader

# 数据预处理
transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor()
])

# CIFAR-10数据集
train_dataset = datasets.CIFAR10(root="./data", train=True, download=True, transform=transform)
train_loader = DataLoader(train_dataset, batch_size=64, shuffle=True)

# 自定义模型，将ResNet模型的前半部分放在cuda:0，后半部分放在cuda:1
class ModelParallelResNet(nn.Module):
    def __init__(self):
        super(ModelParallelResNet, self).__init__()
        self.resnet = models.resnet18(pretrained=True)
        
        # 将前半部分的层放在cuda:0
        self.resnet.layer1 = self.resnet.layer1.to('cuda:0')
        self.resnet.layer2 = self.resnet.layer2.to('cuda:0')
        
        # 将后半部分的层放在cuda:1
        self.resnet.layer3 = self.resnet.layer3.to('cuda:1')
        self.resnet.layer4 = self.resnet.layer4.to('cuda:1')
        self.resnet.fc = nn.Linear(self.resnet.fc.in_features, 10).to('cuda:1')

    def forward(self, x):
        # 前半部分在cuda:0上计算
        x = x.to('cuda:0')
        x = self.resnet.layer1(x)
        x = self.resnet.layer2(x)
        
        # 将中间输出传到cuda:1进行后半部分计算
        x = x.to('cuda:1')
        x = self.resnet.layer3(x)
        x = self.resnet.layer4(x)
        x = x.view(x.size(0), -1)
        x = self.resnet.fc(x)
        return x

# 初始化模型
model = ModelParallelResNet()
model.train()

# 损失函数和优化器
criterion = nn.CrossEntropyLoss()
optimizer = optim.SGD(model.parameters(), lr=0.001, momentum=0.9)

# 训练过程
num_epochs = 2
for epoch in range(num_epochs):
    running_loss = 0.0
    for i, (inputs, labels) in enumerate(train_loader):
        inputs, labels = inputs.to('cuda:0'), labels.to('cuda:1')  # 确保数据在正确的GPU上
        
        optimizer.zero_grad()
        
        # 前向传播
        outputs = model(inputs)
        loss = criterion(outputs, labels)
        
        # 反向传播与优化
        loss.backward()
        optimizer.step()
        
        running_loss += loss.item()
    
    print(f"Epoch {epoch+1}, Loss: {running_loss/len(train_loader)}")


-----------------------------------------------------------------------------------------------------------------


import torch
import torch.nn as nn
import torch.optim as optim
from torchvision import datasets, transforms, models
from torch.utils.data import DataLoader

# 数据预处理
transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor()
])

# CIFAR-10数据集加载
train_dataset = datasets.CIFAR10(root="./data", train=True, download=True, transform=transform)
train_loader = DataLoader(train_dataset, batch_size=16, shuffle=True)  # 小批量设置

# 模型定义（使用ResNet18）
model = models.resnet18(pretrained=True)
model.fc = nn.Linear(model.fc.in_features, 10)  # CIFAR-10的10分类
model = model.cuda()

# 损失函数和优化器
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)

# 梯度累积参数
accumulation_steps = 4  # 累积4步再更新

# 训练循环
num_epochs = 2
for epoch in range(num_epochs):
    running_loss = 0.0
    for i, (inputs, labels) in enumerate(train_loader):
        inputs, labels = inputs.cuda(), labels.cuda()
        
        # 前向传播
        outputs = model(inputs)
        loss = criterion(outputs, labels)
        
        # 反向传播，梯度累积
        loss = loss / accumulation_steps  # 损失缩放
        loss.backward()
        
        # 每 accumulation_steps 进行一次梯度更新
        if (i + 1) % accumulation_steps == 0:
            optimizer.step()
            optimizer.zero_grad()
        
        running_loss += loss.item() * accumulation_steps  # 累积的实际损失

    print(f"Epoch {epoch+1}, Loss: {running_loss/len(train_loader)}")


-----------------------------------------------------------------------------------------------------------------


import torch
import torch.nn as nn
import torch.optim as optim
from torchvision import datasets, transforms, models
from torch.utils.data import DataLoader

# 数据预处理
transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor()
])

# CIFAR-10数据集
train_dataset = datasets.CIFAR10(root="./data", train=True, download=True, transform=transform)
train_loader = DataLoader(train_dataset, batch_size=16, shuffle=True)  # 小批次训练

# 使用ResNet-18模型
model = models.resnet18(pretrained=True)
model.fc = nn.Linear(model.fc.in_features, 10)  # CIFAR-10的10分类
model = model.cuda()

# 损失函数和优化器
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)

# 梯度累积的步数设置
accumulation_steps = 4  # 每4步累积更新一次

# 训练过程
num_epochs = 2
for epoch in range(num_epochs):
    running_loss = 0.0
    for i, (inputs, labels) in enumerate(train_loader):
        inputs, labels = inputs.cuda(), labels.cuda()
        
        # 前向传播
        outputs = model(inputs)
        loss = criterion(outputs, labels)
        
        # 累积梯度
        loss = loss / accumulation_steps
        loss.backward()
        
        # 每到累积步数时，执行一次优化
        if (i + 1) % accumulation_steps == 0:
            optimizer.step()
            optimizer.zero_grad()
        
        running_loss += loss.item() * accumulation_steps  # 累积的真实损失

    print(f"Epoch {epoch+1}, Loss: {running_loss/len(train_loader)}")


-----------------------------------------------------------------------------------------------------------------


import torch
import torch.nn as nn
import torch.optim as optim
from torchtext.datasets import IMDB
from torchtext.data.utils import get_tokenizer
from torchtext.vocab import build_vocab_from_iterator
from torch.utils.data import DataLoader, Dataset

# 超参数定义
batch_size = 32
accumulation_steps = 4  # 每4步累积梯度再更新
embedding_dim = 128
hidden_dim = 256
output_dim = 2
num_epochs = 2
lr = 0.001

# 数据预处理
tokenizer = get_tokenizer("basic_english")

# 创建词汇表
def yield_tokens(data_iter):
    for _, text in data_iter:
        yield tokenizer(text)

train_iter, _ = IMDB(split='train')
vocab = build_vocab_from_iterator(yield_tokens(train_iter), specials=["<unk>"])
vocab.set_default_index(vocab["<unk>"])

# 数据集定义
class TextDataset(Dataset):
    def __init__(self, data_iter, vocab, tokenizer):
        self.data = list(data_iter)
        self.vocab = vocab
        self.tokenizer = tokenizer

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        label, text = self.data[idx]
        label = 1 if label == "pos" else 0
        tokens = [self.vocab[token] for token in self.tokenizer(text)]
        return torch.tensor(tokens), torch.tensor(label)

# 数据加载
train_iter, test_iter = IMDB(split=('train', 'test'))
train_dataset = TextDataset(train_iter, vocab, tokenizer)
train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, collate_fn=lambda x: x)

# 定义模型
class LSTMModel(nn.Module):
    def __init__(self, vocab_size, embedding_dim, hidden_dim, output_dim):
        super(LSTMModel, self).__init__()
        self.embedding = nn.Embedding(vocab_size, embedding_dim)
        self.lstm = nn.LSTM(embedding_dim, hidden_dim, batch_first=True)
        self.fc = nn.Linear(hidden_dim, output_dim)

    def forward(self, x):
        embedded = self.embedding(x)
        _, (hidden, _) = self.lstm(embedded)
        return self.fc(hidden[-1])

# 初始化模型
model = LSTMModel(len(vocab), embedding_dim, hidden_dim, output_dim).cuda()
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=lr)

# 训练循环，使用梯度累积
for epoch in range(num_epochs):
    model.train()
    running_loss = 0.0
    for i, batch in enumerate(train_loader):
        texts, labels = batch
        texts = [text[:200] for text in texts]  # 截断过长的文本以适应显存
        texts = nn.utils.rnn.pad_sequence(texts, batch_first=True).cuda()
        labels = labels.cuda()

        # 前向传播
        outputs = model(texts)
        loss = criterion(outputs, labels)

        # 梯度累积
        loss = loss / accumulation_steps
        loss.backward()

        if (i + 1) % accumulation_steps == 0:
            optimizer.step()
            optimizer.zero_grad()

        running_loss += loss.item() * accumulation_steps

    print(f"Epoch {epoch + 1}, Loss: {running_loss / len(train_loader):.4f}")

# 示例输出（用于验证模型效果）
model.eval()
with torch.no_grad():
    sample_text = "The movie was fantastic with great characters and plot"
    tokens = torch.tensor([vocab[token] for token in tokenizer(sample_text)]).unsqueeze(0).cuda()
    output = model(tokens)
    prediction = torch.argmax(output, dim=1).item()
    print(f"Sample Prediction (1: positive, 0: negative): {prediction}")