-----------------------------------------------------------------------------------------------------------------


import torch
import torch.nn as nn
import torch.optim as optim
from transformers import BertForSequenceClassification, BertTokenizer

# 加载BERT的教师模型
teacher_model = BertForSequenceClassification.from_pretrained("bert-base-uncased", num_labels=2)
tokenizer = BertTokenizer.from_pretrained("bert-base-uncased")

# 构建学生模型：缩减BERT层数
class StudentModel(nn.Module):
    def __init__(self):
        super(StudentModel, self).__init__()
        self.bert = BertForSequenceClassification.from_pretrained("bert-base-uncased", num_labels=2)
        self.bert.config.num_hidden_layers = 4  # 缩减BERT层数

    def forward(self, input_ids, attention_mask):
        return self.bert(input_ids=input_ids, attention_mask=attention_mask)

student_model = StudentModel()


# 蒸馏损失
def distillation_loss(student_logits, teacher_logits, labels, T=2.0, alpha=0.5):
    loss_fn = nn.CrossEntropyLoss()
    soft_loss = nn.KLDivLoss()(nn.functional.log_softmax(student_logits / T, dim=1),
                               nn.functional.softmax(teacher_logits / T, dim=1)) * (T * T)
    hard_loss = loss_fn(student_logits, labels)
    return alpha * soft_loss + (1 - alpha) * hard_loss


# 假设一个简单的数据集
texts = ["This is a positive example.", "This is a negative example."]
labels = torch.tensor([1, 0])

# 数据预处理
inputs = tokenizer(texts, padding=True, truncation=True, return_tensors="pt")
input_ids = inputs["input_ids"]
attention_mask = inputs["attention_mask"]

# 优化器设置
optimizer = optim.Adam(student_model.parameters(), lr=1e-4)

# 蒸馏训练过程
epochs = 3
for epoch in range(epochs):
    student_model.train()
    teacher_model.eval()

    # 教师模型输出
    with torch.no_grad():
        teacher_outputs = teacher_model(input_ids=input_ids, attention_mask=attention_mask)
        teacher_logits = teacher_outputs.logits

    # 学生模型输出
    student_outputs = student_model(input_ids=input_ids, attention_mask=attention_mask)
    student_logits = student_outputs.logits

    # 计算蒸馏损失
    loss = distillation_loss(student_logits, teacher_logits, labels)
    optimizer.zero_grad()
    loss.backward()
    optimizer.step()

    print(f"Epoch {epoch + 1}/{epochs}, Loss: {loss.item():.4f}")


-----------------------------------------------------------------------------------------------------------------


import torch
from torch import nn, optim
from transformers import BertTokenizer, BertForSequenceClassification, DistilBertForSequenceClassification
from torch.utils.data import DataLoader, TensorDataset
# 假设已有预处理后的数据集
# X_train 和 X_labels 表示训练数据的输入和标签

X_train = ["The movie was great!", "I did not like the film.", "An excellent experience."]
X_labels = [1, 0, 1]  # 假设标签为 1 表示正面，0 表示负面

tokenizer = BertTokenizer.from_pretrained("bert-base-uncased")
inputs = tokenizer(X_train, return_tensors="pt", padding=True, truncation=True, max_length=32)
labels = torch.tensor(X_labels)

train_data = TensorDataset(inputs['input_ids'], inputs['attention_mask'], labels)
train_loader = DataLoader(train_data, batch_size=2)


# 加载教师模型（预训练的 BERT）
teacher_model = BertForSequenceClassification.from_pretrained("bert-base-uncased", num_labels=2)
teacher_model.eval()  # 设为评估模式，不更新教师模型的权重

# 加载学生模型（DistilBERT）
student_model = DistilBertForSequenceClassification.from_pretrained("distilbert-base-uncased", num_labels=2)
student_model.train()  # 设为训练模式


def distillation_loss(student_logits, teacher_logits, true_labels, alpha=0.5, temperature=2.0):
    # 使用软标签的KL散度损失
    soft_labels = nn.functional.log_softmax(teacher_logits / temperature, dim=-1)
    student_probs = nn.functional.log_softmax(student_logits / temperature, dim=-1)
    kd_loss = nn.functional.kl_div(student_probs, soft_labels, reduction="batchmean") * (temperature ** 2)

    # 使用真实标签的交叉熵损失
    ce_loss = nn.CrossEntropyLoss()(student_logits, true_labels)
    return alpha * kd_loss + (1 - alpha) * ce_loss


epochs = 3
for epoch in range(epochs):
    epoch_loss = 0
    for batch in train_loader:
        input_ids, attention_mask, labels = batch
        # 教师模型预测
        with torch.no_grad():
            teacher_outputs = teacher_model(input_ids=input_ids, attention_mask=attention_mask)
            teacher_logits = teacher_outputs.logits

        # 学生模型预测
        student_outputs = student_model(input_ids=input_ids, attention_mask=attention_mask)
        student_logits = student_outputs.logits

        # 计算蒸馏损失
        loss = distillation_loss(student_logits, teacher_logits, labels)
        epoch_loss += loss.item()

        # 反向传播和优化
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

    avg_loss = epoch_loss / len(train_loader)
    print(f"Epoch {epoch + 1}/{epochs}, Loss: {avg_loss:.4f}")


-----------------------------------------------------------------------------------------------------------------


import torch
from torch import nn, optim
from transformers import BertForSequenceClassification, DistilBertForSequenceClassification, BertTokenizer
from torch.utils.data import DataLoader, TensorDataset


# 定义示例数据集
texts = ["The product is excellent!", "Worst experience ever.", "Had a great time!", "Not worth the money."]
labels = [1, 0, 1, 0]  # 1 表示正面情绪，0 表示负面情绪

tokenizer = BertTokenizer.from_pretrained("bert-base-uncased")
inputs = tokenizer(texts, return_tensors="pt", padding=True, truncation=True, max_length=16)
input_ids, attention_mask = inputs['input_ids'], inputs['attention_mask']
labels = torch.tensor(labels)

dataset = TensorDataset(input_ids, attention_mask, labels)
data_loader = DataLoader(dataset, batch_size=2)


# 初始化教师模型（BERT）和学生模型（DistilBERT）
teacher_model = BertForSequenceClassification.from_pretrained("bert-base-uncased", num_labels=2)
student_model = DistilBertForSequenceClassification.from_pretrained("distilbert-base-uncased", num_labels=2)

teacher_model.eval()  # 教师模型设为评估模式
student_model.train()  # 学生模型设为训练模式


def distillation_loss(student_logits, teacher_logits, true_labels, alpha=0.5, temperature=2.0):
    # 计算教师模型的软标签
    soft_teacher_probs = nn.functional.log_softmax(teacher_logits / temperature, dim=-1)
    soft_student_probs = nn.functional.log_softmax(student_logits / temperature, dim=-1)
    # 计算 KL 散度损失（蒸馏损失）
    kd_loss = nn.functional.kl_div(soft_student_probs, soft_teacher_probs, reduction="batchmean") * (temperature ** 2)

    # 计算学生模型的交叉熵损失
    ce_loss = nn.CrossEntropyLoss()(student_logits, true_labels)

    # 返回加权总损失
    return alpha * kd_loss + (1 - alpha) * ce_loss


epochs = 3
for epoch in range(epochs):
    epoch_loss = 0
    for batch in data_loader:
        input_ids, attention_mask, labels = batch

        # 教师模型的预测
        with torch.no_grad():
            teacher_outputs = teacher_model(input_ids=input_ids, attention_mask=attention_mask)
            teacher_logits = teacher_outputs.logits

        # 学生模型的预测
        student_outputs = student_model(input_ids=input_ids, attention_mask=attention_mask)
        student_logits = student_outputs.logits

        # 计算蒸馏损失
        loss = distillation_loss(student_logits, teacher_logits, labels)
        epoch_loss += loss.item()

        # 反向传播和优化
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

    avg_loss = epoch_loss / len(data_loader)
    print(f"Epoch {epoch + 1}/{epochs}, Loss: {avg_loss:.4f}")


-----------------------------------------------------------------------------------------------------------------


from transformers import AutoModelForSequenceClassification, AutoTokenizer, Trainer, TrainingArguments
from datasets import load_dataset
import torch
import torch.nn.functional as F
import numpy as np


teacher_model_name = "bert-base-uncased"
student_model_name = "distilbert-base-uncased"

# 加载教师模型和分词器
teacher_model = AutoModelForSequenceClassification.from_pretrained(teacher_model_name, num_labels=2)
teacher_tokenizer = AutoTokenizer.from_pretrained(teacher_model_name)

# 加载学生模型和分词器
student_model = AutoModelForSequenceClassification.from_pretrained(student_model_name, num_labels=2)
student_tokenizer = AutoTokenizer.from_pretrained(student_model_name)


dataset = load_dataset("imdb")

def preprocess_data(examples):
    return teacher_tokenizer(examples['text'], truncation=True, padding='max_length', max_length=128)

encoded_dataset = dataset.map(preprocess_data, batched=True)
def get_teacher_logits(batch):
    inputs = {k: v.to(teacher_model.device) for k, v in batch.items() if k in teacher_tokenizer.model_input_names}
    with torch.no_grad():
        outputs = teacher_model(**inputs)
    return outputs.logits
def distillation_loss(student_logits, teacher_logits, temperature=2.0):
    student_probs = F.log_softmax(student_logits / temperature, dim=-1)
    teacher_probs = F.softmax(teacher_logits / temperature, dim=-1)
    return F.kl_div(student_probs, teacher_probs, reduction="batchmean") * (temperature ** 2)


class DistillationTrainer(Trainer):
    def compute_loss(self, model, inputs, return_outputs=False):
        labels = inputs.get("labels")
        outputs = model(**inputs)
        student_logits = outputs.logits
        teacher_logits = get_teacher_logits(inputs)

        # 计算蒸馏损失
        loss = distillation_loss(student_logits, teacher_logits)
        
        return (loss, outputs) if return_outputs else loss

# 设置训练参数
training_args = TrainingArguments(
    output_dir="./distilled_model",
    evaluation_strategy="epoch",
    learning_rate=5e-5,
    per_device_train_batch_size=8,
    per_device_eval_batch_size=8,
    num_train_epochs=3,
)

# 初始化训练器
trainer = DistillationTrainer(
    model=student_model,
    args=training_args,
    train_dataset=encoded_dataset["train"],
    eval_dataset=encoded_dataset["test"],
)

# 开始训练
trainer.train()


-----------------------------------------------------------------------------------------------------------------


import torch
import time
from transformers import BertForSequenceClassification, DistilBertForSequenceClassification
from transformers import Trainer, TrainingArguments
from datasets import load_dataset

# 加载数据集
dataset = load_dataset("imdb")
train_dataset = dataset["train"].shuffle(seed=42).select(range(2000))
test_dataset = dataset["test"].shuffle(seed=42).select(range(500))

# 初始化教师模型（BERT-base）和学生模型（DistilBERT）
teacher_model = BertForSequenceClassification.from_pretrained("bert-base-uncased")
student_model = DistilBertForSequenceClassification.from_pretrained("distilbert-base-uncased")

# 训练参数设置
training_args = TrainingArguments(
    output_dir="./results",
    evaluation_strategy="epoch",
    logging_dir="./logs",
    num_train_epochs=1,
    per_device_train_batch_size=8,
    per_device_eval_batch_size=8,
)

# 创建Trainer实例
def train_and_evaluate(model, train_dataset, test_dataset, model_name=""):
    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=train_dataset,
        eval_dataset=test_dataset
    )

    # 记录训练时间
    start_train = time.time()
    trainer.train()
    train_time = time.time() - start_train

    # 记录推理时间
    start_eval = time.time()
    metrics = trainer.evaluate()
    eval_time = time.time() - start_eval

    # 模型大小
    model_size = sum(p.numel() for p in model.parameters()) / 1e6  # 转换为百万参数量

    # 输出结果
    print(f"--- {model_name} 模型 ---")
    print(f"训练时间: {train_time:.2f} 秒")
    print(f"推理时间: {eval_time:.2f} 秒")
    print(f"验证集损失: {metrics['eval_loss']:.4f}")
    print(f"验证集准确率: {metrics['eval_accuracy']:.4f}")
    print(f"模型参数量: {model_size:.2f}M\n")

# 训练和评估教师模型
train_and_evaluate(teacher_model, train_dataset, test_dataset, model_name="教师模型 (BERT-base)")

# 训练和评估学生模型
train_and_evaluate(student_model, train_dataset, test_dataset, model_name="学生模型 (DistilBERT)")


-----------------------------------------------------------------------------------------------------------------


import torch
import time
from transformers import RobertaForSequenceClassification, DistilBertForSequenceClassification, Trainer, TrainingArguments
from datasets import load_dataset

# 加载SST-2数据集
dataset = load_dataset("glue", "sst2")
train_dataset = dataset["train"].shuffle(seed=42).select(range(2000))
test_dataset = dataset["validation"].shuffle(seed=42).select(range(500))

# 初始化教师模型 (RoBERTa-large) 和学生模型 (DistilRoBERTa)
teacher_model = RobertaForSequenceClassification.from_pretrained("roberta-large")
student_model = DistilBertForSequenceClassification.from_pretrained("distilroberta-base")

# 训练参数设置
training_args = TrainingArguments(
    output_dir="./results",
    evaluation_strategy="epoch",
    logging_dir="./logs",
    num_train_epochs=1,
    per_device_train_batch_size=8,
    per_device_eval_batch_size=8,
)

# 创建Trainer函数
def train_and_evaluate(model, train_dataset, test_dataset, model_name=""):
    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=train_dataset,
        eval_dataset=test_dataset
    )

    # 记录训练时间
    start_train = time.time()
    trainer.train()
    train_time = time.time() - start_train

    # 记录推理时间
    start_eval = time.time()
    metrics = trainer.evaluate()
    eval_time = time.time() - start_eval

    # 模型大小
    model_size = sum(p.numel() for p in model.parameters()) / 1e6  # 转换为百万参数量

    # 输出结果
    print(f"--- {model_name} 模型 ---")
    print(f"训练时间: {train_time:.2f} 秒")
    print(f"推理时间: {eval_time:.2f} 秒")
    print(f"验证集损失: {metrics['eval_loss']:.4f}")
    print(f"验证集准确率: {metrics['eval_accuracy']:.4f}")
    print(f"模型参数量: {model_size:.2f}M\n")

# 训练和评估教师模型
train_and_evaluate(teacher_model, train_dataset, test_dataset, model_name="教师模型 (RoBERTa-large)")

# 训练和评估学生模型
train_and_evaluate(student_model, train_dataset, test_dataset, model_name="学生模型 (DistilRoBERTa)")


-----------------------------------------------------------------------------------------------------------------


import torch
import torch.nn as nn
import torch.optim as optim
from torch.nn.utils import prune
import time

# 定义一个简单的全连接神经网络
class SimpleNN(nn.Module):
    def __init__(self):
        super(SimpleNN, self).__init__()
        self.fc1 = nn.Linear(784, 256)
        self.relu = nn.ReLU()
        self.fc2 = nn.Linear(256, 128)
        self.fc3 = nn.Linear(128, 10)
        
    def forward(self, x):
        x = self.fc1(x)
        x = self.relu(x)
        x = self.fc2(x)
        x = self.relu(x)
        x = self.fc3(x)
        return x

# 初始化模型、损失函数和优化器
model = SimpleNN()
criterion = nn.CrossEntropyLoss()
optimizer = optim.SGD(model.parameters(), lr=0.01)

# 模拟训练步骤（简单示例，不进行实际训练以节省时间）
def train(model):
    model.train()
    # 模拟批量数据
    inputs = torch.randn(64, 784)
    labels = torch.randint(0, 10, (64,))
    
    # 前向传播
    outputs = model(inputs)
    loss = criterion(outputs, labels)
    
    # 反向传播和优化
    optimizer.zero_grad()
    loss.backward()
    optimizer.step()

# 训练模型（仅示例，实际应多轮训练）
train(model)

# 定义权重剪枝函数，按比例剪枝
def prune_weights(model, amount=0.5):
    for module in model.children():
        if isinstance(module, nn.Linear):
            prune.l1_unstructured(module, name='weight', amount=amount)
            prune.remove(module, 'weight')  # 移除掩膜，保留剪枝后的权重

# 剪枝前评估
def evaluate_model(model):
    model.eval()
    inputs = torch.randn(1000, 784)
    start = time.time()
    with torch.no_grad():
        outputs = model(inputs)
    end = time.time()
    print(f"推理时间: {end - start:.4f} 秒")
    return outputs

# 剪枝前的模型评估
print("剪枝前:")
outputs = evaluate_model(model)

# 应用权重剪枝
prune_weights(model, amount=0.5)

# 剪枝后的模型评估
print("剪枝后:")
outputs = evaluate_model(model)

# 打印模型参数量
def count_parameters(model):
    return sum(p.numel() for p in model.parameters() if p.requires_grad)

print("剪枝前模型参数量:", count_parameters(model))
prune_weights(model, amount=0.5)
print("剪枝后模型参数量:", count_parameters(model))


-----------------------------------------------------------------------------------------------------------------


import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.utils.prune as prune
import torch.nn.functional as F
from torchvision import datasets, transforms
from torch.utils.data import DataLoader

# 定义简单的CNN模型
class SimpleCNN(nn.Module):
    def __init__(self):
        super(SimpleCNN, self).__init__()
        self.conv1 = nn.Conv2d(1, 32, kernel_size=3)
        self.conv2 = nn.Conv2d(32, 64, kernel_size=3)
        self.fc1 = nn.Linear(9216, 128)
        self.fc2 = nn.Linear(128, 10)

    def forward(self, x):
        x = F.relu(self.conv1(x))
        x = F.max_pool2d(x, 2)
        x = F.relu(self.conv2(x))
        x = F.max_pool2d(x, 2)
        x = x.view(-1, 9216)
        x = F.relu(self.fc1(x))
        x = self.fc2(x)
        return x

# 加载数据
transform = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize((0.1307,), (0.3081,))
])

train_loader = DataLoader(
    datasets.MNIST('./data', train=True, download=True, transform=transform),
    batch_size=64, shuffle=True
)

test_loader = DataLoader(
    datasets.MNIST('./data', train=False, transform=transform),
    batch_size=1000, shuffle=False
)

# 初始化模型、优化器和损失函数
model = SimpleCNN()
optimizer = optim.Adam(model.parameters())
criterion = nn.CrossEntropyLoss()

# 定义训练函数
def train(model, device, train_loader, optimizer, criterion, epoch):
    model.train()
    for batch_idx, (data, target) in enumerate(train_loader):
        data, target = data.to(device), target.to(device)
        optimizer.zero_grad()
        output = model(data)
        loss = criterion(output, target)
        loss.backward()
        optimizer.step()

# 定义测试函数
def test(model, device, test_loader):
    model.eval()
    test_loss = 0
    correct = 0
    with torch.no_grad():
        for data, target in test_loader:
            data, target = data.to(device), target.to(device)
            output = model(data)
            test_loss += criterion(output, target).item()
            pred = output.argmax(dim=1, keepdim=True)
            correct += pred.eq(target.view_as(pred)).sum().item()

    test_loss /= len(test_loader.dataset)
    accuracy = 100. * correct / len(test_loader.dataset)
    print(f'Test set: Average loss: {test_loss:.4f}, Accuracy: {correct}/{len(test_loader.dataset)} ({accuracy:.2f}%)\n')
    return accuracy

# 初始训练
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model.to(device)
for epoch in range(1, 3):  # 训练2个epoch以获得基线准确性
    train(model, device, train_loader, optimizer, criterion, epoch)
    test(model, device, test_loader)

# 应用结构化剪枝
def apply_structured_pruning(model, amount):
    # 以20%比例对卷积层进行结构化剪枝
    parameters_to_prune = [
        (model.conv1, 'weight'),
        (model.conv2, 'weight')
    ]
    for layer, param in parameters_to_prune:
        prune.ln_structured(layer, name=param, amount=amount, n=2, dim=0)

    print("结构化剪枝已应用")

# 执行剪枝
apply_structured_pruning(model, amount=0.2)

# 查看剪枝效果
def check_sparsity(model):
    for name, module in model.named_modules():
        if isinstance(module, torch.nn.Conv2d) or isinstance(module, torch.nn.Linear):
            print(f"Sparsity in {name}.weight: {100. * float(torch.sum(module.weight == 0)) / float(module.weight.nelement()):.2f}%")

check_sparsity(model)

# 剪枝后的测试
print("剪枝后测试：")
for epoch in range(1, 3):
    test(model, device, test_loader)


-----------------------------------------------------------------------------------------------------------------


import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import torch.nn.utils.prune as prune
from torchvision import datasets, transforms
from torch.utils.data import DataLoader
import time

# 定义简单的CNN模型
class CNNModel(nn.Module):
    def __init__(self):
        super(CNNModel, self).__init__()
        self.conv1 = nn.Conv2d(1, 32, kernel_size=3, padding=1)
        self.conv2 = nn.Conv2d(32, 64, kernel_size=3, padding=1)
        self.fc1 = nn.Linear(64 * 7 * 7, 128)
        self.fc2 = nn.Linear(128, 10)

    def forward(self, x):
        x = F.relu(self.conv1(x))
        x = F.max_pool2d(x, 2)
        x = F.relu(self.conv2(x))
        x = F.max_pool2d(x, 2)
        x = x.view(-1, 64 * 7 * 7)
        x = F.relu(self.fc1(x))
        x = self.fc2(x)
        return x

# 加载数据
transform = transforms.Compose([transforms.ToTensor(), transforms.Normalize((0.1307,), (0.3081,))])
train_loader = DataLoader(datasets.MNIST('./data', train=True, download=True, transform=transform), batch_size=64, shuffle=True)
test_loader = DataLoader(datasets.MNIST('./data', train=False, transform=transform), batch_size=1000, shuffle=False)

# 初始化模型、优化器和损失函数
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = CNNModel().to(device)
optimizer = optim.Adam(model.parameters())
criterion = nn.CrossEntropyLoss()

# 训练模型函数
def train(model, train_loader, optimizer, criterion, device, epochs=1):
    model.train()
    for epoch in range(epochs):
        for data, target in train_loader:
            data, target = data.to(device), target.to(device)
            optimizer.zero_grad()
            output = model(data)
            loss = criterion(output, target)
            loss.backward()
            optimizer.step()

# 测试模型函数
def test(model, test_loader, device):
    model.eval()
    correct = 0
    with torch.no_grad():
        for data, target in test_loader:
            data, target = data.to(device), target.to(device)
            output = model(data)
            pred = output.argmax(dim=1, keepdim=True)
            correct += pred.eq(target.view_as(pred)).sum().item()
    accuracy = 100. * correct / len(test_loader.dataset)
    return accuracy

# 初始训练和测试
train(model, train_loader, optimizer, criterion, device, epochs=1)
baseline_accuracy = test(model, test_loader, device)
print(f'Initial Model Accuracy: {baseline_accuracy:.2f}%')

# 应用非结构化权重剪枝
def apply_weight_pruning(model, amount=0.3):
    prune.random_unstructured(model.fc1, name="weight", amount=amount)
    prune.random_unstructured(model.fc2, name="weight", amount=amount)
    print("Applied unstructured pruning")

apply_weight_pruning(model, amount=0.3)
accuracy_after_pruning = test(model, test_loader, device)
print(f'Accuracy after Weight Pruning: {accuracy_after_pruning:.2f}%')

# 应用结构化剪枝（例如卷积层剪枝）
def apply_structured_pruning(model, amount=0.3):
    prune.ln_structured(model.conv1, name="weight", amount=amount, n=2, dim=0)
    prune.ln_structured(model.conv2, name="weight", amount=amount, n=2, dim=0)
    print("Applied structured pruning")

apply_structured_pruning(model, amount=0.3)
accuracy_after_structured_pruning = test(model, test_loader, device)
print(f'Accuracy after Structured Pruning: {accuracy_after_structured_pruning:.2f}%')

# 测试剪枝对模型大小和推理速度的影响
def model_size_and_inference_time(model, device, test_loader):
    torch.save(model.state_dict(), "pruned_model.pth")
    model_size = os.path.getsize("pruned_model.pth") / 1e6  # 以MB为单位
    print(f'Model Size after Pruning: {model_size:.2f} MB')

    start_time = time.time()
    test(model, test_loader, device)
    inference_time = time.time() - start_time
    print(f'Inference Time after Pruning: {inference_time:.2f} seconds')

model_size_and_inference_time(model, device, test_loader)


-----------------------------------------------------------------------------------------------------------------


import torch
from transformers import BertForSequenceClassification, BertTokenizer, Trainer, TrainingArguments
from transformers.modeling_outputs import SequenceClassifierOutput
from datasets import load_dataset
import numpy as np

# 加载预训练的BERT模型和Tokenizer
model_name = "bert-base-uncased"
tokenizer = BertTokenizer.from_pretrained(model_name)
model = BertForSequenceClassification.from_pretrained(model_name, num_labels=2)

# 加载IMDb数据集作为示例
dataset = load_dataset("imdb")
train_dataset = dataset["train"].map(lambda e: tokenizer(e['text'], truncation=True, padding='max_length'), batched=True)
test_dataset = dataset["test"].map(lambda e: tokenizer(e['text'], truncation=True, padding='max_length'), batched=True)

# 训练参数设置
training_args = TrainingArguments(
    output_dir="./results",
    evaluation_strategy="epoch",
    per_device_train_batch_size=4,
    per_device_eval_batch_size=4,
    num_train_epochs=1
)

# 基础测试，计算训练前的初始精度
def compute_metrics(eval_pred):
    logits, labels = eval_pred
    predictions = np.argmax(logits, axis=-1)
    accuracy = (predictions == labels).mean()
    return {"accuracy": accuracy}

trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=train_dataset,
    eval_dataset=test_dataset,
    compute_metrics=compute_metrics,
)

# 运行前测试
eval_result = trainer.evaluate()
print(f"Initial Model Accuracy: {eval_result['eval_accuracy']:.2f}")

# 注意力头剪枝函数
def prune_attention_heads(model, layer_num, head_indices):
    model.bert.encoder.layer[layer_num].attention.prune_heads(set(head_indices))

# 剪枝掉第3层的第2和第3个注意力头
prune_attention_heads(model, layer_num=3, head_indices=[2, 3])

# 层剪枝：移除不重要的Transformer层
def prune_layers(model, prune_layer_nums):
    layers = [layer for i, layer in enumerate(model.bert.encoder.layer) if i not in prune_layer_nums]
    model.bert.encoder.layer = torch.nn.ModuleList(layers)

# 移除第11层以减少模型深度
prune_layers(model, prune_layer_nums=[11])

# 剪枝后再次进行评估
eval_result_pruned = trainer.evaluate()
print(f"Accuracy after Pruning: {eval_result_pruned['eval_accuracy']:.2f}")

# 推理速度和模型大小评估
def model_size_and_inference_time(model, device, test_dataset):
    torch.save(model.state_dict(), "pruned_bert_model.pth")
    model_size = os.path.getsize("pruned_bert_model.pth") / 1e6  # 以MB为单位
    print(f'Model Size after Pruning: {model_size:.2f} MB')

    # 推理速度评估
    start_time = time.time()
    trainer.evaluate()  # 重新评估剪枝后的模型
    inference_time = time.time() - start_time
    print(f'Inference Time after Pruning: {inference_time:.2f} seconds')

model_size_and_inference_time(model, device="cuda", test_dataset=test_dataset)

