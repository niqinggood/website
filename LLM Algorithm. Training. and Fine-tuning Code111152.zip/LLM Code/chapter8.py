-----------------------------------------------------------------------------------------------------------------


import torch
import torch.nn as nn
import torch.optim as optim
import torchvision.transforms as transforms
from torchvision.datasets import CIFAR10
from torch.utils.data import DataLoader, Dataset
import numpy as np

# 数据集预处理
transform = transforms.Compose([
    transforms.RandomResizedCrop(32),
    transforms.RandomHorizontalFlip(),
    transforms.ToTensor()
])

# 自定义对比学习数据集，用于生成正负样本对
class ContrastiveDataset(Dataset):
    def __init__(self, dataset):
        self.dataset = dataset
        self.transform = transform

    def __getitem__(self, index):
        # 原始图像和增强图像
        img, label = self.dataset[index]
        positive_img = self.transform(img)
        negative_index = np.random.choice(len(self.dataset))
        negative_img, _ = self.dataset[negative_index]
        negative_img = self.transform(negative_img)
        
        return positive_img, negative_img, label

    def __len__(self):
        return len(self.dataset)

# 构建数据集和数据加载器
dataset = CIFAR10(root='./data', train=True, download=True, transform=transform)
contrastive_dataset = ContrastiveDataset(dataset)
dataloader = DataLoader(contrastive_dataset, batch_size=32, shuffle=True)

# 模型定义，使用简单的CNN作为编码器
class Encoder(nn.Module):
    def __init__(self):
        super(Encoder, self).__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(3, 64, kernel_size=3, stride=2, padding=1),
            nn.ReLU(),
            nn.Conv2d(64, 128, kernel_size=3, stride=2, padding=1),
            nn.ReLU(),
            nn.Flatten(),
            nn.Linear(128 * 8 * 8, 256)
        )

    def forward(self, x):
        return self.conv(x)

# 对比损失定义
class ContrastiveLoss(nn.Module):
    def __init__(self, margin=1.0):
        super(ContrastiveLoss, self).__init__()
        self.margin = margin

    def forward(self, positive_embedding, negative_embedding):
        # 计算正负样本对的距离
        pos_dist = torch.norm(positive_embedding, dim=1)
        neg_dist = torch.norm(negative_embedding, dim=1)
        # 对比损失
        loss = torch.mean((pos_dist - neg_dist + self.margin).clamp(min=0))
        return loss

# 初始化模型和损失函数
encoder = Encoder()
contrastive_loss = ContrastiveLoss()
optimizer = optim.Adam(encoder.parameters(), lr=0.001)

# 训练过程
for epoch in range(5):  # 示例中设为5个epoch
    total_loss = 0
    for positive_img, negative_img, _ in dataloader:
        positive_embedding = encoder(positive_img)
        negative_embedding = encoder(negative_img)
        
        # 计算损失并进行反向传播
        loss = contrastive_loss(positive_embedding, negative_embedding)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        
        total_loss += loss.item()
    
    print(f"Epoch {epoch + 1}, Loss: {total_loss / len(dataloader)}")

# 显示最终结果
print("对比学习训练完成，模型已学习到将正样本对拉近、负样本对拉远的特性")


-----------------------------------------------------------------------------------------------------------------


import torch
import torch.nn as nn
import torch.nn.functional as F

class ContrastiveLoss(nn.Module):
    def __init__(self, margin=1.0):
        super(ContrastiveLoss, self).__init__()
        self.margin = margin

    def forward(self, anchor, positive, negative):
        # 计算正样本对之间的欧几里得距离
        pos_distance = F.pairwise_distance(anchor, positive, keepdim=True)
        
        # 计算负样本对之间的欧几里得距离
        neg_distance = F.pairwise_distance(anchor, negative, keepdim=True)
        
        # 损失函数包含两部分：正样本对距离的平方，以及负样本对距离和 margin 之差的平方
        loss_positive = torch.mean(pos_distance ** 2)
        loss_negative = torch.mean(F.relu(self.margin - neg_distance) ** 2)
        
        # 总的对比损失是正负样本对损失的加权和
        loss = loss_positive + loss_negative
        return loss

# 创建损失函数实例
margin = 1.0  # margin 值可以根据具体任务进行调整
contrastive_loss = ContrastiveLoss(margin=margin)

# 示例数据
# anchor、positive、negative 代表一个批次的锚点样本、正样本对和负样本对的嵌入向量
# 使用随机数据生成三组向量以模拟嵌入结果
anchor = torch.randn(10, 128)    # 10 个样本，每个样本的嵌入向量大小为 128
positive = torch.randn(10, 128)  # 正样本对
negative = torch.randn(10, 128)  # 负样本对

# 计算损失
loss = contrastive_loss(anchor, positive, negative)

print(f"Contrastive Loss: {loss.item()}")

# 正样本对距离和负样本对距离
pos_distance = F.pairwise_distance(anchor, positive, keepdim=True)
neg_distance = F.pairwise_distance(anchor, negative, keepdim=True)

print(f"Positive Pair Distance (mean): {pos_distance.mean().item()}")
print(f"Negative Pair Distance (mean): {neg_distance.mean().item()}")


-----------------------------------------------------------------------------------------------------------------


import torch
import torch.nn as nn
import torch.optim as optim
import torchvision.transforms as transforms
from torchvision.datasets import CIFAR10
from torch.utils.data import DataLoader
import torch.nn.functional as F
import numpy as np

# 数据增强：包括随机裁剪、颜色抖动、水平翻转等
transform = transforms.Compose([
    transforms.RandomResizedCrop(32),
    transforms.RandomHorizontalFlip(),
    transforms.ColorJitter(0.4, 0.4, 0.4, 0.4),
    transforms.ToTensor()
])

# SimCLR 数据集
class SimCLRDataset(torch.utils.data.Dataset):
    def __init__(self, dataset):
        self.dataset = dataset
        self.transform = transform

    def __getitem__(self, idx):
        img, _ = self.dataset[idx]
        img1 = self.transform(img)
        img2 = self.transform(img)
        return img1, img2

    def __len__(self):
        return len(self.dataset)

# CIFAR-10数据集
dataset = CIFAR10(root='./data', train=True, download=True)
simclr_dataset = SimCLRDataset(dataset)
dataloader = DataLoader(simclr_dataset, batch_size=64, shuffle=True)

# 简单的编码器网络
class Encoder(nn.Module):
    def __init__(self):
        super(Encoder, self).__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(3, 64, kernel_size=3, stride=2, padding=1),
            nn.ReLU(),
            nn.Conv2d(64, 128, kernel_size=3, stride=2, padding=1),
            nn.ReLU(),
            nn.Flatten(),
            nn.Linear(128 * 8 * 8, 256)
        )

    def forward(self, x):
        return self.conv(x)

# 投影头
class ProjectionHead(nn.Module):
    def __init__(self, input_dim=256, output_dim=128):
        super(ProjectionHead, self).__init__()
        self.fc = nn.Sequential(
            nn.Linear(input_dim, 128),
            nn.ReLU(),
            nn.Linear(128, output_dim)
        )

    def forward(self, x):
        return self.fc(x)

# 定义 NT-Xent 对比损失
class NTXentLoss(nn.Module):
    def __init__(self, temperature=0.5):
        super(NTXentLoss, self).__init__()
        self.temperature = temperature
        self.cosine_similarity = nn.CosineSimilarity(dim=-1)

    def forward(self, z_i, z_j):
        N = z_i.size(0)
        z_i = F.normalize(z_i, dim=-1)
        z_j = F.normalize(z_j, dim=-1)
        
        # 矩阵计算
        positives = self.cosine_similarity(z_i, z_j).view(N, 1)
        negatives = self.cosine_similarity(z_i.unsqueeze(1), z_j.unsqueeze(0))
        
        labels = torch.zeros(N).long()
        logits = torch.cat([positives, negatives], dim=1) / self.temperature
        loss = F.cross_entropy(logits, labels)
        
        return loss

# 模型、损失和优化器定义
encoder = Encoder()
projection_head = ProjectionHead()
criterion = NTXentLoss(temperature=0.5)
optimizer = optim.Adam(list(encoder.parameters()) + list(projection_head.parameters()), lr=0.001)

# 训练循环
for epoch in range(5):  # 示例设置为5个epoch
    epoch_loss = 0
    for img1, img2 in dataloader:
        z_i = projection_head(encoder(img1))
        z_j = projection_head(encoder(img2))
        
        # 计算对比损失
        loss = criterion(z_i, z_j)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        
        epoch_loss += loss.item()

    print(f"Epoch [{epoch+1}/5], Loss: {epoch_loss / len(dataloader)}")

print("SimCLR训练完成，对比学习模型已收敛。")


-----------------------------------------------------------------------------------------------------------------


import torch
import torch.nn as nn
import torch.optim as optim
import torchvision.transforms as transforms
from torchvision.datasets import CIFAR10
from torch.utils.data import DataLoader
import torch.nn.functional as F
# 定义数据增强策略
transform = transforms.Compose([
    transforms.RandomResizedCrop(32),     # 随机裁剪到32x32
    transforms.RandomHorizontalFlip(),    # 随机水平翻转
    transforms.ColorJitter(0.4, 0.4, 0.4, 0.4),  # 随机调整亮度、对比度、饱和度、色调
    transforms.ToTensor()
])

# 创建SimCLR专用数据集类
class SimCLRDataset(torch.utils.data.Dataset):
    def __init__(self, dataset):
        self.dataset = dataset
        self.transform = transform

    def __getitem__(self, idx):
        img, _ = self.dataset[idx]
        img1 = self.transform(img)
        img2 = self.transform(img)
        return img1, img2  # 返回两个不同增强的视图

    def __len__(self):
        return len(self.dataset)

# 加载CIFAR-10数据集
dataset = CIFAR10(root='./data', train=True, download=True)
simclr_dataset = SimCLRDataset(dataset)
dataloader = DataLoader(simclr_dataset, batch_size=64, shuffle=True)
# 定义编码器
class Encoder(nn.Module):
    def __init__(self):
        super(Encoder, self).__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(3, 64, kernel_size=3, stride=2, padding=1),
            nn.ReLU(),
            nn.Conv2d(64, 128, kernel_size=3, stride=2, padding=1),
            nn.ReLU(),
            nn.Flatten(),
            nn.Linear(128 * 8 * 8, 256)  # 输出为256维的特征向量
        )

    def forward(self, x):
        return self.conv(x)

# 定义投影头
class ProjectionHead(nn.Module):
    def __init__(self, input_dim=256, output_dim=128):
        super(ProjectionHead, self).__init__()
        self.fc = nn.Sequential(
            nn.Linear(input_dim, 128),
            nn.ReLU(),
            nn.Linear(128, output_dim)
        )

    def forward(self, x):
        return self.fc(x)
class NTXentLoss(nn.Module):
    def __init__(self, temperature=0.5):
        super(NTXentLoss, self).__init__()
        self.temperature = temperature
        self.cosine_similarity = nn.CosineSimilarity(dim=-1)

    def forward(self, z_i, z_j):
        N = z_i.size(0)  # 批量大小
        z_i = F.normalize(z_i, dim=-1)  # L2标准化
        z_j = F.normalize(z_j, dim=-1)
        
        # 计算相似度
        positives = self.cosine_similarity(z_i, z_j).view(N, 1)
        negatives = self.cosine_similarity(z_i.unsqueeze(1), z_j.unsqueeze(0))
        
        labels = torch.zeros(N).long()
        logits = torch.cat([positives, negatives], dim=1) / self.temperature
        loss = F.cross_entropy(logits, labels)
        
        return loss
# 初始化编码器和投影头
encoder = Encoder()
projection_head = ProjectionHead()
# 初始化对比损失
criterion = NTXentLoss(temperature=0.5)
# 初始化优化器
optimizer = optim.Adam(list(encoder.parameters()) + list(projection_head.parameters()), lr=0.001)
# 训练SimCLR
for epoch in range(5):  # 示例为5个epoch
    epoch_loss = 0
    for img1, img2 in dataloader:
        # 前向传播
        z_i = projection_head(encoder(img1))
        z_j = projection_head(encoder(img2))
        
        # 计算损失
        loss = criterion(z_i, z_j)
        
        # 反向传播
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        
        epoch_loss += loss.item()

    print(f"Epoch [{epoch+1}/5], Loss: {epoch_loss / len(dataloader)}")

print("SimCLR训练完成，模型已收敛。")


-----------------------------------------------------------------------------------------------------------------


import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torch.utils.data import DataLoader
from torchvision import datasets, transforms

# 定义数据增强
transform = transforms.Compose([
    transforms.RandomResizedCrop(size=32),
    transforms.RandomHorizontalFlip(),
    transforms.ColorJitter(0.4, 0.4, 0.4, 0.4),
    transforms.ToTensor()
])

# 定义自监督数据集
class ContrastiveLearningDataset(torch.utils.data.Dataset):
    def __init__(self, dataset):
        self.dataset = dataset
        self.transform = transform

    def __getitem__(self, index):
        img, _ = self.dataset[index]
        img1 = self.transform(img)
        img2 = self.transform(img)
        return img1, img2

    def __len__(self):
        return len(self.dataset)

# 加载数据集
dataset = datasets.CIFAR10(root="./data", download=True)
contrastive_dataset = ContrastiveLearningDataset(dataset)
dataloader = DataLoader(contrastive_dataset, batch_size=64, shuffle=True)

# 定义编码器网络
class Encoder(nn.Module):
    def __init__(self):
        super(Encoder, self).__init__()
        self.conv_layers = nn.Sequential(
            nn.Conv2d(3, 64, kernel_size=3, stride=2, padding=1),
            nn.ReLU(),
            nn.Conv2d(64, 128, kernel_size=3, stride=2, padding=1),
            nn.ReLU(),
            nn.Conv2d(128, 256, kernel_size=3, stride=2, padding=1),
            nn.ReLU()
        )
        self.fc = nn.Linear(256 * 4 * 4, 128)

    def forward(self, x):
        x = self.conv_layers(x)
        x = x.view(x.size(0), -1)
        return self.fc(x)

# 定义投影头网络
class ProjectionHead(nn.Module):
    def __init__(self, input_dim=128, output_dim=64):
        super(ProjectionHead, self).__init__()
        self.layers = nn.Sequential(
            nn.Linear(input_dim, 64),
            nn.ReLU(),
            nn.Linear(64, output_dim)
        )

    def forward(self, x):
        return self.layers(x)

# 定义对比损失
class NTXentLoss(nn.Module):
    def __init__(self, temperature=0.5):
        super(NTXentLoss, self).__init__()
        self.temperature = temperature
        self.cosine_similarity = nn.CosineSimilarity(dim=-1)

    def forward(self, z_i, z_j):
        z_i = F.normalize(z_i, dim=-1)
        z_j = F.normalize(z_j, dim=-1)
        
        # 计算正样本对相似度
        pos_sim = self.cosine_similarity(z_i, z_j)
        
        # 计算负样本对相似度
        N = z_i.size(0)
        neg_sim = torch.mm(z_i, z_j.T) / self.temperature
        labels = torch.arange(N).long()
        logits = torch.cat([pos_sim.unsqueeze(1), neg_sim], dim=1)
        loss = F.cross_entropy(logits, labels)
        
        return loss

# 初始化模型和损失
encoder = Encoder()
projection_head = ProjectionHead()
criterion = NTXentLoss(temperature=0.5)
optimizer = optim.Adam(list(encoder.parameters()) + list(projection_head.parameters()), lr=1e-3)

# 开始训练
for epoch in range(5):  # 示例为5个epoch
    epoch_loss = 0
    for img1, img2 in dataloader:
        # 获取编码器特征
        h_i = encoder(img1)
        h_j = encoder(img2)
        
        # 生成投影向量
        z_i = projection_head(h_i)
        z_j = projection_head(h_j)
        
        # 计算对比损失
        loss = criterion(z_i, z_j)
        
        # 反向传播和优化
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        
        epoch_loss += loss.item()

    print(f"Epoch [{epoch+1}/5], Loss: {epoch_loss / len(dataloader)}")

print("对比学习自监督预训练完成。")


-----------------------------------------------------------------------------------------------------------------


import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, random_split
from torchvision import datasets, transforms

# 定义数据增强
transform = transforms.Compose([
    transforms.Resize((32, 32)),
    transforms.ToTensor()
])

# 加载CIFAR-10数据集
dataset = datasets.CIFAR10(root="./data", train=True, transform=transform, download=True)
train_size = int(0.8 * len(dataset))
val_size = len(dataset) - train_size
train_dataset, val_dataset = random_split(dataset, [train_size, val_size])

train_loader = DataLoader(train_dataset, batch_size=64, shuffle=True)
val_loader = DataLoader(val_dataset, batch_size=64, shuffle=False)

# 定义分类器网络，使用预训练的编码器
class Classifier(nn.Module):
    def __init__(self, encoder, num_classes=10):
        super(Classifier, self).__init__()
        self.encoder = encoder  # 使用预训练编码器
        self.fc = nn.Linear(128, num_classes)  # 添加新的分类头

    def forward(self, x):
        with torch.no_grad():  # 冻结编码器
            features = self.encoder(x)
        return self.fc(features)

# 加载之前的预训练编码器
pretrained_encoder = Encoder()  # 假设之前已经实例化了 Encoder 类并完成了训练

# 实例化分类器
classifier = Classifier(pretrained_encoder, num_classes=10)

# 解冻分类器并对分类头进行微调
optimizer = optim.Adam(classifier.fc.parameters(), lr=1e-3)
criterion = nn.CrossEntropyLoss()

# 定义微调过程
def fine_tune(model, train_loader, val_loader, criterion, optimizer, num_epochs=5):
    model.train()
    for epoch in range(num_epochs):
        total_loss = 0
        correct = 0
        total = 0

        # 训练循环
        for images, labels in train_loader:
            optimizer.zero_grad()
            outputs = model(images)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()

            total_loss += loss.item()
            _, predicted = torch.max(outputs.data, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()

        train_accuracy = 100 * correct / total
        val_loss, val_accuracy = validate(model, val_loader, criterion)
        print(f"Epoch [{epoch+1}/{num_epochs}], Loss: {total_loss/len(train_loader):.4f}, "
              f"Train Acc: {train_accuracy:.2f}%, Val Loss: {val_loss:.4f}, Val Acc: {val_accuracy:.2f}%")

# 定义验证过程
def validate(model, val_loader, criterion):
    model.eval()
    val_loss = 0
    correct = 0
    total = 0

    with torch.no_grad():
        for images, labels in val_loader:
            outputs = model(images)
            loss = criterion(outputs, labels)
            val_loss += loss.item()
            _, predicted = torch.max(outputs.data, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()

    accuracy = 100 * correct / total
    return val_loss / len(val_loader), accuracy

# 开始微调
fine_tune(classifier, train_loader, val_loader, criterion, optimizer, num_epochs=5)


-----------------------------------------------------------------------------------------------------------------


import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, random_split
from torchvision import datasets, transforms

# 定义数据增强
transform = transforms.Compose([
    transforms.Resize((32, 32)),
    transforms.ToTensor()
])

# 加载CIFAR-10数据集
dataset = datasets.CIFAR10(root="./data", train=True, transform=transform, download=True)
train_size = int(0.8 * len(dataset))
val_size = len(dataset) - train_size
train_dataset, val_dataset = random_split(dataset, [train_size, val_size])

train_loader = DataLoader(train_dataset, batch_size=64, shuffle=True)
val_loader = DataLoader(val_dataset, batch_size=64, shuffle=False)
# 定义分类器网络，使用预训练的编码器
class Classifier(nn.Module):
    def __init__(self, encoder, num_classes=10):
        super(Classifier, self).__init__()
        self.encoder = encoder  # 使用预训练编码器
        self.fc = nn.Linear(128, num_classes)  # 添加新的分类头

    def forward(self, x):
        with torch.no_grad():  # 冻结编码器
            features = self.encoder(x)
        return self.fc(features)

# 加载之前的预训练编码器
pretrained_encoder = Encoder()  # 假设之前已经实例化了 Encoder 类并完成了训练

# 实例化分类器
classifier = Classifier(pretrained_encoder, num_classes=10)
# 定义损失函数和优化器
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(classifier.fc.parameters(), lr=1e-3)  # 只优化分类头的参数
# 定义微调过程
def fine_tune(model, train_loader, val_loader, criterion, optimizer, num_epochs=5):
    model.train()
    for epoch in range(num_epochs):
        total_loss = 0
        correct = 0
        total = 0

        # 训练循环
        for images, labels in train_loader:
            optimizer.zero_grad()
            outputs = model(images)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()

            total_loss += loss.item()
            _, predicted = torch.max(outputs.data, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()

        train_accuracy = 100 * correct / total
        val_loss, val_accuracy = validate(model, val_loader, criterion)
        print(f"Epoch [{epoch+1}/{num_epochs}], Loss: {total_loss/len(train_loader):.4f}, "
              f"Train Acc: {train_accuracy:.2f}%, Val Loss: {val_loss:.4f}, Val Acc: {val_accuracy:.2f}%")
# 定义验证过程
def validate(model, val_loader, criterion):
    model.eval()
    val_loss = 0
    correct = 0
    total = 0

    with torch.no_grad():
        for images, labels in val_loader:
            outputs = model(images)
            loss = criterion(outputs, labels)
            val_loss += loss.item()
            _, predicted = torch.max(outputs.data, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()

    accuracy = 100 * correct / total
    return val_loss / len(val_loader), accuracy
# 开始微调
fine_tune(classifier, train_loader, val_loader, criterion, optimizer, num_epochs=5)


-----------------------------------------------------------------------------------------------------------------


import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, random_split
from torchvision import datasets, transforms
from sklearn.manifold import TSNE
import matplotlib.pyplot as plt

# 数据准备
transform = transforms.Compose([
    transforms.Resize((32, 32)),
    transforms.ToTensor()
])

# 加载CIFAR-10数据集
dataset = datasets.CIFAR10(root="./data", train=True, transform=transform, download=True)
train_size = int(0.8 * len(dataset))
val_size = len(dataset) - train_size
train_dataset, val_dataset = random_split(dataset, [train_size, val_size])

train_loader = DataLoader(train_dataset, batch_size=64, shuffle=True)
val_loader = DataLoader(val_dataset, batch_size=64, shuffle=False)

# 模型定义（对比学习编码器 + 分类头）
class ContrastiveEncoder(nn.Module):
    def __init__(self):
        super(ContrastiveEncoder, self).__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(3, 64, kernel_size=3, stride=1, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(2, 2),
            nn.Conv2d(64, 128, kernel_size=3, stride=1, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(2, 2),
            nn.Flatten(),
            nn.Linear(128 * 8 * 8, 128)
        )

    def forward(self, x):
        return self.conv(x)

# 分类模型
class ClassificationModel(nn.Module):
    def __init__(self, encoder, num_classes=10):
        super(ClassificationModel, self).__init__()
        self.encoder = encoder
        self.fc = nn.Linear(128, num_classes)

    def forward(self, x):
        features = self.encoder(x)
        return self.fc(features)

# 训练和验证方法
def train_model(model, train_loader, criterion, optimizer, num_epochs=5):
    model.train()
    for epoch in range(num_epochs):
        total_loss = 0
        correct = 0
        total = 0

        for images, labels in train_loader:
            optimizer.zero_grad()
            outputs = model(images)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()

            total_loss += loss.item()
            _, predicted = torch.max(outputs.data, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()

        accuracy = 100 * correct / total
        print(f"Epoch [{epoch+1}/{num_epochs}], Loss: {total_loss/len(train_loader):.4f}, Accuracy: {accuracy:.2f}%")

def validate_model(model, val_loader, criterion):
    model.eval()
    val_loss = 0
    correct = 0
    total = 0
    with torch.no_grad():
        for images, labels in val_loader:
            outputs = model(images)
            loss = criterion(outputs, labels)
            val_loss += loss.item()
            _, predicted = torch.max(outputs.data, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()

    accuracy = 100 * correct / total
    print(f"Validation Loss: {val_loss/len(val_loader):.4f}, Accuracy: {accuracy:.2f}%")
    return accuracy

# 训练编码器并验证对比学习在分类任务中的表现
encoder = ContrastiveEncoder()
classification_model = ClassificationModel(encoder)
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(classification_model.parameters(), lr=1e-3)

train_model(classification_model, train_loader, criterion, optimizer, num_epochs=5)
validate_model(classification_model, val_loader, criterion)

# 使用t-SNE可视化嵌入向量的分布情况，展示对比学习在聚类任务中的表现
def visualize_embeddings(encoder, loader):
    encoder.eval()
    embeddings = []
    labels = []
    with torch.no_grad():
        for images, label in loader:
            emb = encoder(images).detach().cpu().numpy()
            embeddings.extend(emb)
            labels.extend(label.numpy())

    embeddings = TSNE(n_components=2).fit_transform(embeddings)
    plt.figure(figsize=(8, 8))
    for i in range(10):
        indices = [j for j, lbl in enumerate(labels) if lbl == i]
        plt.scatter(embeddings[indices, 0], embeddings[indices, 1], label=f'Class {i}')
    plt.legend()
    plt.show()

visualize_embeddings(encoder, val_loader)


-----------------------------------------------------------------------------------------------------------------


import torch
import torch.nn as nn
import torch.optim as optim
from torchvision import datasets, transforms
from torch.utils.data import DataLoader
import matplotlib.pyplot as plt

# 定义生成器
class Generator(nn.Module):
    def __init__(self, input_dim, output_dim):
        super(Generator, self).__init__()
        self.model = nn.Sequential(
            nn.Linear(input_dim, 256),
            nn.ReLU(True),
            nn.Linear(256, 512),
            nn.ReLU(True),
            nn.Linear(512, 1024),
            nn.ReLU(True),
            nn.Linear(1024, output_dim),
            nn.Tanh()
        )

    def forward(self, x):
        return self.model(x)

# 定义判别器
class Discriminator(nn.Module):
    def __init__(self, input_dim):
        super(Discriminator, self).__init__()
        self.model = nn.Sequential(
            nn.Linear(input_dim, 1024),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(1024, 512),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(512, 256),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(256, 1),
            nn.Sigmoid()
        )

    def forward(self, x):
        return self.model(x)

# 超参数设置
latent_dim = 100  # 生成器输入的噪声维度
image_dim = 28 * 28  # MNIST图像维度
lr = 0.0002
batch_size = 64
epochs = 50

# 数据加载
transform = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize([0.5], [0.5])  # 归一化到[-1, 1]
])

dataset = datasets.MNIST(root='./data', train=True, transform=transform, download=True)
dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=True)

# 初始化生成器和判别器
generator = Generator(latent_dim, image_dim).cuda()
discriminator = Discriminator(image_dim).cuda()

# 损失函数和优化器
criterion = nn.BCELoss()
optimizer_G = optim.Adam(generator.parameters(), lr=lr)
optimizer_D = optim.Adam(discriminator.parameters(), lr=lr)

# 训练循环
for epoch in range(epochs):
    for i, (real_images, _) in enumerate(dataloader):
        batch_size = real_images.size(0)
        real_images = real_images.view(batch_size, -1).cuda()
        
        # 创建真实标签和虚假标签
        real_labels = torch.ones(batch_size, 1).cuda()
        fake_labels = torch.zeros(batch_size, 1).cuda()
        
        # 训练判别器
        optimizer_D.zero_grad()
        outputs = discriminator(real_images)
        d_loss_real = criterion(outputs, real_labels)
        
        # 生成假样本
        z = torch.randn(batch_size, latent_dim).cuda()
        fake_images = generator(z)
        outputs = discriminator(fake_images.detach())
        d_loss_fake = criterion(outputs, fake_labels)
        
        # 总判别器损失
        d_loss = d_loss_real + d_loss_fake
        d_loss.backward()
        optimizer_D.step()
        
        # 训练生成器
        optimizer_G.zero_grad()
        outputs = discriminator(fake_images)
        g_loss = criterion(outputs, real_labels)
        g_loss.backward()
        optimizer_G.step()
        
    print(f'Epoch [{epoch+1}/{epochs}], d_loss: {d_loss.item():.4f}, g_loss: {g_loss.item():.4f}')

# 展示生成的图像
def show_generated_images(generator, latent_dim, num_images=25):
    generator.eval()
    with torch.no_grad():
        z = torch.randn(num_images, latent_dim).cuda()
        generated_images = generator(z).view(-1, 1, 28, 28).cpu()
    grid_img = torchvision.utils.make_grid(generated_images, nrow=5, normalize=True)
    plt.imshow(grid_img.permute(1, 2, 0).squeeze(), cmap="gray")
    plt.show()

show_generated_images(generator, latent_dim)


-----------------------------------------------------------------------------------------------------------------


import torch
import torch.nn as nn
import torch.optim as optim
from torchvision import datasets, transforms
from torch.utils.data import DataLoader
import matplotlib.pyplot as plt
import torchvision

# 定义生成器类
class Generator(nn.Module):
    def __init__(self, input_dim, output_dim):
        super(Generator, self).__init__()
        self.model = nn.Sequential(
            nn.Linear(input_dim, 256),
            nn.ReLU(inplace=True),
            nn.Linear(256, 512),
            nn.ReLU(inplace=True),
            nn.Linear(512, 1024),
            nn.ReLU(inplace=True),
            nn.Linear(1024, output_dim),
            nn.Tanh()  # 将生成的数据缩放到[-1, 1]
        )

    def forward(self, x):
        return self.model(x)

# 定义判别器类
class Discriminator(nn.Module):
    def __init__(self, input_dim):
        super(Discriminator, self).__init__()
        self.model = nn.Sequential(
            nn.Linear(input_dim, 1024),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(1024, 512),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(512, 256),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(256, 1),
            nn.Sigmoid()  # 输出概率值
        )

    def forward(self, x):
        return self.model(x)

# 定义超参数
latent_dim = 100  # 生成器输入噪声的维度
image_dim = 28 * 28  # MNIST图像的像素数
learning_rate = 0.0002
batch_size = 64
epochs = 50

# 数据集加载
transform = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize([0.5], [0.5])  # 将数据归一化到[-1, 1]
])

dataset = datasets.MNIST(root='./data', train=True, transform=transform, download=True)
dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=True)

# 初始化生成器和判别器
generator = Generator(latent_dim, image_dim).cuda()
discriminator = Discriminator(image_dim).cuda()

# 损失函数和优化器
criterion = nn.BCELoss()
optimizer_G = optim.Adam(generator.parameters(), lr=learning_rate)
optimizer_D = optim.Adam(discriminator.parameters(), lr=learning_rate)

# 训练过程
for epoch in range(epochs):
    for i, (real_images, _) in enumerate(dataloader):
        batch_size = real_images.size(0)
        real_images = real_images.view(batch_size, -1).cuda()
        
        # 创建真实标签和假标签
        real_labels = torch.ones(batch_size, 1).cuda()
        fake_labels = torch.zeros(batch_size, 1).cuda()
        
        # 训练判别器
        optimizer_D.zero_grad()
        outputs = discriminator(real_images)
        d_loss_real = criterion(outputs, real_labels)
        
        # 生成假样本并计算判别器损失
        z = torch.randn(batch_size, latent_dim).cuda()
        fake_images = generator(z)
        outputs = discriminator(fake_images.detach())
        d_loss_fake = criterion(outputs, fake_labels)
        
        # 判别器总损失
        d_loss = d_loss_real + d_loss_fake
        d_loss.backward()
        optimizer_D.step()
        
        # 训练生成器
        optimizer_G.zero_grad()
        outputs = discriminator(fake_images)
        g_loss = criterion(outputs, real_labels)
        g_loss.backward()
        optimizer_G.step()
        
    print(f'Epoch [{epoch+1}/{epochs}], d_loss: {d_loss.item():.4f}, g_loss: {g_loss.item():.4f}')

# 可视化生成的图像
def show_generated_images(generator, latent_dim, num_images=25):
    generator.eval()
    with torch.no_grad():
        z = torch.randn(num_images, latent_dim).cuda()
        generated_images = generator(z).view(-1, 1, 28, 28).cpu()
    grid_img = torchvision.utils.make_grid(generated_images, nrow=5, normalize=True)
    plt.imshow(grid_img.permute(1, 2, 0).squeeze(), cmap="gray")
    plt.show()

show_generated_images(generator, latent_dim)


-----------------------------------------------------------------------------------------------------------------


import torch
import torch.nn as nn
import torch.optim as optim
from torchvision import datasets, transforms
from torch.utils.data import DataLoader
import torchvision
import matplotlib.pyplot as plt

# 定义生成器
class Generator(nn.Module):
    def __init__(self, latent_dim, output_dim):
        super(Generator, self).__init__()
        self.model = nn.Sequential(
            nn.Linear(latent_dim, 128),
            nn.ReLU(True),
            nn.Linear(128, 256),
            nn.ReLU(True),
            nn.Linear(256, 512),
            nn.ReLU(True),
            nn.Linear(512, output_dim),
            nn.Tanh()
        )

    def forward(self, x):
        return self.model(x)

# 定义判别器
class Discriminator(nn.Module):
    def __init__(self, input_dim):
        super(Discriminator, self).__init__()
        self.model = nn.Sequential(
            nn.Linear(input_dim, 512),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(512, 256),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(256, 1),
            nn.Sigmoid()
        )

    def forward(self, x):
        return self.model(x)

# 超参数设置
latent_dim = 100
image_dim = 28 * 28
batch_size = 64
epochs = 50
lr = 0.0002

# 数据集和数据加载
transform = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize([0.5], [0.5])
])
dataset = datasets.MNIST(root='./data', train=True, transform=transform, download=True)
dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=True)

# 初始化生成器和判别器
generator = Generator(latent_dim, image_dim).cuda()
discriminator = Discriminator(image_dim).cuda()

# 损失函数和优化器
criterion = nn.BCELoss()
optimizer_G = optim.Adam(generator.parameters(), lr=lr)
optimizer_D = optim.Adam(discriminator.parameters(), lr=lr)

# 训练过程
for epoch in range(epochs):
    for i, (real_images, _) in enumerate(dataloader):
        batch_size = real_images.size(0)
        real_images = real_images.view(batch_size, -1).cuda()

        # 真实标签和假标签
        real_labels = torch.ones(batch_size, 1).cuda()
        fake_labels = torch.zeros(batch_size, 1).cuda()

        # 训练判别器
        optimizer_D.zero_grad()
        real_outputs = discriminator(real_images)
        d_loss_real = criterion(real_outputs, real_labels)
        
        # 生成假样本并计算判别器损失
        z = torch.randn(batch_size, latent_dim).cuda()
        fake_images = generator(z)
        fake_outputs = discriminator(fake_images.detach())
        d_loss_fake = criterion(fake_outputs, fake_labels)

        # 总的判别器损失
        d_loss = d_loss_real + d_loss_fake
        d_loss.backward()
        optimizer_D.step()

        # 训练生成器
        optimizer_G.zero_grad()
        fake_outputs = discriminator(fake_images)
        g_loss = criterion(fake_outputs, real_labels)
        g_loss.backward()
        optimizer_G.step()

    print(f'Epoch [{epoch+1}/{epochs}], d_loss: {d_loss.item():.4f}, g_loss: {g_loss.item():.4f}')

# 展示生成的图像
def show_generated_images(generator, latent_dim, num_images=25):
    generator.eval()
    with torch.no_grad():
        z = torch.randn(num_images, latent_dim).cuda()
        generated_images = generator(z).view(-1, 1, 28, 28).cpu()
    grid_img = torchvision.utils.make_grid(generated_images, nrow=5, normalize=True)
    plt.imshow(grid_img.permute(1, 2, 0).squeeze(), cmap="gray")
    plt.show()

show_generated_images(generator, latent_dim)


-----------------------------------------------------------------------------------------------------------------


import torch
import torch.nn as nn
import torch.optim as optim
from torchvision import datasets, transforms
from torch.utils.data import DataLoader
import matplotlib.pyplot as plt
import torchvision

# 定义生成器模型
class Generator(nn.Module):
    def __init__(self, latent_dim, output_dim):
        super(Generator, self).__init__()
        self.model = nn.Sequential(
            nn.Linear(latent_dim, 128),
            nn.ReLU(inplace=True),
            nn.Linear(128, 256),
            nn.ReLU(inplace=True),
            nn.Linear(256, 512),
            nn.ReLU(inplace=True),
            nn.Linear(512, output_dim),
            nn.Tanh()
        )

    def forward(self, x):
        return self.model(x)

# 定义判别器模型
class Discriminator(nn.Module):
    def __init__(self, input_dim):
        super(Discriminator, self).__init__()
        self.model = nn.Sequential(
            nn.Linear(input_dim, 512),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(512, 256),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(256, 1),
            nn.Sigmoid()
        )

    def forward(self, x):
        return self.model(x)

# 参数定义
latent_dim = 100
image_dim = 28 * 28
batch_size = 64
epochs = 50
lr = 0.0002

# 数据集准备
transform = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize([0.5], [0.5])
])
dataset = datasets.MNIST(root='./data', train=True, transform=transform, download=True)
dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=True)

# 初始化生成器和判别器
generator = Generator(latent_dim, image_dim).cuda()
discriminator = Discriminator(image_dim).cuda()

# 损失函数和优化器
criterion = nn.BCELoss()
optimizer_G = optim.Adam(generator.parameters(), lr=lr)
optimizer_D = optim.Adam(discriminator.parameters(), lr=lr)

# 交替训练过程
for epoch in range(epochs):
    for i, (real_images, _) in enumerate(dataloader):
        batch_size = real_images.size(0)
        real_images = real_images.view(batch_size, -1).cuda()

        # 创建真实标签和假标签
        real_labels = torch.ones(batch_size, 1).cuda()
        fake_labels = torch.zeros(batch_size, 1).cuda()

        # 更新判别器
        optimizer_D.zero_grad()
        real_outputs = discriminator(real_images)
        d_loss_real = criterion(real_outputs, real_labels)
        
        # 生成假样本并计算判别器损失
        z = torch.randn(batch_size, latent_dim).cuda()
        fake_images = generator(z)
        fake_outputs = discriminator(fake_images.detach())
        d_loss_fake = criterion(fake_outputs, fake_labels)

        # 判别器总损失
        d_loss = d_loss_real + d_loss_fake
        d_loss.backward()
        optimizer_D.step()

        # 更新生成器
        optimizer_G.zero_grad()
        fake_outputs = discriminator(fake_images)
        g_loss = criterion(fake_outputs, real_labels)
        g_loss.backward()
        optimizer_G.step()

    print(f'Epoch [{epoch+1}/{epochs}], d_loss: {d_loss.item():.4f}, g_loss: {g_loss.item():.4f}')

# 展示生成样本
def show_generated_images(generator, latent_dim, num_images=25):
    generator.eval()
    with torch.no_grad():
        z = torch.randn(num_images, latent_dim).cuda()
        generated_images = generator(z).view(-1, 1, 28, 28).cpu()
    grid_img = torchvision.utils.make_grid(generated_images, nrow=5, normalize=True)
    plt.imshow(grid_img.permute(1, 2, 0).squeeze(), cmap="gray")
    plt.show()

show_generated_images(generator, latent_dim)


-----------------------------------------------------------------------------------------------------------------


import torch
import torch.nn as nn
import torch.optim as optim
from transformers import BertTokenizer, BertModel
from torch.utils.data import DataLoader, Dataset
import numpy as np

# 创建用户评价数据集（简单示例）
class TextDataset(Dataset):
    def __init__(self, texts, labels):
        self.texts = texts
        self.labels = labels
        self.tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
        
    def __len__(self):
        return len(self.texts)
    
    def __getitem__(self, idx):
        tokens = self.tokenizer(self.texts[idx], padding='max_length', truncation=True, max_length=128, return_tensors='pt')
        return tokens['input_ids'].squeeze(), tokens['attention_mask'].squeeze(), torch.tensor(self.labels[idx])

# 简单用户评价样本与标签
texts = ["This product is great!", "Worst purchase ever.", "Not bad, but could be better.", "I absolutely love it!", "Terrible experience."]
labels = [1, 0, 1, 1, 0]
dataset = TextDataset(texts, labels)
dataloader = DataLoader(dataset, batch_size=2, shuffle=True)

# 定义BERT分类器
class BertClassifier(nn.Module):
    def __init__(self):
        super(BertClassifier, self).__init__()
        self.bert = BertModel.from_pretrained('bert-base-uncased')
        self.classifier = nn.Linear(self.bert.config.hidden_size, 2)  # 二分类
        
    def forward(self, input_ids, attention_mask):
        outputs = self.bert(input_ids=input_ids, attention_mask=attention_mask)
        cls_output = outputs.last_hidden_state[:, 0, :]  # [CLS] token的输出
        return self.classifier(cls_output)

# 初始化模型、损失函数与优化器
model = BertClassifier().cuda()
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=2e-5)

# 对抗训练的扰动生成函数
def adversarial_attack(input_embeddings, epsilon=1e-3):
    noise = torch.randn_like(input_embeddings).detach()
    noise = epsilon * noise / noise.norm(p=2, dim=-1, keepdim=True)  # 添加扰动
    return input_embeddings + noise

# 对抗训练过程
for epoch in range(5):
    for input_ids, attention_mask, labels in dataloader:
        input_ids, attention_mask, labels = input_ids.cuda(), attention_mask.cuda(), labels.cuda()

        # 正常的前向传播与损失计算
        optimizer.zero_grad()
        outputs = model(input_ids, attention_mask)
        loss = criterion(outputs, labels)
        
        # 生成对抗样本
        input_embeddings = model.bert.embeddings(input_ids)
        adversarial_embeddings = adversarial_attack(input_embeddings)
        
        # 将对抗样本嵌入传入模型
        adv_outputs = model(adversarial_embeddings, attention_mask)
        adv_loss = criterion(adv_outputs, labels)
        
        # 结合正常损失与对抗损失
        total_loss = (loss + adv_loss) / 2
        total_loss.backward()
        optimizer.step()

    print(f'Epoch {epoch+1}, Loss: {total_loss.item():.4f}')

# 预测函数（测试模型在正常和对抗性样本上的表现）
def predict(text):
    model.eval()
    tokens = dataset.tokenizer(text, padding='max_length', truncation=True, max_length=128, return_tensors='pt')
    input_ids, attention_mask = tokens['input_ids'].cuda(), tokens['attention_mask'].cuda()
    
    with torch.no_grad():
        output = model(input_ids, attention_mask)
        prediction = torch.argmax(output, dim=1)
    return "Positive" if prediction.item() == 1 else "Negative"

# 测试模型在正常和对抗样本上的表现
test_text = "I enjoyed the product, but it has some issues."
print("Prediction on normal input:", predict(test_text))

# 创建对抗性输入
tokens = dataset.tokenizer(test_text, padding='max_length', truncation=True, max_length=128, return_tensors='pt')
input_ids, attention_mask = tokens['input_ids'].cuda(), tokens['attention_mask'].cuda()
input_embeddings = model.bert.embeddings(input_ids)
adversarial_input = adversarial_attack(input_embeddings)
with torch.no_grad():
    adv_output = model(adversarial_input, attention_mask)
    adv_prediction = torch.argmax(adv_output, dim=1)

print("Prediction on adversarial input:", "Positive" if adv_prediction.item() == 1 else "Negative")
