-----------------------------------------------------------------------------------------------------------------


import torch
import torch.nn as nn
import torch.nn.functional as F

# 定义自注意力机制
class SelfAttention(nn.Module):
    def __init__(self, embed_size, heads):
        super(SelfAttention, self).__init__()
        self.embed_size = embed_size
        self.heads = heads
        self.head_dim = embed_size // heads

        assert self.head_dim * heads == embed_size, "Embedding size必须是heads的整数倍"

        self.values = nn.Linear(self.head_dim, self.head_dim, bias=False)
        self.keys = nn.Linear(self.head_dim, self.head_dim, bias=False)
        self.queries = nn.Linear(self.head_dim, self.head_dim, bias=False)
        self.fc_out = nn.Linear(heads * self.head_dim, embed_size)

    def forward(self, values, keys, query, mask):
        N = query.shape[0]
        value_len, key_len, query_len = values.shape[1], keys.shape[1], query.shape[1]

        values = values.view(N, value_len, self.heads, self.head_dim)
        keys = keys.view(N, key_len, self.heads, self.head_dim)
        queries = query.view(N, query_len, self.heads, self.head_dim)

        values = self.values(values)
        keys = self.keys(keys)
        queries = self.queries(queries)

        energy = torch.einsum("nqhd,nkhd->nhqk", [queries, keys]) / (self.head_dim ** 0.5)
        
        if mask is not None:
            energy = energy.masked_fill(mask == 0, float("-1e20"))

        attention = torch.softmax(energy, dim=-1)

        out = torch.einsum("nhql,nlhd->nqhd", [attention, values]).reshape(
            N, query_len, self.heads * self.head_dim
        )
        
        return self.fc_out(out)

# 定义前馈神经网络
class FeedForward(nn.Module):
    def __init__(self, embed_size, forward_expansion):
        super(FeedForward, self).__init__()
        self.fc1 = nn.Linear(embed_size, forward_expansion * embed_size)
        self.fc2 = nn.Linear(forward_expansion * embed_size, embed_size)

    def forward(self, x):
        return self.fc2(F.relu(self.fc1(x)))

# Transformer编码器块的实现
class TransformerBlock(nn.Module):
    def __init__(self, embed_size, heads, forward_expansion, dropout):
        super(TransformerBlock, self).__init__()
        self.attention = SelfAttention(embed_size, heads)
        self.norm1 = nn.LayerNorm(embed_size)
        self.norm2 = nn.LayerNorm(embed_size)
        self.feed_forward = FeedForward(embed_size, forward_expansion)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x, mask):
        attention = self.attention(x, x, x, mask)
        x = self.dropout(self.norm1(attention + x))
        forward = self.feed_forward(x)
        out = self.dropout(self.norm2(forward + x))
        return out

# BERT编码器堆叠
class BERTEncoder(nn.Module):
    def __init__(self, embed_size, heads, forward_expansion, num_layers, dropout):
        super(BERTEncoder, self).__init__()
        self.layers = nn.ModuleList(
            [TransformerBlock(embed_size, heads, forward_expansion, dropout) for _ in range(num_layers)]
        )
        self.dropout = nn.Dropout(dropout)

    def forward(self, x, mask):
        for layer in self.layers:
            x = layer(x, mask)
        return x

# 模拟输入
embed_size = 768
heads = 12
forward_expansion = 4
num_layers = 12
dropout = 0.1
seq_length = 20
batch_size = 2

# 初始化BERT编码器堆叠
bert_encoder = BERTEncoder(embed_size, heads, forward_expansion, num_layers, dropout)

# 随机生成输入数据和掩码
input_data = torch.rand(batch_size, seq_length, embed_size)
mask = torch.ones(batch_size, seq_length, seq_length)  # 无掩码

# 前向传播
output = bert_encoder(input_data, mask)
print("编码器堆叠输出形状:", output.shape)
print("编码器堆叠输出:\n", output)


-----------------------------------------------------------------------------------------------------------------


import torch
import torch.nn as nn
import torch.nn.functional as F
import random

# 自注意力机制实现
class SelfAttention(nn.Module):
    def __init__(self, embed_size, heads):
        super(SelfAttention, self).__init__()
        self.embed_size = embed_size
        self.heads = heads
        self.head_dim = embed_size // heads

        assert self.head_dim * heads == embed_size, "Embedding size必须是heads的整数倍"

        self.values = nn.Linear(self.head_dim, self.head_dim, bias=False)
        self.keys = nn.Linear(self.head_dim, self.head_dim, bias=False)
        self.queries = nn.Linear(self.head_dim, self.head_dim, bias=False)
        self.fc_out = nn.Linear(heads * self.head_dim, embed_size)

    def forward(self, values, keys, query, mask):
        N = query.shape[0]
        value_len, key_len, query_len = values.shape[1], keys.shape[1], query.shape[1]

        values = values.view(N, value_len, self.heads, self.head_dim)
        keys = keys.view(N, key_len, self.heads, self.head_dim)
        queries = query.view(N, query_len, self.heads, self.head_dim)

        values = self.values(values)
        keys = self.keys(keys)
        queries = self.queries(queries)

        energy = torch.einsum("nqhd,nkhd->nhqk", [queries, keys]) / (self.head_dim ** 0.5)
        
        if mask is not None:
            energy = energy.masked_fill(mask == 0, float("-1e20"))

        attention = torch.softmax(energy, dim=-1)
        out = torch.einsum("nhql,nlhd->nqhd", [attention, values]).reshape(
            N, query_len, self.heads * self.head_dim
        )
        
        return self.fc_out(out)

# 掩码任务数据集创建函数
def create_masked_data(inputs, mask_token_id, vocab_size, mask_prob=0.15):
    inputs_with_masks = inputs.clone()
    labels = inputs.clone()
    
    for i in range(inputs.size(0)):
        for j in range(inputs.size(1)):
            prob = random.random()
            if prob < mask_prob:
                prob /= mask_prob
                if prob < 0.8:
                    inputs_with_masks[i, j] = mask_token_id  # 80%的概率替换为[MASK]
                elif prob < 0.9:
                    inputs_with_masks[i, j] = random.randint(0, vocab_size - 1)  # 10%的概率替换为随机词
                # 10%的概率保持不变
            else:
                labels[i, j] = -100  # 忽略不被遮掩的位置

    return inputs_with_masks, labels

# BERT编码器模块
class BERTEncoder(nn.Module):
    def __init__(self, embed_size, heads, forward_expansion, num_layers, dropout):
        super(BERTEncoder, self).__init__()
        self.layers = nn.ModuleList(
            [TransformerBlock(embed_size, heads, forward_expansion, dropout) for _ in range(num_layers)]
        )
        self.dropout = nn.Dropout(dropout)

    def forward(self, x, mask):
        for layer in self.layers:
            x = layer(x, mask)
        return x

# Transformer编码器块
class TransformerBlock(nn.Module):
    def __init__(self, embed_size, heads, forward_expansion, dropout):
        super(TransformerBlock, self).__init__()
        self.attention = SelfAttention(embed_size, heads)
        self.norm1 = nn.LayerNorm(embed_size)
        self.norm2 = nn.LayerNorm(embed_size)
        self.feed_forward = FeedForward(embed_size, forward_expansion)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x, mask):
        attention = self.attention(x, x, x, mask)
        x = self.dropout(self.norm1(attention + x))
        forward = self.feed_forward(x)
        out = self.dropout(self.norm2(forward + x))
        return out

# 前馈网络
class FeedForward(nn.Module):
    def __init__(self, embed_size, forward_expansion):
        super(FeedForward, self).__init__()
        self.fc1 = nn.Linear(embed_size, forward_expansion * embed_size)
        self.fc2 = nn.Linear(forward_expansion * embed_size, embed_size)

    def forward(self, x):
        return self.fc2(F.relu(self.fc1(x)))

# 模拟数据
vocab_size = 30522  # BERT的词汇表大小
embed_size = 768
num_layers = 12
heads = 12
forward_expansion = 4
dropout = 0.1
seq_length = 20
batch_size = 2
mask_token_id = 103  # [MASK]标记的ID

# 初始化BERT编码器
bert_encoder = BERTEncoder(embed_size, heads, forward_expansion, num_layers, dropout)

# 随机生成输入数据
input_data = torch.randint(0, vocab_size, (batch_size, seq_length))
mask = torch.ones(batch_size, seq_length, seq_length)  # 无掩码

# 创建掩码任务数据
masked_data, labels = create_masked_data(input_data, mask_token_id, vocab_size)

# 前向传播
output = bert_encoder(masked_data, mask)
print("编码器输出形状:", output.shape)
print("掩码后的输入:\n", masked_data)
print("掩码标签:\n", labels)
print("编码器输出:\n", output)


-----------------------------------------------------------------------------------------------------------------


import torch
import torch.nn as nn
import torch.nn.functional as F
import random

# 定义SelfAttention模块
class SelfAttention(nn.Module):
    def __init__(self, embed_size, heads):
        super(SelfAttention, self).__init__()
        self.embed_size = embed_size
        self.heads = heads
        self.head_dim = embed_size // heads
        assert self.head_dim * heads == embed_size, "Embedding size必须是heads的整数倍"

        self.values = nn.Linear(self.head_dim, self.head_dim, bias=False)
        self.keys = nn.Linear(self.head_dim, self.head_dim, bias=False)
        self.queries = nn.Linear(self.head_dim, self.head_dim, bias=False)
        self.fc_out = nn.Linear(heads * self.head_dim, embed_size)

    def forward(self, values, keys, query, mask):
        N = query.shape[0]
        values = values.view(N, values.shape[1], self.heads, self.head_dim)
        keys = keys.view(N, keys.shape[1], self.heads, self.head_dim)
        queries = query.view(N, query.shape[1], self.heads, self.head_dim)

        values = self.values(values)
        keys = self.keys(keys)
        queries = self.queries(queries)

        energy = torch.einsum("nqhd,nkhd->nhqk", [queries, keys]) / (self.head_dim ** 0.5)
        
        if mask is not None:
            energy = energy.masked_fill(mask == 0, float("-1e20"))

        attention = torch.softmax(energy, dim=-1)
        out = torch.einsum("nhql,nlhd->nqhd", [attention, values]).reshape(
            N, query.shape[1], self.heads * self.head_dim
        )
        return self.fc_out(out)

# 定义前馈神经网络模块
class FeedForward(nn.Module):
    def __init__(self, embed_size, forward_expansion):
        super(FeedForward, self).__init__()
        self.fc1 = nn.Linear(embed_size, forward_expansion * embed_size)
        self.fc2 = nn.Linear(forward_expansion * embed_size, embed_size)

    def forward(self, x):
        return self.fc2(F.relu(self.fc1(x)))

# Transformer块定义
class TransformerBlock(nn.Module):
    def __init__(self, embed_size, heads, forward_expansion, dropout):
        super(TransformerBlock, self).__init__()
        self.attention = SelfAttention(embed_size, heads)
        self.norm1 = nn.LayerNorm(embed_size)
        self.norm2 = nn.LayerNorm(embed_size)
        self.feed_forward = FeedForward(embed_size, forward_expansion)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x, mask):
        attention = self.attention(x, x, x, mask)
        x = self.dropout(self.norm1(attention + x))
        forward = self.feed_forward(x)
        out = self.dropout(self.norm2(forward + x))
        return out

# BERT编码器定义
class BERTEncoder(nn.Module):
    def __init__(self, embed_size, heads, forward_expansion, num_layers, dropout):
        super(BERTEncoder, self).__init__()
        self.layers = nn.ModuleList(
            [TransformerBlock(embed_size, heads, forward_expansion, dropout) for _ in range(num_layers)]
        )
        self.dropout = nn.Dropout(dropout)

    def forward(self, x, mask):
        for layer in self.layers:
            x = layer(x, mask)
        return x

# 创建掩码任务数据函数
def create_masked_data(inputs, mask_token_id, vocab_size, mask_prob=0.15):
    inputs_with_masks = inputs.clone()
    labels = inputs.clone()
    
    for i in range(inputs.size(0)):
        for j in range(inputs.size(1)):
            prob = random.random()
            if prob < mask_prob:
                prob /= mask_prob
                if prob < 0.8:
                    inputs_with_masks[i, j] = mask_token_id  # 80%的概率替换为[MASK]
                elif prob < 0.9:
                    inputs_with_masks[i, j] = random.randint(0, vocab_size - 1)  # 10%的概率替换为随机词
                # 保留原始单词的10%
            else:
                labels[i, j] = -100  # 忽略非掩码位置

    return inputs_with_masks, labels

# MLM任务实现
class MLMTask(nn.Module):
    def __init__(self, vocab_size, embed_size, heads, forward_expansion, num_layers, dropout):
        super(MLMTask, self).__init__()
        self.embedding = nn.Embedding(vocab_size, embed_size)
        self.bert_encoder = BERTEncoder(embed_size, heads, forward_expansion, num_layers, dropout)
        self.fc_out = nn.Linear(embed_size, vocab_size)

    def forward(self, x, mask):
        embeddings = self.embedding(x)
        encoder_out = self.bert_encoder(embeddings, mask)
        logits = self.fc_out(encoder_out)
        return logits

# 模拟数据
vocab_size = 30522
embed_size = 768
num_layers = 12
heads = 12
forward_expansion = 4
dropout = 0.1
seq_length = 20
batch_size = 2
mask_token_id = 103  # 假设[MASK]标记的ID

# 初始化MLM任务模型
mlm_model = MLMTask(vocab_size, embed_size, heads, forward_expansion, num_layers, dropout)

# 随机生成输入数据
input_data = torch.randint(0, vocab_size, (batch_size, seq_length))
mask = torch.ones(batch_size, seq_length, seq_length)  # 无掩码

# 创建掩码任务数据
masked_data, labels = create_masked_data(input_data, mask_token_id, vocab_size)

# 前向传播
output_logits = mlm_model(masked_data, mask)
loss_fct = nn.CrossEntropyLoss()
masked_loss = loss_fct(output_logits.view(-1, vocab_size), labels.view(-1))
print("MLM任务损失:", masked_loss.item())
print("模型输出形状:", output_logits.shape)
print("掩码后的输入:\n", masked_data)
print("掩码标签:\n", labels)
print("模型输出:\n", output_logits)


-----------------------------------------------------------------------------------------------------------------


import torch
import torch.nn as nn
import torch.nn.functional as F
import random


# 自注意力机制模块
class SelfAttention(nn.Module):
    def __init__(self, embed_size, heads):
        super(SelfAttention, self).__init__()
        self.embed_size = embed_size
        self.heads = heads
        self.head_dim = embed_size // heads

        # 检查 embed_size 是否能被 heads 整除
        assert self.head_dim * heads == embed_size, "Embedding size必须是heads的整数倍"

        # 定义 values, keys 和 queries 的线性映射
        self.values = nn.Linear(self.head_dim, self.head_dim, bias=False)
        self.keys = nn.Linear(self.head_dim, self.head_dim, bias=False)
        self.queries = nn.Linear(self.head_dim, self.head_dim, bias=False)
        self.fc_out = nn.Linear(heads * self.head_dim, embed_size)

    def forward(self, values, keys, query, mask):
        N = query.shape[0]
        value_len, key_len, query_len = values.shape[1], keys.shape[1], query.shape[1]

        # 调整 values, keys, queries 的形状
        values = values.view(N, value_len, self.heads, self.head_dim)
        keys = keys.view(N, key_len, self.heads, self.head_dim)
        queries = query.view(N, query_len, self.heads, self.head_dim)

        # 通过线性映射生成多头的 values, keys, queries
        values = self.values(values)
        keys = self.keys(keys)
        queries = self.queries(queries)

        # 计算注意力能量
        energy = torch.einsum("nqhd,nkhd->nhqk", [queries, keys]) / (self.head_dim ** 0.5)

        # 调整 mask 的形状以匹配 energy
        if mask is not None:
            mask = mask.unsqueeze(1).unsqueeze(2)  # [batch_size, 1, 1, seq_len]
            energy = energy.masked_fill(mask == 0, float("-1e20"))

        attention = torch.softmax(energy, dim=-1)
        out = torch.einsum("nhql,nlhd->nqhd", [attention, values]).reshape(
            N, query_len, self.heads * self.head_dim
        )

        return self.fc_out(out)


# 前馈网络模块
class FeedForward(nn.Module):
    def __init__(self, embed_size, forward_expansion):
        super(FeedForward, self).__init__()
        self.fc1 = nn.Linear(embed_size, forward_expansion * embed_size)
        self.fc2 = nn.Linear(forward_expansion * embed_size, embed_size)

    def forward(self, x):
        return self.fc2(F.relu(self.fc1(x)))


# Transformer编码器块
class TransformerBlock(nn.Module):
    def __init__(self, embed_size, heads, forward_expansion, dropout):
        super(TransformerBlock, self).__init__()
        self.attention = SelfAttention(embed_size, heads)
        self.norm1 = nn.LayerNorm(embed_size)
        self.norm2 = nn.LayerNorm(embed_size)
        self.feed_forward = FeedForward(embed_size, forward_expansion)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x, mask):
        attention = self.attention(x, x, x, mask)
        x = self.dropout(self.norm1(attention + x))
        forward = self.feed_forward(x)
        out = self.dropout(self.norm2(forward + x))
        return out


# BERT编码器定义
class BERTEncoder(nn.Module):
    def __init__(self, embed_size, heads, forward_expansion, num_layers, dropout):
        super(BERTEncoder, self).__init__()
        self.layers = nn.ModuleList(
            [TransformerBlock(embed_size, heads, forward_expansion, dropout) for _ in range(num_layers)]
        )
        self.dropout = nn.Dropout(dropout)

    def forward(self, x, mask):
        for layer in self.layers:
            x = layer(x, mask)
        return x


# 创建掩码任务数据
def create_masked_data(inputs, mask_token_id, vocab_size, mask_prob=0.15):
    inputs_with_masks = inputs.clone()
    labels = inputs.clone()

    for i in range(inputs.size(0)):
        for j in range(inputs.size(1)):
            prob = random.random()
            if prob < mask_prob:
                prob /= mask_prob
                if prob < 0.8:
                    inputs_with_masks[i, j] = mask_token_id  # 80%的概率替换为[MASK]
                elif prob < 0.9:
                    inputs_with_masks[i, j] = random.randint(0, vocab_size - 1)  # 10%的概率替换为随机词
                # 保留原始单词的10%
            else:
                labels[i, j] = -100  # 忽略非掩码位置

    return inputs_with_masks, labels


# MLM任务实现
class MLMTask(nn.Module):
    def __init__(self, vocab_size, embed_size, heads, forward_expansion, num_layers, dropout):
        super(MLMTask, self).__init__()
        self.embedding = nn.Embedding(vocab_size, embed_size)
        self.bert_encoder = BERTEncoder(embed_size, heads, forward_expansion, num_layers, dropout)
        self.fc_out = nn.Linear(embed_size, vocab_size)

    def forward(self, x, mask):
        embeddings = self.embedding(x)
        encoder_out = self.bert_encoder(embeddings, mask)
        logits = self.fc_out(encoder_out)
        return logits


# 模拟数据
vocab_size = 30522
embed_size = 768
num_layers = 12
heads = 12
forward_expansion = 4
dropout = 0.1
seq_length = 20
batch_size = 2
mask_token_id = 103  # 假设[MASK]标记的ID

# 初始化MLM任务模型
mlm_model = MLMTask(vocab_size, embed_size, heads, forward_expansion, num_layers, dropout)

# 随机生成输入数据
input_data = torch.randint(0, vocab_size, (batch_size, seq_length))
mask = torch.ones(batch_size, seq_length, seq_length)  # 无掩码

# 创建掩码任务数据
masked_data, labels = create_masked_data(input_data, mask_token_id, vocab_size)

# 前向传播
output_logits = mlm_model(masked_data, mask)
loss_fct = nn.CrossEntropyLoss()
masked_loss = loss_fct(output_logits.view(-1, vocab_size), labels.view(-1))
print("MLM任务损失:", masked_loss.item())
print("模型输出形状:", output_logits.shape)
print("掩码后的输入:\n", masked_data)
print("掩码标签:\n", labels)
print("模型输出:\n", output_logits)


-----------------------------------------------------------------------------------------------------------------


from transformers import BertTokenizer, BertForMaskedLM
import torch

# 初始化BERT分词器和模型
tokenizer = BertTokenizer.from_pretrained("bert-base-uncased")
model = BertForMaskedLM.from_pretrained("bert-base-uncased")

# 定义带有掩码的输入句子
text = "In the context of global economic growth, the demand for technology companies' [MASK] is rapidly increasing."

# 将输入句子编码为ID序列，并识别掩码位置
input_ids = tokenizer.encode(text, return_tensors="pt")
mask_token_index = torch.where(input_ids == tokenizer.mask_token_id)[1]

# 前向传播预测掩码位置的词汇分布
with torch.no_grad():
    output = model(input_ids)
    logits = output.logits

# 获取掩码位置的预测结果，并取概率最高的词
predicted_token_id = logits[0, mask_token_index].argmax(axis=-1)
predicted_word = tokenizer.decode(predicted_token_id)

# 将预测词插入句子中，生成完整标题
final_sentence = text.replace("[MASK]", predicted_word)
print("生成的标题:", final_sentence)


-----------------------------------------------------------------------------------------------------------------


import torch
import torch.nn as nn
import torch.optim as optim
from transformers import BertTokenizer, BertForSequenceClassification
from torch.utils.data import DataLoader, Dataset, random_split
from sklearn.metrics import accuracy_score
import numpy as np

# 自定义数据集类
class TextDataset(Dataset):
    def __init__(self, texts, labels, tokenizer, max_length):
        self.texts = texts
        self.labels = labels
        self.tokenizer = tokenizer
        self.max_length = max_length

    def __len__(self):
        return len(self.texts)

    def __getitem__(self, idx):
        text = self.texts[idx]
        label = self.labels[idx]
        encoding = self.tokenizer(
            text,
            add_special_tokens=True,
            max_length=self.max_length,
            padding="max_length",
            truncation=True,
            return_tensors="pt"
        )
        return {
            "input_ids": encoding["input_ids"].flatten(),
            "attention_mask": encoding["attention_mask"].flatten(),
            "label": torch.tensor(label, dtype=torch.long)
        }

# 数据集加载
texts = ["Example sentence 1", "Example sentence 2", "Example sentence 3"]
labels = [0, 1, 0]  # 示例标签
tokenizer = BertTokenizer.from_pretrained("bert-base-uncased")
dataset = TextDataset(texts, labels, tokenizer, max_length=32)

# 训练集和验证集拆分
train_size = int(0.8 * len(dataset))
val_size = len(dataset) - train_size
train_dataset, val_dataset = random_split(dataset, [train_size, val_size])

# 数据加载器
train_loader = DataLoader(train_dataset, batch_size=2, shuffle=True)
val_loader = DataLoader(val_dataset, batch_size=2)

# BERT模型初始化
model = BertForSequenceClassification.from_pretrained("bert-base-uncased", num_labels=2)

# 定义优化器和损失函数
optimizer = optim.AdamW(model.parameters(), lr=2e-5)
criterion = nn.CrossEntropyLoss()

# 训练函数
def train_epoch(model, data_loader, criterion, optimizer, device):
    model = model.train()
    losses = []
    correct_predictions = 0

    for batch in data_loader:
        input_ids = batch["input_ids"].to(device)
        attention_mask = batch["attention_mask"].to(device)
        labels = batch["label"].to(device)

        outputs = model(input_ids, attention_mask=attention_mask)
        loss = criterion(outputs.logits, labels)
        _, preds = torch.max(outputs.logits, dim=1)

        correct_predictions += torch.sum(preds == labels)
        losses.append(loss.item())

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

    return correct_predictions.double() / len(data_loader.dataset), np.mean(losses)

# 验证函数
def eval_model(model, data_loader, criterion, device):
    model = model.eval()
    losses = []
    correct_predictions = 0

    with torch.no_grad():
        for batch in data_loader:
            input_ids = batch["input_ids"].to(device)
            attention_mask = batch["attention_mask"].to(device)
            labels = batch["label"].to(device)

            outputs = model(input_ids, attention_mask=attention_mask)
            loss = criterion(outputs.logits, labels)
            _, preds = torch.max(outputs.logits, dim=1)

            correct_predictions += torch.sum(preds == labels)
            losses.append(loss.item())

    return correct_predictions.double() / len(data_loader.dataset), np.mean(losses)

# 训练与评估
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = model.to(device)

epochs = 3
for epoch in range(epochs):
    train_acc, train_loss = train_epoch(model, train_loader, criterion, optimizer, device)
    val_acc, val_loss = eval_model(model, val_loader, criterion, device)

    print(f"Epoch {epoch + 1}/{epochs}")
    print(f"Train loss: {train_loss}, Train accuracy: {train_acc}")
    print(f"Val loss: {val_loss}, Val accuracy: {val_acc}")
