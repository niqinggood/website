-----------------------------------------------------------------------------------------------------------------


import re
import pandas as pd

# 示例数据集
data = {
    'text': [
        "  Hello world! This is an example text with numbers 123 and symbols #, @, and so on.   ",
        "Here's another sentence: it contains HTML tags like <html> and & symbols.",
        "Numbers, punctuations...and STOP words are in this sentence!"
    ]
}
df = pd.DataFrame(data)

# 定义文本数据预处理函数
def preprocess_text(text):
    # 1. 去除前后空格
    text = text.strip()

    # 2. 转换为小写
    text = text.lower()
    
    # 3. 去除HTML标签
    text = re.sub(r'<.*?>', '', text)
    
    # 4. 去除数字
    text = re.sub(r'\d+', '', text)
    
    # 5. 去除特殊字符（保留字母和空格）
    text = re.sub(r'[^a-zA-Z\s]', '', text)
    
    # 6. 去除多余空格
    text = re.sub(r'\s+', ' ', text)
    
    return text

# 应用预处理函数
df['processed_text'] = df['text'].apply(preprocess_text)

# 显示预处理结果
print("预处理前的文本：")
print(df['text'])
print("\n预处理后的文本：")
print(df['processed_text'])


-----------------------------------------------------------------------------------------------------------------


import re
import pandas as pd

# 示例中文长文本
data = {
    'text': [
        """
        在自然语言处理领域，数据预处理是不可或缺的重要步骤。对于中文文本数据来说，预处理显得尤为重要，因为中文文本中可能包含各种特殊字符和标点符号，
        以及不同格式的编码，比如全角字符和半角字符等。在实际应用中，通常需要对原始文本进行预处理，以提升模型的学习效果。
        本文将介绍一种常见的中文文本预处理流程，涵盖去除标点符号、规范化空格、统一大小写、处理特殊字符等操作。
        例如，"你好，世界！"这句话包含了中文标点符号和空格，若直接输入模型，可能会影响模型的训练效果。
        本示例将一步步展示如何将原始文本转化为格式统一的输入，确保文本具备高质量的输入特性。
        
        首先，去除文本中的前后空格，确保输入文本的规范性。接下来，将所有字符转换为小写，以消除大小写的干扰。其次，
        使用正则表达式去除文本中的标点符号，例如句号、逗号、引号等，保留文字的核心信息，确保模型不受到噪声的干扰。此外，
        去除不必要的空格，确保每个词之间只存在一个空格，提升文本的整洁度。
        最后，文本中可能还包含某些特殊字符或乱码，需要进行进一步清理。经过这些步骤，文本数据将更加清晰，有助于提升自然语言处理模型的表现。
        例如，“这个文本中包含数字12345678和标点符号#，&，%等”，需要将这些无关的符号进行处理。
        通过规范化处理，文本将具备更好的输入效果。
        
        在实际应用中，经过预处理后的文本将能够更加准确地被模型理解，同时也能有效提升模型的训练效率。
        本次示例将展示具体的文本清洗步骤和代码实现，帮助理解文本预处理的重要性和具体操作。
        """
    ]
}
df = pd.DataFrame(data)

# 定义中文文本预处理函数
def preprocess_chinese_text(text):
    # 1. 去除前后空格
    text = text.strip()
    
    # 2. 转换为小写
    text = text.lower()
    
    # 3. 去除标点符号和特殊字符（保留汉字、字母和数字）
    text = re.sub(r'[^\u4e00-\u9fa5a-zA-Z0-9\s]', '', text)
    
    # 4. 处理全角空格转换为半角空格
    text = re.sub(r'\u3000', ' ', text)
    
    # 5. 去除多余空格
    text = re.sub(r'\s+', ' ', text)
    
    return text

# 应用预处理函数
df['processed_text'] = df['text'].apply(preprocess_chinese_text)

# 显示预处理结果
print("预处理前的文本：")
print(df['text'][0])
print("\n预处理后的文本：")
print(df['processed_text'][0])


-----------------------------------------------------------------------------------------------------------------


import re
import pandas as pd
from zhon.hanzi import punctuation as zh_punctuation

# 示例数据集
data = {
    'text': [
        "这是一段包含HTML标签的文本。<html>标签内容</html>此外，文本中还有特殊字符：#、@、$以及一些无用信息。",
        "这里是包含重复词汇的示例。比如，比如，这里有一些重复的词汇需要去除。",
        "这是一段含有停用词的文本。停用词包括：和、是、的、了、不等。",
        "  此文本包含了前后空格以及多余的空白     间隔。   ",
        "此文本中包含英文标点符号，例如: ! @ # $, 需要将这些符号进行处理。"
    ]
}
df = pd.DataFrame(data)

# 中文停用词表
stop_words = set(["和", "是", "的", "了", "不", "等"])

# 定义数据清洗函数
def clean_text(text):
    # 1. 去除HTML标签
    text = re.sub(r'<.*?>', '', text)
    
    # 2. 去除特殊字符（保留汉字、字母、数字和空格）
    text = re.sub(r'[^\u4e00-\u9fa5a-zA-Z0-9\s]', '', text)
    
    # 3. 去除中文标点符号
    text = re.sub(f'[{zh_punctuation}]', '', text)
    
    # 4. 去除前后空格
    text = text.strip()
    
    # 5. 删除多余空格
    text = re.sub(r'\s+', ' ', text)
    
    # 6. 去除停用词
    text = ' '.join([word for word in text.split() if word not in stop_words])
    
    # 7. 去除重复词汇
    words = text.split()
    unique_words = []
    for word in words:
        if word not in unique_words:
            unique_words.append(word)
    text = ' '.join(unique_words)
    
    return text

# 应用清洗函数
df['cleaned_text'] = df['text'].apply(clean_text)

# 显示清洗结果
print("清洗前的文本：")
print(df['text'])
print("\n清洗后的文本：")
print(df['cleaned_text'])


-----------------------------------------------------------------------------------------------------------------


import nltk
import random
from nltk.corpus import wordnet as wn
import pandas as pd

# 下载所需的nltk数据（仅需首次执行）
nltk.download('wordnet')
nltk.download('omw-1.4')

# 示例数据集
data = {
    'text': [
        "自然语言处理是人工智能的一个重要领域，它涉及人机交互中的语言理解和生成。",
        "机器学习和深度学习的进步推动了自然语言处理的发展。",
        "同义词替换是一种数据增强技术，能在保持语义不变的情况下扩展数据集。",
    ]
}
df = pd.DataFrame(data)

# 定义获取单词的同义词函数
def get_synonyms(word):
    synonyms = []
    for syn in wn.synsets(word):
        for lemma in syn.lemmas():
            if lemma.name() != word:  # 排除自身
                synonyms.append(lemma.name())
    return list(set(synonyms))  # 返回唯一值的同义词列表

# 同义词替换函数
def synonym_replacement(sentence, n):
    words = sentence.split()
    new_words = words[:]
    replaced = 0
    
    while replaced < n:
        word_idx = random.randint(0, len(words) - 1)
        word = words[word_idx]
        
        # 获取同义词列表
        synonyms = get_synonyms(word)
        
        # 如果存在同义词，则替换
        if synonyms:
            synonym = random.choice(synonyms)
            new_words[word_idx] = synonym
            replaced += 1
            
    return ' '.join(new_words)

# 定义增强函数，对数据集每一行进行同义词替换
def augment_text(df, num_replacements=1):
    augmented_texts = []
    
    for text in df['text']:
        # 每条文本进行同义词替换
        augmented_text = synonym_replacement(text, num_replacements)
        augmented_texts.append(augmented_text)
        
    df['augmented_text'] = augmented_texts
    return df

# 增强数据集，指定每条句子替换1个词
df = augment_text(df, num_replacements=1)

# 显示增强结果
print("原始文本：")
print(df['text'])
print("\n增强后的文本：")
print(df['augmented_text'])


-----------------------------------------------------------------------------------------------------------------


import nltk
import random
from nltk.corpus import wordnet as wn
import pandas as pd

# 下载所需的nltk数据（首次执行时需要下载）
nltk.download('wordnet')
nltk.download('omw-1.4')

# 示例数据集
data = {
    'text': [
        "自然语言处理是人工智能的一个重要领域，它涉及人机交互中的语言理解和生成。",
        "机器学习和深度学习的进步推动了自然语言处理的发展。",
        "数据增强技术可以通过多种方式扩展文本数据，以提升模型的泛化能力。",
    ]
}
df = pd.DataFrame(data)

# 获取同义词函数，用于插入词
def get_synonyms(word):
    synonyms = []
    for syn in wn.synsets(word):
        for lemma in syn.lemmas():
            if lemma.name() != word:
                synonyms.append(lemma.name())
    return list(set(synonyms)) 

# 随机插入函数
def random_insertion(sentence, n):
    words = sentence.split()
    new_words = words[:]
    
    for _ in range(n):
        # 随机选择插入的单词
        word = words[random.randint(0, len(words) - 1)]
        
        # 获取同义词并检查是否存在
        synonyms = get_synonyms(word)
        if synonyms:
            synonym = random.choice(synonyms)
            
            # 随机选择插入位置
            insert_pos = random.randint(0, len(new_words))
            new_words.insert(insert_pos, synonym)
            
    return ' '.join(new_words)

# 定义数据增强函数，对每条文本随机插入词汇
def augment_text_with_insertion(df, num_insertions=1):
    augmented_texts = []
    
    for text in df['text']:
        # 每条文本进行随机插入
        augmented_text = random_insertion(text, num_insertions)
        augmented_texts.append(augmented_text)
        
    df['augmented_text'] = augmented_texts
    return df

# 增强数据集，指定每条句子插入1个词
df = augment_text_with_insertion(df, num_insertions=1)

# 显示增强结果
print("原始文本：")
print(df['text'])
print("\n增强后的文本：")
print(df['augmented_text'])


-----------------------------------------------------------------------------------------------------------------


import random
import pandas as pd

# 示例数据集
data = {
    'text': [
        "自然语言处理是人工智能的一个重要领域，它涉及人机交互中的语言理解和生成。",
        "机器学习和深度学习的进步推动了自然语言处理的发展。",
        "数据增强技术通过扩展文本数据集，提升模型的泛化能力。",
    ]
}
df = pd.DataFrame(data)

# 随机删除函数
def random_deletion(sentence, p=0.2):
    words = sentence.split()
    if len(words) == 1:
        return sentence  # 确保句子至少有一个词
    
    new_words = []
    for word in words:
        # 根据概率决定是否保留词语
        if random.uniform(0, 1) > p:
            new_words.append(word)
    # 若所有词都删除，则随机保留一个词
    if len(new_words) == 0:
        return random.choice(words)
    return ' '.join(new_words)

# 随机顺序交换函数
def random_swap(sentence, n=1):
    words = sentence.split()
    new_words = words[:]
    for _ in range(n):
        idx1, idx2 = random.sample(range(len(new_words)), 2)
        # 交换两个随机位置的词语
        new_words[idx1], new_words[idx2] = new_words[idx2], new_words[idx1]
    return ' '.join(new_words)

# 定义数据增强函数，包含随机删除和随机顺序交换
def augment_text_with_delete_swap(df, delete_prob=0.2, swap_times=1):
    augmented_texts_delete = []
    augmented_texts_swap = []
    
    for text in df['text']:
        # 进行随机删除
        augmented_text_delete = random_deletion(text, delete_prob)
        augmented_texts_delete.append(augmented_text_delete)
        
        # 进行随机顺序交换
        augmented_text_swap = random_swap(text, swap_times)
        augmented_texts_swap.append(augmented_text_swap)
        
    df['augmented_text_delete'] = augmented_texts_delete
    df['augmented_text_swap'] = augmented_texts_swap
    return df

# 增强数据集
df = augment_text_with_delete_swap(df, delete_prob=0.2, swap_times=1)

# 显示增强结果
print("原始文本：")
print(df['text'])
print("\n随机删除后的文本：")
print(df['augmented_text_delete'])
print("\n随机顺序交换后的文本：")
print(df['augmented_text_swap'])


-----------------------------------------------------------------------------------------------------------------


import re
import pandas as pd
from collections import Counter, defaultdict

# 示例数据
data = {
    'text': [
        "自然语言处理是人工智能的一个重要领域。",
        "数据增强技术可以扩展数据集，提高模型的泛化能力。",
        "深度学习和机器学习是现代人工智能的核心技术。",
    ]
}
df = pd.DataFrame(data)

# 定义分词函数
def get_vocab(texts):
    vocab = Counter()
    for text in texts:
        text = ' '.join(list(text))  # 初始按字符切分
        vocab.update(text.split())
    return vocab

# BPE分词合并
def merge_vocab(vocab, pair):
    new_vocab = {}
    bigram = re.escape(' '.join(pair))
    p = re.compile(r'(?<!\S)' + bigram + r'(?!\S)')
    for word in vocab:
        w_out = p.sub(''.join(pair), word)
        new_vocab[w_out] = vocab[word]
    return new_vocab

# 获取最频繁的字对
def get_stats(vocab):
    pairs = defaultdict(int)
    for word, freq in vocab.items():
        symbols = word.split()
        for i in range(len(symbols) - 1):
            pairs[symbols[i], symbols[i + 1]] += freq
    return pairs

# BPE分词主函数
def bpe_tokenize(texts, num_merges):
    vocab = get_vocab(texts)
    for i in range(num_merges):
        pairs = get_stats(vocab)
        if not pairs:
            break
        best = max(pairs, key=pairs.get)
        vocab = merge_vocab(vocab, best)
    return vocab

# 使用BPE进行分词
bpe_vocab = bpe_tokenize(df['text'], num_merges=10)

# 输出结果
print("分词结果：")
for word in bpe_vocab:
    print(f"{word}: {bpe_vocab[word]}")


-----------------------------------------------------------------------------------------------------------------


import pandas as pd
import gensim
from gensim.models import Word2Vec
import numpy as np
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
# 指定字体（Windows可以用“SimHei”，Mac可以用“PingFang SC”）
plt.rcParams['font.sans-serif'] = ['SimHei']  # 使用黑体
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题
# 示例数据集
data = {
    'text': [
        "自然语言处理是人工智能的重要分支。",
        "数据增强可以提高模型的泛化能力。",
        "深度学习和机器学习是现代人工智能的核心。",
        "词向量能表示词汇的语义信息。",
    ]
}
df = pd.DataFrame(data)

# 分词处理函数
def preprocess_text(text):
    return text.split()

# 对数据集进行分词
df['tokenized'] = df['text'].apply(preprocess_text)

# 训练Word2Vec模型
model = Word2Vec(sentences=df['tokenized'], vector_size=100, window=5, min_count=1, workers=4)

# 提取词向量并转化为数组形式
words = list(model.wv.index_to_key)
word_vectors = np.array([model.wv[word] for word in words])

# PCA降维
pca = PCA(n_components=2)
word_vectors_2d = pca.fit_transform(word_vectors)

# 可视化词向量的二维表示
plt.figure(figsize=(10, 8))
for i, word in enumerate(words):
    plt.scatter(word_vectors_2d[i, 0], word_vectors_2d[i, 1])
    plt.annotate(word, (word_vectors_2d[i, 0], word_vectors_2d[i, 1]))
plt.title("2D PCA后的词嵌入可视化")
plt.xlabel("PCA 元素 1")
plt.ylabel("PCA 元素 2")
plt.show()


-----------------------------------------------------------------------------------------------------------------


import nltk
import random
import re
from nltk.corpus import wordnet as wn

# 下载所需资源
nltk.download('wordnet')
nltk.download('omw-1.4')

# 示例文本：莎士比亚《哈姆雷特》片段（1000字左右）
text_data = """To be, or not to be, that is the question:
Whether 'tis nobler in the mind to suffer
The slings and arrows of outrageous fortune,
Or to take arms against a sea of troubles
And by opposing end them. To die: to sleep;
No more; and by a sleep to say we end
The heart-ache and the thousand natural shocks
That flesh is heir to, 'tis a consummation
Devoutly to be wish'd. To die, to sleep;
To sleep: perchance to dream: ay, there's the rub;
For in that sleep of death what dreams may come
When we have shuffled off this mortal coil,
Must give us pause: there's the respect
That makes calamity of so long life;
..."""  # 省略其他内容，确保总文本长度1000字左右

# 1. 分词与数据预处理
def preprocess_text(text):
    words = re.findall(r'\b\w+\b', text.lower())  # 将文本分割成单词
    return words

tokenized_text = preprocess_text(text_data)
print("分词结果:", tokenized_text[:20])

# 2. 同义词替换
def get_synonyms(word):
    synonyms = []
    for syn in wn.synsets(word):
        for lemma in syn.lemmas():
            if lemma.name() != word:
                synonyms.append(lemma.name())
    return list(set(synonyms))

def synonym_replacement(words, n=5):
    new_words = words[:]
    for _ in range(n):
        idx = random.randint(0, len(words) - 1)
        word = words[idx]
        synonyms = get_synonyms(word)
        if synonyms:
            new_words[idx] = random.choice(synonyms)
    return new_words

augmented_text_synonym = synonym_replacement(tokenized_text, n=5)
print("同义词替换结果:", " ".join(augmented_text_synonym[:50]))

# 3. 随机插入
def random_insertion(words, n=5):
    new_words = words[:]
    for _ in range(n):
        word = words[random.randint(0, len(words) - 1)]
        synonyms = get_synonyms(word)
        if synonyms:
            insert_pos = random.randint(0, len(new_words))
            new_words.insert(insert_pos, random.choice(synonyms))
    return new_words

augmented_text_insertion = random_insertion(tokenized_text, n=5)
print("随机插入结果:", " ".join(augmented_text_insertion[:50]))

# 4. 随机删除
def random_deletion(words, p=0.2):
    if len(words) == 1:
        return words
    return [word for word in words if random.uniform(0, 1) > p]

augmented_text_deletion = random_deletion(tokenized_text, p=0.2)
print("随机删除结果:", " ".join(augmented_text_deletion[:50]))
