-----------------------------------------------------------------------------------------------------------------


import re

# 示例文本数据
text_data = [
    "Hello, world! This is an example text with <html> tags.",
    "Python is great!!! $$$",
    "Hello, world!    ",
    "Machine learning is fascinating! 😊",
    "Deep learning <b>models</b> are powerful."
]

def clean_text(text):
    # 去除HTML标签
    text = re.sub(r'<.*?>', '', text)
    # 去除特殊字符和多余空格
    text = re.sub(r'[^a-zA-Z0-9\s]', '', text)
    # 去除多余空格
    text = re.sub(r'\s+', ' ', text).strip()
    return text

# 对每个文本数据进行清洗
cleaned_data = [clean_text(text) for text in text_data]

# 显示清洗结果
for idx, text in enumerate(cleaned_data):
    print(f"Original: {text_data[idx]}")
    print(f"Cleaned: {text}\n")


# 去重操作
unique_data = list(set(cleaned_data))

# 显示去重结果
print("Data after removing duplicates:")
for text in unique_data:
    print(text)


# 按句号切分文本
def split_text(text, delimiter="."):
    return [sentence.strip() for sentence in text.split(delimiter) if sentence]

# 示例：对去重后的文本进行切分
split_data = [split_text(text) for text in unique_data]

# 显示切分结果
print("\nData after splitting:")
for idx, sentences in enumerate(split_data):
    print(f"Text {idx + 1}:")
    for sentence in sentences:
        print(f" - {sentence}")
    print()


# 定义一个简单的标注规则
def label_text(text):
    if "machine learning" in text.lower():
        return "Technology"
    elif "python" in text.lower():
        return "Programming"
    elif "world" in text.lower():
        return "General"
    else:
        return "Other"

# 为每条数据添加标签
labeled_data = [{"text": text, "label": label_text(text)} for text in unique_data]

# 显示标注结果
print("\nLabeled Data:")
for item in labeled_data:
    print(f"Text: {item['text']}, Label: {item['label']}")


-----------------------------------------------------------------------------------------------------------------


# 导入所需库
from transformers import BertTokenizer, GPT2Tokenizer

# 初始化分词器
bert_tokenizer = BertTokenizer.from_pretrained("bert-base-uncased")
gpt_tokenizer = GPT2Tokenizer.from_pretrained("gpt2")

# 定义示例文本
text = "Artificial Intelligence is transforming the world."

# 1. 使用 BERTTokenizer
print("1. 使用 BERTTokenizer")
bert_tokens = bert_tokenizer.tokenize(text)
print("BERT 分词结果:", bert_tokens)

# BERT编码
bert_encoded = bert_tokenizer(text, padding="max_length", max_length=12, truncation=True, return_tensors="pt")
print("BERT 编码后的ID:", bert_encoded['input_ids'])
print("BERT Attention Mask:", bert_encoded['attention_mask'])

# 2. 使用 GPT2Tokenizer
print("\n2. 使用 GPT2Tokenizer")
gpt_tokens = gpt_tokenizer.tokenize(text)
print("GPT2 分词结果:", gpt_tokens)

# GPT2编码
gpt_encoded = gpt_tokenizer(text, padding="max_length", max_length=12, truncation=True, return_tensors="pt")
print("GPT2 编码后的ID:", gpt_encoded['input_ids'])
print("GPT2 Attention Mask:", gpt_encoded['attention_mask'])


-----------------------------------------------------------------------------------------------------------------


# 导入所需库
from transformers import BertTokenizer, GPT2Tokenizer

# 初始化分词器
bert_tokenizer = BertTokenizer.from_pretrained("bert-base-uncased")
gpt_tokenizer = GPT2Tokenizer.from_pretrained("gpt2")

# 定义示例句子集：情感分析任务中的句子
sentences = [
    "I love this movie! It's absolutely amazing.",
    "The plot was terrible and the acting was worse.",
    "An enjoyable experience with outstanding visuals.",
    "I wouldn't recommend it to anyone.",
    "A brilliant and heartwarming story that everyone should watch."
]

# 对每个句子使用BERT和GPT-2分词器进行分词和编码
for i, sentence in enumerate(sentences):
    print(f"\n句子 {i+1}: {sentence}")

    # 使用BERT分词器
    bert_tokens = bert_tokenizer.tokenize(sentence)
    bert_encoded = bert_tokenizer(sentence, padding="max_length", max_length=12, truncation=True, return_tensors="pt")
    print("\nBERT分词结果:", bert_tokens)
    print("BERT编码后的ID:", bert_encoded['input_ids'])
    print("BERT Attention Mask:", bert_encoded['attention_mask'])

    # 使用GPT-2分词器
    gpt_tokens = gpt_tokenizer.tokenize(sentence)
    gpt_encoded = gpt_tokenizer(sentence, padding="max_length", max_length=12, truncation=True, return_tensors="pt")
    print("\nGPT-2分词结果:", gpt_tokens)
    print("GPT-2编码后的ID:", gpt_encoded['input_ids'])
    print("GPT-2 Attention Mask:", gpt_encoded['attention_mask'])


-----------------------------------------------------------------------------------------------------------------


pip install torch
# imports
import os
import torch
import torch.distributed as dist
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.utils.data import DataLoader, Dataset
import torch.optim as optim
import torch.nn as nn

# 设置主节点和端口，配置环境变量
os.environ['MASTER_ADDR'] = 'localhost'  # 主节点的IP地址
os.environ['MASTER_PORT'] = '12355'      # 通信端口


class RandomDataset(Dataset):
    def __init__(self, size, length):
        self.len = length
        self.data = torch.randn(length, size)

    def __getitem__(self, index):
        return self.data[index]

    def __len__(self):
        return self.len
class SimpleModel(nn.Module):
    def __init__(self, input_size, output_size):
        super(SimpleModel, self).__init__()
        self.fc = nn.Linear(input_size, output_size)

    def forward(self, x):
        return self.fc(x)
def setup(rank, world_size):
    dist.init_process_group("gloo", rank=rank, world_size=world_size)
    torch.manual_seed(0)

def cleanup():
    dist.destroy_process_group()


def train(rank, world_size, epochs=10, batch_size=32):
    setup(rank, world_size)

    # 设置数据和模型
    dataset = RandomDataset(10, 500)
    model = SimpleModel(10, 1).to(rank)
    model = DDP(model, device_ids=[rank])

    # Dataloader分布式设置
    train_sampler = torch.utils.data.distributed.DistributedSampler(
        dataset, num_replicas=world_size, rank=rank)
    train_loader = DataLoader(dataset, batch_size=batch_size, sampler=train_sampler)

    # 损失函数和优化器
    criterion = nn.MSELoss()
    optimizer = optim.SGD(model.parameters(), lr=0.01)

    for epoch in range(epochs):
        train_sampler.set_epoch(epoch)  # 每个epoch重设数据分配
        for i, data in enumerate(train_loader, 0):
            inputs = data.to(rank)
            labels = torch.randn(batch_size, 1).to(rank)

            # 正向和反向传播
            optimizer.zero_grad()
            outputs = model(inputs)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()

            if i % 10 == 0:
                print(f"Rank {rank}, Epoch [{epoch+1}/{epochs}], Step [{i+1}/{len(train_loader)}], Loss: {loss.item()}")

    cleanup()
import torch.multiprocessing as mp

def main():
    world_size = 2  # 设置GPU数量
    mp.spawn(train, args=(world_size,), nprocs=world_size, join=True)

if __name__ == "__main__":
    main()


-----------------------------------------------------------------------------------------------------------------


pip install torch tensorboard
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.tensorboard import SummaryWriter

class SimpleModel(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super(SimpleModel, self).__init__()
        self.fc1 = nn.Linear(input_size, hidden_size)
        self.relu = nn.ReLU()
        self.fc2 = nn.Linear(hidden_size, output_size)

    def forward(self, x):
        x = self.fc1(x)
        x = self.relu(x)
        x = self.fc2(x)
        return x


import os

# 定义TensorBoard保存路径
log_dir = "./runs/experiment"
if not os.path.exists(log_dir):
    os.makedirs(log_dir)

# TensorBoard监控器
writer = SummaryWriter(log_dir)


def train(model, criterion, optimizer, epochs, save_interval, checkpoint_dir='./checkpoints'):
    # 确保检查点目录存在
    if not os.path.exists(checkpoint_dir):
        os.makedirs(checkpoint_dir)

    for epoch in range(epochs):
        model.train()
        total_loss = 0

        # 生成模拟数据
        inputs = torch.randn(32, 10)  # 假设输入维度为10
        labels = torch.randn(32, 1)   # 假设输出维度为1

        # 前向传播
        optimizer.zero_grad()
        outputs = model(inputs)
        loss = criterion(outputs, labels)

        # 反向传播和优化
        loss.backward()
        optimizer.step()

        total_loss += loss.item()

        # 记录到TensorBoard
        writer.add_scalar('Loss/train', loss.item(), epoch)

        # 保存检查点
        if (epoch + 1) % save_interval == 0:
            checkpoint_path = f"{checkpoint_dir}/model_epoch_{epoch + 1}.pth"
            torch.save({
                'epoch': epoch + 1,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'loss': loss.item(),
            }, checkpoint_path)
            print(f"Saved checkpoint: {checkpoint_path}")

        print(f"Epoch [{epoch + 1}/{epochs}], Loss: {loss.item()}")

    print("Training complete.")
    writer.close()


# 初始化模型、损失函数和优化器
input_size = 10
hidden_size = 20
output_size = 1
model = SimpleModel(input_size, hidden_size, output_size)

criterion = nn.MSELoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)

# 设置训练参数
epochs = 50
save_interval = 10  # 每10个epoch保存一次检查点

# 训练模型
train(model, criterion, optimizer, epochs, save_interval)


tensorboard --logdir=./runs


-----------------------------------------------------------------------------------------------------------------


pip install torch
import torch
import torch.nn as nn
import torch.optim as optim

class SimpleModel(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super(SimpleModel, self).__init__()
        self.fc1 = nn.Linear(input_size, hidden_size)
        self.relu = nn.ReLU()
        self.fc2 = nn.Linear(hidden_size, output_size)

    def forward(self, x):
        x = self.fc1(x)
        x = self.relu(x)
        x = self.fc2(x)
        return x


import os

def train(model, criterion, optimizer, epochs, save_interval, checkpoint_dir='./checkpoints'):
    # 确保检查点目录存在
    if not os.path.exists(checkpoint_dir):
        os.makedirs(checkpoint_dir)

    for epoch in range(epochs):
        model.train()
        total_loss = 0

        # 生成随机数据
        inputs = torch.randn(32, 10)
        labels = torch.randn(32, 1)

        # 前向传播
        optimizer.zero_grad()
        outputs = model(inputs)
        loss = criterion(outputs, labels)

        # 反向传播和优化
        loss.backward()
        optimizer.step()

        total_loss += loss.item()

        # 每隔指定的epoch保存一次模型
        if (epoch + 1) % save_interval == 0:
            checkpoint_path = f"{checkpoint_dir}/model_epoch_{epoch + 1}.pth"
            torch.save({
                'epoch': epoch + 1,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'loss': loss.item(),
            }, checkpoint_path)
            print(f"Checkpoint saved at epoch {epoch + 1}, path: {checkpoint_path}")

        print(f"Epoch [{epoch + 1}/{epochs}], Loss: {loss.item()}")

    print("Training complete.")


def resume_training(checkpoint_path, model, optimizer):
    if os.path.isfile(checkpoint_path):
        print(f"Loading checkpoint from {checkpoint_path}")
        checkpoint = torch.load(checkpoint_path)
        model.load_state_dict(checkpoint['model_state_dict'])
        optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
        start_epoch = checkpoint['epoch']
        loss = checkpoint['loss']
        print(f"Checkpoint loaded, starting from epoch {start_epoch} with loss {loss}")
        return start_epoch, loss
    else:
        print(f"No checkpoint found at {checkpoint_path}")
        return None, None


# 初始化模型、损失函数和优化器
input_size = 10
hidden_size = 20
output_size = 1
model = SimpleModel(input_size, hidden_size, output_size)

criterion = nn.MSELoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)

# 设置训练参数
epochs = 20
save_interval = 5  # 每5个epoch保存一次

# 训练模型
train(model, criterion, optimizer, epochs, save_interval)


# 恢复检查点
checkpoint_path = './checkpoints/model_epoch_10.pth'
start_epoch, _ = resume_training(checkpoint_path, model, optimizer)

# 如果成功加载检查点，则从下一个epoch继续训练
if start_epoch:
    epochs = 20  # 重新定义需要继续的epoch
    for epoch in range(start_epoch, start_epoch + epochs):
        # 生成数据
        inputs = torch.randn(32, 10)
        labels = torch.randn(32, 1)
        
        # 前向和反向传播
        optimizer.zero_grad()
        outputs = model(inputs)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()

        # 显示每个epoch的损失值
        print(f"Resumed Epoch [{epoch + 1}/{start_epoch + epochs}], Loss: {loss.item()}")


-----------------------------------------------------------------------------------------------------------------


pip install torch transformers datasets tensorboard
from datasets import load_dataset
from transformers import BertTokenizer

# 加载IMDB数据集
dataset = load_dataset("imdb")

# 初始化BERT分词器
tokenizer = BertTokenizer.from_pretrained("bert-base-uncased")

def preprocess_data(examples):
    return tokenizer(examples['text'], padding="max_length", truncation=True, max_length=128)

# 应用数据预处理和Tokenization
train_data = dataset['train'].map(preprocess_data, batched=True)
test_data = dataset['test'].map(preprocess_data, batched=True)

# 保留重要字段
train_data.set_format(type="torch", columns=["input_ids", "attention_mask", "label"])
test_data.set_format(type="torch", columns=["input_ids", "attention_mask", "label"])


import torch
from transformers import BertForSequenceClassification

# 初始化模型
model = BertForSequenceClassification.from_pretrained("bert-base-uncased", num_labels=2)

# 使用多GPU进行分布式训练
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = torch.nn.DataParallel(model)  # 使用DataParallel多GPU
model.to(device)


-----------------------------------------------------------------------------------------------------------------


from torch.utils.tensorboard import SummaryWriter
from torch.utils.data import DataLoader
import torch.optim as optim

# 初始化TensorBoard
writer = SummaryWriter("runs/imdb_experiment")

# 数据加载器
train_loader = DataLoader(train_data, batch_size=8, shuffle=True)
test_loader = DataLoader(test_data, batch_size=8)

# 优化器
optimizer = optim.AdamW(model.parameters(), lr=2e-5)

# 损失函数
criterion = torch.nn.CrossEntropyLoss()

# 训练函数
def train_model(model, train_loader, optimizer, criterion, epochs, save_interval, checkpoint_path='./checkpoints'):
    model.train()
    for epoch in range(epochs):
        total_loss = 0
        for batch in train_loader:
            optimizer.zero_grad()
            inputs = {k: v.to(device) for k, v in batch.items() if k in ["input_ids", "attention_mask"]}
            labels = batch["label"].to(device)

            outputs = model(**inputs)
            loss = criterion(outputs.logits, labels)
            loss.backward()
            optimizer.step()

            total_loss += loss.item()

            # TensorBoard记录
            writer.add_scalar("Loss/train", loss.item(), epoch)

        # 保存检查点
        if (epoch + 1) % save_interval == 0:
            torch.save(model.state_dict(), f"{checkpoint_path}/model_epoch_{epoch + 1}.pth")
            print(f"Checkpoint saved at epoch {epoch + 1}")

        print(f"Epoch {epoch + 1}, Loss: {total_loss/len(train_loader)}")

train_model(model, train_loader, optimizer, criterion, epochs=5, save_interval=2)
writer.close()


-----------------------------------------------------------------------------------------------------------------


def resume_training(model, optimizer, checkpoint_path):
    checkpoint = torch.load(checkpoint_path)
    model.load_state_dict(checkpoint)
    optimizer.load_state_dict(checkpoint)
    print("Resumed from checkpoint")

# 恢复训练示例
resume_training(model, optimizer, './checkpoints/model_epoch_2.pth')


-----------------------------------------------------------------------------------------------------------------


from sklearn.metrics import accuracy_score

def evaluate_model(model, test_loader):
    model.eval()
    all_preds, all_labels = [], []
    with torch.no_grad():
        for batch in test_loader:
            inputs = {k: v.to(device) for k, v in batch.items() if k in ["input_ids", "attention_mask"]}
            labels = batch["label"].to(device)

            outputs = model(**inputs)
            predictions = torch.argmax(outputs.logits, dim=-1)

            all_preds.extend(predictions.cpu().numpy())
            all_labels.extend(labels.cpu().numpy())

    accuracy = accuracy_score(all_labels, all_preds)
    print(f"Test Accuracy: {accuracy * 100:.2f}%")

evaluate_model(model, test_loader)

