-----------------------------------------------------------------------------------------------------------------


import pandas as pd
import re
from sklearn.model_selection import train_test_split
import random

# 假设数据集data.csv中包含两列，'text'和'label'
data = pd.read_csv("data.csv")

# 数据清洗
def clean_text(text):
    # 去除HTML标签
    text = re.sub(r'<.*?>', '', text)
    # 去除非字母数字字符
    text = re.sub(r'[^a-zA-Z0-9\s]', '', text)
    # 去除多余空格
    text = re.sub(r'\s+', ' ', text).strip()
    return text

data['cleaned_text'] = data['text'].apply(clean_text)

# 去重
data = data.drop_duplicates(subset=['cleaned_text'])
print("数据清洗及去重后样本数量:", len(data))

# 样本展示
print(data[['text', 'cleaned_text']].head())


train_data, temp_data = train_test_split(data, test_size=0.3, random_state=42, stratify=data['label'])
val_data, test_data = train_test_split(temp_data, test_size=0.5, random_state=42, stratify=temp_data['label'])

print("训练集样本数:", len(train_data))
print("验证集样本数:", len(val_data))
print("测试集样本数:", len(test_data))


from nltk.corpus import wordnet

# 获取同义词
def get_synonyms(word):
    synonyms = set()
    for syn in wordnet.synsets(word):
        for lemma in syn.lemmas():
            synonyms.add(lemma.name())
    return list(synonyms)

# 同义词替换
def synonym_replacement(text, n=2):
    words = text.split()
    random_words = list(set([word for word in words if len(get_synonyms(word)) > 0]))
    random.shuffle(random_words)
    num_replaced = 0
    for random_word in random_words:
        synonyms = get_synonyms(random_word)
        if len(synonyms) >= 1:
            synonym = random.choice(synonyms)
            words = [synonym if word == random_word else word for word in words]
            num_replaced += 1
        if num_replaced >= n:
            break

    return ' '.join(words)

# 随机插入
def random_insertion(text, n=2):
    words = text.split()
    for _ in range(n):
        synonyms = []
        word_to_replace = random.choice(words)
        synonyms = get_synonyms(word_to_replace)
        if synonyms:
            synonym = random.choice(synonyms)
            insert_pos = random.randint(0, len(words)-1)
            words.insert(insert_pos, synonym)

    return ' '.join(words)

# 应用数据增强
train_data['augmented_text'] = train_data['cleaned_text'].apply(lambda x: synonym_replacement(x, n=2))
train_data['augmented_text'] = train_data['augmented_text'].apply(lambda x: random_insertion(x, n=2))

# 展示增强后的样本
print("数据增强后的样本:")
print(train_data[['cleaned_text', 'augmented_text']].head())


-----------------------------------------------------------------------------------------------------------------


# 导入所需库
import torch
from transformers import BertTokenizer, BertForSequenceClassification, AdamW
from torch.optim.lr_scheduler import StepLR

# 初始化 BERT 分词器和模型
tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
model = BertForSequenceClassification.from_pretrained('bert-base-uncased', num_labels=2)

# 示例输入文本
text = ["This is a positive example.", "This is a negative example."]
inputs = tokenizer(text, return_tensors="pt", padding=True, truncation=True, max_length=32)

# 冻结所有层的参数
for param in model.parameters():
    param.requires_grad = False

# 解冻最后两层以及分类层的参数
for layer in model.bert.encoder.layer[-2:]:
    for param in layer.parameters():
        param.requires_grad = True

for param in model.classifier.parameters():
    param.requires_grad = True

# 打印解冻的层级
print("解冻的层包括: ")
for name, param in model.named_parameters():
    if param.requires_grad:
        print(name)

# 设置优化器和学习率调度器
optimizer = AdamW(filter(lambda p: p.requires_grad, model.parameters()), lr=1e-5)
scheduler = StepLR(optimizer, step_size=1, gamma=0.1)

# 模拟训练步骤
model.train()
for epoch in range(3):
    optimizer.zero_grad()
    outputs = model(**inputs)
    loss = outputs.loss
    print(f"Epoch {epoch + 1}, Loss: {loss.item()}")

    # 反向传播和优化
    loss.backward()
    optimizer.step()
    scheduler.step()


-----------------------------------------------------------------------------------------------------------------


# 导入所需库
import torch
from transformers import BertTokenizer, BertForSequenceClassification, AdamW, get_linear_schedule_with_warmup
from sklearn.metrics import accuracy_score

# 初始化BERT分词器和模型
tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
model = BertForSequenceClassification.from_pretrained('bert-base-uncased', num_labels=2)

# 示例输入文本
texts = ["I love this product, it works perfectly!", "Worst experience ever, completely disappointed."]
labels = torch.tensor([1, 0])  # 1表示积极，0表示消极

# 转换输入
inputs = tokenizer(texts, return_tensors="pt", padding=True, truncation=True, max_length=32)

# 优化器和调度器的超参数设置
learning_rate = 2e-5
weight_decay = 0.01
epochs = 3

optimizer = AdamW(model.parameters(), lr=learning_rate, weight_decay=weight_decay)
total_steps = len(inputs['input_ids']) * epochs
scheduler = get_linear_schedule_with_warmup(optimizer, num_warmup_steps=0, num_training_steps=total_steps)

# 训练模型
model.train()
for epoch in range(epochs):
    optimizer.zero_grad()
    
    outputs = model(**inputs, labels=labels)
    loss = outputs.loss
    loss.backward()
    optimizer.step()
    scheduler.step()

    print(f"Epoch {epoch + 1}, Loss: {loss.item()}")

# 模型评估
model.eval()
with torch.no_grad():
    logits = model(**inputs).logits
    predictions = torch.argmax(logits, dim=-1)
    acc = accuracy_score(labels.numpy(), predictions.numpy())
    print(f"Final Accuracy: {acc:.2f}")


-----------------------------------------------------------------------------------------------------------------


# 导入所需库
import torch
from transformers import BertTokenizer, BertForSequenceClassification
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from torch.quantization import quantize_dynamic

# 加载分词器和微调后的模型
tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
model = BertForSequenceClassification.from_pretrained('bert-base-uncased', num_labels=2)

# 示例测试数据
texts = ["I love this product, it works perfectly!", "Worst experience ever, completely disappointed."]
labels = torch.tensor([1, 0])

# 数据预处理
inputs = tokenizer(texts, return_tensors="pt", padding=True, truncation=True, max_length=32)

# 评估函数
def evaluate_model(model, inputs, labels):
    model.eval()
    with torch.no_grad():
        logits = model(**inputs).logits
        predictions = torch.argmax(logits, dim=-1)
        acc = accuracy_score(labels.numpy(), predictions.numpy())
        precision = precision_score(labels.numpy(), predictions.numpy())
        recall = recall_score(labels.numpy(), predictions.numpy())
        f1 = f1_score(labels.numpy(), predictions.numpy())
        return acc, precision, recall, f1

# 进行评估并输出评估结果
acc, precision, recall, f1 = evaluate_model(model, inputs, labels)
print(f"Accuracy: {acc:.2f}, Precision: {precision:.2f}, Recall: {recall:.2f}, F1 Score: {f1:.2f}")

# 模型量化
quantized_model = quantize_dynamic(
    model, {torch.nn.Linear}, dtype=torch.qint8
)

# 量化模型的推理
def inference(model, inputs):
    model.eval()
    with torch.no_grad():
        logits = model(**inputs).logits
        predictions = torch.argmax(logits, dim=-1)
        return predictions

# 量化后模型推理并输出
quantized_predictions = inference(quantized_model, inputs)
print(f"Quantized Model Predictions: {quantized_predictions}")

# 蒸馏示例（假设有一个教师模型）
# 教师模型输出的logits用于训练学生模型
teacher_logits = model(**inputs).logits
student_model = BertForSequenceClassification.from_pretrained('bert-base-uncased', num_labels=2)

# 蒸馏损失函数：通过KL散度最小化学生模型与教师模型输出的分布差异
def distillation_loss(student_logits, teacher_logits, temperature=2.0):
    teacher_probs = torch.nn.functional.softmax(teacher_logits / temperature, dim=-1)
    student_probs = torch.nn.functional.log_softmax(student_logits / temperature, dim=-1)
    return torch.nn.functional.kl_div(student_probs, teacher_probs, reduction="batchmean") * (temperature ** 2)

# 蒸馏训练示例
optimizer = torch.optim.AdamW(student_model.parameters(), lr=2e-5)
student_model.train()
for epoch in range(2):
    optimizer.zero_grad()
    student_outputs = student_model(**inputs)
    loss = distillation_loss(student_outputs.logits, teacher_logits)
    loss.backward()
    optimizer.step()
    print(f"Epoch {epoch + 1}, Distillation Loss: {loss.item()}")


-----------------------------------------------------------------------------------------------------------------


# 导入所需库
import torch
from transformers import BertTokenizer, BertForSequenceClassification
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from torch.quantization import quantize_dynamic

# 加载数据和模型
tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
model = BertForSequenceClassification.from_pretrained('bert-base-uncased', num_labels=2)

# 1. 数据准备：清洗和分割数据集
texts = ["I love this product, it works perfectly!", "Worst experience ever, completely disappointed."]
labels = torch.tensor([1, 0])
inputs = tokenizer(texts, return_tensors="pt", padding=True, truncation=True, max_length=32)

# 2. 层级冻结：冻结前6层
for param in model.bert.encoder.layer[:6].parameters():
    param.requires_grad = False

# 3. 超参数调整：设置学习率和权重衰减
optimizer = torch.optim.AdamW(model.parameters(), lr=2e-5, weight_decay=0.01)

# 微调训练
model.train()
for epoch in range(2):
    optimizer.zero_grad()
    outputs = model(**inputs, labels=labels)
    loss = outputs.loss
    loss.backward()
    optimizer.step()
    print(f"Epoch {epoch + 1}, Loss: {loss.item()}")

# 4. 模型评估
def evaluate_model(model, inputs, labels):
    model.eval()
    with torch.no_grad():
        logits = model(**inputs).logits
        predictions = torch.argmax(logits, dim=-1)
        acc = accuracy_score(labels.numpy(), predictions.numpy())
        precision = precision_score(labels.numpy(), predictions.numpy())
        recall = recall_score(labels.numpy(), predictions.numpy())
        f1 = f1_score(labels.numpy(), predictions.numpy())
        return acc, precision, recall, f1

acc, precision, recall, f1 = evaluate_model(model, inputs, labels)
print(f"Accuracy: {acc:.2f}, Precision: {precision:.2f}, Recall: {recall:.2f}, F1 Score: {f1:.2f}")

# 5. 推理优化：量化模型
quantized_model = quantize_dynamic(model, {torch.nn.Linear}, dtype=torch.qint8)
quantized_predictions = torch.argmax(quantized_model(**inputs).logits, dim=-1)
print(f"Quantized Model Predictions: {quantized_predictions}")

# 6. 蒸馏（假设有一个教师模型）
teacher_logits = model(**inputs).logits
student_model = BertForSequenceClassification.from_pretrained('bert-base-uncased', num_labels=2)

def distillation_loss(student_logits, teacher_logits, temperature=2.0):
    teacher_probs = torch.nn.functional.softmax(teacher_logits / temperature, dim=-1)
    student_probs = torch.nn.functional.log_softmax(student_logits / temperature, dim=-1)
    return torch.nn.functional.kl_div(student_probs, teacher_probs, reduction="batchmean") * (temperature ** 2)

optimizer = torch.optim.AdamW(student_model.parameters(), lr=2e-5)
student_model.train()
for epoch in range(2):
    optimizer.zero_grad()
    student_outputs = student_model(**inputs)
    loss = distillation_loss(student_outputs.logits, teacher_logits)
    loss.backward()
    optimizer.step()
    print(f"Epoch {epoch + 1}, Distillation Loss: {loss.item()}")
