-----------------------------------------------------------------------------------------------------------------


import torch
import torch.nn as nn
import math

# 自注意力机制的实现
class SelfAttention(nn.Module):
    def __init__(self, embed_size, heads):
        super(SelfAttention, self).__init__()
        self.embed_size = embed_size
        self.heads = heads
        self.head_dim = embed_size // heads

        assert self.head_dim * heads == embed_size, "Embedding size需要是heads的整数倍"

        self.values = nn.Linear(self.head_dim, self.head_dim, bias=False)
        self.keys = nn.Linear(self.head_dim, self.head_dim, bias=False)
        self.queries = nn.Linear(self.head_dim, self.head_dim, bias=False)
        self.fc_out = nn.Linear(heads * self.head_dim, embed_size)

    def forward(self, values, keys, query, mask):
        N = query.shape[0]
        value_len, key_len, query_len = values.shape[1], keys.shape[1], query.shape[1]

        # 分头计算Q, K, V矩阵
        values = values.view(N, value_len, self.heads, self.head_dim)
        keys = keys.view(N, key_len, self.heads, self.head_dim)
        queries = query.view(N, query_len, self.heads, self.head_dim)

        values = self.values(values)
        keys = self.keys(keys)
        queries = self.queries(queries)

        energy = torch.einsum("nqhd,nkhd->nhqk", [queries, keys]) / (self.head_dim ** 0.5)
        
        if mask is not None:
            energy = energy.masked_fill(mask == 0, float("-1e20"))

        attention = torch.softmax(energy, dim=-1)

        out = torch.einsum("nhql,nlhd->nqhd", [attention, values]).reshape(
            N, query_len, self.heads * self.head_dim
        )
        
        return self.fc_out(out)

# 前馈网络的实现
class FeedForward(nn.Module):
    def __init__(self, embed_size, hidden_dim):
        super(FeedForward, self).__init__()
        self.fc1 = nn.Linear(embed_size, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, embed_size)
        self.relu = nn.ReLU()

    def forward(self, x):
        return self.fc2(self.relu(self.fc1(x)))

# Transformer层堆叠的实现
class TransformerBlock(nn.Module):
    def __init__(self, embed_size, heads, hidden_dim, dropout):
        super(TransformerBlock, self).__init__()
        self.attention = SelfAttention(embed_size, heads)
        self.norm1 = nn.LayerNorm(embed_size)
        self.norm2 = nn.LayerNorm(embed_size)
        self.feed_forward = FeedForward(embed_size, hidden_dim)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x, mask):
        attention = self.attention(x, x, x, mask)
        x = self.norm1(attention + x)
        forward = self.feed_forward(x)
        out = self.norm2(forward + x)
        return self.dropout(out)

# GPT-2模型的层堆叠部分
class GPT2LayerStack(nn.Module):
    def __init__(self, embed_size, heads, hidden_dim, num_layers, dropout):
        super(GPT2LayerStack, self).__init__()
        self.layers = nn.ModuleList(
            [TransformerBlock(embed_size, heads, hidden_dim, dropout) for _ in range(num_layers)]
        )
        self.dropout = nn.Dropout(dropout)

    def forward(self, x, mask):
        for layer in self.layers:
            x = layer(x, mask)
        return x

# 模拟输入
embed_size = 128
heads = 8
hidden_dim = 512
num_layers = 4
dropout = 0.1
seq_length = 10
batch_size = 2

# 初始化GPT-2层堆叠模型
gpt2_layer_stack = GPT2LayerStack(embed_size, heads, hidden_dim, num_layers, dropout)

# 随机生成输入数据和掩码
input_data = torch.rand(batch_size, seq_length, embed_size)
mask = None  # GPT-2通常不需要掩码，因为生成过程是单向的

# 前向传播
output = gpt2_layer_stack(input_data, mask)
print("层堆叠模型输出形状:", output.shape)
print("层堆叠模型输出:\n", output)


-----------------------------------------------------------------------------------------------------------------


import torch
import torch.nn as nn
import math

# 自注意力机制实现（包含单向掩码）
class GPT2SelfAttention(nn.Module):
    def __init__(self, embed_size, heads):
        super(GPT2SelfAttention, self).__init__()
        self.embed_size = embed_size
        self.heads = heads
        self.head_dim = embed_size // heads

        assert self.head_dim * heads == embed_size, "Embedding size需为heads的整数倍"

        # 定义线性层用于生成Q、K、V矩阵
        self.values = nn.Linear(self.head_dim, self.head_dim, bias=False)
        self.keys = nn.Linear(self.head_dim, self.head_dim, bias=False)
        self.queries = nn.Linear(self.head_dim, self.head_dim, bias=False)
        self.fc_out = nn.Linear(heads * self.head_dim, embed_size)

    def forward(self, values, keys, query, mask):
        N = query.shape[0]
        value_len, key_len, query_len = values.shape[1], keys.shape[1], query.shape[1]

        # 生成多头矩阵
        values = values.view(N, value_len, self.heads, self.head_dim)
        keys = keys.view(N, key_len, self.heads, self.head_dim)
        queries = query.view(N, query_len, self.heads, self.head_dim)

        values = self.values(values)
        keys = self.keys(keys)
        queries = self.queries(queries)

        # 计算缩放点积注意力
        energy = torch.einsum("nqhd,nkhd->nhqk", [queries, keys]) / (self.head_dim ** 0.5)

        # 使用单向掩码
        mask = torch.tril(torch.ones(query_len, key_len)).expand(N, self.heads, query_len, key_len)
        energy = energy.masked_fill(mask == 0, float("-1e20"))

        # 计算注意力权重并应用于值矩阵
        attention = torch.softmax(energy, dim=-1)
        out = torch.einsum("nhql,nlhd->nqhd", [attention, values]).reshape(
            N, query_len, self.heads * self.head_dim
        )

        return self.fc_out(out)

# 前馈网络的实现
class FeedForward(nn.Module):
    def __init__(self, embed_size, hidden_dim):
        super(FeedForward, self).__init__()
        self.fc1 = nn.Linear(embed_size, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, embed_size)
        self.relu = nn.ReLU()

    def forward(self, x):
        return self.fc2(self.relu(self.fc1(x)))

# Transformer块的实现，包含GPT-2中的注意力机制和前馈网络
class GPT2Block(nn.Module):
    def __init__(self, embed_size, heads, hidden_dim, dropout):
        super(GPT2Block, self).__init__()
        self.attention = GPT2SelfAttention(embed_size, heads)
        self.norm1 = nn.LayerNorm(embed_size)
        self.norm2 = nn.LayerNorm(embed_size)
        self.feed_forward = FeedForward(embed_size, hidden_dim)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x):
        attention = self.attention(x, x, x, mask=None)
        x = self.norm1(attention + x)
        forward = self.feed_forward(x)
        out = self.norm2(forward + x)
        return self.dropout(out)

# 参数设置
embed_size = 128
heads = 8
hidden_dim = 512
dropout = 0.1
seq_length = 10
batch_size = 2

# 初始化GPT-2块
gpt2_block = GPT2Block(embed_size, heads, hidden_dim, dropout)

# 随机生成输入数据
input_data = torch.rand(batch_size, seq_length, embed_size)

# 前向传播
output = gpt2_block(input_data)
print("GPT-2注意力机制输出形状:", output.shape)
print("GPT-2注意力机制输出:\n", output)


-----------------------------------------------------------------------------------------------------------------


import torch
import torch.nn as nn
import torch.nn.functional as F

# GPT-2模型的核心生成模块
class GPT2TextGenerator(nn.Module):
    def __init__(self, vocab_size, embed_size, num_layers, heads, hidden_dim, max_len, dropout=0.1):
        super(GPT2TextGenerator, self).__init__()
        self.embed_size = embed_size
        self.token_embedding = nn.Embedding(vocab_size, embed_size)
        self.position_embedding = nn.Embedding(max_len, embed_size)
        self.layers = nn.ModuleList(
            [GPT2Block(embed_size, heads, hidden_dim, dropout) for _ in range(num_layers)]
        )
        self.fc_out = nn.Linear(embed_size, vocab_size)
    
    def forward(self, x, mask=None):
        N, seq_length = x.shape
        positions = torch.arange(0, seq_length).expand(N, seq_length).to(x.device)
        x = self.token_embedding(x) + self.position_embedding(positions)

        for layer in self.layers:
            x = layer(x)

        logits = self.fc_out(x)
        return logits

    def generate(self, start_token, max_len, temperature=1.0):
        generated = start_token
        for _ in range(max_len - len(start_token)):
            x = torch.tensor(generated).unsqueeze(0).to(next(self.parameters()).device)
            logits = self.forward(x)
            logits = logits[:, -1, :] / temperature
            probs = F.softmax(logits, dim=-1)
            next_token = torch.argmax(probs, dim=-1).item()
            generated.append(next_token)
            if next_token == tokenizer.eos_token_id:  # 假设定义了终止符号
                break
        return generated

# 定义GPT-2的基础块
class GPT2Block(nn.Module):
    def __init__(self, embed_size, heads, hidden_dim, dropout):
        super(GPT2Block, self).__init__()
        self.attention = GPT2SelfAttention(embed_size, heads)
        self.norm1 = nn.LayerNorm(embed_size)
        self.norm2 = nn.LayerNorm(embed_size)
        self.feed_forward = FeedForward(embed_size, hidden_dim)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x):
        attention = self.attention(x, x, x, mask=None)
        x = self.norm1(attention + x)
        forward = self.feed_forward(x)
        out = self.norm2(forward + x)
        return self.dropout(out)

# 假设词汇量大小和其他参数
vocab_size = 50257
embed_size = 768
num_layers = 12
heads = 12
hidden_dim = 3072
max_len = 20
dropout = 0.1

# 初始化模型
gpt2_model = GPT2TextGenerator(vocab_size, embed_size, num_layers, heads, hidden_dim, max_len, dropout)

# 模拟输入提示词
start_token = [1, 345, 876]  # 假设起始词的索引序列

# 设置设备
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
gpt2_model = gpt2_model.to(device)
start_token = torch.tensor(start_token).to(device)

# 生成文本
generated_sequence = gpt2_model.generate(start_token.tolist(), max_len=max_len, temperature=1.0)
print("生成的文本序列:", generated_sequence)

# 模拟输出解码
# 假设定义了简单的词汇解码函数
def decode_sequence(sequence):
    return " ".join([f"<token_{idx}>" for idx in sequence])

decoded_text = decode_sequence(generated_sequence)
print("解码的生成文本:", decoded_text)


-----------------------------------------------------------------------------------------------------------------


import torch
import torch.nn as nn
import torch.nn.functional as F

# 定义GPT-2模型的基础生成模块
class GPT2TextGenerator(nn.Module):
    def __init__(self, vocab_size, embed_size, num_layers, heads, hidden_dim, max_len, dropout=0.1):
        super(GPT2TextGenerator, self).__init__()
        self.embed_size = embed_size
        self.token_embedding = nn.Embedding(vocab_size, embed_size)
        self.position_embedding = nn.Embedding(max_len, embed_size)
        self.layers = nn.ModuleList(
            [GPT2Block(embed_size, heads, hidden_dim, dropout) for _ in range(num_layers)]
        )
        self.fc_out = nn.Linear(embed_size, vocab_size)
    
    def forward(self, x):
        N, seq_length = x.shape
        positions = torch.arange(0, seq_length).expand(N, seq_length).to(x.device)
        x = self.token_embedding(x) + self.position_embedding(positions)

        for layer in self.layers:
            x = layer(x)

        logits = self.fc_out(x)
        return logits

    def greedy_search(self, start_token, max_len):
        generated = start_token
        for _ in range(max_len - len(start_token)):
            x = torch.tensor(generated).unsqueeze(0).to(next(self.parameters()).device)
            logits = self.forward(x)
            next_token = torch.argmax(logits[:, -1, :], dim=-1).item()
            generated.append(next_token)
            if next_token == tokenizer.eos_token_id:
                break
        return generated

    def beam_search(self, start_token, max_len, beam_width=3):
        sequences = [(start_token, 0)]
        for _ in range(max_len - len(start_token)):
            all_candidates = []
            for seq, score in sequences:
                x = torch.tensor(seq).unsqueeze(0).to(next(self.parameters()).device)
                logits = self.forward(x)
                logits = F.log_softmax(logits[:, -1, :], dim=-1)
                top_k_probs, top_k_indices = torch.topk(logits, beam_width, dim=-1)

                for i in range(beam_width):
                    candidate = seq + [top_k_indices[0, i].item()]
                    candidate_score = score + top_k_probs[0, i].item()
                    all_candidates.append((candidate, candidate_score))

            # 选择分数最高的beam_width个候选路径
            ordered = sorted(all_candidates, key=lambda tup: tup[1], reverse=True)
            sequences = ordered[:beam_width]

            # 检查是否已经生成完成标记
            if any(seq[-1] == tokenizer.eos_token_id for seq, _ in sequences):
                break

        # 选择得分最高的序列
        return max(sequences, key=lambda tup: tup[1])[0]

# GPT-2基础块定义
class GPT2Block(nn.Module):
    def __init__(self, embed_size, heads, hidden_dim, dropout):
        super(GPT2Block, self).__init__()
        self.attention = GPT2SelfAttention(embed_size, heads)
        self.norm1 = nn.LayerNorm(embed_size)
        self.norm2 = nn.LayerNorm(embed_size)
        self.feed_forward = FeedForward(embed_size, hidden_dim)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x):
        attention = self.attention(x, x, x, mask=None)
        x = self.norm1(attention + x)
        forward = self.feed_forward(x)
        out = self.norm2(forward + x)
        return self.dropout(out)

# 假设词汇量大小和其他参数
vocab_size = 50257
embed_size = 768
num_layers = 12
heads = 12
hidden_dim = 3072
max_len = 20
dropout = 0.1

# 初始化模型
gpt2_model = GPT2TextGenerator(vocab_size, embed_size, num_layers, heads, hidden_dim, max_len, dropout)

# 模拟输入提示词
start_token = [1, 345, 876]

# 设置设备
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
gpt2_model = gpt2_model.to(device)
start_token = torch.tensor(start_token).to(device)

# Greedy Search生成文本
greedy_generated_sequence = gpt2_model.greedy_search(start_token.tolist(), max_len=max_len)
print("Greedy Search生成的文本序列:", greedy_generated_sequence)

# Beam Search生成文本
beam_generated_sequence = gpt2_model.beam_search(start_token.tolist(), max_len=max_len, beam_width=3)
print("Beam Search生成的文本序列:", beam_generated_sequence)

# 模拟解码生成的文本
def decode_sequence(sequence):
    return " ".join([f"<token_{idx}>" for idx in sequence])

greedy_decoded_text = decode_sequence(greedy_generated_sequence)
beam_decoded_text = decode_sequence(beam_generated_sequence)

print("Greedy Search解码的生成文本:", greedy_decoded_text)
print("Beam Search解码的生成文本:", beam_decoded_text)


-----------------------------------------------------------------------------------------------------------------


import torch
import torch.nn as nn
import torch.nn.functional as F
from nltk.translate.bleu_score import sentence_bleu, SmoothingFunction
from rouge_score import rouge_scorer

# 模拟生成文本和参考文本
generated_text = ["The quick brown fox jumps over the lazy dog"]
reference_text = [["The quick brown fox jumps over the lazy dog"]]

# BLEU分数计算函数
def calculate_bleu(generated, reference):
    bleu_score = sentence_bleu(
        reference, generated, smoothing_function=SmoothingFunction().method1
    )
    return bleu_score

# ROUGE分数计算函数
def calculate_rouge(generated, reference):
    scorer = rouge_scorer.RougeScorer(['rouge1', 'rouge2', 'rougeL'], use_stemmer=True)
    scores = scorer.score(" ".join(reference[0]), " ".join(generated))
    return scores

# 模拟生成的模型输出（词汇列表形式）
generated_tokens = generated_text[0].split()
reference_tokens = reference_text[0][0].split()

# 计算BLEU分数
bleu_score = calculate_bleu(generated_tokens, [reference_tokens])
print("BLEU分数:", bleu_score)

# 计算ROUGE分数
rouge_scores = calculate_rouge(generated_tokens, [reference_tokens])
print("ROUGE分数:")
for key, score in rouge_scores.items():
    print(f"{key}: Precision={score.precision:.4f}, Recall={score.recall:.4f}, F1={score.fmeasure:.4f}")

# 定义GPT模型的困惑度计算函数
class GPTPerplexityCalculator(nn.Module):
    def __init__(self, model, vocab_size):
        super(GPTPerplexityCalculator, self).__init__()
        self.model = model
        self.vocab_size = vocab_size

    def forward(self, input_ids):
        outputs = self.model(input_ids)
        logits = outputs.view(-1, self.vocab_size)
        shift_labels = input_ids[:, 1:].contiguous().view(-1)
        loss = F.cross_entropy(logits[:-1], shift_labels)
        perplexity = torch.exp(loss)
        return perplexity

# 定义假设的GPT模型和输入数据
class SimpleGPTModel(nn.Module):
    def __init__(self, vocab_size, embed_size):
        super(SimpleGPTModel, self).__init__()
        self.embedding = nn.Embedding(vocab_size, embed_size)
        self.fc = nn.Linear(embed_size, vocab_size)

    def forward(self, input_ids):
        x = self.embedding(input_ids)
        x = self.fc(x)
        return x

# 初始化模型和数据
vocab_size = 1000
embed_size = 256
model = SimpleGPTModel(vocab_size, embed_size)
input_data = torch.randint(0, vocab_size, (1, 10))  # 模拟输入数据

# 计算困惑度
perplexity_calculator = GPTPerplexityCalculator(model, vocab_size)
perplexity = perplexity_calculator(input_data)
print("模型困惑度:", perplexity.item())


-----------------------------------------------------------------------------------------------------------------


import torch
import torch.nn as nn
import torch.nn.functional as F
from nltk.translate.bleu_score import sentence_bleu, SmoothingFunction
from rouge_score import rouge_scorer

# 参考文本和生成文本
reference_text = ["近年来，随着人工智能技术的不断发展，深度学习和自然语言处理逐渐成为热门的研究领域，特别是在文本生成方面，GPT（Generative Pre-trained Transformer）模型表现出色，能够生成具有连贯性和逻辑性的长文本。GPT模型基于大规模的文本数据进行预训练，利用自注意力机制在生成过程中关注上下文信息，从而在各种应用场景中取得了显著的成果。例如，在智能客服系统中，GPT模型可以根据用户的问题生成合理的回答，提高了客服效率。此外，GPT模型在内容创作领域也展现出巨大的潜力，能够帮助创作者提供灵感，甚至生成整篇文章。"]

generated_text = ["随着人工智能的发展，深度学习和自然语言处理成为研究的热点。GPT模型在文本生成任务中表现优异，能够生成连贯的长文本。GPT模型通过自注意力机制，利用上下文信息生成符合逻辑的文本，并在诸多领域取得显著成果。例如，智能客服系统利用GPT模型生成合理的回答，大大提高了服务效率。在内容创作中，GPT模型帮助创作者提供灵感，生成初步的内容。这种能力在未来将进一步推动人工智能在各个领域的应用。"]

# BLEU分数计算
def calculate_bleu(generated, reference):
    bleu_score = sentence_bleu(
        [reference[0].split()], generated[0].split(), 
        smoothing_function=SmoothingFunction().method1
    )
    return bleu_score

# ROUGE分数计算
def calculate_rouge(generated, reference):
    scorer = rouge_scorer.RougeScorer(['rouge1', 'rouge2', 'rougeL'], use_stemmer=True)
    scores = scorer.score(reference[0], generated[0])
    return scores

# 计算BLEU分数
bleu_score = calculate_bleu(generated_text, reference_text)
print("BLEU分数:", bleu_score)

# 计算ROUGE分数
rouge_scores = calculate_rouge(generated_text, reference_text)
print("ROUGE分数:")
for key, score in rouge_scores.items():
    print(f"{key}: Precision={score.precision:.4f}, Recall={score.recall:.4f}, F1={score.fmeasure:.4f}")

# 假设的GPT模型，用于困惑度计算
class SimpleGPTModel(nn.Module):
    def __init__(self, vocab_size, embed_size):
        super(SimpleGPTModel, self).__init__()
        self.embedding = nn.Embedding(vocab_size, embed_size)
        self.fc = nn.Linear(embed_size, vocab_size)

    def forward(self, input_ids):
        x = self.embedding(input_ids)
        x = self.fc(x)
        return x

# 困惑度计算类
class GPTPerplexityCalculator(nn.Module):
    def __init__(self, model, vocab_size):
        super(GPTPerplexityCalculator, self).__init__()
        self.model = model
        self.vocab_size = vocab_size

    def forward(self, input_ids):
        outputs = self.model(input_ids)
        logits = outputs.view(-1, self.vocab_size)
        shift_labels = input_ids[:, 1:].contiguous().view(-1)
        loss = F.cross_entropy(logits[:-1], shift_labels)
        perplexity = torch.exp(loss)
        return perplexity

# 定义模型和假设的输入
vocab_size = 3000  # 假设词汇量大小
embed_size = 512
model = SimpleGPTModel(vocab_size, embed_size)
input_data = torch.randint(0, vocab_size, (1, 100))  # 假设的输入数据

# 计算困惑度
perplexity_calculator = GPTPerplexityCalculator(model, vocab_size)
perplexity = perplexity_calculator(input_data)
print("模型困惑度:", perplexity.item())


-----------------------------------------------------------------------------------------------------------------


import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.optim.lr_scheduler import StepLR

# 定义GPT模型和困惑度计算类
class SimpleGPTModel(nn.Module):
    def __init__(self, vocab_size, embed_size):
        super(SimpleGPTModel, self).__init__()
        self.embedding = nn.Embedding(vocab_size, embed_size)
        self.fc = nn.Linear(embed_size, vocab_size)

    def forward(self, input_ids):
        x = self.embedding(input_ids)
        x = self.fc(x)
        return x

class GPTPerplexityCalculator(nn.Module):
    def __init__(self, model, vocab_size):
        super(GPTPerplexityCalculator, self).__init__()
        self.model = model
        self.vocab_size = vocab_size

    def forward(self, input_ids):
        outputs = self.model(input_ids)
        logits = outputs.view(-1, self.vocab_size)
        shift_labels = input_ids[:, 1:].contiguous().view(-1)
        loss = F.cross_entropy(logits[:-1], shift_labels)
        perplexity = torch.exp(loss)
        return perplexity

# 设置模型参数
vocab_size = 1000
embed_size = 256
model = SimpleGPTModel(vocab_size, embed_size)
input_data = torch.randint(0, vocab_size, (1, 20))  # 模拟输入数据
perplexity_calculator = GPTPerplexityCalculator(model, vocab_size)

# 微调和学习率调整设置
optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
scheduler = StepLR(optimizer, step_size=10, gamma=0.1)

# 模拟微调过程
num_epochs = 15
for epoch in range(num_epochs):
    optimizer.zero_grad()
    perplexity = perplexity_calculator(input_data)
    perplexity.backward()
    optimizer.step()
    scheduler.step()

    # 输出每个epoch的困惑度
    print(f"Epoch {epoch+1}, 困惑度: {perplexity.item():.4f}")

# 最终的困惑度计算
final_perplexity = perplexity_calculator(input_data)
print("最终困惑度:", final_perplexity.item())

