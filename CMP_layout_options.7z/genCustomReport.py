import sys
sys.stdout.reconfigure(encoding='utf-8')
sys.stderr.reconfigure(encoding='utf-8')
import json
import pandas as pd
from jinja2 import Environment, FileSystemLoader
from datetime import datetime
import os
from typing import Dict, List, Any
import argparse
import json

class ReportGenerator:
    def __init__(self, template_path: str, output_filepath: str = "reports.html"):
        """初始化报表生成器"""
        self.template = self._load_template(template_path)
        self.data = self._load_data()
        self.env = self._init_jinja_env()
        self.output_filepath = output_filepath


    def _load_template(self, template_path: str) -> Dict:
        """加载JSON模板"""
        try:
            if not os.path.exists(template_path):
                raise FileNotFoundError(f"模板文件不存在: {template_path}")
            with open(template_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            raise RuntimeError(f"加载模板失败: {str(e)}")

    def _load_data(self) -> pd.DataFrame:
        """加载CSV数据源"""
        metadata = self.template.get('metadata', {})
        data_path = metadata.get('filePath', '')

        if not data_path:
            raise ValueError("模板metadata中未配置filePath（数据文件路径）")

        # 处理相对路径/绝对路径
        abs_data_path = data_path if os.path.isabs(data_path) else os.path.join(os.getcwd(), data_path)
        if not os.path.exists(abs_data_path):
            raise FileNotFoundError(f"数据文件不存在: {abs_data_path}")

        try:
            return pd.read_csv(abs_data_path).head(20)
        except Exception as e:
            raise RuntimeError(f"读取CSV数据失败: {str(e)}")

    def _init_jinja_env(self) -> Environment:
        """初始化Jinja2环境（修复模板路径问题）"""
        preview_config = self.template.get('preview', {})
        jinja2_config = preview_config.get('jinja2Config', {})

        # 处理基础模板路径
        base_template_path = jinja2_config.get('baseTemplatePath', 'templates/base_report.html')

        # 检查基础模板是否存在
        if not os.path.isfile(base_template_path):
            # 尝试当前工作目录下的templates文件夹
            default_path = os.path.join(os.getcwd(), 'templates', 'base_report.html')
            if os.path.isfile(default_path):
                base_template_path = default_path
                print(f"警告：使用默认模板路径: {base_template_path}")
            else:
                # 创建默认模板目录结构
                template_dir = os.path.join(os.getcwd(), 'templates')
                charts_dir = os.path.join(template_dir, 'charts')
                os.makedirs(charts_dir, exist_ok=True)
                base_template_path = os.path.join(template_dir, 'base_report.html')
                print(f"警告：创建默认模板目录: {template_dir}")

        # 获取模板目录
        template_dir = os.path.dirname(os.path.abspath(base_template_path))
        print(f"模板目录: {template_dir}")

        return Environment(
            loader=FileSystemLoader(template_dir),
            autoescape=True,
            trim_blocks=True,
            lstrip_blocks=True
        )

    def _process_data(self, block: Dict) -> Dict[str, Any]:
        """根据图表类型动态处理数据"""
        block_type = block.get('type', 'unknown')
        config = block.get('config', {})

        # 图表处理器映射
        processors = {
            'quadrant': self._process_quadrant,
            'bar': self._process_bar,
            'line': self._process_line,
            'table': self._process_table,
            'pie': self._process_pie,
            'radar':self._process_radar,
            'gantt': self._process_gantt,  # 新增甘特图处理器
            'kline': self._process_kline,
            'wafermap': self._process_wafermap,

        }

        if block_type not in processors:
            print(f"警告：未支持的图表类型 '{block_type}'，使用默认表格展示")
            return self._process_table(block, config)  # 降级为表格

        return processors[block_type](block, config)

    def _apply_aggregation(self, data: pd.DataFrame, x_axis: str, y_axis: str, agg_type: str) -> pd.DataFrame:
        """应用数据聚合（mean/sum/count等）"""
        if not x_axis or not y_axis or x_axis not in data.columns or y_axis not in data.columns:
            return pd.DataFrame()

        # 支持的聚合函数
        agg_map = {
            'mean': 'mean', 'sum': 'sum', 'count': 'count',
            'max': 'max', 'min': 'min', 'median': 'median'
        }
        agg_func = agg_map.get(agg_type.lower(), 'mean')

        try:
            return data.groupby(x_axis)[y_axis].agg(agg_func).reset_index()
        except Exception as e:
            print(f"聚合数据失败（{agg_func}）：{str(e)}，返回原始数据")
            return data[[x_axis, y_axis]].dropna()

    def _apply_sampling(self, data: pd.DataFrame, config: Dict) -> pd.DataFrame:
        """应用数据采样"""
        if not config.get('sampling', False) or data.empty:
            return data

        sample_size = config.get('sampleSize', 1000)
        if len(data) <= sample_size:
            return data

        try:
            return data.sample(sample_size, random_state=42)
        except Exception as e:
            print(f"采样数据失败：{str(e)}，返回全部数据")
            return data

    def _get_default_dimension(self, exclude: List[str] = None, categorical: bool = False) -> str:
        """获取默认字段"""
        exclude = exclude or []
        data_cols = self.data.columns.tolist()

        # 过滤排除字段
        available_cols = [col for col in data_cols if col not in exclude]
        if not available_cols:
            return data_cols[0] if data_cols else 'unknown'

        # 优先选择分类字段或数值字段
        for col in available_cols:
            if categorical and self.data[col].dtype == 'object':
                return col
            if pd.api.types.is_numeric_dtype(self.data[col]):
                return col

        return available_cols[0]

    def _clean_nan_values(self, data: pd.DataFrame) -> pd.DataFrame:
        """新增：清理数据中的 NaN 值（关键步骤）"""
        # 1. 打印 NaN 统计，便于调试
        nan_count = data.isna().sum()
        if nan_count.sum() > 0:
            print("⚠️  数据中存在 NaN 值：")
            print(nan_count[nan_count > 0])  # 只显示有 NaN 的列

        # 2. 删除含 NaN 的行（或用 data.fillna(data.mean()) 填充，根据业务选）
        cleaned_data = data.dropna()
        print(f"✅ 数据清理完成：{len(cleaned_data)}行（原始{len(data)}行）")

        if len(cleaned_data) == 0:
            raise ValueError("❌ 清理后无有效数据，请检查原始数据")
        return cleaned_data

    def _process_wafermap(self, block: Dict, config: Dict) -> Dict[str, Any]:
        """
        wafermap数据处理：适配前端晶圆图组件需求
        """
        try:
            # 1. 从配置中获取晶圆图核心字段
            wafer_id_field = config.get('waferIdField', 'wafer_id')
            wafer_x_field = config.get('waferXField', 'x_coordinate')
            wafer_y_field = config.get('waferYField', 'y_coordinate')
            wafer_value_field = config.get('waferValueField', 'measurement_value')
            defect_type_field = config.get('defectTypeField', 'defect_type')

            print(f"Processing wafermap with fields: {wafer_id_field}, {wafer_x_field}, {wafer_y_field}, {wafer_value_field}, {defect_type_field}")

            # 2. 验证核心字段
            required_fields = [wafer_id_field, wafer_x_field, wafer_y_field, wafer_value_field, defect_type_field]
            missing_fields = [f for f in required_fields if f not in self.data.columns]

            if missing_fields:
                available_fields = self.data.columns.tolist()
                raise ValueError(f"晶圆图缺少必要字段：{missing_fields}。可用字段：{available_fields}")

            # 3. 数据预处理
            wafer_data = self.data[required_fields].copy()
            print(f"Raw data shape: {wafer_data.shape}")

            # 清理NaN值并转换类型
            for field in [wafer_x_field, wafer_y_field, wafer_value_field, defect_type_field]:
                wafer_data[field] = pd.to_numeric(wafer_data[field], errors='coerce')

            wafer_data = wafer_data.dropna(subset=required_fields)
            print(f"After cleaning NaN: {wafer_data.shape}")

            # 检查数据样本
            print("Sample data:")
            print(wafer_data.head(10).to_string())

            # 4. 获取所有晶圆ID
            wafer_ids = wafer_data[wafer_id_field].unique().tolist()

            # 5. 采样处理（限制数据量）
            max_points = 2000  # 限制显示点数
            if len(wafer_data) > max_points:
                wafer_data = wafer_data.sample(max_points, random_state=42)
                print(f"Sampled to {max_points} points")

            # 6. 计算坐标范围
            x_min = float(wafer_data[wafer_x_field].min())
            x_max = float(wafer_data[wafer_x_field].max())
            y_min = float(wafer_data[wafer_y_field].min())
            y_max = float(wafer_data[wafer_y_field].max())

            print(f"Coordinate range: x({x_min} to {x_max}), y({y_min} to {y_max})")

            # 7. 计算统计信息
            defect_stats = wafer_data[defect_type_field].value_counts().to_dict()
            total_dies = len(wafer_data)

            # 8. 准备前端数据
            display_data = []
            for _, row in wafer_data.iterrows():
                display_data.append({
                    'wafer_id': row[wafer_id_field],
                    'x': float(row[wafer_x_field]),
                    'y': float(row[wafer_y_field]),
                    'value': float(row[wafer_value_field]),
                    'defect_type': int(row[defect_type_field])
                })

            print(f"Prepared {len(display_data)} data points for frontend")

            # 9. 返回数据结构
            return {
                'type': 'wafermap',
                'wafer_id_field': wafer_id_field,
                'wafer_x_field': wafer_x_field,
                'wafer_y_field': wafer_y_field,
                'wafer_value_field': wafer_value_field,
                'defect_type_field': defect_type_field,
                'wafer_diameter': config.get('waferDiameter', 300),
                'show_grid': config.get('waferShowGrid', True),
                'show_axis': config.get('waferShowAxis', True),
                'color_scheme': config.get('waferColorScheme', 'standard'),
                'wafer_ids': wafer_ids,
                'data': display_data,
                'total_dies': total_dies,
                'defect_stats': defect_stats,
                'coord_range': {
                    'x_min': x_min,
                    'x_max': x_max,
                    'y_min': y_min,
                    'y_max': y_max
                },
                'config': config
            }

        except Exception as e:
            print(f"Error processing wafermap: {str(e)}")
            import traceback
            traceback.print_exc()
            raise

    def _process_kline(self, block: Dict, config: Dict) -> Dict[str, Any]:
        """
        K线图数据处理：适配前端K线图组件需求
        - 核心字段：时间、开盘价、收盘价、最高价、最低价
        - 数据清洗：处理日期格式、过滤无效数据、补充默认值
        """
        # 1. 从配置中获取K线图核心字段（与模板config对应）
        time_field = config.get('klineTimeField', 'date')  # 时间字段
        open_field = config.get('klineOpen', 'open')  # 开盘价字段
        close_field = config.get('klineClose', 'close')  # 收盘价字段
        high_field = config.get('klineHigh', 'high')  # 最高价字段
        low_field = config.get('klineLow', 'low')  # 最低价字段
        sampling = config.get('sampling', True)  # 是否启用采样
        sample_size = config.get('sampleSize', 1000)  # 采样大小

        # 2. 验证核心字段是否存在于数据中
        required_fields = [time_field, open_field, close_field, high_field, low_field]
        missing_fields = [f for f in required_fields if f not in self.data.columns]
        if missing_fields:
            raise ValueError(f"K线图缺少必要字段：{', '.join(missing_fields)}")

        # 3. 数据预处理：复制核心字段、清洗无效数据
        kline_data = self.data[required_fields].copy()

        # 4. 处理价格数据：确保为数值类型，填充缺失值
        price_fields = [open_field, close_field, high_field, low_field]
        for field in price_fields:
            # 转换为数值类型
            kline_data[field] = pd.to_numeric(kline_data[field], errors='coerce')
            # 填充缺失值（使用前一天的值）
            kline_data[field] = kline_data[field].fillna(method='ffill').fillna(method='bfill')

        # 5. 处理日期格式：转换为标准格式
        date_format = "%Y-%m-%d"  # 统一日期格式
        if pd.api.types.is_datetime64_any_dtype(kline_data[time_field]):
            kline_data[time_field] = kline_data[time_field].dt.strftime(date_format)
        else:
            try:
                kline_data[time_field] = pd.to_datetime(
                    kline_data[time_field], errors='coerce'
                ).dt.strftime(date_format)
            except Exception as e:
                print(f"警告：时间字段 {time_field} 转换失败，使用原始值：{str(e)}")

        # 6. 过滤无效数据（时间或价格为空）
        kline_data = kline_data.dropna(subset=required_fields)
        # 按时间排序
        kline_data['_sort_date'] = pd.to_datetime(kline_data[time_field])
        kline_data = kline_data.sort_values(by='_sort_date').drop(columns=['_sort_date'])
        # 采样处理
        if sampling and len(kline_data) > sample_size:
            kline_data = self._apply_sampling(kline_data, config)

        # 7. 处理时间范围
        time_range = config.get('klineTimeRange', 'auto')
        if time_range == 'auto' and not kline_data.empty:
            dates = pd.to_datetime(kline_data[time_field], errors='coerce')
            min_date = dates.min()
            max_date = dates.max()
            time_range = {
                'start': min_date.strftime(date_format),
                'end': max_date.strftime(date_format)
            }
        else:
            time_range = {
                'start': time_range.get('start', '2024-01-01'),
                'end': time_range.get('end', '2024-12-31')
            }

        # 8. 格式化输出数据（适配前端ECharts）
        formatted_data = []
        for _, row in kline_data.iterrows():
            formatted_data.append({
                'time': row[time_field],
                'value': [
                    float(row[open_field]),
                    float(row[close_field]),
                    float(row[low_field]),
                    float(row[high_field])
                ]
            })

        # 9. 返回适配前端的K线图数据结构
        return {
            'type': 'kline',
            'klineTimeField': time_field,
            'klineOpen': open_field,
            'klineClose': close_field,
            'klineHigh': high_field,
            'klineLow': low_field,
            'sampling': sampling,
            'sampleSize': sample_size,
            'time_range': time_range,
            'data': formatted_data,
            'data_count': len(formatted_data),
            'config': config
        }

    # 各图表数据处理器
    def _process_gantt(self, block: Dict, config: Dict) -> Dict[str, Any]:
        """
        甘特图数据处理：适配前端甘特图组件需求
        - 核心字段：任务名称、开始时间、结束时间、进度（可选）
        - 数据清洗：处理日期格式、过滤无效任务、补充默认值
        """
        # 1. 从配置中获取甘特图核心字段（与模板config对应）
        task_field = config.get('ganttTaskField', 'Task Name')  # 任务名称字段
        start_field = config.get('ganttStartField', 'Start Date')  # 开始时间字段
        end_field = config.get('ganttEndField', 'End Date')  # 结束时间字段
        progress_field = config.get('ganttProgressField', 'Progress')  # 进度字段
        show_progress = config.get('ganttShowProgress', True)  # 是否显示进度
        show_labels = config.get('ganttShowLabels', True)  # 是否显示任务标签
        bar_height = config.get('ganttBarHeight', 20)  # 甘特图条高度

        # 2. 验证核心字段是否存在于数据中
        required_fields = [task_field, start_field, end_field]
        missing_fields = [f for f in required_fields if f not in self.data.columns]
        if missing_fields:
            raise ValueError(f"甘特图缺少必要字段：{', '.join(missing_fields)}")

        # 3. 数据预处理：复制核心字段、清洗无效数据
        gantt_data = self.data[required_fields].copy()
        # 补充进度字段（若需要且不存在，默认0）
        if show_progress and progress_field not in gantt_data.columns:
            gantt_data[progress_field] = 0.0
        elif show_progress:
            gantt_data[progress_field] = gantt_data[progress_field].fillna(0.0)
            # 进度值限制在 0-1 之间
            gantt_data[progress_field] = gantt_data[progress_field].clip(0.0, 1.0)

        # 4. 处理日期格式：转换为字符串（避免前端解析问题）
        date_format = "%Y-%m-%d"  # 统一日期格式
        for date_field in [start_field, end_field]:
            # 若字段是datetime类型，直接格式化；否则尝试转换
            if pd.api.types.is_datetime64_any_dtype(gantt_data[date_field]):
                gantt_data[date_field] = gantt_data[date_field].dt.strftime(date_format)
            else:
                try:
                    gantt_data[date_field] = pd.to_datetime(
                        gantt_data[date_field], errors='coerce'
                    ).dt.strftime(date_format)
                except Exception as e:
                    print(f"警告：日期字段 {date_field} 转换失败，使用原始值：{str(e)}")

        # 5. 过滤无效任务（任务名空、开始/结束日期空）
        gantt_data = gantt_data.dropna(subset=[task_field, start_field, end_field])
        # 去重（避免重复任务）
        gantt_data = gantt_data.drop_duplicates(subset=[task_field])
        # 采样（限制任务数量，避免甘特图过长）
        gantt_data = self._apply_sampling(gantt_data, config)

        # 6. 处理时间范围（自动计算或使用配置）
        time_range = config.get('ganttTimeRange', 'auto')
        if time_range == 'auto' and not gantt_data.empty:
            # 自动计算时间范围（前后各留1天余量）
            start_dates = pd.to_datetime(gantt_data[start_field], errors='coerce')
            end_dates = pd.to_datetime(gantt_data[end_field], errors='coerce')
            min_date = start_dates.min() - pd.Timedelta(days=1)
            max_date = end_dates.max() + pd.Timedelta(days=1)
            time_range = {
                'start': min_date.strftime(date_format),
                'end': max_date.strftime(date_format)
            }
        else:
            # 若配置了固定时间范围，直接使用
            time_range = {
                'start': time_range.get('start', '2024-01-01'),
                'end': time_range.get('end', '2024-12-31')
            }

        # 7. 生成任务颜色（按进度或固定色）
        color_mode = config.get('ganttColorMode', 'progress')  # 颜色模式：progress/fixed
        gantt_data['task_color'] = gantt_data.apply(
            lambda row: self._get_gantt_color(row, color_mode, progress_field),
            axis=1
        )

        # 8. 返回适配前端的甘特图数据结构
        return {
            'type': 'gantt',
            'task_field': task_field,
            'start_field': start_field,
            'end_field': end_field,
            'progress_field': progress_field if show_progress else None,
            'show_progress': show_progress,
            'show_labels': show_labels,
            'bar_height': bar_height,
            'time_range': time_range,
            'data': gantt_data.to_dict('records'),  # 任务列表
            'total_tasks': len(gantt_data),  # 任务总数
            'total_rows': len(gantt_data),  # 任务总数
            'config': config
        }

    def _get_gantt_color(self, row: pd.Series, color_mode: str, progress_field: str) -> str:
        """
        生成甘特图任务条颜色
        - color_mode='progress'：按进度渐变（0%→红色，100%→绿色）
        - color_mode='fixed'：固定颜色（蓝色）
        """
        if color_mode == 'progress' and progress_field in row:
            progress = row[progress_field]
            # HSL颜色：进度0→红色（0°），进度100%→绿色（120°）
            hue = int(progress * 120)  # 0-120°
            return f"hsl({hue}, 70%, 50%)"
        # 固定颜色（默认蓝色）
        return "hsl(210, 70%, 50%)"
    def _process_quadrant(self, block: Dict, config: Dict) -> Dict:
        # 从配置中获取两个X维度和一个Y维度
        dim_fields = config.get('dimFields', [])
        value_fields = config.get('valueFields', [])

        # 验证配置是否包含足够的字段
        if len(dim_fields) < 2:
            raise ValueError("散点图需要至少2个dimFields（X轴1和X轴2）")
        if not value_fields:
            raise ValueError("散点图需要至少1个valueFields（气泡大小）")

        x_dim1, x_dim2 = dim_fields[0], dim_fields[1]  # AGE和B
        y_dim = value_fields[0]  # MEDV

        # 数据处理：保留三个字段的原始值（不聚合，因为需要每个点的具体值）
        processed_data = self.data[[x_dim1, x_dim2, y_dim]].copy()
        processed_data = self._clean_nan_values(processed_data)  # 清理NaN
        processed_data = self._apply_sampling(processed_data, config)

        return {
            'type': 'quadrant',
            'data': processed_data.to_dict('records'),  # 格式：[{AGE: x, B: y, MEDV: z}, ...]
            'x_dim1': x_dim1,
            'x_dim2': x_dim2,
            'y_dim': y_dim,
            'config': config
        }

    def _process_bar(self, block: Dict, config: Dict) -> Dict:
        """柱状图数据处理"""
        dim_fields = config.get('dimFields', [])
        value_fields = config.get('valueFields', [])

        x_dim = dim_fields[0] if (dim_fields and len(dim_fields) > 0) else self._get_default_dimension()
        y_dims = value_fields if value_fields else [self._get_default_dimension(exclude=[x_dim])]

        series_data = []
        for y_dim in y_dims:
            agg_type = config.get('aggregations', {}).get(y_dim, 'mean')
            data = self._apply_aggregation(self.data, x_dim, y_dim, agg_type)
            data = self._apply_sampling(data, config)

            series_data.append({
                'name': y_dim,
                'data': data.to_dict('records')
            })

        return {
            'type': 'bar',
            'x_dim': x_dim,
            'series': series_data,
            'config': config
        }

    def _process_line(self, block: Dict, config: Dict) -> Dict:
        """折线图数据处理"""
        line_data = self._process_bar(block, config)
        line_data['type'] = 'line'
        return line_data

    def _process_table(self, block: Dict, config: Dict) -> Dict:
        """表格数据处理"""
        # 确定表格列
        columns = []
        if config.get('xAxis'):
            columns.append(config['xAxis'])
        columns.extend(config.get('yAxis', []))

        # 无配置时默认取前5列
        if not columns:
            columns = self.data.columns.tolist()

        # 过滤存在的列
        valid_columns = [col for col in columns if col in self.data.columns]
        if not valid_columns:
            valid_columns = self.data.columns.tolist()

        # 数据处理
        processed_data = self.data[valid_columns].copy()
        processed_data = self._apply_sampling(processed_data, config)

        # 处理数值格式
        for col in valid_columns:
            if pd.api.types.is_numeric_dtype(processed_data[col]):
                processed_data[col] = processed_data[col].round(2)

        return {
            'type': 'table',
            'columns': valid_columns,
            'data': processed_data.to_dict('records'),
            'total_rows': len(processed_data)
        }

    def _process_pie(self, block: Dict, config: Dict) -> Dict:
        """饼图数据处理"""
        dim_fields      = config.get('dimFields', [])
        value_fields    = config.get('valueFields', [])

        categorydim = dim_fields[0] if (dim_fields and len(dim_fields) > 0) else self._get_default_dimension(
            categorical=True)
        value_dim = value_fields[0] if (value_fields and len(value_fields) > 0) else self._get_default_dimension(
            exclude=[categorydim])
        agg_type = config.get('aggregations', {}).get(value_dim, 'sum')

        # 数据处理
        processed_data = self._apply_aggregation(self.data, categorydim, value_dim, agg_type)
        if not processed_data.empty and value_dim in processed_data.columns:
            processed_data = processed_data[processed_data[value_dim] > 0]  # 过滤无效值

        return {
            'type': 'pie',
            'categorydim': categorydim,
            'valuedim': value_dim,
            'data': processed_data.to_dict('records'),
            'total_items': len(processed_data)
        }

    def _process_radar(self, block: Dict, config: Dict) -> Dict:
        """
        雷达图数据处理：适配「维度轴+多系列」需求
        - 维度（雷达轴标签）：dimFields配置的字段唯一值（如RAD的1、2、3）
        - 数据系列：valueFields配置的所有数值字段（支持多个，如[AGE, B]）
        """
        # 1. 从配置提取核心参数（支持valueFields列表）
        dim_fields = config.get('dimFields', [])  # 维度字段列表（取第一个作为雷达轴）
        value_fields = config.get('valueFields', [])  # 指标字段列表（支持多个）
        agg_config = config.get('aggregations', {})  # 聚合方式配置（每个指标可单独设置）
        sampling = config.get('sampling', True)
        sample_size = config.get('sampleSize', 1000)

        # 2. 验证核心配置（确保维度和指标有效）
        if not dim_fields:
            raise ValueError("❌ 配置中未指定dimFields（雷达图维度字段）")
        dim_field = dim_fields[0]  # 取第一个维度字段作为雷达轴

        if not value_fields:
            raise ValueError("❌ 配置中未指定valueFields（雷达图数据系列）")
        # 过滤无效的指标字段（必须是数值类型）
        valid_value_fields = []
        for vf in value_fields:
            if vf not in self.data.columns:
                print(f"⚠️  指标字段「{vf}」不存在，已跳过")
                continue
            if not pd.api.types.is_numeric_dtype(self.data[vf]):
                print(f"⚠️  指标字段「{vf}」不是数值类型，已跳过")
                continue
            valid_value_fields.append(vf)
        if not valid_value_fields:
            raise ValueError("❌ 无有效指标字段（valueFields需包含至少1个数值字段）")
        value_fields = valid_value_fields  # 使用过滤后的有效指标

        # 3. 数据合法性校验
        all_columns = self.data.columns.tolist()
        if dim_field not in all_columns:
            raise ValueError(f"❌ 维度字段「{dim_field}」不存在于数据中（数据列：{all_columns}）")

        # 4. 关键信息打印（确认配置与数据匹配）
        print("=" * 60)
        print("【雷达图配置与数据检查】")
        print(f"核心配置：")
        print(f"- 雷达轴维度字段：{dim_field}（唯一值作为轴标签）")
        print(f"- 数据系列字段：{value_fields}（共{len(value_fields)}个系列）")
        print(f"- 聚合方式：{ {vf: agg_config.get(vf, 'mean') for vf in value_fields} }")
        print(f"\n数据基础信息：")
        print(f"- {dim_field}字段唯一值数量：{self.data[dim_field].nunique()}")
        print(f"- {dim_field}字段示例值：{self.data[dim_field].unique()[:5]}")
        for vf in value_fields:
            print(f"- {vf}字段数值范围：{self.data[vf].min():.2f} ~ {self.data[vf].max():.2f}")
        print("=" * 60)

        # 5. 核心处理：按维度字段分组，聚合所有指标字段
        try:
            # 构建聚合字典：{指标字段: 聚合函数}
            agg_dict = {}
            for vf in value_fields:
                agg_type = agg_config.get(vf, 'mean').lower()  # 默认为均值
                agg_dict[vf] = self._get_aggregator(agg_type)

            # 按维度字段分组，计算所有指标的聚合值
            aggregated_data = self.data.groupby(dim_field, as_index=False).agg(agg_dict)
            # 重命名维度字段列（便于后续处理）
            aggregated_data = aggregated_data.rename(columns={dim_field: "radar_dimension"})

            # 处理维度异常值
            aggregated_data["radar_dimension"] = aggregated_data["radar_dimension"].fillna("未知维度")
            # 数值型维度转为字符串（避免前端识别为数值）
            if pd.api.types.is_numeric_dtype(aggregated_data["radar_dimension"]):
                aggregated_data["radar_dimension"] = aggregated_data["radar_dimension"].astype(str)

            # 采样（控制维度数量，避免雷达图拥挤）
            if sampling and len(aggregated_data) > sample_size:
                aggregated_data = aggregated_data.head(sample_size).reset_index(drop=True)
                print(f"⚠️  维度数量（{len(aggregated_data)}）超过采样数（{sample_size}），保留前{sample_size}个")

            # 数据清洗与格式化（保留2位小数）
            for vf in value_fields:
                aggregated_data[vf] = aggregated_data[vf].fillna(0).round(2)

            print(f"✅ 数据处理完成：")
            print(f"- 最终维度数（轴数量）：{len(aggregated_data)}")
            print(f"- 处理后数据预览：")
            print(aggregated_data.head(10).to_string(index=False))
            print("=" * 60)

        except Exception as e:
            raise RuntimeError(f"❌ 按{dim_field}分组聚合失败：{str(e)}") from e

        # 6. 整理多系列数据（适配前端渲染）
        series_data = []
        for vf in value_fields:
            series_data.append({
                "name": vf,  # 系列名称（指标字段名）
                "data": aggregated_data[vf].tolist(),  # 该系列的所有维度值
                "agg_type": agg_config.get(vf, 'mean').lower()  # 该系列的聚合方式
            })

        # 7. 返回适配前端的结构
        ret =  {
            'type': 'radar',
            # 为每个字段添加默认值，确保模板引用时不会 Undefined
            'radardimensions': aggregated_data["radar_dimension"].tolist() if not aggregated_data.empty else [],
            'series': series_data if series_data else [],  # 系列数据默认空列表
            "series_key": value_fields,
            'data_raw': aggregated_data.to_dict('records') if not aggregated_data.empty else [],
            'agg_info': {vf: agg_config.get(vf, 'mean') for vf in value_fields} if value_fields else {},
            'total_dimensions': len(aggregated_data) if not aggregated_data.empty else 0,
            'total_series': len(value_fields) if value_fields else 0,
            'config': config or {}  # 避免 config 为 None
        }
        print( 'ret:', ret )
        return  ret

    def _get_aggregator(self, agg_type: str):
        """根据聚合类型返回pandas支持的聚合函数"""
        agg_map = {
            'mean': 'mean', 'sum': 'sum', 'count': 'count',
            'max': 'max', 'min': 'min', 'median': 'median'
        }
        return agg_map.get(agg_type.lower(), 'mean')
    # 报表生成主逻辑
    def generate(self) -> str:
        """生成静态HTML报表"""
        try:
            # 处理所有区块数据
            processed_structure = []
            for row in self.template.get('structure', []):
                processed_row = []
                for block in row:
                    try:
                        processed_block = {**block, **self._process_data(block)}
                        processed_row.append(processed_block)
                    except Exception as e:
                        print(f"处理区块 {block.get('id', '未知ID')} 失败：{str(e)}")
                        processed_row.append({
                            **block,
                            'error': f"区块加载失败：{str(e)}",
                            'type': 'error'
                        })
                processed_structure.append(processed_row)

            # 生成输出文件名
            # if not output_filename:
            #     metadata = self.template.get('metadata', {})
            #     template_name = metadata.get('templateName', '数据报表').replace(' ', '_')
            #     timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            #     output_filename = f"{template_name}_{timestamp}.html"
            #
            # output_path = os.path.join(self.output_dir, output_filename)
            output_path = self.output_filepath
            # 加载基础模板
            preview_config = self.template.get('preview', {})
            jinja2_config = preview_config.get('jinja2Config', {})
            base_template = os.path.basename(jinja2_config.get('baseTemplatePath', 'base_report.html'))

            try:
                template = self.env.get_template(base_template)
            except Exception as e:
                print(f"加载模板 '{base_template}' 失败，使用默认模板：{str(e)}")
                template = self.env.get_template('base_report.html')

            # 准备模板渲染数据
            render_context = {
                'report_title': self.template.get('metadata', {}).get('templateName', '数据报表'),
                'generated_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'current_year': datetime.now().year,
                'structure': processed_structure,
                'preview': preview_config,
                'total_blocks': sum(len(row) for row in processed_structure),
                'metadata': self.template.get('metadata', {})
            }

            # 渲染并保存HTML
            html_content = template.render(render_context)
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(html_content)

            print(f"报表生成成功！路径：{output_path}")
            return output_path

        except Exception as e:
            import traceback
            traceback.print_exc()
            raise RuntimeError(f"生成报表失败：{str(e)}")

def set_args():
    parser = argparse.ArgumentParser(description="生成报表 HTML 文件")
    # 1. 模板 JSON 文件路径（Go 端传入的 tempFilePath）
    parser.add_argument( "--template",    type=str, required=True,default='template.json', help="模板 JSON 文件的完整路径（必填，如：./temp/template_123.json）")
    parser.add_argument("--output_filepath",type=str,required=True,default='./reports/final.html', help="生成的 HTML 文件完整路径（必填，如：./static/reports/user123/report_2024.html）" )
    args = parser.parse_args()
    return args

if __name__ == '__main__':
    args = set_args()
    try:
        generator = ReportGenerator(template_path= args.template,output_filepath= args.output_filepath )
        generator.generate()
    except Exception as e:
        print(f"程序执行失败：{str(e)}")
        exit(1)