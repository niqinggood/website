package main

import (
    "net/url"
	"fmt"
	"net/http"
    "log"
	"os/exec"
	"path/filepath"
	"time"
    "os"
	"gorm.io/gorm" // GORM 核心库
    "github.com/gin-gonic/gin"
)

// ReportTemplate 报表模板模型
type PReportTemplate struct {
	ID           uint           `gorm:"primaryKey" json:"id"`
	Username     string         `gorm:"size:50;not null;index:idx_user_report" json:"username"`
	ReportName   string         `gorm:"size:100;not null;index:idx_user_report" json:"report_name"`
	TemplateJSON string         `gorm:"type:text;not null" json:"template_json"`
	Description  string         `gorm:"size:500" json:"description"`
	FilePath     string         `gorm:"size:255" json:"file_path"`
	CreatedAt    time.Time      `json:"created_at"`
	UpdatedAt    time.Time      `json:"updated_at"`
	DeletedAt    gorm.DeletedAt `gorm:"index" json:"-"`
}

// SaveTemplateRequest 保存模板请求结构体
type SaveTemplateRequest struct {
	ReportName   string `json:"report_name" binding:"required"`
	TemplateJSON string `json:"template_json" binding:"required"`
	Description  string `json:"description"`
	FilePath     string `json:"file_path"`
}

// HTMLGenerateResponse HTML生成响应结构体
type HTMLGenerateResponse struct {
	TemplateID      uint   `json:"template_id"`
	ReportName      string `json:"report_name"`
	HTMLDownloadURL string `json:"html_download_url"`
	GeneratedAt     string `json:"generated_at"`
}

// 辅助函数：获取当前时间字符串
func getCurrentTimeStr() string {
	return time.Now().Format("2006-01-02 15:04:05")
}

// 辅助函数：获取当前时间戳
func getCurrentTimestamp() string {
	return time.Now().Format("20060102150405")
}

// 辅助函数：保存字符串到文件
func saveStringToFile(filePath, content string) error {
	// 修复错误：将os.Path.Dir改为filepath.Dir
	if err := os.MkdirAll(filepath.Dir(filePath), 0755); err != nil {
		return err
	}
	return os.WriteFile(filePath, []byte(content), 0644)
}




// 保存报表模板（新增/更新）
func saveReportTemplate(c *gin.Context) {
    log.Println("=== [saveReportTemplate] 进入保存模板接口 ===")
	// 获取当前用户
	user, ok := getCurrentUser(c)
	if !ok {
		c.JSON(http.StatusInternalServerError, gin.H{
			"status":  "error",
			"message": "获取当前用户失败",
		})
		return
	}
    username := user.Username
    log.Printf("[saveReportTemplate] 当前用户：%s", username) // 日志：记录当前用户
	// 绑定请求参数
	var req SaveTemplateRequest
	if err := c.ShouldBindJSON(&req); err != nil {
	    log.Printf("[saveReportTemplate] 参数解析失败，用户：%s，错误：%v，请求体：%s", username, err, c.Request.Body)
		c.JSON(http.StatusBadRequest, gin.H{
			"status":  "error",
			"message": fmt.Sprintf("参数解析失败: %v", err),
		})
		return
	}
    log.Printf("[saveReportTemplate] 参数解析成功，用户：%s，报表名称：%s", username, req.ReportName)
	// 查询是否已存在
	var template PReportTemplate
	result := db.Where("username = ? AND report_name = ?", username, req.ReportName).First(&template)

	if result.Error == nil {
	    log.Printf("[saveReportTemplate] 模板已存在，开始更新：模板ID=%d", template.ID)
		// 更新现有模板
		template.TemplateJSON = req.TemplateJSON
		template.Description = req.Description
		template.FilePath = req.FilePath
		template.UpdatedAt = time.Now()

		if err := db.Save(&template).Error; err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{
				"status":  "error",
				"message": "更新模板失败",
			})
			return
		}

		c.JSON(http.StatusOK, gin.H{
			"status":  "success",
			"message": "模板更新成功",
			"data":    template,
		})
	} else if result.Error == gorm.ErrRecordNotFound {

	    log.Printf("[saveReportTemplate] 模板不存在，开始创建：用户=%s，报表名称=%s", username, req.ReportName)
		// 创建新模板
		newTemplate := PReportTemplate{
			Username:     username,
			ReportName:   req.ReportName,
			TemplateJSON: req.TemplateJSON,
			Description:  req.Description,
			FilePath:     req.FilePath,
			CreatedAt:    time.Now(),
			UpdatedAt:    time.Now(),
		}

		if err := db.Create(&newTemplate).Error; err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{
				"status":  "error",
				"message": "创建模板失败",
			})
			return
		}

		c.JSON(http.StatusOK, gin.H{
			"status":  "success",
			"message": "模板创建成功",
			"data":    newTemplate,
		})
	} else {
		// 其他错误
		c.JSON(http.StatusInternalServerError, gin.H{
			"status":  "error",
			"message": "查询模板失败",
		})
		return
	}
}

// 获取模板列表
func getReportTemplateList(c *gin.Context) {
	user, ok := getCurrentUser(c)
	if !ok {
		c.JSON(http.StatusInternalServerError, gin.H{
			"status":  "error",
			"message": "获取当前用户失败",
		})
		return
	}
    username := user.Username

	var templates []PReportTemplate
	if err := db.Where("username = ?", username).Order("updated_at DESC").Find(&templates).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{
			"status":  "error",
			"message": "查询模板列表失败",
		})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"status":  "success",
		"message": "获取模板列表成功",
		"data":    templates,
	})
}

type GenHTMLRequest struct {
	ReportName   string `json:"report_name" binding:"required"`
	TemplateJSON string `json:"template_json" binding:"required"`
}

// GenHTMLResponse 生成HTML报表的响应结构体
type GenHTMLResponse struct {
	Status  string                 `json:"status"`
	Message string                 `json:"message"`
	Data    *HTMLDownloadData      `json:"data,omitempty"`
	Error   *GenHTMLResponseError  `json:"error,omitempty"`
}

// HTMLDownloadData 下载链接数据
type HTMLDownloadData struct {
	HTMLDownloadURL string `json:"HTMLDownloadURL"`
	FileName        string `json:"file_name"`
}

// GenHTMLResponseError 错误详情
type GenHTMLResponseError struct {
	Code    string `json:"code,omitempty"`
	Details string `json:"details,omitempty"`
}

// 生成HTML报表的处理函数
func generateHTMLHandler(c *gin.Context) {
	// 1. 绑定并验证请求参数
	var req GenHTMLRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		log.Printf("参数绑定失败: %v", err)
		c.JSON(http.StatusBadRequest, GenHTMLResponse{
			Status:  "error",
			Message: "无效的请求参数",
			Error: &GenHTMLResponseError{
				Details: fmt.Sprintf("参数解析失败: %v", err),
			},
		})
		return
	}

	// 2. 获取当前用户（根据你的认证逻辑实现）
	user, ok := getCurrentUser(c)
	if !ok {
		log.Println("获取当前用户失败")
		c.JSON(http.StatusUnauthorized, GenHTMLResponse{
			Status:  "error",
			Message: "未授权访问",
		})
		return
	}
	username := user.Username
	log.Printf("用户 %s 开始生成HTML报表: %s", username, req.ReportName)

	// 3. 准备临时文件和输出目录
	tempDir := filepath.Join("temp", username)
	outputDir := filepath.Join("data", "reports", username)

	// 创建必要的目录
	if err := os.MkdirAll(tempDir, 0755); err != nil {
		log.Printf("创建临时目录失败: %v", err)
		c.JSON(http.StatusInternalServerError, GenHTMLResponse{
			Status:  "error",
			Message: "服务器准备失败",
			Error: &GenHTMLResponseError{
				Details: "无法创建临时目录",
			},
		})
		return
	}

	if err := os.MkdirAll(outputDir, 0755); err != nil {
		log.Printf("创建输出目录失败: %v", err)
		c.JSON(http.StatusInternalServerError, GenHTMLResponse{
			Status:  "error",
			Message: "服务器准备失败",
			Error: &GenHTMLResponseError{
				Details: "无法创建输出目录",
			},
		})
		return
	}

	// 4. 保存模板JSON到临时文件
	timestamp := time.Now().Format("20060102150405")
	tempFileName := fmt.Sprintf("template_%s_%s.json", req.ReportName, timestamp)
	tempFilePath := filepath.Join(tempDir, tempFileName)

	if err := os.WriteFile(tempFilePath, []byte(req.TemplateJSON), 0644); err != nil {
		log.Printf("保存模板文件失败: %v", err)
		c.JSON(http.StatusInternalServerError, GenHTMLResponse{
			Status:  "error",
			Message: "保存模板失败",
		})
		return
	}

	// 5. 生成HTML文件名（替换空格为下划线）
	htmlFileName := fmt.Sprintf("%s.html",replaceSpaces(req.ReportName))
	htmlOutputPath := filepath.Join(outputDir, htmlFileName)

	// 6. 调用外部脚本生成HTML（例如Python脚本）
// 	log.Printf("开始执行HTML生成脚本，输出路径: %s", htmlOutputPath)
	cmd := exec.Command(
		"python",
		"genCustomReport.py",  // 你的HTML生成脚本
		"--template", tempFilePath,
		"--output", htmlOutputPath,
	)

	output, err := cmd.CombinedOutput()
	if err != nil {
		log.Printf("HTML生成失败: %v, 脚本输出: %s", err, string(output))
		c.JSON(http.StatusInternalServerError, GenHTMLResponse{
			Status:  "error",
			Message: "生成HTML报表失败",
			Error: &GenHTMLResponseError{
				Details: string(output),
			},
		})
		return
	}
	log.Printf("HTML生成成功，脚本输出: %s", string(output))


   encodedFileName := url.PathEscape(htmlFileName)

    // 生成下载 URL（注意替换 server_ip 和 server_port 为实际值）
    downloadURL := fmt.Sprintf(
        "/download/data/reports/%s/%s",
        username,
        encodedFileName,
    )
    //http://%s:%s
	// 8. 构建下载URL
	//downloadURL := fmt.Sprintf("http://%s:%s/download/data/reports/%s/%s", server_ip,server_port,username, htmlFileName)

	// 9. 可选：记录生成历史到数据库
	if err := recordReportGeneration(c, username, req.ReportName, htmlOutputPath); err != nil {
		log.Printf("记录报表生成历史失败: %v", err)
		// 这里不返回错误，只是记录日志，因为主流程已完成
	}
    log.Printf("downloadURL:%s",downloadURL)

	// 10. 返回成功响应
	c.JSON(http.StatusOK, GenHTMLResponse{
		Status:  "success",
		Message: "HTML报表生成成功",
		Data: &HTMLDownloadData{
			HTMLDownloadURL: downloadURL,
			FileName:        htmlFileName,
		},
	})
}

// 辅助函数：替换字符串中的空格为下划线
func replaceSpaces(s string) string {
	result := ""
	for _, r := range s {
		if r == ' ' {
			result += "_"
		} else {
			result += string(r)
		}
	}
	return result
}

// 辅助函数：记录报表生成历史（可选功能）
func recordReportGeneration(c *gin.Context, username string, reportName, filePath string) error {
	history := ReportGenerationHistory{
		Username:     username,
		ReportName: reportName,
		FilePath:   filePath,
		GeneratedAt: time.Now(),
	}

	return db.Create(&history).Error
}

// ReportGenerationHistory 报表生成历史记录模型（可选）
type ReportGenerationHistory struct {
	ID          uint           `gorm:"primaryKey" json:"id"`
	Username    string           `gorm:"not null" json:"username"`
	ReportName  string         `gorm:"size:100;not null" json:"report_name"`
	FilePath    string         `gorm:"size:255;not null" json:"file_path"`
	GeneratedAt time.Time      `json:"generated_at"`
	DeletedAt   gorm.DeletedAt `gorm:"index" json:"-"`
}