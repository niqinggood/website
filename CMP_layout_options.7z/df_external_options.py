# -*- coding: utf-8 -*-
import os
import json
import logging
from datetime import datetime
from flask import Flask, request, jsonify, make_response
from functools import wraps
import traceback

from saddle.utility.utils import set_logging
# 初始化日志配置
logging.basicConfig(  level=logging.INFO,    format='[%(asctime)s][%(levelname)s][%(filename)s:%(lineno)s-%(name)s] %(message)s')
logger = logging.getLogger(__name__)
# 初始化Flask应用
app = Flask(__name__)
app.config['JSON_AS_ASCII'] = False  # 确保JSON支持中文
from flask_cors import CORS  # 添加这行
CORS(app)  # 添加这行，允许所有跨域请求
# 配置文件路径
CONFIG_DIR = './'

class ConfigManager:
    @staticmethod
    def safe_read_json(filepath, default=None):
        """安全读取JSON文件，处理各种编码问题"""
        if not os.path.exists(filepath):
            return default if default is not None else {}

        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                return json.load(f)
        except UnicodeDecodeError:
            try:
                with open(filepath, 'r', encoding='gbk') as f:
                    return json.load(f)
            except Exception as e:
                logger.error(f"Failed to read {filepath}: {str(e)}")
                return default if default is not None else {}
        except Exception as e:
            logger.error(f"Error reading {filepath}: {str(e)}")
            return default if default is not None else {}

    @staticmethod
    def safe_write_json(filepath, data):
        """安全写入JSON文件，确保目录存在并使用UTF-8编码"""
        try:
            os.makedirs(os.path.dirname(filepath), exist_ok=True)
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            return True
        except Exception as e:
            logger.error(f"Failed to write {filepath}: {str(e)}")
            return False


# 配置管理API
import pandas as pd
import traceback

SQLITE_DB_PATH = 'pilot_datafactory.db'
fetchdata_tab  = "pilot_datafetch_config"

import sqlite3
from sqlalchemy import text
sa_engine = None
def get_db_connection():
    """Get database connection, preferring sa_engine but falling back to SQLite"""
    if sa_engine is not None:
        return sa_engine.connect()
    else:
        return sqlite3.connect(SQLITE_DB_PATH)

# 获取选项
@app.route('/api/options/<category>/<field>', methods=['POST'])
def get_options(category,field):
    filepath = './CMP_layout_options.csv'
    with open(filepath, 'r', encoding='utf-8') as f:
        DEFAULT_DATA = json.load(f)
    try:
        data    = request.get_json()
        field   = data.get('field')
        level   = data.get('level')
        tab     = data.get('tab')
        depends = data.get('depends', [])

        logger.info("Received request for %s/%s with depends %s", tab, field, depends)

        # 根据请求参数获取选项
        result = []

        # 全局选项
        if level == 'global':
            if field == 'product':
                result = DEFAULT_DATA.get('global', {}).get('product', [])+ list(range(1,1100))
            elif field in [ 'infer_stage','stage'] and depends:
                result = DEFAULT_DATA.get('global', {}).get('stage', {}).get(depends[0], [])  + list(range(1,2100))

        # WIP选项
        elif tab == 'wip':
            if field == 'eqp_type' and depends:
                result = DEFAULT_DATA.get('wip', {}).get('eqp_type', {}).get(depends[0], [])
            elif field == 'chamber' and depends:
                result = DEFAULT_DATA.get('wip', {}).get('chamber', {}).get(depends[0], [])
            elif field == 'step_seq' and depends:
                result = DEFAULT_DATA.get('wip', {}).get('step_seq', {}).get(depends[0], [])

        # Inline选项
        elif tab == 'inline':
            if field == 'measure_type' and depends:
                result = DEFAULT_DATA.get('inline', {}).get('measure_type', {}).get(depends[0], [])
            elif field == 'param' and depends:
                result = DEFAULT_DATA.get('inline', {}).get('param', {}).get(depends[0], [])

        # IEMS选项
        elif tab == 'iems':
            if field == 'analysis_type' and depends:
                result = DEFAULT_DATA.get('iems', {}).get('analysis_type', {}).get(depends[0], [])
            elif field == 'metric' and depends:
                result = DEFAULT_DATA.get('iems', {}).get('metric', {}).get(depends[0], [])

        logger.info("Returning options for %s/%s with depends %s: %s",
                    tab, field, depends, result)

        return jsonify(result)

    except Exception as e:

        logger.error(f"Options load failed: {str(e)}\n{traceback.format_exc()}")
        return jsonify({"error": "选项加载失败"}), 500

if __name__ == '__main__':
    app.run(   host='0.0.0.0',     port=5002,     debug=True,    threaded=True )
