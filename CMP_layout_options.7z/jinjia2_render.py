from flask import Flask, render_template
import json

app = Flask(__name__)

# 读取你的模板 JSON 文件（实际项目中可从数据库/接口获取）
def load_template_json():
    json_str = '''
{
  "metadata": {
    "templateId": "template-1757156062554",
    "templateName": "test-1",
    "templateDescription": "钻石数据雷达图报表",
    "createdAt": "2025-09-06T10:54:22.554Z",
    "version": "1.0.0",
    "author": "Unknown",
    "filePath": "diamonds.csv",
    "jinja2": {
      "compatible": true,
      "renderEngine": "jinja2@3.x",
      "lastCompatibleVersion": "1.0.0"
    }
  },
  "structure": [
    [
      {
        "id": "block-1757155755832",
        "type": "radar",
        "title": "钻石颜色-价格雷达图",
        "width": 3,
        "isConfigured": true,
        "config": {
          "xAxis": "color",
          "yAxis": ["price"],
          "aggregations": {"price": "mean"},
          "sampling": true,
          "sampleSize": 1000
        }
      }
    ]
  ],
  "preview": {
    "blockCount": 1,
    "rowCount": 1,
    "hasConfiguredBlocks": true,
    "jinja2Config": {
      "baseTemplatePath": "templates/base_report.html",
      "chartTemplatePaths": {
        "bar": "templates/charts/bar_chart.html",
        "line": "templates/charts/line_chart.html",
        "pie": "templates/charts/pie_chart.html",
        "table": "templates/charts/table.html"
      }
    }
  }
}
    '''
    return json.loads(json_str)

# 路由：生成静态报表页面
@app.route('/generate-report')
def generate_report():
    template_data = load_template_json()
    # 将 JSON 数据传递给 Jinja2 模板
    return render_template(
        'report_template.html',  # 对应上面的 Jinja2 模板文件
        metadata=template_data['metadata'],
        structure=template_data['structure'],
        preview=template_data['preview']
    )

if __name__ == '__main__':
    app.run(debug=True)