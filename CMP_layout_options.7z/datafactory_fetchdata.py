#!/usr/bin/env python3
import os,sys,json,time,argparse,logging,random,csv,io
import pandas as pd
import numpy as np
import logging
import os
from logging.handlers import RotatingFileHandler

def set_logging(
    log_file="datafactory_logs.log",
    level=logging.INFO,
    max_bytes=10*1024*1024,  # 10MB
    backup_count=5           # 最多保留5个备份日志文件
):
    """
    配置日志系统，将日志同时输出到文件和控制台
    
    参数:
        log_file: 日志文件路径，默认是"datafactory_logs.log"
        level: 日志级别，默认是INFO
        max_bytes: 单个日志文件最大大小，默认10MB
        backup_count: 日志文件轮转备份数量，默认5个
    """
    # 获取根日志器
    logger = logging.getLogger()
    logger.setLevel(level)
    
    # 避免重复添加处理器
    if logger.handlers:
        logger.handlers.clear()
    
    # 日志格式
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    
    # 确保日志目录存在
    log_dir = os.path.dirname(log_file)
    if log_dir and not os.path.exists(log_dir):
        os.makedirs(log_dir, exist_ok=True)
    
    # 文件处理器：使用RotatingFileHandler实现日志轮转
    file_handler = RotatingFileHandler(
        log_file,
        mode='a',
        maxBytes=max_bytes,
        backupCount=backup_count,
        encoding='utf-8'
    )
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)
    
    # 控制台处理器
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)
    
    return logger

logger = set_logging()

def get_oracle_engine(user,password,ip_port,db,mode:str="sid"):
    import cx_Oracle
    import sqlalchemy as sa
    from sqlalchemy import create_engine, text
    if mode.lower()=="sid":
        return sa.create_engine("oracle+cx_oracle://%s:%s@%s/%s" %(user,password,ip_port,db),max_overflow=15,pool_recycle=600,pool_size=0 )
    elif mode.lower()=="servicename":
        return sa.create_engine("oracle+cx_oracle://%s:%s@%s/?service_name=%s" %(user,password,ip_port,db),max_overflow=15,pool_recycle=600,pool_size=0 )
    else:
        raise ValueError("Wrong mode, should be either 'sid' or 'servicename'")

def get_mysql_engine(user,passwd,ip_port,db):
    from urllib.parse import quote_plus
    from sqlalchemy import create_engine, text
    import sqlalchemy as sa
    encoded_passwd = quote_plus(passwd)
    #if '@' in passwd : passwd = passwd.replace('@','%40')
    return sa.create_engine("mysql+pymysql://%s:%s@%s/%s?charset=utf8mb4"%(user,encoded_passwd,ip_port,db ),max_overflow=15,pool_recycle=600,pool_size=0  )

from typing import Optional,Callable
def get_sql_df(sql,sa_engine,func: Optional[Callable] = None):
    logging.info('######sql:\n%s',sql)
    df = pd.read_sql(sql,sa_engine)
    if func!=None:
        df = func( df )
    logging.info("######ssampledf:\n%s",df.head(2) )
    return df

def to_sqlin_str(in_list):
    if type(in_list) == str:
        in_list = [in_list]
    ret_str = str( tuple(in_list) ).replace(  ',)',','  )
    return ret_str

def selectDB_oracle(connect,sql,val=() ):
    mycursor = connect.cursor()
    mycursor.excute(sql,val)
    myresult = mycursor.fetchall()
    mycursor.close()
    return myresult

def parse_arguments():
    """Parse command line arguments"""
    parser = argparse.ArgumentParser(description='Data Factory Data Fetching Script')
    parser.add_argument('--task-id', required=True, help='Task ID')
    parser.add_argument('--config-file', required=True, help='Configuration file path')
    parser.add_argument('--mode', required=True, help='Fetch mode (e.g., infer)')
    parser.add_argument('--ini_path', default="config.ini", type=str,required=False,help="config file path")  # 保留原参数
    parser.add_argument('--output-json', required=True, help='Path to save download info JSON')  # 新增参数
    parser.add_argument('--infer-params', required=False, help='Inference parameters (JSON)')  # 保留原参数

    return parser.parse_args()
def load_config(config_file):
    """Load configuration file"""
    try:
        with open(config_file, 'r', encoding='utf-8') as f:
            config = json.load(f)
        logging.info(f"Successfully loaded config file: {config_file}")
        return config
    except Exception as e:
        logging.error(f"Failed to load config file: {str(e)}")
        raise

def get_data():
    df = pd.DataFrame({
                "id": range(1, 21),
                "value": np.random.randn(20).round(2),
                "category": np.random.choice(["A", "B", "C"], 20),
                "date": pd.date_range(end=pd.Timestamp.now(), periods=20)
            })
    return df

def gen_data_and_save():
    """简化版：生成测试数据并保存到CSV文件"""
    args                = parse_arguments()
    task_id             = args.task_id
    config_file         = args.config_file
    output_json_path    = args.output_json
    logging.info(f"Starting task processing: {task_id}")
    data_dir = "./data/fetch-data" ;   os.makedirs(data_dir, exist_ok=True)
    download_info = {}
    
    
    
    fetch_data_config   = load_config(config_file)
    config_name         = fetch_data_config.get("configName", "test_config")
    time_range          =  fetch_data_config.get("timeRange", "single")
    

    if time_range == "single":
        file_name = f"{config_name}_single__{task_id}.csv"  ; file_path = os.path.join(data_dir, file_name)
        # 此处填如 获取数据的逻辑
        get_data().to_csv( file_path,index=False)
        download_info["single_file"] = "download/"+file_path
    else:
        # 分割为训练集和测试集
        train_file = f"{config_name}_train__{task_id}.csv"
        test_file  = f"{config_name}_test__{task_id}.csv"
        df         = get_data()
        df.head(5).to_csv( train_file, index=False  )
        df.tail(5).to_csv( test_file,  index=False  )

        download_info = {
            "train_file": "download/"+ os.path.join(data_dir, train_file ),
            "test_file":  "download/"+ os.path.join(data_dir, test_file  ),
        }
    logging.info(f"任务 {task_id} 的数据生成和保存完成 download_info: {download_info}"  )    
    with open(output_json_path, 'w', encoding='utf-8') as f:
        json.dump(download_info, f, ensure_ascii=False, indent=2)    
    return
if __name__ == "__main__":
    try:
        gen_data_and_save(  )
    except Exception as e:
        import traceback
        sys.stderr.write(f"Error processing request: {str(e)} trackback:{ str( traceback.format_exc() )  } \n")
        sys.stderr.flush()