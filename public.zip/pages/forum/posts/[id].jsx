// pages/forum/posts/[id].jsx
import { Layout } from '../../../components/AllComponents';
import { useState, useEffect, useCallback } from 'react';
import { useRouter } from 'next/router';
import {
  Box, Container, Typography, Paper, Grid, Button,
  TextField, IconButton, Chip, Avatar, Divider,
  Card, CardContent, CardActions, Alert, Snackbar,
  Dialog, DialogTitle, DialogContent, DialogActions,
  Breadcrumbs, Link, Fab, Tooltip,
  List, ListItem, ListItemText, ListItemAvatar,
  FormControl, InputLabel, Select, MenuItem,
  CircularProgress, Skeleton, useTheme, useMediaQuery,
  alpha, Collapse
} from '@mui/material';
import {
  ThumbUp, Comment, Share, Bookmark, BookmarkBorder,
  Add, ArrowBack, Reply, Edit, Delete,
  ThumbUpOffAlt, ThumbUpAlt, ExpandMore, ExpandLess,
  CheckCircle, Schedule, Visibility,
  Home, Send, MoreVert, SubdirectoryArrowRight
} from '@mui/icons-material';
import { styled } from '@mui/material/styles';

// 样式组件
const StyledCommentCard = styled(Card)(({ theme, level = 0 }) => ({
  marginBottom: theme.spacing(2),
  marginLeft: level > 0 ? theme.spacing(4) : 0,
  border: `1px solid ${theme.palette.divider}`,
  borderRadius: theme.spacing(1),
  backgroundColor: level > 0 ? alpha(theme.palette.background.default, 0.5) : theme.palette.background.paper,
  transition: 'all 0.2s ease',
  '&:hover': {
    borderColor: theme.palette.primary.light,
    boxShadow: theme.shadows[1],
  }
}));

const StyledReplyTextField = styled(TextField)(({ theme }) => ({
  '& .MuiOutlinedInput-root': {
    borderRadius: theme.spacing(1),
  }
}));

// 评论组件
const CommentItem = ({ comment, level = 0, onReply, onLike, onEdit, onDelete }) => {
  const [isReplying, setIsReplying] = useState(false);
  const [replyContent, setReplyContent] = useState('');
  const [showReplies, setShowReplies] = useState(true);
  const [isLiked, setIsLiked] = useState(comment.isLiked);
  const [likeCount, setLikeCount] = useState(comment.likes);
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));

  const handleLike = async () => {
    const newLikedState = !isLiked;
    setIsLiked(newLikedState);
    setLikeCount(prev => newLikedState ? prev + 1 : prev - 1);
    await onLike?.(comment.id, newLikedState);
  };

  const handleReply = () => {
    if (replyContent.trim()) {
      onReply?.(comment.id, replyContent);
      setReplyContent('');
      setIsReplying(false);
    }
  };

  const formatTime = (dateString) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInMs = now - date;
    const diffInHours = diffInMs / (1000 * 60 * 60);
    const diffInDays = diffInHours / 24;

    if (diffInHours < 1) {
      const minutes = Math.floor(diffInMs / (1000 * 60));
      return minutes < 1 ? '刚刚' : `${minutes}分钟前`;
    } else if (diffInHours < 24) {
      return `${Math.floor(diffInHours)}小时前`;
    } else if (diffInDays < 7) {
      return `${Math.floor(diffInDays)}天前`;
    } else {
      return date.toLocaleDateString('zh-CN');
    }
  };

  const hasReplies = comment.replies && comment.replies.length > 0;

  return (
    <>
      <StyledCommentCard level={level}>
        <CardContent sx={{ pb: 1 }}>
          {/* 评论头部 */}
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 2 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
              <Avatar
                src={comment.author.avatar}
                sx={{
                  width: 32,
                  height: 32,
                  bgcolor: 'primary.light',
                  fontSize: '0.75rem'
                }}
              >
                {comment.author.name.charAt(0)}
              </Avatar>
              <Box>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                  <Typography variant="subtitle2" fontWeight="600">
                    {comment.author.name}
                  </Typography>
                  {comment.author.isVerified && (
                    <CheckCircle sx={{ fontSize: 14, color: 'primary.main' }} />
                  )}
                </Box>
                <Typography variant="caption" color="text.secondary">
                  {comment.author.role} · {formatTime(comment.createdAt)}
                </Typography>
              </Box>
            </Box>

            {/* 操作按钮 */}
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
              <Tooltip title={isLiked ? '取消点赞' : '点赞'}>
                <IconButton
                  size="small"
                  onClick={handleLike}
                  sx={{
                    color: isLiked ? 'primary.main' : 'text.secondary',
                  }}
                >
                  {isLiked ? <ThumbUpAlt /> : <ThumbUpOffAlt />}
                </IconButton>
              </Tooltip>
              <Typography variant="caption" color="text.secondary" sx={{ minWidth: 20, textAlign: 'center' }}>
                {likeCount}
              </Typography>

              <Tooltip title="回复">
                <IconButton
                  size="small"
                  onClick={() => setIsReplying(!isReplying)}
                  sx={{ color: 'text.secondary' }}
                >
                  <Reply />
                </IconButton>
              </Tooltip>
            </Box>
          </Box>

          {/* 评论内容 */}
          <Typography variant="body1" sx={{ lineHeight: 1.6, mb: 2 }}>
            {comment.content}
          </Typography>

          {/* 回复输入框 */}
          <Collapse in={isReplying}>
            <Box sx={{ mb: 2 }}>
              <StyledReplyTextField
                fullWidth
                multiline
                rows={3}
                placeholder={`回复 ${comment.author.name}...`}
                value={replyContent}
                onChange={(e) => setReplyContent(e.target.value)}
                sx={{ mb: 1 }}
              />
              <Box sx={{ display: 'flex', gap: 1, justifyContent: 'flex-end' }}>
                <Button
                  size="small"
                  onClick={() => setIsReplying(false)}
                >
                  取消
                </Button>
                <Button
                  size="small"
                  variant="contained"
                  onClick={handleReply}
                  disabled={!replyContent.trim()}
                  startIcon={<Send />}
                >
                  回复
                </Button>
              </Box>
            </Box>
          </Collapse>
        </CardContent>

        {/* 回复展开/收起 */}
        {hasReplies && (
          <CardActions sx={{ pt: 0, px: 2, pb: 1 }}>
            <Button
              size="small"
              startIcon={showReplies ? <ExpandLess /> : <ExpandMore />}
              onClick={() => setShowReplies(!showReplies)}
              sx={{ color: 'text.secondary' }}
            >
              {showReplies ? '收起回复' : `展开 ${comment.replies.length} 条回复`}
            </Button>
          </CardActions>
        )}
      </StyledCommentCard>

      {/* 子评论 */}
      {hasReplies && showReplies && (
        <Box>
          {comment.replies.map((reply) => (
            <CommentItem
              key={reply.id}
              comment={reply}
              level={level + 1}
              onReply={onReply}
              onLike={onLike}
              onEdit={onEdit}
              onDelete={onDelete}
            />
          ))}
        </Box>
      )}
    </>
  );
};

// 评论列表组件
const CommentList = ({ comments, loading, onReply, onLike }) => {
  if (loading) {
    return (
      <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
        {[...Array(3)].map((_, index) => (
          <Skeleton key={index} variant="rounded" height={120} />
        ))}
      </Box>
    );
  }

  if (!comments || comments.length === 0) {
    return (
      <Paper sx={{ p: 4, textAlign: 'center', borderRadius: 2 }}>
        <Typography variant="h6" color="text.secondary" gutterBottom>
          暂无评论
        </Typography>
        <Typography variant="body2" color="text.secondary">
          成为第一个评论的人吧！
        </Typography>
      </Paper>
    );
  }

  return (
    <Box>
      {comments.map((comment) => (
        <CommentItem
          key={comment.id}
          comment={comment}
          onReply={onReply}
          onLike={onLike}
        />
      ))}
    </Box>
  );
};

// 评论输入组件
const CommentInput = ({ onSubmit, placeholder = "写下你的评论...", loading = false }) => {
  const [content, setContent] = useState('');

  const handleSubmit = () => {
    if (content.trim()) {
      onSubmit?.(content);
      setContent('');
    }
  };

  return (
    <Paper sx={{ p: 3, mb: 3, borderRadius: 2 }}>
      <Typography variant="h6" gutterBottom>
        发表评论
      </Typography>
      <StyledReplyTextField
        fullWidth
        multiline
        rows={4}
        placeholder={placeholder}
        value={content}
        onChange={(e) => setContent(e.target.value)}
        sx={{ mb: 2 }}
      />
      <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
        <Button
          variant="contained"
          onClick={handleSubmit}
          disabled={!content.trim() || loading}
          startIcon={loading ? <CircularProgress size={16} /> : <Send />}
        >
          {loading ? '提交中...' : '发表评论'}
        </Button>
      </Box>
    </Paper>
  );
};

// 帖子详情页面
export default function PostDetailPage() {
  const router = useRouter();
  const { id } = router.query;
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));

  const [post, setPost] = useState(null);
  const [comments, setComments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' });

  // 加载帖子详情和评论
  const loadPostData = useCallback(async () => {
    if (!id) return;

    setLoading(true);
    try {
      // 加载帖子详情
      const postResponse = await fetch(`/api/forum/posts/${id}`);
      if (postResponse.ok) {
        const postData = await postResponse.json();
        setPost(postData.data);
      }

      // 加载评论
      const commentsResponse = await fetch(`/api/forum/posts/${id}/comments`);
      if (commentsResponse.ok) {
        const commentsData = await commentsResponse.json();
        setComments(commentsData.data || []);
      }
    } catch (error) {
      console.error('加载数据失败:', error);
      showSnackbar('加载数据失败', 'error');
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    loadPostData();
  }, [loadPostData]);

  const showSnackbar = (message, severity = 'success') => {
    setSnackbar({ open: true, message, severity });
  };

  // 发表评论
  const handleSubmitComment = async (content, parentId = null) => {
    setSubmitting(true);
    try {
      const response = await fetch(`/api/forum/posts/${id}/comments`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          content,
          parentId
        }),
      });

      if (response.ok) {
        showSnackbar('评论发表成功');
        // 重新加载评论
        loadPostData();
      } else {
        throw new Error('发表评论失败');
      }
    } catch (error) {
      showSnackbar('发表评论失败', 'error');
    } finally {
      setSubmitting(false);
    }
  };

  // 回复评论
  const handleReply = async (parentId, content) => {
    await handleSubmitComment(content, parentId);
  };

  // 点赞评论
  const handleLikeComment = async (commentId, isLiked) => {
    try {
      // 这里应该调用点赞API
      // 暂时模拟点赞操作
      setComments(prev =>
        prev.map(comment =>
          updateCommentLikes(comment, commentId, isLiked)
        )
      );
    } catch (error) {
      console.error('点赞失败:', error);
    }
  };

  // 递归更新评论点赞状态
  const updateCommentLikes = (comment, targetId, isLiked) => {
    if (comment.id === targetId) {
      return {
        ...comment,
        likes: isLiked ? comment.likes + 1 : comment.likes - 1,
        isLiked
      };
    }

    if (comment.replies) {
      return {
        ...comment,
        replies: comment.replies.map(reply =>
          updateCommentLikes(reply, targetId, isLiked)
        )
      };
    }

    return comment;
  };

  if (loading && !post) {
    return (
      <Layout config={{}}>
        <Container maxWidth="lg" sx={{ py: 4 }}>
          <Skeleton variant="rounded" height={400} />
        </Container>
      </Layout>
    );
  }

  if (!post) {
    return (
      <Layout config={{}}>
        <Container maxWidth="lg" sx={{ py: 4 }}>
          <Paper sx={{ p: 6, textAlign: 'center' }}>
            <Typography variant="h5" gutterBottom>
              帖子不存在
            </Typography>
            <Button
              variant="contained"
              startIcon={<ArrowBack />}
              onClick={() => router.push('/forum')}
            >
              返回论坛
            </Button>
          </Paper>
        </Container>
      </Layout>
    );
  }

  return (
    <Layout config={{}}>
      <Container maxWidth="lg" sx={{ py: 4 }}>
        {/* 面包屑导航 */}
        <Breadcrumbs sx={{ mb: 4 }}>
          <Link underline="hover" color="inherit" href="/" onClick={(e) => { e.preventDefault(); router.push('/'); }}>
            <Home sx={{ mr: 0.5 }} fontSize="inherit" />
            首页
          </Link>
          <Link underline="hover" color="inherit" href="/forum" onClick={(e) => { e.preventDefault(); router.push('/forum'); }}>
            技术论坛
          </Link>
          <Typography color="text.primary">{post.title}</Typography>
        </Breadcrumbs>

        <Grid container spacing={4}>
          {/* 主内容 */}
          <Grid item xs={12} lg={8}>
            {/* 帖子详情 */}
            <Paper sx={{ p: 4, mb: 3, borderRadius: 2 }}>
              {/* 帖子头部 */}
              <Box sx={{ mb: 3 }}>
                <Typography variant="h4" gutterBottom fontWeight="700">
                  {post.title}
                </Typography>

                <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, flexWrap: 'wrap', mb: 2 }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <Avatar src={post.author.avatar} sx={{ width: 40, height: 40 }}>
                      {post.author.name.charAt(0)}
                    </Avatar>
                    <Box>
                      <Typography variant="subtitle1" fontWeight="600">
                        {post.author.name}
                      </Typography>
                      <Typography variant="caption" color="text.secondary">
                        {post.author.role}
                      </Typography>
                    </Box>
                  </Box>

                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, color: 'text.secondary' }}>
                    <Schedule sx={{ fontSize: 16 }} />
                    <Typography variant="body2">
                      {new Date(post.createdAt).toLocaleDateString()}
                    </Typography>

                    <Visibility sx={{ fontSize: 16, ml: 1 }} />
                    <Typography variant="body2">
                      {post.views} 浏览
                    </Typography>
                  </Box>
                </Box>

                {/* 标签 */}
                <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
                  <Chip label={post.category.name} color="primary" variant="outlined" />
                  {post.tags.map((tag, index) => (
                    <Chip key={index} label={tag.name} variant="outlined" size="small" />
                  ))}
                </Box>
              </Box>

              <Divider sx={{ my: 3 }} />

              {/* 帖子内容 */}
              <Box sx={{ lineHeight: 1.8 }}>
                <Typography variant="body1" component="div" sx={{ whiteSpace: 'pre-wrap' }}>
                  {post.content}
                </Typography>
              </Box>

              {/* 帖子统计 */}
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mt: 4, pt: 2, borderTop: `1px solid ${theme.palette.divider}` }}>
                <Box sx={{ display: 'flex', gap: 2 }}>
                  <Button
                    startIcon={post.isLiked ? <ThumbUpAlt /> : <ThumbUpOffAlt />}
                    color={post.isLiked ? 'primary' : 'inherit'}
                  >
                    {post.likes}
                  </Button>
                  <Button startIcon={<Comment />}>
                    {post.comments} 评论
                  </Button>
                  <Button startIcon={<Share />}>
                    分享
                  </Button>
                </Box>

                <Button
                  startIcon={<BookmarkBorder />}
                  color={post.isBookmarked ? 'warning' : 'inherit'}
                >
                  {post.isBookmarked ? '已收藏' : '收藏'}
                </Button>
              </Box>
            </Paper>

            {/* 评论输入 */}
            <CommentInput
              onSubmit={(content) => handleSubmitComment(content)}
              loading={submitting}
            />

            {/* 评论列表 */}
            <Box>
              <Typography variant="h5" gutterBottom sx={{ mb: 3 }}>
                评论 ({comments.length})
              </Typography>
              <CommentList
                comments={comments}
                loading={loading}
                onReply={handleReply}
                onLike={handleLikeComment}
              />
            </Box>
          </Grid>

          {/* 侧边栏 */}
          {!isMobile && (
            <Grid item xs={12} lg={4}>
              <Paper sx={{ p: 3, position: 'sticky', top: 100, borderRadius: 2 }}>
                <Typography variant="h6" gutterBottom>
                  帖子信息
                </Typography>

                <List dense>
                  <ListItem>
                    <ListItemText
                      primary="发布时间"
                      secondary={new Date(post.createdAt).toLocaleString()}
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemText
                      primary="最后活动"
                      secondary={new Date(post.lastActivity).toLocaleString()}
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemText
                      primary="阅读时间"
                      secondary={`约 ${post.readingTime} 分钟`}
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemText
                      primary="难度级别"
                      secondary={
                        <Chip
                          label={
                            post.difficulty === 'beginner' ? '初级' :
                            post.difficulty === 'intermediate' ? '中级' : '高级'
                          }
                          size="small"
                          color={
                            post.difficulty === 'beginner' ? 'success' :
                            post.difficulty === 'intermediate' ? 'warning' : 'error'
                          }
                        />
                      }
                    />
                  </ListItem>
                </List>

                <Divider sx={{ my: 2 }} />

                <Typography variant="h6" gutterBottom>
                  作者信息
                </Typography>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 2 }}>
                  <Avatar src={post.author.avatar} sx={{ width: 60, height: 60 }}>
                    {post.author.name.charAt(0)}
                  </Avatar>
                  <Box>
                    <Typography variant="subtitle1" fontWeight="600">
                      {post.author.name}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      {post.author.role}
                    </Typography>
                    <Typography variant="caption" color="text.secondary">
                      声望: {post.author.reputation}
                    </Typography>
                  </Box>
                </Box>

                <Button
                  fullWidth
                  variant="outlined"
                  startIcon={<ArrowBack />}
                  onClick={() => router.push('/forum')}
                  sx={{ mt: 2 }}
                >
                  返回论坛
                </Button>
              </Paper>
            </Grid>
          )}
        </Grid>

        {/* 移动端返回按钮 */}
        {isMobile && (
          <Fab
            color="primary"
            sx={{
              position: 'fixed',
              bottom: 24,
              left: 24,
              zIndex: 1000
            }}
            onClick={() => router.push('/forum')}
          >
            <ArrowBack />
          </Fab>
        )}

        {/* 消息提示 */}
        <Snackbar
          open={snackbar.open}
          autoHideDuration={4000}
          onClose={() => setSnackbar(prev => ({ ...prev, open: false }))}
          anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
        >
          <Alert
            severity={snackbar.severity}
            onClose={() => setSnackbar(prev => ({ ...prev, open: false }))}
            sx={{ borderRadius: 2 }}
          >
            {snackbar.message}
          </Alert>
        </Snackbar>
      </Container>
    </Layout>
  );
}