import Head from 'next/head';
import { useRouter } from 'next/router';
import { Layout } from '../components/AllComponents';
import { useEffect, useState } from 'react';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import {
  Container, Paper, Typography, Box, TextField, Button,
  Grid, Alert
} from '@mui/material';
import api from '../components/axiosConfig'; // 使用全局 axios 实例
import { useAuth } from '../components/AuthContext'; // 导入认证上下文

export const LoginForm = () => {
  const { login } = useAuth(); // 获取登录方法
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");
  const router = useRouter();

  const theme = createTheme({
    palette: {
      primary: { main: '#165DFF' },
      secondary: { main: '#0A2463' },
    }
  });

  const handleLogin = async () => {
    // 表单验证
    if (!username || !password) {
      setError("请输入用户名和密码");
      return;
    }

    const trimmedUsername = username.trim();
    if (trimmedUsername.length < 3) {
      setError("用户名至少3个字符");
      return;
    }
    if (!/^[a-zA-Z0-9_ ]+$/.test(trimmedUsername)) {
      setError("用户名只能包含字母、数字、下划线和空格");
      return;
    }

    try {
      setIsLoading(true);
      setError("");

      // 使用全局 axios 实例
      const response = await api.post('/api/login', {
        username: trimmedUsername,
        password: password
      });

      const { token, user, role } = response.data;

      // 使用上下文的登录方法存储 token
       login(token, { username: user, role });

      router.push(router.query.returnUrl || "/");

    } catch (error) {
      console.error('登录失败:', error);
      setError(
        error.response?.data?.message ||
        error.message ||
        "登录失败，请检查用户名和密码是否正确"
      );
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      handleLogin();
    }
  };

  return (
    <ThemeProvider theme={theme}>
      <Container maxWidth="sm" sx={{ py: { xs: 8, md: 12 } }}>
        <Paper
          elevation={3}
          sx={{
            p: 5,
            borderRadius: 2,
            boxShadow: 4,
            transition: 'box-shadow 0.3s ease',
            '&:hover': { boxShadow: 6 }
          }}
        >
          <Typography variant="h5" component="h1" gutterBottom align="center" sx={{ color: theme.palette.secondary.main }}>
            登录
          </Typography>

          {error && (
            <Alert severity="error" sx={{ mb: 3 }}>
              {error}
            </Alert>
          )}

          <Box component="form" noValidate sx={{ mt: 3 }}>
            <TextField
              margin="normal"
              required
              fullWidth
              label="用户名"
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              onKeyPress={handleKeyPress}
              sx={{
                '& .MuiOutlinedInput-root': {
                  '& fieldset': { borderColor: 'rgba(0, 0, 0, 0.1)' },
                  '&:hover fieldset': { borderColor: theme.palette.primary.main },
                  '&.Mui-focused fieldset': { borderColor: theme.palette.primary.main }
                }
              }}
            />

            <TextField
              margin="normal"
              required
              fullWidth
              label="密码"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              onKeyPress={handleKeyPress}
              sx={{
                '& .MuiOutlinedInput-root': {
                  '& fieldset': { borderColor: 'rgba(0, 0, 0, 0.1)' },
                  '&:hover fieldset': { borderColor: theme.palette.primary.main },
                  '&.Mui-focused fieldset': { borderColor: theme.palette.primary.main }
                }
              }}
            />

            <Button
              fullWidth
              variant="contained"
              sx={{
                mt: 4,
                mb: 3,
                py: 1.2,
                borderRadius: 2,
                textTransform: 'none',
                fontSize: 16,
                backgroundColor: theme.palette.primary.main,
                '&:hover': { backgroundColor: theme.palette.primary.dark },
                transition: 'all 0.3s ease',
              }}
              onClick={handleLogin}
              disabled={isLoading}
            >
              {isLoading ? (
                <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  登录中...
                </Box>
              ) : '登录'}
            </Button>

            <Grid container>
              <Grid item xs>
                <Button
                  variant="text"
                  onClick={() => router.push("/reset-password")}
                  sx={{
                    p: 0,
                    color: theme.palette.primary.main,
                    '&:hover': {
                      color: theme.palette.primary.dark,
                      backgroundColor: 'transparent',
                      textDecoration: 'underline'
                    }
                  }}
                >
                  忘记密码?
                </Button>
              </Grid>
              <Grid item>
                <Button
                  variant="text"
                  onClick={() => router.push("/register")}
                  sx={{
                    p: 0,
                    color: theme.palette.primary.main,
                    '&:hover': {
                      color: theme.palette.primary.dark,
                      backgroundColor: 'transparent',
                      textDecoration: 'underline'
                    }
                  }}
                >
                  还没有账号? 注册
                </Button>
              </Grid>
            </Grid>
          </Box>
        </Paper>
      </Container>
    </ThemeProvider>
  );
};

export default function Login() {
  const [config, setConfig] = useState(null);

  useEffect(() => {
    fetch('/config/site-config.json')
      .then(res => res.json())
      .then(data => setConfig(data))
      .catch(err => console.error('Failed to load config:', err));
  }, []);

  if (!config) return <div>Loading...</div>;

  return (
    <Layout config={config}>
      <Head>
        <title>登录 - {config.site?.name}</title>
      </Head>
      <LoginForm />
    </Layout>
  );
}
