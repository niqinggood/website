import { useState, useEffect } from 'react';
import Head from 'next/head';
import { Layout } from '../components/AllComponents';
import { GetStaticProps } from 'next';
import { useRouter } from 'next/router';
import axios from 'axios';
import {
  Container, Paper, Typography, Box, TextField,
  Button, Alert, ThemeProvider, createTheme
} from '@mui/material';
import { initializeApi } from '../components/config';

//export const getStaticProps = async () => {
//  const config = require('../public/config/site-config.json');
//  return { props: { config } };
//};

export const RegisterForm = ({ config }) => {
  const { registerForm } = config;
  const router = useRouter();

  // 表单状态管理
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: '',
    confirmPassword: '',
    agreeTerms: false
  });

  // 错误状态管理
  const [errors, setErrors] = useState({});
  const [serverError, setServerError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // 创建主题
  const theme = createTheme({
    palette: {
      primary: {
        main: config.theme?.primaryColor || '#165DFF',
      },
      secondary: {
        main: config.theme?.secondaryColor || '#0A2463',
      },
    }
  });

  // 处理表单输入变化
  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));

    // 清除对应字段的错误
    if (errors[name]) {
      setErrors(prev => {
        const newErrors = {...prev};
        delete newErrors[name];
        return newErrors;
      });
    }

    // 清除服务器错误
    if (serverError) {
      setServerError('');
    }
  };

  // 表单验证
  const validateForm = () => {
    const newErrors = {};

    // 用户名验证
    if (!formData.username.trim()) {
      newErrors.username = '用户名不能为空';
    } else if (formData.username.length < 3) {
      newErrors.username = '用户名至少3个字符';
    }

    // 邮箱验证
    if (!formData.email.trim()) {
      newErrors.email = '邮箱不能为空';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = '请输入有效的邮箱地址';
    }

    // 密码验证
    if (!formData.password) {
      newErrors.password = '密码不能为空';
    } else if (formData.password.length < 6) {
      newErrors.password = '密码至少6个字符';
    }

    // 确认密码验证
    if (!formData.confirmPassword) {
      newErrors.confirmPassword = '请确认密码';
    } else if (formData.password !== formData.confirmPassword) {
      newErrors.confirmPassword = '两次密码输入不一致';
    }

    // 同意条款验证
    if (!formData.agreeTerms) {
      newErrors.agreeTerms = '请同意服务条款和隐私政策';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // 处理注册提交
  const handleRegister = async () => {
    // 表单验证
//    if (!validateForm()) {
//      console.info("表达严正不过")
//      return;
//    }

    try {
      setIsLoading(true);
      setServerError('');

      // 准备发送到后端的数据（排除确认密码和同意条款）
      const registerData = {
        username: formData.username,
        email: formData.email,
        password: formData.password
      };

      // 调用后端注册API
      const response = await axios.post('/auth/register', registerData);

      // 注册成功处理
      console.log('注册成功:', response.data);

      // 显示成功消息并跳转到登录页
      alert(registerForm?.successMessage || "注册成功！请登录");
      router.push({
        pathname: '/login',
        query: { email: formData.email } // 传递邮箱到登录页
      });

    } catch (error) {
      console.error('注册失败:', error);

      // 处理服务器返回的错误
      if (error.response && error.response.data && error.response.data.message) {
        setServerError(error.response.data.message);
      } else if (error.response && error.response.status === 409) {
        setServerError('该邮箱已被注册');
      } else {
        setServerError('注册失败，请稍后重试');
      }
    } finally {
      setIsLoading(false);
    }
  };

  // 处理键盘回车提交
  const handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      handleRegister();
    }
  };

  // 渲染表单字段
  const renderFormField = (field) => {
    switch (field.type) {
      case 'text':
      case 'email':
      case 'password':
        return (
          <TextField
            key={field.name}
            margin="normal"
            required={field.required}
            fullWidth
            id={field.name}
            label={field.label}
            name={field.name}
            type={field.type}
            value={formData[field.name] || ''}
            onChange={handleChange}
            onKeyPress={handleKeyPress}
            error={!!errors[field.name]}
            helperText={errors[field.name]}
            sx={{
              '& .MuiOutlinedInput-root': {
                '& fieldset': {
                  borderColor: 'rgba(0, 0, 0, 0.1)',
                },
                '&:hover fieldset': {
                  borderColor: theme.palette.primary.main,
                },
                '&.Mui-focused fieldset': {
                  borderColor: theme.palette.primary.main,
                }
              }
            }}
          />
        );

      case 'checkbox':
        return (
          <Box key={field.name} sx={{ mt: 2, mb: 2 }}>
            <TextField
              type="checkbox"
              id={field.name}
              name={field.name}
              checked={formData[field.name] || false}
              onChange={handleChange}
              label={field.label}
              fullWidth
              required={field.required}
              error={!!errors[field.name]}
              helperText={errors[field.name]}
            />
          </Box>
        );

      default:
        return null;
    }
  };

  // 默认表单字段配置（如果配置文件中没有）
  const defaultFields = [
    { name: 'username', type: 'text', label: '用户名', required: true },
    { name: 'email', type: 'email', label: '邮箱', required: true },
    { name: 'password', type: 'password', label: '密码', required: true },
    { name: 'confirmPassword', type: 'password', label: '确认密码', required: true },
    {
      name: 'agreeTerms',
      type: 'checkbox',
      label: '我同意服务条款和隐私政策',
      required: true
    }
  ];

  const fieldsToRender = defaultFields;

  return (
    <ThemeProvider theme={theme}>
      <Container maxWidth="sm" sx={{ py: { xs: 8, md: 12 } }}>
        <Paper
          elevation={3}
          sx={{
            p: 5,
            borderRadius: 2,
            boxShadow: 4,
            transition: 'box-shadow 0.3s ease',
            '&:hover': {
              boxShadow: 6,
            }
          }}
        >
          <Typography variant="h5" component="h1" gutterBottom align="center" sx={{ color: theme.palette.secondary.main }}>
            {registerForm?.title || "用户注册"}
          </Typography>

          <Typography variant="body2" color="text.secondary" align="center" sx={{ mb: 3 }}>
            {registerForm?.description || "创建账户，获取更多专属服务和资源"}
          </Typography>

          {/* 服务器错误提示 */}
          {serverError && (
            <Alert severity="error" sx={{ mb: 3 }}>
              {serverError}
            </Alert>
          )}

          <Box component="form" noValidate>
            {fieldsToRender.map(field => renderFormField(field))}

            <Button
              fullWidth
              variant="contained"
              sx={{
                mt: 4,
                mb: 2,
                py: 1.2,
                borderRadius: 2,
                textTransform: 'none',
                fontSize: 16,
                backgroundColor: theme.palette.primary.main,
                '&:hover': {
                  backgroundColor: theme.palette.primary.dark,
                },
                transition: 'all 0.3s ease',
              }}
              onClick={handleRegister}
              disabled={isLoading}
            >
              {isLoading ? (
                <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  注册中...
                </Box>
              ) : (registerForm?.submitLabel || "注册")}
            </Button>

            <Box sx={{ textAlign: 'center', mt: 2 }}>
              <Typography variant="body2">
                已有账号？{' '}
                <Button
                  variant="text"
                  onClick={() => router.push('/login')}
                  sx={{
                    p: 0,
                    minWidth: 'auto',
                    verticalAlign: 'baseline',
                    color: theme.palette.primary.main,
                    '&:hover': {
                      backgroundColor: 'transparent',
                      textDecoration: 'underline'
                    }
                  }}
                >
                  立即登录
                </Button>
              </Typography>
            </Box>
          </Box>
        </Paper>
      </Container>
    </ThemeProvider>
  );
};

export default function Register() {

  const [config, setConfig] = useState(null);
  useEffect(() => {
    // 加载配置文件
    const init = async () => {
      // 在这里使用await
      await initializeApi();
      }
    init();
    fetch('/config/site-config.json')
      .then(res => res.json())
      .then(data => setConfig(data))
      .catch(err => console.error('Failed to load config:', err));
  }, []);

  if (!config) return <div>Loading...</div>;

  return (
    <Layout config={config}>
      <Head>
        <title>注册 - {config.site?.name}</title>
      </Head>

      <RegisterForm config={config} />
    </Layout>
  );
}
