import Head from 'next/head';
import { Layout } from '../components/AllComponents';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import {
  Typography, Button, Container, Grid,
  Box, Paper, TextField,
  IconButton, Link as MuiLink,
  List, ListItem, ListItemIcon
} from '@mui/material';
import {
  Mail, GitHub, Chat, Phone, LocationOn, Business, Send
} from '@mui/icons-material';

export const ContactSection = ({ config }) => {
  const { contact, site } = config;
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    company: '',
    message: ''
  });
  const [submitted, setSubmitted] = useState(false);
  const [isVisible, setIsVisible] = useState(false);
  const router = useRouter();

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            setIsVisible(true);
            observer.disconnect();
          }
        });
      },
      { threshold: 0.1 }
    );

    const section = document.getElementById('contact-section');
    if (section) observer.observe(section);

    return () => observer.disconnect();
  }, []);

  const theme = {
    palette: {
      primary: {
        main: config.theme?.primaryColor || '#165DFF',
      },
      secondary: {
        main: config.theme?.secondaryColor || '#0A2463',
      },
      background: {
        default: config.theme?.backgroundColor || '#F5F7FA',
        paper: config.theme?.surfaceColor || '#FFFFFF',
      },
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      console.log('提交联系表单:', formData);
      setSubmitted(true);
      setTimeout(() => {
        setSubmitted(false);
        setFormData({ name: '', email: '', phone: '', company: '', message: '' });
      }, 3000);
    } catch (error) {
      console.error('提交失败:', error);
    }
  };

  if (submitted) {
    return (
      <Box sx={{ py: { xs: 10, md: 16 }, backgroundColor: theme.palette.background.default }}>
        <Container maxWidth="md" sx={{ display: 'flex', justifyContent: 'center' }}>
          <Paper
            elevation={3}
            sx={{
              p: 6,
              textAlign: 'center',
              borderRadius: 3,
              backgroundColor: theme.palette.background.paper,
              maxWidth: 500,
              width: '100%',
              transform: 'scale(0.95)',
              opacity: 0,
              animation: 'formSuccess 0.5s forwards 0.1s',
              '@keyframes formSuccess': {
                '100%': {
                  transform: 'scale(1)',
                  opacity: 1,
                }
              }
            }}
          >
            <Box sx={{
              width: 80,
              height: 80,
              backgroundColor: 'rgba(76, 175, 80, 0.1)',
              borderRadius: '50%',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              margin: '0 auto 24px',
            }}>
              <svg width="40" height="40" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M9 16.17L4.83 12L3.41 13.41L9 19L21 7L19.59 5.59L9 16.17Z" fill="#4CAF50"/>
              </svg>
            </Box>
            <Typography variant="h5" sx={{ mb: 2, color: theme.palette.secondary.main }}>提交成功！</Typography>
            <Typography variant="body1" sx={{ color: 'text.secondary' }}>
              感谢您的留言，我们会尽快与您联系。
            </Typography>
          </Paper>
        </Container>
      </Box>
    );
  }

  return (
    <Box
      id="contact-section"
      sx={{
        py: { xs: 10, md: 16 },
        background: 'linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%)',
        position: 'relative',
        overflow: 'hidden',
        display: 'flex',
        alignItems: 'center',
        minHeight: '100vh'
      }}
    >
      {/* 背景装饰 */}
      <Box sx={{
        position: 'absolute',
        top: -100,
        right: -100,
        width: 300,
        height: 300,
        borderRadius: '50%',
        background: 'linear-gradient(45deg, rgba(22, 93, 255, 0.1) 0%, rgba(10, 36, 99, 0.05) 100%)',
        zIndex: 0
      }} />
      <Box sx={{
        position: 'absolute',
        bottom: -50,
        left: -50,
        width: 200,
        height: 200,
        borderRadius: '50%',
        background: 'linear-gradient(45deg, rgba(22, 93, 255, 0.1) 0%, rgba(10, 36, 99, 0.05) 100%)',
        zIndex: 0
      }} />

      <Container maxWidth="lg" sx={{
        position: 'relative',
        zIndex: 1,
      }}>
        {/* 标题部分 */}
        <Box sx={{ textAlign: 'center', mb: 8 }}>
          <Typography
            variant="h3"
            component="h1"
            gutterBottom
            sx={{
              fontWeight: 700,
              color: theme.palette.secondary.main,
              background: 'linear-gradient(135deg, #0A2463 0%, #165DFF 100%)',
              backgroundClip: 'text',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              opacity: isVisible ? 1 : 0,
              transform: isVisible ? 'translateY(0)' : 'translateY(20px)',
              transition: 'opacity 0.6s ease, transform 0.6s ease',
            }}
          >
            {contact?.title || '联系我们'}
          </Typography>
          <Typography
            variant="h6"
            sx={{
              color: 'text.secondary',
              maxWidth: '600px',
              margin: '0 auto',
              opacity: isVisible ? 1 : 0,
              transform: isVisible ? 'translateY(0)' : 'translateY(20px)',
              transition: 'opacity 0.6s ease 0.2s, transform 0.6s ease 0.2s',
            }}
          >
            有任何问题或需求？我们很乐意为您提供帮助
          </Typography>
        </Box>

        {/* 主要内容 */}
        <Grid
          container
          spacing={4}
          sx={{
            opacity: isVisible ? 1 : 0,
            transform: isVisible ? 'translateY(0)' : 'translateY(30px)',
            transition: 'opacity 0.6s ease 0.4s, transform 0.6s ease 0.4s',
            justifyContent: 'center'
          }}
        >
          {/* 联系信息卡片 */}
          <Grid item xs={12} md={2} lg={4}>
            <Paper
              elevation={0}
              sx={{
                p: 3,
                height: '100%',
                borderRadius: 3,
                background: 'linear-gradient(135deg, rgba(255,255,255,0.9) 0%, rgba(255,255,255,0.7) 100%)',
                backdropFilter: 'blur(10px)',
                border: '1px solid rgba(255,255,255,0.3)',
                position: 'relative',
                overflow: 'hidden',
                '&::before': {
                  content: '""',
                  position: 'absolute',
                  top: 0,
                  left: 0,
                  right: 0,
                  height: 2,
                  background: 'linear-gradient(90deg, #165DFF, #0A2463)',
                }
              }}
            >
              <Typography variant="h5" sx={{ mb: 4, fontWeight: 400, color: theme.palette.secondary.main }}>
                联系信息
              </Typography>

              <List disablePadding>
                {/* 邮箱 - 标签和内容在同一行 */}
                <ListItem disableGutters sx={{ py: 2.5, alignItems: 'center' }}>
                  <ListItemIcon sx={{
                    color: theme.palette.primary.main,
                    minWidth: 44,
                    mt: 0.5
                  }}>
                    <Mail fontSize="medium" />
                  </ListItemIcon>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, flexWrap: 'wrap' }}>
                    <Typography variant="subtitle1" sx={{ fontWeight: 400, whiteSpace: 'nowrap' }}>邮箱：</Typography>
                    <MuiLink
                      href={`mailto:${site?.contactEmail || 'niqinggood@gmail.com'}`}
                      underline="hover"
                      sx={{
                        color: 'text.primary',
                        fontWeight: 500,
                        fontSize: '1rem',
                        '&:hover': {
                          color: theme.palette.primary.main,
                        }
                      }}
                    >
                      {site?.contactEmail || 'niqinggood@gmail.com'}
                    </MuiLink>
                  </Box>
                </ListItem>

                {/* 电话 - 标签和内容在同一行 */}
                <ListItem disableGutters sx={{ py: 2.5, alignItems: 'center' }}>
                  <ListItemIcon sx={{
                    color: theme.palette.primary.main,
                    minWidth: 44,
                    mt: 0.5
                  }}>
                    <Phone fontSize="medium" />
                  </ListItemIcon>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <Typography variant="subtitle1" sx={{ fontWeight: 400, whiteSpace: 'nowrap' }}>电话：</Typography>
                    <Typography sx={{ fontWeight: 500, fontSize: '1rem', color: 'text.primary' }}>
                      {contact?.phone || "400-123-4567"}
                    </Typography>
                  </Box>
                </ListItem>

                {/* 地址 - 标签和内容在同一行 */}
                <ListItem disableGutters sx={{ py: 2.5, alignItems: 'center' }}>
                  <ListItemIcon sx={{
                    color: theme.palette.primary.main,
                    minWidth: 44,
                    mt: 0.5
                  }}>
                    <LocationOn fontSize="medium" />
                  </ListItemIcon>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, flexWrap: 'wrap' }}>
                    <Typography variant="subtitle1" sx={{ fontWeight: 400, whiteSpace: 'nowrap' }}>地址：</Typography>
                    <Typography sx={{ fontWeight: 400, fontSize: '1rem', color: 'text.primary' }}>
                      {contact?.address || "上海市浦东新区科技大道100号"}
                    </Typography>
                  </Box>
                </ListItem>

                {/* 工作时间 - 标签和内容在同一行 */}
                <ListItem disableGutters sx={{ py: 2.5, alignItems: 'center' }}>
                  <ListItemIcon sx={{
                    color: theme.palette.primary.main,
                    minWidth: 44,
                    mt: 0.5
                  }}>
                    <Business fontSize="medium" />
                  </ListItemIcon>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <Typography variant="subtitle1" sx={{ fontWeight: 600, whiteSpace: 'nowrap' }}>工作时间：</Typography>
                    <Typography sx={{ fontWeight: 500, fontSize: '1rem', color: 'text.primary' }}>
                      周一至周五 9:00-18:00
                    </Typography>
                  </Box>
                </ListItem>
              </List>

            </Paper>
          </Grid>

          {/* 联系表单 - 优化文本框高度 */}

        </Grid>
      </Container>
    </Box>
  );
};

export default function Contact() {
  const [config, setConfig] = useState(null);

  useEffect(() => {
    fetch('/config/site-config.json')
      .then(res => res.json())
      .then(data => setConfig(data))
      .catch(err => console.error('Failed to load config:', err));
  }, []);

  if (!config) return <div>Loading...</div>;

  return (
    <Layout config={config}>
      <Head>
        <title>联系我们 - {config.site?.name}</title>
      </Head>

      <Box sx={{
        display: 'flex',
        justifyContent: 'center',
        backgroundColor: 'background.default'
      }}>
        <Box sx={{
          width: '100%',
          maxWidth: '1200px'
        }}>
          <ContactSection config={config} />
        </Box>
      </Box>
    </Layout>
  );
}
