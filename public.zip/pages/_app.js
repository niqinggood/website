import '../styles/globals.css';
import { useEffect, useState } from 'react';
import { QueryClient, QueryClientProvider } from 'react-query';
import axios from 'axios';
import { initializeApi } from '../components/config';
function MyApp({ Component, pageProps }) {
  // 创建React Query客户端
  const [queryClient] = useState(() => new QueryClient());

  const init = async () => {
      // 在这里使用await
      await initializeApi();
      }
  // 全局样式
  useEffect(() => {
    // 导入Google字体
    const link = document.createElement('link');
    link.href = 'https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap';
    link.rel = 'stylesheet';
    document.head.appendChild(link);
    
    return () => {
      document.head.removeChild(link);
    };
  }, []);
  
  return (
    <QueryClientProvider client={queryClient}>
      <Component {...pageProps} />
    </QueryClientProvider>
  );
}

export default MyApp;
