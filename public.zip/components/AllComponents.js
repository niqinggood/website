import { useState, useEffect,useRef  } from 'react';
import {
  AppBar, Toolbar, Typography, Button, Container, Grid,
  Card, CardMedia, CardContent, Box, Paper, TextField,
  Menu, MenuItem, IconButton, Divider, Link as MuiLink,
  List, ListItem, ListItemText, ListItemIcon, Avatar, CssBaseline,
  ThemeProvider, createTheme, useMediaQuery,Chip
} from '@mui/material';
import {
  Menu as MenuIcon, ExpandLess, Mail, GitHub,
  Chat, ChevronRight, Send, ArrowRight,Description,
  Info, Business, Phone, LocationOn,Star,Download ,ChevronLeft,
} from '@mui/icons-material';
import { useRouter } from 'next/router'; // 统一使用Next.js路由
import Link from 'next/link';
import { animateScroll as scroll } from 'react-scroll';

// 通用布局组件 - 优化了导航栏动画和响应式设计
export const Layout = ({ children, config }) => {

  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [anchorEl, setAnchorEl] = useState(null);
  const router = useRouter();

  // 监听滚动事件 - 修复初始状态
  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };

    // 初始检查
    setScrolled(window.scrollY > 50);

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

   const handleMobileMenuOpen = (event) => {
    setAnchorEl(event.currentTarget);
    setMobileMenuOpen(true);
  };

  // 处理移动端菜单关闭
  const handleMobileMenuClose = () => {
    setAnchorEl(null);
    setMobileMenuOpen(false);
  };
    const primaryColor = config.site?.color || '#165DFF';
  const secondaryColor = config.site?.secondaryColor || '#0A2463';
  const textColor = config.site?.textColor || '#333333';
  const highlightColor = config.site?.highlightColor || '#0FC6C2';
  // 创建主题
  const theme = createTheme({
    palette: {
      primary: {
        main: config.theme?.primaryColor || '#165DFF',
        light: config.theme?.primaryLight || '#4080FF',
        dark: config.theme?.primaryDark || '#0E42D2',
        highlightColor:config.site?.highlightColor || '#0FC6C2',
      },
      secondary: {
        main: config.theme?.secondaryColor || '#0A2463',
      },
      background: {
        default: config.theme?.backgroundColor || '#F5F7FA',
        paper: config.theme?.surfaceColor || '#FFFFFF',
      },
      text: {
        primary: config.theme?.textColor || '#1D2129',
        secondary: config.theme?.textSecondary || '#4E5969',
      },
    },
    typography: {
      fontFamily: config.theme?.fontFamily || "'Poppins', 'Inter', sans-serif",
    },
  });

  // 处理导航项点击
  const handleNavItemClick = (path) => {
  handleMobileMenuClose();

  // 检查是否是外部链接（包含http）
  if (path.startsWith('http://') || path.startsWith('https://')) {
    window.open(path, '_blank');
    return;
  }

  const [basePath, anchorId] = path.split('#');

  if (router.pathname !== basePath) {
    router.push(basePath).then(() => {
      if (anchorId) {
        setTimeout(() => {
          const element = document.getElementById(anchorId);
          if (element) element.scrollIntoView({ behavior: 'smooth' });
        }, 100);
      }
    });
  } else if (anchorId) {
    const element = document.getElementById(anchorId);
    if (element) element.scrollIntoView({ behavior: 'smooth' });
  }
};

  // 修复导航栏初始颜色问题
  const navBackground = scrolled ? theme.palette.background.paper : 'rgba(255, 255, 255, 0.95)';
  const navColor = scrolled ? theme.palette.text.primary : theme.palette.text.primary;
  const navBorder = scrolled ? `1px solid rgba(0, 0, 0, 0.05)` : 'none';

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />

      {/* 修复导航栏样式 */}
      <AppBar
        position="fixed"
        elevation={scrolled ? 3 : 0}
        sx={{
          backgroundColor: navBackground,
          color: navColor,
          transition: 'all 0.4s cubic-bezier(0.4, 0, 0.2, 1)',
          backdropFilter: 'blur(12px)',
          borderBottom: navBorder,
          py: scrolled ? 1 : 2,
        }}
      >
        <Toolbar sx={{ px: { xs: 2, md: 4 } }}>
          {/* Logo */}
          <Typography
            variant="h6"
            component="a"
            href="/"
            sx={{
              flexGrow: 1,
              textDecoration: 'none',
              color: 'inherit',
              fontWeight: 700,
              display: 'flex',
              alignItems: 'center',
              gap: 1,
            }}
            onClick={(e) => {
              e.preventDefault();
              router.push('/').then(() => window.scrollTo(0, 0));
            }}
          >
            {config.site?.logo ? (
              <>
                <img
                  src={config.site.logo}
                  alt={config.site.name}
                  style={{ height: '32px', width: 'auto' }}
                />
                <span  style={{
                color:  primaryColor,
                fontSize: '1.25rem',
                background: `linear-gradient(90deg, ${ primaryColor}, ${ highlightColor})`,
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
              }} >{config.site.name}</span>
              </>
            ) : (
              config.site?.name || 'Nova科技'
            )}
          </Typography>

          {/* 桌面导航 */}
          <Box sx={{ display: { xs: 'none', md: 'flex' }, gap: 1 }}>
        {config.navigation?.map((item, index) => (
          <Button
            key={index}
            color="inherit"
            onClick={() => handleNavItemClick(item.path)}
            sx={{
              fontSize: '0.875rem',
              fontWeight: 500,
              borderRadius: 2,
              px: 2.5,
              py: 1.5,
              color: textColor,
              position: 'relative',
              overflow: 'hidden',
              '&:hover': {
                color: primaryColor,
                backgroundColor: 'transparent',
              },
              '&::after': {
                content: '""',
                position: 'absolute',
                bottom: 0,
                left: 0,
                width: '0',
                height: '2px',
                backgroundColor: primaryColor,
                transition: 'width 0.3s ease',
              },
              '&:hover::after': {
                width: '100%',
              },
              '&.active': {
                color: primaryColor,
                '&::after': {
                  width: '100%',
                }
              }
            }}
            className={router.pathname === item.path ? 'active' : ''}
          >
            {item.label}
          </Button>
        ))}
      </Box>

      {/* 移动端菜单按钮 */}
      <IconButton
        color="inherit"
        onClick={handleMobileMenuOpen}
        sx={{
          display: { xs: 'flex', md: 'none' },
          color: primaryColor,
          '&:hover': {
            backgroundColor: 'rgba(22, 93, 255, 0.05)',
          }
        }}
      >
        <MenuIcon sx={{ fontSize: '1.5rem' }} />
      </IconButton>

      {/* 移动端菜单 */}
      <Menu
        anchorEl={anchorEl}
        open={mobileMenuOpen}
        onClose={handleMobileMenuClose}
        sx={{
          display: { xs: 'block', md: 'none' },
          '& .MuiMenu-paper': {
            borderRadius: '8px',
            border: `1px solid rgba(0, 0, 0, 0.08)`,
            boxShadow: '0 4px 20px rgba(0, 0, 0, 0.08)',
            marginTop: '8px',
          }
        }}
      >
        {config.navigation?.map((item, index) => (
          <MenuItem
            key={index}
            onClick={() => handleNavItemClick(item.path)}
            sx={{
              fontSize: '0.875rem',
              py: 1.5,
              color: textColor,
              '&:hover': {
                backgroundColor: 'rgba(22, 93, 255, 0.05)',
                color: primaryColor,
              },
              '&.active': {
                color: primaryColor,
                fontWeight: 500,
              }
            }}
            className={router.pathname === item.path ? 'active' : ''}
          >
            {item.label}
          </MenuItem>
        ))}
      </Menu>
        </Toolbar>
      </AppBar>
      {/* 主要内容 */}
      <Box component="main" sx={{ pt: { xs: 8, md: 10 } }}>
        {children}
      </Box>

      <Footer config={config} theme={theme} />
    </ThemeProvider>
  );
};

// 产品详情组件 - 横向布局
export const ProductDetail = ({ config }) => {
  const router = useRouter();
  const { productid } = router.query;
  const [activeTab, setActiveTab] = useState(0);

  // 产品数据
  const productData = {
    web: {
      id: 1,
      title: "网站与移动端开发",
      description: "为企业提供从设计到部署的全栈开发解决方案，覆盖Web、iOS和Android平台，采用最新技术栈确保高性能和可扩展性。",
      features: ["响应式设计", "跨平台支持", "高性能架构", "SEO优化", "持续集成部署"],
      image: "/img/web-mobile-dev.jpg",
      color: "#1E90FF",
      detailPath: "/services/web"
    },
    mlops: {
      id: 2,
      title: "MLOps平台",
      description: "端到端的机器学习运维平台，实现从数据准备到模型部署的全流程自动化管理，大幅提升AI项目落地效率。",
      features: ["可视化建模", "自动部署", "模型监控", "数据版本控制", "实验追踪"],
      image: "/img/mlops-platform.jpg",
      color: "#0a192f",
      pilot_href: "http://novaexel.com/pilot",
      href: "/img/PILOT_product.pdf",
      detailPath: "/services/mlops"
    },
    ai: {
      id: 3,
      title: "算法定制开发",
      description: "由前腾讯算法专家团队打造的定制化AI解决方案，涵盖计算机视觉、自然语言处理、预测分析等领域。",
      features: ["计算机视觉", "自然语言处理", "预测分析", "推荐系统", "数据挖掘"],
      image: "/img/algo-dev.jpg",
      color: "#4169E1",
      detailPath: "/services/ai"
    }
  };

  const product = productData[productid] || productData.mlops;

  if (!product) {
    return (
      <Box sx={{ py: 10, textAlign: 'center' }}>
        <Typography variant="h4">产品未找到</Typography>
        <Button variant="contained" onClick={() => router.push('/services')} sx={{ mt: 2 }}>
          返回服务页面
        </Button>
      </Box>
    );
  }

  return (
    <Box sx={{ py: 8, backgroundColor: '#f8fafc' }}>
      <Container maxWidth="lg">
        {/* 产品头部 */}
        <Box
          sx={{
            background: `linear-gradient(135deg, ${product.color} 0%, #0a192f 100%)`,
            borderRadius: 4,
            color: 'white',
            p: 6,
            mb: 6,
            textAlign: 'center',
            position: 'relative',
            overflow: 'hidden'
          }}
        >
          <Typography variant="h3" component="h1" sx={{ mb: 2, fontWeight: 700 }}>
            {product.title}
          </Typography>
          <Typography variant="h6" sx={{ opacity: 0.9, maxWidth: '600px', margin: '0 auto' }}>
            {product.description}
          </Typography>
        </Box>

        {/* 产品内容 - 横向布局 */}
        <Grid container spacing={6} alignItems="center">
          <Grid item xs={12} md={6}>
            <Box
              component="img"
              src={product.image}
              alt={product.title}
              sx={{
                width: '100%',
                borderRadius: 3,
                boxShadow: 4,
                transition: 'transform 0.3s ease',
                '&:hover': {
                  transform: 'scale(1.02)'
                }
              }}
            />
          </Grid>

          <Grid item xs={12} md={6}>
            <Typography variant="h4" sx={{ mb: 3, color: product.color }}>
              产品特性
            </Typography>

            <List sx={{ mb: 4 }}>
              {product.features.map((feature, index) => (
                <ListItem key={index} sx={{ px: 0 }}>
                  <ListItemIcon>
                    <Box
                      sx={{
                        width: 8,
                        height: 8,
                        borderRadius: '50%',
                        backgroundColor: product.color
                      }}
                    />
                  </ListItemIcon>
                  <ListItemText primary={feature} />
                </ListItem>
              ))}
            </List>

            <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap' }}>
              {productid === "mlops" && (
                <Button
                  variant="contained"
                  size="large"
                  onClick={() => window.open(product.pilot_href, '_blank')}
                  sx={{
                    backgroundColor: product.color,
                    '&:hover': {
                      backgroundColor: product.color,
                      opacity: 0.9
                    }
                  }}
                >
                  点击使用
                </Button>
              )}

              <Button
                variant="outlined"
                size="large"
                onClick={() => window.open(product.href, '_blank')}
                sx={{
                  borderColor: product.color,
                  color: product.color,
                  '&:hover': {
                    backgroundColor: product.color,
                    color: 'white'
                  }
                }}
              >
                查看文档
              </Button>

              <Button
                variant="text"
                size="large"
                onClick={() => router.push('/contact')}
                sx={{ color: product.color }}
              >
                联系我们
              </Button>
            </Box>
          </Grid>
        </Grid>
      </Container>
    </Box>
  );
};

// 页脚组件 - 增强视觉层次感和交互体验
const Footer = ({ config, theme }) => {
  const { site, navigation } = config;
  const [showScrollTop, setShowScrollTop] = useState(false);
  const router = useRouter();

  // 监听滚动显示/隐藏回到顶部按钮
  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 500);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // 修复导航点击处理函数
  const handleNavClick = (path) => {
    const [basePath, anchorId] = path.split('#');

    if (router.pathname !== basePath) {
      router.push(basePath).then(() => {
        if (anchorId) {
          setTimeout(() => {
            const element = document.getElementById(anchorId);
            if (element) element.scrollIntoView({ behavior: 'smooth' });
          }, 100);
        }
      });
    } else if (anchorId) {
      const element = document.getElementById(anchorId);
      if (element) element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <Box component="footer" sx={{
      backgroundColor: theme.palette.secondary.main,
      py: { xs: 6, md: 10 },
      mt: 10,
      color: '#fff',
      position: 'relative',
    }}>
      <Container maxWidth="lg">
        <Grid container spacing={{ xs: 6, md: 8 }}>
          {/* 公司信息 */}
          <Grid item xs={12} md={3}>
            <Typography variant="h6" sx={{ mb: 3, fontWeight: 700 }}>
              {site?.name || 'Nova科技'}
            </Typography>
            <Typography variant="body2" sx={{ mb: 3, color: 'rgba(255, 255, 255, 0.8)' }}>
              {site?.description || 'MLOps 专家'}
            </Typography>
            <Box sx={{ display: 'flex', gap: 2 }}>
              <IconButton
                size="small"
                component="a"
                href={site?.githubUrl || "https://github.com/niqinggood"}
                target="_blank"
                rel="noopener noreferrer"
                sx={{
                  color: 'rgba(255, 255, 255, 0.8)',
                  '&:hover': {
                    color: '#fff',
                    backgroundColor: 'rgba(255, 255, 255, 0.1)',
                    transform: 'translateY(-3px)',
                  },
                  transition: 'all 0.3s ease',
                }}
              >
                <GitHub fontSize="small" />
              </IconButton>
              <IconButton
                size="small"
                component="a"
                href={site?.wechatUrl || "#"}
                sx={{
                  color: 'rgba(255, 255, 255, 0.8)',
                  '&:hover': {
                    color: '#fff',
                    backgroundColor: 'rgba(255, 255, 255, 0.1)',
                    transform: 'translateY(-3px)',
                  },
                  transition: 'all 0.3s ease',
                }}
              >
                <Chat fontSize="small" />
              </IconButton>
            </Box>
          </Grid>

          {/* 导航链接 */}
          <Grid item xs={12} md={3}>
            <Typography variant="subtitle1" sx={{ mb: 3, fontWeight: 600 }}>
              快速链接
            </Typography>
            <List disablePadding>
              {navigation?.slice(0, 4).map((item, index) => (
                <ListItem key={index} disableGutters sx={{ py: 1 }}>
                  <ListItemText
                    primary={
                      <Box
                        component="a"
                        href="#"
                        onClick={(e) => {
                          e.preventDefault();
                          handleNavClick(item.path);
                        }}
                        sx={{
                          textDecoration: 'none',
                          color: 'rgba(255, 255, 255, 0.8)',
                          transition: 'all 0.2s ease',
                          display: 'flex',
                          alignItems: 'center',
                          gap: 1,
                          cursor: 'pointer',
                          '&:hover': {
                            color: '#fff',
                            '& .nav-icon': {
                              transform: 'translateX(4px)',
                            }
                          }
                        }}
                      >
                        <ChevronRight
                          fontSize="small"
                          className="nav-icon"
                          sx={{ transition: 'transform 0.2s' }}
                        />
                        <span>{item.label}</span>
                      </Box>
                    }
                  />
                </ListItem>
              ))}
            </List>
          </Grid>

          {/* 联系信息 */}
          <Grid item xs={12} md={3}>
            <Typography variant="subtitle1" sx={{ mb: 3, fontWeight: 600 }}>
              联系我们
            </Typography>
            <List disablePadding>
              <ListItem disableGutters sx={{ py: 1 }}>
                <ListItemIcon sx={{ color: 'rgba(255, 255, 255, 0.8)', minWidth: '30px' }}>
                  <Mail fontSize="small" />
                </ListItemIcon>
                <ListItemText
                  primary={
                    <MuiLink
                      href={`mailto:${site?.contactEmail || 'niqinggood@gmail.com'}`}
                      underline="hover"
                      sx={{
                        color: 'rgba(255, 255, 255, 0.8)',
                        '&:hover': {
                          color: '#fff'
                        },
                        transition: 'color 0.2s'
                      }}
                    >
                      {site?.contactEmail || 'niqinggood@gmail.com'}
                    </MuiLink>
                  }
                />
              </ListItem>
              {site?.phone && (
                <ListItem disableGutters sx={{ py: 1 }}>
                  <ListItemIcon sx={{ color: 'rgba(255, 255, 255, 0.8)', minWidth: '30px' }}>
                    <Phone fontSize="small" />
                  </ListItemIcon>
                  <ListItemText
                    primary="电话"
                    secondary={site.phone}
                    secondaryTypographyProps={{ color: 'rgba(255, 255, 255, 0.8)' }}
                  />
                </ListItem>
              )}
              {site?.wechat && (
                <ListItem disableGutters sx={{ py: 1 }}>
                  <ListItemIcon sx={{ color: 'rgba(255, 255, 255, 0.8)', minWidth: '30px' }}>
                    <Chat fontSize="small" />
                  </ListItemIcon>
                  <ListItemText
                    primary="微信"
                    secondary={site.wechat}
                    secondaryTypographyProps={{ color: 'rgba(255, 255, 255, 0.8)' }}
                  />
                </ListItem>
              )}
              {site?.address && (
                <ListItem disableGutters sx={{ py: 1 }}>
                  <ListItemIcon sx={{ color: 'rgba(255, 255, 255, 0.8)', minWidth: '30px' }}>
                    <LocationOn fontSize="small" />
                  </ListItemIcon>
                  <ListItemText
                    primary="地址"
                    secondary={site.address}
                    secondaryTypographyProps={{ color: 'rgba(255, 255, 255, 0.8)' }}
                  />
                </ListItem>
              )}
            </List>
          </Grid>

          {/* 法律信息和微信二维码 */}
          <Grid item xs={12} md={3}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
              <Box>
                <Typography variant="subtitle1" sx={{ mb: 3, fontWeight: 600 }}>
                  法律信息
                </Typography>
                <Typography variant="body2" sx={{ color: 'rgba(255, 255, 255, 0.8)' }}>
                  {site?.copyright || '© 2024 Nova科技. 保留所有权利.'}
                </Typography>
                {site?.icpRecord && (
                  <Typography variant="body2" sx={{ mt: 1, color: 'rgba(255, 255, 255, 0.8)' }}>
                    {site.icpRecord}
                  </Typography>
                )}
              </Box>


            </Box>
          </Grid>
          <Grid item xs={12} md={3}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <Typography variant="subtitle1" sx={{ mb: 3, fontWeight: 600 }}>
                  在线咨询
                </Typography>
              {/* 微信二维码 */}
              {site?.wechatpic && (
                <Box sx={{
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  maxWidth: '150px',
                  ml: 2
                }}>

                  <Box sx={{
                    border: '2px solid rgba(255, 255, 255, 0.2)',
                    borderRadius: 1,
                    p: 1,
                    backgroundColor: 'white',
                    transition: 'all 0.3s ease',
                    '&:hover': {
                      transform: 'scale(1.05)',
                      borderColor: 'rgba(255, 255, 255, 0.5)',
                    }
                  }}>
                    <img
                      src={site.wechatpic}
                      alt="微信二维码"
                      style={{
                        width: '100px',
                        height: '100px',
                        display: 'block'
                      }}
                    />
                  </Box>
                </Box>
              )}
            </Box>
          </Grid>
        </Grid>

        {/* 回到顶部按钮 */}
        <IconButton
          onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          sx={{
            position: 'fixed',
            bottom: 20,
            right: 20,
            backgroundColor: theme.palette.primary.main,
            color: 'white',
            '&:hover': {
              backgroundColor: theme.palette.primary.dark,
              transform: 'translateY(-5px)',
            },
            boxShadow: 3,
            p: 1.5,
            borderRadius: '50%',
            transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
            opacity: showScrollTop ? 1 : 0,
            visibility: showScrollTop ? 'visible' : 'hidden',
            zIndex: 1000,
          }}
          aria-label="回到顶部"
        >
          <ExpandLess />
        </IconButton>
      </Container>
    </Box>
  );
};

const handleServiceClick = (service) => {
  console.info("service:",service)
  if (service.url) {
    // 验证URL格式
    try {
      const url = new URL(service.url, window.location.origin);
      if (url.origin === window.location.origin) {
        // 同源，使用路由跳转
        router.push(url.pathname + url.search + url.hash);
      } else {
        // 跨域，新窗口打开
        window.open(service.url, '_blank', 'noopener,noreferrer');
      }
    } catch {
      // 相对路径，使用路由跳转
      router.push(service.url);
    }
    return;
  }
   // 默认映射逻辑
  const serviceMap = {
    '网站与移动端开发': '/services/web',
    'MLOps 平台': '/services/mlops',
    '算法项目定制开发': '/services/ai'
  };

  const targetUrl = serviceMap[service.title];
  if (targetUrl) {
    router.push(targetUrl);
  }
};

export const HorizontalServicesSection = ({ config }) => {
  const { services } = config;
  const scrollContainerRef = useRef(null);
  const [showLeftArrow, setShowLeftArrow] = useState(false);
  const [showRightArrow, setShowRightArrow] = useState(true);
  const router = useRouter();

  const checkScrollButtons = () => {
    if (scrollContainerRef.current) {
      const { scrollLeft, scrollWidth, clientWidth } = scrollContainerRef.current;
      setShowLeftArrow(scrollLeft > 0);
      setShowRightArrow(scrollLeft < scrollWidth - clientWidth - 10);
    }
  };

  const scrollLeft = () => {
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollBy({ left: -320, behavior: 'smooth' });
    }
  };

  const scrollRight = () => {
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollBy({ left: 320, behavior: 'smooth' });
    }
  };

  useEffect(() => {
    checkScrollButtons();
    const container = scrollContainerRef.current;
    if (container) {
      container.addEventListener('scroll', checkScrollButtons);
      return () => container.removeEventListener('scroll', checkScrollButtons);
    }
  }, []);

  const handleServiceClick = (service) => {
    if (service.url) {
      if (service.url.startsWith('http')) {
        window.open(service.url, '_blank');
      } else {
        router.push(service.url);
      }
      return;
    }

    const serviceMap = {
      '网站与移动端开发': '/services/web',
      'MLOps 平台': '/services/mlops',
      '算法项目定制开发': '/services/ai'
    };

    const targetUrl = serviceMap[service.title];
    if (targetUrl) {
      router.push(targetUrl);
    }
  };

  return (
    <Box sx={{ py: { xs: 8, md: 10 }, backgroundColor: 'background.default', position: 'relative' }}>
      <Container maxWidth="xl"> {/* 使用 xl 让容器更宽 */}
        <Box sx={{ textAlign: 'center', mb: 6 }}>
          <Typography variant="h4" component="h2" gutterBottom sx={{ fontWeight: 700 }}>
            我们的服务
          </Typography>
          <Typography variant="body1" sx={{ color: 'text.secondary', maxWidth: '600px', margin: '0 auto' }}>
            专业的技术服务，助力企业转型与创新发展
          </Typography>
        </Box>

        {/* 横向滑动容器 */}
        <Box sx={{ position: 'relative', px: { xs: 2, md: 4 } }}>
          {/* 左侧滚动按钮 */}
          {showLeftArrow && (
            <IconButton
              onClick={scrollLeft}
              sx={{
                position: 'absolute',
                left: { xs: -10, md: -20 },
                top: '50%',
                transform: 'translateY(-50%)',
                backgroundColor: 'white',
                boxShadow: 3,
                zIndex: 2,
                '&:hover': {
                  backgroundColor: 'grey.100',
                  transform: 'translateY(-50%) scale(1.1)',
                },
                transition: 'all 0.3s ease',
              }}
            >
              <ChevronLeft />
            </IconButton>
          )}

          {/* 服务卡片水平滚动容器 */}
          <Box
            ref={scrollContainerRef}
            sx={{
              display: 'flex',
              gap: 3,
              overflowX: 'auto',
              scrollbarWidth: 'none',
              '&::-webkit-scrollbar': {
                display: 'none'
              },
              py: 3,
              px: 1,
              scrollBehavior: 'smooth',
              // 添加渐变遮罩效果
              maskImage: 'linear-gradient(to right, transparent, black 20px, black calc(100% - 20px), transparent)',
            }}
          >
            {services?.map((service, index) => (
              <ServiceCard
                key={service.id || index}
                service={service}
                onClick={() => handleServiceClick(service)}
                sx={{
                  width: { xs: 280, sm: 320 }, // 响应式宽度
                  height: { xs: 400, sm: 420 }, // 响应式高度
                }}
              />
            ))}
          </Box>

          {/* 右侧滚动按钮 */}
          {showRightArrow && (
            <IconButton
              onClick={scrollRight}
              sx={{
                position: 'absolute',
                right: { xs: -10, md: -20 },
                top: '50%',
                transform: 'translateY(-50%)',
                backgroundColor: 'white',
                boxShadow: 3,
                zIndex: 2,
                '&:hover': {
                  backgroundColor: 'grey.100',
                  transform: 'translateY(-50%) scale(1.1)',
                },
                transition: 'all 0.3s ease',
              }}
            >
              <ChevronRight />
            </IconButton>
          )}
        </Box>

        {/* 滚动指示器 */}
        <Box sx={{ display: 'flex', justifyContent: 'center', mt: 3, gap: 1 }}>
          {services?.map((_, index) => (
            <Box
              key={index}
              sx={{
                width: 8,
                height: 8,
                borderRadius: '50%',
                backgroundColor: 'grey.300',
                transition: 'all 0.3s ease',
                '&:hover': {
                  backgroundColor: 'primary.main',
                  transform: 'scale(1.2)'
                }
              }}
            />
          ))}
        </Box>
      </Container>
    </Box>
  );
};

// 优化的服务卡片组件
const ServiceCard = ({ service, onClick, theme, sx }) => {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <Card
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onClick={onClick}
      sx={{
        width: 320, // 固定宽度
        height: 420, // 固定高度
        display: 'flex',
        flexDirection: 'column',
        cursor: 'pointer',
        transition: 'all 0.4s cubic-bezier(0.4, 0, 0.2, 1)',
        transform: isHovered ? 'translateY(-8px)' : 'translateY(0)',
        boxShadow: isHovered ? 8 : 2,
        borderRadius: 3,
        overflow: 'hidden',
        position: 'relative',
        border: '1px solid rgba(0, 0, 0, 0.05)',
        flexShrink: 0, // 防止卡片被压缩
        '&::before': {
          content: '""',
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          height: 4,
          background: 'linear-gradient(90deg, #165DFF, #0A2463)',
          zIndex: 1,
        },
        ...sx, // 允许外部传入样式覆盖
      }}
    >
      {/* 图片区域 - 固定尺寸 */}
      <Box sx={{ position: 'relative', overflow: 'hidden', height: 180, flexShrink: 0 }}>
        <CardMedia
          component="img"
          height="180"
          image={`/img/${service.image}`}
          alt={service.title}
          sx={{
            width: '100%',
            objectFit: 'cover',
            transition: 'transform 0.6s ease',
            transform: isHovered ? 'scale(1.1)' : 'scale(1)',
          }}
        />
        <Box
          sx={{
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            background: 'linear-gradient(180deg, rgba(0,0,0,0.1) 0%, rgba(0,0,0,0.4) 100%)',
            opacity: isHovered ? 1 : 0,
            transition: 'opacity 0.3s ease',
          }}
        />
      </Box>

      {/* 内容区域 */}
      <CardContent sx={{
        flexGrow: 1,
        p: 3,
        display: 'flex',
        flexDirection: 'column',
        overflow: 'hidden' // 防止内容溢出
      }}>
        <Typography
          variant="h6"
          component="h3"
          sx={{
            fontWeight: 700,
            mb: 2,
            color: 'secondary.main',
            lineHeight: 1.3,
            minHeight: '2.6em', // 固定标题高度
            display: '-webkit-box',
            WebkitLineClamp: 2,
            WebkitBoxOrient: 'vertical',
            overflow: 'hidden',
          }}
        >
          {service.title}
        </Typography>

        <Typography
          variant="body2"
          color="text.secondary"
          sx={{
            lineHeight: 1.6,
            flexGrow: 1,
            display: '-webkit-box',
            WebkitLineClamp: 4,
            WebkitBoxOrient: 'vertical',
            overflow: 'hidden',
            minHeight: '6.4em', // 固定描述高度 (4行 * 1.6行高)
          }}
        >
          {service.desc || service.description}
        </Typography>

        {/* 行动按钮 */}
        <Box
          sx={{
            mt: 3,
            display: 'flex',
            alignItems: 'center',
            color: 'primary.main',
            fontWeight: 600,
            cursor: 'pointer',
            transition: 'all 0.3s ease',
            flexShrink: 0,
            '&:hover': {
              color: 'primary.dark',
            }
          }}
        >
          <span>了解更多</span>
          <ArrowRight sx={{
            ml: 1,
            transform: isHovered ? 'translateX(4px)' : 'translateX(0)',
            transition: 'transform 0.3s ease'
          }} />
        </Box>
      </CardContent>
    </Card>
  );
};

// 下载资源组件 - 支持水平滑动
export const DownloadsSection = ({ config }) => {
  const { products } = config;
  const scrollContainerRef = useRef(null);
  const [showLeftArrow, setShowLeftArrow] = useState(false);
  const [showRightArrow, setShowRightArrow] = useState(true);

  const checkScrollButtons = () => {
    if (scrollContainerRef.current) {
      const { scrollLeft, scrollWidth, clientWidth } = scrollContainerRef.current;
      setShowLeftArrow(scrollLeft > 0);
      setShowRightArrow(scrollLeft < scrollWidth - clientWidth - 10);
    }
  };

  const scrollLeft = () => {
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollBy({ left: -350, behavior: 'smooth' });
    }
  };

  const scrollRight = () => {
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollBy({ left: 350, behavior: 'smooth' });
    }
  };

  useEffect(() => {
    checkScrollButtons();
    const container = scrollContainerRef.current;
    if (container) {
      container.addEventListener('scroll', checkScrollButtons);
      return () => container.removeEventListener('scroll', checkScrollButtons);
    }
  }, []);

  const handleDownload = (product) => {
    console.log('下载产品:', product.name);
    if (product.downloadUrl) {
      const link = document.createElement('a');
      link.href = product.downloadUrl;
      link.download = `${product.name}-${product.version}.zip`;
      link.click();
    }
    alert(`开始下载: ${product.name} ${product.version}`);
  };

  return (
    <Box sx={{ py: { xs: 8, md: 10 }, backgroundColor: 'grey.50' }}>
      <Container maxWidth="xl">
        <Box sx={{ textAlign: 'center', mb: 6 }}>
          <Typography variant="h4" component="h2" gutterBottom sx={{ fontWeight: 700 }}>
            产品详细
          </Typography>
          <Typography variant="body1" sx={{ color: 'text.secondary', maxWidth: '600px', margin: '0 auto' }}>
            获取我们的产品工具包和文档资源
          </Typography>
        </Box>

        {/* 横向滑动容器 */}
        <Box sx={{ position: 'relative', px: { xs: 2, md: 4 } }}>
          {/* 左侧滚动按钮 */}
          {showLeftArrow && (
            <IconButton
              onClick={scrollLeft}
              sx={{
                position: 'absolute',
                left: { xs: -10, md: -20 },
                top: '50%',
                transform: 'translateY(-50%)',
                backgroundColor: 'white',
                boxShadow: 3,
                zIndex: 2,
                '&:hover': {
                  backgroundColor: 'grey.100',
                  transform: 'translateY(-50%) scale(1.1)',
                },
                transition: 'all 0.3s ease',
              }}
            >
              <ChevronLeft />
            </IconButton>
          )}

          {/* 产品卡片水平滚动容器 */}
          <Box
            ref={scrollContainerRef}
            sx={{
              display: 'flex',
              gap: 3,
              overflowX: 'auto',
              scrollbarWidth: 'none',
              '&::-webkit-scrollbar': {
                display: 'none'
              },
              py: 3,
              px: 1,
              scrollBehavior: 'smooth',
              maskImage: 'linear-gradient(to right, transparent, black 20px, black calc(100% - 20px), transparent)',
            }}
          >
            {products?.map((product) => (
              <DownloadCard
                key={product.id}
                product={product}
                onDownload={handleDownload}
                sx={{
                  width: 340, // 固定宽度
                  minWidth: 340, // 防止压缩
                  flexShrink: 0, // 禁止收缩
                }}
              />
            ))}
          </Box>

          {/* 右侧滚动按钮 */}
          {showRightArrow && (
            <IconButton
              onClick={scrollRight}
              sx={{
                position: 'absolute',
                right: { xs: -10, md: -20 },
                top: '50%',
                transform: 'translateY(-50%)',
                backgroundColor: 'white',
                boxShadow: 3,
                zIndex: 2,
                '&:hover': {
                  backgroundColor: 'grey.100',
                  transform: 'translateY(-50%) scale(1.1)',
                },
                transition: 'all 0.3s ease',
              }}
            >
              <ChevronRight />
            </IconButton>
          )}
        </Box>

        {/* 滚动指示器 */}
        {products && products.length > 3 && (
          <Box sx={{ display: 'flex', justifyContent: 'center', mt: 3, gap: 1 }}>
            {products.map((_, index) => (
              <Box
                key={index}
                sx={{
                  width: 6,
                  height: 6,
                  borderRadius: '50%',
                  backgroundColor: 'grey.300',
                  transition: 'all 0.3s ease',
                  '&:hover': {
                    backgroundColor: 'primary.main',
                    transform: 'scale(1.2)'
                  }
                }}
              />
            ))}
          </Box>
        )}
      </Container>
    </Box>
  );
};

// 下载卡片组件 - 优化固定尺寸
const DownloadCard = ({ product, onDownload, sx }) => {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <Paper
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      sx={{
        p: 4,
        height: 480, // 固定高度
        display: 'flex',
        flexDirection: 'column',
        transition: 'all 0.3s ease',
        transform: isHovered ? 'translateY(-4px)' : 'translateY(0)',
        boxShadow: isHovered ? 4 : 1,
        borderRadius: 3,
        border: '1px solid',
        borderColor: 'divider',
        position: 'relative',
        overflow: 'hidden',
        ...sx, // 允许外部传入样式
        '&::before': {
          content: '""',
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          height: 4,
          background: 'linear-gradient(90deg, #165DFF, #0A2463)',
        },
      }}
    >
      {/* 产品头部 */}
      <Box sx={{ display: 'flex', alignItems: 'flex-start', mb: 3 }}>
        <Box
          sx={{
            width: 60,
            height: 60,
            backgroundColor: 'primary.main',
            borderRadius: 2,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            mr: 3,
            flexShrink: 0,
          }}
        >
          <Description sx={{ color: 'white', fontSize: 32 }} />
        </Box>

        <Box sx={{ flexGrow: 1, minWidth: 0 }}> {/* 防止文字溢出 */}
          <Typography
            variant="h6"
            component="h3"
            sx={{
              fontWeight: 700,
              mb: 1,
              overflow: 'hidden',
              textOverflow: 'ellipsis',
              whiteSpace: 'nowrap'
            }}
          >
            {product.name}
          </Typography>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, flexWrap: 'wrap' }}>
            <Chip
              label={`v${product.version}`}
              size="small"
              color="primary"
              variant="outlined"
            />
            <Typography variant="caption" color="text.secondary">
              发布于 {product.releaseDate}
            </Typography>
          </Box>
        </Box>
      </Box>

      {/* 产品描述 */}
      <Typography
        variant="body2"
        color="text.secondary"
        sx={{
          mb: 3,
          lineHeight: 1.6,
          display: '-webkit-box',
          WebkitLineClamp: 3,
          WebkitBoxOrient: 'vertical',
          overflow: 'hidden',
          flexShrink: 0
        }}
      >
        {product.description}
      </Typography>

      {/* 特性列表 */}
      <Box sx={{ mb: 3, flexGrow: 1 }}>
        <Typography variant="subtitle2" sx={{ fontWeight: 600, mb: 2 }}>
          主要特性:
        </Typography>
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
          {product.features?.slice(0, 4).map((feature, index) => ( // 限制显示数量
            <Box key={index} sx={{ display: 'flex', alignItems: 'flex-start', gap: 1 }}>
              <Star sx={{ fontSize: 16, color: 'primary.main', mt: 0.25, flexShrink: 0 }} />
              <Typography
                variant="body2"
                color="text.secondary"
                sx={{
                  lineHeight: 1.4,
                  display: '-webkit-box',
                  WebkitLineClamp: 2,
                  WebkitBoxOrient: 'vertical',
                  overflow: 'hidden'
                }}
              >
                {feature}
              </Typography>
            </Box>
          ))}
          {product.features && product.features.length > 4 && (
            <Typography variant="caption" color="text.secondary" sx={{ mt: 1 }}>
              还有 {product.features.length - 4} 个特性...
            </Typography>
          )}
        </Box>
      </Box>

      {/* 价格信息 */}
      {product.price && (
        <Box sx={{ mb: 2, flexShrink: 0 }}>
          <Typography variant="subtitle1" sx={{ fontWeight: 700, color: 'primary.main' }}>
            {product.price}
          </Typography>
        </Box>
      )}

      {/* 操作按钮 */}
      <Box sx={{ display: 'flex', gap: 2, mt: 'auto', flexWrap: 'wrap', flexShrink: 0 }}>
        <Button
          variant="contained"
          startIcon={<Download />}
          onClick={() => onDownload(product)}
          sx={{
            flexGrow: 1,
            py: 1,
            borderRadius: 2,
            textTransform: 'none',
            fontWeight: 600,
            fontSize: '0.875rem'
          }}
        >
          立即下载
        </Button>

        {product.documentationUrl && (
          <Button
            variant="outlined"
            onClick={() => window.open(product.documentationUrl, '_blank')}
            sx={{
              flexGrow: 1,
              py: 1,
              borderRadius: 2,
              textTransform: 'none',
              fontSize: '0.875rem',
              minWidth: 100,
            }}
          >
            查看文档
          </Button>
        )}
      </Box>

      {/* 文件信息 */}
      <Box sx={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        mt: 2,
        pt: 2,
        borderTop: '1px solid',
        borderColor: 'divider',
        flexShrink: 0
      }}>
        <Typography variant="caption" color="text.secondary">
          {product.fileType || 'ZIP 压缩包'}
        </Typography>
        <Typography variant="caption" color="text.secondary">
          {product.fileSize || '最新版本'}
        </Typography>
      </Box>
    </Paper>
  );
};

// 更新后的服务和产品组合组件
export const ServicesAndProductsSection = ({ config }) => {
  return (
    <>
      <HorizontalServicesSection config={config} />
      <DownloadsSection config={config} />
    </>
  );
};

export const Header = ({ config }) => {
  const { header } = config;
  const router = useRouter();

  const handleCtaClick = (path) => {
    const [basePath, anchorId] = path.split('#');

    if (router.pathname !== basePath) {
      router.push(basePath).then(() => {
        if (anchorId) {
          setTimeout(() => {
            const element = document.getElementById(anchorId);
            if (element) element.scrollIntoView({ behavior: 'smooth' });
          }, 100);
        }
      });
    } else if (anchorId) {
      const element = document.getElementById(anchorId);
      if (element) element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <Box
      sx={{
        height: '70vh',
        minHeight: '500px',
        backgroundImage: header?.background ? `url(${header.background})` : 'url(/aiheader.jpg)',
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        textAlign: 'center',
        color: 'white',
        position: 'relative',
      }}
    >
      {/* 简约遮罩 */}
      <Box
        sx={{
          position: 'absolute',
          top: 0,
          left: 0,
          width: '100%',
          height: '100%',
          backgroundColor: 'rgba(0, 0, 0, 0.4)',
        }}
      />

      <Container maxWidth="md" sx={{ position: 'relative', zIndex: 1 }}>
        <Typography
          variant="h3"
          component="h1"
          sx={{
            mb: 3,
            fontWeight: 700,
            fontSize: { xs: '2rem', md: '3rem' },
          }}
        >
          {header?.title || 'Nova科技 - 智能解决方案专家'}
        </Typography>

        <Typography
          variant="h6"
          sx={{
            mb: 5,
            fontSize: { xs: '1rem', md: '1.25rem' },
            maxWidth: '600px',
            margin: '0 auto',
            opacity: 0.9,
          }}
        >
          {header?.subtitle || '引领数字化转型，赋能企业未来'}
        </Typography>

        <Box sx={{ display: 'flex', justifyContent: 'center', gap: 2, flexWrap: 'wrap' }}>
          {header?.ctaButtons?.map((button, index) => (
            <Button
              key={index}
              variant={button.primary ? "contained" : "outlined"}
              color={button.primary ? "primary" : "inherit"}
              size="large"
              sx={{
                minWidth: 140,
                borderRadius: 2,
                textTransform: 'none',
                fontSize: 16,
                fontWeight: 500,
              }}
              onClick={() => handleCtaClick(button.path)}
            >
              {button.label}
            </Button>
          ))}
        </Box>
      </Container>
    </Box>
  );
};


// 服务/产品列表组件 - 支持点击跳转
export const ServicesSection = ({ config }) => {
  const { services } = config;
  const router = useRouter();
  const [isVisible, setIsVisible] = useState(false);

  // 处理服务点击
  const handleServiceClick = (service) => {
    const serviceMap = {
      '网站与移动端开发': 'web',
      'MLOps 平台': 'mlops',
      '算法项目定制开发': 'ai'
    };

    const serviceId = serviceMap[service.title];
    if (serviceId) {
      router.push(`/services/${serviceId}`);
    }
  };

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            setIsVisible(true);
            observer.disconnect();
          }
        });
      },
      { threshold: 0.1 }
    );

    const section = document.getElementById('services-section');
    if (section) observer.observe(section);

    return () => observer.disconnect();
  }, []);

  const theme = createTheme({
    palette: {
      primary: { main: config.theme?.primaryColor || '#165DFF' },
      secondary: { main: config.theme?.secondaryColor || '#0A2463' },
      background: { default: config.theme?.backgroundColor || '#F5F7FA' },
    }
  });

  return (
    <Box id="services-section" sx={{ py: { xs: 10, md: 12 }, backgroundColor: theme.palette.background.default }}>
      <Container maxWidth="lg">
        <Typography variant="h4" component="h2" align="center" gutterBottom sx={{ mb: 2, fontWeight: 700 }}>
          我们的服务
        </Typography>

        <Typography variant="body1" align="center" sx={{ mb: 8, maxWidth: '700px', margin: '0 auto' }}>
          专业的技术服务，助力企业数字化转型与创新发展
        </Typography>

        <Grid container spacing={4}>
          {services?.map((service, index) => (
            <Grid item xs={12} md={4} key={service.id || index}>
              <ServiceCard
                service={service}
                theme={theme}
                onClick={() => handleServiceClick(service)}
              />
            </Grid>
          ))}
        </Grid>
      </Container>
    </Box>
  );
};
// 论坛组件
export const ForumSection = ({ config }) => {
  const [posts, setPosts] = useState([]);
  const [newPost, setNewPost] = useState({ title: '', content: '', author: '' });
  const [isSubmitting, setIsSubmitting] = useState(false);

  // 模拟初始帖子数据
  useEffect(() => {
    const initialPosts = [
      {
        id: 1,
        title: 'MLOps平台使用体验分享',
        content: '最近使用了Nova的MLOps平台，自动化部署功能非常强大，大大提升了我们的模型迭代效率。',
        author: '张工程师',
        date: '2024-01-15',
        likes: 12,
        comments: 5
      },
      {
        id: 2,
        title: '关于算法定制开发的咨询',
        content: '想了解贵公司在自然语言处理方面的定制开发能力，是否有相关案例可以参考？',
        author: '李经理',
        date: '2024-01-14',
        likes: 8,
        comments: 3
      },
      {
        id: 3,
        title: '网站性能优化建议',
        content: '在使用网站开发服务过程中，发现了一些性能优化的技巧，和大家分享交流。',
        author: '王开发',
        date: '2024-01-13',
        likes: 15,
        comments: 7
      }
    ];
    setPosts(initialPosts);
  }, []);

  const handleSubmitPost = async (e) => {
    e.preventDefault();
    if (!newPost.title || !newPost.content || !newPost.author) {
      alert('请填写所有必填字段');
      return;
    }

    setIsSubmitting(true);

    // 模拟API调用
    setTimeout(() => {
      const post = {
        id: posts.length + 1,
        ...newPost,
        date: new Date().toISOString().split('T')[0],
        likes: 0,
        comments: 0
      };

      setPosts([post, ...posts]);
      setNewPost({ title: '', content: '', author: '' });
      setIsSubmitting(false);
      alert('帖子发布成功！');
    }, 1000);
  };

  const handleLike = (postId) => {
    setPosts(posts.map(post =>
      post.id === postId ? { ...post, likes: post.likes + 1 } : post
    ));
  };

  return (
    <Box sx={{ py: 8, backgroundColor: '#f8fafc' }}>
      <Container maxWidth="lg">
        <Typography variant="h4" component="h1" gutterBottom align="center" sx={{ mb: 2, fontWeight: 700 }}>
          技术论坛
        </Typography>

        <Typography variant="body1" align="center" sx={{ mb: 6, color: 'text.secondary' }}>
          分享经验、交流技术、解决问题
        </Typography>

        <Grid container spacing={6}>
          {/* 发帖表单 */}
          <Grid item xs={12} md={4}>
            <Paper sx={{ p: 4, position: 'sticky', top: 100 }}>
              <Typography variant="h6" gutterBottom>发布新帖子</Typography>

              <Box component="form" onSubmit={handleSubmitPost}>
                <TextField
                  fullWidth
                  label="标题"
                  value={newPost.title}
                  onChange={(e) => setNewPost({...newPost, title: e.target.value})}
                  margin="normal"
                  required
                />

                <TextField
                  fullWidth
                  label="作者"
                  value={newPost.author}
                  onChange={(e) => setNewPost({...newPost, author: e.target.value})}
                  margin="normal"
                  required
                />

                <TextField
                  fullWidth
                  label="内容"
                  value={newPost.content}
                  onChange={(e) => setNewPost({...newPost, content: e.target.value})}
                  margin="normal"
                  multiline
                  rows={4}
                  required
                />

                <Button
                  type="submit"
                  fullWidth
                  variant="contained"
                  disabled={isSubmitting}
                  sx={{ mt: 3 }}
                >
                  {isSubmitting ? '发布中...' : '发布帖子'}
                </Button>
              </Box>
            </Paper>
          </Grid>

          {/* 帖子列表 */}
          <Grid item xs={12} md={8}>
            {posts.map((post) => (
              <Paper key={post.id} sx={{ p: 3, mb: 3 }}>
                <Typography variant="h6" gutterBottom>{post.title}</Typography>

                <Typography variant="body2" color="text.secondary" paragraph>
                  {post.content}
                </Typography>

                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <Typography variant="caption" color="text.secondary">
                    作者: {post.author} | 发布时间: {post.date}
                  </Typography>

                  <Box sx={{ display: 'flex', gap: 2 }}>
                    <Button
                      size="small"
                      startIcon={<span>👍</span>}
                      onClick={() => handleLike(post.id)}
                    >
                      {post.likes}
                    </Button>

                    <Button size="small" startIcon={<span>💬</span>}>
                      {post.comments}
                    </Button>

                    <Button size="small" variant="outlined">
                      查看详情
                    </Button>
                  </Box>
                </Box>
              </Paper>
            ))}
          </Grid>
        </Grid>
      </Container>
    </Box>
  );
};


export const AboutSection = ({ config }) => {
  const { about } = config;
  const [isVisible, setIsVisible] = useState(false);
  const [imageHovered, setImageHovered] = useState(false);
  const router = useRouter();

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            setIsVisible(true);
            observer.disconnect();
          }
        });
      },
      { threshold: 0.1 }
    );

    const section = document.getElementById('about-section');
    if (section) observer.observe(section);

    return () => observer.disconnect();
  }, []);

  const theme = createTheme({
    palette: {
      primary: {
        main: config.theme?.primaryColor || '#165DFF',
      },
      secondary: {
        main: config.theme?.secondaryColor || '#0A2463',
      },
      background: {
        default: config.theme?.backgroundColor || '#F5F7FA',
        paper: config.theme?.surfaceColor || '#FFFFFF',
      },
    }
  });

  return (
    <Box
      id="about-section"
      sx={{
        py: { xs: 10, md: 16 },
        backgroundColor: theme.palette.background.paper,
      }}
    >
      <Container maxWidth="lg">
        <Grid container spacing={{ xs: 8, md: 12 }} alignItems="center">
          <Grid
            item xs={12} md={6}
            sx={{
              order: { xs: 2, md: 1 },
              opacity: isVisible ? 1 : 0,
              transform: isVisible ? 'translateX(0)' : 'translateX(-30px)',
              transition: 'opacity 0.6s ease, transform 0.6s ease 0.3s',
            }}
          >
            {/* 内容部分保持不变 */}
            <Typography
              variant="h4"
              component="h2"
              gutterBottom
              sx={{
                mb: 4,
                fontWeight: 700,
                color: theme.palette.secondary.main
              }}
            >
              {about?.title || '我们团队'}
            </Typography>

            <Typography
              variant="body1"
              paragraph
              sx={{
                lineHeight: 1.8,
                mb: 4,
                color: theme.palette.text.primary
              }}
            >
              {about?.content || '我们是一支源于腾讯的顶尖算法及架构团队，拥有深厚的技术积淀和丰富的行业实践经验。团队成员曾在腾讯主导多个核心项目的算法设计与系统架构开发，具备卓越的技术实力与创新能力。'}
            </Typography>



            {about?.team && about.team.length > 0 && (
              <Box sx={{ mt: 6 }}>
                <Typography variant="h6" sx={{ mb: 3, color: theme.palette.secondary.main }}>核心团队</Typography>
                <Grid container spacing={4}>
                  {about.team.map((member, index) => (
                    <Grid item xs={6} sm={4} key={index}>
                      <Box textAlign="center">
                        <Avatar
                          src={member.image}
                          sx={{
                            width: 80,
                            height: 80,
                            margin: '0 auto 12px',
                            border: `3px solid ${theme.palette.background.default}`,
                            boxShadow: 2,
                            transition: 'transform 0.3s ease',
                            '&:hover': {
                              transform: 'scale(1.05) rotate(3deg)',
                            }
                          }}
                        />
                        <Typography variant="subtitle2" sx={{ fontWeight: 600 }}>{member.name}</Typography>
                        <Typography variant="caption" color="text.secondary">
                          {member.position}
                        </Typography>
                      </Box>
                    </Grid>
                  ))}
                </Grid>
              </Box>
            )}
          </Grid>

          <Grid
            item xs={12} md={6}
            sx={{
              order: { xs: 1, md: 2 },
              opacity: isVisible ? 1 : 0,
              transform: isVisible ? 'translateX(0)' : 'translateX(30px)',
              transition: 'opacity 0.6s ease, transform 0.6s ease',
            }}
          >
            <Box
              sx={{
                borderRadius: 2,
                overflow: 'hidden',
                boxShadow: 4,
                position: 'relative',
                '&::before': {
                  content: '""',
                  position: 'absolute',
                  top: 15,
                  left: 15,
                  right: -15,
                  bottom: -15,
                  border: `2px solid ${theme.palette.primary.main}`,
                  borderRadius: 2,
                  zIndex: -1,
                  transition: 'all 0.3s ease',
                },
                '&:hover::before': {
                  top: 10,
                  left: 10,
                  right: -10,
                  bottom: -10,
                }
              }}
              onMouseEnter={() => setImageHovered(true)}
              onMouseLeave={() => setImageHovered(false)}
            >
              <img
                src={about?.image || '/img/team.jpg'}
                alt="关于我们"
                style={{
                  width: '100%',
                  borderRadius: 2,
                  display: 'block',
                  transition: 'transform 0.5s ease',
                  transform: imageHovered ? 'scale(1.02)' : 'scale(1)',
                }}
              />
            </Box>
          </Grid>
        </Grid>
      </Container>
    </Box>
  );
};


// 登录表单组件 - 优化用户体验和视觉反馈



// 统一导出所有组件
export default {
  Layout,
  Header,
  HorizontalServicesSection,
  DownloadsSection,
  ServicesAndProductsSection,
  AboutSection,
}