// 创建一个专用的 axios 实例，确保配置全局共享
import axios from 'axios';

// 同步设置默认配置，避免异步加载问题
const defaultConfig = {
  apiBaseUrl: 'http://localhost:5000' // 默认API地址
};

// 创建axios实例
const api = axios.create({
  baseURL: defaultConfig.apiBaseUrl,
  headers: {
    'Content-Type': 'application/json',
  },
  withCredentials: true // 启用跨域凭证
});

// 尝试加载配置文件（异步，但不阻塞实例创建）
const loadConfig = async () => {
  try {
    const response = await fetch('/config.json');
    if (response.ok) {
      const config = await response.json();
      if (config.apiBaseUrl) {
        api.defaults.baseURL = config.apiBaseUrl;
        console.log('API base URL updated to:', config.apiBaseUrl);
      }
    }
  } catch (error) {
    console.warn('Using default API configuration:', error.message);
  }
};

// 加载配置但不等待其完成
loadConfig();

// 请求拦截器：自动添加 token
api.interceptors.request.use(
  (config) => {
    if (typeof window !== 'undefined') {
      const token = localStorage.getItem('token');
      // 调试：检查token是否存在
      console.log('Request interceptor - Token exists:', !!token);

      if (token) {
        config.headers.Authorization = `Bearer ${token}`;
      } else {
        // 如果没有token，移除Authorization头
        delete config.headers.Authorization;
      }
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// 响应拦截器：处理 token 过期等问题
api.interceptors.response.use(
  (response) => response,
  (error) => {
    // 401 未授权，清除 token 并跳转到登录页
    if (error.response?.status === 401) {
      if (typeof window !== 'undefined') {
        console.log('Received 401 - logging out');
        localStorage.removeItem('token');
        localStorage.removeItem('user');

        // 保存当前地址，登录后可跳转回来
        const currentPath = window.location.pathname;
        if (!currentPath.includes('/login')) {
          window.location.href = `/login?returnUrl=${currentPath}`;
        }
      }
    }
    return Promise.reject(error);
  }
);

export default api;
