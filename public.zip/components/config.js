// src/config.js
import axios from 'axios';
export const loadConfig = async () => {
  try {
    const response = await fetch('/config.json');
    if (!response.ok) throw new Error('Config not found');
    const config = await response.json();
    return config;
  } catch (error) {
    console.warn('Using default configuration:', error.message);
    return {
      apiPilotBaseUrl: 'http://localhost:5000'
    };
  }
};

// 初始化axios配置
export const initializeApi = async () => {
  const config = await loadConfig();
  axios.defaults.baseURL = config.apiPilotBaseUrl;
  console.log('API base URL set to:', axios.defaults.baseURL);
  return config;
};