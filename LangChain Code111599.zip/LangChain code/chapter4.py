--------------------------------------------------------------------------------------------------------------


import openai
def generate_nlp_concept():
    prompt = "请简要解释自然语言处理（NLP）的基础概念，包括主要技术和应用领域。"
    response = openai.Completion.create(
        engine="text-davinci-003",
        prompt=prompt,
        max_tokens=100,
        temperature=0.5
    )
    return response.choices[0].text.strip()

# 调用生成函数并打印结果
generated_text = generate_nlp_concept()
print("生成的文本:", generated_text)


--------------------------------------------------------------------------------------------------------------


from langchain.prompts import PromptTemplate

# 定义模板：描述主题的应用
template = PromptTemplate(template="请简要描述{topic}的应用。", input_variables=["topic"])

# 使用模板生成提示词
prompt_1 = template.format(topic="机器学习")
prompt_2 = template.format(topic="自然语言处理")

print("提示词1:", prompt_1)
print("提示词2:", prompt_2)


# 定义多变量模板
template = PromptTemplate(
    template="请评价{product}的优缺点，包括{aspect1}和{aspect2}。",
    input_variables=["product", "aspect1", "aspect2"]
)

# 使用模板生成提示词
prompt_1 = template.format(product="智能手机", aspect1="电池续航", aspect2="拍照质量")
prompt_2 = template.format(product="笔记本电脑", aspect1="处理速度", aspect2="便携性")

print("提示词1:", prompt_1)
print("提示词2:", prompt_2)


--------------------------------------------------------------------------------------------------------------


template = PromptTemplate(
    template="请用简洁的语言简述{topic}的基本概念和应用场景。",
    input_variables=["topic"]
)

prompt = template.format(topic="区块链")
print("生成的提示词:", prompt)


# 技术主题列表
topics = ["机器学习", "深度学习", "自然语言处理", "区块链"]

# 定义模板
template = PromptTemplate(template="请简要描述{topic}的应用。", input_variables=["topic"])

# 批量生成提示词并生成内容
for topic in topics:
    prompt = template.format(topic=topic)
    response = openai.Completion.create(
        engine="text-davinci-003",
        prompt=prompt,
        max_tokens=50,
        temperature=0.5
    )
    print(f"{topic}的生成结果:", response.choices[0].text.strip())


--------------------------------------------------------------------------------------------------------------


def generate_adaptive_prompt(user_input):
    # 基于用户输入的自适应Prompt生成
    prompt = f"请简要描述{user_input}的主要应用。"
    return prompt

# 示例输入
user_input = "深度学习"
prompt = generate_adaptive_prompt(user_input)
print("生成的自适应Prompt:", prompt)



import openai

def generate_adaptive_prompt(user_input):
    # 生成自适应Prompt
    prompt = f"请简要描述{user_input}的主要应用。"
    return prompt

def generate_response(user_input):
    # 调用自适应Prompt生成
    prompt = generate_adaptive_prompt(user_input)
    
    # 使用OpenAI API生成响应内容
    response = openai.Completion.create(
        engine="text-davinci-003",
        prompt=prompt,
        max_tokens=50,
        temperature=0.5
    )
    return response.choices[0].text.strip()

# 示例用户输入
user_input = "自然语言处理"
generated_text = generate_response(user_input)
print("生成的文本:", generated_text)


def generate_task_prompt(user_input, task_type):
    # 根据任务类型生成不同的自适应Prompt
    if task_type == "应用":
        prompt = f"请简要描述{user_input}的主要应用。"
    elif task_type == "优缺点":
        prompt = f"请分析{user_input}的主要优缺点。"
    elif task_type == "未来发展":
        prompt = f"请预测{user_input}在未来的主要发展方向。"
    else:
        prompt = f"请简要描述{user_input}。"
    return prompt

# 测试不同任务类型的Prompt生成
user_input = "区块链技术"
prompt_application = generate_task_prompt(user_input, "应用")
prompt_advantages = generate_task_prompt(user_input, "优缺点")
prompt_future = generate_task_prompt(user_input, "未来发展")

print("应用Prompt:", prompt_application)
print("优缺点Prompt:", prompt_advantages)
print("未来发展Prompt:", prompt_future)


# 保存对话上下文
conversation_history = []

def generate_conversation_prompt(user_input):
    # 将历史对话信息融入Prompt中
    conversation_history.append({"role": "user", "content": user_input})
    prompt = "以下是对话历史：\n"
    for i, turn in enumerate(conversation_history):
        prompt += f"{turn['role']}: {turn['content']}\n"
    prompt += "助手: "
    return prompt

def generate_conversation_response(user_input):
    prompt = generate_conversation_prompt(user_input)
    response = openai.Completion.create(
        engine="text-davinci-003",
        prompt=prompt,
        max_tokens=50,
        temperature=0.5
    )
    assistant_response = response.choices[0].text.strip()
    conversation_history.append({"role": "assistant", "content": assistant_response})
    return assistant_response

# 示例交互
user_input_1 = "什么是机器学习？"
response_1 = generate_conversation_response(user_input_1)
print("助手:", response_1)

user_input_2 = "它的应用领域有哪些？"
response_2 = generate_conversation_response(user_input_2)
print("助手:", response_2)


--------------------------------------------------------------------------------------------------------------


def generate_dynamic_prompt(topic, aspect):
    # 动态生成提示词
    prompt = f"请简要描述{topic}的{aspect}。"
    return prompt

# 测试不同的输入条件
print(generate_dynamic_prompt("机器学习", "应用"))
print(generate_dynamic_prompt("区块链", "优缺点"))



def generate_conditional_prompt(topic, aspect, detail_level="简要"):
    # 动态生成的Prompt内容根据条件调整
    if detail_level == "简要":
        prompt = f"请简要描述{topic}的{aspect}。"
    elif detail_level == "详细":
        prompt = f"请详细说明{topic}的{aspect}，包括关键细节和示例。"
    else:
        prompt = f"请描述{topic}的{aspect}。"
    return prompt

# 示例：生成不同细节程度的Prompt
print(generate_conditional_prompt("深度学习", "应用", detail_level="简要"))
print(generate_conditional_prompt("深度学习", "应用", detail_level="详细"))



import openai

def generate_conditional_prompt(topic, aspect, detail_level="简要"):
    # 动态生成Prompt
    if detail_level == "简要":
        prompt = f"请简要描述{topic}的{aspect}。"
    elif detail_level == "详细":
        prompt = f"请详细说明{topic}的{aspect}，包括关键细节和示例。"
    else:
        prompt = f"请描述{topic}的{aspect}。"
    return prompt

def generate_response(topic, aspect, detail_level="简要"):
    # 使用动态Prompt生成响应
    prompt = generate_conditional_prompt(topic, aspect, detail_level)
    
    # 调用OpenAI API
    response = openai.Completion.create(
        engine="text-davinci-003",
        prompt=prompt,
        max_tokens=100,
        temperature=0.5
    )
    return response.choices[0].text.strip()

# 示例生成
print("简要应用描述:", generate_response("机器学习", "应用", detail_level="简要"))
print("详细应用描述:", generate_response("机器学习", "应用", detail_level="详细"))


def generate_complex_prompt(topic, aspect, task_type="描述", detail_level="简要"):
    # 根据不同任务类型和细节要求生成Prompt
    if task_type == "描述":
        if detail_level == "简要":
            prompt = f"请简要描述{topic}的{aspect}。"
        elif detail_level == "详细":
            prompt = f"请详细说明{topic}的{aspect}，包括关键细节。"
    elif task_type == "分析":
        prompt = f"请分析{topic}的{aspect}，特别关注其优缺点。"
    elif task_type == "预测":
        prompt = f"请预测{topic}在未来的{aspect}，并说明可能的影响。"
    else:
        prompt = f"请描述{topic}的{aspect}。"
    return prompt

# 测试不同任务组合生成的Prompt
print(generate_complex_prompt("深度学习", "应用", task_type="描述", detail_level="简要"))
print(generate_complex_prompt("深度学习", "应用", task_type="描述", detail_level="详细"))
print(generate_complex_prompt("深度学习", "前景", task_type="预测"))


--------------------------------------------------------------------------------------------------------------


topics = ["深度学习", "区块链", "量子计算"]

# 生成不同内容需求的提示词
for topic in topics:
    print("\n简要应用描述:")
    print(generate_complex_prompt(topic, "应用", task_type="描述", detail_level="简要"))
    
    print("\n详细应用描述:")
    print(generate_complex_prompt(topic, "应用", task_type="描述", detail_level="详细"))
    
    print("\n未来发展预测:")
    print(generate_complex_prompt(topic, "未来发展", task_type="预测"))


--------------------------------------------------------------------------------------------------------------


请简要描述{topic}的{aspect}。
from langchain.prompts import PromptTemplate

# 定义含有插槽的提示词模板
template = PromptTemplate(template="请简要描述{topic}的{aspect}。", input_variables=["topic", "aspect"])

# 使用模板填充不同的变量值
prompt_1 = template.format(topic="机器学习", aspect="应用")
prompt_2 = template.format(topic="自然语言处理", aspect="优缺点")

print("提示词1:", prompt_1)
print("提示词2:", prompt_2)


# 定义多插槽模板
template = PromptTemplate(
    template="请描述{product}的{feature}，特别关注其{user_experience}。",
    input_variables=["product", "feature", "user_experience"]
)

# 使用不同的变量值生成Prompt
prompt_1 = template.format(product="智能手机", feature="电池续航", user_experience="用户体验")
prompt_2 = template.format(product="笔记本电脑", feature="屏幕分辨率", user_experience="视觉效果")

print("提示词1:", prompt_1)
print("提示词2:", prompt_2)


import openai
from langchain.prompts import PromptTemplate

# 定义插槽填充模板
template = PromptTemplate(
    template="请简要描述{topic}的{aspect}。",
    input_variables=["topic", "aspect"]
)

def generate_response(topic, aspect):
    # 生成插槽填充的Prompt
    prompt = template.format(topic=topic, aspect=aspect)
    
    # 调用OpenAI API生成内容
    response = openai.Completion.create(
        engine="text-davinci-003",
        prompt=prompt,
        max_tokens=50,
        temperature=0.5
    )
    return response.choices[0].text.strip()

# 测试生成不同内容
print("机器学习应用:", generate_response("机器学习", "应用"))
print("自然语言处理优缺点:", generate_response("自然语言处理", "优缺点"))


def generate_contextual_prompt(topic, aspect=None):
    # 如果未提供aspect，默认设置为“应用”
    if aspect is None:
        aspect = "应用"
    
    prompt = template.format(topic=topic, aspect=aspect)
    return prompt

# 测试上下文驱动的插槽填充
print(generate_contextual_prompt("深度学习"))  # 默认生成应用
print(generate_contextual_prompt("深度学习", "发展前景"))  # 生成指定方面


	questions = [
    {"topic": "机器学习", "aspect": "应用"},
    {"topic": "区块链", "aspect": "优缺点"},
    {"topic": "量子计算", "aspect": "未来发展"}
]

# 生成FAQ问答模板
for question in questions:
    prompt = template.format(topic=question["topic"], aspect=question["aspect"])
    print("FAQ Prompt:", prompt)


--------------------------------------------------------------------------------------------------------------


import openai

def step_1_introduction():
    # 步骤 1：简要介绍机器学习
    prompt = "请简要介绍机器学习的基本概念。"
    response = openai.Completion.create(
        engine="text-davinci-003",
        prompt=prompt,
        max_tokens=50,
        temperature=0.5
    )
    return response.choices[0].text.strip()

def step_2_finance_application():
    # 步骤 2：描述机器学习在金融行业的具体应用
    prompt = "描述机器学习在金融行业的应用，如风险预测和自动化交易。"
    response = openai.Completion.create(
        engine="text-davinci-003",
        prompt=prompt,
        max_tokens=100,
        temperature=0.5
    )
    return response.choices[0].text.strip()

def step_3_analysis():
    # 步骤 3：分析机器学习在金融应用中的优缺点
    prompt = "分析机器学习在金融应用中的优缺点。"
    response = openai.Completion.create(
        engine="text-davinci-003",
        prompt=prompt,
        max_tokens=100,
        temperature=0.5
    )
    return response.choices[0].text.strip()

# 调用每个步骤，逐步生成复杂内容
introduction = step_1_introduction()
print("步骤1 - 简介:", introduction)

application = step_2_finance_application()
print("步骤2 - 应用:", application)

analysis = step_3_analysis()
print("步骤3 - 分析:", analysis)


--------------------------------------------------------------------------------------------------------------


def step_2_finance_application(introduction):
    # 使用步骤1的结果作为步骤2的上下文
    prompt = f"{introduction}\n现在，请描述机器学习在金融行业的应用，如风险预测和自动化交易。"
    response = openai.Completion.create(
        engine="text-davinci-003",
        prompt=prompt,
        max_tokens=100,
        temperature=0.5
    )
    return response.choices[0].text.strip()

introduction = step_1_introduction()
print("步骤1 - 简介:", introduction)

application = step_2_finance_application(introduction)
print("步骤2 - 应用:", application)


--------------------------------------------------------------------------------------------------------------


def step_1_overview():
    prompt = "请简要介绍机器学习的基本概念。"
    response = openai.Completion.create(
        engine="text-davinci-003",
        prompt=prompt,
        max_tokens=50,
        temperature=0.5
    )
    return response.choices[0].text.strip()

def step_2_industry_application(overview):
    prompt = f"{overview}\n接下来，请描述机器学习在金融行业的应用。"
    response = openai.Completion.create(
        engine="text-davinci-003",
        prompt=prompt,
        max_tokens=100,
        temperature=0.5
    )
    return response.choices[0].text.strip()

def step_3_case_study(application):
    prompt = f"{application}\n请提供一个机器学习在金融行业的具体应用案例，例如自动化交易或信用评分。"
    response = openai.Completion.create(
        engine="text-davinci-003",
        prompt=prompt,
        max_tokens=100,
        temperature=0.5
    )
    return response.choices[0].text.strip()

def step_4_conclusion(case_study):
    prompt = f"{case_study}\n最后，总结机器学习在金融行业应用中的优缺点。"
    response = openai.Completion.create(
        engine="text-davinci-003",
        prompt=prompt,
        max_tokens=100,
        temperature=0.5
    )
    return response.choices[0].text.strip()

# 调用任务链中的每个步骤
overview = step_1_overview()
print("步骤1 - 概述:", overview)

application = step_2_industry_application(overview)
print("步骤2 - 行业应用:", application)

case_study = step_3_case_study(application)
print("步骤3 - 案例研究:", case_study)

conclusion = step_4_conclusion(case_study)
print("步骤4 - 总结:", conclusion)


--------------------------------------------------------------------------------------------------------------


def generate_report(include_case_study=True):
    overview = step_1_overview()
    print("步骤1 - 概述:", overview)

    application = step_2_industry_application(overview)
    print("步骤2 - 行业应用:", application)

    if include_case_study:
        case_study = step_3_case_study(application)
        print("步骤3 - 案例研究:", case_study)
    
    conclusion = step_4_conclusion(application)
    print("步骤4 - 总结:", conclusion)

# 生成报告，包含案例研究
generate_report(include_case_study=True)

# 生成简略报告，不包含案例研究
generate_report(include_case_study=False)



# 初始化对话历史
conversation_history = []

def generate_conversation_prompt(user_input):
    # 将用户输入和助手回答逐步加入对话历史
    conversation_history.append({"role": "user", "content": user_input})
    
    # 创建带有上下文的Prompt
    prompt = "以下是用户和助手的对话历史：\n"
    for turn in conversation_history:
        prompt += f"{turn['role']}：{turn['content']}\n"
    prompt += "助手："
    return prompt

# 示例用户输入
user_input_1 = "我想了解机器学习的应用。"
print("Prompt 1:", generate_conversation_prompt(user_input_1))


--------------------------------------------------------------------------------------------------------------


import openai

# 初始化对话历史
conversation_history = []

def generate_conversation_prompt(user_input):
    # 生成带有上下文的Prompt
    conversation_history.append({"role": "user", "content": user_input})
    prompt = "以下是用户和助手的对话历史：\n"
    for turn in conversation_history:
        prompt += f"{turn['role']}：{turn['content']}\n"
    prompt += "助手："
    return prompt

def generate_response(user_input):
    # 使用上下文生成Prompt
    prompt = generate_conversation_prompt(user_input)
    
    # 调用OpenAI API生成响应
    response = openai.Completion.create(
        engine="text-davinci-003",
        prompt=prompt,
        max_tokens=100,
        temperature=0.5
    )
    assistant_response = response.choices[0].text.strip()
    # 将助手的回答加入对话历史
    conversation_history.append({"role": "助手", "content": assistant_response})
    return assistant_response

# 示例交互
user_input_1 = "我想了解机器学习的应用。"
response_1 = generate_response(user_input_1)
print("助手:", response_1)

user_input_2 = "具体在医疗领域有哪些应用？"
response_2 = generate_response(user_input_2)
print("助手:", response_2)


--------------------------------------------------------------------------------------------------------------


MAX_HISTORY_LENGTH = 5  # 设置对话历史的最大轮数

def generate_conversation_prompt(user_input):
    # 将用户输入添加到对话历史中
    conversation_history.append({"role": "user", "content": user_input})
    
    # 如果对话历史超过最大长度，移除最早的内容
    if len(conversation_history) > MAX_HISTORY_LENGTH:
        conversation_history.pop(0)
    
    # 生成带有上下文的Prompt
    prompt = "以下是用户和助手的对话历史：\n"
    for turn in conversation_history:
        prompt += f"{turn['role']}：{turn['content']}\n"
    prompt += "助手："
    return prompt


# 初始化OpenAI API
import openai

conversation_history = []

def generate_conversation_prompt(user_input):
    conversation_history.append({"role": "user", "content": user_input})
    if len(conversation_history) > MAX_HISTORY_LENGTH:
        conversation_history.pop(0)
    
    prompt = "以下是用户和助手的对话历史：\n"
    for turn in conversation_history:
        prompt += f"{turn['role']}：{turn['content']}\n"
    prompt += "助手："
    return prompt

def generate_response(user_input):
    prompt = generate_conversation_prompt(user_input)
    response = openai.Completion.create(
        engine="text-davinci-003",
        prompt=prompt,
        max_tokens=100,
        temperature=0.5
    )
    assistant_response = response.choices[0].text.strip()
    conversation_history.append({"role": "助手", "content": assistant_response})
    return assistant_response

# 测试多轮对话
user_input_1 = "什么是机器学习？"
response_1 = generate_response(user_input_1)
print("助手:", response_1)

user_input_2 = "它在医疗领域有哪些应用？"
response_2 = generate_response(user_input_2)
print("助手:", response_2)

user_input_3 = "这个技术有哪些优势？"
response_3 = generate_response(user_input_3)
print("助手:", response_3)


--------------------------------------------------------------------------------------------------------------


import openai

# 初始化对话历史
conversation_history = []

def generate_conversation_prompt(user_input):
    # 将用户输入和助手回答逐步加入对话历史
    conversation_history.append({"role": "user", "content": user_input})
    
    # 创建带有上下文的Prompt，包含对话历史
    prompt = "以下是用户和助手的对话历史：\n"
    for turn in conversation_history:
        prompt += f"{turn['role']}：{turn['content']}\n"
    prompt += "助手："
    return prompt

def generate_response(user_input):
    prompt = generate_conversation_prompt(user_input)
    # 调用API生成响应
    response = openai.Completion.create(
        engine="text-davinci-003",
        prompt=prompt,
        max_tokens=100,
        temperature=0.5
    )
    assistant_response = response.choices[0].text.strip()
    # 将助手的回答加入对话历史
    conversation_history.append({"role": "助手", "content": assistant_response})
    return assistant_response

# 测试对话交互
user_input_1 = "什么是机器学习？"
response_1 = generate_response(user_input_1)
print("助手:", response_1)

user_input_2 = "它在金融行业有哪些应用？"
response_2 = generate_response(user_input_2)
print("助手:", response_2)

user_input_3 = "这种技术的挑战是什么？"
response_3 = generate_response(user_input_3)
print("助手:", response_3)


--------------------------------------------------------------------------------------------------------------


def generate_conversation_prompt(user_input):
    # 将用户输入和助手回答逐步加入对话历史
    conversation_history.append({"role": "user", "content": user_input})
    
    # 创建带有上下文的Prompt，包含引导性语言
    prompt = "以下是用户和助手的对话历史：\n"
    for turn in conversation_history:
        prompt += f"{turn['role']}：{turn['content']}\n"
    prompt += "助手（例如，如果适用，请详细说明）："
    return prompt


def generate_conversation_prompt(user_input, detail_level="简要"):
    conversation_history.append({"role": "user", "content": user_input})
    
    prompt = "以下是用户和助手的对话历史：\n"
    for turn in conversation_history:
        prompt += f"{turn['role']}：{turn['content']}\n"
    
    # 添加对生成内容细节的控制
    if detail_level == "简要":
        prompt += "助手（请简要回答）："
    elif detail_level == "详细":
        prompt += "助手（请详细说明，并举例）："
    return prompt

# 测试简要和详细生成
user_input_1 = "什么是机器学习？"
print("简要回答:", generate_response(user_input_1))

user_input_2 = "它有哪些优势？"
print("详细回答:", generate_response(user_input_2))


def generate_summary():
    # 生成当前对话的总结
    prompt = "请基于以下对话生成一个总结：\n"
    for turn in conversation_history:
        prompt += f"{turn['role']}：{turn['content']}\n"
    prompt += "总结："
    
    response = openai.Completion.create(
        engine="text-davinci-003",
        prompt=prompt,
        max_tokens=100,
        temperature=0.5
    )
    return response.choices[0].text.strip()

# 测试生成总结
print("对话总结:", generate_summary())


--------------------------------------------------------------------------------------------------------------


import openai

# 层级 1：生成概要
def generate_overview():
    prompt = "请简要介绍机器学习的基本概念。"
    response = openai.Completion.create(
        engine="text-davinci-003",
        prompt=prompt,
        max_tokens=50,
        temperature=0.5
    )
    return response.choices[0].text.strip()

# 层级 2：生成不同领域的应用简述
def generate_field_applications(overview):
    prompt = f"{overview}\n接下来，请简要描述机器学习在金融、医疗和教育等领域的应用。"
    response = openai.Completion.create(
        engine="text-davinci-003",
        prompt=prompt,
        max_tokens=100,
        temperature=0.5
    )
    return response.choices[0].text.strip()

# 层级 3：深入描述应用实例
def generate_detailed_example(application_summary, field):
    prompt = f"{application_summary}\n请详细说明机器学习在{field}领域的具体应用实例。"
    response = openai.Completion.create(
        engine="text-davinci-003",
        prompt=prompt,
        max_tokens=100,
        temperature=0.5
    )
    return response.choices[0].text.strip()

# 调用多级Prompt逐步生成内容
overview = generate_overview()
print("层级 1 - 概要:", overview)

application_summary = generate_field_applications(overview)
print("层级 2 - 应用简述:", application_summary)

detailed_example_finance = generate_detailed_example(application_summary, "金融")
print("层级 3 - 金融领域实例:", detailed_example_finance)


--------------------------------------------------------------------------------------------------------------


def generate_detailed_example(application_summary, field):
    # 使用上一层级结果作为输入生成详细实例
    prompt = f"{application_summary}\n请进一步详细说明机器学习在{field}领域的应用，举例说明。"
    response = openai.Completion.create(
        engine="text-davinci-003",
        prompt=prompt,
        max_tokens=100,
        temperature=0.5
    )
    return response.choices[0].text.strip()

# 测试：详细生成不同领域的实例
detailed_example_medical = generate_detailed_example(application_summary, "医疗")
print("层级 3 - 医疗领域实例:", detailed_example_medical)


def generate_report(include_example=False):
    # 层级 1：生成概要
    overview = generate_overview()
    print("层级 1 - 概要:", overview)

    # 层级 2：生成领域应用
    application_summary = generate_field_applications(overview)
    print("层级 2 - 应用简述:", application_summary)

    # 层级 3：生成具体领域实例（可选）
    if include_example:
        detailed_example = generate_detailed_example(application_summary, "教育")
        print("层级 3 - 教育领域实例:", detailed_example)

# 生成包含详细实例的完整报告
generate_report(include_example=True)

# 生成只包含概要和领域应用的简略报告
generate_report(include_example=False)


def generate_detailed_example(application_summary, field):
    # 在Prompt中加入引导词
    prompt = f"{application_summary}\n请详细说明机器学习在{field}领域的应用，举例说明如何使用该技术。"
    response = openai.Completion.create(
        engine="text-davinci-003",
        prompt=prompt,
        max_tokens=100,
        temperature=0.5
    )
    return response.choices[0].text.strip()

# 测试引导性语言生成的效果
detailed_example_finance = generate_detailed_example(application_summary, "金融")
print("层级 3 - 金融领域实例（带引导）:", detailed_example_finance)


--------------------------------------------------------------------------------------------------------------


# 定义Few-shot示例
few_shot_examples = """
示例1：
问题：机器学习的优势是什么？
回答：机器学习能够处理大量数据，自动识别模式，提高预测的准确性。

示例2：
问题：深度学习的主要应用是什么？
回答：深度学习应用于计算机视觉、自然语言处理和语音识别等领域。
"""

# 用户输入的问题
user_question = "自然语言处理的挑战是什么？"

# 构建包含Few-shot示例的Prompt
prompt = f"{few_shot_examples}\n问题：{user_question}\n回答："
print("生成的Few-shot Prompt:\n", prompt)


import openai

# 定义Few-shot示例
few_shot_examples = """
示例1：
问题：机器学习的优势是什么？
回答：机器学习能够处理大量数据，自动识别模式，提高预测的准确性。

示例2：
问题：深度学习的主要应用是什么？
回答：深度学习应用于计算机视觉、自然语言处理和语音识别等领域。
"""

# 用户输入的问题
user_question = "自然语言处理的挑战是什么？"

# 构建Few-shot Prompt
prompt = f"{few_shot_examples}\n问题：{user_question}\n回答："

# 调用OpenAI API
response = openai.Completion.create(
    engine="text-davinci-003",
    prompt=prompt,
    max_tokens=100,
    temperature=0.5
)

# 输出模型的回答
generated_answer = response.choices[0].text.strip()
print("模型生成的回答:", generated_answer)


# 定义示例库
few_shot_examples_general = """
示例1：
问题：机器学习的优势是什么？
回答：机器学习能够处理大量数据，自动识别模式，提高预测的准确性。

示例2：
问题：深度学习的主要应用是什么？
回答：深度学习应用于计算机视觉、自然语言处理和语音识别等领域。
"""

few_shot_examples_finance = """
示例1：
问题：机器学习在金融行业的应用是什么？
回答：机器学习用于风险管理、客户行为分析和自动化交易等方面。

示例2：
问题：区块链的优势是什么？
回答：区块链技术保证了数据的透明性和安全性。
"""

# 根据领域选择不同的Few-shot示例
def select_examples(domain):
    if domain == "金融":
        return few_shot_examples_finance
    else:
        return few_shot_examples_general

# 用户输入和领域选择
user_question = "区块链的挑战是什么？"
domain = "金融"

# 构建Prompt
selected_examples = select_examples(domain)
prompt = f"{selected_examples}\n问题：{user_question}\n回答："

# 调用API生成内容
response = openai.Completion.create(
    engine="text-davinci-003",
    prompt=prompt,
    max_tokens=100,
    temperature=0.5
)

# 输出模型的回答
generated_answer = response.choices[0].text.strip()
print("模型生成的回答:", generated_answer)


--------------------------------------------------------------------------------------------------------------


# 定义多个示例
few_shot_examples = """
示例1：
问题：机器学习的优势是什么？
回答：机器学习能够处理大量数据，自动识别模式，提高预测的准确性。

示例2：
问题：深度学习的主要应用是什么？
回答：深度学习应用于图像识别、自然语言处理和语音识别等领域。

示例3：
问题：自然语言处理的挑战是什么？
回答：自然语言处理面临语言多样性、语境理解和情感分析的挑战。
"""

# 用户输入的问题
user_question = "区块链的未来发展趋势是什么？"

# 构建Few-shot Prompt
prompt = f"{few_shot_examples}\n问题：{user_question}\n回答："

# 调用API生成内容
response = openai.Completion.create(
    engine="text-davinci-003",
    prompt=prompt,
    max_tokens=100,
    temperature=0.5
)

# 输出模型的回答
generated_answer = response.choices[0].text.strip()
print("模型生成的回答:", generated_answer)

