-------------------------------------------------------------------------------------------------------------


from langchain.llms import OpenAI
from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate

# 定义Prompt模板
prompt_template = PromptTemplate(template="请简要描述机器学习的基本概念。")

# 初始化OpenAI模型
llm = OpenAI(model_name="text-davinci-003", temperature=0.7, max_tokens=100)

# 初始化LLM链
llm_chain = LLMChain(llm=llm, prompt=prompt_template)

# 执行链任务
response = llm_chain.run()
print("生成的回答:", response)


llm = OpenAI(
    model_name="text-davinci-003",
    temperature=0.5,
    max_tokens=150,
    top_p=0.9,
    frequency_penalty=0.5,
    presence_penalty=0.3
)


prompt_template = PromptTemplate(template="请简要描述{topic}的应用。")
prompt_text = prompt_template.format(topic="机器学习")
print("生成的Prompt:", prompt_text)
# 创建带变量的Prompt模板


prompt_template = PromptTemplate(template="请简要描述{topic}的应用。")

# 初始化LLM链
llm_chain = LLMChain(llm=llm, prompt=prompt_template)

# 运行LLM链，传入变量
response = llm_chain.run({"topic": "人工智能"})
print("生成的回答:", response)


response_ai = llm_chain.run({"topic": "人工智能"})
response_ml = llm_chain.run({"topic": "机器学习"})

print("人工智能的应用:", response_ai)
print("机器学习的应用:", response_ml)


# 定义后处理函数
def post_process(response):
    processed_response = response.strip()
    return processed_response

# 执行链任务并处理结果
response = llm_chain.run({"topic": "数据科学"})
final_result = post_process(response)
print("最终处理结果:", final_result)


-------------------------------------------------------------------------------------------------------------


from langchain.prompts import PromptTemplate


# 创建包含变量的Prompt模板
prompt_template = PromptTemplate(template="请简要描述{topic}的主要应用。")

# 使用变量填充生成实际Prompt内容
formatted_prompt = prompt_template.format(topic="机器学习")
print("生成的Prompt内容:", formatted_prompt)


from langchain.llms import OpenAI
from langchain.chains import LLMChain

# 初始化OpenAI模型
llm = OpenAI(model_name="text-davinci-003", temperature=0.7, max_tokens=100)

# 创建Prompt模板
prompt_template = PromptTemplate(template="请简要描述{topic}的主要应用。")

# 在LLM链中嵌入Prompt模板
llm_chain = LLMChain(llm=llm, prompt=prompt_template)

# 执行LLM链任务，并传入具体的变量值
response = llm_chain.run({"topic": "人工智能"})
print("生成的回答:", response)


# 定义预处理函数，用于清理和标准化输入内容
def preprocess_input(user_input):
    # 去除多余空格并转换为小写
    cleaned_input = user_input.strip().lower()
    # 将首字母大写
    cleaned_input = cleaned_input.capitalize()
    return cleaned_input

# 示例输入
raw_input = "    机器学习的应用    "
preprocessed_input = preprocess_input(raw_input)
print("预处理后的输入:", preprocessed_input)


# 定义预处理函数
def preprocess_input(user_input):
    cleaned_input = user_input.strip().lower()
    cleaned_input = cleaned_input.capitalize()
    return cleaned_input

# 初始化LLM链
llm_chain = LLMChain(llm=llm, prompt=prompt_template)

# 获取用户输入
user_input = "    数据科学的应用    "

# 执行预处理
processed_input = preprocess_input(user_input)

# 调用LLM链并生成内容
response = llm_chain.run({"topic": processed_input})
print("生成的回答:", response)
# 动态调整Prompt模板
def select_prompt_template(topic_length):
    if topic_length < 10:
        return PromptTemplate(template="请简要描述{topic}的应用。")
    else:
        return PromptTemplate(template="请详细介绍{topic}在各个领域的应用及其影响。")

# 获取用户输入并处理
user_input = "人工智能和机器学习技术"
processed_input = preprocess_input(user_input)


# 动态选择Prompt模板
prompt_template = select_prompt_template(len(processed_input))

# 使用选择的Prompt模板初始化LLM链
llm_chain = LLMChain(llm=llm, prompt=prompt_template)

# 调用LLM链生成内容
response = llm_chain.run({"topic": processed_input})
print("生成的回答:", response)


# 定义后处理函数
def post_process(response):
    # 去除多余空格并将内容转换为标题形式
    processed_response = response.strip().capitalize()
    return processed_response

# 执行链任务并处理结果
response = llm_chain.run({"topic": "深度学习"})
final_result = post_process(response)
print("最终处理结果:", final_result)


-------------------------------------------------------------------------------------------------------------


from langchain.chains import SequentialChain
from langchain.prompts import PromptTemplate
from langchain.llms import OpenAI

# 定义Prompt模板
prompt_step_1 = PromptTemplate(template="简要介绍机器学习的基本概念。")
prompt_step_2 = PromptTemplate(template="基于以下介绍，描述机器学习的应用领域：{intro}")
prompt_step_3 = PromptTemplate(template="结合应用领域，提供机器学习在金融行业的一个实例：{applications}")

# 初始化模型
llm = OpenAI(model_name="text-davinci-003", temperature=0.5, max_tokens=100)

# 定义每个步骤的链
chain_step_1 = LLMChain(llm=llm, prompt=prompt_step_1)
chain_step_2 = LLMChain(llm=llm, prompt=prompt_step_2)
chain_step_3 = LLMChain(llm=llm, prompt=prompt_step_3)

# 初始化Sequential Chain
sequential_chain = SequentialChain(chains=[chain_step_1, chain_step_2, chain_step_3])


# 定义传递参数的输入字典
input_dict = {
    "intro": "机器学习是一种通过数据训练模型，使计算机能够自动识别模式和预测。",
    "applications": "机器学习在金融、医疗和教育等多个领域有广泛应用。"
}

# 配置并运行序列链
response = sequential_chain.run(input_dict)
print("序列链生成的最终结果:", response)
# 使用run方法传入初始输入并执行序列链
initial_input = {"intro": "机器学习是一种通过数据训练模型的技术。"}
response = sequential_chain.run(initial_input)
print("最终生成的内容:", response)


-------------------------------------------------------------------------------------------------------------


# 定义中间处理函数，格式化内容
def format_step_output(text):
    return text.strip().capitalize()

# 执行序列链并处理每个步骤的输出
intro_text = chain_step_1.run()
formatted_intro = format_step_output(intro_text)

applications_text = chain_step_2.run({"intro": formatted_intro})
formatted_applications = format_step_output(applications_text)

instance_text = chain_step_3.run({"applications": formatted_applications})
formatted_instance = format_step_output(instance_text)

# 查看每个步骤的格式化输出
print("步骤1 - 简介:", formatted_intro)
print("步骤2 - 应用:", formatted_applications)
print("步骤3 - 实例:", formatted_instance)


# 定义条件判断逻辑
def is_detailed_request(input_text):
    return len(input_text) > 15

# 创建一个包含条件判断的序列链
def conditional_sequential_chain(input_text):
    if is_detailed_request(input_text):
        print("执行详细生成步骤")
        response = sequential_chain.run({"intro": input_text})
    else:
        print("执行简略生成步骤")
        response = chain_step_1.run({"intro": input_text})
    return response

# 测试不同长度的输入
response_detailed = conditional_sequential_chain("机器学习的详细应用")
response_brief = conditional_sequential_chain("机器学习")

print("详细生成结果:", response_detailed)
print("简略生成结果:", response_brief)


-------------------------------------------------------------------------------------------------------------


from langchain.llms import OpenAI

# 定义用于概述生成的LLM
llm_summary = OpenAI(model_name="text-davinci-003", temperature=0.5, max_tokens=50)

# 定义用于详细生成的LLM
llm_detail = OpenAI(model_name="text-davinci-003", temperature=0.7, max_tokens=150)


from langchain.chains import LLMChain, SequentialChain
from langchain.prompts import PromptTemplate

# 定义Prompt模板
prompt_summary = PromptTemplate(template="请简要介绍机器学习的定义。")
prompt_detail = PromptTemplate(template="基于机器学习的定义，详细描述其在数据分析中的应用：{summary}")

# 创建LLM链实例
chain_summary = LLMChain(llm=llm_summary, prompt=prompt_summary)
chain_detail = LLMChain(llm=llm_detail, prompt=prompt_detail)

# 创建序列链，连接两个LLM链
sequential_chain = SequentialChain(chains=[chain_summary, chain_detail])


import requests

# 定义一个API调用函数，用于获取实时数据（例如：获取股票信息）
def fetch_data(topic):
    response = requests.get(f"https://api.example.com/data?topic={topic}")
    if response.status_code == 200:
        return response.json().get("data", "")
    else:
        return "无法获取数据"

# 将API调用集成到序列链中
topic = "机器学习在金融中的应用"
api_data = fetch_data(topic)

# 将API数据传递给详细描述的LLM链
response = chain_detail.run({"summary": api_data})
print("API获取的数据及其详细生成结果:", response)


import sqlite3

# 创建数据库连接并查询数据
def query_database(keyword):
    conn = sqlite3.connect("example.db")
    cursor = conn.cursor()
    cursor.execute("SELECT info FROM topics WHERE name = ?", (keyword,))
    result = cursor.fetchone()
    conn.close()
    return result[0] if result else "没有找到相关数据"

# 将数据库查询结果传递给LLM链
keyword = "深度学习"
db_data = query_database(keyword)

# 使用数据库查询结果作为生成内容的输入
response = chain_detail.run({"summary": db_data})
print("数据库查询结果及其生成的详细内容:", response)


from langchain.chains import LLMChain, SequentialChain
from langchain.prompts import PromptTemplate

# 初始化LLM和Prompt模板
llm_summary = OpenAI(model_name="text-davinci-003", temperature=0.5, max_tokens=50)
llm_detail = OpenAI(model_name="text-davinci-003", temperature=0.7, max_tokens=150)

prompt_summary = PromptTemplate(template="请简要介绍{topic}的定义。")
prompt_api = PromptTemplate(template="基于以下内容描述{api_data}在{topic}中的作用。")
prompt_detail = PromptTemplate(template="结合概述和API数据，详细描述{topic}的行业应用：{summary}")

# 创建LLM链
chain_summary = LLMChain(llm=llm_summary, prompt=prompt_summary)
chain_api = LLMChain(llm=llm_summary, prompt=prompt_api)
chain_detail = LLMChain(llm=llm_detail, prompt=prompt_detail)

# 定义一个模拟API数据函数
def fetch_data(topic):
    # 模拟API响应数据
    return f"{topic}的最新应用数据"

# 组合为一个序列链
def multi_step_chain(topic):
    # 生成概述
    summary = chain_summary.run({"topic": topic})
    print("生成的概述:", summary)

    # 获取API数据并生成相关内容
    api_data = fetch_data(topic)
    api_content = chain_api.run({"topic": topic, "api_data": api_data})
    print("基于API数据的生成内容:", api_content)

    # 生成详细描述
    detailed_response = chain_detail.run({"topic": topic, "summary": summary})
    print("最终生成的详细内容:", detailed_response)
    return detailed_response

# 执行多步骤链
topic = "机器学习"
final_output = multi_step_chain(topic)
print("最终结果:", final_output)


-------------------------------------------------------------------------------------------------------------


# 定义条件判断函数，根据输入内容返回不同标识
def determine_route(input_text):
    if "投诉" in input_text:
        return "complaint"
    elif "咨询" in input_text:
        return "inquiry"
    elif "建议" in input_text:
        return "suggestion"
    else:
        return "default"


from langchain.prompts import PromptTemplate
from langchain.llms import OpenAI
from langchain.chains import LLMChain

# 初始化模型
llm = OpenAI(model_name="text-davinci-003", temperature=0.5, max_tokens=100)

# 定义不同路径的Prompt模板
prompt_complaint = PromptTemplate(template="处理客户投诉：请针对以下问题提供解决方案：{issue}")
prompt_inquiry = PromptTemplate(template="处理客户咨询：请回答客户的问题：{question}")
prompt_suggestion = PromptTemplate(template="处理客户建议：请提供关于以下建议的反馈：{suggestion}")
prompt_default = PromptTemplate(template="处理常规问题：请回答用户的问题：{query}")

# 为每个路径创建LLM链
chain_complaint = LLMChain(llm=llm, prompt=prompt_complaint)
chain_inquiry = LLMChain(llm=llm, prompt=prompt_inquiry)
chain_suggestion = LLMChain(llm=llm, prompt=prompt_suggestion)
chain_default = LLMChain(llm=llm, prompt=prompt_default)


from langchain.chains import RouterChain

# 定义路径映射，将判断结果映射到对应的子链
route_map = {
    "complaint": chain_complaint,
    "inquiry": chain_inquiry,
    "suggestion": chain_suggestion,
    "default": chain_default
}

# 创建路由链
router_chain = RouterChain(route_map=route_map, route_func=determine_route)
# 示例输入文本
input_text_complaint = "客户投诉：产品质量有问题，需要立即解决。"
input_text_inquiry = "客户咨询：这个产品的保修期是多久？"
input_text_suggestion = "客户建议：希望增加更多的支付选项。"
input_text_default = "普通查询：如何联系客户服务？"

# 执行路由链任务并输出结果
response_complaint = router_chain.run({"issue": input_text_complaint})
response_inquiry = router_chain.run({"question": input_text_inquiry})
response_suggestion = router_chain.run({"suggestion": input_text_suggestion})
response_default = router_chain.run({"query": input_text_default})

print("投诉处理结果:", response_complaint)
print("咨询处理结果:", response_inquiry)
print("建议处理结果:", response_suggestion)
print("默认处理结果:", response_default)


# 添加更复杂的条件判断
def advanced_determine_route(input_text):
    if "投诉" in input_text and "紧急" in input_text:
        return "urgent_complaint"
    elif "投诉" in input_text:
        return "complaint"
    elif "咨询" in input_text:
        return "inquiry"
    elif "建议" in input_text:
        return "suggestion"
    else:
        return "default"

# 创建新的路由映射，增加紧急投诉路径
prompt_urgent_complaint = PromptTemplate(template="处理紧急投诉：立即处理以下问题：{issue}")
chain_urgent_complaint = LLMChain(llm=llm, prompt=prompt_urgent_complaint)

# 更新路由映射表
advanced_route_map = {
    "urgent_complaint": chain_urgent_complaint,
    "complaint": chain_complaint,
    "inquiry": chain_inquiry,
    "suggestion": chain_suggestion,
    "default": chain_default
}

# 创建增强的路由链
advanced_router_chain = RouterChain(route_map=advanced_route_map, route_func=advanced_determine_route)

# 测试不同的输入
response_urgent_complaint = advanced_router_chain.run({"issue": "客户投诉：紧急！需要立即更换故障产品。"})
print("紧急投诉处理结果:", response_urgent_complaint)


-------------------------------------------------------------------------------------------------------------


from langchain.llms import OpenAI

# 用于简洁回答的模型
llm_brief = OpenAI(model_name="text-davinci-003", temperature=0.3, max_tokens=50)

# 用于详细描述的模型
llm_detailed = OpenAI(model_name="text-davinci-003", temperature=0.7, max_tokens=150)

# 用于创意性内容生成的模型
llm_creative = OpenAI(model_name="text-davinci-003", temperature=0.9, max_tokens=100)
from langchain.prompts import PromptTemplate

# Prompt模板配置
prompt_brief = PromptTemplate(template="简要回答以下问题：{query}")
prompt_detailed = PromptTemplate(template="详细回答以下问题：{query}")
prompt_creative = PromptTemplate(template="创造性地回答以下问题，提供一些独特的见解：{query}")


from langchain.chains import LLMChain

# 创建不同任务路径的子链
chain_brief = LLMChain(llm=llm_brief, prompt=prompt_brief)
chain_detailed = LLMChain(llm=llm_detailed, prompt=prompt_detailed)
chain_creative = LLMChain(llm=llm_creative, prompt=prompt_creative)


# 根据输入内容动态选择路径
def task_route(input_text):
    if "简要" in input_text:
        return "brief"
    elif "详细" in input_text:
        return "detailed"
    elif "创意" in input_text or "独特" in input_text:
        return "creative"
    else:
        return "default"


from langchain.chains import RouterChain

# 路由映射，将任务标识映射到对应的子链
route_map = {
    "brief": chain_brief,
    "detailed": chain_detailed,
    "creative": chain_creative,
    "default": chain_brief  # 默认路径可设置为简要回答
}

# 创建路由链
router_chain = RouterChain(route_map=route_map, route_func=task_route)


# 定义输入内容
input_text_brief = "简要回答：机器学习的定义是什么？"
input_text_detailed = "详细回答：机器学习的应用领域有哪些？"
input_text_creative = "创意回答：机器学习在未来可能带来的影响？"

# 执行路由链并输出结果
response_brief = router_chain.run({"query": input_text_brief})
response_detailed = router_chain.run({"query": input_text_detailed})
response_creative = router_chain.run({"query": input_text_creative})

print("简要回答:", response_brief)
print("详细回答:", response_detailed)
print("创意回答:", response_creative)


-------------------------------------------------------------------------------------------------------------


import requests
# 定义API调用函数
def fetch_additional_data(query):
    response = requests.get(f"https://api.example.com/data?query={query}")
    if response.status_code == 200:
        return response.json().get("data", "")
    else:
        return "无法获取数据"

# 在判断函数中添加API路径选择
def advanced_task_route(input_text):
    if "实时" in input_text:
        return "api"
    elif "简要" in input_text:
        return "brief"
    elif "详细" in input_text:
        return "detailed"
    elif "创意" in input_text:
        return "creative"
    else:
        return "default"

# 路由映射表中添加API路径
route_map_advanced = {
    "api": fetch_additional_data,  # 将API函数作为任务路径
    "brief": chain_brief,
    "detailed": chain_detailed,
    "creative": chain_creative,
    "default": chain_brief
}

# 创建新的路由链
advanced_router_chain = RouterChain(route_map=route_map_advanced, route_func=advanced_task_route)

# 测试带有API调用的任务路径
response_api = advanced_router_chain.run({"query": "实时获取股票市场信息"})
print("实时数据获取结果:", response_api)


-------------------------------------------------------------------------------------------------------------


from langchain.chains import StuffDocumentsChain
from langchain.prompts import PromptTemplate
from langchain.llms import OpenAI

# 定义Prompt模板
prompt_template = PromptTemplate(template="请为以下内容生成简要概述：\n\n{content}")

# 初始化模型
llm = OpenAI(model_name="text-davinci-003", temperature=0.5, max_tokens=150)

# 初始化Stuff链
stuff_chain = StuffDocumentsChain(llm=llm, prompt=prompt_template)

# 合并文档内容
document_content = """
文档片段1：
机器学习是一种人工智能技术，旨在通过算法和统计模型，使计算机能够从数据中学习并进行预测。机器学习被广泛应用于图像识别、语音识别、自然语言处理等领域，推动了现代科技的进步。

文档片段2：
近年来，深度学习成为机器学习的一个重要分支，通过多层神经网络，深度学习在复杂任务上表现出了超越传统算法的性能，尤其在医疗诊断、自动驾驶和金融预测等领域取得了显著进展。

文档片段3：
大数据的增长为机器学习模型提供了丰富的数据源。利用大量的数据，机器学习算法可以更加准确地进行模式识别和趋势预测。然而，数据隐私和安全性问题也随之而来，需要在应用中予以关注。
"""

# 执行Stuff链生成概述
response = stuff_chain.run({"content": document_content})
print("生成的概述:", response)


-------------------------------------------------------------------------------------------------------------


from langchain.chains import RefineDocumentsChain

# 定义Prompt模板
prompt_template_refine = PromptTemplate(template="基于以下内容进行精炼，并添加新的信息：\n\n{current_summary}\n\n新信息：{new_content}")

# 初始化Refine链
refine_chain = RefineDocumentsChain(llm=llm, prompt=prompt_template_refine)

# 定义文档片段列表
document_fragments = [
    "机器学习是一种人工智能技术，旨在通过算法和统计模型，使计算机能够从数据中学习并进行预测。机器学习被广泛应用于图像识别、语音识别、自然语言处理等领域，推动了现代科技的进步。",
    "近年来，深度学习成为机器学习的一个重要分支，通过多层神经网络，深度学习在复杂任务上表现出了超越传统算法的性能，尤其在医疗诊断、自动驾驶和金融预测等领域取得了显著进展。",
    "大数据的增长为机器学习模型提供了丰富的数据源。利用大量的数据，机器学习算法可以更加准确地进行模式识别和趋势预测。然而，数据隐私和安全性问题也随之而来，需要在应用中予以关注。"
]

# 执行Refine链任务
current_summary = ""  # 初始化为空
for fragment in document_fragments:
    current_summary = refine_chain.run({"current_summary": current_summary, "new_content": fragment})

print("逐步精炼生成的内容:", current_summary)


-------------------------------------------------------------------------------------------------------------


from langchain.chains import MapReduceDocumentsChain

# 定义Prompt模板，用于处理每个片段
prompt_template_map = PromptTemplate(template="请总结以下内容的核心观点：\n\n{fragment}")

# 初始化模型
llm = OpenAI(model_name="text-davinci-003", temperature=0.5, max_tokens=100)

# 创建Map-Reduce链
map_reduce_chain = MapReduceDocumentsChain(llm=llm, prompt=prompt_template_map)

# 定义文档片段列表
document_fragments = [
    "人工智能技术的快速发展对社会产生了深远影响。其在自动化、医疗、教育等多个领域的应用，正逐步改变人们的生活方式，尤其在医疗诊断和个性化教育领域，人工智能展现出极大的潜力。",
    "然而，人工智能技术的普及也带来了一些挑战。例如，数据隐私成为一个不可忽视的问题，许多企业和个人都担心自己的数据被滥用。此外，自动化可能导致某些职业的消失，带来就业压力。",
    "在未来，随着技术的进步，人工智能有望在智能交通、智能城市、环境保护等领域发挥更大的作用。政府和企业正在积极探索人工智能的潜力，以期提高效率、减少资源浪费，推动可持续发展。"
]

# 执行Map-Reduce链任务
response = map_reduce_chain.run({"documents": document_fragments})
print("Map-Reduce链生成的最终结果:", response)


-------------------------------------------------------------------------------------------------------------


from langchain.chains import MapRerankDocumentsChain

# 定义Prompt模板，用于生成评分和内容
prompt_template_rerank = PromptTemplate(template="请评价以下内容的相关性，并选择最重要的观点：\n\n{fragment}")

# 创建Map-Rerank链
map_rerank_chain = MapRerankDocumentsChain(llm=llm, prompt=prompt_template_rerank)

# 执行Map-Rerank链任务
response_rerank = map_rerank_chain.run({"documents": document_fragments})
print("Map-Rerank链筛选的最终结果:", response_rerank)

