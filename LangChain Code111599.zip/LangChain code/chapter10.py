-------------------------------------------------------------------------------------------------------------


from langchain.prompts import PromptTemplate

# 定义一个提示模板，确保输入的一致性
template = "请简要描述以下事件的背景：{event}"
prompt = PromptTemplate(template=template, input_variables=["event"])


# 使用模板生成输入
formatted_prompt = prompt.format(event="丝绸之路的起源与影响")
print("标准化输入:", formatted_prompt)
from langchain.output_parsers import ResponseParser

# 定义自定义的输出格式化器
class SimpleResponseParser(ResponseParser):
    def parse(self, response):
        return f"格式化输出: {response.strip()}"

output_parser = SimpleResponseParser()


from langchain.llms import OpenAI
from langchain.chains import LLMChain

# 初始化语言模型
llm = OpenAI(temperature=0)

# 创建任务链，将PromptTemplate和输出格式化器整合
chain = LLMChain(llm=llm, prompt=prompt, output_parser=output_parser)

# 执行任务链
response = chain.run({"event": "中国古代的四大发明"})
print("任务链输出:", response)


-------------------------------------------------------------------------------------------------------------


# 示例代码（伪代码）：连接特征存储保存输出
feature_store.save("中国古代的四大发明", formatted_output)


# 导入必要的模块
from langchain.prompts import PromptTemplate
from langchain.output_parsers import ResponseParser
from langchain.llms import OpenAI
from langchain.chains import LLMChain

# 1. 定义多维输入的PromptTemplate
template = """
请描述以下事件的相关内容：
事件：{event}
地点：{location}
时间：{date}
请依次生成该事件的简述、影响和历史评价。
"""
prompt = PromptTemplate(template=template, input_variables=["event", "location", "date"])

# 2. 自定义输出格式化器：生成多段信息
class DetailedResponseParser(ResponseParser):
    def parse(self, response):
        # 将生成内容拆分为三部分
        sections = response.split("\n")
        result = {
            "简述": sections[0].strip() if len(sections) > 0 else "",
            "影响": sections[1].strip() if len(sections) > 1 else "",
            "历史评价": sections[2].strip() if len(sections) > 2 else ""
        }
        return result

output_parser = DetailedResponseParser()

# 3. 创建和配置任务链
llm = OpenAI(temperature=0)
chain = LLMChain(llm=llm, prompt=prompt, output_parser=output_parser)

# 4. 执行任务链并查看输出
response = chain.run({
    "event": "文艺复兴",
    "location": "欧洲",
    "date": "14世纪至17世纪"
})

# 输出测试结果
print("任务链输出:", response)


-------------------------------------------------------------------------------------------------------------


from langchain.prompts import PromptTemplate
from langchain.llms import OpenAI
from langchain.output_parsers import PydanticOutputParser
from pydantic import BaseModel, Field

# 定义数据结构
class EventInfo(BaseModel):
    summary: str = Field(description="事件的简要描述")
    impact: str = Field(description="事件的影响")
    evaluation: str = Field(description="历史评价")

# 创建Pydantic解析器
parser = PydanticOutputParser(pydantic_object=EventInfo)

# 定义PromptTemplate
prompt = PromptTemplate(
    template="描述以下事件，并按照指定结构返回：\n{format_instructions}\n事件：{event}",
    input_variables=["event"],
    partial_variables={"format_instructions": parser.get_format_instructions()}
)

# 初始化语言模型
llm = OpenAI()

# 执行任务并解析
response = llm(prompt.format(event="文艺复兴"))
result = parser.parse(response)

print("解析结果:", result)


-------------------------------------------------------------------------------------------------------------


from langchain.output_parsers import EnumOutputParser
from enum import Enum

# 定义枚举类
class Sentiment(Enum):
    POSITIVE = "正面"
    NEGATIVE = "负面"
    NEUTRAL = "中立"

# 创建Enum解析器
parser = EnumOutputParser(enum=Sentiment)

# 定义PromptTemplate
prompt = PromptTemplate(
    template="以下文本的情感是什么？\n{format_instructions}\n文本：{text}",
    input_variables=["text"],
    partial_variables={"format_instructions": parser.get_format_instructions()}
)

# 执行任务
response = llm(prompt.format(text="我非常喜欢这个产品！"))
result = parser.parse(response)

print("情感解析结果:", result)


-------------------------------------------------------------------------------------------------------------


from langchain.output_parsers import OutputFixingParser

# 使用Pydantic解析器
parser = PydanticOutputParser(pydantic_object=EventInfo)
fixing_parser = OutputFixingParser(parser=parser, llm=llm)

# 执行任务
response = llm(prompt.format(event="工业革命"))
fixed_result = fixing_parser.parse(response)

print("自动修复后的解析结果:", fixed_result)


from langchain.output_parsers import StructuredOutputParser

# 定义输出结构
schema = {
    "summary": "事件的简要描述",
    "impact": "事件的影响",
    "evaluation": "历史评价"
}
parser = StructuredOutputParser(schema=schema)

# 定义PromptTemplate
prompt = PromptTemplate(
    template="描述以下事件，返回结构化JSON数据：\n{format_instructions}\n事件：{event}",
    input_variables=["event"],
    partial_variables={"format_instructions": parser.get_format_instructions()}
)

# 执行任务
response = llm(prompt.format(event="数字革命"))
result = parser.parse(response)

print("JSON格式化输出结果:", result)



from langchain.output_parsers import CommaSeparatedOutputParser

# 初始化解析器
parser = CommaSeparatedOutputParser()

# 定义PromptTemplate
prompt = PromptTemplate(
    template="列出文艺复兴的关键贡献，用逗号分隔。\n{format_instructions}\n",
    input_variables=[]
)

# 执行任务
response = llm(prompt.format())
result = parser.parse(response)

print("逗号分隔的关键点:", result)


-------------------------------------------------------------------------------------------------------------


from langchain.document_loaders import DirectoryLoader

# 初始化DirectoryLoader加载文本文件
loader = DirectoryLoader(
    path="./data",   # 指定要加载的文件目录
    glob="**/*.txt", # 加载所有.txt文件
    show_progress=True
)

# 加载文档
documents = loader.load()
print(f"加载的文档数：{len(documents)}")


from langchain.document_loaders import JSONLoader

# JSON文件加载示例
json_loader = JSONLoader(file_path="./data/sample.json")
json_documents = json_loader.load()
print(f"加载的JSON文档数：{len(json_documents)}")
from langchain.document_loaders import MarkdownLoader

# Markdown文件加载示例
markdown_loader = MarkdownLoader(file_path="./data/sample.md")
markdown_documents = markdown_loader.load()
print(f"加载的Markdown文档数：{len(markdown_documents)}")


from langchain.embeddings import OpenAIEmbeddings

# 初始化嵌入模型
embedding_model = OpenAIEmbeddings()

# 生成嵌入向量
document_embeddings = [embedding_model.embed(doc.page_content) for doc in documents]
print("生成的嵌入向量数：", len(document_embeddings))


from langchain.vectorstores import FAISS

# 初始化FAISS向量存储
faiss_index = FAISS.from_documents(documents, embedding_model)

# 将向量存储持久化到磁盘
faiss_index.save_local("faiss_index")

print("向量存储已保存至faiss_index")


# 查询示例
query = "文艺复兴的主要贡献"
query_embedding = embedding_model.embed(query)

# 执行相似性搜索
similar_docs = faiss_index.similarity_search_by_vector(query_embedding, k=3)
print("相似文档内容：")
for i, doc in enumerate(similar_docs):
    print(f"文档{i + 1}:", doc.page_content)


# 导入必要模块
from langchain.prompts import PromptTemplate
from langchain.llms import OpenAI
from langchain.document_loaders import DirectoryLoader, JSONLoader, MarkdownLoader
from langchain.embeddings import OpenAIEmbeddings
from langchain.vectorstores import FAISS
from langchain.output_parsers import CommaSeparatedOutputParser

# 1. 使用 DirectoryLoader 加载文本文件
loader = DirectoryLoader(path="./data", glob="**/*.txt", show_progress=True)
documents = loader.load()
print(f"加载的文本文档数：{len(documents)}")

# 2. 使用 JSONLoader 加载 JSON 文件
json_loader = JSONLoader(file_path="./data/sample.json")
json_documents = json_loader.load()
print(f"加载的 JSON 文档数：{len(json_documents)}")

# 3. 使用 MarkdownLoader 加载 Markdown 文件
markdown_loader = MarkdownLoader(file_path="./data/sample.md")
markdown_documents = markdown_loader.load()
print(f"加载的 Markdown 文档数：{len(markdown_documents)}")

# 将所有文档合并到一个列表中
all_documents = documents + json_documents + markdown_documents
print(f"总加载文档数：{len(all_documents)}")

# 4. 使用文本嵌入模型生成嵌入向量
embedding_model = OpenAIEmbeddings()
document_embeddings = [embedding_model.embed(doc.page_content) for doc in all_documents]
print("生成的嵌入向量数：", len(document_embeddings))

# 5. 使用 FAISS 向量存储存储生成的嵌入向量
faiss_index = FAISS.from_documents(all_documents, embedding_model)
faiss_index.save_local("faiss_index")
print("向量存储已保存至 faiss_index")

# 6. 执行相似性搜索
query = "文艺复兴的主要贡献"
query_embedding = embedding_model.embed(query)
similar_docs = faiss_index.similarity_search_by_vector(query_embedding, k=3)

print("\n相似文档内容：")
for i, doc in enumerate(similar_docs):
    print(f"文档{i + 1}:", doc.page_content)

# 7. 使用逗号分隔解析器生成关键点列表
parser = CommaSeparatedOutputParser()
prompt = PromptTemplate(
    template="列出文艺复兴的关键贡献，用逗号分隔：\n{format_instructions}\n",
    input_variables=[],
    partial_variables={"format_instructions": parser.get_format_instructions()}
)
llm = OpenAI()
response = llm(prompt.format())
result = parser.parse(response)

print("\n逗号分隔的关键点:", result)


-------------------------------------------------------------------------------------------------------------


# 导入必要模块
from langchain.document_loaders import TextLoader
from langchain.embeddings import OpenAIEmbeddings
from langchain.vectorstores import FAISS
from langchain.text_splitter import CharacterTextSplitter

# 加载文档并分割为小块
loader = TextLoader("./data/sample.txt")
raw_documents = loader.load()
text_splitter = CharacterTextSplitter(chunk_size=1000, chunk_overlap=0)
documents = text_splitter.split_documents(raw_documents)

# 使用OpenAI嵌入模型将文档内容转换为向量
embedding_model = OpenAIEmbeddings()
db = FAISS.from_documents(documents, embedding_model)
print("FAISS向量存储已创建并保存。")

# 执行相似性搜索
query = "文艺复兴对科学的影响"
similar_docs = db.similarity_search(query)
print("\n相似文档内容：")
for i, doc in enumerate(similar_docs):
    print(f"文档{i + 1}:", doc.page_content)


from langchain.vectorstores import Qdrant

# 使用OpenAI嵌入模型将文档向量化，并存入Qdrant数据库
async def create_qdrant_vectorstore():
    db = await Qdrant.afrom_documents(documents, embedding_model, "http://localhost:6333")
    print("Qdrant异步向量存储已创建并连接。")

# 异步相似性搜索
async def async_search_in_qdrant(query):
    query_embedding = embedding_model.embed(query)
    found_docs = await db.asimilarity_search(query)
    for i, doc in enumerate(found_docs):
        print(f"文档{i + 1}:", doc.page_content)

# 运行异步搜索
import asyncio
query = "文艺复兴对艺术的贡献"
asyncio.run(create_qdrant_vectorstore())
asyncio.run(async_search_in_qdrant(query))


async def mmr_search(query):
    found_docs = await db.amax_marginal_relevance_search(query, k=2, fetch_k=10)
    for i, doc in enumerate(found_docs):
        print(f"{i + 1}.", doc.page_content, "\n")

query = "文艺复兴时期的艺术风格"
asyncio.run(mmr_search(query))


# 导入必要模块
import asyncio
from langchain.document_loaders import DirectoryLoader, TextLoader
from langchain.embeddings import OpenAIEmbeddings
from langchain.vectorstores import FAISS, Qdrant
from langchain.text_splitter import CharacterTextSplitter

# 1. 加载数据并进行预处理
# 假设我们有一个文件夹包含关于文艺复兴时期的知识文档
print("加载并分割文档...")

loader = DirectoryLoader(path="./data/renaissance", glob="**/*.txt", show_progress=True)
raw_documents = loader.load()

text_splitter = CharacterTextSplitter(chunk_size=500, chunk_overlap=50)
documents = text_splitter.split_documents(raw_documents)

print(f"总加载文档数：{len(documents)}")

# 2. 初始化嵌入模型
embedding_model = OpenAIEmbeddings()

# 3. 使用 FAISS 存储嵌入向量
print("\n创建FAISS向量存储...")
faiss_db = FAISS.from_documents(documents, embedding_model)
faiss_db.save_local("faiss_index")
print("FAISS向量存储已创建并保存。")

# 4. 异步创建 Qdrant 向量存储
async def create_qdrant_vectorstore():
    global qdrant_db
    qdrant_db = await Qdrant.afrom_documents(documents, embedding_model, "http://localhost:6333")
    print("Qdrant异步向量存储已创建并连接。")

# 5. 搜索功能实现：FAISS相似性搜索、Qdrant异步搜索、MMR搜索
async def faiss_search(query):
    print("\nFAISS 相似性搜索结果：")
    similar_docs = faiss_db.similarity_search(query)
    for i, doc in enumerate(similar_docs):
        print(f"文档{i + 1}:", doc.page_content[:200], "\n")

async def qdrant_search(query):
    print("\nQdrant 异步相似性搜索结果：")
    query_embedding = embedding_model.embed(query)
    found_docs = await qdrant_db.asimilarity_search(query)
    for i, doc in enumerate(found_docs):
        print(f"文档{i + 1}:", doc.page_content[:200], "\n")

async def mmr_search(query):
    print("\n最大边际相关搜索 (MMR) 结果：")
    found_docs = await qdrant_db.amax_marginal_relevance_search(query, k=2, fetch_k=5)
    for i, doc in enumerate(found_docs):
        print(f"{i + 1}.", doc.page_content[:200], "\n")

# 6. 执行所有搜索功能
async def main():
    query = "文艺复兴的主要贡献和影响"

    # 创建Qdrant向量存储
    await create_qdrant_vectorstore()

    # 执行FAISS相似性搜索
    await faiss_search(query)

    # 执行Qdrant异步相似性搜索
    await qdrant_search(query)

    # 执行MMR最大边际相关搜索
    await mmr_search(query)

# 运行综合搜索
asyncio.run(main())

