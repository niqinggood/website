-------------------------------------------------------------------------------------------------------------


from langchain.memory import ConversationBufferMemory
# 创建聊天消息记忆缓冲区
memory = ConversationBufferMemory()


from langchain.chains import ConversationChain
from langchain.llms import OpenAI

# 初始化语言模型
llm = OpenAI(model_name="text-davinci-003", temperature=0.7, max_tokens=150)

# 创建带有记忆功能的对话链
conversation_chain = ConversationChain(llm=llm, memory=memory)

# 开始对话示例
user_input_1 = "你好，能给我介绍一下机器学习吗？"
response_1 = conversation_chain.run(user_input_1)
print("模型回答:", response_1)

# 继续对话
user_input_2 = "机器学习和深度学习有什么区别？"
response_2 = conversation_chain.run(user_input_2)
print("模型回答:", response_2)


from datetime import datetime

# 创建自定义的消息存储函数
def add_timestamped_message(memory, user_input, model_response):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    memory.save_context(
        {"input": f"{timestamp} 用户: {user_input}"},
        {"output": f"{timestamp} 模型: {model_response}"}
    )

# 示例对话
user_input = "你好，告诉我关于人工智能的最新进展。"
model_response = "人工智能在医疗、自动驾驶等领域进展显著，特别是在诊断和自动化方面。"

# 存储带时间戳的对话内容
add_timestamped_message(memory, user_input, model_response)


# 设置缓冲窗口大小，仅保留最近的3条消息
memory.buffer_window = 3

# 开始对话示例
user_input_1 = "你好，能介绍一下机器学习吗？"
response_1 = conversation_chain.run(user_input_1)
print("模型回答:", response_1)

user_input_2 = "机器学习有哪些应用？"
response_2 = conversation_chain.run(user_input_2)
print("模型回答:", response_2)

user_input_3 = "深度学习是什么？"
response_3 = conversation_chain.run(user_input_3)
print("模型回答:", response_3)

user_input_4 = "深度学习和机器学习有什么区别？"
response_4 = conversation_chain.run(user_input_4)
print("模型回答:", response_4)

# 打印存储的消息
print("存储的消息历史:", memory.load_memory_variables({}))


# 清除之前的对话历史
memory.clear()

# 验证存储是否清空
print("已清除的消息历史:", memory.load_memory_variables({}))


-------------------------------------------------------------------------------------------------------------


# 定义一个筛选函数，用于根据关键词筛选消息
def keyword_based_filter(message, keywords=["重要", "关键", "重点"]):
    return any(keyword in message for keyword in keywords)

# 存储带有关键词的消息
def store_filtered_message(memory, user_input, model_response):
    if keyword_based_filter(user_input):
        memory.save_context({"input": user_input}, {"output": model_response})

# 示例对话
user_input = "这是一个关于机器学习的关键问题。"
model_response = "机器学习在很多领域都有重要应用。"
store_filtered_message(memory, user_input, model_response)

print("筛选后的消息历史:", memory.load_memory_variables({}))


# 定义一个函数，根据轮数调整存储深度
def adjust_memory_depth(memory, max_depth=5):
    memory.buffer_window = max_depth

# 对话轮数计数器
dialogue_count = 0

# 动态调整记忆深度
def dynamic_memory_update(user_input, model_response):
    global dialogue_count
    dialogue_count += 1
    
    # 动态调整深度，每5轮减少一次深度
    if dialogue_count <= 5:
        adjust_memory_depth(memory, max_depth=5)
    elif 5 < dialogue_count <= 10:
        adjust_memory_depth(memory, max_depth=3)
    else:
        adjust_memory_depth(memory, max_depth=2)
    
    # 存储当前消息
    memory.save_context({"input": user_input}, {"output": model_response})

# 示例对话
user_input_1 = "介绍一下机器学习。"
model_response_1 = "机器学习是一种通过数据训练模型的技术。"
dynamic_memory_update(user_input_1, model_response_1)

user_input_2 = "机器学习的主要应用有哪些？"
model_response_2 = "它在图像识别、自然语言处理等领域应用广泛。"
dynamic_memory_update(user_input_2, model_response_2)

# 打印当前存储历史
print("动态调整后的消息历史:", memory.load_memory_variables({}))


# 定义优先级判断函数
def message_priority(user_input):
    if "紧急" in user_input or "重要" in user_input:
        return "high"
    elif "了解更多" in user_input:
        return "medium"
    else:
        return "low"

# 根据优先级存储消息
def priority_based_storage(memory, user_input, model_response):
    priority = message_priority(user_input)
    if priority == "high":
        memory.save_context({"input": user_input}, {"output": model_response})
    elif priority == "medium" and len(memory.load_memory_variables({})["history"].split("\n")) < 5:
        memory.save_context({"input": user_input}, {"output": model_response})
    # 低优先级消息不存储

# 示例对话
user_input_high = "这是一个紧急的机器学习问题。"
model_response_high = "紧急问题通常需要立即解决，请说明详细情况。"
priority_based_storage(memory, user_input_high, model_response_high)

user_input_low = "一般来说，机器学习是做什么的？"
model_response_low = "机器学习是一种通过数据学习模式的技术。"
priority_based_storage(memory, user_input_low, model_response_low)

print("按优先级存储的消息历史:", memory.load_memory_variables({}))


# 简单的主题检测函数
def topic_change_detector(new_topic, current_topic):
    return new_topic != current_topic

# 示例对话
current_topic = "机器学习"

# 检测并更新话题
def topic_based_memory_clear(memory, new_topic, user_input, model_response):
    global current_topic
    if topic_change_detector(new_topic, current_topic):
        memory.clear()  # 清除旧话题的记忆
        current_topic = new_topic
    
    # 存储新话题的消息
    memory.save_context({"input": user_input}, {"output": model_response})

# 示例对话
user_input_topic1 = "告诉我关于机器学习的应用。"
model_response_topic1 = "机器学习在许多领域有广泛应用。"
topic_based_memory_clear(memory, "机器学习", user_input_topic1, model_response_topic1)

user_input_topic2 = "区块链的原理是什么？"
model_response_topic2 = "区块链是一种去中心化的分布式账本技术。"
topic_based_memory_clear(memory, "区块链", user_input_topic2, model_response_topic2)

print("切换话题后的消息历史:", memory.load_memory_variables({}))


-------------------------------------------------------------------------------------------------------------


from langchain.memory import ConversationBufferMemory

# 创建会话缓冲区
memory = ConversationBufferMemory()


# 配置会话缓冲区的窗口大小为5条消息
memory.buffer_window = 5

# 打印当前配置的窗口大小
print("会话缓冲区窗口大小:", memory.buffer_window)


from langchain.chains import ConversationChain
from langchain.llms import OpenAI

# 初始化语言模型
llm = OpenAI(model_name="text-davinci-003", temperature=0.7, max_tokens=150)

# 创建带有会话缓冲区的对话链
conversation_chain = ConversationChain(llm=llm, memory=memory)

# 示例对话
user_input_1 = "你好，可以告诉我什么是机器学习吗？"
response_1 = conversation_chain.run(user_input_1)
print("模型回答:", response_1)

user_input_2 = "机器学习有哪些应用？"
response_2 = conversation_chain.run(user_input_2)
print("模型回答:", response_2)

# 打印缓冲区中的消息历史
print("会话缓冲区内容:", memory.load_memory_variables({}))


# 定义一个动态调整缓冲区容量的函数
def adjust_memory_capacity(memory, dialogue_round):
    if dialogue_round <= 5:
        memory.buffer_window = 5
    elif 5 < dialogue_round <= 10:
        memory.buffer_window = 3
    else:
        memory.buffer_window = 2

# 对话轮数计数器
dialogue_round = 0

# 动态调整缓冲区容量
def dynamic_conversation(user_input, model_response):
    global dialogue_round
    dialogue_round += 1
    
    # 根据对话轮数调整缓冲区容量
    adjust_memory_capacity(memory, dialogue_round)
    
    # 保存对话内容
    memory.save_context({"input": user_input}, {"output": model_response})

# 示例对话
user_input_1 = "可以简单介绍一下机器学习吗？"
model_response_1 = "机器学习是一种通过数据训练模型的技术。"
dynamic_conversation(user_input_1, model_response_1)

user_input_2 = "那么，深度学习和机器学习有何区别？"
model_response_2 = "深度学习是机器学习的一种，利用神经网络解决复杂问题。"
dynamic_conversation(user_input_2, model_response_2)

# 打印当前会话缓冲区内容
print("动态调整后的缓冲区内容:", memory.load_memory_variables({}))


# 清除会话缓冲区内容
memory.clear()

# 验证缓冲区是否清空
print("清空后的会话缓冲区内容:", memory.load_memory_variables({}))


-------------------------------------------------------------------------------------------------------------


from langchain.memory import ConversationBufferWindowMemory

# 创建会话缓冲窗口，并设置窗口大小为3条消息
memory = ConversationBufferWindowMemory(k=3)


# 将窗口大小设置为5条消息
memory.k = 5

# 打印当前窗口大小
print("当前会话缓冲窗口大小:", memory.k)


from langchain.chains import ConversationChain
from langchain.llms import OpenAI

# 初始化语言模型
llm = OpenAI(model_name="text-davinci-003", temperature=0.7, max_tokens=150)

# 创建带有会话缓冲窗口的对话链
conversation_chain = ConversationChain(llm=llm, memory=memory)

# 示例对话
user_input_1 = "你好，可以告诉我什么是机器学习吗？"
response_1 = conversation_chain.run(user_input_1)
print("模型回答:", response_1)

user_input_2 = "机器学习有哪些应用？"
response_2 = conversation_chain.run(user_input_2)
print("模型回答:", response_2)

user_input_3 = "能讲讲深度学习吗？"
response_3 = conversation_chain.run(user_input_3)
print("模型回答:", response_3)

user_input_4 = "深度学习和机器学习有什么区别？"
response_4 = conversation_chain.run(user_input_4)
print("模型回答:", response_4)

# 查看缓冲窗口中的内容
print("会话缓冲窗口内容:", memory.load_memory_variables({}))


# 定义一个函数，根据条件动态调整窗口大小
def adjust_window_size(memory, topic_change=False):
    if topic_change:
        memory.k = 5  # 在新话题开始时增加窗口大小
    else:
        memory.k = 3  # 在默认情况下保持窗口大小为3

# 示例对话
user_input_1 = "你好，可以告诉我关于机器学习的基础知识吗？"
response_1 = conversation_chain.run(user_input_1)
print("模型回答:", response_1)

# 假设检测到新话题
adjust_window_size(memory, topic_change=True)

user_input_2 = "再深入讲讲深度学习的概念。"
response_2 = conversation_chain.run(user_input_2)
print("模型回答:", response_2)

# 恢复默认窗口大小
adjust_window_size(memory, topic_change=False)

user_input_3 = "机器学习有哪些应用？"
response_3 = conversation_chain.run(user_input_3)
print("模型回答:", response_3)

# 查看缓冲窗口内容
print("调整后会话缓冲窗口内容:", memory.load_memory_variables({}))


# 定义基于内容的条件判断函数
def should_store_message(message):
    # 只有包含关键字的消息才会存储
    important_keywords = ["重要", "关键", "重点"]
    return any(keyword in message for keyword in important_keywords)

# 在缓冲窗口中存储符合条件的消息
def store_message_with_condition(memory, user_input, model_response):
    if should_store_message(user_input):
        memory.save_context({"input": user_input}, {"output": model_response})

# 示例对话
user_input_important = "这是一个关于机器学习的重要问题。"
model_response_important = "机器学习是现代数据分析中的关键技术。"
store_message_with_condition(memory, user_input_important, model_response_important)

user_input_normal = "一般来说，机器学习是做什么的？"
model_response_normal = "机器学习是一种通过数据学习模式的技术。"
store_message_with_condition(memory, user_input_normal, model_response_normal)

# 查看缓冲窗口内容
print("基于内容存储的会话缓冲窗口内容:", memory.load_memory_variables({}))


-------------------------------------------------------------------------------------------------------------


from langchain.memory import ConversationSummaryMemory
from langchain.llms import OpenAI

# 初始化语言模型
llm = OpenAI(model_name="text-davinci-003", temperature=0.7, max_tokens=150)

# 创建会话摘要内存
summary_memory = ConversationSummaryMemory(llm=llm)


from langchain.chains import ConversationChain

# 创建带有会话摘要的对话链
conversation_chain = ConversationChain(llm=llm, memory=summary_memory)

# 示例对话
user_input_1 = "你好，可以告诉我什么是机器学习吗？"
response_1 = conversation_chain.run(user_input_1)
print("模型回答:", response_1)

user_input_2 = "机器学习和深度学习有什么区别？"
response_2 = conversation_chain.run(user_input_2)
print("模型回答:", response_2)

# 查看会话摘要
print("生成的会话摘要:", summary_memory.load_memory_variables({}))


# 新一轮对话示例
user_input_3 = "机器学习在金融行业有哪些应用？"
response_3 = conversation_chain.run(user_input_3)
print("模型回答:", response_3)

# 查看更新后的会话摘要
print("更新后的会话摘要:", summary_memory.load_memory_variables({}))
# 调整语言模型参数
summary_memory.llm.max_tokens = 100  # 控制摘要长度
summary_memory.llm.temperature = 0.5  # 控制生成的稳定性

# 新一轮对话示例
user_input_4 = "机器学习是否可以帮助提升客户体验？"
response_4 = conversation_chain.run(user_input_4)
print("模型回答:", response_4)

# 查看调整后的会话摘要
print("调整后的会话摘要:", summary_memory.load_memory_variables({}))


# 清除当前会话摘要
summary_memory.clear()

# 验证摘要是否清空
print("清空后的会话摘要:", summary_memory.load_memory_variables({}))


-------------------------------------------------------------------------------------------------------------


from langchain.vectorstores import FAISS
from langchain.embeddings import OpenAIEmbeddings
from langchain.llms import OpenAI

# 初始化向量化模型，用于将文本转换为向量
embedding_model = OpenAIEmbeddings()

# 创建向量存储
vector_store = FAISS(embedding_model)


# 向量化并存储用户输入和模型回复
def store_conversation_as_vector(vector_store, user_input, model_response):
    # 向量化用户输入和模型回复
    user_vector = embedding_model.embed(user_input)
    model_vector = embedding_model.embed(model_response)
    
    # 存储向量化的内容
    vector_store.add_texts([user_input, model_response], embeddings=[user_vector, model_vector])

# 示例对话
user_input_1 = "你好，可以告诉我什么是机器学习吗？"
model_response_1 = "机器学习是一种通过数据训练模型的技术。"
store_conversation_as_vector(vector_store, user_input_1, model_response_1)

user_input_2 = "机器学习和深度学习有什么区别？"
model_response_2 = "深度学习是机器学习的一个分支，利用神经网络解决复杂问题。"
store_conversation_as_vector(vector_store, user_input_2, model_response_2)


# 检索与当前输入最相关的内容
def retrieve_relevant_conversation(vector_store, query):
    # 向量化当前查询
    query_vector = embedding_model.embed(query)
    
    # 从向量存储中检索最相关的内容
    similar_texts = vector_store.similarity_search(query_vector, k=2)  # 返回最相似的2条内容
    return similar_texts

# 示例检索
query = "什么是机器学习？"
relevant_conversations = retrieve_relevant_conversation(vector_store, query)
print("与当前输入最相关的内容:", relevant_conversations)


-------------------------------------------------------------------------------------------------------------


# 定义对话存储和检索的主流程
def update_and_retrieve(vector_store, user_input, model_response, query):
    # 存储新的对话内容
    store_conversation_as_vector(vector_store, user_input, model_response)
    
    # 检索与查询最相关的历史内容
    relevant_conversations = retrieve_relevant_conversation(vector_store, query)
    return relevant_conversations

# 新对话内容示例
user_input_3 = "深度学习的应用有哪些？"
model_response_3 = "深度学习在图像识别和自然语言处理等领域应用广泛。"
query = "深度学习是什么？"

# 执行存储和检索
relevant_conversations = update_and_retrieve(vector_store, user_input_3, model_response_3, query)
print("检索结果:", relevant_conversations)


# 自定义清理函数
def clean_old_vectors(vector_store, max_entries=10):
    # 假设向量存储只保留最近的 max_entries 条记录
    if len(vector_store) > max_entries:
        # 移除较早的向量记录
        vector_store.remove_oldest_entries(len(vector_store) - max_entries)

# 定期调用清理函数
clean_old_vectors(vector_store, max_entries=5)


-------------------------------------------------------------------------------------------------------------


>> sudo apt update
>> sudo apt install postgresql postgresql-contrib
>> sudo service postgresql start
>> sudo -u postgres psql
>> CREATE DATABASE chat_db;
>> CREATE USER chat_user WITH PASSWORD 'your_password';
>> GRANT ALL PRIVILEGES ON DATABASE chat_db TO chat_user;
>> \q
>> pip install psycopg2


import psycopg2

# 连接Postgres数据库
connection = psycopg2.connect(
    database="chat_db",
    user="chat_user",
    password="your_password",
    host="localhost",
    port="5432"
)

# 创建一个游标对象
cursor = connection.cursor()
print("连接成功")


# 创建聊天消息表
create_table_query = '''
CREATE TABLE IF NOT EXISTS chat_messages (
    id SERIAL PRIMARY KEY,
    user_id VARCHAR(50),
    message_type VARCHAR(10),
    message_content TEXT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)
'''
cursor.execute(create_table_query)
connection.commit()
print("聊天消息表创建成功")


# 插入消息记录函数
def insert_message(user_id, message_type, message_content):
    insert_query = '''
    INSERT INTO chat_messages (user_id, message_type, message_content)
    VALUES (%s, %s, %s)
    '''
    cursor.execute(insert_query, (user_id, message_type, message_content))
    connection.commit()
    print("消息插入成功")

# 示例插入用户消息和模型回复
insert_message("user_1", "user", "你好，可以告诉我什么是机器学习吗？")
insert_message("user_1", "model", "机器学习是一种通过数据训练模型的技术。")


# 查询消息记录函数
def fetch_messages(user_id, limit=10):
    fetch_query = '''
    SELECT message_type, message_content, timestamp
    FROM chat_messages
    WHERE user_id = %s
    ORDER BY timestamp DESC
    LIMIT %s
    '''
    cursor.execute(fetch_query, (user_id, limit))
    records = cursor.fetchall()
    for record in records:
        print(f"{record[2]} - {record[0]}: {record[1]}")
    return records

# 示例查询最近10条消息
fetch_messages("user_1", limit=10)



# 删除特定用户的消息记录函数
def delete_user_messages(user_id):
    delete_query = '''
    DELETE FROM chat_messages
    WHERE user_id = %s
    '''
    cursor.execute(delete_query, (user_id,))
    connection.commit()
    print("用户的消息记录已删除")

# 示例删除用户消息
delete_user_messages("user_1")


# 关闭游标和数据库连接
cursor.close()
connection.close()
print("数据库连接已关闭")


-------------------------------------------------------------------------------------------------------------


>> sudo apt update
>> sudo apt install redis-server
>> sudo service redis-server start
>> redis-cli ping
>> pip install redis


import redis

# 连接到本地Redis服务
redis_client = redis.StrictRedis(host='localhost', port=6379, db=0, decode_responses=True)
print("Redis连接成功")


# 存储消息记录函数
def store_message_in_redis(user_id, message_type, message_content):
    # 使用列表存储消息，每个用户的消息列表使用唯一的键
    key = f"chat:{user_id}:messages"
    redis_client.rpush(key, f"{message_type}:{message_content}")
    print("消息已存储到Redis")

# 示例插入用户消息和模型回复
store_message_in_redis("user_1", "user", "你好，可以告诉我什么是机器学习吗？")
store_message_in_redis("user_1", "model", "机器学习是一种通过数据训练模型的技术。")


# 查询用户的最新消息记录函数
def fetch_latest_messages_from_redis(user_id, num_messages=5):
    key = f"chat:{user_id}:messages"
    messages = redis_client.lrange(key, -num_messages, -1)  # 获取最新num_messages条消息
    for message in messages:
        message_type, content = message.split(":", 1)
        print(f"{message_type}: {content}")
    return messages

# 示例查询最近5条消息
fetch_latest_messages_from_redis("user_1", num_messages=5)


-------------------------------------------------------------------------------------------------------------


# 存储消息并设置过期时间（以秒为单位）
def store_message_with_expiry(user_id, message_type, message_content, expiry_time=3600):
    key = f"chat:{user_id}:messages"
    redis_client.rpush(key, f"{message_type}:{message_content}")
    redis_client.expire(key, expiry_time)  # 设置过期时间
    print("消息已存储到Redis，并设置过期时间")

# 示例存储带过期时间的消息
store_message_with_expiry("user_1", "user", "什么是机器学习？", expiry_time=1800)
store_message_with_expiry("user_1", "model", "机器学习是一种通过数据训练模型的技术。", expiry_time=1800)


# 清除特定用户的消息记录
def clear_user_messages_in_redis(user_id):
    key = f"chat:{user_id}:messages"
    redis_client.delete(key)
    print("Redis中的用户消息记录已清除")

# 示例清除用户消息记录
clear_user_messages_in_redis("user_1")


# 存储消息并限制列表长度
def store_message_with_limit(user_id, message_type, message_content, max_messages=10):
    key = f"chat:{user_id}:messages"
    redis_client.rpush(key, f"{message_type}:{message_content}")
    redis_client.ltrim(key, -max_messages, -1)  # 仅保留最新的max_messages条消息
    print("消息已存储到Redis，并限制列表长度")

# 示例存储并限制消息数量
store_message_with_limit("user_1", "user", "你能帮我解释一下深度学习吗？", max_messages=5)
