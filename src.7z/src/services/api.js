import axios from 'axios';

const API_BASE_URL = 'http://localhost:5000/api';

export const getOptions = (dataType) => {
  return axios.get(`${API_BASE_URL}/options/${dataType}`);
};

export const saveConfiguration = (config) => {
  return axios.post(`${API_BASE_URL}/configurations`, config);
};

export const getConfigurations = () => {
  return axios.get(`${API_BASE_URL}/configurations`);
};

export const fetchData = (configId) => {
  return axios.post(`${API_BASE_URL}/fetch-data`, { configId });
};

export const downloadData = (resultId) => {
  return axios.get(`${API_BASE_URL}/download/${resultId}`);
};