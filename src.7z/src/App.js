import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, Navigate } from 'react-router-dom';
import {
  AppBar, Toolbar, Container, CssBaseline, ThemeProvider,
  createTheme, Typography, Box, Button, Avatar, IconButton,
  Menu, MenuItem, CircularProgress, Snackbar, Alert,
  Divider, ListItemIcon, ListItemText
} from '@mui/material';
import { AccountCircle, Settings, ExitToApp, ShoppingCart, ListAlt, 
  DataObject, Insights, AdminPanelSettings, Dashboard,
  ImportExport, BugReport, AutoFixHigh, VpnKey, Palette ,DescriptionOutlined,ScheduleOutlined,Login,SmartToy,
  SettingsInputComponent,PictureAsPdf,AutoAwesome,PrecisionManufacturing,
} from '@mui/icons-material';
import SkinSelector from './components/SkinSelector';
import HelpPage from './components/HelpPage';
import { HelpOutline } from '@mui/icons-material';

import axios from 'axios';
import DataConfigForm from './components/DataConfigForm';
import DataAnalysis from './components/DataAnalysis';
import LoginPage from './components/LoginPage';
import DataListPage from './components/DataListPage';
import AdminPage from './components/AdminPage';
import DataExpress from './components/DataExpress';
import InferenceDebugPage from './components/InferenceDebugPage';
import PasswordChangePage from './components/PasswordChangePage';
import { themeConfigs } from './themeConfig';
// import CustomReportPage from './components/CustomReportPage';
import CustomTaskPage from './components/CustomTaskPage';
import HomePage from './components/HomePage';

import { Home as HomeIcon } from '@mui/icons-material';
import { message } from 'antd';

// 图标映射函数
const getIconComponent = (iconName) => {
  const icons = {
    'ListAlt': ListAlt,
    'ShoppingCart': ShoppingCart,
    'Insights': Insights,
    'AdminPanelSettings': AdminPanelSettings,
    'Dashboard': Dashboard,
    'ImportExport': ImportExport,
    "BugReport": BugReport,
    'Settings': Settings,
    'HelpOutline': HelpOutline,
    'AutoFixHigh': AutoFixHigh,
    'VpnKey': VpnKey,
    'Palette': Palette,
    'DescriptionOutlined':DescriptionOutlined,
    'ScheduleOutlined':ScheduleOutlined,
    'HomeIcon':HomeIcon,
    'Login':Login,
    'AutoAwesome':AutoAwesome,
    'PictureAsPdf':PictureAsPdf,
    'SettingsInputComponent':SettingsInputComponent,
    'SmartToy':SmartToy,
    'PrecisionManufacturing':PrecisionManufacturing,
  };

  return icons[iconName] || ListAlt;
};

// 导航项配置
// { path: '/dataexpress', icon: 'ImportExport', text: '数据直通车' },
const navItems = [
  
  { path: '/home', icon: 'HomeIcon', text: 'Home' },
  { 
    // 取数菜单（包含子项）
    isSubMenu: true,
    text: '取数',
    icon: 'ImportExport',
    subItems: [
      { path: '/list', icon: 'ListAlt', text: '数据列表' },

      { path: '/config', icon: 'ShoppingCart', text: '模板定制' }
    ]
  },
  { path: '/analysis', icon: 'Insights', text: 'BI&分析' },
  //{ path: '/custom-report', icon: 'DescriptionOutlined', text: '定制报表' },
  // 新增：定制任务
  { path: '/custom-task', icon: 'ScheduleOutlined', text: '日常报表和定时任务' },

  { path: '/InferenceDebugPage', icon: 'BugReport', text: '调试及查询' },
  
  { path: '/help', icon: 'HelpOutline', text: '说明' },
];

// 判断是否使用外部链接
const shouldUseExternalLink = (url) => {
  return (
    url.startsWith('http://') ||
    url.startsWith('https://') ||
    url.startsWith('www.') ||
    url.startsWith('mailto:') ||
    url.startsWith('tel:')
  );
};

//{
//    isSubMenu: true,
//    text: 'AI助手',
//    icon: 'SmartToy', // 机器人图标
//    subItems: [
//      { path: '/rpa', icon: 'PrecisionManufacturing', text: 'RPA机器人' },
//      { path: '/ipdf', icon: 'PictureAsPdf', text: 'iPDF分析解读' },
//      { path: '/ai-other', icon: 'AutoAwesome', text: '其他AI功能' }
//    ]
//  },

// 格式化外部URL
const formatExternalUrl = (url) => {
  if (url.startsWith('www.')) {
    return `https://${url}`;
  }
  return url;
};

function App(props) {
  const [appTitle, setAppTitle] = useState(props.appTitle || "数据底座");
  const savedTheme = localStorage.getItem('appTheme') || (props.themeType || "default");
  const [themeType, setThemetype] = useState(savedTheme);

  const [user, setUser] = useState(null);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [loading, setLoading] = useState(true);
  const [notification, setNotification] = useState({
    open: false,
    message: '',
    severity: 'success'
  });
  const [menuItems, setMenuItems] = useState([]);
  const [anchorEl, setAnchorEl] = useState(null);
  const [subMenuAnchorEl, setSubMenuAnchorEl] = useState(null); // 子菜单状态
  const [openSubMenu, setOpenSubMenu] = useState(null);
  // 加载配置和用户信息
  useEffect(() => {
    let isCancelled = false;

    const fetchConfigAndUser = async () => {
      try {

        const isLoginPage = window.location.pathname.includes('/login') || 
                   window.location.pathname.includes('/databi/login');

        if (isLoginPage) {
          // 如果是登录页面，跳过用户状态检查
          console.info(" contain login")
          setLoading(false);
          return;
        }
        
       try {
            const themeResponse = await axios.get('/api/user-selfconfig/theme', { 
              withCredentials: true 
            });
            
            if (!isCancelled && themeResponse.data?.value) {
              setThemetype(themeResponse.data.value);
              localStorage.setItem('appTheme', themeResponse.data.value);
            }
          } catch (themeError) {
            const themeList = ["sunsetPurple", "palette", "mizuhai", "fjordBlue", "grassgreen", "khaki", "waldenblue"];

            // 随机获取主题的函数
            function getRandomTheme() {
              const randomIndex = Math.floor(Math.random() * themeList.length);
              return themeList[randomIndex];
            }

            // 调用函数并赋值
            const randomTheme = getRandomTheme();
            setThemetype(randomTheme); // 假设 setThemetype 是已定义的赋值函数
            console.log('获取用户主题设置失败，使用默认值:', themeError);
          }

        const userResponse = await axios.get('/api/check-login', { withCredentials: true });
        
        if (userResponse.data?.logged_in) {
          setIsLoggedIn(true);
          setUser(userResponse.data.username);
          
          
        } else {
          setIsLoggedIn(false);
          setUser(null);
          localStorage.setItem('userRole', null);
          console.error('登录状态检查失败');
          console.log('准备重定向到登录页');

        console.log('重定向到登录页');
          // <Navigate to="/login" />

        }
      } catch (error) {
        if (error.response && error.response.status === 401) {
            // 专门处理401未授权错误
            console.error('401未授权：登录状态已过期');
            showNotification("not login 请登录", "error");
            // 新开登录页面
            window.open('/login', 'loginWindow', 'width=800,height=600'); // 可自定义窗口参数
          }
        setIsLoggedIn(false);
        setUser('-');
        localStorage.setItem('userRole', null);
        console.error('登录状态检查失败:', error);
   
          console.log('准备重定向到登录页');
          setTimeout(() => {
          // if (!window.location.pathname.includes('/login')) {
          //   window.location.href = '/login';
          // }
        }, 2000);
        console.log('重定向到登录页');

      }
    };

    const fetchMenuItems = async () => {
      try {
        const response = await axios.get('/api/menu-items');
        
        if (!isCancelled) {
          const validItems = response.data.filter(item => item.useplace === "navigation");
          setMenuItems(validItems);
        }
      } catch (error) {
        console.error('获取菜单项失败，使用默认菜单:', error);
        if (!isCancelled) {
          setMenuItems([]);
        }
      }
    };

    const loadData = async () => {
      try {
        await Promise.all([
          fetchConfigAndUser(),
          fetchMenuItems()
        ]);
      } finally {
        if (!isCancelled) {
          setLoading(false);
        }
      }
    };

    loadData();

    return () => {
      isCancelled = true;
    };
  }, []);

  // 处理用户菜单打开/关闭
  const handleMenuOpen = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
  };

  // 处理取数子菜单
  // const handleSubMenuOpen = (event) => {
  //   setSubMenuAnchorEl(event.currentTarget);
  // };

  // const handleSubMenuClose = () => {
  //   setSubMenuAnchorEl(null);
  // };
  const handleSubMenuOpen = (event, menuKey) => {
  setOpenSubMenu(menuKey);
  setSubMenuAnchorEl(event.currentTarget);
};

const handleSubMenuClose = () => {
  setOpenSubMenu(null);
  setSubMenuAnchorEl(null);
};

  // 登出处理
  const handleLogout = async () => {
    try {
      await axios.post('/api/logout', { "username": user });
      setUser(null);
      showNotification('登出成功', 'success');
    } catch (error) {
      console.error("登出失败:", error);
      showNotification('登出失败', 'error');
    } finally {
      handleMenuClose();
    }
  };

  // 通知提示
  const showNotification = (message, severity = 'success') => {
    setNotification({ open: true, message, severity });
  };

  const handleCloseNotification = () => {
    setNotification(prev => ({ ...prev, open: false }));
  };

   
  const getDynamicMenuItems = () => {
  // 将从接口获取的menuItems转换为与navItems一致的格式
  return menuItems.map(item => ({
    path: shouldUseExternalLink(item.link) || item.isExternal 
      ? item.link  // 外部链接直接使用原link
      : item.link || '',  // 内部链接作为path
    icon: item.icon || 'ListAlt',  // 默认为ListAlt图标
    text: item.text || '未命名菜单',  // 菜单文本
    isExternal: shouldUseExternalLink(item.link) || item.isExternal  // 标记是否为外部链接
  }));
};

  // 主题切换处理
  const handleThemeChange = (newTheme) => {
    setThemetype(newTheme);
    localStorage.setItem('appTheme', newTheme);
  };

   const getCurrentTheme = () => {
    return themeConfigs[themeType] || themeConfigs.default;
  };  
const theme = createTheme(getCurrentTheme());  



  if (loading) {
    return (
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <Box sx={{
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          height: '100vh'
        }}>
          <CircularProgress size={60} />
        </Box>
      </ThemeProvider>
    );
  }

  const mergedMenuItems = [
  ...navItems,  // 默认导航菜单
  ...getDynamicMenuItems()  // 转换后的动态菜单
];
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Router>
        {user && (
          <AppBar position="static">
            <Toolbar>
              {/* Logo和标题 */}
              {/*<Avatar src="/foundation.svg" alt="Logo" sx={{ mr: 2, width: 40, height: 40, bgcolor: 'white', padding: '4px' }} />*/}
              <img 
              src="/data.png"
              alt="Logo" 
              style={{ 
                width: 40, 
                height: 40, 
                marginRight: 8, // 替代 mr: 2
                padding: 4, 
                // 去掉所有背景和边框
                backgroundColor: 'transparent', 
                border: 'none',
                borderRadius: 0 // 确保没有圆角
              }} 
            />
              <Typography 
                variant="h6" 
                component="div" 
                sx={{ 
                  flexGrow: 1,
                  fontWeight: 600,
                  fontSize: '1.25rem',
                  letterSpacing: '0.5px'
                }}
              >
                {appTitle}
              </Typography>
              
              <Box sx={{ display: 'flex', gap: 1, alignItems: 'center' }}>
              {/* 主导航菜单 */}
              {mergedMenuItems.map(item => (
                item.isSubMenu ? (
                  // 取数子菜单 - 与主题色保持一致
                  <React.Fragment key={item.text}>
                    <Button
                      color="inherit"
                      onClick={(e) => handleSubMenuOpen(e, item.text)} // 传递菜单标识
                      startIcon={React.createElement(getIconComponent(item.icon))}
                      sx={{ 
                        display: 'flex', 
                        alignItems: 'center',
                        fontWeight: 500,
                        fontSize: '0.95rem',
                        padding: '8px 16px',
                        position: 'relative',
                        '&:hover': {
                          backgroundColor: 'rgba(255, 255, 255, 0.15)',
                        },
                      }}
                    >
                      {item.text}
                    </Button>
                    <Menu
                      anchorEl={subMenuAnchorEl}
                      open={openSubMenu === item.text} // 只打开当前点击的菜单
                      onClose={handleSubMenuClose}
                      anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
                      transformOrigin={{ vertical: 'top', horizontal: 'right' }}
                      // 使用主题中的阴影效果
                      elevation={theme.shadows[3]}
                      // 菜单宽度自动适应内容
                      PaperProps={{
                        sx: {
                          minWidth: 180,
                        }
                      }}
                    >
                      {item.subItems.map(subItem => (
                        <MenuItem
                          key={subItem.path}
                          component={Link}
                          to={subItem.path}
                          onClick={handleSubMenuClose}
                          sx={{
                            pl: 3, // 增加左侧内边距，让图标和文字更居中
                            py: 1.2, // 调整上下内边距
                            '& .MuiListItemIcon-root': {
                              // 子菜单图标使用主题主色
                              color: theme.palette.primary.main,
                              minWidth: 28, // 图标区域宽度
                            }
                          }}
                        >
                          <ListItemIcon>
                            {React.createElement(getIconComponent(subItem.icon))}
                          </ListItemIcon>
                          <ListItemText primary={subItem.text} />
                        </MenuItem>
                      ))}
                    </Menu>
                  </React.Fragment>
                )  : (
                    // 普通导航项
                     <Button
                      key={item.path}
                      color="inherit"
                      component={Link}
                      to={item.path}
                      startIcon={React.createElement(getIconComponent(item.icon))}
                      sx={{ 
                        fontWeight: 500,
                        fontSize: '0.95rem',
                        padding: '8px 16px'
                      }}
                    >
                      {item.text}
                    </Button>
                  )
                ))}
                
                {/* 动态菜单 {renderMenuItems()} */}
               

                {/* 管理员菜单 */}
                {localStorage.getItem('userRole') === 'admin' && (
                  <Button
                    color="inherit"
                    component={Link}
                    to="/admin"
                    startIcon={<AdminPanelSettings />}
                    sx={{ 
                      fontWeight: 500,
                      fontSize: '0.95rem',
                      padding: '8px 16px'
                    }}
                  >
                    管理后台
                  </Button>
                )}

                

                {/* 用户菜单按钮 */}
                <IconButton
                  size="large"
                  edge="end"
                  color="inherit"
                  onClick={handleMenuOpen}
                >
                  <AccountCircle />
                </IconButton>

                {/* 用户菜单 */}
                <Menu
                  anchorEl={anchorEl}
                  open={Boolean(anchorEl)}
                  onClose={handleMenuClose}
                  anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
                  transformOrigin={{ vertical: 'top', horizontal: 'right' }}
                  elevation={theme.shadows[3]}
                >
                  <MenuItem disabled>
                    <Typography variant="body2">
                      登录为: {user?.name || user?.email}
                    </Typography>
                  </MenuItem>
                  <Divider />
                  
                  {/* 页面样式设置 */}
                  <MenuItem component={Link} to="/skin" onClick={handleMenuClose}>
                    <ListItemIcon>
                      <Palette fontSize="small" />
                    </ListItemIcon>
                    <ListItemText>页面样式设置</ListItemText>
                  </MenuItem>
                  
                  {/* 修改密码 */}
                  <MenuItem component={Link} to="/change-password" onClick={handleMenuClose}>
                    <ListItemIcon>
                      <VpnKey fontSize="small" />
                    </ListItemIcon>
                    <ListItemText>修改密码</ListItemText>
                  </MenuItem>

                   <MenuItem component={Link} to="/login" onClick={handleMenuClose}>
                    <ListItemIcon>
                      <Login fontSize="small" />
                    </ListItemIcon>
                    <ListItemText>登录</ListItemText>
                  </MenuItem>
                  
                  <Divider />
                  
                  {/* 退出登录 */}
                  <MenuItem onClick={handleLogout}>
                    <ListItemIcon>
                      <ExitToApp fontSize="small" />
                    </ListItemIcon>
                    <ListItemText>退出登录</ListItemText>
                  </MenuItem>
                </Menu>
              </Box>
            </Toolbar>
          </AppBar>
        )}

        <Container maxWidth="xl" sx={{ mt: 4, mb: 4 }}>
          <Routes>
            <Route path="/login" 
            element={ 
                (() => { // 自执行函数：定义后立即执行
                  console.info("user", user); // 打印日志
                  return <LoginPage setUser={setUser} showNotification={showNotification} />; // 返回组件
                })() 
              } 
               />
            <Route path="/" element={user!=='-' ?  <Navigate to="/home" /> : <Navigate to="/login" />}  />  
            <Route path="/config" element={user ? <DataConfigForm /> : <Navigate to="/login" />} />
            <Route path="/list" element={user ? <DataListPage /> : <Navigate to="/login" />} />
            <Route path="/dataexpress" element={user ? <DataExpress /> : <Navigate to="/login" />} />
            <Route path="/analysis" element={user ? <DataAnalysis /> : <Navigate to="/login" />} />
            <Route path="/admin" element={user && localStorage.getItem('userRole') === 'admin' ? <AdminPage /> : <Navigate to="/login" />} />
            <Route path="/analysis/:configname" element={<DataAnalysis />} />
            <Route path="/InferenceDebugPage" element={<InferenceDebugPage />} />
            <Route path="/skin" element={user ? <SkinSelector currentTheme={themeType} onThemeChange={handleThemeChange} /> : <Navigate to="/login" />} />
            <Route path="/help" element={user ? <HelpPage /> : <Navigate to="/login" />} />
            <Route path="/change-password" element={user ? <PasswordChangePage showNotification={showNotification} /> : <Navigate to="/login" />} />
            {/* <Route path="/custom-report" element={user ? <CustomReportPage /> : <Navigate to="/login" />} /> */}
            <Route path="/custom-task" element={user ? <CustomTaskPage /> : <Navigate to="/login" />} />
            <Route path="/home" element={user ? <HomePage /> : <Navigate to="/login" />} />
          
          </Routes>
        </Container>
      </Router>

      <Snackbar
        open={notification.open}
        autoHideDuration={6000}
        onClose={handleCloseNotification}
        anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
      >
        <Alert
          onClose={handleCloseNotification}
          severity={notification.severity}
          sx={{ width: '100%' }}
        >
          {notification.message}
        </Alert>
      </Snackbar>
    </ThemeProvider>
  );
}

export default App;