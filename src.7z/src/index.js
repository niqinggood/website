import React from 'react';
import ReactDOM from 'react-dom/client';
import './styles/global.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
import { initializeApi,loadConfig } from './config';

import { themeConfigs } from './themeConfig';
// 创建一个根节点
const root = ReactDOM.createRoot(document.getElementById('root'));

const keys = Object.keys(themeConfigs);
// 随机选择一个key
const randomKey = keys[Math.floor(Math.random() * keys.length)];

await initializeApi();
const config= await loadConfig()
const appname=config?.appName || "Data"
const themeType=config?.themeType || randomKey
// 使用 root.render 来渲染应用
root.render(
  <React.StrictMode>
    <App appTitle = {appname} themeType={themeType} />

  </React.StrictMode>
);

reportWebVitals();