#!/usr/bin/env python3
import os
import sys
import json
import time
import argparse
import logging
from datetime import datetime
import io
import random
import csv
import pandas as pd
from dateutil.parser import parse
from dateutil.relativedelta import relativedelta
from urllib.parse import quote_plus
from sqlalchemy import create_engine, text
from sqlalchemy.exc import SQLAlchemyError


# 配置日志
def setup_logging():
    """Set up logging with UTF-8 encoding"""
    if sys.platform == 'win32':
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler("datafactory_logs.log", encoding='utf-8'),
            logging.StreamHandler(sys.stdout)
        ]
    )
    return logging.getLogger(__name__)

logger = setup_logging()
# 数据库操作类
# 数据库操作类
class Database:
    def __init__(self, config_ini_path="config.ini"):
        self.engine = self._init_db(config_ini_path)

    def _init_db(self, config_ini_path):
        """初始化数据库连接"""
        try:
            import configparser
            cfg = configparser.ConfigParser()
            cfg.read(config_ini_path)

            if 'mysql' in cfg.sections():
                mysql   = cfg['mysql']
                host    = mysql.get('host', '')
                port    = mysql.get('port', '3306')
                user    = mysql.get('user', '')
                passwd  = mysql.get('passwd', '')
                dbname  = mysql.get('dbname', '')

                if all([host, user, passwd, dbname]):
                    logger.info("connect MySQL db")
                    return get_mysql_engine(user, passwd, f"{host}:{port}", dbname)

            db_path = os.path.join(os.getcwd(), "datafactory.db")
            logger.info(f"connect SQLite: {db_path}")
            return create_engine(f"sqlite:///{db_path}", echo=False)

        except Exception as e:
            logger.error(f"db init fail: {str(e)}")
            return None

    def update_task_status(self, task_id, status, status_details, download_info=None):
        """更新任务状态和下载信息"""
        if not self.engine:
            logger.error("database connect fail")
            return False

        download_info_str = json.dumps(download_info) if download_info else None
        completed_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        try:
            # 注意：使用id而非task_id，参数以字典形式传递
            update_sql = text("""
                UPDATE data_fetch_tasks 
                SET status = :status, 
                    statusdetails = :status_details, 
                    completedat = :completed_at, 
                    downloadinfo = :download_info 
                WHERE id = :id
            """)

            with self.engine.connect() as conn:
                conn.execute(
                    update_sql,
                    {
                        "id": task_id,
                        "status": status,
                        "status_details": status_details,
                        "completed_at": completed_at,
                        "download_info": download_info_str
                    }
                )
                conn.commit()
            logger.info(f"update succ {task_id} status")
            return True

        except SQLAlchemyError as e:
            logger.error(f"update fail: {str(e)}")
            return False


# MySQL引擎创建函数
def get_mysql_engine(user, passwd, ip_port, db):
    """创建MySQL数据库引擎"""
    encoded_passwd = quote_plus(passwd)
    return create_engine(
        f"mysql+pymysql://{user}:{encoded_passwd}@{ip_port}/{db}?charset=utf8mb4",
        max_overflow=15,
        pool_recycle=600,
        pool_size=0     )

def parse_arguments():
    """Parse command line arguments"""
    parser = argparse.ArgumentParser(description='Data Factory Data Fetching Script')
    parser.add_argument('--task-id', required=True, help='Task ID')
    parser.add_argument('--config-file', required=True, help='Configuration file path')
    return parser.parse_args()
def load_config(config_file):
    """Load configuration file"""
    try:
        with open(config_file, 'r', encoding='utf-8') as f:
            config = json.load(f)
        logger.info(f"Successfully loaded config file: {config_file}")
        return config
    except Exception as e:
        logger.error(f"Failed to load config file: {str(e)}")
        raise


def gen_data_and_save(config, task_id):
    """简化版：生成测试数据并保存到CSV文件"""
    logger.info(f"start  {task_id} ")

    # 提取基本配置
    config_name = config.get("configName", "test_config")
    time_range = config.get("timeRange", "single")

    # 生成列名 - 简化为固定列
    columns = ["date"] + [f"col_{i}" for i in range(1, 6)]  # 一个日期列和5个数据列

    # 生成日期范围 - 简化为固定范围
    start_date = datetime.now().strftime("%Y-%m-%d")
    date_range = [start_date]  # 默认单天数据

    # 如果需要多天数据
    if time_range != "single":
        end_date = (datetime.now() + relativedelta(days=9)).strftime("%Y-%m-%d")  # 10天数据
        date_range = [(datetime.now() + relativedelta(days=i)).strftime("%Y-%m-%d")
                      for i in range(10)]

    # 生成随机数据
    data_rows = []
    for date in date_range:
        row = {"date": date}
        for col in columns[1:]:
            row[col] = round(random.uniform(10, 100), 2)  # 简化数据范围
        data_rows.append(row)

    # 保存数据到CSV
    data_dir = "generated_data"
    os.makedirs(data_dir, exist_ok=True)

    download_info = {}

    if time_range == "single":
        file_name = f"{config_name}_single__{task_id}.csv"
        file_path = os.path.join(data_dir, file_name)
        pd.DataFrame(data_rows).to_csv(file_path, index=False, encoding='utf-8')
        download_info["single_file"] = "download/"+file_path
        logger.info(f"单文件已保存到: {file_path}")
    else:
        # 分割为训练集和测试集
        train_file = f"{config_name}_train__{task_id}.csv"
        test_file = f"{config_name}_test__{task_id}.csv"
        split_idx = int(len(data_rows) * 0.8)

        pd.DataFrame(data_rows[:split_idx]).to_csv(
            os.path.join(data_dir, train_file), index=False, encoding='utf-8')
        pd.DataFrame(data_rows[split_idx:]).to_csv(
            os.path.join(data_dir, test_file), index=False, encoding='utf-8')

        download_info = {
            "train_file": "download/"+ os.path.join(data_dir, train_file ),
            "test_file":  "download/"+ os.path.join(data_dir, test_file  ),
        }
        logger.info(f"训练集和测试集已保存")

    logger.info(f"任务 {task_id} 的数据生成和保存完成")
    return download_info


def main():
    """Main function"""
    try:
        args        = parse_arguments()
        task_id     = args.task_id
        config_file = args.config_file

        logger.info(f"Starting task processing: {task_id}")

        # 初始化数据库连接
        db          = Database()
        if not db.engine:
            logger.warning("db connect fail，will update status")

        config          = load_config(config_file)
        download_info   = gen_data_and_save(config, task_id)

        # 更新任务状态到数据库
        status_message = "Data processing completed"
        if db.update_task_status(
                task_id,
                "completed",
                status_message,
                download_info
        ):
            logger.info(f"update db status succ")
        else:
            logger.warning(f"db status update fail，situation will be save")
            # 作为备用，保存到文件
            status_file = f"{task_id}_status.json"
            status_data = {
                "task_id": task_id,
                "status": "completed",
                "message": status_message,
                "update_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "downloadInfo": download_info
            }
            with open(status_file, 'w', encoding='utf-8') as f:
                json.dump(status_data, f, indent=2)
            logger.info(f"task status saved to: {status_file}")

        logger.info(f"Task {task_id} completed successfully")

    except Exception as e:
        logger.error(f"Task processing failed: {str(e)}")
        # 初始化数据库连接
        db = Database()
        if db.engine:
            db.update_task_status(task_id, "failed", f"Processing error: {str(e)}")
        else:
            status_file = f"{task_id}_status.json"
            status_data = {
                "task_id": task_id,
                "status": "failed",
                "message": f"Processing error: {str(e)}",
                "update_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            }
            with open(status_file, 'w', encoding='utf-8') as f:
                json.dump(status_data, f, indent=2)
            logger.info(f"task status saved to: {status_file}")
        sys.exit(1)


if __name__ == "__main__":
    try:
        import pandas as pd
        from sqlalchemy import create_engine, text
        from urllib.parse import quote_plus
    except ImportError as e:
        logger.error(f"lack module: {str(e)}")
        logger.error("please install: pip install pandas sqlalchemy pymysql")
        sys.exit(1)
    main()

# #!/usr/bin/env python3
# import os
# import sys
# import json
# import time
# import argparse
# import logging
# from datetime import datetime
# import io
# import random
# import csv
# import pandas as pd
# from dateutil.parser import parse
# from dateutil.relativedelta import relativedelta
#
#
# # 配置日志
# def setup_logging():
#     """Set up logging with UTF-8 encoding"""
#     if sys.platform == 'win32':
#         sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
#
#     logging.basicConfig(
#         level=logging.INFO,
#         format='%(asctime)s - %(levelname)s - %(message)s',
#         handlers=[
#             logging.FileHandler("datafactory_logs.log", encoding='utf-8'),
#             logging.StreamHandler(sys.stdout)
#         ]
#     )
#     return logging.getLogger(__name__)
#
#
# logger = setup_logging()
#
#
# def parse_arguments():
#     """Parse command line arguments"""
#     parser = argparse.ArgumentParser(description='Data Factory Data Fetching Script')
#     parser.add_argument('--task-id', required=True, help='Task ID')
#     parser.add_argument('--config-file', required=True, help='Configuration file path')
#     return parser.parse_args()
#
#
# def load_config(config_file):
#     """Load configuration file"""
#     try:
#         with open(config_file, 'r', encoding='utf-8') as f:
#             config = json.load(f)
#         logger.info(f"Successfully loaded config file: {config_file}")
#         return config
#     except Exception as e:
#         logger.error(f"Failed to load config file: {str(e)}")
#         raise
#
#
# def generate_fake_data(config, task_id):
#     """Generate fake data based on configuration"""
#     logger.info(f"Starting to generate fake data for task: {task_id}")
#
#     config_name = config.get("configName", "unknown_config")
#     time_range  = config.get("timeRange", "single")
#     dates       = config.get("dates", {})
#     start_date  = dates.get("startDate", "1970-01-01")
#     end_date    = dates.get("endDate", "1970-01-01")
#
#     logger.info(f"Config info - Name: {config_name}, Time range: {time_range}, Date range: {start_date} to {end_date}")
#
#     # 生成列名
#     columns     = ["date"]  # 日期作为第一列
#     for config_item in config.get("configurations", []):
#         field_configs = config_item.get("fieldConfigs", [])
#         for field in field_configs:
#             col_name = f"{field.get('name', 'unknown')}_{field.get('value', 'unknown')}"
#             if col_name not in columns:  # 避免重复列名
#                 columns.append(col_name)
#
#     # 生成日期范围
#     date_range = _get_date_range(start_date, end_date)
#     if not date_range:
#         date_range = [start_date]
#
#     # 生成数据行
#     data_rows = []
#     for date in date_range:
#         row = {"date": date}
#         for col in columns[1:]:
#             row[col] = round(random.uniform(10, 1000), 2)
#         data_rows.append(row)
#
#     logger.info(f"Data generated - Rows: {len(data_rows)}, Columns: {len(columns)}")
#     return {
#         "config_name":  config_name,
#         "time_range":   time_range,
#         "task_id":      task_id,
#         "columns":      columns,
#         "data":         data_rows
#     }
#
#
# def _get_date_range(start_date, end_date):
#     """Generate date range from start to end date"""
#     try:
#         start = parse(start_date)
#         end = parse(end_date)
#         dates = []
#         current = start
#         while current <= end:
#             dates.append(current.strftime("%Y-%m-%d"))
#             current += relativedelta(days=1)
#         return dates
#     except Exception as e:
#         logger.error(f"Date range error: {str(e)}")
#         return []
#
#
# def save_to_csv(data, task_id):
#     """Save data to CSV files using Pandas"""
#     config_name = data["config_name"]
#     time_range  = data["time_range"]
#     columns     = data["columns"]
#     data_rows   = data["data"]
#
#     data_dir    = "generated_data"
#     if not os.path.exists(data_dir):
#         os.makedirs(data_dir)
#
#     # 生成文件名
#     if time_range == "single":
#         file_name   = f"{config_name}_single__{task_id}.csv"
#     else:
#         # 分割为训练集和测试集
#         train_file  = f"{config_name}_train__{task_id}.csv"
#         test_file   = f"{config_name}_test__{task_id}.csv"
#
#         # 分割数据（前80%训练，后20%测试）
#         train_data  = data_rows[:int(len(data_rows) * 0.8)]
#         test_data   = data_rows[int(len(data_rows) * 0.8):]
#
#         # 保存训练集
#         _save_pandas_csv(train_file, columns, train_data)
#         logger.info(f"Train data saved to: {os.path.join(data_dir, train_file)}")
#
#         # 保存测试集
#         _save_pandas_csv(test_file, columns, test_data)
#         logger.info(f"Test data saved to: {os.path.join(data_dir, test_file)}")
#
#         # 更新DownloadInfo
#         download_info =   {
#             "train_file": os.path.join(data_dir, train_file),
#             "test_file": os.path.join(data_dir, test_file),
#             "file_count": 2
#         }
#         return download_info
#
#     # 保存单文件
#     _save_pandas_csv(file_name, columns, data_rows)
#     logger.info(f"Data saved to: {os.path.join(data_dir, file_name)}")
#
#     # 更新DownloadInfo
#     download_info = {
#         "single_file": os.path.join(data_dir, file_name),
#         "file_count": 1
#     }
#     return download_info
#
# def _save_pandas_csv(file_name, columns, data_rows):
#     """Save data to CSV using Pandas for better performance"""
#     data_dir    = "generated_data"
#     file_path   = os.path.join(data_dir, file_name)
#     try:
#         df      = pd.DataFrame(data_rows, columns=columns)
#         df.to_csv(file_path, index=False, encoding='utf-8')
#     except Exception as e:
#         logger.error(f"Pandas CSV save error: {str(e)}")
#         raise
#
#
# def update_task_status(task_id, status, message, download_info=None):
#     """Update task status with download information"""
#     logger.info(f"Updating task {task_id} status to: {status}, message: {message}")
#
#     status_file = f"{task_id}_status.json"
#     status_data = {
#         "task_id": task_id,
#         "status": status,
#         "message": message,
#         "update_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
#     }
#
#     # 添加下载信息
#     if download_info:
#         status_data["downloadInfo"] = download_info
#
#     with open(status_file, 'w', encoding='utf-8') as f:
#         json.dump(status_data, f, indent=2)
#
#     logger.info(f"Task status saved to: {status_file}")
#     return status_data
#
#
# def main():
#     """Main function"""
#     try:
#         args            = parse_arguments()
#         task_id         = args.task_id
#         config_file     = args.config_file
#
#         logger.info(f"Starting task processing: {task_id}")
#
#         config          = load_config(config_file)
#         data            = generate_fake_data(config, task_id)
#         download_info   = save_to_csv(data, task_id)
#
#         update_task_status( task_id,"completed","Data processing completed",download_info )
#         logger.info(f"Task {task_id} completed successfully")
#
#     except Exception as e:
#         logger.error(f"Task processing failed: {str(e)}")
#         update_task_status(task_id, "failed", f"Processing error: {str(e)}")
#         sys.exit(1)
#
#
# if __name__ == "__main__":
#     try:
#         import pandas as pd
#     except ImportError:
#         logger.error("Pandas library is required. Please install with 'pip install pandas'")
#         sys.exit(1)
#     main()