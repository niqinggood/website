import React, { useState } from 'react';
import { Card, Tabs, Table, Button, Input, Typography, Form, message, Tag, Tooltip, Divider, Select, Space, Statistic, Row, Col, Spin, Modal, DatePicker, RangePicker } from 'antd';
import { SearchOutlined, UploadOutlined, DatabaseOutlined, QuestionCircleOutlined, CodeOutlined, PlayCircleOutlined, StopOutlined, ClockCircleOutlined, FilterOutlined, SyncOutlined, ClearOutlined } from '@ant-design/icons';
import axios from 'axios';
import json5 from 'json5';
import moment from 'moment';

const { TextArea } = Input;
const { Text, Title, Paragraph } = Typography;
const { TabPane } = Tabs;
const { RangePicker: DateRangePicker } = DatePicker;

const InferenceDebugPage = () => {
  // 表单实例
  const [form] = Form.useForm();
  const [historyQueryForm] = Form.useForm();
  
  // 状态管理
  const [apiUrl, setApiUrl] = useState('/api/infer-fetch-data');
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);
  const [executionTime, setExecutionTime] = useState(null);
  const [history, setHistory] = useState([]);
  const [activeHistoryIndex, setActiveHistoryIndex] = useState(-1);
  
  // 历史推理记录查询状态
  const [inferHistory, setInferHistory] = useState([]);
  const [isQueryingHistory, setIsQueryingHistory] = useState(false);
  const [historyTotal, setHistoryTotal] = useState(0);
  const [historyPage, setHistoryPage] = useState(1);
  const [historyPageSize, setHistoryPageSize] = useState(10);
  
  // 模态框状态
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [isDetailModalVisible, setIsDetailModalVisible] = useState(false);
  const [queryTaskId, setQueryTaskId] = useState('');
  const [configName, setConfigName] = useState('');
  const [isQuerying, setIsQuerying] = useState(false);
  const [currentDetail, setCurrentDetail] = useState(null);
  
  // 触发来源选项
  const triggerSources = [
    { label: '手动测试', value: 'manual_test' },
    { label: '系统调度', value: 'system_schedule' },
    { label: 'API调用', value: 'api_call' },
    { label: '其他', value: 'other' },
  ];
  
  // 状态选项
  const statusOptions = [
    { label: '处理中', value: 'processing' },
    { label: '成功', value: 'success' },
    { label: '失败', value: 'failed' },
  ];
  
  // 处理API地址，自动补全协议
  const getFullApiUrl = (url) => {
    if (url.startsWith('http://') || url.startsWith('https://')) {
      return url;
    }
    return url;
  };
  
  // 执行推理请求
  const handleInferFetch = async () => {
    console.info("begin handleInferFetch")
    try {
      // 验证表单
      const values = await form.validateFields();
      
      // 准备请求数据
      const requestData = {
        taskid: values.taskId,
        inferparams: values.inferParams ? json5.parse(values.inferParams) : {},
        triggersource: values.triggerSource,
      };
      
      // 获取完整API地址
      const fullApiUrl = getFullApiUrl(apiUrl);
      
      // 记录开始时间
      const startTime = performance.now();
      
      // 重置状态
      setIsLoading(true);
      setResult(null);
      setError(null);
      setExecutionTime(null);
      
      // 发送请求
      const response = await axios.post(fullApiUrl, requestData);
      
      // 计算执行时间
      const endTime = performance.now();
      const timeTaken = ((endTime - startTime) / 1000).toFixed(2);
      
      // 更新状态
      setResult(response.data);
      setExecutionTime(timeTaken);
      
      // 添加到历史记录
      const newHistoryItem = {
        timestamp: new Date().toISOString(),
        request: { ...requestData, apiUrl: fullApiUrl },
        response: response.data,
        executionTime: timeTaken,
        success: true,
      };
      
      setHistory(prev => [newHistoryItem, ...prev].slice(0, 10));
      message.success('数据推理请求成功');
    } catch (err) {
      // 处理错误
      setError(err.response?.data || { message: err.message });
      
      // 添加错误记录到历史
      const newHistoryItem = {
        timestamp: new Date().toISOString(),
        request: err.config?.data ? { ...JSON.parse(err.config.data), apiUrl: err.config.url } : null,
        error: err.response?.data || { message: err.message },
        success: false,
      };
      
      setHistory(prev => [newHistoryItem, ...prev].slice(0, 10));
      message.error('数据推理请求失败');
    } finally {
      setIsLoading(false);
    }
  };
  
  // 查询TaskId对应的ConfigName
  const handleQueryConfigName = async () => {
    if (!queryTaskId.trim()) {
      message.warning('请输入要查询的Task ID');
      return;
    }
    
    try {
      setIsQuerying(true);
      setConfigName('查询中...');
      
      // 调用后端Post接口
      const response = await axios.post(
        '/api/fetchdatatask-config-query', 
        { taskId: queryTaskId.trim() }
      );
      
      const result = response.data;
      
      if (result.success && result.data && result.data.configName) {
        setConfigName(`找到匹配配置：\n配置名: ${result.data.configName}\nTask ID: ${result.data.taskId}`);
      } else {
        setConfigName('未找到对应的配置名，请检查Task ID是否正确');
      }
    } catch (err) {
      let errorMsg = '未知错误';
      if (err.response) {
        errorMsg = err.response.data?.message || `HTTP错误: ${err.response.status}`;
      } else if (err.request) {
        errorMsg = '未收到服务器响应，请检查网络';
      } else {
        errorMsg = err.message;
      }
      
      message.error(`查询失败：${errorMsg}`);
      setConfigName(`查询失败：${errorMsg}`);
    } finally {
      setIsQuerying(false);
    }
  };
  
  // 查询历史推理记录
  // 修改查询历史推理记录的函数
const handleQueryInferHistory = async () => {
  try {
    setIsQueryingHistory(true);
    const values = await historyQueryForm.validateFields();
    
    // 格式化查询参数
    const queryParams = {
      id: values.id || '',
      taskId: values.taskId || '',
      baseTaskId: values.baseTaskId || '',
      triggerSource: values.triggerSource || '',
      status: values.status || '',
      page: historyPage,
      pageSize: historyPageSize,
    };
    
    // 处理时间范围
    if (values.timeRange && values.timeRange.length === 2) {
      queryParams.startTime = values.timeRange[0].format('YYYY-MM-DD HH:mm:ss');
      queryParams.endTime = values.timeRange[1].format('YYYY-MM-DD HH:mm:ss');
    }
    
    // 关键修改：使用POST方法，参数放在请求体中
    const response = await axios.post('/api/infer-history', 
      queryParams // 请求参数作为JSON体发送
    );
    
    if (response.data.success) {
      setInferHistory(response.data.data || []);
      setHistoryTotal(response.data.total || 0);
      message.success(`查询成功，共找到 ${response.data.total} 条记录`);
    } else {
      setInferHistory([]);
      setHistoryTotal(0);
      message.warning(response.data.message || '未找到匹配的历史记录');
    }
  } catch (err) {
    setInferHistory([]);
    setHistoryTotal(0);
    message.error(`查询失败：${err.response?.data?.message || err.message}`);
  } finally {
    setIsQueryingHistory(false);
  }
};
  
  // 重置历史查询表单
  const handleResetHistoryQuery = () => {
    historyQueryForm.resetFields();
    setInferHistory([]);
    setHistoryTotal(0);
    setHistoryPage(1);
  };
  
  // 查看历史记录详情
  const handleViewDetail = (record) => {
    setCurrentDetail(record);
    setIsDetailModalVisible(true);
  };
  
  // 打开模态框
  const showModal = () => {
    setQueryTaskId(form.getFieldValue('taskId') || '');
    setConfigName('');
    setIsModalVisible(true);
  };
  
  // 关闭模态框
  const handleCancel = () => {
    setIsModalVisible(false);
  };
  
  // 关闭详情模态框
  const handleDetailCancel = () => {
    setIsDetailModalVisible(false);
    setCurrentDetail(null);
  };
  
  // 加载历史记录
  const loadHistoryItem = (index) => {
    const item = history[index];
    if (!item || !item.request) return;
    
    form.setFieldsValue({
      taskId: item.request.taskid || '',
      inferParams: item.request.inferparams ? JSON.stringify(item.request.inferparams, null, 2) : '',
      triggerSource: item.request.triggersource || 'manual_test',
    });
    
    setApiUrl(item.request.apiUrl || '/api/infer-fetch-data');
    setResult(item.success ? item.response : null);
    setError(item.success ? null : item.error);
    setExecutionTime(item.executionTime || null);
    setActiveHistoryIndex(index);
  };
  
  // 格式化JSON显示
  const formatJson = (data) => {
    try {
      return JSON.stringify(data, null, 2);
    } catch (e) {
      return String(data);
    }
  };
  
  // 计算耗时
  const calculateDuration = (start, end) => {
    if (!start || !end) return '-';
    const startMoment = moment(start);
    const endMoment = moment(end);
    const seconds = endMoment.diff(startMoment, 'seconds', true);
    return seconds.toFixed(2) + 's';
  };
  
  // 历史记录列定义
  const historyColumns = [
    {
      title: '时间',
      dataIndex: 'timestamp',
      key: 'timestamp',
      render: (timestamp) => (
        <Text>
          {new Date(timestamp).toLocaleString()}
        </Text>
      ),
    },
    {
      title: 'Task ID',
      dataIndex: ['request', 'taskid'],
      key: 'taskid',
      ellipsis: true,
    },
    {
      title: '状态',
      dataIndex: 'success',
      key: 'status',
      render: (success) => (
        <Tag color={success ? 'green' : 'red'}>
          {success ? '成功' : '失败'}
        </Tag>
      ),
    },
    {
      title: '耗时(秒)',
      dataIndex: 'executionTime',
      key: 'executionTime',
      render: (time) => time || '-',
    },
    {
      title: '操作',
      key: 'action',
      render: (_, record, index) => (
        <Button 
          size="small" 
          onClick={() => loadHistoryItem(index)}
          type={activeHistoryIndex === index ? 'primary' : 'default'}
        >
          查看
        </Button>
      ),
    },
  ];
  
  // 历史推理记录列定义
  const inferHistoryColumns = [
  {
    title: '推理ID',
    dataIndex: 'id',  // 注意：后端返回的是小写id，不是大写ID
    key: 'id',
    width: 100,
    ellipsis: true,
  },
  {
    title: 'Task ID',
    dataIndex: 'taskId',
    key: 'taskId',
    ellipsis: true,
  },
  {
    title: '任务名称',
    dataIndex: 'taskName',
    key: 'taskName',
    ellipsis: true,
  },
  {
    title: '类型',
    dataIndex: 'type',
    key: 'type',
    width: 80,
    render: (type) => (
      <Tag color={type === 'sql' ? 'blue' : 'purple'}>
        {type}
      </Tag>
    ),
  },
  {
    title: '基础任务ID',
    dataIndex: 'baseTaskId',
    key: 'baseTaskId',
    ellipsis: true,
  },
  {
    title: '触发来源',
    dataIndex: 'triggerSource',
    key: 'triggerSource',
    width: 100,
    render: (source) => {
      // 修复：使用find时的安全处理
      const sourceItem = triggerSources.find(t => t.value === source);
      return <Text>{sourceItem ? sourceItem.label : source}</Text>;
    },
  },
  {
    title: '状态',
    dataIndex: 'status',
    key: 'status',
    width: 90,
    render: (status) => {
      let color = 'orange';
      let label = status;
      
      // 修复：状态文本映射
      if (status === 'success') {
        color = 'green';
        label = '成功';
      } else if (status === 'failed') {
        color = 'red';
        label = '失败';
      } else if (status === 'processing') {
        label = '处理中';
      }
      
      return <Tag color={color}>{label}</Tag>;
    },
  },
  {
    title: '开始时间',
    dataIndex: 'startTime',
    key: 'startTime',
    width: 160,
    render: (time) => {
      // 修复：时间格式化兼容处理
      if (!time) return '-';
      // 处理带时区的时间格式
      return moment(time).format('YYYY-MM-DD HH:mm:ss');
    },
  },
  {
    title: '耗时',
    key: 'duration',
    width: 80,
    render: (record) => {
      // 修复：处理endTime可能为null的情况
      if (!record.startTime || !record.endTime) return '-';
      const startMoment = moment(record.startTime);
      const endMoment = moment(record.endTime);
      const seconds = endMoment.diff(startMoment, 'seconds', true);
      return seconds.toFixed(2) + 's';
    },
  },
  {
    title: '操作',
    key: 'action',
    width: 100,
    render: (_, record) => (
      <Button 
        size="small" 
        onClick={() => handleViewDetail(record)}
        type="text"
      >
        详情
      </Button>
    ),
  },
];
  
  return (
    <div className="inference-debug-page" style={{ padding: '20px', maxWidth: '1400px', margin: '0 auto' }}>
      <Title level={2}>
        <DatabaseOutlined style={{ marginRight: 8, color: '#1890ff' }} />
        数据推理调试
      </Title>
      
      <Paragraph>
        在已有需要做训练推理任务的基础上，修改inferParams来适配推理的情况，触发推理取数测试，准确性、时效性
      </Paragraph>
      
      <Divider />
      
      <Row gutter={[12, 24]}>
        {/* 左侧：请求配置 */}
        <Col xs={24} lg={6}>
          <Card title="请求配置" bordered={true}>
            <Form
              form={form}
              layout="vertical"
              initialValues={{
                triggerSource: 'manual_test',
                inferParams: '{}',
              }}
            >
              {/* API地址配置 */}
              <Form.Item
                name="api"
                label={
                  <Space>
                    <Text>API地址(可修改)</Text>
                    <Tooltip title="推理接口的URL地址，支持相对路径和完整URL">
                      <QuestionCircleOutlined style={{ color: '#1890ff' }} />
                    </Tooltip>
                  </Space>
                }
                rules={[{  message: '请输入API地址' }]}
              >
                <Input 
                  value={apiUrl}
                  defaultValue={apiUrl}
                  onChange={(e) => setApiUrl(e.target.value)}
                  prefix={<CodeOutlined style={{ color: '#722ed1' }} />}
                  placeholder="例如: /api/infer-fetch-data 或 https://example.com/api"
                />
              </Form.Item>
              
              {/* Task ID */}
              <Form.Item
                name="taskId"
                label={
                  <Space>
                    <Text>Task ID</Text>
                    <Tooltip title="关联的基础跑批任务ID，必填项">
                      <QuestionCircleOutlined style={{ color: '#1890ff' }} />
                    </Tooltip>
                    <Button 
                      type="text" 
                      icon={<SearchOutlined style={{ fontSize: 14, color: '#1890ff' }} />} 
                      onClick={showModal}
                      size="small"
                    >
                      查询配置名
                    </Button>
                  </Space>
                }
                rules={[{ required: true, message: '请输入Task ID' }]}
              >
                <Input 
                  placeholder="请输入任务ID"
                  prefix={<DatabaseOutlined style={{ color: '#1890ff' }} />}
                />
              </Form.Item>
              
              {/* 触发来源 */}
              <Form.Item
                name="triggerSource"
                label={
                  <Space>
                    <Text>触发来源</Text>
                    <Tooltip title="标识请求的触发来源，必填项">
                      <QuestionCircleOutlined style={{ color: '#1890ff' }} />
                    </Tooltip>
                  </Space>
                }
                rules={[{  message: '请选择触发来源' }]}
              >
                <Select
                  placeholder="请选择触发来源"
                  style={{ width: '100%' }}
                >
                  {triggerSources.map(source => (
                    <Select.Option key={source.value} value={source.value}>
                      {source.label}
                    </Select.Option>
                  ))}
                </Select>
              </Form.Item>
              
              {/* 推理参数 */}
              <Form.Item
                name="inferParams"
                label={
                  <Space>
                    <Text>Infer Params</Text>
                    <Tooltip title="推理参数，JSON格式">
                      <QuestionCircleOutlined style={{ color: '#1890ff' }} />
                    </Tooltip>
                  </Space>
                }
              >
                <TextArea
                  placeholder='请输入JSON格式的推理参数，例如：{"param1": "value1", "param2": 123}'
                  rows={6}
                  monospaced
                />
              </Form.Item>
              
              {/* 操作按钮 */}
              <Form.Item>
                <Button
                  type="primary"
                  icon={<PlayCircleOutlined style={{ color: '#fff' }} />}
                  onClick={handleInferFetch}
                  loading={isLoading}
                  size="large"
                >
                  触发推理取数
                </Button>
              </Form.Item>
            </Form>
          </Card>
          
          {/* 性能统计 */}
          {executionTime !== null && (
            <Card title="性能统计" bordered={true} style={{ marginTop: 16 }}>
              <Row gutter={[16, 16]}>
                <Col xs={12} sm={8}>
                  <Statistic
                    title="执行时间"
                    value={executionTime}
                    precision={2}
                    suffix="秒"
                    prefix={<ClockCircleOutlined style={{ color: executionTime > 5 ? '#cf1322' : '#52c41a' }} />}
                    valueStyle={{ 
                      color: executionTime > 5 ? '#cf1322' : '#52c41a' 
                    }}
                  />
                </Col>
                <Col xs={12} sm={8}>
                  <Statistic
                    title="状态"
                    value={error ? "失败" : "成功"}
                    valueStyle={{ 
                      color: error ? '#cf1322' : '#52c41a' 
                    }}
                  />
                </Col>
                <Col xs={12} sm={8}>
                  <Statistic
                    title="数据大小"
                    value={result ? (JSON.stringify(result).length / 1024).toFixed(2) : 0}
                    suffix="KB"
                    prefix={<UploadOutlined style={{ color: '#1890ff' }} />}
                  />
                </Col>
              </Row>
            </Card>
          )}
        </Col>
        
        {/* 右侧：结果与历史 */}
        <Col xs={24} lg={18}>
          <Tabs defaultActiveKey="result" style={{ height: '100%' }}>
            {/* 结果标签页 */}
            <TabPane tab="推理结果" key="result">
              <Card bordered={true} bodyStyle={{ minHeight: 400, display: 'flex', flexDirection: 'column' }}>
                {isLoading ? (
                  <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: 300 }}>
                    <Spin size="large" tip="正在执行推理请求...">
                      <div className="content" />
                    </Spin>
                  </div>
                ) : error ? (
                  <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
                    <div style={{ color: '#cf1322', marginBottom: 8, display: 'flex', alignItems: 'center' }}>
                      <StopOutlined style={{ marginRight: 8, color: '#cf1322' }} />
                      <Text strong>请求错误</Text>
                    </div>
                    <TextArea
                      value={formatJson(error)}
                      rows={16}
                      readOnly
                      monospaced
                      style={{ backgroundColor: '#fff1f0', flex: 1 }}
                    />
                  </div>
                ) : result ? (
                  <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
                    <div style={{ color: '#52c41a', marginBottom: 8, display: 'flex', alignItems: 'center' }}>
                      <PlayCircleOutlined style={{ marginRight: 8, color: '#52c41a' }} />
                      <Text strong>请求成功</Text>
                    </div>
                    <TextArea
                      value={formatJson(result)}
                      rows={16}
                      readOnly
                      monospaced
                      style={{ flex: 1 }}
                    />
                  </div>
                ) : (
                  <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: 300, color: '#999' }}>
                    <Paragraph>请输入参数并点击"触发推理取数"按钮获取结果</Paragraph>
                  </div>
                )}
              </Card>
            </TabPane>
            
            {/* 历史记录标签页 */}
            <TabPane tab="历史记录" key="history">
              <Card bordered={true}>
                {history.length > 0 ? (
                  <Table
                    columns={historyColumns}
                    dataSource={history}
                    rowKey="timestamp"
                    pagination={{ pageSize: 5 }}
                    size="middle"
                  />
                ) : (
                  <div style={{ textAlign: 'center', padding: 40, color: '#999' }}>
                    <SyncOutlined style={{ fontSize: 24, marginBottom: 16, color: '#1890ff' }} />
                    <Paragraph>暂无历史记录</Paragraph>
                  </div>
                )}
              </Card>
            </TabPane>
            
            {/* 历史推理记录查询标签页 */}
            <TabPane tab="历史推理记录查询" key="infer-history">
              <Card bordered={true}>
                <Form 
                  form={historyQueryForm} 
                  layout="inline" 
                  style={{ marginBottom: 16, flexWrap: 'wrap' }}
                  initialValues={{
                    triggerSource: '',
                    status: '',
                  }}
                >
                  <Form.Item name="id" label="推理ID">
                    <Input placeholder="请输入推理ID" style={{ width: 120 }} />
                  </Form.Item>
                  
                  <Form.Item name="taskId" label="Task ID">
                    <Input placeholder="请输入Task ID" style={{ width: 150 }} />
                  </Form.Item>
                  
                  <Form.Item name="baseTaskId" label="基础任务ID">
                    <Input placeholder="请输入基础任务ID" style={{ width: 150 }} />
                  </Form.Item>
                  
                  <Form.Item name="triggerSource" label="触发来源">
                    <Select 
                      placeholder="全部" 
                      style={{ width: 130 }}
                      allowClear
                    >
                      {triggerSources.map(source => (
                        <Select.Option key={source.value} value={source.value}>
                          {source.label}
                        </Select.Option>
                      ))}
                    </Select>
                  </Form.Item>
                  
                  <Form.Item name="status" label="状态">
                    <Select 
                      placeholder="全部" 
                      style={{ width: 100 }}
                      allowClear
                    >
                      {statusOptions.map(status => (
                        <Select.Option key={status.value} value={status.value}>
                          {status.label}
                        </Select.Option>
                      ))}
                    </Select>
                  </Form.Item>
                  
                  <Form.Item name="timeRange" label="时间范围">
                    <DateRangePicker 
                      showTime={{ format: 'HH:mm:ss' }}
                      format="YYYY-MM-DD HH:mm:ss"
                      style={{ width: 300 }}
                      placeholder={['开始时间', '结束时间']}
                    />
                  </Form.Item>
                  
                  <Form.Item>
                    <Space>
                      <Button 
                        type="primary" 
                        icon={<SearchOutlined />} 
                        onClick={handleQueryInferHistory}
                        loading={isQueryingHistory}
                      >
                        查询
                      </Button>
                      <Button 
                        icon={<SyncOutlined />} 
                        onClick={handleQueryInferHistory}
                        loading={isQueryingHistory}
                      >
                        刷新
                      </Button>
                      <Button 
                        icon={<ClearOutlined />} 
                        onClick={handleResetHistoryQuery}
                      >
                        重置
                      </Button>
                    </Space>
                  </Form.Item>
                </Form>
                
                <Table
                  columns={inferHistoryColumns}
                  dataSource={inferHistory}
                  rowKey="ID"
                  loading={isQueryingHistory}
                  pagination={{
                    current: historyPage,
                    pageSize: historyPageSize,
                    total: historyTotal,
                    showSizeChanger: true,
                    showTotal: (total) => `共 ${total} 条记录`,
                    onShowSizeChange: (current, size) => {
                      setHistoryPage(1);
                      setHistoryPageSize(size);
                    },
                    onChange: (page) => {
                      setHistoryPage(page);
                    }
                  }}
                  size="middle"
                  scroll={{ x: 'max-content' }}
                />
              </Card>
            </TabPane>
          </Tabs>
        </Col>
      </Row>
      
      {/* TaskID查询模态框 */}
      <Modal
        title="查询Task ID配置名"
        visible={isModalVisible}
        onCancel={handleCancel}
        footer={[
          <Button key="back" onClick={handleCancel}>
            取消
          </Button>,
          <Button key="submit" type="primary" loading={isQuerying} onClick={handleQueryConfigName}>
            <SearchOutlined style={{ marginRight: 4 }} />
            查询
          </Button>,
        ]}
      >
        <Form layout="vertical">
          <Form.Item
            label="Task ID"
            rules={[{ required: true, message: '请输入Task ID' }]}
          >
            <Input
              value={queryTaskId}
              onChange={(e) => setQueryTaskId(e.target.value)}
              placeholder="请输入要查询的Task ID"
            />
          </Form.Item>
          
          {configName && (
            <Form.Item label="配置名查询结果">
              <div style={{ 
                padding: 12, 
                borderRadius: 4, 
                border: '1px solid #e8e8e8',
                minHeight: 60,
                backgroundColor: configName.includes('未找到') ? '#fff1f0' : '#f6ffed',
                whiteSpace: 'pre-line'
              }}>
                <Text>{configName}</Text>
              </div>
            </Form.Item>
          )}
        </Form>
      </Modal>
      
      {/* 历史详情模态框 */}
      <Modal
        title={`推理记录详情 #${currentDetail?.ID}`}
        visible={isDetailModalVisible}
        onCancel={handleDetailCancel}
        width={800}
        footer={[
          <Button key="close" onClick={handleDetailCancel}>
            关闭
          </Button>,
        ]}
      >
        {currentDetail && (
          <div>
            <Row gutter={[16, 16]}>
              <Col xs={12} sm={8}>
                <Text strong>Task ID: </Text>
                <Text code>{currentDetail.TaskID}</Text>
              </Col>
              <Col xs={12} sm={8}>
                <Text strong>任务名称: </Text>
                <Text>{currentDetail.TaskName}</Text>
              </Col>
              <Col xs={12} sm={8}>
                <Text strong>类型: </Text>
                <Tag color={currentDetail.Type === 'sql' ? 'blue' : 'purple'}>
                  {currentDetail.Type}
                </Tag>
              </Col>
              <Col xs={12} sm={8}>
                <Text strong>基础任务ID: </Text>
                <Text code>{currentDetail.BaseTaskId}</Text>
              </Col>
              <Col xs={12} sm={8}>
                <Text strong>触发来源: </Text>
                <Text>
                  {triggerSources.find(t => t.value === currentDetail.TriggerSource)?.label || currentDetail.TriggerSource}
                </Text>
              </Col>
              <Col xs={12} sm={8}>
                <Text strong>状态: </Text>
                <Tag color={
                  currentDetail.Status === 'success' ? 'green' : 
                  currentDetail.Status === 'failed' ? 'red' : 'orange'
                }>
                  {currentDetail.Status === 'processing' ? '处理中' : 
                   currentDetail.Status === 'success' ? '成功' : '失败'}
                </Tag>
              </Col>
              <Col xs={12} sm={8}>
                <Text strong>开始时间: </Text>
                <Text>{currentDetail.startTime ? moment(currentDetail.startTime).format('YYYY-MM-DD HH:mm:ss') : '-'}</Text>
              </Col>
              <Col xs={12} sm={8}>
                <Text strong>结束时间: </Text>
                <Text>{currentDetail.endTime ? moment(currentDetail.endTime).format('YYYY-MM-DD HH:mm:ss') : '-'}</Text>
              </Col>
              <Col xs={12} sm={8}>
                <Text strong>耗时: </Text>
                <Text>{calculateDuration(currentDetail.StartTime, currentDetail.EndTime)}</Text>
              </Col>
            </Row>
            
            {currentDetail.ErrorMsg && (
              <div style={{ marginTop: 16 }}>
                <Text strong style={{ color: '#cf1322' }}>错误信息:</Text>
                <div style={{ 
                  marginTop: 8,
                  padding: 12, 
                  borderRadius: 4, 
                  border: '1px solid #ffccc7',
                  backgroundColor: '#fff1f0',
                  whiteSpace: 'pre-wrap'
                }}>
                  <Text type="danger">{currentDetail.ErrorMsg}</Text>
                </div>
              </div>
            )}
            
            {currentDetail.Supplement && (
              <div style={{ marginTop: 16 }}>
                <Text strong>补充说明:</Text>
                <div style={{ 
                  marginTop: 8,
                  padding: 12, 
                  borderRadius: 4, 
                  border: '1px solid #e8e8e8',
                  whiteSpace: 'pre-wrap'
                }}>
                  <Text>{currentDetail.Supplement}</Text>
                </div>
              </div>
            )}
            
            {currentDetail.resultJSON && (
              <div style={{ marginTop: 16 }}>
                <Text strong>推理结果:</Text>
                <TextArea
                  // 修复：处理空JSON和解析错误
                  value={currentDetail.resultJSON ? formatJson(
                    currentDetail.resultJSON !== "" ? JSON.parse(currentDetail.resultJSON) : {}
                  ) : '无结果数据'}
                  rows={10}
                  readOnly
                  monospaced
                  style={{ marginTop: 8 }}
                />
              </div>
            )}
          </div>
        )}
      </Modal>
    </div>
  );
};

export default InferenceDebugPage;

// import React, { useState } from 'react';
// import { Card, Tabs, Table, Button, Input, Typography, Form, message, Tag, Tooltip, Divider, Select, Space, Statistic, Row, Col, Spin, Modal } from 'antd';
// import { SearchOutlined, UploadOutlined, DatabaseOutlined, QuestionCircleOutlined, CodeOutlined, PlayCircleOutlined, StopOutlined, SyncOutlined, ClockCircleOutlined } from '@ant-design/icons';
// import axios from 'axios';
// import json5 from 'json5';

// const { TextArea } = Input;
// const { Text, Title, Paragraph } = Typography;
// const { TabPane } = Tabs;

// const InferenceDebugPage = () => {
//   // 表单实例
//   const [form] = Form.useForm();
  
//   // 状态管理
//   const [apiUrl, setApiUrl] = useState('/api/infer-fetch-data');
//   const [isLoading, setIsLoading] = useState(false);
//   const [result, setResult] = useState(null);
//   const [error, setError] = useState(null);
//   const [executionTime, setExecutionTime] = useState(null);
//   const [history, setHistory] = useState([]);
//   const [activeHistoryIndex, setActiveHistoryIndex] = useState(-1);
  
//   // 模态框状态
//   const [isModalVisible, setIsModalVisible] = useState(false);
//   const [queryTaskId, setQueryTaskId] = useState('');
//   const [configName, setConfigName] = useState('');
//   const [isQuerying, setIsQuerying] = useState(false);
  
//   // 触发来源选项
//   const triggerSources = [
//     { label: '手动测试', value: 'manual_test' },
//     { label: '系统调度', value: 'system_schedule' },
//     { label: 'API调用', value: 'api_call' },
//     { label: '其他', value: 'other' },
//   ];
  
//   // 处理API地址，自动补全协议
//   const getFullApiUrl = (url) => {
//     // 如果URL以http或https开头，则直接使用
//     if (url.startsWith('http://') || url.startsWith('https://')) {
//       return url;
//     }
//     // 否则视为相对路径，使用当前域名和协议
//     return url;
//   };
  
//   // 执行推理请求
//   const handleInferFetch = async () => {
//      console.info("begin handleInferFetch")
//     try {
     
//       // 验证表单
//       const values = await form.validateFields();
      
//       // 准备请求数据
//       const requestData = {
//         taskid: values.taskId,
//         inferparams: values.inferParams ? json5.parse(values.inferParams) : {},
//         triggersource: values.triggerSource,
//       };
      
//       // 获取完整API地址
//       const fullApiUrl = getFullApiUrl(apiUrl);
      
//       // 记录开始时间
//       const startTime = performance.now();
      
//       // 重置状态
//       setIsLoading(true);
//       setResult(null);
//       setError(null);
//       setExecutionTime(null);
      
//       // 发送请求
//       const response = await axios.post(fullApiUrl, requestData);
      
//       // 计算执行时间
//       const endTime = performance.now();
//       const timeTaken = ((endTime - startTime) / 1000).toFixed(2);
      
//       // 更新状态
//       setResult(response.data);
//       setExecutionTime(timeTaken);
      
//       // 添加到历史记录
//       const newHistoryItem = {
//         timestamp: new Date().toISOString(),
//         request: { ...requestData, apiUrl: fullApiUrl },
//         response: response.data,
//         executionTime: timeTaken,
//         success: true,
//       };
      
//       setHistory(prev => [newHistoryItem, ...prev].slice(0, 10));
//       message.success('数据推理请求成功');
//     } catch (err) {
//       // 处理错误
//       setError(err.response?.data || { message: err.message });
      
//       // 添加错误记录到历史
//       const newHistoryItem = {
//         timestamp: new Date().toISOString(),
//         request: err.config?.data ? { ...JSON.parse(err.config.data), apiUrl: err.config.url } : null,
//         error: err.response?.data || { message: err.message },
//         success: false,
//       };
      
//       setHistory(prev => [newHistoryItem, ...prev].slice(0, 10));
//       message.error('数据推理请求失败');
//     } finally {
//       setIsLoading(false);
//     }
//   };
  
//   // 查询TaskId对应的ConfigName
//   const handleQueryConfigName = async () => {
//         if (!queryTaskId.trim()) {
//             message.warning('请输入要查询的Task ID');
//             return;
//         }
        
//         try {
//             setIsQuerying(true);
//             setConfigName('查询中...');
            
//             // 调用后端Post接口
//             const response = await axios.post(
//             '/api/fetchdatatask-config-query', 
//             { taskId: queryTaskId.trim() }
//             );
            
//             // axios已自动解析JSON，无需再调用response.json()
//             const result = response.data;
            
//             if (result.success && result.data && result.data.configName) {
//             // 显示找到的配置名和对应的taskId
//             setConfigName(`找到匹配配置：\n配置名: ${result.data.configName}\nTask ID: ${result.data.taskId}`);
//             } else {
//             setConfigName('未找到对应的配置名，请检查Task ID是否正确');
//             }
//         } catch (err) {
//             // 处理各种错误情况
//             let errorMsg = '未知错误';
//             if (err.response) {
//             // 服务器返回错误状态码
//             errorMsg = err.response.data?.message || `HTTP错误: ${err.response.status}`;
//             } else if (err.request) {
//             // 无响应
//             errorMsg = '未收到服务器响应，请检查网络';
//             } else {
//             // 请求配置错误
//             errorMsg = err.message;
//             }
            
//             message.error(`查询失败：${errorMsg}`);
//             setConfigName(`查询失败：${errorMsg}`);
//         } finally {
//             setIsQuerying(false);
//         }
//         }; 
  
//   // 打开模态框
//   const showModal = () => {
//     // 默认填充当前表单中的taskid
//     setQueryTaskId(form.getFieldValue('taskId') || '');
//     setConfigName('');
//     setIsModalVisible(true);
//   };
  
//   // 关闭模态框
//   const handleCancel = () => {
//     setIsModalVisible(false);
//   };
  
//   // 加载历史记录
//   const loadHistoryItem = (index) => {
//     const item = history[index];
//     if (!item || !item.request) return;
    
//     form.setFieldsValue({
//       taskId: item.request.taskid || '',
//       inferParams: item.request.inferparams ? JSON.stringify(item.request.inferparams, null, 2) : '',
//       triggerSource: item.request.triggersource || 'manual_test',
//     });
    
//     setApiUrl(item.request.apiUrl || '/api/infer-fetch-data');
//     setResult(item.success ? item.response : null);
//     setError(item.success ? null : item.error);
//     setExecutionTime(item.executionTime || null);
//     setActiveHistoryIndex(index);
//   };
  
//   // 格式化JSON显示
//   const formatJson = (data) => {
//     try {
//       return JSON.stringify(data, null, 2);
//     } catch (e) {
//       return String(data);
//     }
//   };
  
//   // 历史记录列定义
//   const historyColumns = [
//     {
//       title: '时间',
//       dataIndex: 'timestamp',
//       key: 'timestamp',
//       render: (timestamp) => (
//         <Text>
//           {new Date(timestamp).toLocaleString()}
//         </Text>
//       ),
//     },
//     {
//       title: 'Task ID',
//       dataIndex: ['request', 'taskid'],
//       key: 'taskid',
//       ellipsis: true,
//     },
//     {
//       title: '状态',
//       dataIndex: 'success',
//       key: 'status',
//       render: (success) => (
//         <Tag color={success ? 'green' : 'red'}>
//           {success ? '成功' : '失败'}
//         </Tag>
//       ),
//     },
//     {
//       title: '耗时(秒)',
//       dataIndex: 'executionTime',
//       key: 'executionTime',
//       render: (time) => time || '-',
//     },
//     {
//       title: '操作',
//       key: 'action',
//       render: (_, record, index) => (
//         <Button 
//           size="small" 
//           onClick={() => loadHistoryItem(index)}
//           type={activeHistoryIndex === index ? 'primary' : 'default'}
//         >
//           查看
//         </Button>
//       ),
//     },
//   ];
  
//   return (
//     <div className="inference-debug-page" style={{ padding: '20px', maxWidth: '1400px', margin: '0 auto' }}>
//       <Title level={2}>
//         <DatabaseOutlined style={{ marginRight: 8, color: '#1890ff' }} />
//         数据推理调试
//       </Title>
      
//       <Paragraph>
//         在已有需要做训练推理任务的基础上，修改inferParams来适配推理的情况，触发推理取数测试，准确性、时效性
//       </Paragraph>
      
//       <Divider />
      
//       <Row gutter={[24, 24]}>
//         {/* 左侧：请求配置 */}
//         <Col xs={24} lg={12}>
//           <Card title="请求配置" bordered={true}>
//             <Form
              
//               form={form}
//               layout="vertical"
//               initialValues={{
//                 triggerSource: 'manual_test',
//                 inferParams: '{}',
//               }}
//             >
//               {/* API地址配置 */}
//               <Form.Item
//                 name="api"
//                 label={
//                   <Space>
//                     <Text>API地址(可修改)</Text>
//                     <Tooltip title="推理接口的URL地址，支持相对路径和完整URL">
//                       <QuestionCircleOutlined style={{ color: '#1890ff' }} />
//                     </Tooltip>
//                   </Space>
//                 }
//                 rules={[{  message: '请输入API地址' }]}
//               >
//                 <Input 
//                   value={apiUrl}
//                   defaultValue={apiUrl}
//                   onChange={(e) => setApiUrl(e.target.value)}
//                   prefix={<CodeOutlined style={{ color: '#722ed1' }} />}
//                   placeholder="例如: /api/infer-fetch-data 或 https://example.com/api"
//                 />
//               </Form.Item>
              
//               {/* Task ID */}
//               <Form.Item
//                 name="taskId"
//                 label={
//                   <Space>
//                     <Text>Task ID</Text>
//                     <Tooltip title="关联的基础跑批任务ID，必填项">
//                       <QuestionCircleOutlined style={{ color: '#1890ff' }} />
//                     </Tooltip>
//                     <Button 
//                       type="text" 
//                       icon={<SearchOutlined style={{ fontSize: 14, color: '#1890ff' }} />} 
//                       onClick={showModal}
//                       size="small"
//                     >
//                       查询配置名
//                     </Button>
//                   </Space>
//                 }
//                 rules={[{ required: true, message: '请输入Task ID' }]}
//               >
//                 <Input 
//                   placeholder="请输入任务ID"
//                   prefix={<DatabaseOutlined style={{ color: '#1890ff' }} />}
//                 />
//               </Form.Item>
              
//               {/* 触发来源 */}
//               <Form.Item
//                 name="triggerSource"
//                 label={
//                   <Space>
//                     <Text>触发来源</Text>
//                     <Tooltip title="标识请求的触发来源，必填项">
//                       <QuestionCircleOutlined style={{ color: '#1890ff' }} />
//                     </Tooltip>
//                   </Space>
//                 }
//                 rules={[{  message: '请选择触发来源' }]}
//               >
//                 <Select
//                   placeholder="请选择触发来源"
//                   style={{ width: '100%' }}
//                 >
//                   {triggerSources.map(source => (
//                     <Select.Option key={source.value} value={source.value}>
//                       {source.label}
//                     </Select.Option>
//                   ))}
//                 </Select>
//               </Form.Item>
              
//               {/* 推理参数 */}
//               <Form.Item
//                 name="inferParams"
//                 label={
//                   <Space>
//                     <Text>Infer Params</Text>
//                     <Tooltip title="推理参数，JSON格式">
//                       <QuestionCircleOutlined style={{ color: '#1890ff' }} />
//                     </Tooltip>
//                   </Space>
//                 }
//               >
//                 <TextArea
//                   placeholder='请输入JSON格式的推理参数，例如：{"param1": "value1", "param2": 123}'
//                   rows={6}
//                   monospaced
//                 />
//               </Form.Item>
              
//               {/* 操作按钮 */}
//               <Form.Item>
//                 <Button
//                   type="primary"
//                   icon={<PlayCircleOutlined style={{ color: '#fff' }} />}
//                   onClick={handleInferFetch}
//                   loading={isLoading}
//                   size="large"
//                 >
//                   触发推理取数
//                 </Button>
//               </Form.Item>
//             </Form>
//           </Card>
          
//           {/* 性能统计 */}
//           {executionTime !== null && (
//             <Card title="性能统计" bordered={true} style={{ marginTop: 16 }}>
//               <Row gutter={[16, 16]}>
//                 <Col xs={12} sm={8}>
//                   <Statistic
//                     title="执行时间"
//                     value={executionTime}
//                     precision={2}
//                     suffix="秒"
//                     prefix={<ClockCircleOutlined style={{ color: executionTime > 5 ? '#cf1322' : '#52c41a' }} />}
//                     valueStyle={{ 
//                       color: executionTime > 5 ? '#cf1322' : '#52c41a' 
//                     }}
//                   />
//                 </Col>
//                 <Col xs={12} sm={8}>
//                   <Statistic
//                     title="状态"
//                     value={error ? "失败" : "成功"}
//                     valueStyle={{ 
//                       color: error ? '#cf1322' : '#52c41a' 
//                     }}
//                   />
//                 </Col>
//                 <Col xs={12} sm={8}>
//                   <Statistic
//                     title="数据大小"
//                     value={result ? (JSON.stringify(result).length / 1024).toFixed(2) : 0}
//                     suffix="KB"
//                     prefix={<UploadOutlined style={{ color: '#1890ff' }} />}
//                   />
//                 </Col>
//               </Row>
//             </Card>
//           )}
//         </Col>
        
//         {/* 右侧：结果与历史 */}
//         <Col xs={24} lg={12}>
//           <Tabs defaultActiveKey="result" style={{ height: '100%' }}>
//             {/* 结果标签页 */}
//             <TabPane tab="推理结果" key="result">
//               <Card bordered={true} bodyStyle={{ minHeight: 400, display: 'flex', flexDirection: 'column' }}>
//                 {isLoading ? (
//                   <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: 300 }}>
//                     <Spin size="large" tip="正在执行推理请求...">
//                       <div className="content" />
//                     </Spin>
//                   </div>
//                 ) : error ? (
//                   <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
//                     <div style={{ color: '#cf1322', marginBottom: 8, display: 'flex', alignItems: 'center' }}>
//                       <StopOutlined style={{ marginRight: 8, color: '#cf1322' }} />
//                       <Text strong>请求错误</Text>
//                     </div>
//                     <TextArea
//                       value={formatJson(error)}
//                       rows={16}
//                       readOnly
//                       monospaced
//                       style={{ backgroundColor: '#fff1f0', flex: 1 }}
//                     />
//                   </div>
//                 ) : result ? (
//                   <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
//                     <div style={{ color: '#52c41a', marginBottom: 8, display: 'flex', alignItems: 'center' }}>
//                       <PlayCircleOutlined style={{ marginRight: 8, color: '#52c41a' }} />
//                       <Text strong>请求成功</Text>
//                     </div>
//                     <TextArea
//                       value={formatJson(result)}
//                       rows={16}
//                       readOnly
//                       monospaced
//                       style={{ flex: 1 }}
//                     />
//                   </div>
//                 ) : (
//                   <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: 300, color: '#999' }}>
//                     <Paragraph>请输入参数并点击"触发推理取数"按钮获取结果</Paragraph>
//                   </div>
//                 )}
//               </Card>
//             </TabPane>
            
//             {/* 历史记录标签页 */}
//             <TabPane tab="历史记录" key="history">
//               <Card bordered={true}>
//                 {history.length > 0 ? (
//                   <Table
//                     columns={historyColumns}
//                     dataSource={history}
//                     rowKey="timestamp"
//                     pagination={{ pageSize: 5 }}
//                     size="middle"
//                   />
//                 ) : (
//                   <div style={{ textAlign: 'center', padding: 40, color: '#999' }}>
//                     <SyncOutlined style={{ fontSize: 24, marginBottom: 16, color: '#1890ff' }} />
//                     <Paragraph>暂无历史记录</Paragraph>
//                   </div>
//                 )}
//               </Card>
//             </TabPane>
//           </Tabs>
//         </Col>
//       </Row>
      
//       {/* TaskID查询模态框 */}
//       <Modal
//         title="查询Task ID配置名"
//         visible={isModalVisible}
//         onCancel={handleCancel}
//         footer={[
//           <Button key="back" onClick={handleCancel}>
//             取消
//           </Button>,
//           <Button key="submit" type="primary" loading={isQuerying} onClick={handleQueryConfigName}>
//             <SearchOutlined style={{ marginRight: 4 }} />
//             查询
//           </Button>,
//         ]}
//       >
//         <Form layout="vertical">
//           <Form.Item
//             label="Task ID"
//             rules={[{ required: true, message: '请输入Task ID' }]}
//           >
//             <Input
//               value={queryTaskId}
//               onChange={(e) => setQueryTaskId(e.target.value)}
//               placeholder="请输入要查询的Task ID"
//             />
//           </Form.Item>
          
//           {configName && (
//             <Form.Item label="配置名查询结果">
//               <div style={{ 
//                 padding: 12, 
//                 borderRadius: 4, 
//                 border: '1px solid #e8e8e8',
//                 minHeight: 60,
//                 backgroundColor: configName.includes('未找到') ? '#fff1f0' : '#f6ffed'
//               }}>
//                 <Text>{configName}</Text>
//               </div>
//             </Form.Item>
//           )}
//         </Form>
//       </Modal>
//     </div>
//   );
// };

// export default InferenceDebugPage;
