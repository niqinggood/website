import React, { useState, useRef } from 'react';
import { 
  Container, Typography, Box, Card, CardContent, Divider, 
  List, ListItem, ListItemIcon, ListItemText, Step, StepLabel,
  Stepper, Alert, Table, TableBody, TableCell, TableContainer,
  TableHead, TableRow, Accordion, AccordionSummary, AccordionDetails,
  Link, Chip, Paper, Button, CircularProgress, Snackbar
} from '@mui/material';
import { 
  DataObject, Insights, BugReport, ImportExport, Settings, 
  Description, Lock, Shield, Assignment, Person , FileCopy, 
  FilterList, Timeline, Help, ExpandMore, CheckCircle,
  Warning, ChevronRight, FileDownload, ArrowRight, Save,
  Download, Check, Error, Info
} from '@mui/icons-material';
import { useTheme } from '@mui/material/styles';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { format } from 'date-fns';

const HelpPage = () => {
  const theme = useTheme();
  const [activeStep, setActiveStep] = useState(0);
  const [exporting, setExporting] = useState(false);
  const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'info' });
  const contentRef = useRef(null);

  // 侧边导航数据
  const [activeNav, setActiveNav] = useState(0);
  const navItems = [
    { label: "产品概述", icon: <Description /> },
    { label: "数据获取", icon: <DataObject /> },
    { label: "数据分析", icon: <Insights /> },
    { label: "模型推理调试", icon: <BugReport /> },
    { label: "管理员风险防控", icon: <Shield /> }
  ];

  // 处理PDF导出
  const handleExportPDF = async () => {
    setExporting(true);
    setSnackbar({ open: true, message: '正在生成PDF文档...', severity: 'info' });

    try {
      const pdf = new jsPDF('p', 'mm', 'a4');
      const content = contentRef.current;
      
      const canvas = await html2canvas(content, {
        scale: 2,
        useCORS: true,
        logging: false
      });
      const imgData = canvas.toDataURL('image/jpeg', 1.0);
      
      const imgWidth = 210;
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
      let heightLeft = imgHeight;
      let position = 0;

      pdf.addImage(imgData, 'JPEG', 0, position, imgWidth, imgHeight);
      heightLeft -= 297;

      while (heightLeft > 0) {
        position = heightLeft - imgHeight;
        pdf.addPage();
        pdf.addImage(imgData, 'JPEG', 0, position, imgWidth, imgHeight);
        heightLeft -= 297;
      }

      const fileName = `数据管理平台使用指南_${format(new Date(), 'yyyyMMddHHmmss')}.pdf`;
      pdf.save(fileName);
      setSnackbar({ open: true, message: 'PDF导出成功！', severity: 'success' });
    } catch (error) {
      console.error('PDF导出失败:', error);
      setSnackbar({ open: true, message: 'PDF导出失败，请重试', severity: 'error' });
    } finally {
      setExporting(false);
    }
  };

  // 切换导航项
  const handleNavClick = (index) => {
    setActiveNav(index);
    const element = document.getElementById(`section-${index}`);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <Container maxWidth="xl" sx={{ mt: 4, mb: 8 }}>
      {/* 页面标题与导出按钮 */}
      <Box 
        sx={{ 
          mb: 6, 
          display: 'flex', 
          flexDirection: { xs: 'column', md: 'row' }, 
          justifyContent: 'space-between', 
          alignItems: 'center', 
          gap: 3 
        }}
      >
        <Box sx={{ textAlign: { xs: 'center', md: 'left' } }}>
          <Typography variant="h3" component="h1" gutterBottom>
            数据管理与分析平台使用指南
          </Typography>
          <Typography 
            variant="body1" 
            color="text.secondary" 
            maxWidth="md" 
            sx={{ mx: { xs: 'auto', md: 0 } }}
          >
            产品介绍 · 操作手册 · 最佳实践
          </Typography>
        </Box>
        
        <Button 
          variant="contained" 
          color="primary" 
          size="large"
          startIcon={exporting ? <CircularProgress size={20} color="inherit" /> : <FileDownload />}
          onClick={handleExportPDF}
          disabled={exporting}
          sx={{ alignSelf: 'center' }}
        >
          {exporting ? '导出中...' : '导出PDF手册'}
        </Button>
      </Box>

      {/* 主体内容：侧边导航 + 详情区 */}
      <Box 
        sx={{ 
          display: 'flex', 
          flexDirection: { xs: 'column', md: 'row' }, 
          gap: 4 
        }}
      >
        {/* 侧边导航 */}
        <Box 
          sx={{ 
            width: { xs: '100%', md: 280 }, 
            flexShrink: 0,
            mb: { xs: 4, md: 0 },
            position: { xs: 'relative', md: 'sticky' },
            top: 20,
            maxHeight: { xs: 'auto', md: 'calc(100vh - 100px)' },
            overflowY: { md: 'auto' }
          }}
        >
          <Card elevation={2}>
            <CardContent>
              <Typography variant="h6" sx={{ mb: 2, color: theme.palette.primary.main }}>
                目录导航
              </Typography>
              <List dense>
                {navItems.map((item, index) => (
                  <ListItem 
                    button 
                    key={index}
                    sx={{ 
                      borderRadius: 1, 
                      mb: 0.5,
                      backgroundColor: activeNav === index ? theme.palette.primary.light : 'inherit',
                      '&:hover': { 
                        backgroundColor: theme.palette.action.hover 
                      }
                    }}
                    onClick={() => handleNavClick(index)}
                  >
                    <ListItemIcon sx={{ minWidth: 30, color: activeNav === index ? theme.palette.primary.main : theme.palette.text.secondary }}>
                      {item.icon}
                    </ListItemIcon>
                    <ListItemText 
                      primary={item.label} 
                      primaryTypographyProps={{ 
                        color: activeNav === index ? theme.palette.primary.main : 'inherit',
                        fontWeight: activeNav === index ? 'bold' : 'regular'
                      }}
                    />
                    {activeNav === index && <ArrowRight size={16} color="primary" />}
                  </ListItem>
                ))}
              </List>

              <Divider sx={{ my: 3 }} />
              
              {/* 版本信息 */}
              <Box sx={{ textAlign: 'center', fontSize: 12, color: 'text.secondary' }}>
                <Typography>手册版本: v1.0.0</Typography>
                <Typography>更新日期: {format(new Date(), 'yyyy年MM月dd日')}</Typography>
              </Box>
            </CardContent>
          </Card>
        </Box>

        {/* 详情内容区 */}
        <Box ref={contentRef} sx={{ flexGrow: 1, p: { xs: 0, md: 1 } }}>
          {/* 1. 产品概述 */}
          <Card elevation={2} sx={{ mb: 6, overflow: 'hidden' }} id="section-0">
            <Box sx={{ backgroundColor: theme.palette.primary.light, p: 3 }}>
              <Typography variant="h4" sx={{ color: '#fff', display: 'flex', alignItems: 'center' }}>
                <Description sx={{ mr: 2 }} />
                产品概述
              </Typography>
            </Box>
            <CardContent sx={{ p: 4 }}>
              <Typography variant="body1" paragraph sx={{ lineHeight: 1.8 }}>
                本平台是面向业务人员的一站式数据管理与分析工具，旨在降低数据操作门槛，支持从数据获取、分析到模型推理调试的全流程工作。
                无需复杂编程能力，即可通过可视化操作完成数据处理与分析，助力业务决策。
              </Typography>
              
              {/* 产品架构 */}
              <Box sx={{ my: 4 }}>
                <Typography variant="h6" sx={{ mb: 2 }}>产品架构</Typography>
                <Paper sx={{ p: 3, backgroundColor: theme.palette.background.default }}>
                  <List dense>
                    <ListItem>
                      <ListItemIcon><DataObject /></ListItemIcon>
                      <ListItemText primary="数据层" secondary="对接多源数据（关系型数据库、数据仓库、API接口等），统一数据访问入口" />
                    </ListItem>
                    <ListItem>
                      <ListItemIcon><ImportExport /></ListItemIcon>
                      <ListItemText primary="处理层" secondary="提供数据清洗、转换、融合能力，支持自定义处理逻辑" />
                    </ListItem>
                    <ListItem>
                      <ListItemIcon><Insights /></ListItemIcon>
                      <ListItemText primary="分析层" secondary="内置统计分析、可视化工具，支持拖拽式分析建模" />
                    </ListItem>
                    <ListItem>
                      <ListItemIcon><BugReport /></ListItemIcon>
                      <ListItemText primary="推理层" secondary="集成模型引擎，支持模型部署、推理与结果解释" />
                    </ListItem>
                    <ListItem>
                      <ListItemIcon><Shield /></ListItemIcon>
                      <ListItemText primary="权限层" secondary="精细化权限管控，确保数据访问与操作安全合规" />
                    </ListItem>
                  </List>
                </Paper>
              </Box>
              
              <Box sx={{ mt: 4, display: 'flex', gap: 3, flexWrap: 'wrap' }}>
                <Paper sx={{ p: 3, flex: 1, minWidth: 250, backgroundColor: theme.palette.background.default }}>
                  <Typography variant="h6" sx={{ mb: 2, display: 'flex', alignItems: 'center' }}>
                    <CheckCircle color="success" sx={{ mr: 1 }} /> 核心价值
                  </Typography>
                  <List dense>
                    <ListItem>
                      <ListItemText primary="降低技术门槛" secondary="业务人员无需代码基础即可完成数据分析" />
                    </ListItem>
                    <ListItem>
                      <ListItemText primary="流程标准化" secondary="统一数据获取与分析流程，确保结果一致性" />
                    </ListItem>
                    <ListItem>
                      <ListItemText primary="安全可控" secondary="精细化权限管理与操作审计，保障数据安全" />
                    </ListItem>
                    <ListItem>
                      <ListItemText primary="快速迭代" secondary="支持业务需求快速落地，缩短数据分析周期" />
                    </ListItem>
                  </List>
                </Paper>
                
                <Paper sx={{ p: 3, flex: 1, minWidth: 250, backgroundColor: theme.palette.background.default }}>
                  <Typography variant="h6" sx={{ mb: 2, display: 'flex', alignItems: 'center' }}>
                    <Person  sx={{ mr: 1 }} /> 适用角色
                  </Typography>
                  <List dense>
                    <ListItem>
                      <ListItemText primary="业务人员" secondary="使用平台进行数据查询、分析与模型调试" />
                    </ListItem>
                    <ListItem>
                      <ListItemText primary="数据分析师" secondary="创建分析模板与模型，赋能业务团队" />
                    </ListItem>
                    <ListItem>
                      <ListItemText primary="DBA/技术人员" secondary="配置数据源与数据表权限" />
                    </ListItem>
                    <ListItem>
                      <ListItemText primary="管理员" secondary="配置权限、模板与安全策略" />
                    </ListItem>
                  </List>
                </Paper>
              </Box>

              {/* 快速入门指引 */}
              <Box sx={{ mt: 5 }}>
                <Typography variant="h6" sx={{ mb: 3 }}>快速入门</Typography>
                <Stepper activeStep={0} sx={{ mb: 3 }}>
                  <Step>
                    <StepLabel>注册登录(企业账号免注册)</StepLabel>
                  </Step>
                  <Step>
                    <StepLabel>权限申请(数据表权限)</StepLabel>
                  </Step>
                  <Step>
                    <StepLabel>通过「数据定制和数据直通」模块获取首批数据</StepLabel>
                  </Step>
                  <Step>
                    <StepLabel>使用「BI分析」工具生成可视化报告</StepLabel>
                  </Step>
                </Stepper>
                <Alert severity="info">
                  <Info sx={{ mr: 1 }} />
                  新用户可通过首页「新手引导」功能获取交互式操作教程
                </Alert>
              </Box>
            </CardContent>
          </Card>

          {/* 2. 数据获取 */}
          <Card elevation={2} sx={{ mb: 6 }} id="section-1">
            <Box sx={{ backgroundColor: theme.palette.primary.main, p: 3 }}>
              <Typography variant="h4" sx={{ color: '#fff', display: 'flex', alignItems: 'center' }}>
                <DataObject sx={{ mr: 2 }} />
                数据获取
              </Typography>
            </Box>
            <CardContent sx={{ p: 4 }}>
              <Typography variant="body1" paragraph>
                平台提供两种数据获取方式，满足不同技术能力的业务人员需求：「数据直通车」（适合会写SQL的用户）和「模板定制」（适合零代码用户）。
              </Typography>

              {/* 2.1 数据直通车（SQL方式） */}
              <Box sx={{ mb: 6 }}>
                <Typography variant="h5" sx={{ mb: 3, color: theme.palette.primary.main }}>
                  2.1 数据直通车（SQL查询）
                </Typography>
                <Alert severity="info" sx={{ mb: 3 }}>
                  <Help sx={{ mr: 1, verticalAlign: 'middle' }} />
                  适用于熟悉SQL语法的用户，可直接编写查询语句获取数据。支持MySQL、Hive、SparkSQL等多种语法方言。
                </Alert>

                <Typography variant="h6" sx={{ mb: 2 }}>操作步骤：</Typography>
                <Stepper activeStep={activeStep} sx={{ mb: 4 }}>
                  <Step>
                    <StepLabel>进入数据直通车页面</StepLabel>
                  </Step>
                  <Step>
                    <StepLabel>在「数据表浏览」查看表结构</StepLabel>
                  </Step>
                  <Step>
                    <StepLabel>编写并验证SQL</StepLabel>
                  </Step>
                  <Step>
                    <StepLabel>执行查询并保存结果</StepLabel>
                  </Step>
                </Stepper>

                <Accordion defaultExpanded>
                  <AccordionSummary expandIcon={<ExpandMore />}>
                    <Typography>详细操作说明</Typography>
                  </AccordionSummary>
                  <AccordionDetails>
                    <List>
                      <ListItem>
                        <ListItemIcon><ChevronRight /></ListItemIcon>
                        <ListItemText 
                          primary="步骤1：进入数据直通车" 
                          secondary="从导航栏点击「取数」->「数据直通车」" 
                        />
                      </ListItem>
                      <ListItem>
                        <ListItemIcon><ChevronRight /></ListItemIcon>
                        <ListItemText 
                          primary="步骤2：查看有权限的数据「数据表浏览」" 
                          secondary="在页面「数据表浏览」系统会自动加载该数据源下您有权限访问的表，可查看表结构" 
                        />
                      </ListItem>
                      <ListItem>
                        <ListItemIcon><ChevronRight /></ListItemIcon>
                        <ListItemText 
                          primary="步骤3：编写SQL" 
                          secondary="在查询编辑器中输入SQL语句，支持语法提示和格式化；点击「验证语法」按钮检查语句合法性" 
                        />
                      </ListItem>
                      <ListItem>
                        <ListItemIcon><ChevronRight /></ListItemIcon>
                        <ListItemText 
                          primary="步骤4：执行与保存" 
                          secondary="点击「执行查询」获取结果，支持分页查看；如需复用，点击「任务查询」可后台执行任务后续用于推理" 
                        />
                      </ListItem>
                    </List>
                  </AccordionDetails>
                </Accordion>

                {/* SQL查询最佳实践 */}
                <Box sx={{ mt: 4 }}>
                  <Typography variant="h6" sx={{ mb: 2 }}>SQL查询最佳实践</Typography>
                  <Paper sx={{ p: 3, backgroundColor: theme.palette.background.default }}>
                    <List dense>
                      <ListItem>
                        <ListItemIcon><Check color="success" /></ListItemIcon>
                        <ListItemText primary="使用 LIMIT 限制返回条数" secondary="测试查询时建议添加 LIMIT 100，避免返回大量数据" />
                      </ListItem>
                      <ListItem>
                        <ListItemIcon><Check color="success" /></ListItemIcon>
                        <ListItemText primary="添加明确的时间范围" secondary="如 WHERE create_time >= '2023-01-01'，提高查询效率" />
                      </ListItem>
                      <ListItem>
                        <ListItemIcon><Check color="success" /></ListItemIcon>
                        <ListItemText primary="使用表别名" secondary="简化SQL语句，如 SELECT t1.name FROM user t1" />
                      </ListItem>
                      <ListItem>
                        <ListItemIcon><Warning color="warning" /></ListItemIcon>
                        <ListItemText primary="避免 SELECT *" secondary="只查询需要的字段，减少数据传输量" />
                      </ListItem>
                    </List>
                  </Paper>
                </Box>

                <Alert severity="warning" sx={{ mt: 3 }}>
                  <Warning sx={{ mr: 1, verticalAlign: 'middle' }} />
                  注意：单次查询返回数据量不超过10万条，复杂查询建议设置查询条件限制范围。超大数据量查询请联系管理员协助。
                </Alert>
              </Box>

              {/* 2.2 模板定制（零代码） */}
              <Box>
                <Typography variant="h5" sx={{ mb: 3, color: theme.palette.primary.main }}>
                  2.2 模板定制（零代码）
                </Typography>
                <Alert severity="info" sx={{ mb: 3 }}>
                  <Help sx={{ mr: 1, verticalAlign: 'middle' }} />
                  适用于无SQL基础的用户，通过填写预定义模板获取数据。平台提供行业通用模板库，支持自定义模板保存。
                </Alert>

                <Typography variant="h6" sx={{ mb: 2 }}>操作步骤：</Typography>
                <TableContainer sx={{ mb: 3 }}>
                  <Table>
                    <TableHead>
                      <TableRow>
                        <TableCell>步骤</TableCell>
                        <TableCell>操作</TableCell>
                        <TableCell>说明</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      <TableRow>
                        <TableCell>1</TableCell>
                        <TableCell>选择模板</TableCell>
                        <TableCell>从「模板库」中选择业务相关模板（如“销售数据查询”“用户画像分析”）</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell>2</TableCell>
                        <TableCell>填写参数</TableCell>
                        <TableCell>在模板表单中填写查询条件（如时间范围、区域、产品类型等），支持日期选择器、下拉框等可视化组件</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell>3</TableCell>
                        <TableCell>预览与确认</TableCell>
                        <TableCell>点击「预览数据」查看前10条结果，确认无误后点击「获取完整数据」</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell>4</TableCell>
                        <TableCell>导出或分析</TableCell>
                        <TableCell>结果支持Excel导出，或直接点击「进入分析」跳转至数据分析模块</TableCell>
                      </TableRow>
                    </TableBody>
                  </Table>
                </TableContainer>

                {/* 模板管理功能 */}
                <Accordion>
                  <AccordionSummary expandIcon={<ExpandMore />}>
                    <Typography>模板管理与自定义</Typography>
                  </AccordionSummary>
                  <AccordionDetails>
                    <List>
                      <ListItem>
                        <ListItemText 
                          primary="保存自定义模板" 
                          secondary="修改现有模板参数后，点击「保存为新模板」可存入个人模板库，支持命名与描述" 
                        />
                      </ListItem>
                      <ListItem>
                        <ListItemText 
                          primary="模板权限设置" 
                          secondary="个人模板默认为私有，可通过「模板共享」功能授权给指定团队或全公司使用" 
                        />
                      </ListItem>
                      <ListItem>
                        <ListItemText 
                          primary="模板申请" 
                          secondary="如需特定业务模板，可通过「模板需求申请」提交给数据团队开发" 
                        />
                      </ListItem>
                    </List>
                  </AccordionDetails>
                </Accordion>
              </Box>
            </CardContent>
          </Card>

          {/* 3. 数据分析 */}
          <Card elevation={2} sx={{ mb: 6 }} id="section-2">
            <Box sx={{ backgroundColor: theme.palette.primary.main, p: 3 }}>
              <Typography variant="h4" sx={{ color: '#fff', display: 'flex', alignItems: 'center' }}>
                <Insights sx={{ mr: 2 }} />
                数据分析
              </Typography>
            </Box>
            <CardContent sx={{ p: 4 }}>
              <Typography variant="body1" paragraph>
                平台提供多种预置分析工具，支持对获取的数据进行全方位分析，无需手动编写分析代码。所有分析结果均可一键生成报告或导出。
              </Typography>

              <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: 'repeat(2, 1fr)' }, gap: 3, mb: 4 }}>
                {/* 3.1 概要分析 */}
                <Card elevation={1} sx={{ p: 3 }}>
                  <Typography variant="h6" sx={{ mb: 2, display: 'flex', alignItems: 'center' }}>
                    <FilterList sx={{ mr: 1 }} /> 概要分析
                  </Typography>
                  <Typography variant="body2" paragraph>
                    自动生成数据整体统计信息，包括字段类型、非空值数量、均值、中位数、最大值、最小值等。支持一键生成数据质量评估报告。
                  </Typography>
                  <Typography variant="subtitle2" color="text.secondary">
                    操作入口：数据结果页 → 点击「分析工具」→「概要分析」
                  </Typography>
                </Card>

                {/* 3.2 相关性分析 */}
                <Card elevation={1} sx={{ p: 3 }}>
                  <Typography variant="h6" sx={{ mb: 2, display: 'flex', alignItems: 'center' }}>
                    <Timeline sx={{ mr: 1 }} /> 相关性分析
                  </Typography>
                  <Typography variant="body2" paragraph>
                    计算数值型字段间的相关系数（如皮尔逊系数），生成热力图，直观展示变量间关联强度。支持设置相关系数阈值筛选强相关变量。
                  </Typography>
                  <Typography variant="subtitle2" color="text.secondary">
                    操作入口：数据结果页 → 点击「分析工具」→「相关性分析」
                  </Typography>
                </Card>

                {/* 3.3 特征分析 */}
                <Card elevation={1} sx={{ p: 3 }}>
                  <Typography variant="h6" sx={{ mb: 2, display: 'flex', alignItems: 'center' }}>
                    <DataObject sx={{ mr: 1 }} /> 特征分析
                  </Typography>
                  <Typography variant="body2" paragraph>
                    对分类字段生成分布直方图，对数值字段生成箱线图/密度图，识别异常值和分布特征。支持按时间/类别维度拆分分析。
                  </Typography>
                  <Typography variant="subtitle2" color="text.secondary">
                    操作入口：数据结果页 → 点击字段名右侧「分析」→「特征分布」
                  </Typography>
                </Card>

                {/* 3.4 下钻与时间序列分析 */}
                <Card elevation={1} sx={{ p: 3 }}>
                  <Typography variant="h6" sx={{ mb: 2, display: 'flex', alignItems: 'center' }}>
                    <ImportExport sx={{ mr: 1 }} /> 下钻与时间序列
                  </Typography>
                  <Typography variant="body2" paragraph>
                    支持按维度（如区域、渠道）下钻查看细分数据；对含时间字段的数据自动生成趋势图，支持按日/周/月聚合。
                  </Typography>
                  <Typography variant="subtitle2" color="text.secondary">
                    操作入口：分析结果页 → 点击图表「下钻」按钮 / 切换「时间粒度」
                  </Typography>
                </Card>
              </Box>

              {/* 可视化报告功能 */}
              <Box sx={{ mt: 5 }}>
                <Typography variant="h5" sx={{ mb: 3 }}>可视化报告制作</Typography>
                <Alert severity="info" sx={{ mb: 3 }}>
                  <Info sx={{ mr: 1 }} />
                  支持将多个分析图表组合成交互式报告，添加文本说明与结论，支持在线分享或导出为PDF/PPT。
                </Alert>
                
                <Stepper activeStep={0} sx={{ mb: 4 }}>
                  <Step>
                    <StepLabel>新建报告</StepLabel>
                  </Step>
                  <Step>
                    <StepLabel>添加图表与文本</StepLabel>
                  </Step>
                  <Step>
                    <StepLabel>设置布局与样式</StepLabel>
                  </Step>
                  <Step>
                    <StepLabel>发布或导出</StepLabel>
                  </Step>
                </Stepper>

                <Paper sx={{ p: 3 }}>
                  <Typography variant="subtitle1" sx={{ mb: 2 }}>支持的图表类型：</Typography>
                  <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 2 }}>
                    <Chip label="折线图" size="small" />
                    <Chip label="柱状图" size="small" />
                    <Chip label="饼图" size="small" />
                    <Chip label="散点图" size="small" />
                    <Chip label="热力图" size="small" />
                    <Chip label="漏斗图" size="small" />
                    <Chip label="雷达图" size="small" />
                    <Chip label="KPI指标卡" size="small" />
                    <Chip label="数据表格" size="small" />
                  </Box>
                </Paper>
              </Box>

              <Alert severity="success" sx={{ mt: 4 }}>
                <CheckCircle sx={{ mr: 1 }} /> 所有分析结果支持一键导出为PDF报告，或生成在线共享链接（支持设置访问权限）。
              </Alert>
            </CardContent>
          </Card>

          {/* 4. 模型推理调试 */}
          <Card elevation={2} sx={{ mb: 6 }} id="section-3">
            <Box sx={{ backgroundColor: theme.palette.primary.main, p: 3 }}>
              <Typography variant="h4" sx={{ color: '#fff', display: 'flex', alignItems: 'center' }}>
                <BugReport sx={{ mr: 2 }} />
                模型推理调试
              </Typography>
            </Box>
            <CardContent sx={{ p: 4 }}>
              <Typography variant="body1" paragraph>
                平台内置模型推理引擎，支持加载预置模型或自定义模型，同时提供可视化调试工具，帮助定位数据问题与模型偏差。
              </Typography>

              {/* 模型库介绍 */}
              <Box sx={{ mb: 5 }}>
                <Typography variant="h5" sx={{ mb: 3 }}>模型库与部署</Typography>
                <TableContainer>
                  <Table>
                    <TableHead>
                      <TableRow>
                        <TableCell>模型类型</TableCell>
                        <TableCell>适用场景</TableCell>
                        <TableCell>部署方式</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      <TableRow>
                        <TableCell>分类模型</TableCell>
                        <TableCell>客户流失预测、风险等级划分</TableCell>
                        <TableCell>一键部署（平台托管）</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell>回归模型</TableCell>
                        <TableCell>销量预测、价格预估</TableCell>
                        <TableCell>一键部署（平台托管）</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell>聚类模型</TableCell>
                        <TableCell>用户分群、产品归类</TableCell>
                        <TableCell>一键部署（平台托管）</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell>自定义模型</TableCell>
                        <TableCell>业务专属场景</TableCell>
                        <TableCell>API对接（外部模型服务）</TableCell>
                      </TableRow>
                    </TableBody>
                  </Table>
                </TableContainer>
              </Box>

              <Typography variant="h5" sx={{ mb: 3 }}>核心功能与操作：</Typography>
              
              <Accordion defaultExpanded sx={{ mb: 2 }}>
                <AccordionSummary expandIcon={<ExpandMore />}>
                  <Typography>输入数据验证</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <List>
                    <ListItem>
                      <ListItemText 
                        primary="操作步骤" 
                        secondary="1. 上传推理数据（支持Excel/CSV）；2. 点击「数据验证」；3. 查看验证结果（格式错误、缺失值、超出范围值会标红提示）" 
                      />
                    </ListItem>
                    <ListItem>
                      <ListItemText 
                        primary="常见问题处理" 
                        secondary="缺失值：可选择「均值填充」「中位数填充」或「手动输入」；格式错误：系统提供自动转换建议（如字符串转日期）" 
                      />
                    </ListItem>
                  </List>
                </AccordionDetails>
              </Accordion>

              <Accordion sx={{ mb: 2 }}>
                <AccordionSummary expandIcon={<ExpandMore />}>
                  <Typography>推理过程追踪</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <Typography paragraph>
                    点击「开始推理」后，系统会展示模型各层输出结果（如特征权重、中间计算值），支持：
                  </Typography>
                  <List dense>
                    <ListItem>查看每一步特征转换结果</ListItem>
                    <ListItem>对比输入数据与模型预期输入的差异</ListItem>
                    <ListItem>定位异常预测值的来源（如某特征值异常导致）</ListItem>
                    <ListItem>调整特征权重并实时查看对结果的影响（仅调试模式）</ListItem>
                  </List>
                </AccordionDetails>
              </Accordion>

              <Accordion sx={{ mb: 2 }}>
                <AccordionSummary expandIcon={<ExpandMore />}>
                  <Typography>结果解释与调试</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <Typography paragraph>
                    推理完成后，系统生成：
                  </Typography>
                  <List dense>
                    <ListItem>预测结果分布直方图（识别是否存在偏误）</ListItem>
                    <ListItem>特征重要性排序（展示对结果影响最大的前10个特征）</ListItem>
                    <ListItem>错误案例分析（列出预测错误的样本及可能原因）</ListItem>
                    <ListItem>模型评估指标（准确率、召回率、F1值等，依模型类型而定）</ListItem>
                  </List>
                  <Typography variant="subtitle2" sx={{ mt: 2 }}>
                    调试入口：结果页 → 点击「错误样本」→ 查看「调试建议」
                  </Typography>
                </AccordionDetails>
              </Accordion>

              {/* 模型版本管理 */}
              <Accordion sx={{ mb: 2 }}>
                <AccordionSummary expandIcon={<ExpandMore />}>
                  <Typography>模型版本管理</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <List>
                    <ListItem>
                      <ListItemText 
                        primary="版本对比" 
                        secondary="支持对比不同模型版本的推理结果差异，生成版本变更报告" 
                      />
                    </ListItem>
                    <ListItem>
                      <ListItemText 
                        primary="版本回滚" 
                        secondary="当新版本模型效果不佳时，可一键回滚至历史稳定版本" 
                      />
                    </ListItem>
                    <ListItem>
                      <ListItemText 
                        primary="性能监控" 
                        secondary="系统自动记录各版本模型的推理耗时、准确率等指标，支持趋势分析" 
                      />
                    </ListItem>
                  </List>
                </AccordionDetails>
              </Accordion>
            </CardContent>
          </Card>

          {/* 5. 管理员风险防控 */}
          <Card elevation={2} sx={{ mb: 6 }} id="section-4">
            <Box sx={{ backgroundColor: theme.palette.secondary.main, p: 3 }}>
              <Typography variant="h4" sx={{ color: '#fff', display: 'flex', alignItems: 'center' }}>
                <Shield sx={{ mr: 2 }} />
                管理员风险防控
              </Typography>
            </Box>
            <CardContent sx={{ p: 4 }}>
              <Typography variant="body1" paragraph>
                管理员可通过以下策略保障平台数据安全与合规性，防范数据泄露、滥用等风险。建议结合企业数据安全管理制度制定平台使用规范。
              </Typography>

              <Box sx={{ mb: 4 }}>
                <Typography variant="h5" sx={{ mb: 3, color: theme.palette.secondary.main }}>
                  5.1 数据权限管理
                </Typography>
                <TableContainer>
                  <Table>
                    <TableHead>
                      <TableRow>
                        <TableCell>防控措施</TableCell>
                        <TableCell>操作路径</TableCell>
                        <TableCell>风险点</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      <TableRow>
                        <TableCell>数据源权限隔离</TableCell>
                        <TableCell>「系统管理」→「数据源权限」→ 按角色分配数据源访问权限</TableCell>
                        <TableCell>未授权用户访问敏感数据源（如客户隐私数据）</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell>字段级权限控制</TableCell>
                        <TableCell>「表管理」→ 选择表 →「字段权限」→ 隐藏/脱敏敏感字段（如手机号、身份证）</TableCell>
                        <TableCell>敏感字段暴露（如直接展示完整身份证号）</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell>操作权限细分</TableCell>
                        <TableCell>「用户管理」→「角色配置」→ 细化「查询/导出/修改」权限</TableCell>
                        <TableCell>普通用户导出大量原始数据</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell>数据行级过滤</TableCell>
                        <TableCell>「表管理」→「行级权限」→ 配置基于用户属性的数据过滤规则</TableCell>
                        <TableCell>跨区域/部门查看数据</TableCell>
                      </TableRow>
                    </TableBody>
                  </Table>
                </TableContainer>
              </Box>

              <Box sx={{ mb: 4 }}>
                <Typography variant="h5" sx={{ mb: 3, color: theme.palette.secondary.main }}>
                  5.2 操作审计与监控
                </Typography>
                <List>
                  <ListItem>
                    <ListItemIcon><Assignment /></ListItemIcon>
                    <ListItemText 
                      primary="操作日志查询" 
                      secondary="「系统管理」→「操作日志」可查看所有用户的关键操作（如查询、导出、修改模板），支持按用户、时间、操作类型筛选，日志保留期180天" 
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemIcon><Warning /></ListItemIcon>
                    <ListItemText 
                      primary="异常行为告警" 
                      secondary="配置告警规则（如单次导出超10万条、高频查询敏感表），触发时通过邮件/短信通知管理员，支持自定义告警阈值" 
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemIcon><FileCopy /></ListItemIcon>
                    <ListItemText 
                      primary="数据导出水印" 
                      secondary="开启「导出水印」功能，所有导出文件自动添加用户名+时间戳，追溯数据传播路径" 
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemIcon><Timeline /></ListItemIcon>
                    <ListItemText 
                      primary="数据访问热力图" 
                      secondary="可视化展示各表/字段的访问频率、用户分布，识别异常访问模式" 
                    />
                  </ListItem>
                </List>
              </Box>

              <Box>
                <Typography variant="h5" sx={{ mb: 3, color: theme.palette.secondary.main }}>
                  5.3 系统安全设置
                </Typography>
                <Alert severity="warning" sx={{ mb: 3 }}>
                  <Lock sx={{ mr: 1 }} /> 定期进行安全配置检查，建议每季度更新一次策略，配合企业安全审计。
                </Alert>
                <List>
                  <ListItem>
                    <ListItemText primary="会话超时控制" secondary="设置自动登出时间（如30分钟无操作），路径：「系统设置」→「安全配置」" />
                  </ListItem>
                  <ListItem>
                    <ListItemText primary="IP白名单" secondary="限制仅指定IP段可访问平台，适合内部敏感数据场景，支持分角色配置" />
                  </ListItem>
                  <ListItem>
                    <ListItemText primary="定期权限审计" secondary="每季度 review 所有用户权限，移除不再需要的访问权限，路径：「用户管理」→「权限审计」" />
                  </ListItem>
                  <ListItem>
                    <ListItemText primary="密码策略" secondary="配置密码复杂度要求（长度、字符类型）、定期更换周期，路径：「系统设置」→「密码策略」" />
                  </ListItem>
                  <ListItem>
                    <ListItemText primary="API访问控制" secondary="对外部系统API调用设置访问令牌有效期与调用频率限制，路径：「系统管理」→「API设置」" />
                  </ListItem>
                </List>
              </Box>
            </CardContent>
          </Card>
        </Box>
      </Box>

      {/* 导出状态提示 */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={6000}
        onClose={() => setSnackbar({ ...snackbar, open: false })}
        message={snackbar.message}
        action={
          <Button color="inherit" size="small" onClick={() => setSnackbar({ ...snackbar, open: false })}>
            关闭
          </Button>
        }
      />
    </Container>
  );
};

export default HelpPage;
    
// import React, { useState } from 'react';
// import { 
//   Container, Typography, Box, Card, CardContent, Divider, 
//   List, ListItem, ListItemIcon, ListItemText, Step, StepLabel,
//   Stepper, Alert, Table, TableBody, TableCell, TableContainer,
//   TableHead, TableRow, Accordion, AccordionSummary, AccordionDetails,
//   Link, Chip, Paper
// } from '@mui/material';
// import { 
//   DataObject, Insights, BugReport, ImportExport, Settings, 
//   Description, Lock, Shield, Assignment, Person , FileCopy, 
//   FilterList, Timeline, Help, ExpandMore, CheckCircle,
//   Warning, ChevronRight
// } from '@mui/icons-material';
// import { useTheme } from '@mui/material/styles';

// const HelpPage = () => {
//   const theme = useTheme();
//   const [activeStep, setActiveStep] = useState(0); // 用于步骤展示的交互

//   // 侧边导航数据
//   const navItems = [
//     { label: "产品概述", icon: <Description /> },
//     { label: "数据获取", icon: <DataObject /> },
//     { label: "数据分析", icon: <Insights /> },
//     { label: "模型推理调试", icon: <BugReport /> },
//     { label: "管理员风险防控", icon: <Shield /> }
//   ];

//   return (
//     <Container maxWidth="xl" sx={{ mt: 4, mb: 8 }}>
//       {/* 页面标题 */}
//       <Box sx={{ mb: 6, textAlign: 'center' }}>
//         <Typography variant="h3" component="h1" gutterBottom>
//           数据管理与分析平台使用指南
//         </Typography>
//         <Typography variant="body1" color="text.secondary" maxWidth="md" mx="auto">
//           本指南涵盖产品功能说明、业务人员操作步骤及管理员风险防控策略，帮助您高效、安全地使用系统
//         </Typography>
//       </Box>

//       {/* 主体内容：侧边导航 + 详情区 */}
//       <Box sx={{ display: 'flex', gap: 4 }}>
//         {/* 侧边导航（桌面端固定，移动端可滚动） */}
//         <Box 
//           sx={{ 
//             width: { xs: '100%', md: 280 }, 
//             flexShrink: 0,
//             mb: { xs: 4, md: 0 }
//           }}
//         >
//           <Card elevation={2}>
//             <CardContent>
//               <Typography variant="h6" sx={{ mb: 2, color: theme.palette.primary.main }}>
//                 目录导航
//               </Typography>
//               <List dense>
//                 {navItems.map((item, index) => (
//                   <ListItem 
//                     button 
//                     key={index}
//                     sx={{ 
//                       borderRadius: 1, 
//                       mb: 0.5,
//                       '&:hover': { 
//                         backgroundColor: theme.palette.action.hover 
//                       }
//                     }}
//                   >
//                     <ListItemIcon sx={{ minWidth: 30, color: theme.palette.primary.main }}>
//                       {item.icon}
//                     </ListItemIcon>
//                     <ListItemText primary={item.label} />
//                   </ListItem>
//                 ))}
//               </List>
//             </CardContent>
//           </Card>
//         </Box>

//         {/* 详情内容区 */}
//         <Box sx={{ flexGrow: 1 }}>
//           {/* 1. 产品概述 */}
//           <Card elevation={2} sx={{ mb: 6, overflow: 'hidden' }}>
//             <Box sx={{ bgColor: theme.palette.primary.light, p: 3 }}>
//               <Typography variant="h4" sx={{ color: '#fff', display: 'flex', alignItems: 'center' }}>
//                 <Description sx={{ mr: 2 }} />
//                 产品概述
//               </Typography>
//             </Box>
//             <CardContent sx={{ p: 4 }}>
//               <Typography variant="body1" paragraph sx={{ lineHeight: 1.8 }}>
//                 本平台是面向业务人员的一站式数据管理与分析工具，旨在降低数据操作门槛，支持从数据获取、分析到模型推理调试的全流程工作。
//                 无需复杂编程能力，即可通过可视化操作完成数据处理与分析，助力业务决策。
//               </Typography>
              
//               <Box sx={{ mt: 4, display: 'flex', gap: 3, flexWrap: 'wrap' }}>
//                 <Paper sx={{ p: 3, flex: 1, minWidth: 250, bgColor: theme.palette.background.default }}>
//                   <Typography variant="h6" sx={{ mb: 2, display: 'flex', alignItems: 'center' }}>
//                     <CheckCircle color="success" sx={{ mr: 1 }} /> 核心价值
//                   </Typography>
//                   <List dense>
//                     <ListItem>
//                       <ListItemText primary="降低技术门槛" secondary="业务人员无需代码基础即可高效完成数据提取、分析" />
//                     </ListItem>
//                     <ListItem>
//                       <ListItemText primary="流程标准化" secondary="统一数据获取与分析流程，确保结果一致性" />
//                     </ListItem>
//                     <ListItem>
//                       <ListItemText primary="安全可控" secondary="精细化权限管理与操作审计，保障数据安全" />
//                     </ListItem>
//                   </List>
//                 </Paper>
                
//                 <Paper sx={{ p: 3, flex: 1, minWidth: 250, bgColor: theme.palette.background.default }}>
//                   <Typography variant="h6" sx={{ mb: 2, display: 'flex', alignItems: 'center' }}>
//                     <Person  sx={{ mr: 1 }} /> 适用角色
//                   </Typography>
//                   <List dense>
//                     <ListItem>
//                       <ListItemText primary="业务人员" secondary="使用平台进行数据查询、分析与模型调试" />
//                     </ListItem>
//                     <ListItem>
//                       <ListItemText primary="管理员" secondary="配置权限、模板与安全策略" />
//                     </ListItem>
//                     <ListItem>
//                       <ListItemText primary="DBA/技术人员" secondary="配置数据源与数据表权限" />
//                     </ListItem>
//                   </List>
//                 </Paper>
//               </Box>
//             </CardContent>
//           </Card>

//           {/* 2. 数据获取 */}
//           <Card elevation={2} sx={{ mb: 6 }}>
//             <Box sx={{ bgColor: theme.palette.primary.main, p: 3 }}>
//               <Typography variant="h4" sx={{ color: '#fff', display: 'flex', alignItems: 'center' }}>
//                 <DataObject sx={{ mr: 2 }} />
//                 数据获取
//               </Typography>
//             </Box>
//             <CardContent sx={{ p: 4 }}>
//               <Typography variant="body1" paragraph>
//                 平台提供两种数据获取方式，满足不同技术能力的业务人员需求：「数据直通车」（适合会写SQL的用户）和「模板定制」（适合零代码用户）。
//               </Typography>

//               {/* 2.1 数据直通车（SQL方式） */}
//               <Box sx={{ mb: 6 }}>
//                 <Typography variant="h5" sx={{ mb: 3, color: theme.palette.primary.main }}>
//                   2.1 数据直通车（SQL查询）
//                 </Typography>
//                 <Alert severity="info" sx={{ mb: 3 }}>
//                   <Help sx={{ mr: 1, verticalAlign: 'middle' }} />
//                   适用于熟悉SQL语法的用户，可直接编写查询语句获取数据。
//                 </Alert>

//                 <Typography variant="h6" sx={{ mb: 2 }}>操作步骤：</Typography>
//                 <Stepper activeStep={activeStep} sx={{ mb: 4 }}>
//                   <Step>
//                     <StepLabel>进入数据直通车页面</StepLabel>
//                   </Step>
//                   <Step>
//                     <StepLabel>选择数据源</StepLabel>
//                   </Step>
//                   <Step>
//                     <StepLabel>编写并验证SQL</StepLabel>
//                   </Step>
//                   <Step>
//                     <StepLabel>执行查询并保存结果</StepLabel>
//                   </Step>
//                 </Stepper>

//                 <Accordion defaultExpanded>
//                   <AccordionSummary expandIcon={<ExpandMore />}>
//                     <Typography>详细操作说明</Typography>
//                   </AccordionSummary>
//                   <AccordionDetails>
//                     <List>
//                       <ListItem>
//                         <ListItemIcon><ChevronRight /></ListItemIcon>
//                         <ListItemText 
//                           primary="步骤1：进入数据直通车" 
//                           secondary="从左侧导航栏点击「数据管理」→「数据直通车」" 
//                         />
//                       </ListItem>
//                       <ListItem>
//                         <ListItemIcon><ChevronRight /></ListItemIcon>
//                         <ListItemText 
//                           primary="步骤2：选择数据源" 
//                           secondary="在页面顶部下拉框选择目标数据源（如MySQL、Hive等），系统会自动加载该数据源下您有权限访问的表" 
//                         />
//                       </ListItem>
//                       <ListItem>
//                         <ListItemIcon><ChevronRight /></ListItemIcon>
//                         <ListItemText 
//                           primary="步骤3：编写SQL" 
//                           secondary="在查询编辑器中输入SQL语句，支持语法提示和格式化；点击「验证语法」按钮检查语句合法性" 
//                         />
//                       </ListItem>
//                       <ListItem>
//                         <ListItemIcon><ChevronRight /></ListItemIcon>
//                         <ListItemText 
//                           primary="步骤4：执行与保存" 
//                           secondary="点击「执行查询」获取结果，支持分页查看；如需复用，点击「保存查询」命名后存入个人查询库" 
//                         />
//                       </ListItem>
//                     </List>
//                   </AccordionDetails>
//                 </Accordion>

//                 <Alert severity="warning" sx={{ mt: 2 }}>
//                   <Warning sx={{ mr: 1, verticalAlign: 'middle' }} />
//                   注意：单次查询返回数据量不超过10万条，复杂查询建议设置查询条件限制范围。
//                 </Alert>
//               </Box>

//               {/* 2.2 模板定制（零代码） */}
//               <Box>
//                 <Typography variant="h5" sx={{ mb: 3, color: theme.palette.primary.main }}>
//                   2.2 模板定制（零代码）
//                 </Typography>
//                 <Alert severity="info" sx={{ mb: 3 }}>
//                   <Help sx={{ mr: 1, verticalAlign: 'middle' }} />
//                   适用于无SQL基础的用户，通过填写预定义模板获取数据。
//                 </Alert>

//                 <Typography variant="h6" sx={{ mb: 2 }}>操作步骤：</Typography>
//                 <TableContainer sx={{ mb: 3 }}>
//                   <Table bordered>
//                     <TableHead>
//                       <TableRow>
//                         <TableCell>步骤</TableCell>
//                         <TableCell>操作</TableCell>
//                         <TableCell>说明</TableCell>
//                       </TableRow>
//                     </TableHead>
//                     <TableBody>
//                       <TableRow>
//                         <TableCell>1</TableCell>
//                         <TableCell>选择模板</TableCell>
//                         <TableCell>从「模板库」中选择业务相关模板（如“销售数据查询”“用户画像分析”）</TableCell>
//                       </TableRow>
//                       <TableRow>
//                         <TableCell>2</TableCell>
//                         <TableCell>填写参数</TableCell>
//                         <TableCell>在模板表单中填写查询条件（如时间范围、区域、产品类型等），支持日期选择器、下拉框等可视化组件</TableCell>
//                       </TableRow>
//                       <TableRow>
//                         <TableCell>3</TableCell>
//                         <TableCell>预览与确认</TableCell>
//                         <TableCell>点击「预览数据」查看前10条结果，确认无误后点击「获取完整数据」</TableCell>
//                       </TableRow>
//                       <TableRow>
//                         <TableCell>4</TableCell>
//                         <TableCell>导出或分析</TableCell>
//                         <TableCell>结果支持Excel导出，或直接点击「进入分析」跳转至数据分析模块</TableCell>
//                       </TableRow>
//                     </TableBody>
//                   </Table>
//                 </TableContainer>
//               </Box>
//             </CardContent>
//           </Card>

//           {/* 3. 数据分析 */}
//           <Card elevation={2} sx={{ mb: 6 }}>
//             <Box sx={{ bgColor: theme.palette.primary.main, p: 3 }}>
//               <Typography variant="h4" sx={{ color: '#fff', display: 'flex', alignItems: 'center' }}>
//                 <Insights sx={{ mr: 2 }} />
//                 数据分析
//               </Typography>
//             </Box>
//             <CardContent sx={{ p: 4 }}>
//               <Typography variant="body1" paragraph>
//                 平台提供多种预置分析工具，支持对获取的数据进行全方位分析，无需手动编写分析代码。
//               </Typography>

//               <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: 'repeat(2, 1fr)' }, gap: 3, mb: 4 }}>
//                 {/* 3.1 概要分析 */}
//                 <Card elevation={1} sx={{ p: 3 }}>
//                   <Typography variant="h6" sx={{ mb: 2, display: 'flex', alignItems: 'center' }}>
//                     <FilterList sx={{ mr: 1 }} /> 概要分析
//                   </Typography>
//                   <Typography variant="body2" paragraph>
//                     自动生成数据整体统计信息，包括字段类型、非空值数量、均值、中位数、最大值、最小值等。
//                   </Typography>
//                   <Typography variant="subtitle2" color="text.secondary">
//                     操作入口：数据结果页 → 点击「分析工具」→「概要分析」
//                   </Typography>
//                 </Card>

//                 {/* 3.2 相关性分析 */}
//                 <Card elevation={1} sx={{ p: 3 }}>
//                   <Typography variant="h6" sx={{ mb: 2, display: 'flex', alignItems: 'center' }}>
//                     <Timeline sx={{ mr: 1 }} /> 相关性分析
//                   </Typography>
//                   <Typography variant="body2" paragraph>
//                     计算数值型字段间的相关系数（如皮尔逊系数），生成热力图，直观展示变量间关联强度。
//                   </Typography>
//                   <Typography variant="subtitle2" color="text.secondary">
//                     操作入口：数据结果页 → 点击「分析工具」→「相关性分析」
//                   </Typography>
//                 </Card>

//                 {/* 3.3 特征分析 */}
//                 <Card elevation={1} sx={{ p: 3 }}>
//                   <Typography variant="h6" sx={{ mb: 2, display: 'flex', alignItems: 'center' }}>
//                     <DataObject sx={{ mr: 1 }} /> 特征分析
//                   </Typography>
//                   <Typography variant="body2" paragraph>
//                     对分类字段生成分布直方图，对数值字段生成箱线图/密度图，识别异常值和分布特征。
//                   </Typography>
//                   <Typography variant="subtitle2" color="text.secondary">
//                     操作入口：数据结果页 → 点击字段名右侧「分析」→「特征分布」
//                   </Typography>
//                 </Card>

//                 {/* 3.4 下钻与时间序列分析 */}
//                 <Card elevation={1} sx={{ p: 3 }}>
//                   <Typography variant="h6" sx={{ mb: 2, display: 'flex', alignItems: 'center' }}>
//                     <ImportExport sx={{ mr: 1 }} /> 下钻与时间序列
//                   </Typography>
//                   <Typography variant="body2" paragraph>
//                     支持按维度（如区域、渠道）下钻查看细分数据；对含时间字段的数据自动生成趋势图，支持按日/周/月聚合。
//                   </Typography>
//                   <Typography variant="subtitle2" color="text.secondary">
//                     操作入口：分析结果页 → 点击图表「下钻」按钮 / 切换「时间粒度」
//                   </Typography>
//                 </Card>
//               </Box>

//               <Alert severity="success">
//                 <CheckCircle sx={{ mr: 1 }} /> 所有分析结果支持一键导出为PDF报告，或生成在线共享链接。
//               </Alert>
//             </CardContent>
//           </Card>

//           {/* 4. 模型推理调试 */}
//           <Card elevation={2} sx={{ mb: 6 }}>
//             <Box sx={{ bgColor: theme.palette.primary.main, p: 3 }}>
//               <Typography variant="h4" sx={{ color: '#fff', display: 'flex', alignItems: 'center' }}>
//                 <BugReport sx={{ mr: 2 }} />
//                 模型推理调试
//               </Typography>
//             </Box>
//             <CardContent sx={{ p: 4 }}>
//               <Typography variant="body1" paragraph>
//                 平台内置模型推理引擎，支持加载预置模型或自定义模型，同时提供可视化调试工具，帮助定位数据问题。
//               </Typography>

//               <Typography variant="h5" sx={{ mb: 3 }}>核心功能与操作：</Typography>
              
//               <Accordion defaultExpanded sx={{ mb: 2 }}>
//                 <AccordionSummary expandIcon={<ExpandMore />}>
//                   <Typography>输入数据验证</Typography>
//                 </AccordionSummary>
//                 <AccordionDetails>
//                   <List>
//                     <ListItem>
//                       <ListItemText 
//                         primary="操作步骤" 
//                         secondary="1. 上传推理数据（支持Excel/CSV）；2. 点击「数据验证」；3. 查看验证结果（格式错误、缺失值、超出范围值会标红提示）" 
//                       />
//                     </ListItem>
//                     <ListItem>
//                       <ListItemText 
//                         primary="常见问题处理" 
//                         secondary="缺失值：可选择「均值填充」「中位数填充」或「手动输入」；格式错误：系统提供自动转换建议（如字符串转日期）" 
//                       />
//                     </ListItem>
//                   </List>
//                 </AccordionDetails>
//               </Accordion>

//               <Accordion sx={{ mb: 2 }}>
//                 <AccordionSummary expandIcon={<ExpandMore />}>
//                   <Typography>推理过程追踪</Typography>
//                 </AccordionSummary>
//                 <AccordionDetails>
//                   <Typography paragraph>
//                     点击「开始推理」后，系统会展示模型各层输出结果（如特征权重、中间计算值），支持：
//                   </Typography>
//                   <List dense>
//                     <ListItem>查看每一步特征转换结果</ListItem>
//                     <ListItem>对比输入数据与模型预期输入的差异</ListItem>
//                     <ListItem>定位异常预测值的来源（如某特征值异常导致）</ListItem>
//                   </List>
//                 </AccordionDetails>
//               </Accordion>

//               <Accordion sx={{ mb: 2 }}>
//                 <AccordionSummary expandIcon={<ExpandMore />}>
//                   <Typography>结果解释与调试</Typography>
//                 </AccordionSummary>
//                 <AccordionDetails>
//                   <Typography paragraph>
//                     推理完成后，系统生成：
//                   </Typography>
//                   <List dense>
//                     <ListItem>预测结果分布直方图（识别是否存在偏误）</ListItem>
//                     <ListItem>特征重要性排序（展示对结果影响最大的前10个特征）</ListItem>
//                     <ListItem>错误案例分析（列出预测错误的样本及可能原因）</ListItem>
//                   </List>
//                   <Typography variant="subtitle2" sx={{ mt: 2 }}>
//                     调试入口：结果页 → 点击「错误样本」→ 查看「调试建议」
//                   </Typography>
//                 </AccordionDetails>
//               </Accordion>
//             </CardContent>
//           </Card>

//           {/* 5. 管理员风险防控 */}
//           <Card elevation={2} sx={{ mb: 6 }}>
//             <Box sx={{ bgColor: theme.palette.secondary.main, p: 3 }}>
//               <Typography variant="h4" sx={{ color: '#fff', display: 'flex', alignItems: 'center' }}>
//                 <Shield sx={{ mr: 2 }} />
//                 管理员风险防控
//               </Typography>
//             </Box>
//             <CardContent sx={{ p: 4 }}>
//               <Typography variant="body1" paragraph>
//                 管理员可通过以下策略保障平台数据安全与合规性，防范数据泄露、滥用等风险。
//               </Typography>

//               <Box sx={{ mb: 4 }}>
//                 <Typography variant="h5" sx={{ mb: 3, color: theme.palette.secondary.main }}>
//                   5.1 数据权限管理
//                 </Typography>
//                 <TableContainer>
//                   <Table>
//                     <TableHead>
//                       <TableRow>
//                         <TableCell>防控措施</TableCell>
//                         <TableCell>操作路径</TableCell>
//                         <TableCell>风险点</TableCell>
//                       </TableRow>
//                     </TableHead>
//                     <TableBody>
//                       <TableRow>
//                         <TableCell>数据源权限隔离</TableCell>
//                         <TableCell>「系统管理」→「数据源权限」→ 按角色分配数据源访问权限</TableCell>
//                         <TableCell>未授权用户访问敏感数据源（如客户隐私数据）</TableCell>
//                       </TableRow>
//                       <TableRow>
//                         <TableCell>字段级权限控制</TableCell>
//                         <TableCell>「表管理」→ 选择表 →「字段权限」→ 隐藏/脱敏敏感字段（如手机号、身份证）</TableCell>
//                         <TableCell>敏感字段暴露（如直接展示完整身份证号）</TableCell>
//                       </TableRow>
//                       <TableRow>
//                         <TableCell>操作权限细分</TableCell>
//                         <TableCell>「用户管理」→「角色配置」→ 细化「查询/导出/修改」权限</TableCell>
//                         <TableCell>普通用户导出大量原始数据</TableCell>
//                       </TableRow>
//                     </TableBody>
//                   </Table>
//                 </TableContainer>
//               </Box>

//               <Box sx={{ mb: 4 }}>
//                 <Typography variant="h5" sx={{ mb: 3, color: theme.palette.secondary.main }}>
//                   5.2 操作审计与监控
//                 </Typography>
//                 <List>
//                   <ListItem>
//                     <ListItemIcon><Assignment /></ListItemIcon>
//                     <ListItemText 
//                       primary="操作日志查询" 
//                       secondary="「系统管理」→「操作日志」可查看所有用户的关键操作（如查询、导出、修改模板），支持按用户、时间、操作类型筛选" 
//                     />
//                   </ListItem>
//                   <ListItem>
//                     <ListItemIcon><Warning /></ListItemIcon>
//                     <ListItemText 
//                       primary="异常行为告警" 
//                       secondary="配置告警规则（如单次导出超10万条、高频查询敏感表），触发时通过邮件/短信通知管理员" 
//                     />
//                   </ListItem>
//                   <ListItem>
//                     <ListItemIcon><FileCopy /></ListItemIcon>
//                     <ListItemText 
//                       primary="数据导出水印" 
//                       secondary="开启「导出水印」功能，所有导出文件自动添加用户名+时间戳，追溯数据传播路径" 
//                     />
//                   </ListItem>
//                 </List>
//               </Box>

//               <Box>
//                 <Typography variant="h5" sx={{ mb: 3, color: theme.palette.secondary.main }}>
//                   5.3 系统安全设置
//                 </Typography>
//                 <Alert severity="warning" sx={{ mb: 3 }}>
//                   <Lock sx={{ mr: 1 }} /> 定期进行安全配置检查，建议每季度更新一次策略。
//                 </Alert>
//                 <List>
//                   <ListItem>
//                     <ListItemText primary="会话超时控制" secondary="设置自动登出时间（如30分钟无操作），路径：「系统设置」→「安全配置」" />
//                   </ListItem>
//                   <ListItem>
//                     <ListItemText primary="IP白名单" secondary="限制仅指定IP段可访问平台，适合内部敏感数据场景" />
//                   </ListItem>
//                   <ListItem>
//                     <ListItemText primary="定期权限审计" secondary="每季度 review 所有用户权限，移除不再需要的访问权限" />
//                   </ListItem>
//                 </List>
//               </Box>
//             </CardContent>
//           </Card>
//         </Box>
//       </Box>
//     </Container>
//   );
// };

// export default HelpPage;

// import React from 'react';
// import { Container, Typography, Box, Paper, Divider, List, ListItem, ListItemIcon, ListItemText } from '@mui/material';
// import { DataObject, Insights, BugReport, ImportExport, Settings, Description } from '@mui/icons-material';

// const HelpPage = () => {
//   return (
//     <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
//       <Typography variant="h4" gutterBottom>
//         产品功能说明
//       </Typography>
      
//       <Paper sx={{ p: 3, mb: 4 }}>
//         <Typography variant="h6" gutterBottom>
//           产品概述
//         </Typography>
//         <Typography paragraph>
//           本产品是一款面向业务人员的数据管理与分析平台，旨在简化数据获取、分析和模型推理调试流程，帮助业务人员快速获取有价值的数据分析结果。
//         </Typography>
//       </Paper>
      
//       <Box sx={{ mb: 4 }}>
//         <Typography variant="h5" gutterBottom>
//           核心功能
//         </Typography>
        
//         {/* 数据获取部分 */}
//         <Paper sx={{ p: 3, mb: 3 }}>
//           <Typography variant="h6" sx={{ mb: 2, display: 'flex', alignItems: 'center' }}>
//             <DataObject sx={{ mr: 1 }} />
//             1. 数据获取
//           </Typography>
//           <Divider sx={{ mb: 2 }} />
          
//           <List>
//             <ListItem>
//               <ListItemIcon><ImportExport /></ListItemIcon>
//               <ListItemText 
//                 primary="数据直通车" 
//                 secondary="面向会写SQL的人员，DBA配置数据表和视图并赋予权限后，用户可通过编写SQL直接获取数据"
//               />
//             </ListItem>
//             <ListItem>
//               <ListItemIcon><Settings /></ListItemIcon>
//               <ListItemText 
//                 primary="模板定制" 
//                 secondary="管理员通过后台配置低代码JSON生成前端取数配置页面，用户配置后生成取数清单，由后台Python程序实现取数并保存入库（支持二次开发）"
//               />
//             </ListItem>
//           </List>
//         </Paper>
        
//         {/* 数据分析部分 */}
//         <Paper sx={{ p: 3, mb: 3 }}>
//           <Typography variant="h6" sx={{ mb: 2, display: 'flex', alignItems: 'center' }}>
//             <Insights sx={{ mr: 1 }} />
//             2. 数据分析
//           </Typography>
//           <Divider sx={{ mb: 2 }} />
          
//           <Typography paragraph sx={{ ml: 2 }}>
//             提供全方位数据分析功能，方便用户深入了解数据特征：
//           </Typography>
//           <List>
//             <ListItem>
//               <ListItemText primary="概要分析" secondary="数据整体情况概览，包括基本统计量、数据分布等" />
//             </ListItem>
//             <ListItem>
//               <ListItemText primary="相关性分析" secondary="分析变量之间的相关关系，识别关键影响因素" />
//             </ListItem>
//             <ListItem>
//               <ListItemText primary="特征分析" secondary="深入分析各特征的分布、重要性及对结果的影响" />
//             </ListItem>
//             <ListItem>
//               <ListItemText primary="PCA分析" secondary="主成分分析，简化数据维度同时保留关键信息" />
//             </ListItem>
//             <ListItem>
//               <ListItemText primary="下钻与时间序列分析" secondary="支持多维度下钻分析和时间序列趋势统计" />
//             </ListItem>
//           </List>
//         </Paper>
        
//         {/* 模型推理调试部分 */}
//         <Paper sx={{ p: 3 }}>
//           <Typography variant="h6" sx={{ mb: 2, display: 'flex', alignItems: 'center' }}>
//             <BugReport sx={{ mr: 1 }} />
//             3. 模型推理时的数据调试
//           </Typography>
//           <Divider sx={{ mb: 2 }} />
          
//           <Typography paragraph sx={{ ml: 2 }}>
//             提供直观的模型推理调试界面，帮助用户：
//           </Typography>
//           <List>
//             <ListItem>
//               <ListItemText primary="输入数据验证" secondary="检查输入数据格式、范围及完整性" />
//             </ListItem>
//             <ListItem>
//               <ListItemText primary="推理过程追踪" secondary="跟踪模型推理的中间结果，识别异常点" />
//             </ListItem>
//             <ListItem>
//               <ListItemText primary="结果解释" secondary="对模型输出结果进行解释，增强结果可信度" />
//             </ListItem>
//             <ListItem>
//               <ListItemText primary="问题诊断" secondary="快速定位推理过程中的数据问题，提供解决方案建议" />
//             </ListItem>
//           </List>
//         </Paper>
//       </Box>
//     </Container>
//   );
// };

// export default HelpPage;