import React, { useState, useEffect } from 'react';
import {
  Box, Typography, Paper, Table, TableBody, TableCell, TableContainer,
  TableHead, TableRow, Select, MenuItem, Button, Grid, CircularProgress,
  TextField, IconButton, Tabs, Tab, List, ListItem, ListItemText,
  Divider, Dialog, DialogTitle, DialogContent, DialogActions
} from '@mui/material';
import {
  DataObject, TableChart, ShowChart, Storage,
  Refresh, Delete, Add, Description, UploadFile,
  Folder, InsertDriveFile, Close
} from '@mui/icons-material';

const DataAnalysis = () => {
  const [tabValue, setTabValue] = useState('upload');
  const [dataFiles, setDataFiles] = useState([]);
  const [selectedFile, setSelectedFile] = useState('');
  const [fileType, setFileType] = useState('csv');
  const [columns, setColumns] = useState([]);
  const [selectedColumns, setSelectedColumns] = useState([]);
  const [analysisType, setAnalysisType] = useState('overview');
  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(false);
  const [uploadDialogOpen, setUploadDialogOpen] = useState(false);
  const [selectedUploadFile, setSelectedUploadFile] = useState(null);

  // 获取文件列表
  useEffect(() => {
    if (tabValue === 'browse') {
      fetch('/files')
        .then(res => res.json())
        .then(data => setDataFiles(data));
    }
  }, [tabValue]);

  // 获取选定文件的列
  useEffect(() => {
    if (selectedFile && tabValue === 'browse') {
      fetch('/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          filePath: `data/${selectedFile}`,
          fileType: fileType,
          analysisType: 'columns' // 假设后端支持仅获取列名
        })
      })
      .then(res => res.json())
      .then(data => setColumns(data.columns || []))
      .catch(err => console.error(err));
    }
  }, [selectedFile, fileType, tabValue]);

  const handleFileUpload = (event) => {
    const file = event.target.files[0];
    if (file) {
      setSelectedUploadFile(file);
    }
  };

  const handleUploadConfirm = () => {
    if (!selectedUploadFile) return;

    const formData = new FormData();
    formData.append('file', selectedUploadFile);

    setLoading(true);
    fetch('/upload', {
      method: 'POST',
      body: formData
    })
    .then(res => res.json())
    .then(data => {
      setTabValue('browse');
      setSelectedFile(selectedUploadFile.name);
      setUploadDialogOpen(false);
      setSelectedUploadFile(null);
      setLoading(false);
    })
    .catch(err => {
      console.error(err);
      setLoading(false);
    });
  };

  const handleAnalyze = () => {
    setLoading(true);

    let requestBody;
    if (tabValue === 'upload' && selectedUploadFile) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const content = e.target.result;

        requestBody = {
          fileContent: Array.from(new Uint8Array(content)),
          fileType: fileType,
          columns: selectedColumns,
          analysisType: analysisType
        };

        sendAnalysisRequest(requestBody);
      };
      reader.readAsArrayBuffer(selectedUploadFile);
    } else if (tabValue === 'browse' && selectedFile) {
      requestBody = {
        filePath: `data/${selectedFile}`,
        fileType: fileType,
        columns: selectedColumns,
        analysisType: analysisType
      };

      sendAnalysisRequest(requestBody);
    } else {
      setLoading(false);
      return;
    }
  };

  const sendAnalysisRequest = (requestBody) => {
    fetch('/analyze', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(requestBody)
    })
    .then(res => res.json())
    .then(data => {
      setResults(data);
      setLoading(false);
    })
    .catch(err => {
      console.error(err);
      setLoading(false);
    });
  };

  const renderOverview = () => {
    // 同之前的实现
  };

  const renderCorrelation = () => {
    // 同之前的实现
  };

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h4" gutterBottom>
        <DataObject sx={{ verticalAlign: 'middle', mr: 1 }} />
        Data Analysis Tool
      </Typography>

      <Paper sx={{ p: 3, mb: 3 }}>
        <Tabs value={tabValue} onChange={(e, newValue) => setTabValue(newValue)}>
          <Tab label="Upload File" value="upload" icon={<UploadFile />} />
          <Tab label="Browse Files" value="browse" icon={<Folder />} />
        </Tabs>

        <Divider sx={{ my: 2 }} />

        {tabValue === 'upload' && (
          <Grid container spacing={2} alignItems="center">
            <Grid item xs={12} md={4}>
              <Button
                variant="outlined"
                component="label"
                fullWidth
                startIcon={<InsertDriveFile />}
              >
                Select File
                <input
                  type="file"
                  hidden
                  onChange={handleFileUpload}
                  accept=".csv,.xlsx,.json"
                />
              </Button>
            </Grid>

            <Grid item xs={12} md={2}>
              <Select
                fullWidth
                value={fileType}
                onChange={(e) => setFileType(e.target.value)}
              >
                <MenuItem value="csv">CSV</MenuItem>
                <MenuItem value="excel">Excel</MenuItem>
                <MenuItem value="json">JSON</MenuItem>
              </Select>
            </Grid>

            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                value={selectedUploadFile ? selectedUploadFile.name : 'No file selected'}
                InputProps={{
                  readOnly: true,
                  endAdornment: selectedUploadFile && (
                    <IconButton onClick={() => setSelectedUploadFile(null)}>
                      <Close />
                    </IconButton>
                  )
                }}
              />
            </Grid>
          </Grid>
        )}

        {tabValue === 'browse' && (
          <Grid container spacing={2} alignItems="center">
            <Grid item xs={12} md={6}>
              <Select
                fullWidth
                value={selectedFile}
                onChange={(e) => setSelectedFile(e.target.value)}
                displayEmpty
                startAdornment={<Folder sx={{ mr: 1 }} />}
              >
                <MenuItem value=""><em>Select File</em></MenuItem>
                {dataFiles.map(file => (
                  <MenuItem key={file.name} value={file.name}>
                    {file.name} ({Math.round(file.size / 1024)} KB)
                  </MenuItem>
                ))}
              </Select>
            </Grid>

            <Grid item xs={12} md={2}>
              <Select
                fullWidth
                value={fileType}
                onChange={(e) => setFileType(e.target.value)}
              >
                <MenuItem value="csv">CSV</MenuItem>
                <MenuItem value="excel">Excel</MenuItem>
                <MenuItem value="json">JSON</MenuItem>
              </Select>
            </Grid>

            <Grid item xs={12} md={4}>
              <Button
                variant="contained"
                onClick={() => setUploadDialogOpen(true)}
                fullWidth
                startIcon={<UploadFile />}
              >
                Upload New
              </Button>
            </Grid>
          </Grid>
        )}

        {(selectedUploadFile || selectedFile) && (
          <>
            <Grid container spacing={2} mt={2} alignItems="center">
              <Grid item xs={12} md={8}>
                <Select
                  fullWidth
                  multiple
                  value={selectedColumns}
                  onChange={(e) => setSelectedColumns(e.target.value)}
                  displayEmpty
                  renderValue={(selected) => selected.length ? selected.join(', ') : 'Select Columns'}
                >
                  {columns.map(col => (
                    <MenuItem key={col} value={col}>{col}</MenuItem>
                  ))}
                </Select>
              </Grid>

              <Grid item xs={12} md={2}>
                <Select
                  fullWidth
                  value={analysisType}
                  onChange={(e) => setAnalysisType(e.target.value)}
                >
                  <MenuItem value="overview">Data Overview</MenuItem>
                  <MenuItem value="correlation">Correlation</MenuItem>
                  <MenuItem value="full">Full Analysis</MenuItem>
                </Select>
              </Grid>

              <Grid item xs={12} md={2}>
                <Button
                  fullWidth
                  variant="contained"
                  onClick={handleAnalyze}
                  disabled={selectedColumns.length === 0}
                  startIcon={<Refresh />}
                >
                  Analyze
                </Button>
              </Grid>
            </Grid>
          </>
        )}
      </Paper>

      {loading && (
        <Box textAlign="center" mt={4}>
          <CircularProgress />
          <Typography>Analyzing data...</Typography>
        </Box>
      )}

      {results && (
        <>
          {renderOverview()}
          {renderCorrelation()}
        </>
      )}

      <Dialog open={uploadDialogOpen} onClose={() => setUploadDialogOpen(false)}>
        <DialogTitle>Upload New File</DialogTitle>
        <DialogContent>
          <Box sx={{ p: 2 }}>
            <Button
              variant="outlined"
              component="label"
              fullWidth
              startIcon={<UploadFile />}
            >
              Select File
              <input
                type="file"
                hidden
                onChange={handleFileUpload}
                accept=".csv,.xlsx,.json"
              />
            </Button>

            {selectedUploadFile && (
              <Box mt={2}>
                <Typography variant="body2">
                  Selected: {selectedUploadFile.name}
                </Typography>
              </Box>
            )}
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setUploadDialogOpen(false)}>Cancel</Button>
          <Button
            onClick={handleUploadConfirm}
            disabled={!selectedUploadFile}
            variant="contained"
          >
            Upload
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default DataAnalysis;


//import React, { useState, useEffect } from 'react';
//import {
//    Card, Select, Button, Row, Col, DatePicker, Divider, Spin,
//    Collapse, Form, Input, Slider, Tabs, Empty, message, Upload,
//    Modal, Space, Radio, Tooltip
//} from 'antd';
//import {
//    BarChartOutlined, LineChartOutlined, PieChartOutlined,
//    TableOutlined, AppstoreAddOutlined, DeleteOutlined,
//    EditOutlined, DragOutlined, UploadOutlined,
//    ScheduleOutlined, AppstoreOutlined, DownOutlined, UpOutlined,
//    SyncOutlined
//} from '@ant-design/icons';
//import { Chart } from 'react-chartjs-2';
//import { Chart as ChartJS, registerables } from 'chart.js';
//import 'chartjs-plugin-datalabels';
//import { Table } from 'antd';
//import { DndContext, DragOverlay, closestCenter } from '@dnd-kit/core';
//import { arrayMove, SortableContext, horizontalListSortingStrategy } from '@dnd-kit/sortable';
//import { restrictToHorizontalAxis } from '@dnd-kit/modifiers';
//import { useSortable } from '@dnd-kit/sortable';
//import { CSS } from '@dnd-kit/utilities';
//import { Gantt } from 'gantt-task-react';
//import "gantt-task-react/dist/index.css";
//import Papa from 'papaparse';
//import { read, utils } from 'xlsx';
//
//ChartJS.register(...registerables);
//
//const { Option } = Select;
//const { Panel } = Collapse;
//const { TabPane } = Tabs;
//const { Dragger } = Upload;
//
//// 可拖拽的展示项组件
//const SortableItem = ({ id, children, span }) => {
//    const {
//        attributes,
//        listeners,
//        setNodeRef,
//        transform,
//        transition,
//        isDragging,
//    } = useSortable({ id });
//
//    const style = {
//        transform: CSS.Transform.toString(transform),
//        transition,
//        opacity: isDragging ? 0.5 : 1,
//    };
//
//    return (
//        <Col span={span} ref={setNodeRef} style={style} {...attributes}>
//            <Card
//                title={
//                    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
//                        <span>{children.props.title}</span>
//                        <div>
//                            <Tooltip title="拖拽排序">
//                                <Button
//                                    type="text"
//                                    icon={<DragOutlined />}
//                                    {...listeners}
//                                    style={{ cursor: 'move' }}
//                                />
//                            </Tooltip>
//                            <Tooltip title="编辑">
//                                <Button
//                                    type="text"
//                                    icon={<EditOutlined />}
//                                    onClick={() => children.props.onEdit()}
//                                />
//                            </Tooltip>
//                            <Tooltip title="删除">
//                                <Button
//                                    type="text"
//                                    icon={<DeleteOutlined />}
//                                    onClick={() => children.props.onDelete()}
//                                />
//                            </Tooltip>
//                        </div>
//                    </div>
//                }
//            >
//                {children}
//            </Card>
//        </Col>
//    );
//};
//
//// 可视化组件类型
//const CHART_TYPES = {
//    line: { name: '折线图', icon: <LineChartOutlined /> },
//    bar: { name: '柱状图', icon: <BarChartOutlined /> },
//    pie: { name: '饼图', icon: <PieChartOutlined /> },
//    table: { name: '表格', icon: <TableOutlined /> },
//    pivot: { name: '透视表', icon: <AppstoreOutlined /> },
//    gantt: { name: '甘特图', icon: <ScheduleOutlined /> },
//};
//
//// 配置表单组件 - 提取为独立组件
//const ConfigForm = ({
//    type,
//    form,
//    dimensions,
//    metrics,
//    onValuesChange
//}) => {
//    // 获取当前表单值
//    const formValues = Form.useWatch([], form);
//
//    useEffect(() => {
//        // 当图表类型变化时重置表单
//        form.resetFields();
//    }, [type, form]);
//
//    // 根据当前选择过滤可用字段
//    const getAvailableFields = (currentField, excludeFields = []) => {
//        const allFields = [...dimensions, ...metrics];
//        return allFields.filter(
//            field => !excludeFields.includes(field.field) &&
//                    field.field !== currentField
//        );
//    };
//
//    // 获取可用的Y轴字段（数值字段，且不等于X轴字段）
//    const getAvailableYFields = () => {
//        const xField = formValues?.xField;
//        return metrics.filter(metric =>
//            metric.field !== xField
//        );
//    };
//
//    // 获取可用的数值字段（数值字段，且不等于分类字段）
//    const getAvailableValueFields = () => {
//        const categoryField = formValues?.categoryField;
//        return metrics.filter(metric =>
//            metric.field !== categoryField
//        );
//    };
//
//    // 获取可用的透视表数值字段（数值字段，且不等于行或列维度字段）
//    const getAvailablePivotValues = () => {
//        const rows = formValues?.rows || [];
//        const cols = formValues?.cols || [];
//        const excludedFields = [...rows, ...cols];
//        return metrics.filter(metric =>
//            !excludedFields.includes(metric.field)
//        );
//    };
//
//    const renderFormItems = () => {
//        switch (type) {
//            case 'line':
//            case 'bar':
//                return (
//                    <>
//                        <Form.Item label="X轴" name="xField" rules={[{ required: true, message: '请选择X轴字段' }]}>
//                            <Select
//                                placeholder="选择X轴字段"
//                                onChange={() => {
//                                    // 当X轴变化时，重置Y轴选择
//                                    form.setFieldsValue({ yField: undefined });
//                                }}
//                            >
//                                {dimensions.map(dim => (
//                                    <Option key={dim.field} value={dim.field}>{dim.name}</Option>
//                                ))}
//                            </Select>
//                        </Form.Item>
//                        <Form.Item label="Y轴" name="yField" rules={[{ required: true, message: '请选择Y轴字段' }]}>
//                            <Select
//                                mode="multiple"
//                                placeholder={formValues?.xField ? "选择Y轴字段" : "请先选择X轴"}
//                                disabled={!formValues?.xField}
//                            >
//                                {getAvailableYFields().map(metric => (
//                                    <Option key={metric.field} value={metric.field}>{metric.name}</Option>
//                                ))}
//                            </Select>
//                        </Form.Item>
//                    </>
//                );
//            case 'pie':
//                return (
//                    <>
//                        <Form.Item label="分类字段" name="categoryField" rules={[{ required: true, message: '请选择分类字段' }]}>
//                            <Select
//                                placeholder="选择分类字段"
//                                onChange={() => {
//                                    // 当分类字段变化时，重置数值字段
//                                    form.setFieldsValue({ valueField: undefined });
//                                }}
//                            >
//                                {dimensions.map(dim => (
//                                    <Option key={dim.field} value={dim.field}>{dim.name}</Option>
//                                ))}
//                            </Select>
//                        </Form.Item>
//                        <Form.Item label="数值字段" name="valueField" rules={[{ required: true, message: '请选择数值字段' }]}>
//                            <Select
//                                placeholder={formValues?.categoryField ? "选择数值字段" : "请先选择分类字段"}
//                                disabled={!formValues?.categoryField}
//                            >
//                                {getAvailableValueFields().map(metric => (
//                                    <Option key={metric.field} value={metric.field}>{metric.name}</Option>
//                                ))}
//                            </Select>
//                        </Form.Item>
//                    </>
//                );
//            case 'table':
//                return (
//                    <Form.Item label="显示列" name="columns" rules={[{ required: true, message: '请选择显示列' }]}>
//                        <Select mode="multiple" placeholder="选择要显示的列">
//                            {[...dimensions, ...metrics].map(item => (
//                                <Option key={item.field} value={item.field}>{item.name}</Option>
//                            ))}
//                        </Select>
//                    </Form.Item>
//                );
//            case 'pivot':
//                return (
//                    <>
//                        <Form.Item label="行维度" name="rows" rules={[{ required: true, message: '请选择行维度' }]}>
//                            <Select
//                                mode="multiple"
//                                placeholder="选择行维度"
//                                onChange={() => {
//                                    // 当行维度变化时，检查并过滤数值字段
//                                    const currentValues = form.getFieldValue('values') || [];
//                                    const availableValues = getAvailablePivotValues();
//                                    const filteredValues = currentValues.filter(value =>
//                                        availableValues.some(av => av.field === value)
//                                    );
//                                    if (filteredValues.length < currentValues.length) {
//                                        form.setFieldsValue({ values: filteredValues });
//                                    }
//                                }}
//                            >
//                                {dimensions.map(dim => (
//                                    <Option key={dim.field} value={dim.field}>{dim.name}</Option>
//                                ))}
//                            </Select>
//                        </Form.Item>
//                        <Form.Item label="列维度" name="cols">
//                            <Select
//                                mode="multiple"
//                                placeholder="选择列维度"
//                                onChange={() => {
//                                    // 当列维度变化时，检查并过滤数值字段
//                                    const currentValues = form.getFieldValue('values') || [];
//                                    const availableValues = getAvailablePivotValues();
//                                    const filteredValues = currentValues.filter(value =>
//                                        availableValues.some(av => av.field === value)
//                                    );
//                                    if (filteredValues.length < currentValues.length) {
//                                        form.setFieldsValue({ values: filteredValues });
//                                    }
//                                }}
//                            >
//                                {dimensions.map(dim => (
//                                    <Option key={dim.field} value={dim.field}>{dim.name}</Option>
//                                ))}
//                            </Select>
//                        </Form.Item>
//                        <Form.Item label="数值字段" name="values" rules={[{ required: true, message: '请选择数值字段' }]}>
//                            <Select
//                                mode="multiple"
//                                placeholder="选择数值字段"
//                                disabled={!formValues?.rows || formValues?.rows.length === 0}
//                            >
//                                {getAvailablePivotValues().map(metric => (
//                                    <Option key={metric.field} value={metric.field}>{metric.name}</Option>
//                                ))}
//                            </Select>
//                        </Form.Item>
//                        <Form.Item label="聚合方式" name="aggregate" initialValue="sum">
//                            <Select>
//                                <Option value="sum">求和</Option>
//                                <Option value="avg">平均值</Option>
//                                <Option value="count">计数</Option>
//                                <Option value="max">最大值</Option>
//                                <Option value="min">最小值</Option>
//                            </Select>
//                        </Form.Item>
//                    </>
//                );
//            case 'gantt':
//                return (
//                    <>
//                        <Form.Item label="任务名称" name="taskField" rules={[{ required: true, message: '请选择任务名字段' }]}>
//                            <Select placeholder="选择任务名字段">
//                                {dimensions.map(dim => (
//                                    <Option key={dim.field} value={dim.field}>{dim.name}</Option>
//                                ))}
//                            </Select>
//                        </Form.Item>
//                        <Form.Item label="开始时间" name="startField" rules={[{ required: true, message: '请选择开始时间字段' }]}>
//                            <Select placeholder="选择开始时间字段">
//                                {dimensions.filter(d => d.field.toLowerCase().includes('date') || d.field.toLowerCase().includes('time')).map(dim => (
//                                    <Option key={dim.field} value={dim.field}>{dim.name}</Option>
//                                ))}
//                            </Select>
//                        </Form.Item>
//                        <Form.Item label="结束时间" name="endField" rules={[{ required: true, message: '请选择结束时间字段' }]}>
//                            <Select placeholder="选择结束时间字段">
//                                {dimensions.filter(d => d.field.toLowerCase().includes('date') || d.field.toLowerCase().includes('time')).map(dim => (
//                                    <Option key={dim.field} value={dim.field}>{dim.name}</Option>
//                                ))}
//                            </Select>
//                        </Form.Item>
//                        <Form.Item label="进度" name="progressField">
//                            <Select placeholder="选择进度字段(可选)">
//                                {metrics.map(metric => (
//                                    <Option key={metric.field} value={metric.field}>{metric.name}</Option>
//                                ))}
//                            </Select>
//                        </Form.Item>
//                        <Form.Item label="任务类型" name="typeField">
//                            <Select placeholder="选择任务类型字段(可选)">
//                                {dimensions.map(dim => (
//                                    <Option key={dim.field} value={dim.field}>{dim.name}</Option>
//                                ))}
//                            </Select>
//                        </Form.Item>
//                    </>
//                );
//            default:
//                return null;
//        }
//    };
//
//    return (
//        <Form
//            form={form}
//            layout="vertical"
//            onValuesChange={onValuesChange}
//        >
//            <Form.Item label="标题" name="title">
//                <Input placeholder="输入组件标题" />
//            </Form.Item>
//            <Form.Item label="宽度占比" name="span" initialValue={8}>
//                <Slider
//                    min={4}
//                    max={24}
//                    step={4}
//                    marks={{ 4: '1/6', 8: '1/3', 12: '1/2', 16: '2/3', 20: '5/6', 24: '100%' }}
//                />
//            </Form.Item>
//
//            {renderFormItems()}
//        </Form>
//    );
//};
//
//const DataAnalysis = ({ initialData, onDataUpdate }) => {
//    const [loading, setLoading] = useState(false);
//    const [updating, setUpdating] = useState(false);
//    const [dimensions, setDimensions] = useState([]);
//    const [metrics, setMetrics] = useState([]);
//    const [activeTab, setActiveTab] = useState('line');
//    const [configForm] = Form.useForm();
//    const [widgets, setWidgets] = useState([]);
//    const [activeId, setActiveId] = useState(null);
//    const [dataSource, setDataSource] = useState(initialData || []);
//    const [dataConfigVisible, setDataConfigVisible] = useState(false);
//    const [dataSourceType, setDataSourceType] = useState(initialData ? 'initial' : 'upload');
//    const [configCollapsed, setConfigCollapsed] = useState(false);
//
//    // 获取维度和指标
//    useEffect(() => {
//        if (dataSource.length > 0) {
//            extractDimensionsAndMetrics();
//        }
//    }, [dataSource]);
//
//    const extractDimensionsAndMetrics = () => {
//        if (dataSource.length === 0) return;
//
//        try {
//            const sampleItem = dataSource[0];
//            const extractedDims = [];
//            const extractedMetrics = [];
//
//            Object.keys(sampleItem).forEach(key => {
//                const value = sampleItem[key];
//
//                // 更严格的数值检测
//                const isNumeric = (val) => {
//                    if (typeof val === 'number') return true;
//                    if (typeof val === 'string') {
//                        // 检查是否能转换为数字
//                        return !isNaN(val) && !isNaN(parseFloat(val));
//                    }
//                    return false;
//                };
//
//                if (value instanceof Date ||
//                    (typeof value === 'string' && !isNumeric(value))) {
//                    extractedDims.push({ field: key, name: key });
//                } else if (isNumeric(value)) {
//                    extractedMetrics.push({ field: key, name: key });
//                }
//            });
//
//            setDimensions(extractedDims);
//            setMetrics(extractedMetrics);
//
//            // 打印识别结果用于调试
//            console.log('维度字段:', extractedDims);
//            console.log('指标字段:', extractedMetrics);
//        } catch (error) {
//            console.error('Error extracting dimensions and metrics:', error);
//            message.error('提取数据字段失败');
//        }
//    };
//
//    // 处理上传数据
//    const handleUpload = (file) => {
//        const reader = new FileReader();
//        reader.onload = (e) => {
//            try {
//                let data;
//                if (file.type === 'text/csv') {
//                    const result = Papa.parse(e.target.result, { header: true });
//                    data = result.data;
//                } else if (file.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || file.type === 'application/vnd.ms-excel') {
//                    const workbook = read(e.target.result, { type: 'binary' });
//                    const firstSheetName = workbook.SheetNames[0];
//                    const worksheet = workbook.Sheets[firstSheetName];
//                    data = utils.sheet_to_json(worksheet);
//                } else {
//                    message.error('仅支持 CSV 或 Excel 文件');
//                    return;
//                }
//
//                if (Array.isArray(data)) {
//                    setDataSource(data);
//                    setDataConfigVisible(false);
//                    message.success('数据上传成功');
//                } else {
//                    message.error('上传的数据必须是数组格式');
//                }
//            } catch (err) {
//                console.error('Error parsing uploaded file:', err);
//                message.error('解析上传文件失败');
//            }
//        };
//
//        if (file.type === 'text/csv') {
//            reader.readAsText(file);
//        } else {
//            reader.readAsBinaryString(file);
//        }
//        return false; // 阻止默认上传行为
//    };
//
//    // 更新数据
//    const handleUpdateData = async () => {
//        if (!onDataUpdate) {
//            message.warning('未配置数据更新函数');
//            return;
//        }
//
//        try {
//            setUpdating(true);
//            const newData = await onDataUpdate(dataSource);
//            if (Array.isArray(newData)) {
//                setDataSource(newData);
//                message.success('数据更新成功');
//            } else {
//                message.error('返回的数据格式不正确');
//            }
//        } catch (error) {
//            console.error('Error updating data:', error);
//            message.error('数据更新失败');
//        } finally {
//            setUpdating(false);
//        }
//    };
//
//    // 添加可视化组件
//    const addWidget = () => {
//        if (dataSource.length === 0) {
//            message.error('请先配置数据');
//            return;
//        }
//        configForm.validateFields().then(values => {
//            const newWidget = {
//                id: `widget-${Date.now()}`,
//                type: activeTab,
//                title: values.title || CHART_TYPES[activeTab].name,
//                span: values.span || 8,
//                config: { ...values },
//            };
//
//            setWidgets([...widgets, newWidget]);
//            configForm.resetFields();
//            message.success('组件添加成功');
//        }).catch(err => {
//            console.error('Validation failed:', err);
//            message.error('表单验证失败，请检查配置');
//        });
//    };
//
//    // 删除组件
//    const deleteWidget = (id) => {
//        setWidgets(widgets.filter(w => w.id !== id));
//    };
//
//    // 编辑组件
//    const editWidget = (id) => {
//        const widget = widgets.find(w => w.id === id);
//        if (widget) {
//            setActiveTab(widget.type);
//            configForm.setFieldsValue({
//                ...widget.config,
//                title: widget.title,
//                span: widget.span,
//            });
//            deleteWidget(id);
//        }
//    };
//
//    // 拖拽相关函数
//    const handleDragStart = (event) => {
//        setActiveId(event.active.id);
//    };
//
//    const handleDragEnd = (event) => {
//        const { active, over } = event;
//
//        if (active.id !== over.id) {
//            setWidgets((items) => {
//                const oldIndex = items.findIndex(item => item.id === active.id);
//                const newIndex = items.findIndex(item => item.id === over.id);
//                return arrayMove(items, oldIndex, newIndex);
//            });
//        }
//
//        setActiveId(null);
//    };
//
//    // 渲染可视化组件
//    const renderWidget = (widget) => {
//        const { id, type, title, span, config } = widget;
//
//        switch (type) {
//            case 'line':
//            case 'bar':
//                return (
//                    <ChartWidget
//                        key={id}
//                        id={id}
//                        title={title}
//                        type={type}
//                        config={config}
//                        data={dataSource}
//                        onEdit={() => editWidget(id)}
//                        onDelete={() => deleteWidget(id)}
//                    />
//                );
//            case 'pie':
//                return (
//                    <PieWidget
//                        key={id}
//                        id={id}
//                        title={title}
//                        config={config}
//                        data={dataSource}
//                        onEdit={() => editWidget(id)}
//                        onDelete={() => deleteWidget(id)}
//                    />
//                );
//            case 'table':
//                return (
//                    <TableWidget
//                        key={id}
//                        id={id}
//                        title={title}
//                        config={config}
//                        data={dataSource}
//                        onEdit={() => editWidget(id)}
//                        onDelete={() => deleteWidget(id)}
//                    />
//                );
//            case 'pivot':
//                return (
//                    <PivotWidget
//                        key={id}
//                        id={id}
//                        title={title}
//                        config={config}
//                        data={dataSource}
//                        onEdit={() => editWidget(id)}
//                        onDelete={() => deleteWidget(id)}
//                    />
//                );
//            case 'gantt':
//                return (
//                    <GanttWidget
//                        key={id}
//                        id={id}
//                        title={title}
//                        config={config}
//                        data={dataSource}
//                        onEdit={() => editWidget(id)}
//                        onDelete={() => deleteWidget(id)}
//                    />
//                );
//            default:
//                return null;
//        }
//    };
//
//    return (
//        <div className="data-analysis-container">
//            {/* 数据配置模态框 */}
//            <Modal
//                title="数据配置"
//                visible={dataConfigVisible}
//                onCancel={() => setDataConfigVisible(false)}
//                footer={null}
//                width={800}
//            >
//                <Radio.Group
//                    value={dataSourceType}
//                    onChange={(e) => setDataSourceType(e.target.value)}
//                    style={{ marginBottom: 16 }}
//                >
//                    <Radio.Button value="initial">使用初始数据</Radio.Button>
//                    <Radio.Button value="upload">上传数据</Radio.Button>
//                </Radio.Group>
//
//                {dataSourceType === 'upload' && (
//                    <Dragger
//                        name="file"
//                        accept=".csv, .xlsx, .xls"
//                        beforeUpload={handleUpload}
//                        showUploadList={false}
//                    >
//                        <p className="ant-upload-drag-icon">
//                            <UploadOutlined />
//                        </p>
//                        <p className="ant-upload-text">点击或拖拽 CSV 或 Excel 文件到此处上传</p>
//                        <p className="ant-upload-hint">
//                            支持上传 CSV 或 Excel 格式的数据文件，数据应为表格形式
//                        </p>
//                    </Dragger>
//                )}
//
//                {dataSourceType === 'initial' && initialData && (
//                    <div>
//                        <h4>当前使用初始数据</h4>
//                        <p>数据量: {initialData.length} 条</p>
//                        <Button
//                            type="primary"
//                            onClick={() => {
//                                setDataSource(initialData);
//                                setDataConfigVisible(false);
//                            }}
//                        >
//                            确认使用
//                        </Button>
//                    </div>
//                )}
//            </Modal>
//
//            <Row gutter={16}>
//                {/* 配置区 - 宽度调整为6列 */}
//                <Col span={configCollapsed ? 0 : 6}>
//                    <Card
//                        title={
//                            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
//                                <span>可视化配置</span>
//                                <Button
//                                    type="text"
//                                    icon={configCollapsed ? <UpOutlined /> : <DownOutlined />}
//                                    onClick={() => setConfigCollapsed(!configCollapsed)}
//                                />
//                            </div>
//                        }
//                        extra={
//                            <Space>
//                                {onDataUpdate && (
//                                    <Tooltip title="更新数据">
//                                        <Button
//                                            icon={<SyncOutlined spin={updating} />}
//                                            onClick={handleUpdateData}
//                                            disabled={updating || dataSource.length === 0}
//                                        />
//                                    </Tooltip>
//                                )}
//                                <Button
//                                    type="primary"
//                                    icon={<AppstoreAddOutlined />}
//                                    onClick={addWidget}
//                                    disabled={dataSource.length === 0}
//                                >
//                                    添加组件
//                                </Button>
//                            </Space>
//                        }
//                    >
//                        <Collapse defaultActiveKey={['1']}>
//                            <Panel header="数据配置" key="1">
//                                <Space direction="vertical" style={{ width: '100%' }}>
//                                    <Button
//                                        type="primary"
//                                        onClick={() => setDataConfigVisible(true)}
//                                        block
//                                    >
//                                        {dataSource.length > 0 ? '更改数据' : '配置数据'}
//                                    </Button>
//                                    {dataSource.length > 0 && (
//                                        <div>
//                                            <p>当前数据量: {dataSource.length} 条</p>
//                                            <p>维度字段: {dimensions.length} 个</p>
//                                            <p>指标字段: {metrics.length} 个</p>
//                                        </div>
//                                    )}
//                                </Space>
//                            </Panel>
//                            <Panel header="组件配置" key="2">
//                                <Tabs activeKey={activeTab} onChange={setActiveTab}>
//                                    {Object.entries(CHART_TYPES).map(([key, { name, icon }]) => (
//                                        <TabPane tab={<span>{icon} {name}</span>} key={key} />
//                                    ))}
//                                </Tabs>
//
//                                <ConfigForm
//                                    type={activeTab}
//                                    form={configForm}
//                                    dimensions={dimensions}
//                                    metrics={metrics}
//                                />
//                            </Panel>
//                        </Collapse>
//                    </Card>
//                </Col>
//
//                {configCollapsed && (
//                    <Col span={2} style={{ paddingTop: '16px', display: 'flex', justifyContent: 'center' }}>
//                        <div
//                            onClick={() => setConfigCollapsed(false)}
//                            style={{
//                                cursor: 'pointer',
//                                width: '40px',
//                                height: '100px',
//                                backgroundColor: 'rgba(255, 255, 255, 0.2)',
//                                color: '#333',
//                                borderRadius: '20px',
//                                display: 'flex',
//                                flexDirection: 'column',
//                                alignItems: 'center',
//                                justifyContent: 'center',
//                                backdropFilter: 'blur(10px)',
//                                border: '1px solid rgba(255, 255, 255, 0.3)',
//                                boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
//                                transition: 'all 0.3s ease',
//                                ':hover': {
//                                    backgroundColor: 'rgba(255, 255, 255, 0.3)',
//                                    transform: 'scale(1.05)',
//                                    boxShadow: '0 6px 12px rgba(0, 0, 0, 0.15)'
//                                }
//                            }}
//                        >
//                            <UpOutlined style={{
//                                fontSize: '18px',
//                                marginBottom: '8px',
//                                color: '#555'
//                            }} />
//                            <span style={{
//                                writingMode: 'vertical-rl',
//                                textOrientation: 'mixed',
//                                fontSize: '12px',
//                                fontWeight: '500',
//                                color: '#555'
//                            }}>
//                                展开配置
//                            </span>
//                        </div>
//                    </Col>
//                )}
//
//                {/* 展示区 - 宽度调整为根据配置区是否折叠动态变化 */}
//                <Col span={configCollapsed ? 22 : 18}>
//                    <Card
//                        title="可视化展示"
//                        loading={loading}
//                        extra={
//                            <Space>
//                                {dataSource.length > 0 && (
//                                    <span>数据量: {dataSource.length} 条</span>
//                                )}
//                                {onDataUpdate && (
//                                    <Tooltip title="更新数据">
//                                        <Button
//                                            size="small"
//                                            icon={<SyncOutlined spin={updating} />}
//                                            onClick={handleUpdateData}
//                                            disabled={updating || dataSource.length === 0}
//                                        />
//                                    </Tooltip>
//                                )}
//                            </Space>
//                        }
//                    >
//                        {dataSource.length === 0 ? (
//                            <Empty
//                                description={
//                                    <span>
//                                        <p>暂无数据</p>
//                                        <Button
//                                            type="primary"
//                                            onClick={() => setDataConfigVisible(true)}
//                                        >
//                                            配置数据
//                                        </Button>
//                                    </span>
//                                }
//                            />
//                        ) : widgets.length === 0 ? (
//                            <Empty description="请添加可视化组件" />
//                        ) : (
//                            <DndContext
//                                modifiers={[restrictToHorizontalAxis]}
//                                collisionDetection={closestCenter}
//                                onDragStart={handleDragStart}
//                                onDragEnd={handleDragEnd}
//                            >
//                                <SortableContext
//                                    items={widgets.map(w => w.id)}
//                                    strategy={horizontalListSortingStrategy}
//                                >
//                                    <Row gutter={16}>
//                                        {widgets.map(widget => (
//                                            <SortableItem key={widget.id} id={widget.id} span={widget.span}>
//                                                {renderWidget(widget)}
//                                            </SortableItem>
//                                        ))}
//                                    </Row>
//                                </SortableContext>
//
//                                <DragOverlay>
//                                    {activeId ? (
//                                        <div style={{
//                                            width: '100%',
//                                            backgroundColor: 'rgba(255, 255, 255, 0.8)',
//                                            boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
//                                            borderRadius: 4
//                                        }}>
//                                            {renderWidget(widgets.find(w => w.id === activeId))}
//                                        </div>
//                                    ) : null}
//                                </DragOverlay>
//                            </DndContext>
//                        )}
//                    </Card>
//                </Col>
//            </Row>
//        </div>
//    );
//};
//
//// 图表组件
//const ChartWidget = ({ title, type, config, data, onEdit, onDelete }) => {
//    // 检查配置和数据有效性
//    if (!config || !data.length) {
//        return <Empty description="配置不完整或数据为空" />;
//    }
//
//    // 验证X轴和Y轴字段
//    if (!config.xField || !config.yField || config.yField.length === 0) {
//        return <Empty description="请配置X轴和Y轴字段" />;
//    }
//
//    // 准备图表数据
//    const prepareChartData = () => {
//        try {
//            // 过滤掉无效数据
//            const validData = data.filter(item =>
//                item[config.xField] !== undefined &&
//                config.yField.every(yField =>
//                    item[yField] !== undefined && !isNaN(Number(item[yField])))
//            );
//
//            if (validData.length === 0) {
//                console.error('没有有效数据可用于图表');
//                return null;
//            }
//
//            return {
//                labels: validData.map(item => {
//                    // 处理日期类型数据
//                    if (item[config.xField] instanceof Date) {
//                        return item[config.xField].toLocaleDateString();
//                    }
//                    return item[config.xField];
//                }),
//                datasets: config.yField.map((field, index) => ({
//                    label: field,
//                    data: validData.map(item => {
//                        const value = item[field];
//                        // 确保值为数字
//                        return typeof value === 'number' ? value : Number(value);
//                    }),
//                    backgroundColor: `hsla(${index * 360 / config.yField.length}, 70%, 50%, 0.6)`,
//                    borderColor: `hsl(${index * 360 / config.yField.length}, 70%, 30%)`,
//                    borderWidth: 1,
//                })),
//            };
//        } catch (error) {
//            console.error('准备图表数据时出错:', error);
//            return null;
//        }
//    };
//
//    const chartData = prepareChartData();
//
//    if (!chartData) {
//        return (
//            <Empty description={
//                <div>
//                    <p>无法渲染图表</p>
//                    <p>请检查:</p>
//                    <ul>
//                        <li>X轴和Y轴字段是否正确</li>
//                        <li>Y轴字段是否为数值类型</li>
//                        <li>数据中是否存在有效值</li>
//                    </ul>
//                </div>
//            } />
//        );
//    }
//
//    const options = {
//        responsive: true,
//        plugins: {
//            legend: {
//                position: 'top',
//            },
//            tooltip: {
//                callbacks: {
//                    label: function(context) {
//                        let label = context.dataset.label || '';
//                        if (label) {
//                            label += ': ';
//                        }
//                        if (context.parsed.y !== null) {
//                            label += Number(context.parsed.y).toLocaleString();
//                        }
//                        return label;
//                    }
//                }
//            }
//        },
//        scales: {
//            y: {
//                beginAtZero: true,
//                ticks: {
//                    callback: function(value) {
//                        return Number(value).toLocaleString();
//                    }
//                }
//            }
//        }
//    };
//
//    return (
//        <div style={{ height: 400 }}>
//            <Chart type={type} data={chartData} options={options} />
//        </div>
//    );
//};
//
//// 饼图组件
//const PieWidget = ({ title, config, data, onEdit, onDelete }) => {
//    if (!config || !data.length) return <Empty description="配置不完整或数据为空" />;
//
//    const chartData = {
//        labels: data.map(item => item[config.categoryField]),
//        datasets: [{
//            data: data.map(item => item[config.valueField]),
//            backgroundColor: data.map((_, index) =>
//                `hsl(${index * 360 / data.length}, 70%, 50%)`
//            ),
//        }],
//    };
//
//    const options = {
//        responsive: true,
//        plugins: {
//            legend: {
//                position: 'right',
//            },
//        },
//    };
//
//    return (
//        <div style={{ height: 400 }}>
//            <Chart type="pie" data={chartData} options={options} />
//        </div>
//    );
//};
//
//// 表格组件
//const TableWidget = ({ title, config, data, onEdit, onDelete }) => {
//    if (!config || !data.length) return <Empty description="配置不完整或数据为空" />;
//
//    const columns = config.columns.map(col => ({
//        title: col,
//        dataIndex: col,
//        key: col,
//    }));
//
//    return (
//        <Table
//            columns={columns}
//            dataSource={data}
//            size="small"
//            scroll={{ x: true }}
//            pagination={{ pageSize: 5 }}
//        />
//    );
//};
//
//// 透视表组件
//const PivotWidget = ({ title, config, data, onEdit, onDelete }) => {
//    if (!config || !data.length) return <Empty description="配置不完整或数据为空" />;
//
//    // 这里简化实现，实际项目中可以使用专门的透视表库
//    const pivotData = {};
//
//    // 生成透视数据
//    data.forEach(item => {
//        const rowKey = config.rows.map(row => item[row]).join('-');
//        const colKey = config.cols?.length > 0 ? config.cols.map(col => item[col]).join('-') : '总计';
//
//        if (!pivotData[rowKey]) {
//            pivotData[rowKey] = { key: rowKey };
//            config.rows.forEach(row => {
//                pivotData[rowKey][row] = item[row];
//            });
//        }
//
//        config.values.forEach(value => {
//            const fieldName = colKey === '总计' ? value : `${value}_${colKey}`;
//            pivotData[rowKey][fieldName] = (pivotData[rowKey][fieldName] || 0) + (item[value] || 0);
//        });
//    });
//
//    const columns = [
//        ...config.rows.map(row => ({
//            title: row,
//            dataIndex: row,
//            key: row,
//        })),
//        ...Object.keys(pivotData[Object.keys(pivotData)[0]])
//          .filter(key => !config.rows.includes(key) && key!== 'key')
//          .map(key => ({
//                title: key,
//                dataIndex: key,
//                key: key,
//            }))
//    ];
//
//    return (
//        <Table
//            columns={columns}
//            dataSource={Object.values(pivotData)}
//            size="small"
//            scroll={{ x: true }}
//            pagination={{ pageSize: 5 }}
//        />
//    );
//};
//
//// 甘特图组件
//const GanttWidget = ({ title, config, data, onEdit, onDelete }) => {
//    if (!config || !data.length) return <Empty description="配置不完整或数据为空" />;
//
//    try {
//        // 转换数据为甘特图需要的格式
//        const tasks = data.map(item => ({
//            id: item[config.taskField] || Math.random().toString(36).substr(2, 9),
//            name: String(item[config.taskField] || '未命名任务'),
//            start: new Date(item[config.startField]),
//            end: new Date(item[config.endField]),
//            progress: item[config.progressField] ? Number(item[config.progressField]) : 0,
//            type: item[config.typeField] || 'task',
//            styles: { progressColor: '#ffbb54', progressSelectedColor: '#ff9e0d' },
//        }));
//
//        return (
//            <div style={{ overflowX: 'auto', width: '100%' }}>
//                <Gantt
//                    tasks={tasks}
//                    viewMode="Day"
//                    listCellWidth=""
//                    columnWidth={60}
//                    fontSize="12"
//                    locale="zh-CN"
//                />
//            </div>
//        );
//    } catch (error) {
//        console.error('Error rendering Gantt chart:', error);
//        return <Empty description="渲染甘特图时出错" />;
//    }
//};
//
//export default DataAnalysis;
//
//
//
////import React, { useState, useEffect } from 'react';
////import {
////    Card, Select, Button, Row, Col, DatePicker, Divider, Spin,
////    Collapse, Form, Input, Slider, Tabs, Empty, message, Upload,
////    Modal, Space, Radio
////} from 'antd';
////import {
////    BarChartOutlined, LineChartOutlined, PieChartOutlined,
////    TableOutlined, AppstoreAddOutlined, DeleteOutlined,
////    EditOutlined, DragOutlined, UploadOutlined,
////    ScheduleOutlined, AppstoreOutlined, DownOutlined, UpOutlined
////} from '@ant-design/icons';
////import { Chart } from 'react-chartjs-2';
////import { Chart as ChartJS, registerables } from 'chart.js';
////import 'chartjs-plugin-datalabels';
////import { Table } from 'antd';
////import { DndContext, DragOverlay, closestCenter } from '@dnd-kit/core';
////import { arrayMove, SortableContext, horizontalListSortingStrategy } from '@dnd-kit/sortable';
////import { restrictToHorizontalAxis } from '@dnd-kit/modifiers';
////import { useSortable } from '@dnd-kit/sortable';
////import { CSS } from '@dnd-kit/utilities';
////import { Gantt } from 'gantt-task-react';
////import "gantt-task-react/dist/index.css";
////import Papa from 'papaparse';
////import { read, utils } from 'xlsx';
////
////ChartJS.register(...registerables);
////
////const { Option } = Select;
////const { Panel } = Collapse;
////const { TabPane } = Tabs;
////const { Dragger } = Upload;
////
////// 可拖拽的展示项组件
////const SortableItem = ({ id, children, span }) => {
////    const {
////        attributes,
////        listeners,
////        setNodeRef,
////        transform,
////        transition,
////        isDragging,
////    } = useSortable({ id });
////
////    const style = {
////        transform: CSS.Transform.toString(transform),
////        transition,
////        opacity: isDragging ? 0.5 : 1,
////    };
////
////    return (
////        <Col span={span} ref={setNodeRef} style={style} {...attributes}>
////            <Card
////                title={
////                    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
////                        <span>{children.props.title}</span>
////                        <div>
////                            <Button
////                                type="text"
////                                icon={<DragOutlined />}
////                                {...listeners}
////                                style={{ cursor: 'move' }}
////                            />
////                            <Button
////                                type="text"
////                                icon={<EditOutlined />}
////                                onClick={() => children.props.onEdit()}
////                            />
////                            <Button
////                                type="text"
////                                icon={<DeleteOutlined />}
////                                onClick={() => children.props.onDelete()}
////                            />
////                        </div>
////                    </div>
////                }
////            >
////                {children}
////            </Card>
////        </Col>
////    );
////};
////
////// 可视化组件类型
////const CHART_TYPES = {
////    line: { name: '折线图', icon: <LineChartOutlined /> },
////    bar: { name: '柱状图', icon: <BarChartOutlined /> },
////    pie: { name: '饼图', icon: <PieChartOutlined /> },
////    table: { name: '表格', icon: <TableOutlined /> },
////    pivot: { name: '透视表', icon: <AppstoreOutlined /> },
////    gantt: { name: '甘特图', icon: <ScheduleOutlined /> },
////};
////
////const DataAnalysis = ({ initialData }) => {
////    const [loading, setLoading] = useState(false);
////    const [dimensions, setDimensions] = useState([]);
////    const [metrics, setMetrics] = useState([]);
////    const [activeTab, setActiveTab] = useState('line');
////    const [configForm] = Form.useForm();
////    const [widgets, setWidgets] = useState([]);
////    const [activeId, setActiveId] = useState(null);
////    const [dataSource, setDataSource] = useState(initialData || []);
////    const [dataConfigVisible, setDataConfigVisible] = useState(false);
////    const [dataSourceType, setDataSourceType] = useState(initialData ? 'initial' : 'upload');
////    const [configCollapsed, setConfigCollapsed] = useState(false);
////
////    // 获取维度和指标
////    useEffect(() => {
////        if (dataSource.length > 0) {
////            extractDimensionsAndMetrics();
////        }
////    }, [dataSource]);
////
////    const extractDimensionsAndMetrics = () => {
////        if (dataSource.length === 0) return;
////
////        try {
////            // 从数据中提取维度和指标
////            const sampleItem = dataSource[0];
////            const extractedDims = [];
////            const extractedMetrics = [];
////
////            Object.keys(sampleItem).forEach(key => {
////                const value = sampleItem[key];
////                if (typeof value === 'string' || value instanceof Date) {
////                    extractedDims.push({ field: key, name: key });
////                } else if (typeof value === 'number') {
////                    extractedMetrics.push({ field: key, name: key });
////                }
////            });
////
////            setDimensions(extractedDims);
////            setMetrics(extractedMetrics);
////        } catch (error) {
////            console.error('Error extracting dimensions and metrics:', error);
////            message.error('提取数据字段失败');
////        }
////    };
////
////    // 处理上传数据
////    const handleUpload = (file) => {
////        const reader = new FileReader();
////        reader.onload = (e) => {
////            try {
////                let data;
////                if (file.type === 'text/csv') {
////                    const result = Papa.parse(e.target.result, { header: true });
////                    data = result.data;
////                } else if (file.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || file.type === 'application/vnd.ms-excel') {
////                    const workbook = read(e.target.result, { type: 'binary' });
////                    const firstSheetName = workbook.SheetNames[0];
////                    const worksheet = workbook.Sheets[firstSheetName];
////                    data = utils.sheet_to_json(worksheet);
////                } else {
////                    message.error('仅支持 CSV 或 Excel 文件');
////                    return;
////                }
////
////                if (Array.isArray(data)) {
////                    setDataSource(data);
////                    setDataConfigVisible(false);
////                    message.success('数据上传成功');
////                } else {
////                    message.error('上传的数据必须是数组格式');
////                }
////            } catch (err) {
////                console.error('Error parsing uploaded file:', err);
////                message.error('解析上传文件失败');
////            }
////        };
////
////        if (file.type === 'text/csv') {
////            reader.readAsText(file);
////        } else {
////            reader.readAsBinaryString(file);
////        }
////        return false; // 阻止默认上传行为
////    };
////
////    // 添加可视化组件
////    const addWidget = () => {
////        if (dataSource.length === 0) {
////            message.error('请先配置数据');
////            return;
////        }
////        configForm.validateFields().then(values => {
////            const newWidget = {
////                id: `widget-${Date.now()}`,
////                type: activeTab,
////                title: values.title || CHART_TYPES[activeTab].name,
////                span: values.span || 8,
////                config: { ...values },
////            };
////
////            setWidgets([...widgets, newWidget]);
////            configForm.resetFields();
////            message.success('组件添加成功');
////        }).catch(err => {
////            console.error('Validation failed:', err);
////            message.error('表单验证失败，请检查配置');
////        });
////    };
////
////    // 删除组件
////    const deleteWidget = (id) => {
////        setWidgets(widgets.filter(w => w.id !== id));
////    };
////
////    // 编辑组件
////    const editWidget = (id) => {
////        const widget = widgets.find(w => w.id === id);
////        if (widget) {
////            setActiveTab(widget.type);
////            configForm.setFieldsValue({
////                ...widget.config,
////                title: widget.title,
////                span: widget.span,
////            });
////            deleteWidget(id);
////        }
////    };
////
////    // 拖拽相关函数
////    const handleDragStart = (event) => {
////        setActiveId(event.active.id);
////    };
////
////    const handleDragEnd = (event) => {
////        const { active, over } = event;
////
////        if (active.id !== over.id) {
////            setWidgets((items) => {
////                const oldIndex = items.findIndex(item => item.id === active.id);
////                const newIndex = items.findIndex(item => item.id === over.id);
////                return arrayMove(items, oldIndex, newIndex);
////            });
////        }
////
////        setActiveId(null);
////    };
////
////    // 渲染可视化组件
////    const renderWidget = (widget) => {
////        const { id, type, title, span, config } = widget;
////
////        switch (type) {
////            case 'line':
////            case 'bar':
////                return (
////                    <ChartWidget
////                        key={id}
////                        id={id}
////                        title={title}
////                        type={type}
////                        config={config}
////                        data={dataSource}
////                        onEdit={() => editWidget(id)}
////                        onDelete={() => deleteWidget(id)}
////                    />
////                );
////            case 'pie':
////                return (
////                    <PieWidget
////                        key={id}
////                        id={id}
////                        title={title}
////                        config={config}
////                        data={dataSource}
////                        onEdit={() => editWidget(id)}
////                        onDelete={() => deleteWidget(id)}
////                    />
////                );
////            case 'table':
////                return (
////                    <TableWidget
////                        key={id}
////                        id={id}
////                        title={title}
////                        config={config}
////                        data={dataSource}
////                        onEdit={() => editWidget(id)}
////                        onDelete={() => deleteWidget(id)}
////                    />
////                );
////            case 'pivot':
////                return (
////                    <PivotWidget
////                        key={id}
////                        id={id}
////                        title={title}
////                        config={config}
////                        data={dataSource}
////                        onEdit={() => editWidget(id)}
////                        onDelete={() => deleteWidget(id)}
////                    />
////                );
////            case 'gantt':
////                return (
////                    <GanttWidget
////                        key={id}
////                        id={id}
////                        title={title}
////                        config={config}
////                        data={dataSource}
////                        onEdit={() => editWidget(id)}
////                        onDelete={() => deleteWidget(id)}
////                    />
////                );
////            default:
////                return null;
////        }
////    };
////
////    // 渲染配置表单
////    const renderConfigForm = () => {
////        switch (activeTab) {
////            case 'line':
////            case 'bar':
////                // 获取当前表单值
////                const formValues = configForm.getFieldsValue();
////                const xFieldValue = formValues.xField;
////
////                // 可选的Y轴字段应该是所有指标字段，排除已选为X轴的字段（如果有）
////                const availableYFields = xFieldValue
////                    ? metrics.filter(metric => metric.field !== xFieldValue)
////                    : metrics;
////
////                return (
////                    <>
////                        <Form.Item label="X轴" name="xField" rules={[{ required: true, message: '请选择X轴字段' }]}>
////                            <Select
////                                placeholder="选择X轴字段"
////                                onChange={() => {
////                                    // 当X轴变化时，重置Y轴选择
////                                    configForm.setFieldsValue({ yField: undefined });
////                                }}
////                            >
////                                {dimensions.map(dim => (
////                                    <Option key={dim.field} value={dim.field}>{dim.name}</Option>
////                                ))}
////                            </Select>
////                        </Form.Item>
////                        <Form.Item label="Y轴" name="yField" rules={[{ required: true, message: '请选择Y轴字段' }]}>
////                            <Select
////                                mode="multiple"
////                                placeholder={xFieldValue ? "选择Y轴字段" : "请先选择X轴"}
////                                disabled={!xFieldValue}
////                            >
////                                {availableYFields.map(metric => (
////                                    <Option key={metric.field} value={metric.field}>{metric.name}</Option>
////                                ))}
////                            </Select>
////                        </Form.Item>
////                    </>
////                );
////            case 'pie':
////                return (
////                    <>
////                        <Form.Item label="分类字段" name="categoryField" rules={[{ required: true, message: '请选择分类字段' }]}>
////                            <Select placeholder="选择分类字段">
////                                {dimensions.map(dim => (
////                                    <Option key={dim.field} value={dim.field}>{dim.name}</Option>
////                                ))}
////                            </Select>
////                        </Form.Item>
////                        <Form.Item label="数值字段" name="valueField" rules={[{ required: true, message: '请选择数值字段' }]}>
////                            <Select placeholder="选择数值字段">
////                                {metrics.map(metric => (
////                                    <Option key={metric.field} value={metric.field}>{metric.name}</Option>
////                                ))}
////                            </Select>
////                        </Form.Item>
////                    </>
////                );
////            case 'table':
////                return (
////                    <Form.Item label="显示列" name="columns" rules={[{ required: true, message: '请选择显示列' }]}>
////                        <Select mode="multiple" placeholder="选择要显示的列">
////                            {[...dimensions, ...metrics].map(item => (
////                                <Option key={item.field} value={item.field}>{item.name}</Option>
////                            ))}
////                        </Select>
////                    </Form.Item>
////                );
////            case 'pivot':
////                const [rows, cols] = configForm.getFieldsValue(['rows', 'cols']);
////                const availableMetrics = metrics.filter(metric => {
////                    return (!rows || !rows.includes(metric.field)) && (!cols || !cols.includes(metric.field));
////                });
////                return (
////                    <>
////                        <Form.Item label="行维度" name="rows" rules={[{ required: true, message: '请选择行维度' }]}>
////                            <Select mode="multiple" placeholder="选择行维度">
////                                {dimensions.map(dim => (
////                                    <Option key={dim.field} value={dim.field}>{dim.name}</Option>
////                                ))}
////                            </Select>
////                        </Form.Item>
////                        <Form.Item label="列维度" name="cols">
////                            <Select mode="multiple" placeholder="选择列维度">
////                                {dimensions.map(dim => (
////                                    <Option key={dim.field} value={dim.field}>{dim.name}</Option>
////                                ))}
////                            </Select>
////                        </Form.Item>
////                        <Form.Item label="数值字段" name="values" rules={[{ required: true, message: '请选择数值字段' }]}>
////                            <Select mode="multiple" placeholder="选择数值字段">
////                                {availableMetrics.map(metric => (
////                                    <Option key={metric.field} value={metric.field}>{metric.name}</Option>
////                                ))}
////                            </Select>
////                        </Form.Item>
////                        <Form.Item label="聚合方式" name="aggregate" initialValue="sum">
////                            <Select>
////                                <Option value="sum">求和</Option>
////                                <Option value="avg">平均值</Option>
////                                <Option value="count">计数</Option>
////                                <Option value="max">最大值</Option>
////                                <Option value="min">最小值</Option>
////                            </Select>
////                        </Form.Item>
////                    </>
////                );
////            case 'gantt':
////                return (
////                    <>
////                        <Form.Item label="任务名称" name="taskField" rules={[{ required: true, message: '请选择任务名字段' }]}>
////                            <Select placeholder="选择任务名字段">
////                                {dimensions.map(dim => (
////                                    <Option key={dim.field} value={dim.field}>{dim.name}</Option>
////                                ))}
////                            </Select>
////                        </Form.Item>
////                        <Form.Item label="开始时间" name="startField" rules={[{ required: true, message: '请选择开始时间字段' }]}>
////                            <Select placeholder="选择开始时间字段">
////                                {dimensions.filter(d => d.field.toLowerCase().includes('date') || d.field.toLowerCase().includes('time')).map(dim => (
////                                    <Option key={dim.field} value={dim.field}>{dim.name}</Option>
////                                ))}
////                            </Select>
////                        </Form.Item>
////                        <Form.Item label="结束时间" name="endField" rules={[{ required: true, message: '请选择结束时间字段' }]}>
////                            <Select placeholder="选择结束时间字段">
////                                {dimensions.filter(d => d.field.toLowerCase().includes('date') || d.field.toLowerCase().includes('time')).map(dim => (
////                                    <Option key={dim.field} value={dim.field}>{dim.name}</Option>
////                                ))}
////                            </Select>
////                        </Form.Item>
////                        <Form.Item label="进度" name="progressField">
////                            <Select placeholder="选择进度字段(可选)">
////                                {metrics.map(metric => (
////                                    <Option key={metric.field} value={metric.field}>{metric.name}</Option>
////                                ))}
////                            </Select>
////                        </Form.Item>
////                        <Form.Item label="任务类型" name="typeField">
////                            <Select placeholder="选择任务类型字段(可选)">
////                                {dimensions.map(dim => (
////                                    <Option key={dim.field} value={dim.field}>{dim.name}</Option>
////                                ))}
////                            </Select>
////                        </Form.Item>
////                    </>
////                );
////            default:
////                return null;
////        }
////    };
////
////    return (
////        <div className="data-analysis-container">
////            {/* 数据配置模态框 */}
////            <Modal
////                title="数据配置"
////                visible={dataConfigVisible}
////                onCancel={() => setDataConfigVisible(false)}
////                footer={null}
////                width={800}
////            >
////                <Radio.Group
////                    value={dataSourceType}
////                    onChange={(e) => setDataSourceType(e.target.value)}
////                    style={{ marginBottom: 16 }}
////                >
////                    <Radio.Button value="initial">使用初始数据</Radio.Button>
////                    <Radio.Button value="upload">上传数据</Radio.Button>
////                </Radio.Group>
////
////                {dataSourceType === 'upload' && (
////                    <Dragger
////                        name="file"
////                        accept=".csv, .xlsx, .xls"
////                        beforeUpload={handleUpload}
////                        showUploadList={false}
////                    >
////                        <p className="ant-upload-drag-icon">
////                            <UploadOutlined />
////                        </p>
////                        <p className="ant-upload-text">点击或拖拽 CSV 或 Excel 文件到此处上传</p>
////                        <p className="ant-upload-hint">
////                            支持上传 CSV 或 Excel 格式的数据文件，数据应为表格形式
////                        </p>
////                    </Dragger>
////                )}
////
////                {dataSourceType === 'initial' && initialData && (
////                    <div>
////                        <h4>当前使用初始数据</h4>
////                        <p>数据量: {initialData.length} 条</p>
////                        <Button
////                            type="primary"
////                            onClick={() => {
////                                setDataSource(initialData);
////                                setDataConfigVisible(false);
////                            }}
////                        >
////                            确认使用
////                        </Button>
////                    </div>
////                )}
////            </Modal>
////
////            <Row gutter={16}>
////                {/* 配置区 - 宽度调整为6列 */}
////                <Col span={configCollapsed ? 0 : 6}>
////                    <Card
////                        title={
////                            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
////                                <span>可视化配置</span>
////                                <Button
////                                    type="text"
////                                    icon={configCollapsed ? <UpOutlined /> : <DownOutlined />}
////                                    onClick={() => setConfigCollapsed(!configCollapsed)}
////                                />
////                            </div>
////                        }
////                        extra={
////                            <Button
////                                type="primary"
////                                icon={<AppstoreAddOutlined />}
////                                onClick={addWidget}
////                                disabled={dataSource.length === 0}
////                            >
////                                添加组件
////                            </Button>
////                        }
////                    >
////                        <Collapse defaultActiveKey={['1']}>
////                            <Panel header="数据配置" key="1">
////                                <Space direction="vertical" style={{ width: '100%' }}>
////                                    <Button
////                                        type="primary"
////                                        onClick={() => setDataConfigVisible(true)}
////                                        block
////                                    >
////                                        {dataSource.length > 0 ? '更改数据' : '配置数据'}
////                                    </Button>
////                                    {dataSource.length > 0 && (
////                                        <div>
////                                            <p>当前数据量: {dataSource.length} 条</p>
////                                            <p>维度字段: {dimensions.length} 个</p>
////                                            <p>指标字段: {metrics.length} 个</p>
////                                        </div>
////                                    )}
////                                </Space>
////                            </Panel>
////                            <Panel header="组件配置" key="2">
////                                <Tabs activeKey={activeTab} onChange={setActiveTab}>
////                                    {Object.entries(CHART_TYPES).map(([key, { name, icon }]) => (
////                                        <TabPane tab={<span>{icon} {name}</span>} key={key} />
////                                    ))}
////                                </Tabs>
////
////                                <Form form={configForm} layout="vertical">
////                                    <Form.Item label="标题" name="title">
////                                        <Input placeholder="输入组件标题" />
////                                    </Form.Item>
////                                    <Form.Item label="宽度占比" name="span" initialValue={8}>
////                                        <Slider
////                                            min={4}
////                                            max={24}
////                                            step={4}
////                                            marks={{ 4: '1/6', 8: '1/3', 12: '1/2', 16: '2/3', 20: '5/6', 24: '100%' }}
////                                        />
////                                    </Form.Item>
////
////                                    {renderConfigForm()}
////                                </Form>
////                            </Panel>
////                        </Collapse>
////                    </Card>
////                </Col>
////
////                {configCollapsed && (
////                    <Col span={2} style={{ paddingTop: '16px', display: 'flex', justifyContent: 'center' }}>
////                        <div
////                            onClick={() => setConfigCollapsed(false)}
////                            style={{
////                                cursor: 'pointer',
////                                width: '40px',
////                                height: '100px',
////                                backgroundColor: 'rgba(255, 255, 255, 0.2)',
////                                color: '#333',
////                                borderRadius: '20px',
////                                display: 'flex',
////                                flexDirection: 'column',
////                                alignItems: 'center',
////                                justifyContent: 'center',
////                                backdropFilter: 'blur(10px)',
////                                border: '1px solid rgba(255, 255, 255, 0.3)',
////                                boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
////                                transition: 'all 0.3s ease',
////                                ':hover': {
////                                    backgroundColor: 'rgba(255, 255, 255, 0.3)',
////                                    transform: 'scale(1.05)',
////                                    boxShadow: '0 6px 12px rgba(0, 0, 0, 0.15)'
////                                }
////                            }}
////                        >
////                            <UpOutlined style={{
////                                fontSize: '18px',
////                                marginBottom: '8px',
////                                color: '#555'
////                            }} />
////                            <span style={{
////                                writingMode: 'vertical-rl',
////                                textOrientation: 'mixed',
////                                fontSize: '12px',
////                                fontWeight: '500',
////                                color: '#555'
////                            }}>
////                                展开配置
////                            </span>
////                        </div>
////                    </Col>
////                )}
////
////
////                {/* 展示区 - 宽度调整为根据配置区是否折叠动态变化 */}
////                <Col span={configCollapsed ? 22 : 18}>
////                    <Card
////                        title="可视化展示"
////                        loading={loading}
////                        extra={
////                            dataSource.length > 0 && (
////                                <span>数据量: {dataSource.length} 条</span>
////                            )
////                        }
////                    >
////                        {dataSource.length === 0 ? (
////                            <Empty
////                                description={
////                                    <span>
////                                        <p>暂无数据</p>
////                                        <Button
////                                            type="primary"
////                                            onClick={() => setDataConfigVisible(true)}
////                                        >
////                                            配置数据
////                                        </Button>
////                                    </span>
////                                }
////                            />
////                        ) : widgets.length === 0 ? (
////                            <Empty description="请添加可视化组件" />
////                        ) : (
////                            <DndContext
////                                modifiers={[restrictToHorizontalAxis]}
////                                collisionDetection={closestCenter}
////                                onDragStart={handleDragStart}
////                                onDragEnd={handleDragEnd}
////                            >
////                                <SortableContext
////                                    items={widgets.map(w => w.id)}
////                                    strategy={horizontalListSortingStrategy}
////                                >
////                                    <Row gutter={16}>
////                                        {widgets.map(widget => (
////                                            <SortableItem key={widget.id} id={widget.id} span={widget.span}>
////                                                {renderWidget(widget)}
////                                            </SortableItem>
////                                        ))}
////                                    </Row>
////                                </SortableContext>
////
////                                <DragOverlay>
////                                    {activeId ? (
////                                        <div style={{
////                                            width: '100%',
////                                            backgroundColor: 'rgba(255, 255, 255, 0.8)',
////                                            boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
////                                            borderRadius: 4
////                                        }}>
////                                            {renderWidget(widgets.find(w => w.id === activeId))}
////                                        </div>
////                                    ) : null}
////                                </DragOverlay>
////                            </DndContext>
////                        )}
////                    </Card>
////                </Col>
////            </Row>
////        </div>
////    );
////};
////
////const ChartWidget = ({ title, type, config, data, onEdit, onDelete }) => {
////    if (!config || !data.length) return <Empty description="配置不完整或数据为空" />;
////
////    const chartData = {
////        labels: data.map(item => item[config.xField]),
////        datasets: config.yField.map((field, index) => ({
////            label: field,
////            data: data.map(item => item[field]),
////            backgroundColor: `hsl(${index * 360 / config.yField.length}, 70%, 50%)`,
////            borderColor: `hsl(${index * 360 / config.yField.length}, 70%, 30%)`,
////            borderWidth: 1,
////        })),
////    };
////
////    const options = {
////        responsive: true,
////        plugins: {
////            legend: {
////                position: 'top',
////            },
////        },
////    };
////
////    return (
////        <div style={{ height: 400 }}>
////            <Chart type={type} data={chartData} options={options} />
////        </div>
////    );
////};
////
////// 饼图组件
////const PieWidget = ({ title, config, data, onEdit, onDelete }) => {
////    if (!config || !data.length) return <Empty description="配置不完整或数据为空" />;
////
////    const chartData = {
////        labels: data.map(item => item[config.categoryField]),
////        datasets: [{
////            data: data.map(item => item[config.valueField]),
////            backgroundColor: data.map((_, index) =>
////                `hsl(${index * 360 / data.length}, 70%, 50%)`
////            ),
////        }],
////    };
////
////    const options = {
////        responsive: true,
////        plugins: {
////            legend: {
////                position: 'right',
////            },
////        },
////    };
////
////    return (
////        <div style={{ height: 400 }}>
////            <Chart type="pie" data={chartData} options={options} />
////        </div>
////    );
////};
////
////// 表格组件
////const TableWidget = ({ title, config, data, onEdit, onDelete }) => {
////    if (!config || !data.length) return <Empty description="配置不完整或数据为空" />;
////
////    const columns = config.columns.map(col => ({
////        title: col,
////        dataIndex: col,
////        key: col,
////    }));
////
////    return (
////        <Table
////            columns={columns}
////            dataSource={data}
////            size="small"
////            scroll={{ x: true }}
////            pagination={{ pageSize: 5 }}
////        />
////    );
////};
////
////// 透视表组件
////const PivotWidget = ({ title, config, data, onEdit, onDelete }) => {
////    if (!config || !data.length) return <Empty description="配置不完整或数据为空" />;
////
////    // 这里简化实现，实际项目中可以使用专门的透视表库
////    const pivotData = {};
////
////    // 生成透视数据
////    data.forEach(item => {
////        const rowKey = config.rows.map(row => item[row]).join('-');
////        const colKey = config.cols?.length > 0 ? config.cols.map(col => item[col]).join('-') : '总计';
////
////        if (!pivotData[rowKey]) {
////            pivotData[rowKey] = { key: rowKey };
////            config.rows.forEach(row => {
////                pivotData[rowKey][row] = item[row];
////            });
////        }
////
////        config.values.forEach(value => {
////            const fieldName = colKey === '总计' ? value : `${value}_${colKey}`;
////            pivotData[rowKey][fieldName] = (pivotData[rowKey][fieldName] || 0) + (item[value] || 0);
////        });
////    });
////
////    const columns = [
////        ...config.rows.map(row => ({
////            title: row,
////            dataIndex: row,
////            key: row,
////        })),
////        ...Object.keys(pivotData[Object.keys(pivotData)[0]])
////          .filter(key => !config.rows.includes(key) && key!== 'key')
////          .map(key => ({
////                title: key,
////                dataIndex: key,
////                key: key,
////            }))
////    ];
////
////    return (
////        <Table
////            columns={columns}
////            dataSource={Object.values(pivotData)}
////            size="small"
////            scroll={{ x: true }}
////            pagination={{ pageSize: 5 }}
////        />
////    );
////};
////
////// 甘特图组件
////const GanttWidget = ({ title, config, data, onEdit, onDelete }) => {
////    if (!config || !data.length) return <Empty description="配置不完整或数据为空" />;
////
////    try {
////        // 转换数据为甘特图需要的格式
////        const tasks = data.map(item => ({
////            id: item[config.taskField] || Math.random().toString(36).substr(2, 9),
////            name: String(item[config.taskField] || '未命名任务'),
////            start: new Date(item[config.startField]),
////            end: new Date(item[config.endField]),
////            progress: item[config.progressField] ? Number(item[config.progressField]) : 0,
////            type: item[config.typeField] || 'task',
////            styles: { progressColor: '#ffbb54', progressSelectedColor: '#ff9e0d' },
////        }));
////
////        return (
////            <div style={{ overflowX: 'auto', width: '100%' }}>
////                <Gantt
////                    tasks={tasks}
////                    viewMode="Day"
////                    listCellWidth=""
////                    columnWidth={60}
////                    fontSize="12"
////                    locale="zh-CN"
////                />
////            </div>
////        );
////    } catch (error) {
////        console.error('Error rendering Gantt chart:', error);
////        return <Empty description="渲染甘特图时出错" />;
////    }
////};
////
////export default DataAnalysis;
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
////import React, { useState, useEffect } from 'react';
////import {
////  Card, Select, Button, Row, Col, DatePicker, Divider, Spin,
////  Collapse, Form, Input, Slider, Tabs, Empty, message, Upload,
////  Modal, Space, Radio
////} from 'antd';
////import {
////  BarChartOutlined, LineChartOutlined, PieChartOutlined,
////  TableOutlined, AppstoreAddOutlined, DeleteOutlined,
////  EditOutlined, DragOutlined, UploadOutlined,
////  ScheduleOutlined, AppstoreOutlined, DownOutlined, UpOutlined
////} from '@ant-design/icons';
////import { Chart } from 'react-chartjs-2';
////import { Chart as ChartJS, registerables } from 'chart.js';
////import 'chartjs-plugin-datalabels';
////import { Table } from 'antd';
////import { DndContext, DragOverlay, closestCenter } from '@dnd-kit/core';
////import { arrayMove, SortableContext, horizontalListSortingStrategy } from '@dnd-kit/sortable';
////import { restrictToHorizontalAxis } from '@dnd-kit/modifiers';
////import { useSortable } from '@dnd-kit/sortable';
////import { CSS } from '@dnd-kit/utilities';
////import { Gantt } from 'gantt-task-react';
////import "gantt-task-react/dist/index.css";
////import Papa from 'papaparse';
////import { read, utils } from 'xlsx';
////
////ChartJS.register(...registerables);
////
////const { Option } = Select;
////const { Panel } = Collapse;
////const { TabPane } = Tabs;
////const { Dragger } = Upload;
////
////// 可拖拽的展示项组件
////const SortableItem = ({ id, children, span }) => {
////  const {
////    attributes,
////    listeners,
////    setNodeRef,
////    transform,
////    transition,
////    isDragging,
////  } = useSortable({ id });
////
////  const style = {
////    transform: CSS.Transform.toString(transform),
////    transition,
////    opacity: isDragging ? 0.5 : 1,
////  };
////
////  return (
////    <Col span={span} ref={setNodeRef} style={style} {...attributes}>
////      <Card
////        title={
////          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
////            <span>{children.props.title}</span>
////            <div>
////              <Button
////                type="text"
////                icon={<DragOutlined />}
////                {...listeners}
////                style={{ cursor: 'move' }}
////              />
////              <Button
////                type="text"
////                icon={<EditOutlined />}
////                onClick={() => children.props.onEdit()}
////              />
////              <Button
////                type="text"
////                icon={<DeleteOutlined />}
////                onClick={() => children.props.onDelete()}
////              />
////            </div>
////          </div>
////        }
////      >
////        {children}
////      </Card>
////    </Col>
////  );
////};
////
////// 可视化组件类型
////const CHART_TYPES = {
////  line: { name: '折线图', icon: <LineChartOutlined /> },
////  bar: { name: '柱状图', icon: <BarChartOutlined /> },
////  pie: { name: '饼图', icon: <PieChartOutlined /> },
////  table: { name: '表格', icon: <TableOutlined /> },
////  pivot: { name: '透视表', icon: <AppstoreOutlined /> },
////  gantt: { name: '甘特图', icon: <ScheduleOutlined /> },
////};
////
////const DataAnalysis = ({ initialData }) => {
////  const [loading, setLoading] = useState(false);
////  const [dimensions, setDimensions] = useState([]);
////  const [metrics, setMetrics] = useState([]);
////  const [activeTab, setActiveTab] = useState('line');
////  const [configForm] = Form.useForm();
////  const [widgets, setWidgets] = useState([]);
////  const [activeId, setActiveId] = useState(null);
////  const [dataSource, setDataSource] = useState(initialData || []);
////  const [dataConfigVisible, setDataConfigVisible] = useState(false);
////  const [dataSourceType, setDataSourceType] = useState(initialData ? 'initial' : 'upload');
////  const [configCollapsed, setConfigCollapsed] = useState(false);
////
////  // 获取维度和指标
////  useEffect(() => {
////    if (dataSource.length > 0) {
////      extractDimensionsAndMetrics();
////    }
////  }, [dataSource]);
////
////  const extractDimensionsAndMetrics = () => {
////    if (dataSource.length === 0) return;
////
////    try {
////      // 从数据中提取维度和指标
////      const sampleItem = dataSource[0];
////      const extractedDims = [];
////      const extractedMetrics = [];
////
////      Object.keys(sampleItem).forEach(key => {
////        const value = sampleItem[key];
////        if (typeof value === 'string' || value instanceof Date) {
////          extractedDims.push({ field: key, name: key });
////        } else if (typeof value === 'number') {
////          extractedMetrics.push({ field: key, name: key });
////        }
////      });
////
////      setDimensions(extractedDims);
////      setMetrics(extractedMetrics);
////    } catch (error) {
////      console.error('Error extracting dimensions and metrics:', error);
////      message.error('提取数据字段失败');
////    }
////  };
////
////  // 处理上传数据
////  const handleUpload = (file) => {
////    const reader = new FileReader();
////    reader.onload = (e) => {
////      try {
////        let data;
////        if (file.type === 'text/csv') {
////          const result = Papa.parse(e.target.result, { header: true });
////          data = result.data;
////        } else if (file.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || file.type === 'application/vnd.ms-excel') {
////          const workbook = read(e.target.result, { type: 'binary' });
////          const firstSheetName = workbook.SheetNames[0];
////          const worksheet = workbook.Sheets[firstSheetName];
////          data = utils.sheet_to_json(worksheet);
////        } else {
////          message.error('仅支持 CSV 或 Excel 文件');
////          return;
////        }
////
////        if (Array.isArray(data)) {
////          setDataSource(data);
////          setDataConfigVisible(false);
////          message.success('数据上传成功');
////        } else {
////          message.error('上传的数据必须是数组格式');
////        }
////      } catch (err) {
////        console.error('Error parsing uploaded file:', err);
////        message.error('解析上传文件失败');
////      }
////    };
////
////    if (file.type === 'text/csv') {
////      reader.readAsText(file);
////    } else {
////      reader.readAsBinaryString(file);
////    }
////    return false; // 阻止默认上传行为
////  };
////
////  // 添加可视化组件
////  const addWidget = () => {
////    configForm.validateFields().then(values => {
////      const newWidget = {
////        id: `widget-${Date.now()}`,
////        type: activeTab,
////        title: values.title || CHART_TYPES[activeTab].name,
////        span: values.span || 8,
////        config: { ...values },
////      };
////
////      setWidgets([...widgets, newWidget]);
////      configForm.resetFields();
////      message.success('组件添加成功');
////    }).catch(err => {
////      console.error('Validation failed:', err);
////    });
////  };
////
////  // 删除组件
////  const deleteWidget = (id) => {
////    setWidgets(widgets.filter(w => w.id !== id));
////  };
////
////  // 编辑组件
////  const editWidget = (id) => {
////    const widget = widgets.find(w => w.id === id);
////    if (widget) {
////      setActiveTab(widget.type);
////      configForm.setFieldsValue({
////        ...widget.config,
////        title: widget.title,
////        span: widget.span,
////      });
////      deleteWidget(id);
////    }
////  };
////
////  // 拖拽相关函数
////  const handleDragStart = (event) => {
////    setActiveId(event.active.id);
////  };
////
////  const handleDragEnd = (event) => {
////    const { active, over } = event;
////
////    if (active.id !== over.id) {
////      setWidgets((items) => {
////        const oldIndex = items.findIndex(item => item.id === active.id);
////        const newIndex = items.findIndex(item => item.id === over.id);
////        return arrayMove(items, oldIndex, newIndex);
////      });
////    }
////
////    setActiveId(null);
////  };
////
////  // 渲染可视化组件
////  const renderWidget = (widget) => {
////    const { id, type, title, span, config } = widget;
////
////    switch (type) {
////      case 'line':
////      case 'bar':
////        return (
////          <ChartWidget
////            key={id}
////            id={id}
////            title={title}
////            type={type}
////            config={config}
////            data={dataSource}
////            onEdit={() => editWidget(id)}
////            onDelete={() => deleteWidget(id)}
////          />
////        );
////      case 'pie':
////        return (
////          <PieWidget
////            key={id}
////            id={id}
////            title={title}
////            config={config}
////            data={dataSource}
////            onEdit={() => editWidget(id)}
////            onDelete={() => deleteWidget(id)}
////          />
////        );
////      case 'table':
////        return (
////          <TableWidget
////            key={id}
////            id={id}
////            title={title}
////            config={config}
////            data={dataSource}
////            onEdit={() => editWidget(id)}
////            onDelete={() => deleteWidget(id)}
////          />
////        );
////      case 'pivot':
////        return (
////          <PivotWidget
////            key={id}
////            id={id}
////            title={title}
////            config={config}
////            data={dataSource}
////            onEdit={() => editWidget(id)}
////            onDelete={() => deleteWidget(id)}
////          />
////        );
////      case 'gantt':
////        return (
////          <GanttWidget
////            key={id}
////            id={id}
////            title={title}
////            config={config}
////            data={dataSource}
////            onEdit={() => editWidget(id)}
////            onDelete={() => deleteWidget(id)}
////          />
////        );
////      default:
////        return null;
////    }
////  };
////
////  // 渲染配置表单
////  const renderConfigForm = () => {
////    switch (activeTab) {
////      case 'line':
////      case 'bar':
////        return (
////          <>
////            <Form.Item label="X轴" name="xField" rules={[{ required: true, message: '请选择X轴字段' }]}>
////              <Select placeholder="选择X轴字段">
////                {dimensions.map(dim => (
////                  <Option key={dim.field} value={dim.field}>{dim.name}</Option>
////                ))}
////              </Select>
////            </Form.Item>
////            <Form.Item label="Y轴" name="yField" rules={[{ required: true, message: '请选择Y轴字段' }]}>
////              <Select mode="multiple" placeholder="选择Y轴字段">
////                {metrics.map(metric => (
////                  <Option key={metric.field} value={metric.field}>{metric.name}</Option>
////                ))}
////              </Select>
////            </Form.Item>
////          </>
////        );
////      case 'pie':
////        return (
////          <>
////            <Form.Item label="分类字段" name="categoryField" rules={[{ required: true, message: '请选择分类字段' }]}>
////              <Select placeholder="选择分类字段">
////                {dimensions.map(dim => (
////                  <Option key={dim.field} value={dim.field}>{dim.name}</Option>
////                ))}
////              </Select>
////            </Form.Item>
////            <Form.Item label="数值字段" name="valueField" rules={[{ required: true, message: '请选择数值字段' }]}>
////              <Select placeholder="选择数值字段">
////                {metrics.map(metric => (
////                  <Option key={metric.field} value={metric.field}>{metric.name}</Option>
////                ))}
////              </Select>
////            </Form.Item>
////          </>
////        );
////      case 'table':
////        return (
////          <Form.Item label="显示列" name="columns" rules={[{ required: true, message: '请选择显示列' }]}>
////            <Select mode="multiple" placeholder="选择要显示的列">
////              {[...dimensions, ...metrics].map(item => (
////                <Option key={item.field} value={item.field}>{item.name}</Option>
////              ))}
////            </Select>
////          </Form.Item>
////        );
////      case 'pivot':
////        const [rows, cols] = configForm.getFieldsValue(['rows', 'cols']);
////        const availableMetrics = metrics.filter(metric => {
////          return (!rows || !rows.includes(metric.field)) && (!cols || !cols.includes(metric.field));
////        });
////        return (
////          <>
////            <Form.Item label="行维度" name="rows" rules={[{ required: true, message: '请选择行维度' }]}>
////              <Select mode="multiple" placeholder="选择行维度">
////                {dimensions.map(dim => (
////                  <Option key={dim.field} value={dim.field}>{dim.name}</Option>
////                ))}
////              </Select>
////            </Form.Item>
////            <Form.Item label="列维度" name="cols">
////              <Select mode="multiple" placeholder="选择列维度">
////                {dimensions.map(dim => (
////                  <Option key={dim.field} value={dim.field}>{dim.name}</Option>
////                ))}
////              </Select>
////            </Form.Item>
////            <Form.Item label="数值字段" name="values" rules={[{ required: true, message: '请选择数值字段' }]}>
////              <Select mode="multiple" placeholder="选择数值字段">
////                {availableMetrics.map(metric => (
////                  <Option key={metric.field} value={metric.field}>{metric.name}</Option>
////                ))}
////              </Select>
////            </Form.Item>
////            <Form.Item label="聚合方式" name="aggregate" initialValue="sum">
////              <Select>
////                <Option value="sum">求和</Option>
////                <Option value="avg">平均值</Option>
////                <Option value="count">计数</Option>
////                <Option value="max">最大值</Option>
////                <Option value="min">最小值</Option>
////              </Select>
////            </Form.Item>
////          </>
////        );
////      case 'gantt':
////        return (
////          <>
////            <Form.Item label="任务名称" name="taskField" rules={[{ required: true, message: '请选择任务名字段' }]}>
////              <Select placeholder="选择任务名字段">
////                {dimensions.map(dim => (
////                  <Option key={dim.field} value={dim.field}>{dim.name}</Option>
////                ))}
////              </Select>
////            </Form.Item>
////            <Form.Item label="开始时间" name="startField" rules={[{ required: true, message: '请选择开始时间字段' }]}>
////              <Select placeholder="选择开始时间字段">
////                {dimensions.filter(d => d.field.toLowerCase().includes('date') || d.field.toLowerCase().includes('time')).map(dim => (
////                  <Option key={dim.field} value={dim.field}>{dim.name}</Option>
////                ))}
////              </Select>
////            </Form.Item>
////            <Form.Item label="结束时间" name="endField" rules={[{ required: true, message: '请选择结束时间字段' }]}>
////              <Select placeholder="选择结束时间字段">
////                {dimensions.filter(d => d.field.toLowerCase().includes('date') || d.field.toLowerCase().includes('time')).map(dim => (
////                  <Option key={dim.field} value={dim.field}>{dim.name}</Option>
////                ))}
////              </Select>
////            </Form.Item>
////            <Form.Item label="进度" name="progressField">
////              <Select placeholder="选择进度字段(可选)">
////                {metrics.map(metric => (
////                  <Option key={metric.field} value={metric.field}>{metric.name}</Option>
////                ))}
////              </Select>
////            </Form.Item>
////            <Form.Item label="任务类型" name="typeField">
////              <Select placeholder="选择任务类型字段(可选)">
////                {dimensions.map(dim => (
////                  <Option key={dim.field} value={dim.field}>{dim.name}</Option>
////                ))}
////              </Select>
////            </Form.Item>
////          </>
////        );
////      default:
////        return null;
////    }
////  };
////
////  return (
////    <div className="data-analysis-container">
////      {/* 数据配置模态框 */}
////      <Modal
////        title="数据配置"
////        visible={dataConfigVisible}
////        onCancel={() => setDataConfigVisible(false)}
////        footer={null}
////        width={800}
////      >
////        <Radio.Group
////          value={dataSourceType}
////          onChange={(e) => setDataSourceType(e.target.value)}
////          style={{ marginBottom: 16 }}
////        >
////          <Radio.Button value="initial">使用初始数据</Radio.Button>
////          <Radio.Button value="upload">上传数据</Radio.Button>
////        </Radio.Group>
////
////        {dataSourceType === 'upload' && (
////          <Dragger
////            name="file"
////            accept=".csv, .xlsx, .xls"
////            beforeUpload={handleUpload}
////            showUploadList={false}
////          >
////            <p className="ant-upload-drag-icon">
////              <UploadOutlined />
////            </p>
////            <p className="ant-upload-text">点击或拖拽 CSV 或 Excel 文件到此处上传</p>
////            <p className="ant-upload-hint">
////              支持上传 CSV 或 Excel 格式的数据文件，数据应为表格形式
////            </p>
////          </Dragger>
////        )}
////
////        {dataSourceType === 'initial' && initialData && (
////          <div>
////            <h4>当前使用初始数据</h4>
////            <p>数据量: {initialData.length} 条</p>
////            <Button
////              type="primary"
////              onClick={() => {
////                setDataSource(initialData);
////                setDataConfigVisible(false);
////              }}
////            >
////              确认使用
////            </Button>
////          </div>
////        )}
////      </Modal>
////
////      <Row gutter={16}>
////        {/* 配置区 - 宽度调整为6列 */}
////        <Col span={configCollapsed ? 0 : 6}>
////          <Card
////            title={
////              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
////                <span>可视化配置</span>
////                <Button
////                  type="text"
////                  icon={configCollapsed ? <UpOutlined /> : <DownOutlined />}
////                  onClick={() => setConfigCollapsed(!configCollapsed)}
////                />
////              </div>
////            }
////            extra={
////              <Button
////                type="primary"
////                icon={<AppstoreAddOutlined />}
////                onClick={addWidget}
////                disabled={dataSource.length === 0}
////              >
////                添加组件
////              </Button>
////            }
////          >
////            <Collapse defaultActiveKey={['1']}>
////              <Panel header="数据配置" key="1">
////                <Space direction="vertical" style={{ width: '100%' }}>
////                  <Button
////                    type="primary"
////                    onClick={() => setDataConfigVisible(true)}
////                    block
////                  >
////                    {dataSource.length > 0 ? '更改数据' : '配置数据'}
////                  </Button>
////                  {dataSource.length > 0 && (
////                    <div>
////                      <p>当前数据量: {dataSource.length} 条</p>
////                      <p>维度字段: {dimensions.length} 个</p>
////                      <p>指标字段: {metrics.length} 个</p>
////                    </div>
////                  )}
////                </Space>
////              </Panel>
////              <Panel header="组件配置" key="2">
////                <Tabs activeKey={activeTab} onChange={setActiveTab}>
////                  {Object.entries(CHART_TYPES).map(([key, { name, icon }]) => (
////                    <TabPane tab={<span>{icon} {name}</span>} key={key} />
////                  ))}
////                </Tabs>
////
////                <Form form={configForm} layout="vertical">
////                  <Form.Item label="标题" name="title">
////                    <Input placeholder="输入组件标题" />
////                  </Form.Item>
////                  <Form.Item label="宽度占比" name="span" initialValue={8}>
////                    <Slider
////                      min={4}
////                      max={24}
////                      step={4}
////                      marks={{ 4: '1/6', 8: '1/3', 12: '1/2', 16: '2/3', 20: '5/6', 24: '100%' }}
////                    />
////                  </Form.Item>
////
////                  {renderConfigForm()}
////                </Form>
////              </Panel>
////            </Collapse>
////          </Card>
////        </Col>
////
////        {/* 展示区 - 宽度调整为根据配置区是否折叠动态变化 */}
////        <Col span={configCollapsed ? 24 : 18}>
////          <Card
////            title="可视化展示"
////            loading={loading}
////            extra={
////              dataSource.length > 0 && (
////                <span>数据量: {dataSource.length} 条</span>
////              )
////            }
////          >
////            {dataSource.length === 0 ? (
////              <Empty
////                description={
////                  <span>
////                    <p>暂无数据</p>
////                    <Button
////                      type="primary"
////                      onClick={() => setDataConfigVisible(true)}
////                    >
////                      配置数据
////                    </Button>
////                  </span>
////                }
////              />
////            ) : widgets.length === 0 ? (
////              <Empty description="请添加可视化组件" />
////            ) : (
////              <DndContext
////                modifiers={[restrictToHorizontalAxis]}
////                collisionDetection={closestCenter}
////                onDragStart={handleDragStart}
////                onDragEnd={handleDragEnd}
////              >
////                <SortableContext
////                  items={widgets.map(w => w.id)}
////                  strategy={horizontalListSortingStrategy}
////                >
////                  <Row gutter={16}>
////                    {widgets.map(widget => (
////                      <SortableItem key={widget.id} id={widget.id} span={widget.span}>
////                        {renderWidget(widget)}
////                      </SortableItem>
////                    ))}
////                  </Row>
////                </SortableContext>
////
////                <DragOverlay>
////                  {activeId ? (
////                    <div style={{
////                      width: '100%',
////                      backgroundColor: 'rgba(255, 255, 255, 0.8)',
////                      boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
////                      borderRadius: 4
////                    }}>
////                      {renderWidget(widgets.find(w => w.id === activeId))}
////                    </div>
////                  ) : null}
////                </DragOverlay>
////              </DndContext>
////            )}
////          </Card>
////        </Col>
////      </Row>
////    </div>
////  );
////};
////
////const ChartWidget = ({ title, type, config, data, onEdit, onDelete }) => {
////  if (!config || !data.length) return <Empty description="配置不完整或数据为空" />;
////
////  const chartData = {
////    labels: data.map(item => item[config.xField]),
////    datasets: config.yField.map((field, index) => ({
////      label: field,
////      data: data.map(item => item[field]),
////      backgroundColor: `hsl(${index * 360 / config.yField.length}, 70%, 50%)`,
////      borderColor: `hsl(${index * 360 / config.yField.length}, 70%, 30%)`,
////      borderWidth: 1,
////    })),
////  };
////
////  const options = {
////    responsive: true,
////    plugins: {
////      legend: {
////        position: 'top',
////      },
////    },
////  };
////
////  return (
////    <div style={{ height: 400 }}>
////      <Chart type={type} data={chartData} options={options} />
////    </div>
////  );
////};
////
////// 饼图组件
////const PieWidget = ({ title, config, data, onEdit, onDelete }) => {
////  if (!config || !data.length) return <Empty description="配置不完整或数据为空" />;
////
////  const chartData = {
////    labels: data.map(item => item[config.categoryField]),
////    datasets: [{
////      data: data.map(item => item[config.valueField]),
////      backgroundColor: data.map((_, index) =>
////        `hsl(${index * 360 / data.length}, 70%, 50%)`
////      ),
////    }],
////  };
////
////  const options = {
////    responsive: true,
////    plugins: {
////      legend: {
////        position: 'right',
////      },
////    },
////  };
////
////  return (
////    <div style={{ height: 400 }}>
////      <Chart type="pie" data={chartData} options={options} />
////    </div>
////  );
////};
////
////// 表格组件
////const TableWidget = ({ title, config, data, onEdit, onDelete }) => {
////  if (!config || !data.length) return <Empty description="配置不完整或数据为空" />;
////
////  const columns = config.columns.map(col => ({
////    title: col,
////    dataIndex: col,
////    key: col,
////  }));
////
////  return (
////    <Table
////      columns={columns}
////      dataSource={data}
////      size="small"
////      scroll={{ x: true }}
////      pagination={{ pageSize: 5 }}
////    />
////  );
////};
////
////// 透视表组件
////const PivotWidget = ({ title, config, data, onEdit, onDelete }) => {
////  if (!config || !data.length) return <Empty description="配置不完整或数据为空" />;
////
////  // 这里简化实现，实际项目中可以使用专门的透视表库
////  const pivotData = {};
////
////  // 生成透视数据
////  data.forEach(item => {
////    const rowKey = config.rows.map(row => item[row]).join('-');
////    const colKey = config.cols?.length > 0 ? config.cols.map(col => item[col]).join('-') : '总计';
////
////    if (!pivotData[rowKey]) {
////      pivotData[rowKey] = { key: rowKey };
////      config.rows.forEach(row => {
////        pivotData[rowKey][row] = item[row];
////      });
////    }
////
////    config.values.forEach(value => {
////      const fieldName = colKey === '总计' ? value : `${value}_${colKey}`;
////      pivotData[rowKey][fieldName] = (pivotData[rowKey][fieldName] || 0) + (item[value] || 0);
////    });
////  });
////
////  const columns = [
////    ...config.rows.map(row => ({
////      title: row,
////      dataIndex: row,
////      key: row,
////    })),
////    ...Object.keys(pivotData[Object.keys(pivotData)[0]])
////      .filter(key => !config.rows.includes(key) && key !== 'key')
////      .map(key => ({
////        title: key,
////        dataIndex: key,
////        key: key,
////      }))
////  ];
////
////  return (
////    <Table
////      columns={columns}
////      dataSource={Object.values(pivotData)}
////      size="small"
////      scroll={{ x: true }}
////      pagination={{ pageSize: 5 }}
////    />
////  );
////};
////
////// 甘特图组件
////const GanttWidget = ({ title, config, data, onEdit, onDelete }) => {
////  if (!config || !data.length) return <Empty description="配置不完整或数据为空" />;
////
////  try {
////    // 转换数据为甘特图需要的格式
////    const tasks = data.map(item => ({
////      id: item[config.taskField] || Math.random().toString(36).substr(2, 9),
////      name: String(item[config.taskField] || '未命名任务'),
////      start: new Date(item[config.startField]),
////      end: new Date(item[config.endField]),
////      progress: item[config.progressField] ? Number(item[config.progressField]) : 0,
////      type: item[config.typeField] || 'task',
////      styles: { progressColor: '#ffbb54', progressSelectedColor: '#ff9e0d' },
////    }));
////
////    return (
////      <div style={{ overflowX: 'auto', width: '100%' }}>
////        <Gantt
////          tasks={tasks}
////          viewMode="Day"
////          listCellWidth=""
////          columnWidth={60}
////          fontSize="12"
////          locale="zh-CN"
////        />
////      </div>
////    );
////  } catch (error) {
////    console.error('Error rendering Gantt chart:', error);
////    return <Empty description="渲染甘特图时出错" />;
////  }
////};
////
////export default DataAnalysis;
//
////import React, { useState, useEffect } from 'react';
////import {
////  Card, Select, Button, Row, Col, DatePicker, Divider, Spin,
////  Collapse, Form, Input, Slider, Tabs, Empty, message, Upload,
////  Modal, Space, Radio
////} from 'antd';
////import {
////  BarChartOutlined, LineChartOutlined, PieChartOutlined,
////  TableOutlined, AppstoreAddOutlined, DeleteOutlined,
////  EditOutlined, DragOutlined, UploadOutlined,
////  ScheduleOutlined, AppstoreOutlined, DownOutlined, UpOutlined
////} from '@ant-design/icons';
////import { Chart } from 'react-chartjs-2';
////import { Chart as ChartJS, registerables } from 'chart.js';
////import 'chartjs-plugin-datalabels';
////import { Table } from 'antd';
////import { DndContext, DragOverlay, closestCenter } from '@dnd-kit/core';
////import { arrayMove, SortableContext, horizontalListSortingStrategy } from '@dnd-kit/sortable';
////import { restrictToHorizontalAxis } from '@dnd-kit/modifiers';
////import { useSortable } from '@dnd-kit/sortable';
////import { CSS } from '@dnd-kit/utilities';
////import { Gantt } from 'gantt-task-react';
////import "gantt-task-react/dist/index.css";
////import Papa from 'papaparse';
////import { read, utils } from 'xlsx';
////
////ChartJS.register(...registerables);
////
////const { Option } = Select;
////const { Panel } = Collapse;
////const { TabPane } = Tabs;
////const { Dragger } = Upload;
////
////// 可拖拽的展示项组件
////const SortableItem = ({ id, children, span }) => {
////  const {
////    attributes,
////    listeners,
////    setNodeRef,
////    transform,
////    transition,
////    isDragging,
////  } = useSortable({ id });
////
////  const style = {
////    transform: CSS.Transform.toString(transform),
////    transition,
////    opacity: isDragging ? 0.5 : 1,
////  };
////
////  return (
////    <Col span={span} ref={setNodeRef} style={style} {...attributes}>
////      <Card
////        title={
////          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
////            <span>{children.props.title}</span>
////            <div>
////              <Button
////                type="text"
////                icon={<DragOutlined />}
////                {...listeners}
////                style={{ cursor: 'move' }}
////              />
////              <Button
////                type="text"
////                icon={<EditOutlined />}
////                onClick={() => children.props.onEdit()}
////              />
////              <Button
////                type="text"
////                icon={<DeleteOutlined />}
////                onClick={() => children.props.onDelete()}
////              />
////            </div>
////          </div>
////        }
////      >
////        {children}
////      </Card>
////    </Col>
////  );
////};
////
////// 可视化组件类型
////const CHART_TYPES = {
////  line: { name: '折线图', icon: <LineChartOutlined /> },
////  bar: { name: '柱状图', icon: <BarChartOutlined /> },
////  pie: { name: '饼图', icon: <PieChartOutlined /> },
////  table: { name: '表格', icon: <TableOutlined /> },
////  pivot: { name: '透视表', icon: <AppstoreOutlined /> },
////  gantt: { name: '甘特图', icon: <ScheduleOutlined /> },
////};
////
////const DataAnalysis = ({ initialData }) => {
////  const [loading, setLoading] = useState(false);
////  const [dimensions, setDimensions] = useState([]);
////  const [metrics, setMetrics] = useState([]);
////  const [activeTab, setActiveTab] = useState('line');
////  const [configForm] = Form.useForm();
////  const [widgets, setWidgets] = useState([]);
////  const [activeId, setActiveId] = useState(null);
////  const [dataSource, setDataSource] = useState(initialData || []);
////  const [dataConfigVisible, setDataConfigVisible] = useState(false);
////  const [dataSourceType, setDataSourceType] = useState(initialData ? 'initial' : 'upload');
////  const [configCollapsed, setConfigCollapsed] = useState(false);
////
////  // 获取维度和指标
////  useEffect(() => {
////    if (dataSource.length > 0) {
////      extractDimensionsAndMetrics();
////    }
////  }, [dataSource]);
////
////  const extractDimensionsAndMetrics = () => {
////    if (dataSource.length === 0) return;
////
////    try {
////      // 从数据中提取维度和指标
////      const sampleItem = dataSource[0];
////      const extractedDims = [];
////      const extractedMetrics = [];
////
////      Object.keys(sampleItem).forEach(key => {
////        const value = sampleItem[key];
////        if (typeof value === 'string' || value instanceof Date) {
////          extractedDims.push({ field: key, name: key });
////        } else if (typeof value === 'number') {
////          extractedMetrics.push({ field: key, name: key });
////        }
////      });
////
////      setDimensions(extractedDims);
////      setMetrics(extractedMetrics);
////    } catch (error) {
////      console.error('Error extracting dimensions and metrics:', error);
////      message.error('提取数据字段失败');
////    }
////  };
////
////  // 处理上传数据
////  const handleUpload = (file) => {
////    const reader = new FileReader();
////    reader.onload = (e) => {
////      try {
////        let data;
////        if (file.type === 'text/csv') {
////          const result = Papa.parse(e.target.result, { header: true });
////          data = result.data;
////        } else if (file.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || file.type === 'application/vnd.ms-excel') {
////          const workbook = read(e.target.result, { type: 'binary' });
////          const firstSheetName = workbook.SheetNames[0];
////          const worksheet = workbook.Sheets[firstSheetName];
////          data = utils.sheet_to_json(worksheet);
////        } else {
////          message.error('仅支持 CSV 或 Excel 文件');
////          return;
////        }
////
////        if (Array.isArray(data)) {
////          setDataSource(data);
////          setDataConfigVisible(false);
////          message.success('数据上传成功');
////        } else {
////          message.error('上传的数据必须是数组格式');
////        }
////      } catch (err) {
////        console.error('Error parsing uploaded file:', err);
////        message.error('解析上传文件失败');
////      }
////    };
////
////    if (file.type === 'text/csv') {
////      reader.readAsText(file);
////    } else {
////      reader.readAsBinaryString(file);
////    }
////    return false; // 阻止默认上传行为
////  };
////
////  // 添加可视化组件
////  const addWidget = () => {
////    configForm.validateFields().then(values => {
////      const newWidget = {
////        id: `widget-${Date.now()}`,
////        type: activeTab,
////        title: values.title || CHART_TYPES[activeTab].name,
////        span: values.span || 8,
////        config: { ...values },
////      };
////
////      setWidgets([...widgets, newWidget]);
////      configForm.resetFields();
////      message.success('组件添加成功');
////    }).catch(err => {
////      console.error('Validation failed:', err);
////    });
////  };
////
////  // 删除组件
////  const deleteWidget = (id) => {
////    setWidgets(widgets.filter(w => w.id !== id));
////  };
////
////  // 编辑组件
////  const editWidget = (id) => {
////    const widget = widgets.find(w => w.id === id);
////    if (widget) {
////      setActiveTab(widget.type);
////      configForm.setFieldsValue({
////        ...widget.config,
////        title: widget.title,
////        span: widget.span,
////      });
////      deleteWidget(id);
////    }
////  };
////
////  // 拖拽相关函数
////  const handleDragStart = (event) => {
////    setActiveId(event.active.id);
////  };
////
////  const handleDragEnd = (event) => {
////    const { active, over } = event;
////
////    if (active.id !== over.id) {
////      setWidgets((items) => {
////        const oldIndex = items.findIndex(item => item.id === active.id);
////        const newIndex = items.findIndex(item => item.id === over.id);
////        return arrayMove(items, oldIndex, newIndex);
////      });
////    }
////
////    setActiveId(null);
////  };
////
////  // 渲染可视化组件
////  const renderWidget = (widget) => {
////    const { id, type, title, span, config } = widget;
////
////    switch (type) {
////      case 'line':
////      case 'bar':
////        return (
////          <ChartWidget
////            key={id}
////            id={id}
////            title={title}
////            type={type}
////            config={config}
////            data={dataSource}
////            onEdit={() => editWidget(id)}
////            onDelete={() => deleteWidget(id)}
////          />
////        );
////      case 'pie':
////        return (
////          <PieWidget
////            key={id}
////            id={id}
////            title={title}
////            config={config}
////            data={dataSource}
////            onEdit={() => editWidget(id)}
////            onDelete={() => deleteWidget(id)}
////          />
////        );
////      case 'table':
////        return (
////          <TableWidget
////            key={id}
////            id={id}
////            title={title}
////            config={config}
////            data={dataSource}
////            onEdit={() => editWidget(id)}
////            onDelete={() => deleteWidget(id)}
////          />
////        );
////      case 'pivot':
////        return (
////          <PivotWidget
////            key={id}
////            id={id}
////            title={title}
////            config={config}
////            data={dataSource}
////            onEdit={() => editWidget(id)}
////            onDelete={() => deleteWidget(id)}
////          />
////        );
////      case 'gantt':
////        return (
////          <GanttWidget
////            key={id}
////            id={id}
////            title={title}
////            config={config}
////            data={dataSource}
////            onEdit={() => editWidget(id)}
////            onDelete={() => deleteWidget(id)}
////          />
////        );
////      default:
////        return null;
////    }
////  };
////
////  // 渲染配置表单
////  const renderConfigForm = () => {
////    switch (activeTab) {
////      case 'line':
////      case 'bar':
////        return (
////          <>
////            <Form.Item label="X轴" name="xField" rules={[{ required: true, message: '请选择X轴字段' }]}>
////              <Select placeholder="选择X轴字段">
////                {dimensions.map(dim => (
////                  <Option key={dim.field} value={dim.field}>{dim.name}</Option>
////                ))}
////              </Select>
////            </Form.Item>
////            <Form.Item label="Y轴" name="yField" rules={[{ required: true, message: '请选择Y轴字段' }]}>
////              <Select mode="multiple" placeholder="选择Y轴字段">
////                {metrics.map(metric => (
////                  <Option key={metric.field} value={metric.field}>{metric.name}</Option>
////                ))}
////              </Select>
////            </Form.Item>
////          </>
////        );
////      case 'pie':
////        return (
////          <>
////            <Form.Item label="分类字段" name="categoryField" rules={[{ required: true, message: '请选择分类字段' }]}>
////              <Select placeholder="选择分类字段">
////                {dimensions.map(dim => (
////                  <Option key={dim.field} value={dim.field}>{dim.name}</Option>
////                ))}
////              </Select>
////            </Form.Item>
////            <Form.Item label="数值字段" name="valueField" rules={[{ required: true, message: '请选择数值字段' }]}>
////              <Select placeholder="选择数值字段">
////                {metrics.map(metric => (
////                  <Option key={metric.field} value={metric.field}>{metric.name}</Option>
////                ))}
////              </Select>
////            </Form.Item>
////          </>
////        );
////      case 'table':
////        return (
////          <Form.Item label="显示列" name="columns" rules={[{ required: true, message: '请选择显示列' }]}>
////            <Select mode="multiple" placeholder="选择要显示的列">
////              {[...dimensions, ...metrics].map(item => (
////                <Option key={item.field} value={item.field}>{item.name}</Option>
////              ))}
////            </Select>
////          </Form.Item>
////        );
////      case 'pivot':
////        return (
////          <>
////            <Form.Item label="行维度" name="rows" rules={[{ required: true, message: '请选择行维度' }]}>
////              <Select mode="multiple" placeholder="选择行维度">
////                {dimensions.map(dim => (
////                  <Option key={dim.field} value={dim.field}>{dim.name}</Option>
////                ))}
////              </Select>
////            </Form.Item>
////            <Form.Item label="列维度" name="cols">
////              <Select mode="multiple" placeholder="选择列维度">
////                {dimensions.map(dim => (
////                  <Option key={dim.field} value={dim.field}>{dim.name}</Option>
////                ))}
////              </Select>
////            </Form.Item>
////            <Form.Item label="数值字段" name="values" rules={[{ required: true, message: '请选择数值字段' }]}>
////              <Select mode="multiple" placeholder="选择数值字段">
////                {metrics.map(metric => (
////                  <Option key={metric.field} value={metric.field}>{metric.name}</Option>
////                ))}
////              </Select>
////            </Form.Item>
////            <Form.Item label="聚合方式" name="aggregate" initialValue="sum">
////              <Select>
////                <Option value="sum">求和</Option>
////                <Option value="avg">平均值</Option>
////                <Option value="count">计数</Option>
////                <Option value="max">最大值</Option>
////                <Option value="min">最小值</Option>
////              </Select>
////            </Form.Item>
////          </>
////        );
////      case 'gantt':
////        return (
////          <>
////            <Form.Item label="任务名称" name="taskField" rules={[{ required: true, message: '请选择任务名字段' }]}>
////              <Select placeholder="选择任务名字段">
////                {dimensions.map(dim => (
////                  <Option key={dim.field} value={dim.field}>{dim.name}</Option>
////                ))}
////              </Select>
////            </Form.Item>
////            <Form.Item label="开始时间" name="startField" rules={[{ required: true, message: '请选择开始时间字段' }]}>
////              <Select placeholder="选择开始时间字段">
////                {dimensions.filter(d => d.field.toLowerCase().includes('date') || d.field.toLowerCase().includes('time')).map(dim => (
////                  <Option key={dim.field} value={dim.field}>{dim.name}</Option>
////                ))}
////              </Select>
////            </Form.Item>
////            <Form.Item label="结束时间" name="endField" rules={[{ required: true, message: '请选择结束时间字段' }]}>
////              <Select placeholder="选择结束时间字段">
////                {dimensions.filter(d => d.field.toLowerCase().includes('date') || d.field.toLowerCase().includes('time')).map(dim => (
////                  <Option key={dim.field} value={dim.field}>{dim.name}</Option>
////                ))}
////              </Select>
////            </Form.Item>
////            <Form.Item label="进度" name="progressField">
////              <Select placeholder="选择进度字段(可选)">
////                {metrics.map(metric => (
////                  <Option key={metric.field} value={metric.field}>{metric.name}</Option>
////                ))}
////              </Select>
////            </Form.Item>
////            <Form.Item label="任务类型" name="typeField">
////              <Select placeholder="选择任务类型字段(可选)">
////                {dimensions.map(dim => (
////                  <Option key={dim.field} value={dim.field}>{dim.name}</Option>
////                ))}
////              </Select>
////            </Form.Item>
////          </>
////        );
////      default:
////        return null;
////    }
////  };
////
////  return (
////    <div className="data-analysis-container">
////      {/* 数据配置模态框 */}
////      <Modal
////        title="数据配置"
////        visible={dataConfigVisible}
////        onCancel={() => setDataConfigVisible(false)}
////        footer={null}
////        width={800}
////      >
////        <Radio.Group
////          value={dataSourceType}
////          onChange={(e) => setDataSourceType(e.target.value)}
////          style={{ marginBottom: 16 }}
////        >
////          <Radio.Button value="initial">使用初始数据</Radio.Button>
////          <Radio.Button value="upload">上传数据</Radio.Button>
////        </Radio.Group>
////
////        {dataSourceType === 'upload' && (
////          <Dragger
////            name="file"
////            accept=".csv, .xlsx, .xls"
////            beforeUpload={handleUpload}
////            showUploadList={false}
////          >
////            <p className="ant-upload-drag-icon">
////              <UploadOutlined />
////            </p>
////            <p className="ant-upload-text">点击或拖拽 CSV 或 Excel 文件到此处上传</p>
////            <p className="ant-upload-hint">
////              支持上传 CSV 或 Excel 格式的数据文件，数据应为表格形式
////            </p>
////          </Dragger>
////        )}
////
////        {dataSourceType === 'initial' && initialData && (
////          <div>
////            <h4>当前使用初始数据</h4>
////            <p>数据量: {initialData.length} 条</p>
////            <Button
////              type="primary"
////              onClick={() => {
////                setDataSource(initialData);
////                setDataConfigVisible(false);
////              }}
////            >
////              确认使用
////            </Button>
////          </div>
////        )}
////      </Modal>
////
////      <Row gutter={16}>
////        {/* 配置区 - 宽度调整为6列 */}
////        <Col span={configCollapsed ? 0 : 6}>
////          <Card
////            title={
////              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
////                <span>可视化配置</span>
////                <Button
////                  type="text"
////                  icon={configCollapsed ? <UpOutlined /> : <DownOutlined />}
////                  onClick={() => setConfigCollapsed(!configCollapsed)}
////                />
////              </div>
////            }
////            extra={
////              <Button
////                type="primary"
////                icon={<AppstoreAddOutlined />}
////                onClick={addWidget}
////                disabled={dataSource.length === 0}
////              >
////                添加组件
////              </Button>
////            }
////          >
////            <Collapse defaultActiveKey={['1']}>
////              <Panel header="数据配置" key="1">
////                <Space direction="vertical" style={{ width: '100%' }}>
////                  <Button
////                    type="primary"
////                    onClick={() => setDataConfigVisible(true)}
////                    block
////                  >
////                    {dataSource.length > 0 ? '更改数据' : '配置数据'}
////                  </Button>
////                  {dataSource.length > 0 && (
////                    <div>
////                      <p>当前数据量: {dataSource.length} 条</p>
////                      <p>维度字段: {dimensions.length} 个</p>
////                      <p>指标字段: {metrics.length} 个</p>
////                    </div>
////                  )}
////                </Space>
////              </Panel>
////              <Panel header="组件配置" key="2">
////                <Tabs activeKey={activeTab} onChange={setActiveTab}>
////                  {Object.entries(CHART_TYPES).map(([key, { name, icon }]) => (
////                    <TabPane tab={<span>{icon} {name}</span>} key={key} />
////                  ))}
////                </Tabs>
////
////                <Form form={configForm} layout="vertical">
////                  <Form.Item label="标题" name="title">
////                    <Input placeholder="输入组件标题" />
////                  </Form.Item>
////                  <Form.Item label="宽度占比" name="span" initialValue={8}>
////                    <Slider
////                      min={4}
////                      max={24}
////                      step={4}
////                      marks={{ 4: '1/6', 8: '1/3', 12: '1/2', 16: '2/3', 20: '5/6', 24: '100%' }}
////                    />
////                  </Form.Item>
////
////                  {renderConfigForm()}
////                </Form>
////              </Panel>
////            </Collapse>
////          </Card>
////        </Col>
////
////        {/* 展示区 - 宽度调整为根据配置区是否折叠动态变化 */}
////        <Col span={configCollapsed ? 24 : 18}>
////          <Card
////            title="可视化展示"
////            loading={loading}
////            extra={
////              dataSource.length > 0 && (
////                <span>数据量: {dataSource.length} 条</span>
////              )
////            }
////          >
////            {dataSource.length === 0 ? (
////              <Empty
////                description={
////                  <span>
////                    <p>暂无数据</p>
////                    <Button
////                      type="primary"
////                      onClick={() => setDataConfigVisible(true)}
////                    >
////                      配置数据
////                    </Button>
////                  </span>
////                }
////              />
////            ) : widgets.length === 0 ? (
////              <Empty description="请添加可视化组件" />
////            ) : (
////              <DndContext
////                modifiers={[restrictToHorizontalAxis]}
////                collisionDetection={closestCenter}
////                onDragStart={handleDragStart}
////                onDragEnd={handleDragEnd}
////              >
////                <SortableContext
////                  items={widgets.map(w => w.id)}
////                  strategy={horizontalListSortingStrategy}
////                >
////                  <Row gutter={16}>
////                    {widgets.map(widget => (
////                      <SortableItem key={widget.id} id={widget.id} span={widget.span}>
////                        {renderWidget(widget)}
////                      </SortableItem>
////                    ))}
////                  </Row>
////                </SortableContext>
////
////                <DragOverlay>
////                  {activeId ? (
////                    <div style={{
////                      width: '100%',
////                      backgroundColor: 'rgba(255, 255, 255, 0.8)',
////                      boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
////                      borderRadius: 4
////                    }}>
////                      {renderWidget(widgets.find(w => w.id === activeId))}
////                    </div>
////                  ) : null}
////                </DragOverlay>
////              </DndContext>
////            )}
////          </Card>
////        </Col>
////      </Row>
////    </div>
////  );
////};
////
////const ChartWidget = ({ title, type, config, data, onEdit, onDelete }) => {
////  if (!config || !data.length) return <Empty description="配置不完整或数据为空" />;
////
////  const chartData = {
////    labels: data.map(item => item[config.xField]),
////    datasets: config.yField.map((field, index) => ({
////      label: field,
////      data: data.map(item => item[field]),
////      backgroundColor: `hsl(${index * 360 / config.yField.length}, 70%, 50%)`,
////      borderColor: `hsl(${index * 360 / config.yField.length}, 70%, 30%)`,
////      borderWidth: 1,
////    })),
////  };
////
////  const options = {
////    responsive: true,
////    plugins: {
////      legend: {
////        position: 'top',
////      },
////    },
////  };
////
////  return (
////    <div style={{ height: 400 }}>
////      <Chart type={type} data={chartData} options={options} />
////    </div>
////  );
////};
////
////// 饼图组件
////const PieWidget = ({ title, config, data, onEdit, onDelete }) => {
////  if (!config || !data.length) return <Empty description="配置不完整或数据为空" />;
////
////  const chartData = {
////    labels: data.map(item => item[config.categoryField]),
////    datasets: [{
////      data: data.map(item => item[config.valueField]),
////      backgroundColor: data.map((_, index) =>
////        `hsl(${index * 360 / data.length}, 70%, 50%)`
////      ),
////    }],
////  };
////
////  const options = {
////    responsive: true,
////    plugins: {
////      legend: {
////        position: 'right',
////      },
////    },
////  };
////
////  return (
////    <div style={{ height: 400 }}>
////      <Chart type="pie" data={chartData} options={options} />
////    </div>
////  );
////};
////
////// 表格组件
////const TableWidget = ({ title, config, data, onEdit, onDelete }) => {
////  if (!config || !data.length) return <Empty description="配置不完整或数据为空" />;
////
////  const columns = config.columns.map(col => ({
////    title: col,
////    dataIndex: col,
////    key: col,
////  }));
////
////  return (
////    <Table
////      columns={columns}
////      dataSource={data}
////      size="small"
////      scroll={{ x: true }}
////      pagination={{ pageSize: 5 }}
////    />
////  );
////};
////
////// 透视表组件
////const PivotWidget = ({ title, config, data, onEdit, onDelete }) => {
////  if (!config || !data.length) return <Empty description="配置不完整或数据为空" />;
////
////  // 这里简化实现，实际项目中可以使用专门的透视表库
////  const pivotData = {};
////
////  // 生成透视数据
////  data.forEach(item => {
////    const rowKey = config.rows.map(row => item[row]).join('-');
////    const colKey = config.cols?.length > 0 ? config.cols.map(col => item[col]).join('-') : '总计';
////
////    if (!pivotData[rowKey]) {
////      pivotData[rowKey] = { key: rowKey };
////      config.rows.forEach(row => {
////        pivotData[rowKey][row] = item[row];
////      });
////    }
////
////    config.values.forEach(value => {
////      const fieldName = colKey === '总计' ? value : `${value}_${colKey}`;
////      pivotData[rowKey][fieldName] = (pivotData[rowKey][fieldName] || 0) + (item[value] || 0);
////    });
////  });
////
////  const columns = [
////    ...config.rows.map(row => ({
////      title: row,
////      dataIndex: row,
////      key: row,
////    })),
////    ...Object.keys(pivotData[Object.keys(pivotData)[0]])
////      .filter(key => !config.rows.includes(key) && key !== 'key')
////      .map(key => ({
////        title: key,
////        dataIndex: key,
////        key: key,
////      }))
////  ];
////
////  return (
////    <Table
////      columns={columns}
////      dataSource={Object.values(pivotData)}
////      size="small"
////      scroll={{ x: true }}
////      pagination={{ pageSize: 5 }}
////    />
////  );
////};
////
////// 甘特图组件
////const GanttWidget = ({ title, config, data, onEdit, onDelete }) => {
////  if (!config || !data.length) return <Empty description="配置不完整或数据为空" />;
////
////  try {
////    // 转换数据为甘特图需要的格式
////    const tasks = data.map(item => ({
////      id: item[config.taskField] || Math.random().toString(36).substr(2, 9),
////      name: String(item[config.taskField] || '未命名任务'),
////      start: new Date(item[config.startField]),
////      end: new Date(item[config.endField]),
////      progress: item[config.progressField] ? Number(item[config.progressField]) : 0,
////      type: item[config.typeField] || 'task',
////      styles: { progressColor: '#ffbb54', progressSelectedColor: '#ff9e0d' },
////    }));
////
////    return (
////      <div style={{ overflowX: 'auto', width: '100%' }}>
////        <Gantt
////          tasks={tasks}
////          viewMode="Day"
////          listCellWidth=""
////          columnWidth={60}
////          fontSize="12"
////          locale="zh-CN"
////        />
////      </div>
////    );
////  } catch (error) {
////    console.error('Error rendering Gantt chart:', error);
////    return <Empty description="渲染甘特图时出错" />;
////  }
////};
////
////export default DataAnalysis;
//
////import React, { useState, useEffect } from 'react';
////import {
////  Card, Select, Button, Row, Col, DatePicker, Divider, Spin,
////  Collapse, Form, Input, Slider, Tabs, Empty, message, Upload,
////  Modal, Space, Radio
////} from 'antd';
////import {
////  BarChartOutlined, LineChartOutlined, PieChartOutlined,
////  TableOutlined, AppstoreAddOutlined, DeleteOutlined,
////  EditOutlined, DragOutlined, UploadOutlined,
////  ScheduleOutlined, AppstoreOutlined, DownOutlined, UpOutlined
////} from '@ant-design/icons';
////import { Chart } from 'react-chartjs-2';
////import { Chart as ChartJS, registerables } from 'chart.js';
////import 'chartjs-plugin-datalabels';
////import { Table } from 'antd';
////import { DndContext, DragOverlay, closestCenter } from '@dnd-kit/core';
////import { arrayMove, SortableContext, horizontalListSortingStrategy } from '@dnd-kit/sortable';
////import { restrictToHorizontalAxis } from '@dnd-kit/modifiers';
////import { useSortable } from '@dnd-kit/sortable';
////import { CSS } from '@dnd-kit/utilities';
////import { Gantt } from 'gantt-task-react';
////import "gantt-task-react/dist/index.css";
////import Papa from 'papaparse';
////import { read, utils } from 'xlsx';
////
////ChartJS.register(...registerables);
////
////const { Option } = Select;
////const { Panel } = Collapse;
////const { TabPane } = Tabs;
////const { Dragger } = Upload;
////
////// 可拖拽的展示项组件
////const SortableItem = ({ id, children, span }) => {
////  const {
////    attributes,
////    listeners,
////    setNodeRef,
////    transform,
////    transition,
////    isDragging,
////  } = useSortable({ id });
////
////  const style = {
////    transform: CSS.Transform.toString(transform),
////    transition,
////    opacity: isDragging ? 0.5 : 1,
////  };
////
////  return (
////    <Col span={span} ref={setNodeRef} style={style} {...attributes}>
////      <Card
////        title={
////          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
////            <span>{children.props.title}</span>
////            <div>
////              <Button
////                type="text"
////                icon={<DragOutlined />}
////                {...listeners}
////                style={{ cursor: 'move' }}
////              />
////              <Button
////                type="text"
////                icon={<EditOutlined />}
////                onClick={() => children.props.onEdit()}
////              />
////              <Button
////                type="text"
////                icon={<DeleteOutlined />}
////                onClick={() => children.props.onDelete()}
////              />
////            </div>
////          </div>
////        }
////      >
////        {children}
////      </Card>
////    </Col>
////  );
////};
////
////// 可视化组件类型
////const CHART_TYPES = {
////  line: { name: '折线图', icon: <LineChartOutlined /> },
////  bar: { name: '柱状图', icon: <BarChartOutlined /> },
////  pie: { name: '饼图', icon: <PieChartOutlined /> },
////  table: { name: '表格', icon: <TableOutlined /> },
////  pivot: { name: '透视表', icon: <AppstoreOutlined /> },
////  gantt: { name: '甘特图', icon: <ScheduleOutlined /> },
////};
////
////const DataAnalysis = ({ initialData }) => {
////  const [loading, setLoading] = useState(false);
////  const [dimensions, setDimensions] = useState([]);
////  const [metrics, setMetrics] = useState([]);
////  const [activeTab, setActiveTab] = useState('line');
////  const [configForm] = Form.useForm();
////  const [widgets, setWidgets] = useState([]);
////  const [activeId, setActiveId] = useState(null);
////  const [dataSource, setDataSource] = useState(initialData || []);
////  const [dataConfigVisible, setDataConfigVisible] = useState(false);
////  const [dataSourceType, setDataSourceType] = useState(initialData ? 'initial' : 'upload');
////  const [configCollapsed, setConfigCollapsed] = useState(false);
////
////  // 获取维度和指标
////  useEffect(() => {
////    if (dataSource.length > 0) {
////      extractDimensionsAndMetrics();
////    }
////  }, [dataSource]);
////
////  const extractDimensionsAndMetrics = () => {
////    if (dataSource.length === 0) return;
////
////    try {
////      // 从数据中提取维度和指标
////      const sampleItem = dataSource[0];
////      const extractedDims = [];
////      const extractedMetrics = [];
////
////      Object.keys(sampleItem).forEach(key => {
////        const value = sampleItem[key];
////        if (typeof value === 'string' || value instanceof Date) {
////          extractedDims.push({ field: key, name: key });
////        } else if (typeof value === 'number') {
////          extractedMetrics.push({ field: key, name: key });
////        }
////      });
////
////      setDimensions(extractedDims);
////      setMetrics(extractedMetrics);
////    } catch (error) {
////      console.error('Error extracting dimensions and metrics:', error);
////      message.error('提取数据字段失败');
////    }
////  };
////
////  // 处理上传数据
////  const handleUpload = (file) => {
////    const reader = new FileReader();
////    reader.onload = (e) => {
////      try {
////        let data;
////        if (file.type === 'text/csv') {
////          const result = Papa.parse(e.target.result, { header: true });
////          data = result.data;
////        } else if (file.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || file.type === 'application/vnd.ms-excel') {
////          const workbook = XLSX.read(e.target.result, { type: 'binary' });
////          const firstSheetName = workbook.SheetNames[0];
////          const worksheet = workbook.Sheets[firstSheetName];
////          data = XLSX.utils.sheet_to_json(worksheet);
////        } else {
////          message.error('仅支持 CSV 或 Excel 文件');
////          return;
////        }
////
////        if (Array.isArray(data)) {
////          setDataSource(data);
////          setDataConfigVisible(false);
////          message.success('数据上传成功');
////        } else {
////          message.error('上传的数据必须是数组格式');
////        }
////      } catch (err) {
////        console.error('Error parsing uploaded file:', err);
////        message.error('解析上传文件失败');
////      }
////    };
////
////    if (file.type === 'text/csv') {
////      reader.readAsText(file);
////    } else {
////      reader.readAsBinaryString(file);
////    }
////    return false; // 阻止默认上传行为
////  };
////
////  // 添加可视化组件
////  const addWidget = () => {
////    configForm.validateFields().then(values => {
////      const newWidget = {
////        id: `widget-${Date.now()}`,
////        type: activeTab,
////        title: values.title || CHART_TYPES[activeTab].name,
////        span: values.span || 8,
////        config: { ...values },
////      };
////
////      setWidgets([...widgets, newWidget]);
////      configForm.resetFields();
////      message.success('组件添加成功');
////    }).catch(err => {
////      console.error('Validation failed:', err);
////    });
////  };
////
////  // 删除组件
////  const deleteWidget = (id) => {
////    setWidgets(widgets.filter(w => w.id !== id));
////  };
////
////  // 编辑组件
////  const editWidget = (id) => {
////    const widget = widgets.find(w => w.id === id);
////    if (widget) {
////      setActiveTab(widget.type);
////      configForm.setFieldsValue({
////        ...widget.config,
////        title: widget.title,
////        span: widget.span,
////      });
////      deleteWidget(id);
////    }
////  };
////
////  // 拖拽相关函数
////  const handleDragStart = (event) => {
////    setActiveId(event.active.id);
////  };
////
////  const handleDragEnd = (event) => {
////    const { active, over } = event;
////
////    if (active.id !== over.id) {
////      setWidgets((items) => {
////        const oldIndex = items.findIndex(item => item.id === active.id);
////        const newIndex = items.findIndex(item => item.id === over.id);
////        return arrayMove(items, oldIndex, newIndex);
////      });
////    }
////
////    setActiveId(null);
////  };
////
////  // 渲染可视化组件
////  const renderWidget = (widget) => {
////    const { id, type, title, span, config } = widget;
////
////    switch (type) {
////      case 'line':
////      case 'bar':
////        return (
////          <ChartWidget
////            key={id}
////            id={id}
////            title={title}
////            type={type}
////            config={config}
////            data={dataSource}
////            onEdit={() => editWidget(id)}
////            onDelete={() => deleteWidget(id)}
////          />
////        );
////      case 'pie':
////        return (
////          <PieWidget
////            key={id}
////            id={id}
////            title={title}
////            config={config}
////            data={dataSource}
////            onEdit={() => editWidget(id)}
////            onDelete={() => deleteWidget(id)}
////          />
////        );
////      case 'table':
////        return (
////          <TableWidget
////            key={id}
////            id={id}
////            title={title}
////            config={config}
////            data={dataSource}
////            onEdit={() => editWidget(id)}
////            onDelete={() => deleteWidget(id)}
////          />
////        );
////      case 'pivot':
////        return (
////          <PivotWidget
////            key={id}
////            id={id}
////            title={title}
////            config={config}
////            data={dataSource}
////            onEdit={() => editWidget(id)}
////            onDelete={() => deleteWidget(id)}
////          />
////        );
////      case 'gantt':
////        return (
////          <GanttWidget
////            key={id}
////            id={id}
////            title={title}
////            config={config}
////            data={dataSource}
////            onEdit={() => editWidget(id)}
////            onDelete={() => deleteWidget(id)}
////          />
////        );
////      default:
////        return null;
////    }
////  };
////
////  // 渲染配置表单
////  const renderConfigForm = () => {
////    switch (activeTab) {
////      case 'line':
////      case 'bar':
////        return (
////          <>
////            <Form.Item label="X轴" name="xField" rules={[{ required: true, message: '请选择X轴字段' }]}>
////              <Select placeholder="选择X轴字段">
////                {dimensions.map(dim => (
////                  <Option key={dim.field} value={dim.field}>{dim.name}</Option>
////                ))}
////              </Select>
////            </Form.Item>
////            <Form.Item label="Y轴" name="yField" rules={[{ required: true, message: '请选择Y轴字段' }]}>
////              <Select mode="multiple" placeholder="选择Y轴字段">
////                {metrics.map(metric => (
////                  <Option key={metric.field} value={metric.field}>{metric.name}</Option>
////                ))}
////              </Select>
////            </Form.Item>
////          </>
////        );
////      case 'pie':
////        return (
////          <>
////            <Form.Item label="分类字段" name="categoryField" rules={[{ required: true, message: '请选择分类字段' }]}>
////              <Select placeholder="选择分类字段">
////                {dimensions.map(dim => (
////                  <Option key={dim.field} value={dim.field}>{dim.name}</Option>
////                ))}
////              </Select>
////            </Form.Item>
////            <Form.Item label="数值字段" name="valueField" rules={[{ required: true, message: '请选择数值字段' }]}>
////              <Select placeholder="选择数值字段">
////                {metrics.map(metric => (
////                  <Option key={metric.field} value={metric.field}>{metric.name}</Option>
////                ))}
////              </Select>
////            </Form.Item>
////          </>
////        );
////      case 'table':
////        return (
////          <Form.Item label="显示列" name="columns" rules={[{ required: true, message: '请选择显示列' }]}>
////            <Select mode="multiple" placeholder="选择要显示的列">
////              {[...dimensions, ...metrics].map(item => (
////                <Option key={item.field} value={item.field}>{item.name}</Option>
////              ))}
////            </Select>
////          </Form.Item>
////        );
////      case 'pivot':
////        return (
////          <>
////            <Form.Item label="行维度" name="rows" rules={[{ required: true, message: '请选择行维度' }]}>
////              <Select mode="multiple" placeholder="选择行维度">
////                {dimensions.map(dim => (
////                  <Option key={dim.field} value={dim.field}>{dim.name}</Option>
////                ))}
////              </Select>
////            </Form.Item>
////            <Form.Item label="列维度" name="cols">
////              <Select mode="multiple" placeholder="选择列维度">
////                {dimensions.map(dim => (
////                  <Option key={dim.field} value={dim.field}>{dim.name}</Option>
////                ))}
////              </Select>
////            </Form.Item>
////            <Form.Item label="数值字段" name="values" rules={[{ required: true, message: '请选择数值字段' }]}>
////              <Select mode="multiple" placeholder="选择数值字段">
////                {metrics.map(metric => (
////                  <Option key={metric.field} value={metric.field}>{metric.name}</Option>
////                ))}
////              </Select>
////            </Form.Item>
////            <Form.Item label="聚合方式" name="aggregate" initialValue="sum">
////              <Select>
////                <Option value="sum">求和</Option>
////                <Option value="avg">平均值</Option>
////                <Option value="count">计数</Option>
////                <Option value="max">最大值</Option>
////                <Option value="min">最小值</Option>
////              </Select>
////            </Form.Item>
////          </>
////        );
////      case 'gantt':
////        return (
////          <>
////            <Form.Item label="任务名称" name="taskField" rules={[{ required: true, message: '请选择任务名字段' }]}>
////              <Select placeholder="选择任务名字段">
////                {dimensions.map(dim => (
////                  <Option key={dim.field} value={dim.field}>{dim.name}</Option>
////                ))}
////              </Select>
////            </Form.Item>
////            <Form.Item label="开始时间" name="startField" rules={[{ required: true, message: '请选择开始时间字段' }]}>
////              <Select placeholder="选择开始时间字段">
////                {dimensions.filter(d => d.field.toLowerCase().includes('date') || d.field.toLowerCase().includes('time')).map(dim => (
////                  <Option key={dim.field} value={dim.field}>{dim.name}</Option>
////                ))}
////              </Select>
////            </Form.Item>
////            <Form.Item label="结束时间" name="endField" rules={[{ required: true, message: '请选择结束时间字段' }]}>
////              <Select placeholder="选择结束时间字段">
////                {dimensions.filter(d => d.field.toLowerCase().includes('date') || d.field.toLowerCase().includes('time')).map(dim => (
////                  <Option key={dim.field} value={dim.field}>{dim.name}</Option>
////                ))}
////              </Select>
////            </Form.Item>
////            <Form.Item label="进度" name="progressField">
////              <Select placeholder="选择进度字段(可选)">
////                {metrics.map(metric => (
////                  <Option key={metric.field} value={metric.field}>{metric.name}</Option>
////                ))}
////              </Select>
////            </Form.Item>
////            <Form.Item label="任务类型" name="typeField">
////              <Select placeholder="选择任务类型字段(可选)">
////                {dimensions.map(dim => (
////                  <Option key={dim.field} value={dim.field}>{dim.name}</Option>
////                ))}
////              </Select>
////            </Form.Item>
////          </>
////        );
////      default:
////        return null;
////    }
////  };
////
////  return (
////    <div className="data-analysis-container">
////      {/* 数据配置模态框 */}
////      <Modal
////        title="数据配置"
////        visible={dataConfigVisible}
////        onCancel={() => setDataConfigVisible(false)}
////        footer={null}
////        width={800}
////      >
////        <Radio.Group
////          value={dataSourceType}
////          onChange={(e) => setDataSourceType(e.target.value)}
////          style={{ marginBottom: 16 }}
////        >
////          <Radio.Button value="initial">使用初始数据</Radio.Button>
////          <Radio.Button value="upload">上传数据</Radio.Button>
////        </Radio.Group>
////
////        {dataSourceType === 'upload' && (
////          <Dragger
////            name="file"
////            accept=".csv, .xlsx, .xls"
////            beforeUpload={handleUpload}
////            showUploadList={false}
////          >
////            <p className="ant-upload-drag-icon">
////              <UploadOutlined />
////            </p>
////            <p className="ant-upload-text">点击或拖拽 CSV 或 Excel 文件到此处上传</p>
////            <p className="ant-upload-hint">
////              支持上传 CSV 或 Excel 格式的数据文件，数据应为表格形式
////            </p>
////          </Dragger>
////        )}
////
////        {dataSourceType === 'initial' && initialData && (
////          <div>
////            <h4>当前使用初始数据</h4>
////            <p>数据量: {initialData.length} 条</p>
////            <Button
////              type="primary"
////              onClick={() => {
////                setDataSource(initialData);
////                setDataConfigVisible(false);
////              }}
////            >
////              确认使用
////            </Button>
////          </div>
////        )}
////      </Modal>
////
////      <Row gutter={16}>
////        {/* 配置区 - 宽度调整为6列 */}
////        <Col span={configCollapsed ? 0 : 6}>
////          <Card
////            title={
////              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
////                <span>可视化配置</span>
////                <Button
////                  type="text"
////                  icon={configCollapsed ? <UpOutlined /> : <DownOutlined />}
////                  onClick={() => setConfigCollapsed(!configCollapsed)}
////                />
////              </div>
////            }
////            extra={
////              <Button
////                type="primary"
////                icon={<AppstoreAddOutlined />}
////                onClick={addWidget}
////                disabled={dataSource.length === 0}
////              >
////                添加组件
////              </Button>
////            }
////          >
////            <Collapse defaultActiveKey={['1']}>
////              <Panel header="数据配置" key="1">
////                <Space direction="vertical" style={{ width: '100%' }}>
////                  <Button
////                    type="primary"
////                    onClick={() => setDataConfigVisible(true)}
////                    block
////                  >
////                    {dataSource.length > 0 ? '更改数据' : '配置数据'}
////                  </Button>
////                  {dataSource.length > 0 && (
////                    <div>
////                      <p>当前数据量: {dataSource.length} 条</p>
////                      <p>维度字段: {dimensions.length} 个</p>
////                      <p>指标字段: {metrics.length} 个</p>
////                    </div>
////                  )}
////                </Space>
////              </Panel>
////              <Panel header="组件配置" key="2">
////                <Tabs activeKey={activeTab} onChange={setActiveTab}>
////                  {Object.entries(CHART_TYPES).map(([key, { name, icon }]) => (
////                    <TabPane tab={<span>{icon} {name}</span>} key={key} />
////                  ))}
////                </Tabs>
////
////                <Form form={configForm} layout="vertical">
////                  <Form.Item label="标题" name="title">
////                    <Input placeholder="输入组件标题" />
////                  </Form.Item>
////                  <Form.Item label="宽度占比" name="span" initialValue={8}>
////                    <Slider
////                      min={4}
////                      max={24}
////                      step={4}
////                      marks={{ 4: '1/6', 8: '1/3', 12: '1/2', 16: '2/3', 20: '5/6', 24: '100%' }}
////                    />
////                  </Form.Item>
////
////                  {renderConfigForm()}
////                </Form>
////              </Panel>
////            </Collapse>
////          </Card>
////        </Col>
////
////        {/* 展示区 - 宽度调整为根据配置区是否折叠动态变化 */}
////        <Col span={configCollapsed ? 24 : 18}>
////          <Card
////            title="可视化展示"
////            loading={loading}
////            extra={
////              dataSource.length > 0 && (
////                <span>数据量: {dataSource.length} 条</span>
////              )
////            }
////          >
////            {dataSource.length === 0 ? (
////              <Empty
////                description={
////                  <span>
////                    <p>暂无数据</p>
////                    <Button
////                      type="primary"
////                      onClick={() => setDataConfigVisible(true)}
////                    >
////                      配置数据
////                    </Button>
////                  </span>
////                }
////              />
////            ) : widgets.length === 0 ? (
////              <Empty description="请添加可视化组件" />
////            ) : (
////              <DndContext
////                modifiers={[restrictToHorizontalAxis]}
////                collisionDetection={closestCenter}
////                onDragStart={handleDragStart}
////                onDragEnd={handleDragEnd}
////              >
////                <SortableContext
////                  items={widgets.map(w => w.id)}
////                  strategy={horizontalListSortingStrategy}
////                >
////                  <Row gutter={16}>
////                    {widgets.map(widget => (
////                      <SortableItem key={widget.id} id={widget.id} span={widget.span}>
////                        {renderWidget(widget)}
////                      </SortableItem>
////                    ))}
////                  </Row>
////                </SortableContext>
////
////                <DragOverlay>
////                  {activeId ? (
////                    <div style={{
////                      width: '100%',
////                      backgroundColor: 'rgba(255, 255, 255, 0.8)',
////                      boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
////                      borderRadius: 4
////                    }}>
////                      {renderWidget(widgets.find(w => w.id === activeId))}
////                    </div>
////                  ) : null}
////                </DragOverlay>
////              </DndContext>
////            )}
////          </Card>
////        </Col>
////      </Row>
////    </div>
////  );
////};
////
////const ChartWidget = ({ title, type, config, data, onEdit, onDelete }) => {
////  if (!config || !data.length) return <Empty description="配置不完整或数据为空" />;
////
////  const chartData = {
////    labels: data.map(item => item[config.xField]),
////    datasets: config.yField.map((field, index) => ({
////      label: field,
////      data: data.map(item => item[field]),
////      backgroundColor: `hsl(${index * 360 / config.yField.length}, 70%, 50%)`,
////      borderColor: `hsl(${index * 360 / config.yField.length}, 70%, 30%)`,
////      borderWidth: 1,
////    })),
////  };
////
////  const options = {
////    responsive: true,
////    plugins: {
////      legend: {
////        position: 'top',
////      },
////    },
////  };
////
////  return (
////    <div style={{ height: 400 }}>
////      <Chart type={type} data={chartData} options={options} />
////    </div>
////  );
////};
////
////// 饼图组件
////const PieWidget = ({ title, config, data, onEdit, onDelete }) => {
////  if (!config || !data.length) return <Empty description="配置不完整或数据为空" />;
////
////  const chartData = {
////    labels: data.map(item => item[config.categoryField]),
////    datasets: [{
////      data: data.map(item => item[config.valueField]),
////      backgroundColor: data.map((_, index) =>
////        `hsl(${index * 360 / data.length}, 70%, 50%)`
////      ),
////    }],
////  };
////
////  const options = {
////    responsive: true,
////    plugins: {
////      legend: {
////        position: 'right',
////      },
////    },
////  };
////
////  return (
////    <div style={{ height: 400 }}>
////      <Chart type="pie" data={chartData} options={options} />
////    </div>
////  );
////};
////
////// 表格组件
////const TableWidget = ({ title, config, data, onEdit, onDelete }) => {
////  if (!config || !data.length) return <Empty description="配置不完整或数据为空" />;
////
////  const columns = config.columns.map(col => ({
////    title: col,
////    dataIndex: col,
////    key: col,
////  }));
////
////  return (
////    <Table
////      columns={columns}
////      dataSource={data}
////      size="small"
////      scroll={{ x: true }}
////      pagination={{ pageSize: 5 }}
////    />
////  );
////};
////
////// 透视表组件
////const PivotWidget = ({ title, config, data, onEdit, onDelete }) => {
////  if (!config || !data.length) return <Empty description="配置不完整或数据为空" />;
////
////  // 这里简化实现，实际项目中可以使用专门的透视表库
////  const pivotData = {};
////
////  // 生成透视数据
////  data.forEach(item => {
////    const rowKey = config.rows.map(row => item[row]).join('-');
////    const colKey = config.cols?.length > 0 ? config.cols.map(col => item[col]).join('-') : '总计';
////
////    if (!pivotData[rowKey]) {
////      pivotData[rowKey] = { key: rowKey };
////      config.rows.forEach(row => {
////        pivotData[rowKey][row] = item[row];
////      });
////    }
////
////    config.values.forEach(value => {
////      const fieldName = colKey === '总计' ? value : `${value}_${colKey}`;
////      pivotData[rowKey][fieldName] = (pivotData[rowKey][fieldName] || 0) + (item[value] || 0);
////    });
////  });
////
////  const columns = [
////    ...config.rows.map(row => ({
////      title: row,
////      dataIndex: row,
////      key: row,
////    })),
////    ...Object.keys(pivotData[Object.keys(pivotData)[0]])
////      .filter(key => !config.rows.includes(key) && key !== 'key')
////      .map(key => ({
////        title: key,
////        dataIndex: key,
////        key: key,
////      }))
////  ];
////
////  return (
////    <Table
////      columns={columns}
////      dataSource={Object.values(pivotData)}
////      size="small"
////      scroll={{ x: true }}
////      pagination={{ pageSize: 5 }}
////    />
////  );
////};
////
////// 甘特图组件
////const GanttWidget = ({ title, config, data, onEdit, onDelete }) => {
////  if (!config || !data.length) return <Empty description="配置不完整或数据为空" />;
////
////  try {
////    // 转换数据为甘特图需要的格式
////    const tasks = data.map(item => ({
////      id: item[config.taskField] || Math.random().toString(36).substr(2, 9),
////      name: String(item[config.taskField] || '未命名任务'),
////      start: new Date(item[config.startField]),
////      end: new Date(item[config.endField]),
////      progress: item[config.progressField] ? Number(item[config.progressField]) : 0,
////      type: item[config.typeField] || 'task',
////      styles: { progressColor: '#ffbb54', progressSelectedColor: '#ff9e0d' },
////    }));
////
////    return (
////      <div style={{ overflowX: 'auto', width: '100%' }}>
////        <Gantt
////          tasks={tasks}
////          viewMode="Day"
////          listCellWidth=""
////          columnWidth={60}
////          fontSize="12"
////          locale="zh-CN"
////        />
////      </div>
////    );
////  } catch (error) {
////    console.error('Error rendering Gantt chart:', error);
////    return <Empty description="渲染甘特图时出错" />;
////  }
////};
////
////export default DataAnalysis;
//
////import React, { useState, useEffect } from 'react';
////import {
////  Card, Select, Button, Row, Col, DatePicker, Divider, Spin,
////  Collapse, Form, Input, Slider, Tabs, Empty, message, Upload,
////  Modal, Space, Radio
////} from 'antd';
////import {
////  BarChartOutlined, LineChartOutlined, PieChartOutlined,
////  TableOutlined, AppstoreAddOutlined, DeleteOutlined,
////  EditOutlined, DragOutlined, UploadOutlined,
////  ScheduleOutlined, AppstoreOutlined
////} from '@ant-design/icons';
////import { Chart } from 'react-chartjs-2';
////import { Chart as ChartJS, registerables } from 'chart.js';
////import 'chartjs-plugin-datalabels';
////import { Table } from 'antd';
////import { DndContext, DragOverlay, closestCenter } from '@dnd-kit/core';
////import { arrayMove, SortableContext, horizontalListSortingStrategy } from '@dnd-kit/sortable';
////import { restrictToHorizontalAxis } from '@dnd-kit/modifiers';
////import { useSortable } from '@dnd-kit/sortable';
////import { CSS } from '@dnd-kit/utilities';
////import { Gantt } from 'gantt-task-react';
////import "gantt-task-react/dist/index.css";
////
////ChartJS.register(...registerables);
////
////const { Option } = Select;
////const { Panel } = Collapse;
////const { TabPane } = Tabs;
////const { Dragger } = Upload;
////
////// 可拖拽的展示项组件
////const SortableItem = ({ id, children, span }) => {
////  const {
////    attributes,
////    listeners,
////    setNodeRef,
////    transform,
////    transition,
////    isDragging,
////  } = useSortable({ id });
////
////  const style = {
////    transform: CSS.Transform.toString(transform),
////    transition,
////    opacity: isDragging ? 0.5 : 1,
////  };
////
////  return (
////    <Col span={span} ref={setNodeRef} style={style} {...attributes}>
////      <Card
////        title={
////          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
////            <span>{children.props.title}</span>
////            <div>
////              <Button
////                type="text"
////                icon={<DragOutlined />}
////                {...listeners}
////                style={{ cursor: 'move' }}
////              />
////              <Button
////                type="text"
////                icon={<EditOutlined />}
////                onClick={() => children.props.onEdit()}
////              />
////              <Button
////                type="text"
////                icon={<DeleteOutlined />}
////                onClick={() => children.props.onDelete()}
////              />
////            </div>
////          </div>
////        }
////      >
////        {children}
////      </Card>
////    </Col>
////  );
////};
////
////// 可视化组件类型
////const CHART_TYPES = {
////  line: { name: '折线图', icon: <LineChartOutlined /> },
////  bar: { name: '柱状图', icon: <BarChartOutlined /> },
////  pie: { name: '饼图', icon: <PieChartOutlined /> },
////  table: { name: '表格', icon: <TableOutlined /> },
////  pivot: { name: '透视表', icon: <AppstoreOutlined /> },
////  gantt: { name: '甘特图', icon: <ScheduleOutlined /> },
////};
////
////const DataAnalysis = ({ initialData }) => {
////  const [loading, setLoading] = useState(false);
////  const [dimensions, setDimensions] = useState([]);
////  const [metrics, setMetrics] = useState([]);
////  const [activeTab, setActiveTab] = useState('line');
////  const [configForm] = Form.useForm();
////  const [widgets, setWidgets] = useState([]);
////  const [activeId, setActiveId] = useState(null);
////  const [dataSource, setDataSource] = useState(initialData || []);
////  const [dataConfigVisible, setDataConfigVisible] = useState(false);
////  const [dataSourceType, setDataSourceType] = useState(initialData ? 'initial' : 'upload');
////
////  // 获取维度和指标
////  useEffect(() => {
////    if (dataSource.length > 0) {
////      extractDimensionsAndMetrics();
////    }
////  }, [dataSource]);
////
////  const extractDimensionsAndMetrics = () => {
////    if (dataSource.length === 0) return;
////
////    try {
////      // 从数据中提取维度和指标
////      const sampleItem = dataSource[0];
////      const extractedDims = [];
////      const extractedMetrics = [];
////
////      Object.keys(sampleItem).forEach(key => {
////        const value = sampleItem[key];
////        if (typeof value === 'string' || value instanceof Date) {
////          extractedDims.push({ field: key, name: key });
////        } else if (typeof value === 'number') {
////          extractedMetrics.push({ field: key, name: key });
////        }
////      });
////
////      setDimensions(extractedDims);
////      setMetrics(extractedMetrics);
////    } catch (error) {
////      console.error('Error extracting dimensions and metrics:', error);
////      message.error('提取数据字段失败');
////    }
////  };
////
////  // 处理上传数据
////  const handleUpload = (file) => {
////    const reader = new FileReader();
////    reader.onload = (e) => {
////      try {
////        const data = JSON.parse(e.target.result);
////        if (Array.isArray(data)) {
////          setDataSource(data);
////          setDataConfigVisible(false);
////          message.success('数据上传成功');
////        } else {
////          message.error('上传的数据必须是数组格式');
////        }
////      } catch (err) {
////        console.error('Error parsing uploaded file:', err);
////        message.error('解析上传文件失败');
////      }
////    };
////    reader.readAsText(file);
////    return false; // 阻止默认上传行为
////  };
////
////  // 添加可视化组件
////  const addWidget = () => {
////    configForm.validateFields().then(values => {
////      const newWidget = {
////        id: `widget-${Date.now()}`,
////        type: activeTab,
////        title: values.title || CHART_TYPES[activeTab].name,
////        span: values.span || 8,
////        config: { ...values },
////      };
////
////      setWidgets([...widgets, newWidget]);
////      configForm.resetFields();
////      message.success('组件添加成功');
////    }).catch(err => {
////      console.error('Validation failed:', err);
////    });
////  };
////
////  // 删除组件
////  const deleteWidget = (id) => {
////    setWidgets(widgets.filter(w => w.id !== id));
////  };
////
////  // 编辑组件
////  const editWidget = (id) => {
////    const widget = widgets.find(w => w.id === id);
////    if (widget) {
////      setActiveTab(widget.type);
////      configForm.setFieldsValue({
////        ...widget.config,
////        title: widget.title,
////        span: widget.span,
////      });
////      deleteWidget(id);
////    }
////  };
////
////  // 拖拽相关函数
////  const handleDragStart = (event) => {
////    setActiveId(event.active.id);
////  };
////
////  const handleDragEnd = (event) => {
////    const { active, over } = event;
////
////    if (active.id !== over.id) {
////      setWidgets((items) => {
////        const oldIndex = items.findIndex(item => item.id === active.id);
////        const newIndex = items.findIndex(item => item.id === over.id);
////        return arrayMove(items, oldIndex, newIndex);
////      });
////    }
////
////    setActiveId(null);
////  };
////
////  // 渲染可视化组件
////  const renderWidget = (widget) => {
////    const { id, type, title, span, config } = widget;
////
////    switch (type) {
////      case 'line':
////      case 'bar':
////        return (
////          <ChartWidget
////            key={id}
////            id={id}
////            title={title}
////            type={type}
////            config={config}
////            data={dataSource}
////            onEdit={() => editWidget(id)}
////            onDelete={() => deleteWidget(id)}
////          />
////        );
////      case 'pie':
////        return (
////          <PieWidget
////            key={id}
////            id={id}
////            title={title}
////            config={config}
////            data={dataSource}
////            onEdit={() => editWidget(id)}
////            onDelete={() => deleteWidget(id)}
////          />
////        );
////      case 'table':
////        return (
////          <TableWidget
////            key={id}
////            id={id}
////            title={title}
////            config={config}
////            data={dataSource}
////            onEdit={() => editWidget(id)}
////            onDelete={() => deleteWidget(id)}
////          />
////        );
////      case 'pivot':
////        return (
////          <PivotWidget
////            key={id}
////            id={id}
////            title={title}
////            config={config}
////            data={dataSource}
////            onEdit={() => editWidget(id)}
////            onDelete={() => deleteWidget(id)}
////          />
////        );
////      case 'gantt':
////        return (
////          <GanttWidget
////            key={id}
////            id={id}
////            title={title}
////            config={config}
////            data={dataSource}
////            onEdit={() => editWidget(id)}
////            onDelete={() => deleteWidget(id)}
////          />
////        );
////      default:
////        return null;
////    }
////  };
////
////  // 渲染配置表单
////  const renderConfigForm = () => {
////    switch (activeTab) {
////      case 'line':
////      case 'bar':
////        return (
////          <>
////            <Form.Item label="X轴" name="xField" rules={[{ required: true, message: '请选择X轴字段' }]}>
////              <Select placeholder="选择X轴字段">
////                {dimensions.map(dim => (
////                  <Option key={dim.field} value={dim.field}>{dim.name}</Option>
////                ))}
////              </Select>
////            </Form.Item>
////            <Form.Item label="Y轴" name="yField" rules={[{ required: true, message: '请选择Y轴字段' }]}>
////              <Select mode="multiple" placeholder="选择Y轴字段">
////                {metrics.map(metric => (
////                  <Option key={metric.field} value={metric.field}>{metric.name}</Option>
////                ))}
////              </Select>
////            </Form.Item>
////          </>
////        );
////      case 'pie':
////        return (
////          <>
////            <Form.Item label="分类字段" name="categoryField" rules={[{ required: true, message: '请选择分类字段' }]}>
////              <Select placeholder="选择分类字段">
////                {dimensions.map(dim => (
////                  <Option key={dim.field} value={dim.field}>{dim.name}</Option>
////                ))}
////              </Select>
////            </Form.Item>
////            <Form.Item label="数值字段" name="valueField" rules={[{ required: true, message: '请选择数值字段' }]}>
////              <Select placeholder="选择数值字段">
////                {metrics.map(metric => (
////                  <Option key={metric.field} value={metric.field}>{metric.name}</Option>
////                ))}
////              </Select>
////            </Form.Item>
////          </>
////        );
////      case 'table':
////        return (
////          <Form.Item label="显示列" name="columns" rules={[{ required: true, message: '请选择显示列' }]}>
////            <Select mode="multiple" placeholder="选择要显示的列">
////              {[...dimensions, ...metrics].map(item => (
////                <Option key={item.field} value={item.field}>{item.name}</Option>
////              ))}
////            </Select>
////          </Form.Item>
////        );
////      case 'pivot':
////        return (
////          <>
////            <Form.Item label="行维度" name="rows" rules={[{ required: true, message: '请选择行维度' }]}>
////              <Select mode="multiple" placeholder="选择行维度">
////                {dimensions.map(dim => (
////                  <Option key={dim.field} value={dim.field}>{dim.name}</Option>
////                ))}
////              </Select>
////            </Form.Item>
////            <Form.Item label="列维度" name="cols">
////              <Select mode="multiple" placeholder="选择列维度">
////                {dimensions.map(dim => (
////                  <Option key={dim.field} value={dim.field}>{dim.name}</Option>
////                ))}
////              </Select>
////            </Form.Item>
////            <Form.Item label="数值字段" name="values" rules={[{ required: true, message: '请选择数值字段' }]}>
////              <Select mode="multiple" placeholder="选择数值字段">
////                {metrics.map(metric => (
////                  <Option key={metric.field} value={metric.field}>{metric.name}</Option>
////                ))}
////              </Select>
////            </Form.Item>
////            <Form.Item label="聚合方式" name="aggregate" initialValue="sum">
////              <Select>
////                <Option value="sum">求和</Option>
////                <Option value="avg">平均值</Option>
////                <Option value="count">计数</Option>
////                <Option value="max">最大值</Option>
////                <Option value="min">最小值</Option>
////              </Select>
////            </Form.Item>
////          </>
////        );
////      case 'gantt':
////        return (
////          <>
////            <Form.Item label="任务名称" name="taskField" rules={[{ required: true, message: '请选择任务名字段' }]}>
////              <Select placeholder="选择任务名字段">
////                {dimensions.map(dim => (
////                  <Option key={dim.field} value={dim.field}>{dim.name}</Option>
////                ))}
////              </Select>
////            </Form.Item>
////            <Form.Item label="开始时间" name="startField" rules={[{ required: true, message: '请选择开始时间字段' }]}>
////              <Select placeholder="选择开始时间字段">
////                {dimensions.filter(d => d.field.toLowerCase().includes('date') || d.field.toLowerCase().includes('time')).map(dim => (
////                  <Option key={dim.field} value={dim.field}>{dim.name}</Option>
////                ))}
////              </Select>
////            </Form.Item>
////            <Form.Item label="结束时间" name="endField" rules={[{ required: true, message: '请选择结束时间字段' }]}>
////              <Select placeholder="选择结束时间字段">
////                {dimensions.filter(d => d.field.toLowerCase().includes('date') || d.field.toLowerCase().includes('time')).map(dim => (
////                  <Option key={dim.field} value={dim.field}>{dim.name}</Option>
////                ))}
////              </Select>
////            </Form.Item>
////            <Form.Item label="进度" name="progressField">
////              <Select placeholder="选择进度字段(可选)">
////                {metrics.map(metric => (
////                  <Option key={metric.field} value={metric.field}>{metric.name}</Option>
////                ))}
////              </Select>
////            </Form.Item>
////            <Form.Item label="任务类型" name="typeField">
////              <Select placeholder="选择任务类型字段(可选)">
////                {dimensions.map(dim => (
////                  <Option key={dim.field} value={dim.field}>{dim.name}</Option>
////                ))}
////              </Select>
////            </Form.Item>
////          </>
////        );
////      default:
////        return null;
////    }
////  };
////
////  return (
////    <div className="data-analysis-container">
////      {/* 数据配置模态框 */}
////      <Modal
////        title="数据配置"
////        visible={dataConfigVisible}
////        onCancel={() => setDataConfigVisible(false)}
////        footer={null}
////        width={800}
////      >
////        <Radio.Group
////          value={dataSourceType}
////          onChange={(e) => setDataSourceType(e.target.value)}
////          style={{ marginBottom: 16 }}
////        >
////          <Radio.Button value="initial">使用初始数据</Radio.Button>
////          <Radio.Button value="upload">上传数据</Radio.Button>
////        </Radio.Group>
////
////        {dataSourceType === 'upload' && (
////          <Dragger
////            name="file"
////            accept=".json"
////            beforeUpload={handleUpload}
////            showUploadList={false}
////          >
////            <p className="ant-upload-drag-icon">
////              <UploadOutlined />
////            </p>
////            <p className="ant-upload-text">点击或拖拽JSON文件到此处上传</p>
////            <p className="ant-upload-hint">
////              支持上传JSON格式的数据文件，数据应为数组格式
////            </p>
////          </Dragger>
////        )}
////
////        {dataSourceType === 'initial' && initialData && (
////          <div>
////            <h4>当前使用初始数据</h4>
////            <p>数据量: {initialData.length} 条</p>
////            <Button
////              type="primary"
////              onClick={() => {
////                setDataSource(initialData);
////                setDataConfigVisible(false);
////              }}
////            >
////              确认使用
////            </Button>
////          </div>
////        )}
////      </Modal>
////
////      <Row gutter={16}>
////        {/* 配置区 - 宽度调整为6列 */}
////        <Col span={6}>
////          <Card
////            title="可视化配置"
////            extra={
////              <Button
////                type="primary"
////                icon={<AppstoreAddOutlined />}
////                onClick={addWidget}
////                disabled={dataSource.length === 0}
////              >
////                添加组件
////              </Button>
////            }
////          >
////            <Collapse defaultActiveKey={['1']}>
////              <Panel header="数据配置" key="1">
////                <Space direction="vertical" style={{ width: '100%' }}>
////                  <Button
////                    type="primary"
////                    onClick={() => setDataConfigVisible(true)}
////                    block
////                  >
////                    {dataSource.length > 0 ? '更改数据' : '配置数据'}
////                  </Button>
////                  {dataSource.length > 0 && (
////                    <div>
////                      <p>当前数据量: {dataSource.length} 条</p>
////                      <p>维度字段: {dimensions.length} 个</p>
////                      <p>指标字段: {metrics.length} 个</p>
////                    </div>
////                  )}
////                </Space>
////              </Panel>
////              <Panel header="组件配置" key="2">
////                <Tabs activeKey={activeTab} onChange={setActiveTab}>
////                  {Object.entries(CHART_TYPES).map(([key, { name, icon }]) => (
////                    <TabPane tab={<span>{icon} {name}</span>} key={key} />
////                  ))}
////                </Tabs>
////
////                <Form form={configForm} layout="vertical">
////                  <Form.Item label="标题" name="title">
////                    <Input placeholder="输入组件标题" />
////                  </Form.Item>
////                  <Form.Item label="宽度占比" name="span" initialValue={8}>
////                    <Slider
////                      min={4}
////                      max={24}
////                      step={4}
////                      marks={{ 4: '1/6', 8: '1/3', 12: '1/2', 16: '2/3', 20: '5/6', 24: '100%' }}
////                    />
////                  </Form.Item>
////
////                  {renderConfigForm()}
////                </Form>
////              </Panel>
////            </Collapse>
////          </Card>
////        </Col>
////
////        {/* 展示区 - 宽度调整为18列 */}
////        <Col span={18}>
////          <Card
////            title="可视化展示"
////            loading={loading}
////            extra={
////              dataSource.length > 0 && (
////                <span>数据量: {dataSource.length} 条</span>
////              )
////            }
////          >
////            {dataSource.length === 0 ? (
////              <Empty
////                description={
////                  <span>
////                    <p>暂无数据</p>
////                    <Button
////                      type="primary"
////                      onClick={() => setDataConfigVisible(true)}
////                    >
////                      配置数据
////                    </Button>
////                  </span>
////                }
////              />
////            ) : widgets.length === 0 ? (
////              <Empty description="请添加可视化组件" />
////            ) : (
////              <DndContext
////                modifiers={[restrictToHorizontalAxis]}
////                collisionDetection={closestCenter}
////                onDragStart={handleDragStart}
////                onDragEnd={handleDragEnd}
////              >
////                <SortableContext
////                  items={widgets.map(w => w.id)}
////                  strategy={horizontalListSortingStrategy}
////                >
////                  <Row gutter={16}>
////                    {widgets.map(widget => (
////                      <SortableItem key={widget.id} id={widget.id} span={widget.span}>
////                        {renderWidget(widget)}
////                      </SortableItem>
////                    ))}
////                  </Row>
////                </SortableContext>
////
////                <DragOverlay>
////                  {activeId ? (
////                    <div style={{
////                      width: '100%',
////                      backgroundColor: 'rgba(255, 255, 255, 0.8)',
////                      boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
////                      borderRadius: 4
////                    }}>
////                      {renderWidget(widgets.find(w => w.id === activeId))}
////                    </div>
////                  ) : null}
////                </DragOverlay>
////              </DndContext>
////            )}
////          </Card>
////        </Col>
////      </Row>
////    </div>
////  );
////};
////
////const ChartWidget = ({ title, type, config, data, onEdit, onDelete }) => {
////  if (!config || !data.length) return <Empty description="配置不完整或数据为空" />;
////
////  const chartData = {
////    labels: data.map(item => item[config.xField]),
////    datasets: config.yField.map((field, index) => ({
////      label: field,
////      data: data.map(item => item[field]),
////      backgroundColor: `hsl(${index * 360 / config.yField.length}, 70%, 50%)`,
////      borderColor: `hsl(${index * 360 / config.yField.length}, 70%, 30%)`,
////      borderWidth: 1,
////    })),
////  };
////
////  const options = {
////    responsive: true,
////    plugins: {
////      legend: {
////        position: 'top',
////      },
////    },
////  };
////
////  return (
////    <div style={{ height: 400 }}>
////      <Chart type={type} data={chartData} options={options} />
////    </div>
////  );
////};
////
////// 饼图组件
////const PieWidget = ({ title, config, data, onEdit, onDelete }) => {
////  if (!config || !data.length) return <Empty description="配置不完整或数据为空" />;
////
////  const chartData = {
////    labels: data.map(item => item[config.categoryField]),
////    datasets: [{
////      data: data.map(item => item[config.valueField]),
////      backgroundColor: data.map((_, index) =>
////        `hsl(${index * 360 / data.length}, 70%, 50%)`
////      ),
////    }],
////  };
////
////  const options = {
////    responsive: true,
////    plugins: {
////      legend: {
////        position: 'right',
////      },
////    },
////  };
////
////  return (
////    <div style={{ height: 400 }}>
////      <Chart type="pie" data={chartData} options={options} />
////    </div>
////  );
////};
////
////// 表格组件
////const TableWidget = ({ title, config, data, onEdit, onDelete }) => {
////  if (!config || !data.length) return <Empty description="配置不完整或数据为空" />;
////
////  const columns = config.columns.map(col => ({
////    title: col,
////    dataIndex: col,
////    key: col,
////  }));
////
////  return (
////    <Table
////      columns={columns}
////      dataSource={data}
////      size="small"
////      scroll={{ x: true }}
////      pagination={{ pageSize: 5 }}
////    />
////  );
////};
////
////// 透视表组件
////const PivotWidget = ({ title, config, data, onEdit, onDelete }) => {
////  if (!config || !data.length) return <Empty description="配置不完整或数据为空" />;
////
////  // 这里简化实现，实际项目中可以使用专门的透视表库
////  const pivotData = {};
////
////  // 生成透视数据
////  data.forEach(item => {
////    const rowKey = config.rows.map(row => item[row]).join('-');
////    const colKey = config.cols?.length > 0 ? config.cols.map(col => item[col]).join('-') : '总计';
////
////    if (!pivotData[rowKey]) {
////      pivotData[rowKey] = { key: rowKey };
////      config.rows.forEach(row => {
////        pivotData[rowKey][row] = item[row];
////      });
////    }
////
////    config.values.forEach(value => {
////      const fieldName = colKey === '总计' ? value : `${value}_${colKey}`;
////      pivotData[rowKey][fieldName] = (pivotData[rowKey][fieldName] || 0) + (item[value] || 0);
////    });
////  });
////
////  const columns = [
////    ...config.rows.map(row => ({
////      title: row,
////      dataIndex: row,
////      key: row,
////    })),
////    ...Object.keys(pivotData[Object.keys(pivotData)[0]])
////      .filter(key => !config.rows.includes(key) && key !== 'key')
////      .map(key => ({
////        title: key,
////        dataIndex: key,
////        key: key,
////      }))
////  ];
////
////  return (
////    <Table
////      columns={columns}
////      dataSource={Object.values(pivotData)}
////      size="small"
////      scroll={{ x: true }}
////      pagination={{ pageSize: 5 }}
////    />
////  );
////};
////
////// 甘特图组件
////const GanttWidget = ({ title, config, data, onEdit, onDelete }) => {
////  if (!config || !data.length) return <Empty description="配置不完整或数据为空" />;
////
////  try {
////    // 转换数据为甘特图需要的格式
////    const tasks = data.map(item => ({
////      id: item[config.taskField] || Math.random().toString(36).substr(2, 9),
////      name: String(item[config.taskField] || '未命名任务'),
////      start: new Date(item[config.startField]),
////      end: new Date(item[config.endField]),
////      progress: item[config.progressField] ? Number(item[config.progressField]) : 0,
////      type: item[config.typeField] || 'task',
////      styles: { progressColor: '#ffbb54', progressSelectedColor: '#ff9e0d' },
////    }));
////
////    return (
////      <div style={{ overflowX: 'auto', width: '100%' }}>
////        <Gantt
////          tasks={tasks}
////          viewMode="Day"
////          listCellWidth=""
////          columnWidth={60}
////          fontSize="12"
////          locale="zh-CN"
////        />
////      </div>
////    );
////  } catch (error) {
////    console.error('Error rendering Gantt chart:', error);
////    return <Empty description="渲染甘特图时出错" />;
////  }
////};
////
////export default DataAnalysis;
//
//
//
////import React, { useState, useEffect } from 'react';
////import {
////  Card, Select, Button, Row, Col, DatePicker, Divider, Spin,
////  Collapse, Form, Input, Switch, Slider, Tabs, Empty, message
////} from 'antd';
////import {
////  BarChartOutlined, LineChartOutlined, PieChartOutlined,
////  TableOutlined, AppstoreAddOutlined, PivotTableOutlined,
////  DeleteOutlined, EditOutlined, DragOutlined
////} from '@ant-design/icons';
////import { Chart } from 'react-chartjs-2';
////import { Chart as ChartJS, registerables } from 'chart.js';
////import 'chartjs-plugin-datalabels';
////import { Table } from 'antd';
////import { DndContext, DragOverlay, closestCenter } from '@dnd-kit/core';
////import { arrayMove, SortableContext, horizontalListSortingStrategy } from '@dnd-kit/sortable';
////import { restrictToHorizontalAxis } from '@dnd-kit/modifiers';
////import { useSortable } from '@dnd-kit/sortable';
////import { CSS } from '@dnd-kit/utilities';
////
////ChartJS.register(...registerables);
////
////const { Option } = Select;
////const { RangePicker } = DatePicker;
////const { Panel } = Collapse;
////const { TabPane } = Tabs;
////
////// 可拖拽的展示项组件
////const SortableItem = ({ id, children, span }) => {
////  const {
////    attributes,
////    listeners,
////    setNodeRef,
////    transform,
////    transition,
////    isDragging,
////  } = useSortable({ id });
////
////  const style = {
////    transform: CSS.Transform.toString(transform),
////    transition,
////    opacity: isDragging ? 0.5 : 1,
////  };
////
////  return (
////    <Col span={span} ref={setNodeRef} style={style} {...attributes}>
////      <Card
////        title={
////          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
////            <span>{children.props.title}</span>
////            <div>
////              <Button
////                type="text"
////                icon={<DragOutlined />}
////                {...listeners}
////                style={{ cursor: 'move' }}
////              />
////              <Button
////                type="text"
////                icon={<EditOutlined />}
////                onClick={() => children.props.onEdit()}
////              />
////              <Button
////                type="text"
////                icon={<DeleteOutlined />}
////                onClick={() => children.props.onDelete()}
////              />
////            </div>
////          </div>
////        }
////      >
////        {children}
////      </Card>
////    </Col>
////  );
////};
////
////// 可视化组件类型
////const CHART_TYPES = {
////  line: { name: '折线图', icon: <LineChartOutlined /> },
////  bar: { name: '柱状图', icon: <BarChartOutlined /> },
////  pie: { name: '饼图', icon: <PieChartOutlined /> },
////  table: { name: '表格', icon: <TableOutlined /> },
////  pivot: { name: '透视表', icon: <TableOutlined  /> },
////};
////
////const DataAnalysis = () => {
////  const [loading, setLoading] = useState(false);
////  const [dimensions, setDimensions] = useState([]);
////  const [metrics, setMetrics] = useState([]);
////  const [activeTab, setActiveTab] = useState('line');
////  const [configForm] = Form.useForm();
////  const [widgets, setWidgets] = useState([]);
////  const [activeId, setActiveId] = useState(null);
////  const [dataSource, setDataSource] = useState([]);
////  const [dateRange, setDateRange] = useState([]);
////
////  // 获取维度和指标
////  useEffect(() => {
////    fetchDimensionsAndMetrics();
////  }, []);
////
////  const fetchDimensionsAndMetrics = async () => {
////    setLoading(true);
////    try {
////      const response = await fetch('/api/analysis/dimensions-metrics');
////      const result = await response.json();
////      setDimensions(result.dimensions);
////      setMetrics(result.metrics);
////    } catch (error) {
////      console.error('Error fetching dimensions and metrics:', error);
////      message.error('获取维度和指标失败');
////    } finally {
////      setLoading(false);
////    }
////  };
////
////  // 获取数据
////  const fetchData = async () => {
////    setLoading(true);
////    try {
////      const params = new URLSearchParams();
////      if (dateRange && dateRange.length === 2) {
////        params.append('startDate', dateRange[0].format('YYYY-MM-DD'));
////        params.append('endDate', dateRange[1].format('YYYY-MM-DD'));
////      }
////
////      const response = await fetch(`/api/analysis/data?${params.toString()}`);
////      const result = await response.json();
////      setDataSource(result.data);
////      message.success('数据加载成功');
////    } catch (error) {
////      console.error('Error fetching data:', error);
////      message.error('数据加载失败');
////    } finally {
////      setLoading(false);
////    }
////  };
////
////  // 添加可视化组件
////  const addWidget = () => {
////    configForm.validateFields().then(values => {
////      const newWidget = {
////        id: `widget-${Date.now()}`,
////        type: activeTab,
////        title: values.title || CHART_TYPES[activeTab].name,
////        span: values.span || 8,
////        config: { ...values },
////      };
////
////      setWidgets([...widgets, newWidget]);
////      configForm.resetFields();
////      message.success('组件添加成功');
////    }).catch(err => {
////      console.error('Validation failed:', err);
////    });
////  };
////
////  // 删除组件
////  const deleteWidget = (id) => {
////    setWidgets(widgets.filter(w => w.id !== id));
////  };
////
////  // 编辑组件
////  const editWidget = (id) => {
////    const widget = widgets.find(w => w.id === id);
////    if (widget) {
////      setActiveTab(widget.type);
////      configForm.setFieldsValue({
////        ...widget.config,
////        title: widget.title,
////        span: widget.span,
////      });
////      deleteWidget(id);
////    }
////  };
////
////  // 拖拽相关函数
////  const handleDragStart = (event) => {
////    setActiveId(event.active.id);
////  };
////
////  const handleDragEnd = (event) => {
////    const { active, over } = event;
////
////    if (active.id !== over.id) {
////      setWidgets((items) => {
////        const oldIndex = items.findIndex(item => item.id === active.id);
////        const newIndex = items.findIndex(item => item.id === over.id);
////        return arrayMove(items, oldIndex, newIndex);
////      });
////    }
////
////    setActiveId(null);
////  };
////
////  // 渲染可视化组件
////  const renderWidget = (widget) => {
////    const { id, type, title, span, config } = widget;
////
////    switch (type) {
////      case 'line':
////      case 'bar':
////        return (
////          <ChartWidget
////            key={id}
////            id={id}
////            title={title}
////            type={type}
////            config={config}
////            data={dataSource}
////            onEdit={() => editWidget(id)}
////            onDelete={() => deleteWidget(id)}
////          />
////        );
////      case 'pie':
////        return (
////          <PieWidget
////            key={id}
////            id={id}
////            title={title}
////            config={config}
////            data={dataSource}
////            onEdit={() => editWidget(id)}
////            onDelete={() => deleteWidget(id)}
////          />
////        );
////      case 'table':
////        return (
////          <TableWidget
////            key={id}
////            id={id}
////            title={title}
////            config={config}
////            data={dataSource}
////            onEdit={() => editWidget(id)}
////            onDelete={() => deleteWidget(id)}
////          />
////        );
////      case 'pivot':
////        return (
////          <PivotWidget
////            key={id}
////            id={id}
////            title={title}
////            config={config}
////            data={dataSource}
////            onEdit={() => editWidget(id)}
////            onDelete={() => deleteWidget(id)}
////          />
////        );
////      default:
////        return null;
////    }
////  };
////
////  // 渲染配置表单
////  const renderConfigForm = () => {
////    switch (activeTab) {
////      case 'line':
////      case 'bar':
////        return (
////          <>
////            <Form.Item label="X轴" name="xField" rules={[{ required: true, message: '请选择X轴字段' }]}>
////              <Select placeholder="选择X轴字段">
////                {dimensions.map(dim => (
////                  <Option key={dim.field} value={dim.field}>{dim.name}</Option>
////                ))}
////              </Select>
////            </Form.Item>
////            <Form.Item label="Y轴" name="yField" rules={[{ required: true, message: '请选择Y轴字段' }]}>
////              <Select mode="multiple" placeholder="选择Y轴字段">
////                {metrics.map(metric => (
////                  <Option key={metric.field} value={metric.field}>{metric.name}</Option>
////                ))}
////              </Select>
////            </Form.Item>
////          </>
////        );
////      case 'pie':
////        return (
////          <>
////            <Form.Item label="分类字段" name="categoryField" rules={[{ required: true, message: '请选择分类字段' }]}>
////              <Select placeholder="选择分类字段">
////                {dimensions.map(dim => (
////                  <Option key={dim.field} value={dim.field}>{dim.name}</Option>
////                ))}
////              </Select>
////            </Form.Item>
////            <Form.Item label="数值字段" name="valueField" rules={[{ required: true, message: '请选择数值字段' }]}>
////              <Select placeholder="选择数值字段">
////                {metrics.map(metric => (
////                  <Option key={metric.field} value={metric.field}>{metric.name}</Option>
////                ))}
////              </Select>
////            </Form.Item>
////          </>
////        );
////      case 'table':
////        return (
////          <Form.Item label="显示列" name="columns" rules={[{ required: true, message: '请选择显示列' }]}>
////            <Select mode="multiple" placeholder="选择要显示的列">
////              {[...dimensions, ...metrics].map(item => (
////                <Option key={item.field} value={item.field}>{item.name}</Option>
////              ))}
////            </Select>
////          </Form.Item>
////        );
////      case 'pivot':
////        return (
////          <>
////            <Form.Item label="行维度" name="rows" rules={[{ required: true, message: '请选择行维度' }]}>
////              <Select mode="multiple" placeholder="选择行维度">
////                {dimensions.map(dim => (
////                  <Option key={dim.field} value={dim.field}>{dim.name}</Option>
////                ))}
////              </Select>
////            </Form.Item>
////            <Form.Item label="列维度" name="cols">
////              <Select mode="multiple" placeholder="选择列维度">
////                {dimensions.map(dim => (
////                  <Option key={dim.field} value={dim.field}>{dim.name}</Option>
////                ))}
////              </Select>
////            </Form.Item>
////            <Form.Item label="数值字段" name="values" rules={[{ required: true, message: '请选择数值字段' }]}>
////              <Select mode="multiple" placeholder="选择数值字段">
////                {metrics.map(metric => (
////                  <Option key={metric.field} value={metric.field}>{metric.name}</Option>
////                ))}
////              </Select>
////            </Form.Item>
////          </>
////        );
////      default:
////        return null;
////    }
////  };
////
////  return (
////    <div className="data-analysis-container">
////      <Row gutter={16}>
////        {/* 配置区 */}
////        <Col span={8}>
////          <Card
////            title="可视化配置"
////            extra={
////              <Button
////                type="primary"
////                icon={<AppstoreAddOutlined />}
////                onClick={addWidget}
////              >
////                添加组件
////              </Button>
////            }
////          >
////            <Collapse defaultActiveKey={['1']}>
////              <Panel header="数据配置" key="1">
////                <Row gutter={16}>
////                  <Col span={24}>
////                    <RangePicker
////                      style={{ width: '100%' }}
////                      onChange={setDateRange}
////                    />
////                  </Col>
////                  <Col span={24} style={{ marginTop: 16 }}>
////                    <Button
////                      type="primary"
////                      onClick={fetchData}
////                      loading={loading}
////                      block
////                    >
////                      加载数据
////                    </Button>
////                  </Col>
////                </Row>
////              </Panel>
////              <Panel header="组件配置" key="2">
////                <Tabs activeKey={activeTab} onChange={setActiveTab}>
////                  {Object.entries(CHART_TYPES).map(([key, { name, icon }]) => (
////                    <TabPane tab={<span>{icon} {name}</span>} key={key} />
////                  ))}
////                </Tabs>
////
////                <Form form={configForm} layout="vertical">
////                  <Form.Item label="标题" name="title">
////                    <Input placeholder="输入组件标题" />
////                  </Form.Item>
////                  <Form.Item label="宽度占比" name="span" initialValue={8}>
////                    <Slider
////                      min={4}
////                      max={24}
////                      step={4}
////                      marks={{ 4: '1/6', 8: '1/3', 12: '1/2', 16: '2/3', 20: '5/6', 24: '100%' }}
////                    />
////                  </Form.Item>
////
////                  {renderConfigForm()}
////                </Form>
////              </Panel>
////            </Collapse>
////          </Card>
////        </Col>
////
////        {/* 展示区 */}
////        <Col span={16}>
////          <Card title="可视化展示" loading={loading}>
////            {dataSource.length === 0 ? (
////              <Empty description="请先加载数据" />
////            ) : widgets.length === 0 ? (
////              <Empty description="请添加可视化组件" />
////            ) : (
////              <DndContext
////                modifiers={[restrictToHorizontalAxis]}
////                collisionDetection={closestCenter}
////                onDragStart={handleDragStart}
////                onDragEnd={handleDragEnd}
////              >
////                <SortableContext
////                  items={widgets.map(w => w.id)}
////                  strategy={horizontalListSortingStrategy}
////                >
////                  <Row gutter={16}>
////                    {widgets.map(widget => (
////                      <SortableItem key={widget.id} id={widget.id} span={widget.span}>
////                        {renderWidget(widget)}
////                      </SortableItem>
////                    ))}
////                  </Row>
////                </SortableContext>
////
////                <DragOverlay>
////                  {activeId ? (
////                    <div style={{
////                      width: '100%',
////                      backgroundColor: 'rgba(255, 255, 255, 0.8)',
////                      boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
////                      borderRadius: 4
////                    }}>
////                      {renderWidget(widgets.find(w => w.id === activeId))}
////                    </div>
////                  ) : null}
////                </DragOverlay>
////              </DndContext>
////            )}
////          </Card>
////        </Col>
////      </Row>
////    </div>
////  );
////};
////
//// 图表组件
////const ChartWidget = ({ title, type, config, data, onEdit, onDelete }) => {
////  if (!config || !data.length) return <Empty description="配置不完整或数据为空" />;
////
////  const chartData = {
////    labels: data.map(item => item[config.xField]),
////    datasets: config.yField.map((field, index) => ({
////      label: field,
////      data: data.map(item => item[field]),
////      backgroundColor: `hsl(${index * 360 / config.yField.length}, 70%, 50%)`,
////      borderColor: `hsl(${index * 360 / config.yField.length}, 70%, 30%)`,
////      borderWidth: 1,
////    })),
////  };
////
////  const options = {
////    responsive: true,
////    plugins: {
////      legend: {
////        position: 'top',
////      },
////    },
////  };
////
////  return (
////    <div style={{ height: 400 }}>
////      <Chart type={type} data={chartData} options={options} />
////    </div>
////  );
////};
////
////// 饼图组件
////const PieWidget = ({ title, config, data, onEdit, onDelete }) => {
////  if (!config || !data.length) return <Empty description="配置不完整或数据为空" />;
////
////  const chartData = {
////    labels: data.map(item => item[config.categoryField]),
////    datasets: [{
////      data: data.map(item => item[config.valueField]),
////      backgroundColor: data.map((_, index) =>
////        `hsl(${index * 360 / data.length}, 70%, 50%)`
////      ),
////    }],
////  };
////
////  const options = {
////    responsive: true,
////    plugins: {
////      legend: {
////        position: 'right',
////      },
////    },
////  };
////
////  return (
////    <div style={{ height: 400 }}>
////      <Chart type="pie" data={chartData} options={options} />
////    </div>
////  );
////};
////
////// 表格组件
////const TableWidget = ({ title, config, data, onEdit, onDelete }) => {
////  if (!config || !data.length) return <Empty description="配置不完整或数据为空" />;
////
////  const columns = config.columns.map(col => ({
////    title: col,
////    dataIndex: col,
////    key: col,
////  }));
////
////  return (
////    <Table
////      columns={columns}
////      dataSource={data}
////      size="small"
////      scroll={{ x: true }}
////      pagination={{ pageSize: 5 }}
////    />
////  );
////};
////
////// 透视表组件
////const PivotWidget = ({ title, config, data, onEdit, onDelete }) => {
////  if (!config || !data.length) return <Empty description="配置不完整或数据为空" />;
////
////  // 这里简化实现，实际项目中可以使用专门的透视表库
////  const pivotData = {};
////
////  // 生成透视数据
////  data.forEach(item => {
////    const rowKey = config.rows.map(row => item[row]).join('-');
////    const colKey = config.cols?.length > 0 ? config.cols.map(col => item[col]).join('-') : '总计';
////
////    if (!pivotData[rowKey]) {
////      pivotData[rowKey] = { key: rowKey };
////      config.rows.forEach(row => {
////        pivotData[rowKey][row] = item[row];
////      });
////    }
////
////    config.values.forEach(value => {
////      const fieldName = colKey === '总计' ? value : `${value}_${colKey}`;
////      pivotData[rowKey][fieldName] = (pivotData[rowKey][fieldName] || 0) + (item[value] || 0);
////    });
////  });
////
////  const columns = [
////    ...config.rows.map(row => ({
////      title: row,
////      dataIndex: row,
////      key: row,
////    })),
////    ...Object.keys(pivotData[Object.keys(pivotData)[0]])
////      .filter(key => !config.rows.includes(key) && key !== 'key')
////      .map(key => ({
////        title: key,
////        dataIndex: key,
////        key: key,
////      }))
////  ];
////
////  return (
////    <Table
////      columns={columns}
////      dataSource={Object.values(pivotData)}
////      size="small"
////      scroll={{ x: true }}
////      pagination={{ pageSize: 5 }}
////    />
////  );
////};
////
////export default DataAnalysis;