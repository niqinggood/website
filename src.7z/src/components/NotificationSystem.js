import React, { useState } from 'react';
import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Typography,
  IconButton,
  Collapse,
  Alert
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import ErrorOutlineIcon from '@mui/icons-material/ErrorOutline';
import CheckCircleOutlineIcon from '@mui/icons-material/CheckCircleOutline';

const NotificationSystem = () => {
  const [notification, setNotification] = useState({
    open: false,
    type: '', // 'error' or 'success'
    title: '',
    message: '',
    details: []
  });

  // 高亮显示通知
  const showHighlightedNotification = (type, title, message, details = []) => {
    setNotification({
      open: true,
      type,
      title,
      message,
      details
    });
  };

  // 关闭通知
  const handleCloseNotification = () => {
    setNotification(prev => ({ ...prev, open: false }));
  };

  // 示例使用
  const triggerValidationError = () => {
    showHighlightedNotification('error', '表单验证失败', '请检查并修正以下问题', [
      '配置名称不能为空',
      '训练结束日期必须在评估开始日期之前',
      '至少需要添加一个配置项'
    ]);
  };

  const triggerSuccess = () => {
    showHighlightedNotification('success', '操作成功', '已成功触发5个配置取数');
  };

  return (
    <div style={{ padding: 24 }}>
      <Button
        variant="contained"
        color="error"
        onClick={triggerValidationError}
        sx={{ mr: 2 }}
      >
        触发错误提示
      </Button>

      <Button
        variant="contained"
        color="success"
        onClick={triggerSuccess}
      >
        触发成功提示
      </Button>

      {/* 通知对话框 */}
      <Dialog
        open={notification.open}
        onClose={handleCloseNotification}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
        PaperProps={{
          sx: {
            minWidth: 450,
            borderLeft: notification.type === 'error'
              ? '4px solid #d32f2f'
              : '4px solid #2e7d32'
          }
        }}
      >
        <DialogTitle sx={{ display: 'flex', alignItems: 'center', pt: 2 }}>
          {notification.type === 'error' ? (
            <ErrorOutlineIcon color="error" sx={{ fontSize: 30, mr: 1.5 }} />
          ) : (
            <CheckCircleOutlineIcon color="success" sx={{ fontSize: 30, mr: 1.5 }} />
          )}
          <Typography variant="h6" component="span" fontWeight="bold">
            {notification.title}
          </Typography>
          <IconButton
            aria-label="close"
            onClick={handleCloseNotification}
            sx={{
              position: 'absolute',
              right: 8,
              top: 8,
              color: (theme) => theme.palette.grey[500],
            }}
          >
            <CloseIcon />
          </IconButton>
        </DialogTitle>

        <DialogContent sx={{ pt: 0, pb: 2 }}>
          <Typography variant="body1" color="text.primary" sx={{ mb: 1 }}>
            {notification.message}
          </Typography>

          {notification.details.length > 0 && (
            <Collapse in={true} sx={{ mt: 2, borderTop: '1px solid rgba(0, 0, 0, 0.12)', pt: 2 }}>
              <Typography variant="subtitle2" fontWeight="bold" sx={{ mb: 1 }}>
                详细问题:
              </Typography>
              <ul style={{ margin: 0, paddingLeft: 24 }}>
                {notification.details.map((detail, index) => (
                  <li key={index}>
                    <Typography
                      variant="body2"
                      color="error"
                      component="span"
                      sx={{ fontWeight: notification.type === 'error' ? 500 : 'inherit' }}
                    >
                      {detail}
                    </Typography>
                  </li>
                ))}
              </ul>
            </Collapse>
          )}
        </DialogContent>

        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button
            variant="contained"
            onClick={handleCloseNotification}
            color={notification.type === 'error' ? 'error' : 'success'}
            autoFocus
            fullWidth
          >
            确认
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
};

export default NotificationSystem;