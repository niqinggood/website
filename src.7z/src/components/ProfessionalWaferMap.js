import React, { useMemo, useState, useRef, useEffect } from 'react';
import {
  Box, Typography, Select, MenuItem, Tooltip, Divider,
  FormControl, InputLabel, IconButton, useTheme
} from '@mui/material';
import ZoomInIcon from '@mui/icons-material/ZoomIn';
import ZoomOutIcon from '@mui/icons-material/ZoomOut';
import * as d3 from 'd3';

// ==============================
// SEMI 标准配置
// ==============================
const SEMICON_STANDARD_CONFIG = {
  dieStatus: [
    { id: 0, name: "合格芯片", color: "#22C55E", description: "电学参数、物理外观均符合标准" },
    { id: 1, name: "电气缺陷", color: "#F59E0B", description: "电压/电流参数超出规格范围" },
    { id: 2, name: "物理缺陷", color: "#EF4444", description: "表面划痕、崩角、污染等外观问题" },
    { id: 3, name: "功能失效", color: "#3B82F6", description: "芯片完全无法正常工作" },
    { id: 4, name: "跳过芯片", color: "#D946EF", description: "测试过程中跳过的芯片" },
    { id: 5, name: "标记芯片", color: "#FFFF00", description: "需要特殊关注或处理的芯片" },
    { id: 6, name: "空芯片", color: "#FFFFFF", description: "晶圆上无芯片的位置" },
  ],
  waferStyle: {
    background: "#F9FAFB",
    border: "#9CA3AF",
    gridLine: "#E5E7EB",
    flatZone: "#374151",
  },
};

// ==============================
// 主组件
// ==============================
export default function ProfessionalWaferMap({ data = [], size = 600, block, sampledData }) {
  const svgRef = useRef(null);
  const theme = useTheme();
  const [activeWaferId, setActiveWaferId] = useState('');
  const [zoomLevel, setZoomLevel] = useState(1);
  const [transform, setTransform] = useState(d3.zoomIdentity);
  const [hoveredDie, setHoveredDie] = useState(null);

  // 数据处理
  const processedData = useMemo(() => {
    if (!sampledData?.length || !block?.config) return [];

    const {
      waferIdField,
      waferXField,
      waferYField,
      waferValueField,
      defectTypeField
    } = block.config;

    return sampledData
      .filter(item => {
        const x = item[waferXField];
        const y = item[waferYField];
        const value = item[waferValueField];
        const defectType = item[defectTypeField];
        const waferId = item[waferIdField];

        return (
          x != null && !isNaN(Number(x)) &&
          y != null && !isNaN(Number(y)) &&
          value != null && !isNaN(Number(value)) &&
          defectType != null && !isNaN(Number(defectType)) &&
          waferId != null
        );
      })
      .map(item => ({
        waferId: item[waferIdField],
        x: Number(item[waferXField]),
        y: Number(item[waferYField]),
        measurement: Number(item[waferValueField]),
        defectType: Number(item[defectTypeField]),
        rawData: item
      }));
  }, [sampledData, block]);

  // 当前 wafer 数据
  const waferData = useMemo(() => {
    if (!activeWaferId && processedData.length > 0) {
      const uniqueIds = [...new Set(processedData.map(d => d.waferId))];
      setActiveWaferId(uniqueIds[0]);
      return processedData.filter(d => d.waferId === uniqueIds[0]);
    }
    return processedData.filter(d => d.waferId === activeWaferId);
  }, [processedData, activeWaferId]);

  // 动态计算 die 尺寸和网格 - 修复坐标转换逻辑
  const { gridSize, radius, center, dieSize, scaleFactor } = useMemo(() => {
    if (waferData.length === 0) {
      return {
        gridSize: 20,
        radius: size / 2 - 20,
        center: size / 2,
        dieSize: 18,
        scaleFactor: 1
      };
    }

    const xValues = waferData.map(d => d.x);
    const yValues = waferData.map(d => d.y);

    const xMin = Math.min(...xValues);
    const xMax = Math.max(...xValues);
    const yMin = Math.min(...yValues);
    const yMax = Math.max(...yValues);

    // 计算晶圆半径（基于最大坐标）
    const maxRadius = Math.max(
      Math.max(...xValues.map(Math.abs)),
      Math.max(...yValues.map(Math.abs))
    ) + 1;

    // 计算缩放因子，确保所有die都能显示在晶圆内
    const scaleFactor = (size * 0.4) / maxRadius;
    const gridSize = scaleFactor;
    const dieSize = Math.max(4, Math.min(20, gridSize * 0.8));

    return {
      gridSize,
      dieSize,
      radius: maxRadius * scaleFactor,
      center: size / 2,
      scaleFactor,
      xMin,
      xMax,
      yMin,
      yMax,
      maxRadius
    };
  }, [waferData, size]);

  // 初始化D3缩放
  useEffect(() => {
    if (!svgRef.current || waferData.length === 0) return;

    const svg = d3.select(svgRef.current);
    const zoom = d3.zoom()
      .scaleExtent([0.5, 8])
      .on('zoom', (event) => {
        setTransform(event.transform);
      });

    svg.call(zoom);

    return () => {
      svg.on('.zoom', null);
    };
  }, [waferData]);

  // die 配置
  const getDieConfig = (id) =>
    SEMICON_STANDARD_CONFIG.dieStatus.find((t) => t.id === id) ||
    SEMICON_STANDARD_CONFIG.dieStatus[0];

  // 计算统计信息
  const stats = useMemo(() => {
    if (waferData.length === 0) {
      return { total: 0, good: 0, yield: 0, defectCount: {} };
    }

    const defectCount = waferData.reduce((acc, die) => {
      acc[die.defectType] = (acc[die.defectType] || 0) + 1;
      return acc;
    }, {});

    const goodCount = defectCount[0] || 0;
    const totalCount = waferData.length;
    const yieldRate = (goodCount / totalCount) * 100;

    return {
      total: totalCount,
      good: goodCount,
      yield: yieldRate.toFixed(2),
      defectCount
    };
  }, [waferData]);

  // 渲染图例
  const renderLegend = () => (
    <Box sx={{ p: 2, backgroundColor: 'white', borderRadius: 1, boxShadow: 1 }}>
      <Typography variant="h6" gutterBottom>
        图例
      </Typography>
      {SEMICON_STANDARD_CONFIG.dieStatus.map((status) => (
        <Box key={status.id} sx={{ display: 'flex', alignItems: 'center', mb: 1.5 }}>
          <Box
            sx={{
              width: 16,
              height: 16,
              backgroundColor: status.color,
              border: '1px solid #666',
              borderRadius: 1,
              mr: 1.5
            }}
          />
          <Box sx={{ flex: 1 }}>
            <Typography variant="body2" fontWeight="medium">
              {status.name}
            </Typography>
            <Typography variant="caption" color="text.secondary">
              {status.description}
            </Typography>
          </Box>
        </Box>
      ))}
    </Box>
  );

  // 渲染统计信息
  const renderStats = () => (
    <Box sx={{ p: 2, backgroundColor: 'white', borderRadius: 1, boxShadow: 1, mt: 2 }}>
      <Typography variant="h6" gutterBottom>
        统计信息
      </Typography>
      <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 1 }}>
        <Typography variant="body2">总芯片数:</Typography>
        <Typography variant="body2" fontWeight="bold">{stats.total}</Typography>

        <Typography variant="body2" color="success.main">合格芯片:</Typography>
        <Typography variant="body2" color="success.main" fontWeight="bold">
          {stats.good}
        </Typography>

        <Typography variant="body2">良率:</Typography>
        <Typography variant="body2" fontWeight="bold" color={stats.yield > 90 ? 'success.main' : 'error.main'}>
          {stats.yield}%
        </Typography>
      </Box>

      {/* 显示各类缺陷数量 */}
      <Divider sx={{ my: 1 }} />
      <Typography variant="subtitle2" gutterBottom>
        缺陷分布
      </Typography>
      {Object.entries(stats.defectCount).map(([type, count]) => {
        if (type === '0') return null; // 跳过合格芯片
        const cfg = getDieConfig(parseInt(type));
        return (
          <Box key={type} sx={{ display: 'flex', justifyContent: 'space-between', mb: 0.5 }}>
            <Typography variant="body2" sx={{ color: cfg.color }}>
              {cfg.name}:
            </Typography>
            <Typography variant="body2" fontWeight="bold">
              {count}
            </Typography>
          </Box>
        );
      })}
    </Box>
  );

  if (processedData.length === 0) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" height={400}>
        <Typography color="text.secondary">无有效晶圆数据</Typography>
      </Box>
    );
  }

  return (
    <Box sx={{ p: 3, display: 'flex', gap: 3, minHeight: 500 }}>
      {/* 左侧控制面板 */}
      <Box sx={{ width: 250 }}>
        <FormControl fullWidth sx={{ mb: 2 }}>
          <InputLabel>晶圆ID</InputLabel>
          <Select
            value={activeWaferId}
            label="晶圆ID"
            onChange={(e) => setActiveWaferId(e.target.value)}
          >
            {[...new Set(processedData.map(d => d.waferId))].map(id => (
              <MenuItem key={id} value={id}>
                Wafer {id}
              </MenuItem>
            ))}
          </Select>
        </FormControl>

        <Box display="flex" alignItems="center" sx={{ mb: 3 }}>
          <IconButton
            size="small"
            onClick={() => setZoomLevel(Math.max(0.5, zoomLevel - 0.5))}
          >
            <ZoomOutIcon />
          </IconButton>
          <Typography sx={{ mx: 1, minWidth: 40, textAlign: 'center' }}>
            {(zoomLevel * 100).toFixed(0)}%
          </Typography>
          <IconButton
            size="small"
            onClick={() => setZoomLevel(Math.min(5, zoomLevel + 0.5))}
          >
            <ZoomInIcon />
          </IconButton>
        </Box>

        {renderLegend()}
        {renderStats()}
      </Box>

      {/* Wafer 渲染区域 */}
      <Box sx={{ flex: 1, display: 'flex', justifyContent: 'center' }}>
        <Box sx={{ position: 'relative' }}>
          <svg
            ref={svgRef}
            width={size}
            height={size}
            viewBox={`0 0 ${size} ${size}`}
            style={{
              cursor: 'pointer',
              backgroundColor: '#f8f9fa',
              borderRadius: '8px'
            }}
          >
            <g transform={transform}>
              {/* 晶圆背景 */}
              <circle
                cx={center}
                cy={center}
                r={radius}
                fill={SEMICON_STANDARD_CONFIG.waferStyle.background}
                stroke={SEMICON_STANDARD_CONFIG.waferStyle.border}
                strokeWidth={2}
              />

              {/* 平边 */}
              <rect
                x={center - radius * 0.125}
                y={center + radius - 6}
                width={radius * 0.25}
                height={6}
                fill={SEMICON_STANDARD_CONFIG.waferStyle.flatZone}
                rx={1}
              />

              {/* Die 网格 - 修复坐标转换 */}
              {waferData.map((die, index) => {
                const dieCfg = getDieConfig(die.defectType);

                // 正确的坐标转换：将晶圆坐标转换为SVG像素坐标
                const cx = center + die.x * gridSize;
                const cy = center - die.y * gridSize; // 注意Y轴方向

                // 判断是否在晶圆内
                const distanceFromCenter = Math.sqrt(
                  Math.pow(cx - center, 2) + Math.pow(cy - center, 2)
                );

                // 确保die在晶圆边界内
                if (distanceFromCenter > radius - dieSize / 2) return null;

                return (
                  <Tooltip
                    key={index}
                    title={
                      <Box>
                        <Typography variant="subtitle2">芯片详情</Typography>
                        <Divider sx={{ my: 1 }} />
                        <Typography variant="body2">
                          坐标: ({die.x}, {die.y})
                        </Typography>
                        <Typography variant="body2">
                          测试值: {die.measurement.toFixed(2)}
                        </Typography>
                        <Typography variant="body2">
                          状态: {dieCfg.name}
                        </Typography>
                        <Typography variant="body2">
                          缺陷类型: {die.defectType}
                        </Typography>
                      </Box>
                    }
                    arrow
                  >
                    <rect
                      x={cx - dieSize / 2}
                      y={cy - dieSize / 2}
                      width={dieSize}
                      height={dieSize}
                      fill={dieCfg.color}
                      stroke="#555"
                      strokeWidth={0.5}
                      rx={2}
                      ry={2}
                      onMouseEnter={() => setHoveredDie({ index, die })}
                      onMouseLeave={() => setHoveredDie(null)}
                      style={{
                        transition: 'all 0.2s ease',
                        filter: hoveredDie?.index === index ?
                          'brightness(1.2) drop-shadow(0 0 2px rgba(0,0,0,0.5))' : 'none'
                      }}
                    />
                  </Tooltip>
                );
              })}
            </g>
          </svg>

          {/* 当前晶圆ID显示 */}
          <Box
            sx={{
              position: 'absolute',
              top: 10,
              right: 10,
              backgroundColor: 'rgba(255, 255, 255, 0.9)',
              padding: '4px 12px',
              borderRadius: 2,
              border: '1px solid #ddd'
            }}
          >
            <Typography variant="body2" fontWeight="medium">
              Wafer {activeWaferId}
            </Typography>
          </Box>

          {/* 坐标信息 */}
          <Box
            sx={{
              position: 'absolute',
              bottom: 10,
              left: 10,
              backgroundColor: 'rgba(255, 255, 255, 0.8)',
              padding: '4px 8px',
              borderRadius: 1,
              fontSize: '12px'
            }}
          >
            <Typography variant="caption">
              X: {waferData[0]?.x || 0}, Y: {waferData[0]?.y || 0}
            </Typography>
          </Box>
        </Box>
      </Box>
    </Box>
  );
}

//import React, { useMemo, useState, useRef, useEffect } from 'react';
//import {
//  Box, Typography, Select, MenuItem, Tooltip, Divider,
//  FormControl, InputLabel, IconButton, useTheme
//} from '@mui/material';
//import ZoomInIcon from '@mui/icons-material/ZoomIn';
//import ZoomOutIcon from '@mui/icons-material/ZoomOut';
//import * as d3 from 'd3';
//
//// ==============================
//// SEMI 标准配置
//// ==============================
//const SEMICON_STANDARD_CONFIG = {
//  dieStatus: [
//    { id: 0, name: "合格芯片", color: "#22C55E", description: "电学参数、物理外观均符合标准" },
//    { id: 1, name: "电气缺陷", color: "#F59E0B", description: "电压/电流参数超出规格范围" },
//    { id: 2, name: "物理缺陷", color: "#EF4444", description: "表面划痕、崩角、污染等外观问题" },
//    { id: 3, name: "功能失效", color: "#3B82F6", description: "芯片完全无法正常工作" },
//    { id: 4, name: "跳过芯片", color: "#D946EF", description: "测试过程中跳过的芯片" },
//    { id: 5, name: "标记芯片", color: "#FFFF00", description: "需要特殊关注或处理的芯片" },
//    { id: 6, name: "空芯片", color: "#FFFFFF", description: "晶圆上无芯片的位置" },
//  ],
//  waferStyle: {
//    background: "#F9FAFB",
//    border: "#9CA3AF",
//    gridLine: "#E5E7EB",
//    flatZone: "#374151",
//  },
//};
//
//// ==============================
//// 主组件
//// ==============================
//export default function ProfessionalWaferMap({ data = [], size = 600, block, sampledData }) {
//  const svgRef = useRef(null);
//  const theme = useTheme();
//  const [activeWaferId, setActiveWaferId] = useState('');
//  const [zoomLevel, setZoomLevel] = useState(1);
//  const [transform, setTransform] = useState(d3.zoomIdentity);
//  const [hoveredDie, setHoveredDie] = useState(null);
//
//  // 数据处理
//  const processedData = useMemo(() => {
//    if (!sampledData?.length || !block?.config) return [];
//
//    const {
//      waferIdField,
//      waferXField,
//      waferYField,
//      waferValueField,
//      defectTypeField
//    } = block.config;
//
//    return sampledData
//      .filter(item => {
//        const x = item[waferXField];
//        const y = item[waferYField];
//        const value = item[waferValueField];
//        const defectType = item[defectTypeField];
//        const waferId = item[waferIdField];
//
//        return (
//          x != null && !isNaN(Number(x)) &&
//          y != null && !isNaN(Number(y)) &&
//          value != null && !isNaN(Number(value)) &&
//          defectType != null && !isNaN(Number(defectType)) &&
//          waferId != null
//        );
//      })
//      .map(item => ({
//        waferId: item[waferIdField],
//        x: Number(item[waferXField]),
//        y: Number(item[waferYField]),
//        measurement: Number(item[waferValueField]),
//        defectType: Number(item[defectTypeField]),
//        rawData: item
//      }));
//  }, [sampledData, block]);
//
//  // 当前 wafer 数据
//  const waferData = useMemo(() => {
//    if (!activeWaferId && processedData.length > 0) {
//      const uniqueIds = [...new Set(processedData.map(d => d.waferId))];
//      setActiveWaferId(uniqueIds[0]);
//      return processedData.filter(d => d.waferId === uniqueIds[0]);
//    }
//    return processedData.filter(d => d.waferId === activeWaferId);
//  }, [processedData, activeWaferId]);
//
//  // 动态计算 die 尺寸和网格
//  const { gridSize, radius, center, dieSize } = useMemo(() => {
//    if (waferData.length === 0) {
//      return {
//        gridSize: 20,
//        radius: size / 2 - 20,
//        center: size / 2,
//        dieSize: 18
//      };
//    }
//
//    const xValues = waferData.map(d => d.x);
//    const yValues = waferData.map(d => d.y);
//
//    const xMin = Math.min(...xValues);
//    const xMax = Math.max(...xValues);
//    const yMin = Math.min(...yValues);
//    const yMax = Math.max(...yValues);
//
//    const xRange = xMax - xMin;
//    const yRange = yMax - yMin;
//    const maxRange = Math.max(xRange, yRange) + 2; // 增加边距
//
//    const gridSize = (size * 0.8) / maxRange;
//    const dieSize = Math.max(4, Math.min(20, gridSize * 0.8)); // 限制die大小范围
//
//    return {
//      gridSize,
//      dieSize,
//      radius: size * 0.4,
//      center: size / 2,
//      xMin,
//      xMax,
//      yMin,
//      yMax
//    };
//  }, [waferData, size]);
//
//  // 初始化D3缩放
//  useEffect(() => {
//    if (!svgRef.current || waferData.length === 0) return;
//
//    const svg = d3.select(svgRef.current);
//    const zoom = d3.zoom()
//      .scaleExtent([0.5, 8])
//      .on('zoom', (event) => {
//        setTransform(event.transform);
//      });
//
//    svg.call(zoom);
//
//    return () => {
//      svg.on('.zoom', null);
//    };
//  }, [waferData]);
//
//  // die 配置
//  const getDieConfig = (id) =>
//    SEMICON_STANDARD_CONFIG.dieStatus.find((t) => t.id === id) ||
//    SEMICON_STANDARD_CONFIG.dieStatus[0];
//
//  // 计算统计信息
//  const stats = useMemo(() => {
//    if (waferData.length === 0) {
//      return { total: 0, good: 0, yield: 0, defectCount: {} };
//    }
//
//    const defectCount = waferData.reduce((acc, die) => {
//      acc[die.defectType] = (acc[die.defectType] || 0) + 1;
//      return acc;
//    }, {});
//
//    const goodCount = defectCount[0] || 0;
//    const totalCount = waferData.length;
//    const yieldRate = (goodCount / totalCount) * 100;
//
//    return {
//      total: totalCount,
//      good: goodCount,
//      yield: yieldRate.toFixed(2),
//      defectCount
//    };
//  }, [waferData]);
//
//  // 渲染图例
//  const renderLegend = () => (
//    <Box sx={{ p: 2, backgroundColor: 'white', borderRadius: 1, boxShadow: 1 }}>
//      <Typography variant="h6" gutterBottom>
//        图例
//      </Typography>
//      {SEMICON_STANDARD_CONFIG.dieStatus.map((status) => (
//        <Box key={status.id} sx={{ display: 'flex', alignItems: 'center', mb: 1.5 }}>
//          <Box
//            sx={{
//              width: 16,
//              height: 16,
//              backgroundColor: status.color,
//              border: '1px solid #666',
//              borderRadius: 1,
//              mr: 1.5
//            }}
//          />
//          <Box sx={{ flex: 1 }}>
//            <Typography variant="body2" fontWeight="medium">
//              {status.name}
//            </Typography>
//            <Typography variant="caption" color="text.secondary">
//              {status.description}
//            </Typography>
//          </Box>
//        </Box>
//      ))}
//    </Box>
//  );
//
//  // 渲染统计信息
//  const renderStats = () => (
//    <Box sx={{ p: 2, backgroundColor: 'white', borderRadius: 1, boxShadow: 1, mt: 2 }}>
//      <Typography variant="h6" gutterBottom>
//        统计信息
//      </Typography>
//      <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 1 }}>
//        <Typography variant="body2">总芯片数:</Typography>
//        <Typography variant="body2" fontWeight="bold">{stats.total}</Typography>
//
//        <Typography variant="body2" color="success.main">合格芯片:</Typography>
//        <Typography variant="body2" color="success.main" fontWeight="bold">
//          {stats.good}
//        </Typography>
//
//        <Typography variant="body2">良率:</Typography>
//        <Typography variant="body2" fontWeight="bold" color={stats.yield > 90 ? 'success.main' : 'error.main'}>
//          {stats.yield}%
//        </Typography>
//      </Box>
//    </Box>
//  );
//
//  if (processedData.length === 0) {
//    return (
//      <Box display="flex" justifyContent="center" alignItems="center" height={400}>
//        <Typography color="text.secondary">无有效晶圆数据</Typography>
//      </Box>
//    );
//  }
//
//  return (
//    <Box sx={{ p: 3, display: 'flex', gap: 3, minHeight: 500 }}>
//      {/* 左侧控制面板 */}
//      <Box sx={{ width: 250 }}>
//        <FormControl fullWidth sx={{ mb: 2 }}>
//          <InputLabel>晶圆ID</InputLabel>
//          <Select
//            value={activeWaferId}
//            label="晶圆ID"
//            onChange={(e) => setActiveWaferId(e.target.value)}
//          >
//            {[...new Set(processedData.map(d => d.waferId))].map(id => (
//              <MenuItem key={id} value={id}>
//                Wafer {id}
//              </MenuItem>
//            ))}
//          </Select>
//        </FormControl>
//
//        <Box display="flex" alignItems="center" sx={{ mb: 3 }}>
//          <IconButton
//            size="small"
//            onClick={() => setZoomLevel(Math.max(0.5, zoomLevel - 0.5))}
//          >
//            <ZoomOutIcon />
//          </IconButton>
//          <Typography sx={{ mx: 1, minWidth: 40, textAlign: 'center' }}>
//            {(zoomLevel * 100).toFixed(0)}%
//          </Typography>
//          <IconButton
//            size="small"
//            onClick={() => setZoomLevel(Math.min(5, zoomLevel + 0.5))}
//          >
//            <ZoomInIcon />
//          </IconButton>
//        </Box>
//
//        {renderLegend()}
//        {renderStats()}
//      </Box>
//
//      {/* Wafer 渲染区域 */}
//      <Box sx={{ flex: 1, display: 'flex', justifyContent: 'center' }}>
//        <Box sx={{ position: 'relative' }}>
//          <svg
//            ref={svgRef}
//            width={size}
//            height={size}
//            style={{
//              transform: `scale(${zoomLevel})`,
//              transformOrigin: 'center center',
//              cursor: 'pointer'
//            }}
//          >
//            <g transform={transform}>
//              {/* 晶圆背景 */}
//              <circle
//                cx={center}
//                cy={center}
//                r={radius}
//                fill={SEMICON_STANDARD_CONFIG.waferStyle.background}
//                stroke={SEMICON_STANDARD_CONFIG.waferStyle.border}
//                strokeWidth={2}
//              />
//
//              {/* 平边 */}
//              <rect
//                x={center - radius * 0.125}
//                y={center + radius - 6}
//                width={radius * 0.25}
//                height={6}
//                fill={SEMICON_STANDARD_CONFIG.waferStyle.flatZone}
//                rx={1}
//              />
//
//              {/* Die 网格 */}
//              {waferData.map((die, index) => {
//                const dieCfg = getDieConfig(die.defectType);
//                const cx = center + die.x * gridSize;
//                const cy = center - die.y * gridSize;
//
//                // 判断是否在晶圆内
//                const distanceFromCenter = Math.sqrt(
//                  Math.pow(cx - center, 2) + Math.pow(cy - center, 2)
//                );
//                if (distanceFromCenter > radius - dieSize / 2) return null;
//
//                return (
//                  <Tooltip
//                    key={index}
//                    title={
//                      <Box>
//                        <Typography variant="subtitle2">芯片详情</Typography>
//                        <Divider sx={{ my: 1 }} />
//                        <Typography variant="body2">
//                          坐标: ({die.x}, {die.y})
//                        </Typography>
//                        <Typography variant="body2">
//                          测试值: {die.measurement.toFixed(2)}
//                        </Typography>
//                        <Typography variant="body2">
//                          状态: {dieCfg.name}
//                        </Typography>
//                      </Box>
//                    }
//                    arrow
//                  >
//                    <rect
//                      x={cx - dieSize / 2}
//                      y={cy - dieSize / 2}
//                      width={dieSize}
//                      height={dieSize}
//                      fill={dieCfg.color}
//                      stroke="#555"
//                      strokeWidth={0.5}
//                      rx={2}
//                      ry={2}
//                      onMouseEnter={() => setHoveredDie({ index, die })}
//                      onMouseLeave={() => setHoveredDie(null)}
//                      style={{
//                        transition: 'all 0.2s ease',
//                        filter: hoveredDie?.index === index ? 'brightness(1.2) drop-shadow(0 0 2px rgba(0,0,0,0.5))' : 'none'
//                      }}
//                    />
//                  </Tooltip>
//                );
//              })}
//            </g>
//          </svg>
//
//          {/* 当前晶圆ID显示 */}
//          <Box
//            sx={{
//              position: 'absolute',
//              top: 10,
//              right: 10,
//              backgroundColor: 'rgba(255, 255, 255, 0.9)',
//              padding: '4px 12px',
//              borderRadius: 2,
//              border: '1px solid #ddd'
//            }}
//          >
//            <Typography variant="body2" fontWeight="medium">
//              Wafer {activeWaferId}
//            </Typography>
//          </Box>
//        </Box>
//      </Box>
//    </Box>
//  );
//}


//import React, { useState, useMemo } from 'react';
//import {
//  Box, Typography, Slider, Tooltip, Select,
//  MenuItem, FormControl, InputLabel, Divider, IconButton
//} from '@mui/material';
//import { styled } from '@mui/material/styles';
//import ZoomInIcon from '@mui/icons-material/ZoomIn';
//import ZoomOutIcon from '@mui/icons-material/ZoomOut';
//
//// ==============================
//// 1. 半导体行业标准配置（符合SEMI规范）
//// ==============================
//const SEMICON_STANDARD_CONFIG = {
//  // 缺陷类型定义（参考半导体测试行业标准）
//  defectClassification: [
//    {
//      id: 0,
//      name: '无缺陷',
//      color: '#22C55E', // 绿色：正常
//      marker: 'circle',
//      description: '电学参数、物理外观均符合标准',
//      severity: '低'
//    },
//    {
//      id: 1,
//      name: '电气缺陷',
//      color: '#F59E0B', // 橙色：电学异常
//      marker: 'square',
//      description: '电压/电流参数超出规格范围',
//      severity: '中'
//    },
//    {
//      id: 2,
//      name: '物理缺陷',
//      color: '#EF4444', // 红色：物理损坏
//      marker: 'triangle',
//      description: '表面划痕、崩角、污染等外观问题',
//      severity: '高'
//    },
//    {
//      id: 3,
//      name: '致命缺陷',
//      color: '#3B82F6', // 蓝色：功能失效
//      marker: 'diamond',
//      description: '芯片完全无法正常工作',
//      severity: '极高'
//    }
//  ],
//  // 晶圆视觉样式（模拟真实晶圆物理特性）
//  waferStyle: {
//    background: '#F9FAFB', // 晶圆基底色
//    border: '#D1D5DB',     // 晶圆边缘色
//    centerLine: '#E5E7EB', // 十字中心线色
//    flatZone: '#6B7280',   // 定位平边色
//    padding: 16,           // 边距
//    gridLine: '#E5E7EB'    // 网格线颜色
//  },
//  // Jet色彩映射（半导体行业数值可视化标准）
//  jetColorMap: [
//    '#000080', '#0000FF', '#0080FF', '#00FFFF', '#80FF80',
//    '#FFFF00', '#FF8000', '#FF0000', '#800000', '#000000'
//  ]
//};
//
//// ==============================
//// 2. 自定义组件样式（复用性设计）
//// ==============================
//// 晶圆芯片标记组件（支持多形状/交互）
//const WaferChipMarker = styled(Box)(({
//  markerType, markerSize, markerColor, isHover
//}) => {
//  // 不同缺陷类型的形状定义
//  const markerShapes = {
//    circle: { borderRadius: '50%' },
//    square: { borderRadius: '2px' },
//    triangle: {
//      borderRadius: 0,
//      clipPath: 'polygon(50% 0%, 0% 100%, 100% 100%)',
//      transform: 'rotate(180deg)'
//    },
//    diamond: {
//      borderRadius: 0,
//      clipPath: 'polygon(50% 0%, 100% 50%, 50% 100%, 0% 50%)'
//    }
//  };
//
//  return {
//    ...markerShapes[markerType],
//    width: isHover ? markerSize + 6 : markerSize,
//    height: isHover ? markerSize + 6 : markerSize,
//    backgroundColor: markerColor,
//    border: isHover ? '2px solid #111827' : '1px solid #E5E7EB',
//    boxShadow: isHover ? '0 0 12px rgba(0,0,0,0.7)' : '0 1px 3px rgba(0,0,0,0.1)',
//    transition: 'all 0.2s ease-in-out',
//    zIndex: isHover ? 20 : 5,
//    cursor: 'pointer'
//  };
//});
//
//// 晶圆边界组件（模拟真实晶圆圆形轮廓）
//const WaferBoundary = styled(Box)(({ size }) => ({
//  position: 'absolute',
//  width: size,
//  height: size,
//  borderRadius: '50%',
//  border: `2px solid ${SEMICON_STANDARD_CONFIG.waferStyle.border}`,
//  backgroundColor: SEMICON_STANDARD_CONFIG.waferStyle.background,
//  overflow: 'hidden',
//  zIndex: 2
//}));
//
//// 晶圆定位平边（Flat Zone，用于晶圆校准）
//const WaferFlatZone = styled(Box)(({ size }) => ({
//  position: 'absolute',
//  bottom: 0,
//  left: '50%',
//  transform: 'translateX(-50%)',
//  width: size * 0.25, // 平边宽度为晶圆直径25%（行业常规）
//  height: 6,
//  backgroundColor: SEMICON_STANDARD_CONFIG.waferStyle.flatZone,
//  zIndex: 4
//}));
//
//// 晶圆中心十字线（用于坐标参考）
//const WaferCenterLine = styled(Box)(({ isVertical, size }) => ({
//  position: 'absolute',
//  backgroundColor: SEMICON_STANDARD_CONFIG.waferStyle.centerLine,
//  opacity: 0.6,
//  zIndex: 3,
//  ...(isVertical
//    ? {
//        left: '50%',
//        top: 0,
//        bottom: 0,
//        width: 1,
//        transform: 'translateX(-50%)'
//      }
//    : {
//        top: '50%',
//        left: 0,
//        right: 0,
//        height: 1,
//        transform: 'translateY(-50%)'
//      })
//}));
//
//// 晶圆网格线（模拟真实晶圆上的die布局）
//const WaferGridLine = styled(Box)(({ isVertical, size, position, gridSpacing }) => ({
//  position: 'absolute',
//  backgroundColor: SEMICON_STANDARD_CONFIG.waferStyle.gridLine,
//  opacity: 0.4,
//  zIndex: 1,
//  ...(isVertical
//    ? {
//        left: `${position * gridSpacing}%`,
//        top: 0,
//        bottom: 0,
//        width: 1,
//      }
//    : {
//        top: `${position * gridSpacing}%`,
//        left: 0,
//        right: 0,
//        height: 1,
//      })
//}));
//
//// ==============================
//// 3. 主组件逻辑（专业级功能实现）
//// ==============================
//export const ProfessionalWaferMap = ({ block, sampledData, theme }) => {
//  // 状态管理：交互相关
//  const [activeWaferId, setActiveWaferId] = useState(''); // 当前选中晶圆ID
//  const [hoveredChip, setHoveredChip] = useState(null);   // 鼠标悬停芯片
//  const [zoomRatio, setZoomRatio] = useState(100);        // 缩放比例（100%默认）
//  const [showGrid, setShowGrid] = useState(true);         // 是否显示网格
//
//  // ==============================
//  // 3.1 数据预处理（专业级清洗）
//  // ==============================
//  const processedData = useMemo(() => {
//    // 1. 验证必要配置字段（防止报错）
//    const requiredConfigFields = [
//      'waferIdField',    // 晶圆ID字段
//      'waferXField',     // X坐标字段
//      'waferYField',     // Y坐标字段
//      'waferValueField', // 测试值字段
//      'defectTypeField'  // 缺陷类型字段
//    ];
//    const hasValidConfig = requiredConfigFields.every(
//      field => block?.config?.[field]
//    );
//
//    if (!hasValidConfig || !sampledData?.length) return [];
//
//    // 2. 数据清洗：过滤无效值、格式标准化
//    const cleanedData = sampledData
//      .filter(item => {
//        // 提取原始字段值
//        const x = item[block.config.waferXField];
//        const y = item[block.config.waferYField];
//        const value = item[block.config.waferValueField];
//        const defectType = item[block.config.defectTypeField];
//        const waferId = item[block.config.waferIdField];
//
//        // 过滤条件：非空、非NaN
//        return (
//          x != null && !isNaN(Number(x)) &&
//          y != null && !isNaN(Number(y)) &&
//          value != null && !isNaN(Number(value)) &&
//          defectType != null && !isNaN(Number(defectType)) &&
//          waferId != null
//        );
//      })
//      .map(item => ({
//        waferId: item[block.config.waferIdField],
//        x: Number(item[block.config.waferXField]),
//        y: Number(item[block.config.waferYField]),
//        measurement: Number(item[block.config.waferValueField]),
//        defectType: Number(item[block.config.defectTypeField]),
//        rawData: item // 保留原始数据用于详情展示
//      }));
//
//    // 3. 初始化：自动选择第一个晶圆
//    if (cleanedData.length > 0 && !activeWaferId) {
//      const uniqueWaferIds = [...new Set(cleanedData.map(item => item.waferId))];
//      setActiveWaferId(uniqueWaferIds[0]);
//    }
//
//    return cleanedData;
//  }, [sampledData, block, activeWaferId]);
//
//  // ==============================
//  // 3.2 筛选当前激活晶圆数据
//  // ==============================
//  const activeWaferData = useMemo(() => {
//    if (!activeWaferId) return [];
//    return processedData.filter(item => item.waferId === activeWaferId);
//  }, [processedData, activeWaferId]);
//
//  // ==============================
//  // 3.3 计算数据统计信息（核心）
//  // ==============================
//  const dataStats = useMemo(() => {
//    if (activeWaferData.length === 0) {
//      return {
//        coordinates: {
//          x: { min: 0, max: 0, range: 0 },
//          y: { min: 0, max: 0, range: 0 }
//        },
//        measurement: { min: 0, max: 0, range: 0 },
//        defectSummary: { total: 0, types: { 0: 0, 1: 0, 2: 0, 3: 0 } },
//        yield: 0 // 良率（无缺陷芯片占比）
//      };
//    }
//
//    // 1. 坐标范围计算（增加10%边距，避免芯片贴边）
//    const xValues = activeWaferData.map(item => item.x);
//    const yValues = activeWaferData.map(item => item.y);
//    const measureValues = activeWaferData.map(item => item.measurement);
//
//    const xMin = Math.min(...xValues);
//    const xMax = Math.max(...xValues);
//    const yMin = Math.min(...yValues);
//    const yMax = Math.max(...yValues);
//
//    // 2. 缺陷统计
//    const defectCount = activeWaferData.reduce((acc, item) => {
//      acc[item.defectType] = (acc[item.defectType] || 0) + 1;
//      return acc;
//    }, { 0: 0, 1: 0, 2: 0, 3: 0 });
//
//    // 3. 良率计算（无缺陷芯片占比）
//    const goodChipCount = defectCount[0];
//    const totalChipCount = activeWaferData.length;
//    const yieldRate = (goodChipCount / totalChipCount) * 100;
//
//    return {
//      coordinates: {
//        x: {
//          min: xMin - (xMax - xMin) * 0.1,
//          max: xMax + (xMax - xMin) * 0.1,
//          range: (xMax + (xMax - xMin) * 0.1) - (xMin - (xMax - xMin) * 0.1)
//        },
//        y: {
//          min: yMin - (yMax - yMin) * 0.1,
//          max: yMax + (yMax - yMin) * 0.1,
//          range: (yMax + (yMax - yMin) * 0.1) - (yMin - (yMax - yMin) * 0.1)
//        }
//      },
//      measurement: {
//        min: Math.min(...measureValues),
//        max: Math.max(...measureValues),
//        range: Math.max(...measureValues) - Math.min(...measureValues)
//      },
//      defectSummary: {
//        total: totalChipCount,
//        types: defectCount
//      },
//      yield: yieldRate.toFixed(2)
//    };
//  }, [activeWaferData]);
//
//  // ==============================
//  // 3.4 辅助工具函数
//  // ==============================
//  // 获取缺陷类型配置
//  const getDefectConfig = (defectTypeId) => {
//    return SEMICON_STANDARD_CONFIG.defectClassification.find(
//      type => type.id === defectTypeId
//    ) || SEMICON_STANDARD_CONFIG.defectClassification[0];
//  };
//
//  // Jet色彩映射计算（数值转颜色）
//  const getJetColor = (value) => {
//    if (dataStats.measurement.range === 0) return SEMICON_STANDARD_CONFIG.jetColorMap[4];
//    const normalizedValue = (value - dataStats.measurement.min) / dataStats.measurement.range;
//    const colorIndex = Math.min(
//      Math.floor(normalizedValue * SEMICON_STANDARD_CONFIG.jetColorMap.length),
//      SEMICON_STANDARD_CONFIG.jetColorMap.length - 1
//    );
//    return SEMICON_STANDARD_CONFIG.jetColorMap[colorIndex];
//  };
//
//  // 获取所有唯一晶圆ID
//  const getUniqueWaferIds = useMemo(() => {
//    return [...new Set(processedData.map(item => item.waferId))];
//  }, [processedData]);
//
//  // ==============================
//  // 3.5 渲染子组件（模块化设计）
//  // ==============================
//  // 渲染晶圆网格线
//  const renderWaferGrid = () => {
//    if (!showGrid) return null;
//
//    const gridLines = [];
//    const gridSpacing = 10; // 网格间距百分比
//
//    // 垂直网格线
//    for (let i = 1; i < 10; i++) {
//      gridLines.push(
//        <WaferGridLine
//          key={`v-grid-${i}`}
//          isVertical={true}
//          position={i}
//          gridSpacing={gridSpacing}
//        />
//      );
//    }
//
//    // 水平网格线
//    for (let i = 1; i < 10; i++) {
//      gridLines.push(
//        <WaferGridLine
//          key={`h-grid-${i}`}
//          isVertical={false}
//          position={i}
//          gridSpacing={gridSpacing}
//        />
//      );
//    }
//
//    return gridLines;
//  };
//
//  // 渲染晶圆芯片（核心可视化）
//  const renderWaferChips = () => {
//    if (activeWaferData.length === 0) return null;
//
//    // 计算实际晶圆尺寸（受缩放比例影响）
//    const baseWaferSize = block.config.waferDiameter || 280;
//    const actualWaferSize = (baseWaferSize * zoomRatio) / 100;
//    const waferRadius = actualWaferSize / 2;
//
//    return activeWaferData.map((chip, index) => {
//      // 1. 坐标归一化（原始坐标 → 晶圆像素坐标）
//      const normalizedX = (chip.x - dataStats.coordinates.x.min) / dataStats.coordinates.x.range;
//      const normalizedY = (chip.y - dataStats.coordinates.y.min) / dataStats.coordinates.y.range;
//
//      // 2. 计算芯片在晶圆中的像素位置（居中对齐，预留边距）
//      const chipX = (normalizedX * (actualWaferSize - 20)) + 10;
//      const chipY = (normalizedY * (actualWaferSize - 20)) + 10;
//
//      // 3. 几何校验：过滤晶圆边界外的芯片
//      const centerX = actualWaferSize / 2;
//      const centerY = actualWaferSize / 2;
//      const distanceToCenter = Math.sqrt(
//        Math.pow(chipX - centerX, 2) + Math.pow(chipY - centerY, 2)
//      );
//      if (distanceToCenter > waferRadius - 5) return null;
//
//      // 4. 获取缺陷配置与交互状态
//      const defectConfig = getDefectConfig(chip.defectType);
//      const isHover = hoveredChip?.index === index;
//
//      return (
//        <Tooltip
//          key={`wafer-chip-${index}`}
//          title={
//            <Box p={1.5} width={240} sx={{
//              backgroundColor: '#FFFFFF',
//              borderRadius: '6px',
//              boxShadow: '0 2px 8px rgba(0,0,0,0.15)'
//            }}>
//              <Typography variant="subtitle2" fontWeight="bold" sx={{ color: '#1F2937' }}>
//                芯片详情
//              </Typography>
//              <Divider sx={{ my: 1, opacity: 0.5 }} />
//              <Typography variant="caption" sx={{ display: 'block', mb: 0.5, color: '#4B5563' }}>
//                <span style={{ fontWeight: 500 }}>晶圆ID：</span> {chip.waferId}
//              </Typography>
//              <Typography variant="caption" sx={{ display: 'block', mb: 0.5, color: '#4B5563' }}>
//                <span style={{ fontWeight: 500 }}>坐标：</span> ({chip.x.toFixed(1)}, {chip.y.toFixed(1)})
//              </Typography>
//              <Typography variant="caption" sx={{ display: 'block', mb: 0.5, color: '#4B5563' }}>
//                <span style={{ fontWeight: 500 }}>测试值：</span> {chip.measurement.toFixed(2)}
//              </Typography>
//              <Typography variant="caption" sx={{ display: 'block', mb: 0.5, color: '#4B5563' }}>
//                <span style={{ fontWeight: 500 }}>缺陷类型：</span> {defectConfig.name}
//              </Typography>
//              <Typography variant="caption" sx={{ display: 'block', mb: 0.5, color: '#4B5563' }}>
//                <span style={{ fontWeight: 500 }}>严重程度：</span> {defectConfig.severity}
//              </Typography>
//              <Typography variant="caption" sx={{ display: 'block', color: '#4B5563' }}>
//                <span style={{ fontWeight: 500 }}>缺陷描述：</span> {defectConfig.description}
//              </Typography>
//            </Box>
//          }
//          placement="top"
//          arrow
//          sx={{ zIndex: 30 }}
//        >
//          <WaferChipMarker
//            markerType={defectConfig.marker}
//            markerSize={12}
//            markerColor={defectConfig.color}
//            isHover={isHover}
//            sx={{
//              position: 'absolute',
//              left: chipX - 6, // 基于markerSize/2居中偏移
//              top: chipY - 6,
//              transform: isHover ? 'scale(1.3)' : 'scale(1)'
//            }}
//            onMouseEnter={() => setHoveredChip({ index, chip })}
//            onMouseLeave={() => setHoveredChip(null)}
//          />
//        </Tooltip>
//      );
//    });
//  };
//
//  // 渲染测试值颜色图例（垂直方向）
//  const renderMeasurementLegend = () => {
//    const { min, max } = dataStats.measurement;
//    return (
//      <Box sx={{
//        display: 'flex',
//        flexDirection: 'column',
//        alignItems: 'center',
//        mt: 2,
//        p: 1.5,
//        backgroundColor: '#FFFFFF',
//        borderRadius: '8px',
//        border: `1px solid ${SEMICON_STANDARD_CONFIG.waferStyle.border}`,
//        boxShadow: '0 2px 6px rgba(0,0,0,0.05)',
//        width: 60,
//        height: 300
//      }}>
//        <Typography variant="caption" sx={{ color: '#4B5563', mb: 1, whiteSpace: 'nowrap' }}>
//          {max.toFixed(1)}
//        </Typography>
//        <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column', width: 28 }}>
//          {Array.from({ length: 15 }).map((_, i) => {
//            const value = min + (i / 14) * (max - min);
//            return (
//              <Tooltip
//                key={`measure-legend-${i}`}
//                title={value.toFixed(2)}
//                placement="left"
//              >
//                <Box
//                  sx={{
//                    flex: 1,
//                    backgroundColor: getJetColor(value),
//                    borderBottom: i < 14 ? `1px solid rgba(255,255,255,0.2)` : 'none'
//                  }}
//                />
//              </Tooltip>
//            );
//          })}
//        </Box>
//        <Typography variant="caption" sx={{ color: '#4B5563', mt: 1, whiteSpace: 'nowrap' }}>
//          {min.toFixed(1)}
//        </Typography>
//        <Typography variant="caption" sx={{ color: '#6B7280', mt: 1, fontSize: '0.7rem' }}>
//          测试值
//        </Typography>
//      </Box>
//    );
//  };
//
//  // 渲染缺陷类型图例
//  const renderDefectLegend = () => {
//    return (
//      <Box sx={{
//        display: 'flex',
//        flexDirection: 'column',
//        gap: 1,
//        mt: 2,
//        p: 1.5,
//        backgroundColor: '#FFFFFF',
//        borderRadius: '8px',
//        border: `1px solid ${SEMICON_STANDARD_CONFIG.waferStyle.border}`,
//        boxShadow: '0 2px 6px rgba(0,0,0,0.05)',
//        width: 140,
//        height: 300,
//        justifyContent: 'center'
//      }}>
//        {SEMICON_STANDARD_CONFIG.defectClassification.map(defect => (
//          <Box key={`defect-legend-${defect.id}`} sx={{
//            display: 'flex',
//            alignItems: 'center',
//            gap: 1,
//            padding: '6px 8px',
//            borderRadius: '4px',
//            backgroundColor: '#F3F4F6',
//            cursor: 'help'
//          }}>
//            <WaferChipMarker
//              markerType={defect.marker}
//              markerSize={10}
//              markerColor={defect.color}
//              isHover={false}
//            />
//            <Box>
//              <Typography variant="caption" sx={{ color: '#1F2937', fontWeight: 500, fontSize: '0.7rem' }}>
//                {defect.name}
//              </Typography>
//              <Typography variant="caption" sx={{ color: '#6B7280', fontSize: '0.65rem', display: 'block' }}>
//                {defect.severity}
//              </Typography>
//            </Box>
//          </Box>
//        ))}
//      </Box>
//    );
//  };
//
//  // 渲染晶圆统计信息面板
//  const renderWaferStats = () => {
//    const { total, types } = dataStats.defectSummary;
//    return (
//      <Box sx={{
//        display: 'flex',
//        flexDirection: 'column',
//        gap: 1,
//        mt: 2,
//        p: 1.5,
//        backgroundColor: '#FFFFFF',
//        borderRadius: '8px',
//        border: `1px solid ${SEMICON_STANDARD_CONFIG.waferStyle.border}`,
//        boxShadow: '0 2px 6px rgba(0,0,0,0.05)',
//        width: 140,
//        height: 300
//      }}>
//        <StatItem
//          label="总芯片数"
//          value={total}
//          icon={<Box sx={{ width: 12, height: 12, borderRadius: '50%', backgroundColor: '#9CA3AF' }} />}
//        />
//        <StatItem
//          label="无缺陷"
//          value={types[0]}
//          icon={<Box sx={{ width: 12, height: 12, borderRadius: '50%', backgroundColor: '#22C55E' }} />}
//        />
//        <StatItem
//          label="电气缺陷"
//          value={types[1]}
//          icon={<Box sx={{ width: 12, height: 12, borderRadius: '2px', backgroundColor: '#F59E0B' }} />}
//        />
//        <StatItem
//          label="物理缺陷"
//          value={types[2]}
//          icon={<Box sx={{ width: 12, height: 12, clipPath: 'polygon(50% 0%, 0% 100%, 100% 100%)', backgroundColor: '#EF4444' }} />}
//        />
//        <StatItem
//          label="致命缺陷"
//          value={types[3]}
//          icon={<Box sx={{ width: 12, height: 12, clipPath: 'polygon(50% 0%, 100% 50%, 50% 100%, 0% 50%)', backgroundColor: '#3B82F6' }} />}
//        />
//        <StatItem
//          label="良率"
//          value={`${dataStats.yield}%`}
//          icon={<Box sx={{ width: 12, height: 12, borderRadius: '50%', backgroundColor: '#10B981' }} />}
//          isHighlight={dataStats.yield > 90}
//        />
//      </Box>
//    );
//  };
//
//  // 统计项子组件（复用）
//  const StatItem = ({ label, value, icon, isHighlight = false }) => (
//    <Box sx={{
//      display: 'flex',
//      alignItems: 'center',
//      gap: 1,
//      padding: '4px 6px',
//      borderRadius: '4px',
//      backgroundColor: isHighlight ? '#ECFDF5' : '#F9FAFB',
//      border: isHighlight ? '1px solid #D1FAE5' : 'none'
//    }}>
//      {icon}
//      <Box>
//        <Typography variant="caption" sx={{ color: '#6B7280', fontSize: '0.7rem' }}>
//          {label}
//        </Typography>
//        <Typography variant="body2" sx={{
//          color: isHighlight ? '#059669' : '#1F2937',
//          fontWeight: 600,
//          fontSize: '0.8rem'
//        }}>
//          {value}
//        </Typography>
//      </Box>
//    </Box>
//  );
//
//  // ==============================
//  // 3.6 错误状态渲染
//  // ==============================
//  const renderErrorState = () => {
//    // 配置不完整
//    const requiredFields = [
//      'waferIdField', 'waferXField', 'waferYField', 'waferValueField', 'defectTypeField'
//    ];
//    const missingFields = requiredFields.filter(field => !block?.config?.[field]);
//
//    if (missingFields.length > 0) {
//      return (
//        <Box
//          height="100%"
//          display="flex"
//          justifyContent="center"
//          alignItems="center"
//          p={4}
//          backgroundColor="#F9FAFB"
//          borderRadius="8px"
//          border="1px solid #F3F4F6"
//        >
//          <Box textAlign="center">
//            <Typography variant="h6" sx={{ color: '#DC2626', mb: 2 }}>
//              Wafer Map 配置不完整
//            </Typography>
//            <Typography variant="body2" sx={{ color: '#4B5563', mb: 3 }}>
//              请补充以下必要配置字段：
//            </Typography>
//            <Box sx={{
//              display: 'flex',
//              flexWrap: 'wrap',
//              gap: 1,
//              justifyContent: 'center'
//            }}>
//              {missingFields.map(field => (
//                <Box key={field} sx={{
//                  padding: '4px 8px',
//                  backgroundColor: '#FEE2E2',
//                  color: '#B91C1C',
//                  borderRadius: '4px',
//                  fontSize: '0.75rem'
//                }}>
//                  {field}
//                </Box>
//              ))}
//            </Box>
//          </Box>
//        </Box>
//      );
//    }
//
//    // 无数据
//    if (processedData.length === 0) {
//      return (
//        <Box
//          height="100%"
//          display="flex"
//          justifyContent="center"
//          alignItems="center"
//          p={4}
//          backgroundColor="#F9FAFB"
//          borderRadius="8px"
//          border="1px solid #F3F4F6"
//        >
//          <Box textAlign="center">
//            <Typography variant="h6" sx={{ color: '#6B7280', mb: 2 }}>
//              无有效晶圆数据
//            </Typography>
//            <Typography variant="body2" sx={{ color: '#9CA3AF' }}>
//              请检查数据格式是否符合要求，或确认数据来源是否正常
//            </Typography>
//          </Box>
//        </Box>
//      );
//    }
//
//    return null;
//  };
//
//  // ==============================
//  // 3.7 主渲染逻辑
//  // ==============================
//  const errorState = renderErrorState();
//  if (errorState) return errorState;
//
//  // 计算实际晶圆尺寸（含缩放）
//  const baseWaferSize = block.config.waferDiameter || 280;
//  const actualWaferSize = (baseWaferSize * zoomRatio) / 100;
//
//  return (
//    <Box sx={{
//      height: '100%',
//      width: '100%',
//      p: 2,
//      display: 'flex',
//      flexDirection: 'column',
//      backgroundColor: '#FAFAFA',
//      borderRadius: '12px',
//      boxShadow: '0 4px 12px rgba(0,0,0,0.05)'
//    }}>
//      {/* 1. 标题与控制栏 */}
//      <Box sx={{
//        width: '100%',
//        display: 'flex',
//        justifyContent: 'space-between',
//        alignItems: 'center',
//        mb: 2
//      }}>
//        <Typography variant="h6" sx={{ color: '#1F2937', fontWeight: 600 }}>
//          晶圆缺陷分布图
//        </Typography>
//
//        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
//          {/* 网格显示切换 */}
//          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
//            <Typography variant="caption" sx={{ color: '#6B7280' }}>
//              网格:
//            </Typography>
//            <Box
//              sx={{
//                width: 36,
//                height: 20,
//                borderRadius: 10,
//                backgroundColor: showGrid ? '#3B82F6' : '#E5E7EB',
//                display: 'flex',
//                alignItems: 'center',
//                justifyContent: showGrid ? 'flex-end' : 'flex-start',
//                padding: '2px',
//                cursor: 'pointer'
//              }}
//              onClick={() => setShowGrid(!showGrid)}
//            >
//              <Box sx={{
//                width: 16,
//                height: 16,
//                borderRadius: '50%',
//                backgroundColor: '#FFFFFF'
//              }} />
//            </Box>
//          </Box>
//
//          {/* 晶圆选择下拉框 */}
//          <FormControl size="small" sx={{ minWidth: 120 }}>
//            <InputLabel sx={{ fontSize: '0.75rem' }}>晶圆ID</InputLabel>
//            <Select
//              value={activeWaferId}
//              label="晶圆ID"
//              onChange={(e) => setActiveWaferId(e.target.value)}
//              sx={{
//                '& .MuiSelect-select': { fontSize: '0.75rem', py: 0.5 },
//                '& .MuiOutlinedInput-notchedOutline': { borderColor: '#D1D5DB' },
//                '&:hover .MuiOutlinedInput-notchedOutline': { borderColor: '#3B82F6' },
//                '&.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: '#3B82F6' }
//              }}
//            >
//              {getUniqueWaferIds.map(waferId => (
//                <MenuItem key={waferId} value={waferId} sx={{ fontSize: '0.75rem' }}>
//                  {waferId}
//                </MenuItem>
//              ))}
//            </Select>
//          </FormControl>
//
//          {/* 缩放控制 */}
//          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
//            <IconButton
//              size="small"
//              onClick={() => setZoomRatio(Math.max(50, zoomRatio - 10))}
//              sx={{ color: '#6B7280' }}
//            >
//              <ZoomOutIcon fontSize="small" />
//            </IconButton>
//
//            <Typography variant="caption" sx={{ color: '#6B7280', minWidth: 40, textAlign: 'center' }}>
//              {zoomRatio}%
//            </Typography>
//
//            <IconButton
//              size="small"
//              onClick={() => setZoomRatio(Math.min(200, zoomRatio + 10))}
//              sx={{ color: '#6B7280' }}
//            >
//              <ZoomInIcon fontSize="small" />
//            </IconButton>
//          </Box>
//        </Box>
//      </Box>
//
//      {/* 2. 主要内容区域 */}
//      <Box sx={{
//        display: 'flex',
//        flex: 1,
//        gap: 2
//      }}>
//        {/* 左侧图例 */}
//        <Box sx={{
//          display: 'flex',
//          flexDirection: 'column',
//          alignItems: 'center'
//        }}>
//          {renderMeasurementLegend()}
//        </Box>
//
//        {/* 中央晶圆可视化区域 */}
//        <Box sx={{
//          flex: 1,
//          display: 'flex',
//          justifyContent: 'center',
//          alignItems: 'center',
//          minHeight: 500
//        }}>
//          <Box sx={{
//            position: 'relative',
//            width: actualWaferSize + 40, // 含边距
//            height: actualWaferSize + 40,
//            display: 'flex',
//            justifyContent: 'center',
//            alignItems: 'center',
//            backgroundColor: '#FFFFFF',
//            borderRadius: '8px',
//            padding: 2,
//            boxShadow: '0 2px 8px rgba(0,0,0,0.05)'
//          }}>
//            {/* 晶圆边界 */}
//            <WaferBoundary size={actualWaferSize} />
//
//            {/* 网格线 */}
//            {renderWaferGrid()}
//
//            {/* 中心十字线 */}
//            <WaferCenterLine isVertical={true} size={actualWaferSize} />
//            <WaferCenterLine isVertical={false} size={actualWaferSize} />
//
//            {/* 定位平边 */}
//            <WaferFlatZone size={actualWaferSize} />
//
//            {/* 晶圆芯片（核心内容） */}
//            {renderWaferChips()}
//
//            {/* 坐标标签 */}
//            <Box sx={{
//              position: 'absolute',
//              bottom: 0,
//              left: 0,
//              right: 0,
//              display: 'flex',
//              justifyContent: 'space-between',
//              padding: '0 10px'
//            }}>
//              <Typography variant="caption" sx={{ color: '#9CA3AF', fontSize: '0.7rem' }}>
//                X: {dataStats.coordinates.x.min.toFixed(1)}
//              </Typography>
//              <Typography variant="caption" sx={{ color: '#9CA3AF', fontSize: '0.7rem' }}>
//                X: {dataStats.coordinates.x.max.toFixed(1)}
//              </Typography>
//            </Box>
//            <Box sx={{
//              position: 'absolute',
//              top: 0,
//              bottom: 0,
//              left: 0,
//              display: 'flex',
//              flexDirection: 'column',
//              justifyContent: 'space-between',
//              padding: '10px 0'
//            }}>
//              <Typography variant="caption" sx={{ color: '#9CA3AF', fontSize: '0.7rem', transform: 'rotate(-90deg) translateX(-50%)' }}>
//                Y: {dataStats.coordinates.y.max.toFixed(1)}
//              </Typography>
//              <Typography variant="caption" sx={{ color: '#9CA3AF', fontSize: '0.7rem', transform: 'rotate(-90deg) translateX(-50%)' }}>
//                Y: {dataStats.coordinates.y.min.toFixed(1)}
//              </Typography>
//            </Box>
//
//            {/* 当前晶圆ID标记 */}
//            <Box sx={{
//              position: 'absolute',
//              top: 10,
//              right: 10,
//              backgroundColor: 'rgba(59, 130, 246, 0.8)',
//              color: '#FFFFFF',
//              padding: '2px 8px',
//              borderRadius: '4px',
//              zIndex: 10
//            }}>
//              <Typography variant="caption" fontWeight="bold" sx={{ fontSize: '0.7rem' }}>
//                {activeWaferId}
//              </Typography>
//            </Box>
//          </Box>
//        </Box>
//
//        {/* 右侧图例和统计 */}
//        <Box sx={{
//          display: 'flex',
//          flexDirection: 'column',
//          alignItems: 'center',
//          gap: 2
//        }}>
//          {renderDefectLegend()}
//          {renderWaferStats()}
//        </Box>
//      </Box>
//
//      {/* 3. 悬停芯片详情面板（固定位置展示） */}
//      {hoveredChip && (
//        <Box sx={{
//          position: 'fixed',
//          bottom: 20,
//          right: 20,
//          width: 300,
//          backgroundColor: '#FFFFFF',
//          borderRadius: '8px',
//          border: '1px solid #E5E7EB',
//          boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
//          padding: 2,
//          zIndex: 50
//        }}>
//          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1 }}>
//            <Typography variant="subtitle2" fontWeight="bold" sx={{ color: '#1F2937' }}>
//              芯片实时详情
//            </Typography>
//            <Box
//              sx={{
//                width: 16,
//                height: 16,
//                borderRadius: '50%',
//                backgroundColor: '#F3F4F6',
//                display: 'flex',
//                justifyContent: 'center',
//                alignItems: 'center',
//                cursor: 'pointer'
//              }}
//              onClick={() => setHoveredChip(null)}
//            >
//              <Typography variant="caption" sx={{ color: '#9CA3AF' }}>×</Typography>
//            </Box>
//          </Box>
//          <Divider sx={{ mb: 1.5, opacity: 0.5 }} />
//
//          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
//            <DetailItem
//              label="晶圆ID"
//              value={hoveredChip.chip.waferId}
//              icon={<Box sx={{ width: 12, height: 12, borderRadius: '2px', backgroundColor: '#E5E7EB' }} />}
//            />
//            <DetailItem
//              label="坐标位置"
//              value={`(${hoveredChip.chip.x.toFixed(1)}, ${hoveredChip.chip.y.toFixed(1)})`}
//              icon={<Box sx={{ width: 12, height: 12, borderRadius: '50%', backgroundColor: '#E5E7EB' }} />}
//            />
//            <DetailItem
//              label="测试数值"
//              value={hoveredChip.chip.measurement.toFixed(2)}
//              icon={<Box sx={{ width: 12, height: 12, borderRadius: '2px', backgroundColor: getJetColor(hoveredChip.chip.measurement) }} />}
//            />
//            <DetailItem
//              label="缺陷类型"
//              value={getDefectConfig(hoveredChip.chip.defectType).name}
//              icon={<Box
//                sx={{
//                  width: 12,
//                  height: 12,
//                  ...(getDefectConfig(hoveredChip.chip.defectType).marker === 'circle' ? { borderRadius: '50%' } :
//                      getDefectConfig(hoveredChip.chip.defectType).marker === 'square' ? { borderRadius: '2px' } :
//                      getDefectConfig(hoveredChip.chip.defectType).marker === 'triangle' ? { clipPath: 'polygon(50% 0%, 0% 100%, 100% 100%)' } :
//                      { clipPath: 'polygon(50% 0%, 100% 50%, 50% 100%, 0% 50%)' }),
//                  backgroundColor: getDefectConfig(hoveredChip.chip.defectType).color
//                }}
//              />}
//            />
//            <DetailItem
//              label="严重程度"
//              value={getDefectConfig(hoveredChip.chip.defectType).severity}
//              icon={<Box sx={{ width: 12, height: 12, borderRadius: '2px', backgroundColor:
//                getDefectConfig(hoveredChip.chip.defectType).severity === '低' ? '#D1FAE5' :
//                getDefectConfig(hoveredChip.chip.defectType).severity === '中' ? '#FEF3C7' :
//                getDefectConfig(hoveredChip.chip.defectType).severity === '高' ? '#FEE2E2' : '#F0ABFC'
//              }} />}
//            />
//          </Box>
//        </Box>
//      )}
//    </Box>
//  );
//};
//
//// 详情项子组件（复用）
//const DetailItem = ({ label, value, icon }) => (
//  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
//    {icon}
//    <Typography variant="body2" sx={{ color: '#6B7280', flex: 1 }}>
//      {label}
//    </Typography>
//    <Typography variant="body2" sx={{ color: '#1F2937', fontWeight: 500 }}>
//      {value}
//    </Typography>
//  </Box>
//);
//
//export default ProfessionalWaferMap;

//
//
//import React, { useState, useMemo } from 'react';
//import {
//  Box, Typography, Slider, Tooltip, Select,
//  MenuItem, FormControl, InputLabel, Divider
//} from '@mui/material';
//import { styled } from '@mui/material/styles';
//
//// ==============================
//// 1. 半导体行业标准配置（符合SEMI规范）
//// ==============================
//const SEMICON_STANDARD_CONFIG = {
//  // 缺陷类型定义（参考半导体测试行业标准）
//  defectClassification: [
//    {
//      id: 0,
//      name: '无缺陷',
//      color: '#22C55E', // 绿色：正常
//      marker: 'circle',
//      description: '电学参数、物理外观均符合标准',
//      severity: '低'
//    },
//    {
//      id: 1,
//      name: '电气缺陷',
//      color: '#F59E0B', // 橙色：电学异常
//      marker: 'square',
//      description: '电压/电流参数超出规格范围',
//      severity: '中'
//    },
//    {
//      id: 2,
//      name: '物理缺陷',
//      color: '#EF4444', // 红色：物理损坏
//      marker: 'triangle',
//      description: '表面划痕、崩角、污染等外观问题',
//      severity: '高'
//    },
//    {
//      id: 3,
//      name: '致命缺陷',
//      color: '#3B82F6', // 蓝色：功能失效
//      marker: 'diamond',
//      description: '芯片完全无法正常工作',
//      severity: '极高'
//    }
//  ],
//  // 晶圆视觉样式（模拟真实晶圆物理特性）
//  waferStyle: {
//    background: '#F9FAFB', // 晶圆基底色
//    border: '#D1D5DB',     // 晶圆边缘色
//    centerLine: '#E5E7EB', // 十字中心线色
//    flatZone: '#6B7280',   // 定位平边色
//    padding: 16            // 边距
//  },
//  // Jet色彩映射（半导体行业数值可视化标准）
//  jetColorMap: [
//    '#000080', '#0000FF', '#0080FF', '#00FFFF', '#80FF80',
//    '#FFFF00', '#FF8000', '#FF0000', '#800000', '#000000'
//  ]
//};
//
//// ==============================
//// 2. 自定义组件样式（复用性设计）
//// ==============================
//// 晶圆芯片标记组件（支持多形状/交互）
//const WaferChipMarker = styled(Box)(({
//  markerType, markerSize, markerColor, isHover
//}) => {
//  // 不同缺陷类型的形状定义
//  const markerShapes = {
//    circle: { borderRadius: '50%' },
//    square: { borderRadius: '2px' },
//    triangle: {
//      borderRadius: 0,
//      clipPath: 'polygon(50% 0%, 0% 100%, 100% 100%)',
//      transform: 'rotate(180deg)'
//    },
//    diamond: {
//      borderRadius: 0,
//      clipPath: 'polygon(50% 0%, 100% 50%, 50% 100%, 0% 50%)'
//    }
//  };
//
//  return {
//    ...markerShapes[markerType],
//    width: isHover ? markerSize + 6 : markerSize,
//    height: isHover ? markerSize + 6 : markerSize,
//    backgroundColor: markerColor,
//    border: isHover ? '2px solid #111827' : '1px solid #E5E7EB',
//    boxShadow: isHover ? '0 0 12px rgba(0,0,0,0.7)' : '0 1px 3px rgba(0,0,0,0.1)',
//    transition: 'all 0.2s ease-in-out',
//    zIndex: isHover ? 20 : 5,
//    cursor: 'pointer'
//  };
//});
//
//// 晶圆边界组件（模拟真实晶圆圆形轮廓）
//const WaferBoundary = styled(Box)(({ size }) => ({
//  position: 'absolute',
//  width: size,
//  height: size,
//  borderRadius: '50%',
//  border: `2px solid ${SEMICON_STANDARD_CONFIG.waferStyle.border}`,
//  backgroundColor: SEMICON_STANDARD_CONFIG.waferStyle.background,
//  overflow: 'hidden',
//  zIndex: 2
//}));
//
//// 晶圆定位平边（Flat Zone，用于晶圆校准）
//const WaferFlatZone = styled(Box)(({ size }) => ({
//  position: 'absolute',
//  bottom: 0,
//  left: '50%',
//  transform: 'translateX(-50%)',
//  width: size * 0.25, // 平边宽度为晶圆直径25%（行业常规）
//  height: 6,
//  backgroundColor: SEMICON_STANDARD_CONFIG.waferStyle.flatZone,
//  zIndex: 4
//}));
//
//// 晶圆中心十字线（用于坐标参考）
//const WaferCenterLine = styled(Box)(({ isVertical, size }) => ({
//  position: 'absolute',
//  backgroundColor: SEMICON_STANDARD_CONFIG.waferStyle.centerLine,
//  opacity: 0.6,
//  zIndex: 3,
//  ...(isVertical
//    ? {
//        left: '50%',
//        top: 0,
//        bottom: 0,
//        width: 1,
//        transform: 'translateX(-50%)'
//      }
//    : {
//        top: '50%',
//        left: 0,
//        right: 0,
//        height: 1,
//        transform: 'translateY(-50%)'
//      })
//}));
//
//// ==============================
//// 3. 主组件逻辑（专业级功能实现）
//// ==============================
//export const ProfessionalWaferMap = ({ block, sampledData, theme }) => {
//  // 状态管理：交互相关
//  const [activeWaferId, setActiveWaferId] = useState(''); // 当前选中晶圆ID
//  const [hoveredChip, setHoveredChip] = useState(null);   // 鼠标悬停芯片
//  const [zoomRatio, setZoomRatio] = useState(100);        // 缩放比例（100%默认）
//
//  // ==============================
//  // 3.1 数据预处理（专业级清洗）
//  // ==============================
//  const processedData = useMemo(() => {
//    // 1. 验证必要配置字段（防止报错）
//    const requiredConfigFields = [
//      'waferIdField',    // 晶圆ID字段
//      'waferXField',     // X坐标字段
//      'waferYField',     // Y坐标字段
//      'waferValueField', // 测试值字段
//      'defectTypeField'  // 缺陷类型字段
//    ];
//    const hasValidConfig = requiredConfigFields.every(
//      field => block?.config?.[field]
//    );
//
//    if (!hasValidConfig || !sampledData?.length) return [];
//
//    // 2. 数据清洗：过滤无效值、格式标准化
//    const cleanedData = sampledData
//      .filter(item => {
//        // 提取原始字段值
//        const x = item[block.config.waferXField];
//        const y = item[block.config.waferYField];
//        const value = item[block.config.waferValueField];
//        const defectType = item[block.config.defectTypeField];
//        const waferId = item[block.config.waferIdField];
//
//        // 过滤条件：非空、非NaN
//        return (
//          x != null && !isNaN(Number(x)) &&
//          y != null && !isNaN(Number(y)) &&
//          value != null && !isNaN(Number(value)) &&
//          defectType != null && !isNaN(Number(defectType)) &&
//          waferId != null
//        );
//      })
//      .map(item => ({
//        waferId: item[block.config.waferIdField],
//        x: Number(item[block.config.waferXField]),
//        y: Number(item[block.config.waferYField]),
//        measurement: Number(item[block.config.waferValueField]),
//        defectType: Number(item[block.config.defectTypeField]),
//        rawData: item // 保留原始数据用于详情展示
//      }));
//
//    // 3. 初始化：自动选择第一个晶圆
//    if (cleanedData.length > 0 && !activeWaferId) {
//      const uniqueWaferIds = [...new Set(cleanedData.map(item => item.waferId))];
//      setActiveWaferId(uniqueWaferIds[0]);
//    }
//
//    return cleanedData;
//  }, [sampledData, block, activeWaferId]);
//
//  // ==============================
//  // 3.2 筛选当前激活晶圆数据
//  // ==============================
//  const activeWaferData = useMemo(() => {
//    if (!activeWaferId) return [];
//    return processedData.filter(item => item.waferId === activeWaferId);
//  }, [processedData, activeWaferId]);
//
//  // ==============================
//  // 3.3 计算数据统计信息（核心）
//  // ==============================
//  const dataStats = useMemo(() => {
//    if (activeWaferData.length === 0) {
//      return {
//        coordinates: {
//          x: { min: 0, max: 0, range: 0 },
//          y: { min: 0, max: 0, range: 0 }
//        },
//        measurement: { min: 0, max: 0, range: 0 },
//        defectSummary: { total: 0, types: { 0: 0, 1: 0, 2: 0, 3: 0 } },
//        yield: 0 // 良率（无缺陷芯片占比）
//      };
//    }
//
//    // 1. 坐标范围计算（增加10%边距，避免芯片贴边）
//    const xValues = activeWaferData.map(item => item.x);
//    const yValues = activeWaferData.map(item => item.y);
//    const measureValues = activeWaferData.map(item => item.measurement);
//
//    const xMin = Math.min(...xValues);
//    const xMax = Math.max(...xValues);
//    const yMin = Math.min(...yValues);
//    const yMax = Math.max(...yValues);
//
//    // 2. 缺陷统计
//    const defectCount = activeWaferData.reduce((acc, item) => {
//      acc[item.defectType] = (acc[item.defectType] || 0) + 1;
//      return acc;
//    }, { 0: 0, 1: 0, 2: 0, 3: 0 });
//
//    // 3. 良率计算（无缺陷芯片占比）
//    const goodChipCount = defectCount[0];
//    const totalChipCount = activeWaferData.length;
//    const yieldRate = (goodChipCount / totalChipCount) * 100;
//
//    return {
//      coordinates: {
//        x: {
//          min: xMin - (xMax - xMin) * 0.1,
//          max: xMax + (xMax - xMin) * 0.1,
//          range: (xMax + (xMax - xMin) * 0.1) - (xMin - (xMax - xMin) * 0.1)
//        },
//        y: {
//          min: yMin - (yMax - yMin) * 0.1,
//          max: yMax + (yMax - yMin) * 0.1,
//          range: (yMax + (yMax - yMin) * 0.1) - (yMin - (yMax - yMin) * 0.1)
//        }
//      },
//      measurement: {
//        min: Math.min(...measureValues),
//        max: Math.max(...measureValues),
//        range: Math.max(...measureValues) - Math.min(...measureValues)
//      },
//      defectSummary: {
//        total: totalChipCount,
//        types: defectCount
//      },
//      yield: yieldRate.toFixed(2)
//    };
//  }, [activeWaferData]);
//
//  // ==============================
//  // 3.4 辅助工具函数
//  // ==============================
//  // 获取缺陷类型配置
//  const getDefectConfig = (defectTypeId) => {
//    return SEMICON_STANDARD_CONFIG.defectClassification.find(
//      type => type.id === defectTypeId
//    ) || SEMICON_STANDARD_CONFIG.defectClassification[0];
//  };
//
//  // Jet色彩映射计算（数值转颜色）
//  const getJetColor = (value) => {
//    if (dataStats.measurement.range === 0) return SEMICON_STANDARD_CONFIG.jetColorMap[4];
//    const normalizedValue = (value - dataStats.measurement.min) / dataStats.measurement.range;
//    const colorIndex = Math.min(
//      Math.floor(normalizedValue * SEMICON_STANDARD_CONFIG.jetColorMap.length),
//      SEMICON_STANDARD_CONFIG.jetColorMap.length - 1
//    );
//    return SEMICON_STANDARD_CONFIG.jetColorMap[colorIndex];
//  };
//
//  // 获取所有唯一晶圆ID
//  const getUniqueWaferIds = useMemo(() => {
//    return [...new Set(processedData.map(item => item.waferId))];
//  }, [processedData]);
//
//  // ==============================
//  // 3.5 渲染子组件（模块化设计）
//  // ==============================
//  // 渲染晶圆芯片（核心可视化）
//  const renderWaferChips = () => {
//    if (activeWaferData.length === 0) return null;
//
//    // 计算实际晶圆尺寸（受缩放比例影响）
//    const baseWaferSize = block.config.waferDiameter || 280;
//    const actualWaferSize = (baseWaferSize * zoomRatio) / 100;
//    const waferRadius = actualWaferSize / 2;
//
//    return activeWaferData.map((chip, index) => {
//      // 1. 坐标归一化（原始坐标 → 晶圆像素坐标）
//      const normalizedX = (chip.x - dataStats.coordinates.x.min) / dataStats.coordinates.x.range;
//      const normalizedY = (chip.y - dataStats.coordinates.y.min) / dataStats.coordinates.y.range;
//
//      // 2. 计算芯片在晶圆中的像素位置（居中对齐，预留边距）
//      const chipX = (normalizedX * (actualWaferSize - 20)) + 10;
//      const chipY = (normalizedY * (actualWaferSize - 20)) + 10;
//
//      // 3. 几何校验：过滤晶圆边界外的芯片
//      const centerX = actualWaferSize / 2;
//      const centerY = actualWaferSize / 2;
//      const distanceToCenter = Math.sqrt(
//        Math.pow(chipX - centerX, 2) + Math.pow(chipY - centerY, 2)
//      );
//      if (distanceToCenter > waferRadius - 5) return null;
//
//      // 4. 获取缺陷配置与交互状态
//      const defectConfig = getDefectConfig(chip.defectType);
//      const isHover = hoveredChip?.index === index;
//
//      return (
//        <Tooltip
//          key={`wafer-chip-${index}`}
//          title={
//            <Box p={1.5} width={240} sx={{
//              backgroundColor: '#FFFFFF',
//              borderRadius: '6px',
//              boxShadow: '0 2px 8px rgba(0,0,0,0.15)'
//            }}>
//              <Typography variant="subtitle2" fontWeight="bold" sx={{ color: '#1F2937' }}>
//                芯片详情
//              </Typography>
//              <Divider sx={{ my: 1, opacity: 0.5 }} />
//              <Typography variant="caption" sx={{ display: 'block', mb: 0.5, color: '#4B5563' }}>
//                <span style={{ fontWeight: 500 }}>晶圆ID：</span> {chip.waferId}
//              </Typography>
//              <Typography variant="caption" sx={{ display: 'block', mb: 0.5, color: '#4B5563' }}>
//                <span style={{ fontWeight: 500 }}>坐标：</span> ({chip.x.toFixed(1)}, {chip.y.toFixed(1)})
//              </Typography>
//              <Typography variant="caption" sx={{ display: 'block', mb: 0.5, color: '#4B5563' }}>
//                <span style={{ fontWeight: 500 }}>测试值：</span> {chip.measurement.toFixed(2)}
//              </Typography>
//              <Typography variant="caption" sx={{ display: 'block', mb: 0.5, color: '#4B5563' }}>
//                <span style={{ fontWeight: 500 }}>缺陷类型：</span> {defectConfig.name}
//              </Typography>
//              <Typography variant="              caption" sx={{ display: 'block', mb: 0.5, color: '#4B5563' }}>
//                <span style={{ fontWeight: 500 }}>严重程度：</span> {defectConfig.severity}
//              </Typography>
//              <Typography variant="caption" sx={{ display: 'block', color: '#4B5563' }}>
//                <span style={{ fontWeight: 500 }}>缺陷描述：</span> {defectConfig.description}
//              </Typography>
//            </Box>
//          }
//          placement="top"
//          arrow
//          sx={{ zIndex: 30 }}
//        >
//          <WaferChipMarker
//            markerType={defectConfig.marker}
//            markerSize={12}
//            markerColor={defectConfig.color}
//            isHover={isHover}
//            sx={{
//              position: 'absolute',
//              left: chipX - 6, // 基于markerSize/2居中偏移
//              top: chipY - 6,
//              transform: isHover ? 'scale(1.3)' : 'scale(1)'
//            }}
//            onMouseEnter={() => setHoveredChip({ index, chip })}
//            onMouseLeave={() => setHoveredChip(null)}
//          />
//        </Tooltip>
//      );
//    });
//  };
//
//  // 渲染测试值颜色图例
//  const renderMeasurementLegend = () => {
//    const { min, max } = dataStats.measurement;
//    return (
//      <Box sx={{
//        display: 'flex',
//        alignItems: 'center',
//        mt: 2,
//        p: 1.5,
//        backgroundColor: '#FFFFFF',
//        borderRadius: '8px',
//        border: `1px solid ${SEMICON_STANDARD_CONFIG.waferStyle.border}`,
//        boxShadow: '0 2px 6px rgba(0,0,0,0.05)',
//        width: '100%',
//        maxWidth: 550
//      }}>
//        <Typography variant="caption" sx={{ color: '#4B5563', mr: 2, whiteSpace: 'nowrap' }}>
//          测试值：{min.toFixed(1)}
//        </Typography>
//        <Box sx={{ flex: 1, display: 'flex', height: 28 }}>
//          {Array.from({ length: 15 }).map((_, i) => {
//            const value = min + (i / 14) * (max - min);
//            return (
//              <Tooltip
//                key={`measure-legend-${i}`}
//                title={value.toFixed(2)}
//                placement="top"
//              >
//                <Box
//                  sx={{
//                    flex: 1,
//                    backgroundColor: getJetColor(value),
//                    borderRight: i < 14 ? `1px solid rgba(255,255,255,0.2)` : 'none'
//                  }}
//                />
//              </Tooltip>
//            );
//          })}
//        </Box>
//        <Typography variant="caption" sx={{ color: '#4B5563', ml: 2, whiteSpace: 'nowrap' }}>
//          {max.toFixed(1)}
//        </Typography>
//      </Box>
//    );
//  };
//
//  // 渲染缺陷类型图例
//  const renderDefectLegend = () => {
//    return (
//      <Box sx={{
//        display: 'flex',
//        flexWrap: 'wrap',
//        gap: 2,
//        mt: 2,
//        p: 1.5,
//        backgroundColor: '#FFFFFF',
//        borderRadius: '8px',
//        border: `1px solid ${SEMICON_STANDARD_CONFIG.waferStyle.border}`,
//        boxShadow: '0 2px 6px rgba(0,0,0,0.05)',
//        width: '100%',
//        maxWidth: 550,
//        justifyContent: 'center'
//      }}>
//        {SEMICON_STANDARD_CONFIG.defectClassification.map(defect => (
//          <Box key={`defect-legend-${defect.id}`} sx={{
//            display: 'flex',
//            alignItems: 'center',
//            gap: 1,
//            padding: '4px 8px',
//            borderRadius: '4px',
//            backgroundColor: '#F3F4F6',
//            cursor: 'help'
//          }}>
//            <WaferChipMarker
//              markerType={defect.marker}
//              markerSize={8}
//              markerColor={defect.color}
//              isHover={false}
//            />
//            <Box>
//              <Typography variant="caption" sx={{ color: '#1F2937', fontWeight: 500 }}>
//                {defect.name}
//              </Typography>
//              <Typography variant="caption" sx={{ color: '#6B7280', fontSize: '0.7rem' }}>
//                {defect.severity}
//              </Typography>
//            </Box>
//          </Box>
//        ))}
//      </Box>
//    );
//  };
//
//  // 渲染晶圆统计信息面板
//  const renderWaferStats = () => {
//    const { total, types } = dataStats.defectSummary;
//    return (
//      <Box sx={{
//        display: 'flex',
//        flexWrap: 'wrap',
//        gap: 2,
//        mt: 2,
//        p: 2,
//        backgroundColor: '#FFFFFF',
//        borderRadius: '8px',
//        border: `1px solid ${SEMICON_STANDARD_CONFIG.waferStyle.border}`,
//        boxShadow: '0 2px 6px rgba(0,0,0,0.05)',
//        width: '100%',
//        maxWidth: 550
//      }}>
//        <StatItem
//          label="总芯片数"
//          value={total}
//          icon={<Box sx={{ width: 16, height: 16, borderRadius: '50%', backgroundColor: '#9CA3AF' }} />}
//        />
//        <StatItem
//          label="无缺陷"
//          value={types[0]}
//          icon={<Box sx={{ width: 16, height: 16, borderRadius: '50%', backgroundColor: '#22C55E' }} />}
//        />
//        <StatItem
//          label="电气缺陷"
//          value={types[1]}
//          icon={<Box sx={{ width: 16, height: 16, borderRadius: '2px', backgroundColor: '#F59E0B' }} />}
//        />
//        <StatItem
//          label="物理缺陷"
//          value={types[2]}
//          icon={<Box sx={{ width: 16, height: 16, clipPath: 'polygon(50% 0%, 0% 100%, 100% 100%)', backgroundColor: '#EF4444' }} />}
//        />
//        <StatItem
//          label="致命缺陷"
//          value={types[3]}
//          icon={<Box sx={{ width: 16, height: 16, clipPath: 'polygon(50% 0%, 100% 50%, 50% 100%, 0% 50%)', backgroundColor: '#3B82F6' }} />}
//        />
//        <StatItem
//          label="良率"
//          value={`${dataStats.yield}%`}
//          icon={<Box sx={{ width: 16, height: 16, borderRadius: '50%', backgroundColor: '#10B981' }} />}
//          isHighlight={dataStats.yield > 90}
//        />
//      </Box>
//    );
//  };
//
//  // 统计项子组件（复用）
//  const StatItem = ({ label, value, icon, isHighlight = false }) => (
//    <Box sx={{
//      display: 'flex',
//      alignItems: 'center',
//      gap: 1,
//      padding: '6px 12px',
//      borderRadius: '6px',
//      backgroundColor: isHighlight ? '#ECFDF5' : '#F9FAFB',
//      border: isHighlight ? '1px solid #D1FAE5' : 'none'
//    }}>
//      {icon}
//      <Box>
//        <Typography variant="caption" sx={{ color: '#6B7280' }}>
//          {label}
//        </Typography>
//        <Typography variant="body2" sx={{
//          color: isHighlight ? '#059669' : '#1F2937',
//          fontWeight: 600
//        }}>
//          {value}
//        </Typography>
//      </Box>
//    </Box>
//  );
//
//  // ==============================
//  // 3.6 错误状态渲染
//  // ==============================
//  const renderErrorState = () => {
//    // 配置不完整
//    const requiredFields = [
//      'waferIdField', 'waferXField', 'waferYField', 'waferValueField', 'defectTypeField'
//    ];
//    const missingFields = requiredFields.filter(field => !block?.config?.[field]);
//
//    if (missingFields.length > 0) {
//      return (
//        <Box
//          height="100%"
//          display="flex"
//          justifyContent="center"
//          alignItems="center"
//          p={4}
//          backgroundColor="#F9FAFB"
//          borderRadius="8px"
//          border="1px solid #F3F4F6"
//        >
//          <Box textAlign="center">
//            <Typography variant="h6" sx={{ color: '#DC2626', mb: 2 }}>
//              Wafer Map 配置不完整
//            </Typography>
//            <Typography variant="body2" sx={{ color: '#4B5563', mb: 3 }}>
//              请补充以下必要配置字段：
//            </Typography>
//            <Box sx={{
//              display: 'flex',
//              flexWrap: 'wrap',
//              gap: 1,
//              justifyContent: 'center'
//            }}>
//              {missingFields.map(field => (
//                <Box key={field} sx={{
//                  padding: '4px 8px',
//                  backgroundColor: '#FEE2E2',
//                  color: '#B91C1C',
//                  borderRadius: '4px',
//                  fontSize: '0.75rem'
//                }}>
//                  {field}
//                </Box>
//              ))}
//            </Box>
//          </Box>
//        </Box>
//      );
//    }
//
//    // 无数据
//    if (processedData.length === 0) {
//      return (
//        <Box
//          height="100%"
//          display="flex"
//          justifyContent="center"
//          alignItems="center"
//          p={4}
//          backgroundColor="#F9FAFB"
//          borderRadius="8px"
//          border="1px solid #F3F4F6"
//        >
//          <Box textAlign="center">
//            <Typography variant="h6" sx={{ color: '#6B7280', mb: 2 }}>
//              无有效晶圆数据
//            </Typography>
//            <Typography variant="body2" sx={{ color: '#9CA3AF' }}>
//              请检查数据格式是否符合要求，或确认数据来源是否正常
//            </Typography>
//          </Box>
//        </Box>
//      );
//    }
//
//    return null;
//  };
//
//  // ==============================
//  // 3.7 主渲染逻辑
//  // ==============================
//  const errorState = renderErrorState();
//  if (errorState) return errorState;
//
//  // 计算实际晶圆尺寸（含缩放）
//  const baseWaferSize = block.config.waferDiameter || 280;
//  const actualWaferSize = (baseWaferSize * zoomRatio) / 100;
//
//  return (
//    <Box sx={{
//      height: '100%',
//      width: '100%',
//      p: 3,
//      display: 'flex',
//      flexDirection: 'column',
//      alignItems: 'center',
//      backgroundColor: '#FAFAFA',
//      borderRadius: '12px',
//      boxShadow: '0 4px 12px rgba(0,0,0,0.05)'
//    }}>
//      {/* 1. 标题与控制栏 */}
//      <Box sx={{
//        width: '100%',
//        display: 'flex',
//        justifyContent: 'space-between',
//        alignItems: 'center',
//        mb: 3
//      }}>
//        <Box sx={{ display: 'flex', alignItems: 'center', gap: 3 }}>
//          {/* 晶圆选择下拉框 */}
//          <FormControl size="small" sx={{ minWidth: 140 }}>
//            <InputLabel sx={{ fontSize: '0.875rem' }}>晶圆ID</InputLabel>
//            <Select
//              value={activeWaferId}
//              label="晶圆ID"
//              onChange={(e) => setActiveWaferId(e.target.value)}
//              sx={{
//                '& .MuiSelect-select': { fontSize: '0.875rem' },
//                '& .MuiOutlinedInput-notchedOutline': { borderColor: '#D1D5DB' },
//                '&:hover .MuiOutlinedInput-notchedOutline': { borderColor: '#3B82F6' },
//                '&.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: '#3B82F6' }
//              }}
//            >
//              {getUniqueWaferIds.map(waferId => (
//                <MenuItem key={waferId} value={waferId} sx={{ fontSize: '0.875rem' }}>
//                  {waferId}
//                </MenuItem>
//              ))}
//            </Select>
//          </FormControl>
//
//          {/* 缩放控制 */}
//          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, width: 200 }}>
//            <Typography variant="caption" sx={{ color: '#6B7280' }}>
//              缩放: {zoomRatio}%
//            </Typography>
//            <Slider
//              value={zoomRatio}
//              min={50}
//              max={200}
//              step={10}
//              onChange={(_, value) => setZoomRatio(value)}
//              sx={{
//                '& .MuiSlider-thumb': { width: 16, height: 16 },
//                '& .MuiSlider-track': { backgroundColor: '#3B82F6' },
//                '& .MuiSlider-rail': { backgroundColor: '#E5E7EB' }
//              }}
//            />
//          </Box>
//        </Box>
//      </Box>
//
//      {/* 2. 晶圆可视化区域 */}
//      <Box sx={{
//        position: 'relative',
//        width: actualWaferSize + 40, // 含边距
//        height: actualWaferSize + 40,
//        display: 'flex',
//        justifyContent: 'center',
//        alignItems: 'center',
//        backgroundColor: '#FFFFFF',
//        borderRadius: '8px',
//        padding: 2,
//        boxShadow: '0 2px 8px rgba(0,0,0,0.05)'
//      }}>
//        {/* 晶圆边界 */}
//        <WaferBoundary size={actualWaferSize} />
//
//        {/* 中心十字线 */}
//        <WaferCenterLine isVertical={true} size={actualWaferSize} />
//        <WaferCenterLine isVertical={false} size={actualWaferSize} />
//
//        {/* 定位平边 */}
//        <WaferFlatZone size={actualWaferSize} />
//
//        {/* 晶圆芯片（核心内容） */}
//        {renderWaferChips()}
//
//        {/* 坐标标签 */}
//        <Box sx={{
//          position: 'absolute',
//          bottom: 0,
//          left: 0,
//          right: 0,
//          display: 'flex',
//          justifyContent: 'space-between',
//          padding: '0 10px'
//        }}>
//          <Typography variant="caption" sx={{ color: '#9CA3AF' }}>
//            X: {dataStats.coordinates.x.min.toFixed(1)}
//          </Typography>
//          <Typography variant="caption" sx={{ color: '#9CA3AF' }}>
//            X: {dataStats.coordinates.x.max.toFixed(1)}
//          </Typography>
//        </Box>
//        <Box sx={{
//          position: 'absolute',
//          top: 0,
//          bottom: 0,
//          left: 0,
//          display: 'flex',
//          flexDirection: 'column',
//          justifyContent: 'space-between',
//          padding: '10px 0'
//        }}>
//          <Typography variant="caption" sx={{ color: '#9CA3AF', transform: 'rotate(-90deg) translateX(-50%)' }}>
//            Y: {dataStats.coordinates.y.max.toFixed(1)}
//                    </Typography>
//          <Typography variant="caption" sx={{ color: '#9CA3AF', transform: 'rotate(-90deg) translateX(-50%)' }}>
//            Y: {dataStats.coordinates.y.min.toFixed(1)}
//          </Typography>
//        </Box>
//
//        {/* 当前晶圆ID标记 */}
//        <Box sx={{
//          position: 'absolute',
//          top: 10,
//          right: 10,
//          backgroundColor: 'rgba(59, 130, 246, 0.8)',
//          color: '#FFFFFF',
//          padding: '2px 8px',
//          borderRadius: '4px',
//          zIndex: 10
//        }}>
//          <Typography variant="caption" fontWeight="bold">
//            {activeWaferId}
//          </Typography>
//        </Box>
//      </Box>
//
//      {/* 3. 数据辅助面板（图例+统计） */}
//      <Box sx={{
//        width: '100%',
//        maxWidth: 600,
//        display: 'flex',
//        flexDirection: 'column',
//        gap: 2,
//        mt: 4
//      }}>
//        {/* 测试值图例 */}
//        {renderMeasurementLegend()}
//
//        {/* 缺陷类型图例 */}
//        {renderDefectLegend()}
//
//        {/* 统计信息 */}
//        {renderWaferStats()}
//      </Box>
//
//      {/* 4. 悬停芯片详情面板（固定位置展示） */}
//      {hoveredChip && (
//        <Box sx={{
//          position: 'fixed',
//          bottom: 20,
//          right: 20,
//          width: 300,
//          backgroundColor: '#FFFFFF',
//          borderRadius: '8px',
//          border: '1px solid #E5E7EB',
//          boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
//          padding: 2,
//          zIndex: 50
//        }}>
//          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1 }}>
//            <Typography variant="subtitle2" fontWeight="bold" sx={{ color: '#1F2937' }}>
//              芯片实时详情
//            </Typography>
//            <Box
//              sx={{
//                width: 16,
//                height: 16,
//                borderRadius: '50%',
//                backgroundColor: '#F3F4F6',
//                display: 'flex',
//                justifyContent: 'center',
//                alignItems: 'center',
//                cursor: 'pointer'
//              }}
//              onClick={() => setHoveredChip(null)}
//            >
//              <Typography variant="caption" sx={{ color: '#9CA3AF' }}>×</Typography>
//            </Box>
//          </Box>
//          <Divider sx={{ mb: 1.5, opacity: 0.5 }} />
//
//          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
//            <DetailItem
//              label="晶圆ID"
//              value={hoveredChip.chip.waferId}
//              icon={<Box sx={{ width: 12, height: 12, borderRadius: '2px', backgroundColor: '#E5E7EB' }} />}
//            />
//            <DetailItem
//              label="坐标位置"
//              value={`(${hoveredChip.chip.x.toFixed(1)}, ${hoveredChip.chip.y.toFixed(1)})`}
//              icon={<Box sx={{ width: 12, height: 12, borderRadius: '50%', backgroundColor: '#E5E7EB' }} />}
//            />
//            <DetailItem
//              label="测试数值"
//              value={hoveredChip.chip.measurement.toFixed(2)}
//              icon={<Box sx={{ width: 12, height: 12, borderRadius: '2px', backgroundColor: getJetColor(hoveredChip.chip.measurement) }} />}
//            />
//            <DetailItem
//              label="缺陷类型"
//              value={getDefectConfig(hoveredChip.chip.defectType).name}
//              icon={<Box
//                sx={{
//                  width: 12,
//                  height: 12,
//                  ...(getDefectConfig(hoveredChip.chip.defectType).marker === 'circle' ? { borderRadius: '50%' } :
//                      getDefectConfig(hoveredChip.chip.defectType).marker === 'square' ? { borderRadius: '2px' } :
//                      getDefectConfig(hoveredChip.chip.defectType).marker === 'triangle' ? { clipPath: 'polygon(50% 0%, 0% 100%, 100% 100%)' } :
//                      { clipPath: 'polygon(50% 0%, 100% 50%, 50% 100%, 0% 50%)' }),
//                  backgroundColor: getDefectConfig(hoveredChip.chip.defectType).color
//                }}
//              />}
//            />
//            <DetailItem
//              label="严重程度"
//              value={getDefectConfig(hoveredChip.chip.defectType).severity}
//              icon={<Box sx={{ width: 12, height: 12, borderRadius: '2px', backgroundColor:
//                getDefectConfig(hoveredChip.chip.defectType).severity === '低' ? '#D1FAE5' :
//                getDefectConfig(hoveredChip.chip.defectType).severity === '中' ? '#FEF3C7' :
//                getDefectConfig(hoveredChip.chip.defectType).severity === '高' ? '#FEE2E2' : '#F0ABFC'
//              }} />}
//            />
//          </Box>
//        </Box>
//      )}
//    </Box>
//  );
//};
//
//// 详情项子组件（复用）
//const DetailItem = ({ label, value, icon }) => (
//  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
//    {icon}
//    <Typography variant="body2" sx={{ color: '#6B7280', flex: 1 }}>
//      {label}
//    </Typography>
//    <Typography variant="body2" sx={{ color: '#1F2937', fontWeight: 500 }}>
//      {value}
//    </Typography>
//  </Box>
//);
//
//export default ProfessionalWaferMap;





//########################################### doubao
//import React, { useMemo, useState, useRef, useEffect, useCallback } from 'react';
//import {
//  Box, Typography, Select, MenuItem, Tooltip, Divider,
//  FormControl, InputLabel, IconButton, useTheme, Paper,
//  Chip, LinearProgress, useMediaQuery,
//} from '@mui/material';
//
//import { HelpOutline as HelpOutlineIcon,} from '@mui/icons-material';
//import ZoomInIcon from '@mui/icons-material/ZoomIn';
//import ZoomOutIcon from '@mui/icons-material/ZoomOut';
//import RefreshIcon from '@mui/icons-material/Refresh';
//import * as d3 from 'd3';
//
//// ==============================
//// SEMI 标准配置（视觉升级）
//// ==============================
//const SEMICON_STANDARD_CONFIG = {
//  dieStatus: [
//    { id: 0, name: "合格芯片", color: "#22C55E", bgColor: "#ECFDF5", description: "电学参数、物理外观均符合标准", icon: "✅" },
//    { id: 1, name: "电气缺陷", color: "#F59E0B", bgColor: "#FFFBEB", description: "电压/电流参数超出规格范围", icon: "⚡" },
//    { id: 2, name: "物理缺陷", color: "#EF4444", bgColor: "#FEE2E2", description: "表面划痕、崩角、污染等外观问题", icon: "🔍" },
//    { id: 3, name: "功能失效", color: "#3B82F6", bgColor: "#DBEAFE", description: "芯片完全无法正常工作", icon: "❌" },
//    { id: 4, name: "跳过芯片", color: "#D946EF", bgColor: "#FCE7F3", description: "测试过程中跳过的芯片", icon: "⏭️" },
//    { id: 5, name: "标记芯片", color: "#FFFF00", bgColor: "#FEF3C7", description: "需要特殊关注或处理的芯片", icon: "⭐" },
//    { id: 6, name: "空芯片", color: "#9CA3AF", bgColor: "#F3F4F6", description: "晶圆上无芯片的位置", icon: "⬜" },
//  ],
//  waferStyle: {
//    background: "linear-gradient(145deg, #F9FAFB, #F3F4F6)",
//    border: "#D1D5DB",
//    borderWidth: 1.5,
//    gridLine: "rgba(229, 231, 235, 0.6)",
//    flatZone: "#4B5563",
//    flatZoneHeight: 5,
//    shadow: "0 8px 30px rgba(0, 0, 0, 0.05)",
//  },
//  interaction: {
//    zoomStep: 0.1,
//    zoomMin: 0.3,
//    zoomMax: 5,
//    hoverScale: 1.2,
//    hoverShadow: "0 0 8px rgba(0, 0, 0, 0.2)",
//    tooltipDelay: 100,
//  },
//};
//
//// ==============================
//// 主组件（保留原字段逻辑，优化体验）
//// ==============================
//export default function ProfessionalWaferMap({ data = [], size = 600, block, sampledData }) {
//  const svgRef = useRef(null);
//  const theme = useTheme();
//  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
//
//  // 状态管理
//  const [activeWaferId, setActiveWaferId] = useState('');
//  const [zoomLevel, setZoomLevel] = useState(1);
//  const [transform, setTransform] = useState(d3.zoomIdentity);
//  const [hoveredDie, setHoveredDie] = useState(null);
//  const [isPanning, setIsPanning] = useState(false);
//  const [lastPanPos, setLastPanPos] = useState({ x: 0, y: 0 });
//  const [isLoading, setIsLoading] = useState(false);
//
//  // ==============================
//  // 1. 数据处理（保留原字段映射）
//  // ==============================
//  const processedData = useMemo(() => {
//    if (!sampledData?.length || !block?.config) return [];
//
//    // 保留原有字段配置逻辑
//    const {
//      waferIdField,
//      waferXField,
//      waferYField,
//      waferValueField,
//      defectTypeField
//    } = block.config;
//
//    return sampledData
//      .filter(item => {
//        const x = item[waferXField];
//        const y = item[waferYField];
//        const value = item[waferValueField];
//        const defectType = item[defectTypeField];
//        const waferId = item[waferIdField];
//
//        return (
//          typeof x !== 'undefined' && x != null && !isNaN(Number(x)) &&
//          typeof y !== 'undefined' && y != null && !isNaN(Number(y)) &&
//          typeof value !== 'undefined' && value != null && !isNaN(Number(value)) &&
//          typeof defectType !== 'undefined' && defectType != null && !isNaN(Number(defectType)) &&
//          typeof waferId !== 'undefined' && waferId != null
//        );
//      })
//      .map(item => ({
//        waferId: item[waferIdField],
//        x: Number(item[waferXField]),
//        y: Number(item[waferYField]),
//        measurement: Number(item[waferValueField]),
//        defectType: Number(item[defectTypeField]),
//        rawData: item
//      }));
//  }, [sampledData, block]);
//
//  // 当前 wafer 数据
//  const waferData = useMemo(() => {
//    if (!activeWaferId && processedData.length > 0) {
//      const uniqueIds = [...new Set(processedData.map(d => d.waferId))];
//      setTimeout(() => setActiveWaferId(uniqueIds[0]), 0);
//      return processedData.filter(d => d.waferId === uniqueIds[0]);
//    }
//    return processedData.filter(d => d.waferId === activeWaferId);
//  }, [processedData, activeWaferId]);
//
//  // ==============================
//  // 2. 动态计算（修复显示问题核心）
//  // ==============================
//  const { gridSize, radius, center, dieSize, xMin, xMax, yMin, yMax } = useMemo(() => {
//    if (waferData.length === 0) {
//      return {
//        gridSize: 20,
//        radius: size / 2 - 20,
//        center: size / 2,
//        dieSize: isMobile ? 12 : 18,
//        xMin: -2, xMax: 2, yMin: -2, yMax: 2
//      };
//    }
//
//    const xValues = waferData.map(d => d.x);
//    const yValues = waferData.map(d => d.y);
//
//    // 计算真实数据范围，修复仅显示一个点的问题
//    const xMin = Math.min(...xValues);
//    const xMax = Math.max(...xValues);
//    const yMin = Math.min(...yValues);
//    const yMax = Math.max(...yValues);
//
//    // 增加10%边距，避免芯片贴边
//    const xRange = xMax - xMin;
//    const yRange = yMax - yMin;
//    const maxRange = Math.max(xRange, yRange) * 1.1;
//
//    // 基于数据范围计算网格大小
//    const availableSize = size * 0.8;
//    const gridSize = availableSize / (maxRange || 4);
//    const dieSize = Math.max(isMobile ? 8 : 6, Math.min(22, gridSize * 0.8));
//
//    return {
//      gridSize,
//      dieSize,
//      radius: availableSize / 2,
//      center: size / 2,
//      xMin, xMax, yMin, yMax
//    };
//  }, [waferData, size, isMobile]);
//
//  // ==============================
//  // 3. 交互逻辑（增强体验）
//  // ==============================
//  useEffect(() => {
//    if (!svgRef.current || waferData.length === 0) return;
//
//    const svg = d3.select(svgRef.current);
//    const zoom = d3.zoom()
//      .scaleExtent([SEMICON_STANDARD_CONFIG.interaction.zoomMin, SEMICON_STANDARD_CONFIG.interaction.zoomMax])
//      .on('zoom', (event) => {
//        setTransform(event.transform);
//      });
//
//    svg.call(zoom);
//
//    return () => {
//      svg.on('.zoom', null);
//    };
//  }, [waferData]);
//
//  const handleZoom = useCallback((direction) => {
//    setZoomLevel(prev => {
//      const step = SEMICON_STANDARD_CONFIG.interaction.zoomStep;
//      return direction === 'in'
//        ? Math.min(prev + step, SEMICON_STANDARD_CONFIG.interaction.zoomMax)
//        : Math.max(prev - step, SEMICON_STANDARD_CONFIG.interaction.zoomMin);
//    });
//  }, []);
//
//  const handlePanStart = useCallback((e) => {
//    setIsPanning(true);
//    setLastPanPos({ x: e.clientX, y: e.clientY });
//  }, []);
//
//  const handlePanMove = useCallback((e) => {
//    if (!isPanning) return;
//    const deltaX = e.clientX - lastPanPos.x;
//    const deltaY = e.clientY - lastPanPos.y;
//    setTransform(prev => prev.translate(deltaX / zoomLevel, deltaY / zoomLevel));
//    setLastPanPos({ x: e.clientX, y: e.clientY });
//  }, [isPanning, lastPanPos, zoomLevel]);
//
//  const handlePanEnd = useCallback(() => {
//    setIsPanning(false);
//  }, []);
//
//  const resetView = useCallback(() => {
//    setZoomLevel(1);
//    setTransform(d3.zoomIdentity);
//    setHoveredDie(null);
//    setIsLoading(true);
//    setTimeout(() => setIsLoading(false), 300);
//  }, []);
//
//  // ==============================
//  // 4. 辅助逻辑
//  // ==============================
//  const getDieConfig = useCallback((id) => {
//    return SEMICON_STANDARD_CONFIG.dieStatus.find((t) => t.id === id) ||
//      SEMICON_STANDARD_CONFIG.dieStatus[6];
//  }, []);
//
//  const stats = useMemo(() => {
//    if (waferData.length === 0) {
//      return {
//        total: 0, good: 0, yield: 0, defectCount: {},
//        defectRatio: {}, measurement: { min: 0, max: 0, avg: 0 }
//      };
//    }
//
//    const defectCount = waferData.reduce((acc, die) => {
//      acc[die.defectType] = (acc[die.defectType] || 0) + 1;
//      return acc;
//    }, {});
//
//    const defectRatio = Object.keys(defectCount).reduce((acc, type) => {
//      acc[type] = ((defectCount[type] / waferData.length) * 100).toFixed(1);
//      return acc;
//    }, {});
//
//    const measurements = waferData.map(d => d.measurement);
//    const measurementStats = {
//      min: Math.min(...measurements).toFixed(2),
//      max: Math.max(...measurements).toFixed(2),
//      avg: (measurements.reduce((sum, val) => sum + val, 0) / measurements.length).toFixed(2)
//    };
//
//    const goodCount = defectCount[0] || 0;
//    const totalCount = waferData.length;
//    const yieldRate = (goodCount / totalCount) * 100;
//
//    return {
//      total: totalCount,
//      good: goodCount,
//      yield: yieldRate.toFixed(2),
//      defectCount,
//      defectRatio,
//      measurement: measurementStats
//    };
//  }, [waferData]);
//
//  // ==============================
//  // 5. 渲染组件
//  // ==============================
//  const renderGridLines = useMemo(() => {
//    if (waferData.length === 0) return null;
//
//    const lines = [];
//    const gridCount = 10;
//
//    // 垂直网格线
//    for (let x = xMin; x <= xMax; x += (xMax - xMin) / gridCount) {
//      const pixelX = center + (x * gridSize);
//      if (Math.abs(pixelX - center) > radius) continue;
//      lines.push(
//        <line
//          key={`v-line-${x}`}
//          x1={pixelX}
//          y1={center - radius}
//          x2={pixelX}
//          y2={center + radius}
//          stroke={SEMICON_STANDARD_CONFIG.waferStyle.gridLine}
//          strokeWidth={0.8}
//          strokeDasharray="2,2"
//        />
//      );
//    }
//
//    // 水平网格线
//    for (let y = yMin; y <= yMax; y += (yMax - yMin) / gridCount) {
//      const pixelY = center - (y * gridSize);
//      if (Math.abs(pixelY - center) > radius) continue;
//      lines.push(
//        <line
//          key={`h-line-${y}`}
//          x1={center - radius}
//          y1={pixelY}
//          x2={center + radius}
//          y2={pixelY}
//          stroke={SEMICON_STANDARD_CONFIG.waferStyle.gridLine}
//          strokeWidth={0.8}
//          strokeDasharray="2,2"
//        />
//      );
//    }
//
//    // 中心十字线
//    lines.push(
//      <line
//        key="center-x"
//        x1={center}
//        y1={center - radius}
//        x2={center}
//        y2={center + radius}
//        stroke={SEMICON_STANDARD_CONFIG.waferStyle.gridLine}
//        strokeWidth={1}
//        strokeDasharray="4,4"
//      />,
//      <line
//        key="center-y"
//        x1={center - radius}
//        y1={center}
//        x2={center + radius}
//        y2={center}
//        stroke={SEMICON_STANDARD_CONFIG.waferStyle.gridLine}
//        strokeWidth={1}
//        strokeDasharray="4,4"
//      />
//    );
//
//    return lines;
//  }, [waferData, center, gridSize, radius, xMin, xMax, yMin, yMax]);
//
//  const renderLegend = () => (
//    <Paper elevation={2} sx={{ p: 2, borderRadius: 1.5, mb: 2, backgroundColor: 'white' }}>
//      <Box display="flex" alignItems="center" mb={2}>
//        <HelpOutlineIcon sx={{ color: theme.palette.primary.main, mr: 1, fontSize: 18 }} />
//        <Typography variant="h6" sx={{ fontSize: '1rem', fontWeight: 600 }}>
//          芯片状态图例
//        </Typography>
//      </Box>
//      <Box sx={{ display: "grid", gridTemplateColumns: "1fr", gap: 1.5 }}>
//        {SEMICON_STANDARD_CONFIG.dieStatus.map((status) => {
//          const count = stats.defectCount[status.id] || 0;
//          const ratio = stats.defectRatio[status.id] || "0.0";
//          return (
//            <Box key={status.id} sx={{ display: "flex", alignItems: "center" }}>
//              <Box
//                sx={{
//                  width: 16,
//                  height: 16,
//                  backgroundColor: status.color,
//                  borderRadius: 0.5,
//                  mr: 1.5,
//                  flexShrink: 0,
//                }}
//              />
//              <Box sx={{ flexGrow: 1 }}>
//                <Box display="flex" justifyContent="space-between">
//                  <Typography variant="body2" fontWeight="medium">
//                    {status.name}
//                  </Typography>
//                  <Typography variant="body2" color="#6B7280">
//                    {count} ({ratio}%)
//                  </Typography>
//                </Box>
//                <Typography variant="caption" color="#9CA3AF" sx={{ fontSize: "0.75rem" }}>
//                  {status.description}
//                </Typography>
//              </Box>
//            </Box>
//          );
//        })}
//      </Box>
//    </Paper>
//  );
//
//  const renderStats = () => (
//    <Paper elevation={2} sx={{ p: 2, borderRadius: 1.5, backgroundColor: 'white' }}>
//      <Box display="flex" alignItems="center" mb={2}>
//        <Box sx={{
//          width: 20,
//          height: 20,
//          backgroundColor: theme.palette.primary.light,
//          borderRadius: "50%",
//          display: "flex",
//          alignItems: "center",
//          justifyContent: "center",
//          color: "#fff",
//          mr: 1,
//        }}>
//          📊
//        </Box>
//        <Typography variant="h6" sx={{ fontSize: "1rem", fontWeight: 600 }}>
//          晶圆统计信息
//        </Typography>
//      </Box>
//
//      <Box sx={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 1.5, mb: 2 }}>
//        <StatItem label="总芯片数" value={stats.total} icon="🔢" />
//        <StatItem label="合格芯片" value={stats.good} icon="✅" color="#22C55E" />
//        <StatItem label="测试值最小" value={stats.measurement.min} icon="📉" />
//        <StatItem label="测试值最大" value={stats.measurement.max} icon="📈" />
//        <StatItem label="测试值平均" value={stats.measurement.avg} icon="📊" />
//        <StatItem label="良率" value={`${stats.yield}%`} icon="🎯"
//                  color={stats.yield > 90 ? "#22C55E" : "#EF4444"} />
//      </Box>
//
//      {/* 良率进度条 */}
//      <Box sx={{ mb: 1 }}>
//        <Box display="flex" justifyContent="space-between" mb={0.5}>
//          <Typography variant="body2" color="#6B7280">
//            良率进度
//          </Typography>
//          <Typography variant="body2" fontWeight="medium">
//            {stats.yield}%
//          </Typography>
//        </Box>
//        <LinearProgress
//          variant="determinate"
//          value={Number(stats.yield)}
//          sx={{
//            height: 8,
//            borderRadius: 4,
//            backgroundColor: "#F3F4F6",
//            "& .MuiLinearProgress-bar": {
//              backgroundColor: stats.yield > 90 ? "#22C55E" : stats.yield > 70 ? "#F59E0B" : "#EF4444",
//            },
//          }}
//        />
//      </Box>
//    </Paper>
//  );
//
//  const StatItem = ({ label, value, icon, color = "#1F2937" }) => (
//    <Box sx={{
//      p: 1.2,
//      backgroundColor: "#F9FAFB",
//      borderRadius: 1,
//      display: "flex",
//      alignItems: "center",
//    }}>
//      <Box sx={{
//        width: 24,
//        height: 24,
//        borderRadius: "50%",
//        backgroundColor: "#F3F4F6",
//        display: "flex",
//        alignItems: "center",
//        justifyContent: "center",
//        mr: 1.5,
//        color: color,
//      }}>
//        {icon}
//      </Box>
//      <Box>
//        <Typography variant="caption" color="#9CA3AF">
//          {label}
//        </Typography>
//        <Typography variant="body2" fontWeight="medium" sx={{ color: color }}>
//          {value}
//        </Typography>
//      </Box>
//    </Box>
//  );
//
//  if (processedData.length === 0) {
//    return (
//      <Box
//        display="flex"
//        flexDirection="column"
//        justifyContent="center"
//        alignItems="center"
//        minHeight={500}
//        p={4}
//        backgroundColor="#F9FAFB"
//        borderRadius={2}
//      >
//        <Box sx={{
//          width: 80,
//          height: 80,
//          borderRadius: "50%",
//          backgroundColor: "#F3F4F6",
//          display: "flex",
//          alignItems: "center",
//          justifyContent: "center",
//          mb: 3,
//          color: "#9CA3AF",
//          fontSize: "2rem",
//        }}>
//          📁
//        </Box>
//        <Typography variant="h6" color="#6B7280" mb={1}>
//          无有效晶圆数据
//        </Typography>
//        <Typography variant="body2" color="#9CA3AF" textAlign="center" maxWidth={400}>
//          请检查传入数据格式是否符合要求
//        </Typography>
//      </Box>
//    );
//  }
//
//  return (
//    <Box sx={{
//      p: isMobile ? 2 : 3,
//      display: "flex",
//      flexDirection: isMobile ? "column" : "row",
//      gap: isMobile ? 2 : 3,
//      minHeight: isMobile ? "auto" : 600,
//      backgroundColor: "#FAFAFA",
//      borderRadius: 2,
//    }}>
//      {/* 左侧控制面板 */}
//      <Box sx={{
//        width: isMobile ? "100%" : 300,
//        display: "flex",
//        flexDirection: "column",
//      }}>
//        <FormControl fullWidth sx={{ mb: 2, minWidth: 200 }}>
//          <InputLabel
//            sx={{
//              fontSize: "0.85rem",
//              color: "#6B7280",
//              "&.Mui-focused": { color: theme.palette.primary.main },
//            }}
//          >
//            晶圆ID
//          </InputLabel>
//          <Select
//            value={activeWaferId}
//            label="晶圆ID"
//            onChange={(e) => {
//              setActiveWaferId(e.target.value);
//              resetView();
//            }}
//            sx={{
//              "& .MuiSelect-select": { fontSize: "0.9rem", py: 1.2 },
//              "& .MuiOutlinedInput-notchedOutline": { borderColor: "#E5E7EB" },
//              "&:hover .MuiOutlinedInput-notchedOutline": { borderColor: theme.palette.primary.main },
//            }}
//          >
//            {[...new Set(processedData.map(d => d.waferId))].map(id => (
//              <MenuItem key={id} value={id} sx={{ fontSize: "0.85rem" }}>
//                Wafer {id}
//              </MenuItem>
//            ))}
//          </Select>
//        </FormControl>
//
//        <Paper elevation={1} sx={{
//          p: 1.2,
//          borderRadius: 1,
//          display: "flex",
//          alignItems: "center",
//          justifyContent: "space-between",
//          mb: 2,
//        }}>
//          <Typography variant="body2" fontWeight="medium">
//            视图控制
//          </Typography>
//          <Box display="flex" alignItems="center" gap={1}>
//            <IconButton
//              size="small"
//              onClick={() => handleZoom("out")}
//              sx={{ color: "#6B7280", "&:hover": { color: theme.palette.primary.main } }}
//              title="缩小"
//            >
//              <ZoomOutIcon fontSize="small" />
//            </IconButton>
//            <Typography variant="caption" sx={{ minWidth: 40, textAlign: "center" }}>
//              {(zoomLevel * 100).toFixed(0)}%
//            </Typography>
//            <IconButton
//              size="small"
//              onClick={() => handleZoom("in")}
//              sx={{ color: "#6B7280", "&:hover": { color: theme.palette.primary.main } }}
//              title="放大"
//            >
//              <ZoomInIcon fontSize="small" />
//            </IconButton>
//            <Divider orientation="vertical" flexItem sx={{ mx: 0.5 }} />
//            <IconButton
//              size="small"
//              onClick={resetView}
//              sx={{ color: "#6B7280", "&:hover": { color: theme.palette.primary.main } }}
//              title="重置视图"
//            >
//              <RefreshIcon fontSize="small" />
//            </IconButton>
//          </Box>
//        </Paper>
//
//        {renderLegend()}
//        {renderStats()}
//      </Box>
//
//      {/* Wafer 渲染区域 */}
//      <Box sx={{ flex: 1, display: 'flex', justifyContent: 'center' }}>
//        <Box sx={{ position: 'relative' }}>
//          {/* 加载状态 */}
//          {isLoading && (
//            <Box
//              sx={{
//                position: "absolute",
//                top: 0,
//                left: 0,
//                right: 0,
//                bottom: 0,
//                backgroundColor: "rgba(255, 255, 255, 0.8)",
//                display: "flex",
//                justifyContent: "center",
//                alignItems: "center",
//                zIndex: 50,
//                borderRadius: "50%",
//              }}
//            >
//              <Box sx={{
//                width: 40,
//                height: 40,
//                border: "4px solid #E5E7EB",
//                borderTopColor: theme.palette.primary.main,
//                borderRadius: "50%",
//                animation: "spin 1s linear infinite",
//              }} />
//            </Box>
//          )}
//
//          <svg
//            ref={svgRef}
//            width={size}
//            height={size}
//            style={{
//              transform: `scale(${zoomLevel})`,
//              transformOrigin: 'center center',
//              cursor: isPanning ? "grabbing" : "grab",
//              transition: isPanning ? "none" : "transform 0.2s ease",
//            }}
//            onMouseDown={handlePanStart}
//            onMouseMove={handlePanMove}
//            onMouseUp={handlePanEnd}
//            onMouseLeave={handlePanEnd}
//          >
//            <g transform={transform}>
//              {/* 晶圆背景 */}
//              <circle
//                cx={center}
//                cy={center}
//                r={radius}
//                fill={SEMICON_STANDARD_CONFIG.waferStyle.background}
//                stroke={SEMICON_STANDARD_CONFIG.waferStyle.border}
//                strokeWidth={SEMICON_STANDARD_CONFIG.waferStyle.borderWidth}
//                style={{ filter: `drop-shadow(${SEMICON_STANDARD_CONFIG.waferStyle.shadow})` }}
//              />
//
//              {/* 平边 */}
//              <rect
//                x={center - radius * 0.125}
//                y={center + radius - SEMICON_STANDARD_CONFIG.waferStyle.flatZoneHeight}
//                width={radius * 0.25}
//                height={SEMICON_STANDARD_CONFIG.waferStyle.flatZoneHeight}
//                fill={SEMICON_STANDARD_CONFIG.waferStyle.flatZone}
//                rx={1}
//              />
//
//              {/* 网格线 */}
//              {renderGridLines}
//
//              {/* 芯片 */}
//              {waferData.map((die, index) => {
//                const dieCfg = getDieConfig(die.defectType);
//                const cx = center + die.x * gridSize;
//                const cy = center - die.y * gridSize;
//
//                // 判断是否在晶圆内
//                const distanceFromCenter = Math.sqrt(
//                  Math.pow(cx - center, 2) + Math.pow(cy - center, 2)
//                );
//                if (distanceFromCenter > radius - dieSize / 2) return null;
//
//                return (
//                  <Tooltip
//                    key={index}
//                    title={
//                      <Paper elevation={3} sx={{ p: 1.5, width: 280, borderRadius: 1.5 }}>
//                        <Box display="flex" alignItems="center" mb={1}>
//                          <Box sx={{
//                            mr: 1.5,
//                            width: 18,
//                            height: 18,
//                            backgroundColor: dieCfg.color,
//                            borderRadius: 0.5,
//                            display: "flex",
//                            alignItems: "center",
//                            justifyContent: "center",
//                            color: "#fff",
//                            fontSize: "0.7rem",
//                          }}>
//                            {dieCfg.icon}
//                          </Box>
//                          <Typography variant="subtitle2" fontWeight="bold">
//                            芯片详情
//                          </Typography>
//                        </Box>
//                        <Divider sx={{ my: 1, opacity: 0.6 }} />
//                        <Box sx={{ fontSize: "0.85rem", color: "#4B5563" }}>
//                          <Box display="flex" justifyContent="space-between" mb={0.5}>
//                            <span>晶圆ID：</span>
//                            <Typography variant="body2" fontWeight="medium">
//                              {die.waferId}
//                            </Typography>
//                          </Box>
//                          <Box display="flex" justifyContent="space-between" mb={0.5}>
//                            <span>物理坐标：</span>
//                            <Typography variant="body2" fontWeight="medium">
//                              ({die.x}, {die.y})
//                            </Typography>
//                          </Box>
//                          <Box display="flex" justifyContent="space-between" mb={0.5}>
//                            <span>测试值：</span>
//                            <Typography variant="body2" fontWeight="medium">
//                              {die.measurement.toFixed(2)}
//                            </Typography>
//                          </Box>
//                          <Box display="flex" justifyContent="space-between">
//                            <span>芯片状态：</span>
//                            <Chip
//                              size="small"
//                              label={dieCfg.name}
//                              sx={{
//                                backgroundColor: dieCfg.bgColor,
//                                color: dieCfg.color,
//                                fontWeight: "medium",
//                              }}
//                            />
//                          </Box>
//                        </Box>
//                      </Paper>
//                    }
//                    placement="top"
//                    arrow
//                    enterDelay={SEMICON_STANDARD_CONFIG.interaction.tooltipDelay}
//                    sx={{ zIndex: 100 }}
//                  >
//                    <rect
//                      x={cx - dieSize / 2}
//                      y={cy - dieSize / 2}
//                      width={dieSize}
//                      height={dieSize}
//                      fill={dieCfg.color}
//                      stroke="#F3F4F6"
//                      strokeWidth={hoveredDie?.index === index ? 1.5 : 0.8}
//                      rx={hoveredDie?.index === index ? 2 : 1.5}
//                      ry={hoveredDie?.index === index ? 2 : 1.5}
//                      onMouseEnter={() => setHoveredDie({ index, die })}
//                      onMouseLeave={() => setHoveredDie(null)}
//                      style={{
//                        transition: "all 0.2s cubic-bezier(0.4, 0, 0.2, 1)",
//                        transform: hoveredDie?.index === index
//                          ? `scale(${SEMICON_STANDARD_CONFIG.interaction.hoverScale})`
//                          : "scale(1)",
//                        filter: hoveredDie?.index === index
//                          ? `drop-shadow(${SEMICON_STANDARD_CONFIG.interaction.hoverShadow})`
//                          : "none",
//                        cursor: "pointer",
//                      }}
//                    />
//                  </Tooltip>
//                );
//              })}
//            </g>
//          </svg>
//
//          {/* 当前晶圆ID显示 */}
//          <Box
//            sx={{
//              position: 'absolute',
//              top: 10,
//              right: 10,
//              backgroundColor: 'rgba(255, 255, 255, 0.9)',
//              padding: '4px 12px',
//              borderRadius: 2,
//              border: '1px solid #ddd',
//              boxShadow: '0 2px 8px rgba(0, 0, 0, 0.08)',
//            }}
//          >
//            <Typography variant="body2" fontWeight="medium">
//              Wafer {activeWaferId}
//            </Typography>
//          </Box>
//        </Box>
//      </Box>
//    </Box>
//  );
//}
