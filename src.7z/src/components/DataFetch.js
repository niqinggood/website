import React, { useState, useEffect } from 'react';
import {
  Grid, Select, MenuItem, Table, TableBody, TableCell, TableContainer,
  TableHead, TableRow, Paper, Typography, Button, Link, Box,
  CircularProgress, IconButton, Badge, Tooltip, Collapse
} from '@mui/material';
import DownloadIcon from '@mui/icons-material/Download';
import RefreshIcon from '@mui/icons-material/Refresh';

// 任务状态颜色映射
const statusColors = {
  pending: 'text.secondary',
  processing: 'info.main',
  success: 'success.main',
  failed: 'error.main'
};

// 状态文本映射
const statusTexts = {
  pending: '等待中',
  processing: '处理中',
  success: '成功',
  failed: '失败'
};

const TaskDetails = ({ task }) => {
  if (!task) return null;

  // 安全解析日期配置
  const dates = typeof task.dates === 'string' ? JSON.parse(task.dates) : task.dates || {};

  return (
    <Paper sx={{ p: 2, mt: 1 }}>
      <Typography variant="subtitle1" gutterBottom>
        <strong>配置名称:</strong> {task.projectName}
      </Typography>

      <Grid container spacing={2}>
        <Grid item xs={6}>
          <Typography><strong>时间范围:</strong> {task.timeRange}</Typography>
          {task.timeRange === 'single' ? (
            <Typography>
              {dates.startDate} 至 {dates.endDate}
            </Typography>
          ) : (
            <>
              <Typography><strong>训练周期:</strong></Typography>
              <Typography>
                {dates.trainStartDate} - {dates.trainEndDate}
              </Typography>
              <Typography><strong>评估周期:</strong></Typography>
              <Typography>
                {dates.evalStartDate} - {dates.evalEndDate}
              </Typography>
            </>
          )}
        </Grid>

        <Grid item xs={6}>
          <Typography><strong>布局配置:</strong></Typography>
          <Typography variant="body2" sx={{ whiteSpace: 'pre-wrap' }}>
            {task.layoutConfig}
          </Typography>
        </Grid>
      </Grid>

      {task.status === 'success' && task.downloadInfo && (
        <Box sx={{ mt: 2 }}>
          <Typography variant="subtitle1"><strong>下载信息:</strong></Typography>
          <pre style={{ overflowX: 'auto' }}>
            {JSON.stringify(JSON.parse(task.downloadInfo), null, 2)}
          </pre>
        </Box>
      )}

      {task.statusDetails && (
        <Typography sx={{ mt: 2 }}>
          <strong>详情:</strong> {task.statusDetails}
        </Typography>
      )}
    </Paper>
  );
};

const DataFetch = ( { configName } ) => {
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(false);
  const [selectedLayout, setSelectedLayout] = useState('default');
  const [expandedTask, setExpandedTask] = useState(null); // 存储展开的任务ID

  // 加载历史数据
  const fetchHistory = async () => {
    setLoading(true);
    try {
       const response = await fetch(`/api/fetch-history?configName=${encodeURIComponent(configName)}`);
      const data = await response.json();
      if (data.success) {
        setHistory(data.tasks);
      }
    } catch (error) {
      console.error('获取历史记录失败:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchHistory();
  }, []);

  // 刷新历史记录
  const handleRefresh = () => {
    fetchHistory();
  };

  // 触发新的取数请求
  const handleFetchData = async () => {
    try {
      const response = await fetch('/api/fetch-data', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          configurations: [],
          layoutConfig: selectedLayout
        })
      });
      const result = await response.json();
      if (result.success) {
        fetchHistory();
      }
    } catch (error) {
      console.error('取数请求失败:', error);
    }
  };

  // 处理下载
  const handleDownload = (task) => {
    try {
      const downloadInfo = JSON.parse(task.downloadInfo);
      console.log('下载任务:', task.id, downloadInfo);
      // 实际下载逻辑
      if (downloadInfo.url) {
        window.open(downloadInfo.url, '_blank');
      }
    } catch (error) {
      console.error('解析下载信息失败:', error);
    }
  };

  // 切换任务详情展开状态
  const toggleTaskDetails = (taskId) => {
    setExpandedTask(expandedTask === taskId ? null : taskId);
  };

  return (
    <Box sx={{ width: '100%', py: 3 }}>
      {/* 布局配置选择器 */}
      <Box sx={{ mb: 3, display: 'flex', alignItems: 'center', gap: 2 }}>
        <Typography variant="subtitle1">当前布局:</Typography>
        <Select
          value={selectedLayout}
          onChange={(e) => setSelectedLayout(e.target.value)}
          sx={{ minWidth: 120, background: 'white' }}
        >
          <MenuItem value="default">默认布局</MenuItem>
          <MenuItem value="advanced">高级布局</MenuItem>
          <MenuItem value="compact">紧凑布局</MenuItem>
        </Select>
        <Button
          variant="contained"
          onClick={handleFetchData}
          sx={{ ml: 2 }}
        >
          触发取数
        </Button>
      </Box>

      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
        <Typography variant="h6" sx={{ fontWeight: 500 }}>
          数据取数历史记录
        </Typography>
        <Tooltip title="刷新记录">
          <IconButton onClick={handleRefresh} color="primary">
            <RefreshIcon />
          </IconButton>
        </Tooltip>
      </Box>

      {loading ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
          <CircularProgress />
        </Box>
      ) : history.length === 0 ? (
        <Typography variant="body1" sx={{ py: 3, textAlign: 'center' }}>
          暂无取数历史
        </Typography>
      ) : (
        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell width="18%">取数时间</TableCell>
                <TableCell width="12%">项目名称</TableCell>
                <TableCell width="12%">布局配置</TableCell>
                <TableCell width="10%">状态</TableCell>
                <TableCell width="25%">详细信息</TableCell>
                <TableCell width="8%">配置数</TableCell>
                <TableCell width="15%">操作</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {history.map((task) => (
                <React.Fragment key={task.id}>
                  <TableRow
                    hover
                    onClick={() => toggleTaskDetails(task.id)}
                    sx={{ cursor: 'pointer' }}
                  >
                    <TableCell>
                      {new Date(task.triggered_at).toLocaleString()}
                      {task.completedAt && (
                        <Typography variant="body2" color="text.secondary">
                          完成: {new Date(task.completedAt).toLocaleTimeString()}
                        </Typography>
                      )}
                    </TableCell>
                    <TableCell>{task.projectName}</TableCell>
                    <TableCell>{task.layoutConfig}</TableCell>
                    <TableCell>
                      <Typography color={statusColors[task.status]}>
                        {statusTexts[task.status] || task.status}
                      </Typography>
                    </TableCell>
                    <TableCell>
                      <Typography variant="body2">{task.statusDetails}</Typography>
                      {task.status === 'failed' && (
                        <Typography variant="body2" color="error">
                          原因: {task.statusDetails}
                        </Typography>
                      )}
                    </TableCell>
                    <TableCell>
                      <Badge
                        badgeContent={task.configuration ? JSON.parse(task.configuration).length : 0}
                        color="primary"
                      />
                    </TableCell>
                    <TableCell>
                      {task.status === 'success' && (
                        <Button
                          variant="outlined"
                          startIcon={<DownloadIcon />}
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDownload(task);
                          }}
                          size="small"
                        >
                          下载
                        </Button>
                      )}
                    </TableCell>
                  </TableRow>

                  {/* 任务详情行 */}
                  {expandedTask === task.id && (
                    <TableRow>
                      <TableCell colSpan={7} sx={{ py: 2, borderTop: 'none' }}>
                        <TaskDetails task={task} />
                      </TableCell>
                    </TableRow>
                  )}
                </React.Fragment>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}
    </Box>
  );
};

export default DataFetch;