import React, { useState } from 'react';
import { 
  Container, Typography, Box, Paper, Grid, Divider, 
  Snackbar, Alert, Tooltip 
} from '@mui/material';
import axios from 'axios';
import { allThemes } from '../themeConfig';

const SkinSelector = ({ currentTheme, onThemeChange }) => {
  const themes = allThemes;
  
  const [notification, setNotification] = useState({
    open: false,
    message: '',
    severity: 'success'
  });

  const handleThemeSelect = (themeId) => {
    onThemeChange(themeId);
    saveThemePreference(themeId);
  };

  const saveThemePreference = async (themeId) => {
    try {
      await axios.post('/api/user-selfconfig', {
        configType: 'theme',
        value: themeId
      }, { withCredentials: true });
      
      setNotification({
        open: true,
        message: '皮肤设置已保存',
        severity: 'success'
      });
    } catch (error) {
      console.error('保存主题设置失败:', error);
      setNotification({
        open: true,
        message: '保存皮肤设置失败',
        severity: 'error'
      });
    }
  };

  const handleCloseNotification = () => {
    setNotification(prev => ({ ...prev, open: false }));
  };

  // 根据主题数量计算最合适的列数，避免末尾出现孤立卡片
  const getGridColumns = () => {
    // 针对不同数量的主题，优化列数分布
    if (themes.length <= 4) return 2;
    if (themes.length <= 6) return 3;
    if (themes.length <= 8) return 4;
    return 5; // 超过8个主题时使用5列布局
  };

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 6 }}>
      <Typography variant="h4" gutterBottom>皮肤设置</Typography>
      
      <Paper sx={{ p: { xs: 2, md: 3 }, borderRadius: 2 }}>
        <Typography variant="h6" gutterBottom>选择您偏好的界面主题</Typography>
        <Divider sx={{ mb: 3 }} />
        
        {/* 优化的网格布局，根据主题数量动态调整列数 */}
        <Grid container spacing={{ xs: 2, sm: 3, md: 4 }}>
          {themes.map((theme, index) => (
            <Grid 
              item 
              xs={6} 
              sm={4} 
              md={12 / getGridColumns()}  // 动态计算每列宽度
              key={theme.id}
              // 最后几个项目的特殊处理，避免单行只有1-2个元素
              sx={{
                // 当最后只剩1项时，让它占半宽
                ...(index === themes.length - 1 && themes.length % getGridColumns() === 1 && {
                  md: 6,
                  display: 'flex',
                  justifyContent: 'center'
                }),
                // 当最后剩2项且总列数>2时，让它们居中显示
                ...(index >= themes.length - 2 && themes.length % getGridColumns() === 2 && getGridColumns() > 2 && {
                  display: 'flex',
                  justifyContent: 'center'
                })
              }}
            >
              <Tooltip 
                title={`${theme.id}`}
                placement="top"
                arrow
              >
                <Paper 
                  sx={{ 
                    p: 2, 
                    textAlign: 'center',
                    width: '100%',
                    maxWidth: 180, // 限制最大宽度，确保一致性
                    border: currentTheme === theme.id ? `2px solid ${theme.color}` : '1px solid #ddd',
                    borderRadius: 2,
                    cursor: 'pointer',
                    transition: 'all 0.3s ease',
                    '&:hover': {
                      boxShadow: 6,
                      transform: 'translateY(-3px)',
                      borderColor: theme.color + '80' // 增加透明度的边框色
                    },
                    '&:active': {
                      transform: 'translateY(-1px)'
                    }
                  }}
                  onClick={() => handleThemeSelect(theme.id)}
                >
                  <Box 
                    sx={{ 
                      width: 36, 
                      height: 36, 
                      borderRadius: '50%', 
                      backgroundColor: theme.color,
                      margin: '0 auto 12px',
                      border: theme.id === 'dark' ? '1px solid #fff' : 'none',
                      boxShadow: `0 0 0 3px ${theme.color}20` // 浅色光晕效果
                    }}
                  />
                  <Typography variant="body2" fontWeight="medium">
                    {theme.name}
                  </Typography>
                  {currentTheme === theme.id && (
                    <Typography 
                      variant="caption" 
                      color="primary" 
                      sx={{ 
                        mt: 1, 
                        display: 'block',
                        fontWeight: 'bold'
                      }}
                    >
                      当前选中
                    </Typography>
                  )}
                </Paper>
              </Tooltip>
            </Grid>
          ))}
        </Grid>
        
        {/* 当主题数量较少时，添加说明文字填充空间 */}
        {themes.length < 6 && (
          <Typography 
            variant="body2" 
            color="text.secondary" 
            sx={{ 
              mt: 4, 
              textAlign: 'center',
              fontStyle: 'italic'
            }}
          >
            更多主题将在未来版本中推出，敬请期待...
          </Typography>
        )}
      </Paper>
      
      <Snackbar
        open={notification.open}
        autoHideDuration={4000}
        onClose={handleCloseNotification}
        anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
      >
        <Alert
          onClose={handleCloseNotification}
          severity={notification.severity}
          sx={{ width: '100%' }}
        >
          {notification.message}
        </Alert>
      </Snackbar>
    </Container>
  );
};

export default SkinSelector;



// src/components/SkinSelector.js
// import React, { useState } from 'react';
// import { Container, Typography, Box, Paper, Grid, Divider, Snackbar, Alert } from '@mui/material';
// import axios from 'axios';
// // 导入共享的主题配置
// import { allThemes } from '../themeConfig';

// const SkinSelector = ({ currentTheme, onThemeChange }) => {
//   // 直接使用共享的主题列表（不再硬编码themes）
//   const themes = allThemes;
  
//   const [notification, setNotification] = useState({
//     open: false,
//     message: '',
//     severity: 'success'
//   });

//   const handleThemeSelect = (themeId) => {
//     onThemeChange(themeId); // 通知父组件（App）更新主题
//     saveThemePreference(themeId);
//   };

//   const saveThemePreference = async (themeId) => {
//     try {
//       await axios.post('user-selfconfig', {
//         configType: 'theme',
//         value: themeId
//       }, { withCredentials: true });
      
//       setNotification({
//         open: true,
//         message: '皮肤设置已保存',
//         severity: 'success'
//       });
//     } catch (error) {
//       console.error('保存主题设置失败:', error);
//       setNotification({
//         open: true,
//         message: '保存皮肤设置失败',
//         severity: 'error'
//       });
//     }
//   };

//   const handleCloseNotification = () => {
//     setNotification(prev => ({ ...prev, open: false }));
//   };

//   return (
//     <Container maxWidth="md" sx={{ mt: 4, mb: 4 }}>
//       <Typography variant="h4" gutterBottom>皮肤设置</Typography>
      
//       <Paper sx={{ p: 3 }}>
//         <Typography variant="h6" gutterBottom>选择您偏好的界面主题</Typography>
//         <Divider sx={{ mb: 3 }} />
        
//         <Grid container spacing={4}>
//           {themes.map(theme => (
//             <Grid item xs={6} sm={4} md={3} key={theme.id}>
//               <Paper 
//                 sx={{ 
//                   p: 2, 
//                   textAlign: 'center',
//                   border: currentTheme === theme.id ? `2px solid ${theme.color}` : '1px solid #ddd',
//                   borderRadius: 2,
//                   cursor: 'pointer',
//                   transition: 'all 0.3s',
//                   '&:hover': {
//                     boxShadow: 3,
//                     transform: 'translateY(-2px)'
//                   }
//                 }}
//                 onClick={() => handleThemeSelect(theme.id)}
//               >
//                 <Box 
//                   sx={{ 
//                     width: 30, 
//                     height: 30, 
//                     borderRadius: '50%', 
//                     backgroundColor: theme.color,
//                     margin: '0 auto 10px',
//                     // 深色主题加白色边框，增强可见性
//                     border: theme.id === 'dark' ? '1px solid #fff' : 'none'
//                   }}
//                 />
//                 <Typography variant="body2">{theme.name}</Typography>
//                 {currentTheme === theme.id && (
//                   <Typography variant="caption" color="primary" sx={{ mt: 1, display: 'block' }}>
//                     当前选中
//                   </Typography>
//                 )}
//               </Paper>
//             </Grid>
//           ))}
//         </Grid>
//       </Paper>
      
//       <Snackbar
//         open={notification.open}
//         autoHideDuration={6000}
//         onClose={handleCloseNotification}
//         anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
//       >
//         <Alert
//           onClose={handleCloseNotification}
//           severity={notification.severity}
//           sx={{ width: '100%' }}
//         >
//           {notification.message}
//         </Alert>
//       </Snackbar>
//     </Container>
//   );
// };

// export default SkinSelector;


// import React, { useState } from 'react';
// import { Container, Typography, Box, Paper, Grid, Divider, Snackbar, Alert } from '@mui/material';
// import axios from 'axios';

// const SkinSelector = ({ currentTheme, onThemeChange }) => {
//   // 扩展主题列表，增加6个新主题并修复深色主题
//   const [themes, setThemes] = useState([
//     { id: 'default', name: '默认主题' },
//     { id: 'pingan', name: '橘色主题' },
//     { id: 'bytedance', name: '字节跳动主题' },
//     { id: 'bank', name: '银行金融主题' },
//     { id: 'dark', name: '深色主题' },
//     { id: 'purple', name: '紫色主题' },
//     { id: 'premium', name: '高级感主题' },
//     { id: 'skyblue', name: '天青色主题' },      // 新增
//     { id: 'grassgreen', name: '草绿灰主题' },   // 新增
//     { id: 'khaki', name: '卡其色主题' },        // 新增
//     { id: 'waldenblue', name: '瓦尔登蓝主题' }, // 新增
//     { id: 'pink', name: '粉色世家主题' },       // 新增
//     { id: 'peach', name: '蜜桃色主题' }         // 新增
//   ]);
  
//   const [notification, setNotification] = useState({
//     open: false,
//     message: '',
//     severity: 'success'
//   });

//   const handleThemeSelect = (themeId) => {
//     // 更新前端主题
//     onThemeChange(themeId);
    
//     // 保存到后台
//     saveThemePreference(themeId);
//   };

//   const saveThemePreference = async (themeId) => {
//     try {
//       await axios.post('user-selfconfig', {
//         configType: 'theme',
//         value: themeId
//       }, { withCredentials: true });
      
//       setNotification({
//         open: true,
//         message: '皮肤设置已保存',
//         severity: 'success'
//       });
//     } catch (error) {
//       console.error('保存主题设置失败:', error);
//       setNotification({
//         open: true,
//         message: '保存皮肤设置失败',
//         severity: 'error'
//       });
//     }
//   };

//   const handleCloseNotification = () => {
//     setNotification(prev => ({ ...prev, open: false }));
//   };

//   // 获取主题的主色调用于预览，包含新主题和修复的深色主题
//   const getThemeColor = (themeId) => {
//     const themeColors = {
//       'default': '#1976d2',
//       'pingan': '#ECA063',
//       'bytedance': '#2d7ff9',
//       'bank': '#003366',
//       'dark': '#121212',       // 修复：深色主题使用黑色作为主色
//       'purple': '#9c27b0',
//       'premium': '#3F6F76',
//       'skyblue': '#90caf9',    // 天青色
//       'grassgreen': '#91AA9D', // 草绿灰
//       'khaki': '#A7A37E',      // 卡其色
//       'waldenblue': '#B9E3FB', // 瓦尔登蓝
//       'pink': '#DBC1D4',       // 粉色世家
//       'peach': '#E0B198'       // 蜜桃色
//     };
//     return themeColors[themeId] || '#1976d2';
//   };

//   return (
//     <Container maxWidth="md" sx={{ mt: 4, mb: 4 }}>
//       <Typography variant="h4" gutterBottom>
//         皮肤设置
//       </Typography>
      
//       <Paper sx={{ p: 3 }}>
//         <Typography variant="h6" gutterBottom>
//           选择您偏好的界面主题
//         </Typography>
//         <Divider sx={{ mb: 3 }} />
        
//         {/* 调整网格布局以适应更多主题 */}
//         <Grid container spacing={2}>
//           {themes.map(theme => (
//             <Grid item xs={6} sm={4} md={3} key={theme.id}>
//               <Paper 
//                 sx={{ 
//                   p: 2, 
//                   textAlign: 'center',
//                   border: currentTheme === theme.id ? `2px solid ${getThemeColor(theme.id)}` : '1px solid #ddd',
//                   borderRadius: 2,
//                   cursor: 'pointer',
//                   transition: 'all 0.3s',
//                   '&:hover': {
//                     boxShadow: 3,
//                     transform: 'translateY(-2px)'
//                   }
//                 }}
//                 onClick={() => handleThemeSelect(theme.id)}
//               >
//                 <Box 
//                   sx={{ 
//                     width: 30, 
//                     height: 30, 
//                     borderRadius: '50%', 
//                     backgroundColor: getThemeColor(theme.id),
//                     margin: '0 auto 10px',
//                     border: theme.id === 'dark' ? '1px solid #fff' : 'none' // 深色主题添加白色边框以增强可见性
//                   }}
//                 />
//                 <Typography variant="body2">
//                   {theme.name}
//                 </Typography>
//                 {currentTheme === theme.id && (
//                   <Typography variant="caption" color="primary" sx={{ mt: 1, display: 'block' }}>
//                     当前选中
//                   </Typography>
//                 )}
//               </Paper>
//             </Grid>
//           ))}
//         </Grid>
//       </Paper>
      
//       <Snackbar
//         open={notification.open}
//         autoHideDuration={6000}
//         onClose={handleCloseNotification}
//         anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
//       >
//         <Alert
//           onClose={handleCloseNotification}
//           severity={notification.severity}
//           sx={{ width: '100%' }}
//         >
//           {notification.message}
//         </Alert>
//       </Snackbar>
//     </Container>
//   );
// };

// export default SkinSelector;
    

// import React, { useState, useEffect } from 'react';
// import { Container, Typography, Box, Paper, Grid, Button, Divider, Snackbar, Alert } from '@mui/material';
// import axios from 'axios';

// const SkinSelector = ({ currentTheme, onThemeChange }) => {
//   const [themes, setThemes] = useState([
//     { id: 'default', name: '默认主题' },
//     { id: 'pingan', name: '橘色主题' },
//     { id: 'bytedance', name: '字节跳动主题' },
//     { id: 'bank', name: '银行金融主题' },
//     { id: 'dark', name: '深色主题' },
//     { id: 'purple', name: '紫色主题' },
//     { id: 'premium', name: '高级感主题' }
//   ]);
  
//   const [notification, setNotification] = useState({
//     open: false,
//     message: '',
//     severity: 'success'
//   });

//   const handleThemeSelect = (themeId) => {
//     // 更新前端主题
//     onThemeChange(themeId);
    
//     // 保存到后台
//     saveThemePreference(themeId);
//   };

//   const saveThemePreference = async (themeId) => {
//     try {
//       await axios.post('user-selfconfig', {
//         configType: 'theme',
//         value: themeId
//       }, { withCredentials: true });
      
//       setNotification({
//         open: true,
//         message: '皮肤设置已保存',
//         severity: 'success'
//       });
//     } catch (error) {
//       console.error('保存主题设置失败:', error);
//       setNotification({
//         open: true,
//         message: '保存皮肤设置失败',
//         severity: 'error'
//       });
//     }
//   };

//   const handleCloseNotification = () => {
//     setNotification(prev => ({ ...prev, open: false }));
//   };

//   // 获取主题的主色调用于预览
//   const getThemeColor = (themeId) => {
//     const themeColors = {
//       'default': '#1976d2',
//       'pingan': '#ECA063',
//       'bytedance': '#2d7ff9',
//       'bank': '#003366',
//       'dark': '#90caf9',
//       'purple': '#9c27b0',
//       'premium': '#3F6F76'
//     };
//     return themeColors[themeId] || '#1976d2';
//   };

//   return (
//     <Container maxWidth="md" sx={{ mt: 4, mb: 4 }}>
//       <Typography variant="h4" gutterBottom>
//         皮肤设置
//       </Typography>
      
//       <Paper sx={{ p: 3 }}>
//         <Typography variant="h6" gutterBottom>
//           选择您偏好的界面主题
//         </Typography>
//         <Divider sx={{ mb: 3 }} />
        
//         <Grid container spacing={2}>
//           {themes.map(theme => (
//             <Grid item xs={12} sm={6} md={4} key={theme.id}>
//               <Paper 
//                 sx={{ 
//                   p: 2, 
//                   textAlign: 'center',
//                   border: currentTheme === theme.id ? `2px solid ${getThemeColor(theme.id)}` : '1px solid #ddd',
//                   borderRadius: 2,
//                   cursor: 'pointer',
//                   transition: 'all 0.3s',
//                   '&:hover': {
//                     boxShadow: 3
//                   }
//                 }}
//                 onClick={() => handleThemeSelect(theme.id)}
//               >
//                 <Box 
//                   sx={{ 
//                     width: 30, 
//                     height: 30, 
//                     borderRadius: '50%', 
//                     backgroundColor: getThemeColor(theme.id),
//                     margin: '0 auto 10px'
//                   }}
//                 />
//                 <Typography>
//                   {theme.name}
//                 </Typography>
//                 {currentTheme === theme.id && (
//                   <Typography variant="body2" color="primary" sx={{ mt: 1 }}>
//                     当前选中
//                   </Typography>
//                 )}
//               </Paper>
//             </Grid>
//           ))}
//         </Grid>
//       </Paper>
      
//       <Snackbar
//         open={notification.open}
//         autoHideDuration={6000}
//         onClose={handleCloseNotification}
//         anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
//       >
//         <Alert
//           onClose={handleCloseNotification}
//           severity={notification.severity}
//           sx={{ width: '100%' }}
//         >
//           {notification.message}
//         </Alert>
//       </Snackbar>
//     </Container>
//   );
// };

// export default SkinSelector;