import React, { useState } from 'react';
import { 
  Container, Paper, Typography, Box, TextField, Button, 
  Divider, Alert, CircularProgress 
} from '@mui/material';
import { LockOutlined, CheckCircleOutlined } from '@mui/icons-material';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const PasswordChangePage = ({ showNotification }) => {
  const [formData, setFormData] = useState({
    oldPassword: '',
    newPassword: '',
    confirmPassword: ''
  });
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const navigate = useNavigate();

  // 表单字段变化处理
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    
    // 清除对应字段的错误提示
    if (errors[name]) {
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[name];
        return newErrors;
      });
    }
  };

  // 表单验证
  const validateForm = () => {
    const newErrors = {};
    
    // 验证旧密码
    if (!formData.oldPassword) {
      newErrors.oldPassword = '请输入当前密码';
    }
    
    // 验证新密码
    if (!formData.newPassword) {
      newErrors.newPassword = '请输入新密码';
    } else if (formData.newPassword.length < 8) {
      newErrors.newPassword = '新密码长度至少为8位';
    } else if (!/[A-Za-z]/.test(formData.newPassword) || !/[0-9]/.test(formData.newPassword)) {
      newErrors.newPassword = '新密码需包含字母和数字';
    }
    
    // 验证确认密码
    if (!formData.confirmPassword) {
      newErrors.confirmPassword = '请确认新密码';
    } else if (formData.confirmPassword !== formData.newPassword) {
      newErrors.confirmPassword = '两次输入的密码不一致';
    }
    
    // 验证新旧密码是否相同
    if (formData.oldPassword && formData.newPassword && formData.oldPassword === formData.newPassword) {
      newErrors.newPassword = '新密码不能与当前密码相同';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // 提交密码修改
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }
    
    setLoading(true);
    try {
      const response = await axios.post(
        '/api/user/change-password',
        {
          oldPassword: formData.oldPassword,
          newPassword: formData.newPassword
        },
        { withCredentials: true }
      );
      
      if (response.data.success) {
        setSuccess(true);
        setFormData({
          oldPassword: '',
          newPassword: '',
          confirmPassword: ''
        });
        showNotification('密码修改成功，请重新登录', 'success');
        
        // 3秒后跳转到登录页
        setTimeout(() => {
          navigate('/login');
        }, 3000);
      }
    } catch (error) {
      const errorMsg = error.response?.data?.error || '密码修改失败，请稍后重试';
      showNotification(errorMsg, 'error');
      setErrors({ server: errorMsg });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Container maxWidth="sm" sx={{ mt: 8, mb: 4 }}>
      <Paper sx={{ p: 4, borderRadius: 2, boxShadow: 3 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', mb: 3 }}>
          <LockOutlined color="primary" sx={{ mr: 2, fontSize: 32 }} />
          <Typography variant="h5" component="h1">
            修改密码
          </Typography>
        </Box>
        
        <Divider sx={{ mb: 4 }} />
        
        {success ? (
          <Box sx={{ textAlign: 'center', py: 4 }}>
            <CheckCircleOutlined color="success" sx={{ fontSize: 64, mb: 2 }} />
            <Typography variant="h6" color="success" sx={{ mb: 2 }}>
              密码修改成功！
            </Typography>
            <Typography variant="body1">
              系统将在3秒后跳转到登录页面，请使用新密码登录
            </Typography>
          </Box>
        ) : (
          <form onSubmit={handleSubmit}>
            {errors.server && (
              <Alert severity="error" sx={{ mb: 3 }}>
                {errors.server}
              </Alert>
            )}
            
            {/* 当前密码 */}
            <TextField
              fullWidth
              margin="normal"
              label="当前密码"
              name="oldPassword"
              type="password"
              variant="outlined"
              value={formData.oldPassword}
              onChange={handleChange}
              error={!!errors.oldPassword}
              helperText={errors.oldPassword}
              required
            />
            
            {/* 新密码 */}
            <TextField
              fullWidth
              margin="normal"
              label="新密码"
              name="newPassword"
              type="password"
              variant="outlined"
              value={formData.newPassword}
              onChange={handleChange}
              error={!!errors.newPassword}
              helperText={errors.newPassword || '新密码需至少8位，包含字母和数字'}
              required
            />
            
            {/* 确认新密码 */}
            <TextField
              fullWidth
              margin="normal"
              label="确认新密码"
              name="confirmPassword"
              type="password"
              variant="outlined"
              value={formData.confirmPassword}
              onChange={handleChange}
              error={!!errors.confirmPassword}
              helperText={errors.confirmPassword}
              required
            />
            
            <Box sx={{ mt: 4, display: 'flex', gap: 2 }}>
              <Button
                type="button"
                fullWidth
                variant="outlined"
                onClick={() => navigate(-1)}
                disabled={loading}
              >
                取消
              </Button>
              <Button
                type="submit"
                fullWidth
                variant="contained"
                color="primary"
                disabled={loading}
                startIcon={loading ? <CircularProgress size={20} /> : null}
              >
                {loading ? '处理中...' : '确认修改'}
              </Button>
            </Box>
          </form>
        )}
      </Paper>
    </Container>
  );
};

export default PasswordChangePage;