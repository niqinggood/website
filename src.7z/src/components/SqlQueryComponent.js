import React, { useState, useEffect, useImperativeHandle, forwardRef, useCallback } from 'react';
import { Form, Button, Table, message, Input, Typography, Divider, Tooltip, Tabs, Card, Popconfirm, Tag, Radio, Space } from 'antd';
import { SearchOutlined, QuestionCircleOutlined, CodeOutlined, SettingOutlined, SaveOutlined, EditOutlined,
  DeleteOutlined, DownloadOutlined, SyncOutlined, FileTextOutlined } from '@ant-design/icons';
import axios from 'axios';
import moment from 'moment';
import { useNavigate, useLocation } from 'react-router-dom';
import debounce from 'lodash.debounce';

const { TextArea } = Input;
const { Title, Text, Paragraph } = Typography;
const { TabPane } = Tabs;

// 主题配置定义
const themeConfigs = {
  default: {
    palette: {
      primary: { main: '#1976d2' },
      secondary: { main: '#42a5f5' },
      background: {
        default: '#f5f5f5',
        paper: '#ffffff'
      },
    },
    displayName: '默认主题'
  },
  skyblue: {
    palette: {
      primary: { main: '#90caf9' },
      secondary: { main: '#64b5f6' },
      background: {
        default: '#f0f7ff',
        paper: '#ffffff'
      },
    },
    displayName: '天青色'
  }
};

// 获取当前主题配置
const getCurrentTheme = () => {
  const themeType = localStorage.getItem('appTheme') || 'default';
  const currentTheme = themeConfigs[themeType] || themeConfigs.default;

  return {
    ...currentTheme,
    palette: {
      primary: {
        main: '#1976d2',
        light: '#63a4ff',
        dark: '#004ba0',
        ...currentTheme.palette?.primary
      },
      text: {
        primary: '#333333',
        secondary: '#666666',
        ...currentTheme.palette?.text
      },
      background: {
        paper: '#ffffff',
        default: '#f5f5f5',
        ...currentTheme.palette?.background
      },
      ...currentTheme.palette
    }
  };
};

const SqlQueryComponent = forwardRef((props, ref) => {
  // 状态管理（保持不变）
  const [form] = Form.useForm();
  const [taskForm] = Form.useForm();
  const [loading, setLoading] = useState(false);
  const [queryResults, setQueryResults] = useState(null);
  const [showInferSection, setShowInferSection] = useState(false);
  const [showParams, setShowParams] = useState(false);
  const [showInferParams, setShowInferParams] = useState(false);
  const [paramError, setParamError] = useState('');
  const [inferParamError, setInferParamError] = useState('');
  const [activeTabKey, setActiveTabKey] = useState('query');
  const [currentConfigName, setCurrentConfigName] = useState('');
  const [queryType, setQueryType] = useState('single');
  const [taskHistory, setTaskHistory] = useState([]);
  const [lastError, setLastError] = useState('');
  const [isNewTask, setIsNewTask] = useState(true);
  const [sqlInput, setSqlInput] = useState('');
  const [paramsInput, setParamsInput] = useState('');
  const [inferParamsInput, setInferParamsInput] = useState('');
  const [showHelp, setShowHelp] = useState(false);
  const [theme, setTheme] = useState(getCurrentTheme()); // 主题状态
  const [editingTaskId, setEditingTaskId] = useState(null); // 当前正在编辑的任务ID
  const [editSqlValue, setEditSqlValue] = useState(''); // 编辑框中的值


  const navigate = useNavigate();
  const location = useLocation();

  // 监听主题变化（保持不变）
  useEffect(() => {
    const handleStorageChange = () => {
      setTheme(getCurrentTheme());
    };

    setTheme(getCurrentTheme());
    window.addEventListener('storage', handleStorageChange);
    return () => {
      window.removeEventListener('storage', handleStorageChange);
    };
  }, []);

  // 初始化配置（保持不变）
  

  // 其他生命周期和方法（保持不变）
  useEffect(() => {
    const currentParams = form.getFieldValue('params') || '';
    if (currentParams !== paramsInput) {
      setParamsInput(currentParams);
    }
  }, [form, form.getFieldValue('params')]);

  useEffect(() => {
    const currentInferParams = form.getFieldValue('inferParams') || '';
    if (currentInferParams !== inferParamsInput) {
      setInferParamsInput(currentInferParams);
    }
  }, [form, form.getFieldValue('inferParams')]);

  useEffect(() => {
    if (currentConfigName) {
      taskForm.setFieldsValue({ taskName: currentConfigName });
    }
  }, [currentConfigName, taskForm]);

  useImperativeHandle(ref, () => ({
    loadConfig: (config) => {
    console.info("useImperativeHandle #####################config:",typeof config,config)
    setCurrentConfigName(config.configname);
    setIsNewTask(false); // 关键：标记为已存在的任务，避免新任务逻辑干扰

    let sqlJson = config.sql_json;
    if (typeof sqlJson === 'string') {
          try {
            sqlJson = JSON.parse(sqlJson); // 第一次解析
            if (typeof sqlJson === 'string') {
              sqlJson = JSON.parse(sqlJson); // 还原到对象
            }
          } catch (e) {
            console.error('解析sql_json失败:', e);
          }
    }

    console.info("sqlJson###:",typeof sqlJson,sqlJson)
    console.info("sqlJson.sql:",sqlJson.sql)
    console.info("sqlJson###2:",typeof sqlJson,sqlJson)
    // 1. 同步更新 Form 表单值
    form.setFieldsValue({
      sql: sqlJson.sql || sqlJson.mainSql || '111112123123123',
      params: sqlJson.params ? JSON.stringify(sqlJson.params, null, 2) :   sqlJson.mainParams ? JSON.stringify(sqlJson.mainParams, null, 2):''  ,
      inferSql: sqlJson.inferSql || '',
      inferParams: sqlJson.inferParams ? JSON.stringify(sqlJson.inferParams, null, 2) : '',
    });
    
    const currentSql = form.getFieldValue('sql');
      console.log("表单中实际的sql值：", currentSql); // 若为undefined或空，说明字段名不匹配
   
    setTimeout(() => {
      console.log("所有表单字段:", form.getFieldsValue());
      console.log("表单中实际的sql值：", form.getFieldValue('sql'));
    },100);
    
    setSqlInput( sqlJson.sql || '' )
  
    // 2. 同步更新参数输入框状态
    setParamsInput(sqlJson.params ? JSON.stringify(sqlJson.params, null, 2) : '');
    setInferParamsInput(sqlJson.inferParams ? JSON.stringify(sqlJson.inferParams, null, 2) : '');

    // 3. 同步显示/隐藏参数面板
    setShowParams(!!(sqlJson.params && Object.keys(sqlJson.params).length > 0));
    setShowInferSection(!!sqlJson.inferSql);
    setShowInferParams(!!(sqlJson.inferSql && sqlJson.inferParams && Object.keys(sqlJson.inferParams).length > 0));

    // 4. 同步更新任务名称表单
    taskForm.setFieldsValue({ taskName: config.configname });

    // 5. 加载任务历史（可选，按需保留）
    loadTaskHistory(config.configname);
  },
    setConfigName: (name) => {
      setCurrentConfigName(name);
      taskForm.setFieldsValue({ taskName: name });
    },
    setSampleSql: (sqlString, isMain = true) => {
      form.setFieldsValue({ [isMain ? 'sql' : 'inferSql']: sqlString });
      if (!isMain) setShowInferSection(true);
    }
  }));

  // 核心功能方法（保持不变）
  const loadTaskHistory = async (configName) => {
    try {
      const response = await axios.get(`/api/fetch-history?configName=${configName}`, { withCredentials: true });
       console.info("has finish loadTaskHistory ")
      if (response.data.success &&  response.data.tasks.length >0 ) {
        console.info("begin setTaskHistory")
        setTaskHistory(response.data.tasks);
      }
    } catch (error) {
      console.error('加载任务历史失败', error);
      message.error('加载任务历史失败');
      setTaskHistory([]);
    }
  };

  const handleEdit = (record) => {
  try {
    let sqlJson = record.sql_json;
    if (typeof sqlJson === 'string') {
      const parsed = JSON.parse(sqlJson);
      setEditSqlValue(JSON.stringify(parsed, null, 2));
    } else if (typeof sqlJson === 'object') {
      setEditSqlValue(JSON.stringify(sqlJson, null, 2));
    } else {
      setEditSqlValue(sqlJson || '');
    }
    setEditingTaskId(record.id);
  } catch (e) {
    setEditSqlValue(record.sql_json || '');
    setEditingTaskId(record.id);
  }
};

// 取消编辑
const handleCancelEdit = () => {
  setEditingTaskId(null);
  setEditSqlValue('');
};

 const saveModifiedSql = async (taskId, modifiedSqlJson) => {
  console.info("modifiedSqlJson:",modifiedSqlJson)
  try {
    // 验证JSON格式
    JSON.parse(modifiedSqlJson);

    const response = await axios.put(`/api/fetchhistory/${taskId}/sql`, {
      sql_json: modifiedSqlJson
    }, { withCredentials: true });

    if (response.data.success) {
      message.success('SQL配置更新成功');
      // 刷新任务历史
      loadTaskHistory(currentConfigName);
    } else {
      message.error('更新失败: ' + response.data.error);
    }
  } catch (error) {
    const errMsg = error.response?.data?.error ||
                  (error instanceof SyntaxError ? 'JSON格式错误' : error.message);
    message.error(`保存失败: ${errMsg}`);
  }
};

  const validateParams = (paramsStr, sql, errorSetter) => {
    errorSetter('');

    if (!paramsStr || paramsStr.trim() === '') {
      return {};
    }

    try {
      const params = JSON.parse(paramsStr);

      if (typeof params !== 'object' || params === null || Array.isArray(params)) {
        errorSetter('参数必须是JSON对象（如 {"key": "value"}）');
        return null;
      }

      const sqlParams = new Set();
      const paramRegex = /:([a-zA-Z0-9_]+)/g;
      let match;
      while ((match = paramRegex.exec(sql)) !== null) {
        sqlParams.add(match[1]);
      }

      const unusedParams = Object.keys(params).filter(key => !sqlParams.has(key));
      if (unusedParams.length > 0) {
        errorSetter(`参数 "${unusedParams.join(', ')}" 在SQL中未使用`);
        return params;
      }

      const processedParams = {};
      Object.keys(params).forEach(key => {
        const value = params[key];
        processedParams[key] = (typeof value === 'string' && !isNaN(Number(value)) && value.trim() !== '')
          ? Number(value)
          : value;
      });

      return processedParams;
    } catch (e) {
      errorSetter(`JSON格式错误: ${e.message}`);
      return null;
    }
  };

  const debouncedValidate = useCallback(
    debounce((value, sql) => validateParams(value, sql, setParamError), 300),
    []
  );

  const debouncedInferValidate = useCallback(
    debounce((value, sql) => validateParams(value, sql, setInferParamError), 300),
    []
  );

  const saveSqlConfig = async () => {
    try {
      const values = await form.validateFields();

      if (!values.sql || values.sql.trim() === '') {
        message.error('SQL不能为空');
        return;
      }

      const params = validateParams(values.params, values.sql, setParamError);
      if (paramError) {
        message.error(`参数错误: ${paramError}`);
        return;
      }

      let inferParams = {};
      if (showInferSection && values.inferSql && values.inferParams) {
        inferParams = validateParams(values.inferParams, values.inferSql, setInferParamError);
        if (inferParamError) {
          message.error(`推理参数错误: ${inferParamError}`);
          return;
        }
      }

      const configData = {
        configname: currentConfigName,
        type: 'sql',
        sql_json: JSON.stringify({
          sql: values.sql,
          params: params || {},
          inferSql: values.inferSql || '',
          inferParams: inferParams || {}
        }),
        savedat: new Date().toISOString()
      };

      await axios.post('/api/saveconfigurations', configData, { withCredentials: true });

      message.success(isNewTask ? '任务创建成功' : '配置更新成功');
      navigate(`/dataexpress?edit=${currentConfigName}`, { replace: true });
      setIsNewTask(false);
      loadTaskHistory(currentConfigName);
    } catch (error) {
      const errMsg = error.response?.data?.error || error.message;
      message.error(`${isNewTask ? '创建' : '更新'}失败: ${errMsg}`);
      setLastError(errMsg);
    }
  };

  const executeQuery = async (isMain = true) => {
    setLoading(true);
    setQueryResults(null);
    setLastError('');

    try {
      const values = await form.validateFields();
      const sqlKey = isMain ? 'sql' : 'inferSql';
      const paramsKey = isMain ? 'params' : 'inferParams';
      const errorSetter = isMain ? setParamError : setInferParamError;
      const errorState = isMain ? paramError : inferParamError;

      const userInputSql = values[sqlKey] || '';
      if (!userInputSql.trim()) {
        message.error(`${isMain ? '' : '推理'}SQL不能为空`);
        setLoading(false);
        return;
      }

      const userInputParamsStr = values[paramsKey] || '';
      const params = validateParams(userInputParamsStr, userInputSql, errorSetter);

      if (errorState) {
        setLoading(false);
        return;
      }

      const response = await axios.post('/api/data/sqltestquery', {
        sql: userInputSql,
        params: params
      }, { withCredentials: true });

      setQueryResults(response.data);
      const queryTypeText = `${isMain ? '' : '推理'}查询`;
      message.success(`${queryTypeText}成功，返回 ${response.data.count || 0} 条数据`);
    } catch (error) {
      const errMsg = error.response?.data?.error || error.message;
      message.error(`查询失败: ${errMsg}`);
      setLastError(errMsg);
    } finally {
      setLoading(false);
    }
  };

  const executeTaskQuery = async () => {
    setLoading(true);
    setLastError('');

    try {
      const [mainValues, taskValues] = await Promise.all([
        form.validateFields(),
        taskForm.validateFields()
      ]);

      if (!mainValues.sql || mainValues.sql.trim() === '') {
        message.error('SQL不能为空');
        setLoading(false);
        return;
      }

      const params = validateParams(mainValues.params, mainValues.sql, setParamError);
      if (paramError) {
        setLoading(false);
        return;
      }

      if (showInferSection && mainValues.inferSql) {
        const inferParams = validateParams(mainValues.inferParams, mainValues.inferSql, setInferParamError);
        if (inferParamError) {
          setLoading(false);
          return;
        }
      }

      const newConfigName = taskValues.taskName;
      setCurrentConfigName(newConfigName);

      const configData = {
        configname: newConfigName,
        type: 'sql',
        sql_json: JSON.stringify({
          sql: mainValues.sql,
          params: params || {},
          inferSql: mainValues.inferSql || '',
          inferParams: mainValues.inferParams ? JSON.parse(mainValues.inferParams) : {}
        }),
        description: taskValues.description || ''
      };

      const response = await axios.post('/api/fetch-data', configData, { withCredentials: true });
      if (response.data.success) {
        message.success('任务执行成功');
        navigate(`/dataexpress?edit=${newConfigName}`, { replace: true });
        setIsNewTask(false);
        loadTaskHistory(newConfigName);
      } else {
        message.error('错误: ' + response.data.error);
        setLastError(response.data.error);
      }
    } catch (error) {
      const errMsg = error.response?.data?.error || error.message;
      message.error(`操作失败: ${errMsg}`);
      setLastError(errMsg);
    } finally {
      setLoading(false);
    }
  };

  const deleteTask = async (taskId) => {
    try {
      await axios.delete(`/api/fetch-history/${taskId}`);
      message.success('任务删除成功');
      loadTaskHistory(currentConfigName);
    } catch (error) {
      message.error(`删除失败: ${error.response?.data?.error || error.message}`);
    }
  };

  const clearTaskHistory = async () => {
    try {
      await axios.delete(`/api/fetch-history?configName=${currentConfigName}`, { withCredentials: true });
      message.success('任务历史已清空');
      loadTaskHistory(currentConfigName);
    } catch (error) {
      message.error(`清空失败: ${error.response?.data?.error || error.message}`);
    }
  };

  const downloadTaskResult = (taskId) => {
    axios.get(`/api/task/download/${taskId}`, {
      withCredentials: true,
      responseType: 'blob'
    }).then(res => {
      const url = window.URL.createObjectURL(new Blob([res.data]));
      const a = document.createElement('a');
      a.href = url;
      a.download = `task-${taskId}-result.csv`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      message.success('文件下载成功');
    }).catch(err => {
      message.error(`下载失败: ${err.response?.data?.error || '文件不存在'}`);
    });
  };

  // 样式定义 - 重点优化头部布局
  const headerStyle = {
    backgroundColor: theme.palette.background.paper,
    border: `1px solid ${theme.palette.primary.main}30`,
    borderRadius: '8px',
    padding: '12px 16px', // 减少内边距使整体更紧凑
    marginBottom: '16px',
    boxShadow: '0 2px 8px rgba(0, 0, 0, 0.05)',
  };

  // 关键优化：紧凑布局，输入框和按钮靠左紧凑排列
  const titleContainerStyle = {
    display: 'flex',
    alignItems: 'center',
    gap: '12px', // 减少间距
    flexWrap: 'wrap',
    width: '100%',
    // 左对齐所有内容
    justifyContent: 'flex-start'
  };

  // 标题和标签容器
  const titleWrapperStyle = {
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
    flexShrink: 0,
    marginRight: '8px' // 与输入框保持小间距
  };

  const titleStyle = {
    margin: 0,
    color: theme.palette.text.primary,
    fontSize: '1.5rem' // 稍微缩小标题字体
  };

  // 输入框容器 - 紧凑设计
  const inputContainerStyle = {
    display: 'flex',
    alignItems: 'center',
    flexShrink: 0, // 不收缩
    minWidth: '200px'
  };

  // 按钮容器 - 紧挨着输入框
  const buttonContainerStyle = {
    display: 'flex',
    gap: '8px',
    flexShrink: 0,
    marginLeft: '8px' // 与输入框保持小间距
  };

  const cardStyle = {
    backgroundColor: theme.palette.background.paper,
    borderColor: `${theme.palette.primary.main}20`,
    transition: 'all 0.3s',
  };

  const buttonStyle = {
    backgroundColor: theme.palette.primary.main,
    borderColor: theme.palette.primary.main,
    '&:hover': {
      backgroundColor: theme.palette.primary.dark,
      borderColor: theme.palette.primary.dark,
    },
  };

  return (
    <div style={{
      padding: '20px',
      backgroundColor: theme.palette.background.default,
      minHeight: '100%'
    }}>
      {/* 使用说明（保持不变） */}
      <div style={{ marginBottom: 16 }}>
        <Button
          icon={<FileTextOutlined />}
          onClick={() => setShowHelp(!showHelp)}
          type="text"
          style={{ marginBottom: 8, color: theme.palette.text.secondary }}
        >
          {showHelp ? '隐藏使用说明' : '显示使用说明'}
        </Button>

        {showHelp && (
 <Card style={{
  marginBottom: 16,
  backgroundColor: theme.palette.background.paper,
  borderColor: `${theme.palette.primary.main}20`
}}>
  <Title level={5} style={{ color: theme.palette.text.primary }}>使用说明</Title>

  <Paragraph style={{ color: theme.palette.text.secondary, marginBottom: 12 }}>
    <strong>1. 基本概念</strong>
  </Paragraph>
  <Paragraph style={{ color: theme.palette.text.secondary, marginLeft: 16, marginBottom: 16 }}>
    - 本工具用于配置和执行SQL查询任务，支持即时测试和定时任务两种模式
    - 所有任务名称需遵循K8s命名规范，仅允许包含字母、数字和中划线（-）
  </Paragraph>

  <Paragraph style={{ color: theme.palette.text.secondary, marginBottom: 12 }}>
    <strong>2. 主SQL配置（必填）</strong>
  </Paragraph>
  <Paragraph style={{ color: theme.palette.text.secondary, marginLeft: 16, marginBottom: 8 }}>
    - 用于定义核心数据查询逻辑，必须以SELECT开头的SQL语句
    - 支持参数化查询，参数格式为冒号加参数名（例如:start_date）
  </Paragraph>
  <Paragraph style={{ color: theme.palette.text.secondary, marginLeft: 16, marginBottom: 8 }}>
    <strong>示例：</strong>
    <Text code style={{ display: 'block', marginTop: 4, padding: 8, backgroundColor: '#f5f5f5', borderRadius: 4 }}>
      SELECT user_id, order_amount
      FROM orders
      WHERE order_date BETWEEN :start_date AND :end_date
      AND user_level = :user_level
    </Text>
  </Paragraph>

  <Paragraph style={{ color: theme.palette.text.secondary, marginBottom: 12 }}>
    <strong>3. 查询参数配置</strong>
  </Paragraph>
  <Paragraph style={{ color: theme.palette.text.secondary, marginLeft: 16, marginBottom: 8 }}>
    - 以JSON对象格式填写，键名必须与SQL中的参数名完全匹配（包括大小写）
    - 支持字符串、数字、布尔等基本数据类型
  </Paragraph>
  <Paragraph style={{ color: theme.palette.text.secondary, marginLeft: 16, marginBottom: 16 }}>
    <strong>示例：</strong>
    <Text code style={{ display: 'block', marginTop: 4, padding: 8, backgroundColor: '#f5f5f5', borderRadius: 4 }}>
      {'{'}
        &quot;start_date&quot;: &quot;2023-09-01&quot;,
        &quot;end_date&quot;: &quot;2023-09-30&quot;,
        &quot;user_level&quot;: &quot;VIP&quot;
      {'}'}
    </Text>
  </Paragraph>

  <Paragraph style={{ color: theme.palette.text.secondary, marginBottom: 12 }}>
    <strong>4. 推理SQL配置（可选）</strong>
  </Paragraph>
  <Paragraph style={{ color: theme.palette.text.secondary, marginLeft: 16, marginBottom: 8 }}>
    - 用于定义与主SQL对比分析的辅助查询，通常用于验证主查询结果的准确性
    - 场景举例：
      - 主SQL查询当日数据，推理SQL查询昨日同期数据进行对比
      - 主SQL查询某指标汇总值，推理SQL查询该指标的明细构成
      - 主SQL使用复杂逻辑计算，推理SQL使用简化逻辑进行校验
  </Paragraph>
  <Paragraph style={{ color: theme.palette.text.secondary, marginLeft: 16, marginBottom: 16 }}>
    <strong>示例：</strong>
    <Text code style={{ display: 'block', marginTop: 4, padding: 8, backgroundColor: '#f5f5f5', borderRadius: 4 }}>
      -- 与主SQL对比的前一个月数据
      SELECT user_id, order_amount
      FROM orders
      WHERE order_date BETWEEN
        DATE_ADD(:start_date, INTERVAL -1 MONTH) AND
        DATE_ADD(:end_date, INTERVAL -1 MONTH)
      AND user_level = :user_level
    </Text>
  </Paragraph>

  <Paragraph style={{ color: theme.palette.text.secondary, marginBottom: 12 }}>
    <strong>5. 单次测试查询使用方法</strong>
  </Paragraph>
  <Paragraph style={{ color: theme.palette.text.secondary, marginLeft: 16, marginBottom: 8 }}>
    1) 在"SQL配置"标签页填写主SQL和对应参数
    2) 点击"调试查询"按钮执行即时查询
    3) 下方会显示查询结果表格，包含返回的数据记录
    4) 如需使用推理SQL，展开"推理SQL设置"并填写后点击"调试推理查询"
  </Paragraph>

  <Paragraph style={{ color: theme.palette.text.secondary, marginBottom: 12 }}>
    <strong>6. 任务名称命名规范</strong>
  </Paragraph>
  <Paragraph style={{ color: theme.palette.text.secondary, marginLeft: 16, marginBottom: 8 }}>
    - 建议格式：<Text code>sql-日期-业务场景-功能描述</Text>
    - 示例：
      - <Text code>sql-20230904-user-order-summary</Text>
      - <Text code>sql-20230904-product-sales-analysis</Text>
    - 注意：避免使用下划线、空格及特殊字符，长度建议不超过50个字符
  </Paragraph>
</Card>
        )}
      </div>

      {/* 核心优化：头部布局 - 输入框和按钮靠左紧凑排列 */}
      <div style={headerStyle}>
        <div style={titleContainerStyle}>
          {/* 标题部分 */}
          <div style={titleWrapperStyle}>
            <Title level={2} style={titleStyle}>
              SQL查询配置
            </Title>
            {isNewTask && (
              <Tag
                color={theme.palette.primary.main}
                style={{
                  backgroundColor: `${theme.palette.primary.main}10`,
                  color: theme.palette.primary.main,
                  height: '24px', // 减小标签高度
                  lineHeight: '24px'
                }}
              >
                新任务
              </Tag>
            )}
          </div>

          {/* 任务名称输入框 - 紧凑设计 */}
          <Form form={taskForm} layout="inline" style={inputContainerStyle}>
            <Form.Item
              name="taskName"
              label={
                <span style={{ marginRight: '8px', whiteSpace: 'nowrap' }}>
                  任务名称
                  <Tooltip title="使用字母、数字和中划线，如sql-0904-userdata">
                    <QuestionCircleOutlined style={{ marginLeft: 3, color: theme.palette.primary.main, fontSize: '14px' }} />
                  </Tooltip>
                </span>
              }
              rules={[
                { required: true, message: '请输入任务名称' },
                { pattern: /^[a-zA-Z0-9-_]+$/, message: '仅允许字母、数字和中划线' }
              ]}
              style={{ margin: 0 }} // 移除默认边距
            >
              <Input
                placeholder="sql-0904-userdata"
                value={currentConfigName}
                onChange={(e) => {
                  const newValue = e.target.value;
                  setCurrentConfigName(newValue);
                  taskForm.setFieldsValue({ taskName: newValue });
                }}
                style={{
                  borderColor: `${theme.palette.primary.main}30`,
                  '&:focus': {
                    borderColor: theme.palette.primary.main,
                    boxShadow: `0 0 0 2px ${theme.palette.primary.main}20`,
                  },
                  width: 200, // 固定宽度
                  margin: 0 // 移除默认边距
                }}
              />
            </Form.Item>
          </Form>

          {/* 操作按钮 - 紧挨着输入框 */}
          <div style={buttonContainerStyle}>
            <Button
              icon={<SaveOutlined />}
              onClick={saveSqlConfig}
              disabled={loading}
              type="primary"
              style={buttonStyle}
              size="middle" // 使用中等大小按钮
            >
              {isNewTask ? '保存配置' : '更新配置'}
            </Button>
          </div>
        </div>
      </div>

      {/* 错误提示（保持不变） */}
      {lastError && (
        <div style={{
          marginBottom: 16,
          padding: 10,
          backgroundColor: '#fff2f0',
          border: '1px solid #ffccc7',
          borderRadius: 4
        }}>
          <Text type="danger">{lastError}</Text>
        </div>
      )}

      {/* 标签页（保持不变） */}
      <Tabs
        activeKey={activeTabKey}
        onChange={setActiveTabKey}
        style={{ marginBottom: 20 }}
        tabBarStyle={{
          backgroundColor: theme.palette.background.paper,
          borderRadius: '8px 8px 0 0',
          paddingLeft: '16px'
        }}
      >
        <TabPane
          key="query"
          tab="SQL配置"
          icon={<CodeOutlined style={{ color: theme.palette.primary.main }} />}
        />
        <TabPane
          key="history"
          tab="任务历史"
          icon={<EditOutlined style={{ color: theme.palette.primary.main }} />}
        />
      </Tabs>

      {/* SQL配置标签页内容（保持不变） */}
      {activeTabKey === 'query' && (
        <Card style={{...cardStyle}}>
          <Form form={form} layout="vertical">
            {/* 主SQL配置区 - 必选 */}
            <div style={{ marginBottom: 24, paddingBottom: 16, borderBottom: `1px dashed ${theme.palette.primary.main}20` }}>
              <Form.Item
                name="sql"
                value={sqlInput}
                label={
                  <span>
                    查询SQL
                    <Tooltip title="支持SELECT语句和命名参数（格式:参数名）">
                      <QuestionCircleOutlined style={{ marginLeft: 5, color: theme.palette.primary.main }} />
                    </Tooltip>
                  </span>
                }
                rules={[
                  { required: true, message: '请输入SQL查询语句' },
                  { pattern: /^select/i, message: '请输入SELECT开头的查询语句' }
                ]}
              >
                <TextArea
                  rows={6}
                  placeholder="示例: SELECT * FROM user_behavior WHERE date < :end_date"
                  spellCheck={false}
                  style={{
                    borderColor: `${theme.palette.primary.main}30`,
                    '&:focus': {
                      borderColor: theme.palette.primary.main,
                      boxShadow: `0 0 0 2px ${theme.palette.primary.main}20`,
                    }
                  }}
                />
              </Form.Item>

              <Form.Item>
                <Space>
                  <Button
                    type={showParams ? "primary" : "default"}
                    onClick={() => setShowParams(!showParams)}
                    icon={<SettingOutlined />}
                    style={showParams ? buttonStyle : {}}
                  >
                    {showParams ? "隐藏参数" : "显示参数"}
                  </Button>

                  <Button
                    type={showInferSection ? "primary" : "default"}
                    onClick={() => setShowInferSection(!showInferSection)}
                    icon={<SettingOutlined />}
                    style={showInferSection ? buttonStyle : {}}
                  >
                    {showInferSection ? "隐藏推理SQL设置" : "设置推理SQL"}
                  </Button>

                  <Button
                    type="primary"
                    icon={<SearchOutlined />}
                    onClick={() => executeQuery(true)}
                    loading={loading}
                    style={buttonStyle}
                  >
                    调试查询
                  </Button>
                </Space>
              </Form.Item>

              {/* 主参数设置 */}
              <Form.Item
                name="params"
                label={
                  <span>
                    查询参数
                    <Tooltip title="JSON对象格式，键需与SQL中的:参数名完全匹配">
                      <QuestionCircleOutlined style={{ marginLeft: 5, color: theme.palette.primary.main }} />
                    </Tooltip>
                  </span>
                }
                style={{
                  display: showParams ? 'block' : 'none',
                  marginBottom: showParams ? 16 : 0
                }}
              >
                <TextArea
                  rows={3}
                  placeholder='请输入JSON格式的参数，例如: {"end_date": "2023-12-31"}'
                  spellCheck={false}
                  value={paramsInput}
                  onChange={(e) => {
                    const value = e.target.value;
                    setParamsInput(value);
                    form.setFieldsValue({ params: value });
                    const sql = form.getFieldValue('sql') || '';
                    debouncedValidate(value, sql);
                  }}
                  style={{
                    borderColor: `${theme.palette.primary.main}30`,
                    '&:focus': {
                      borderColor: theme.palette.primary.main,
                      boxShadow: `0 0 0 2px ${theme.palette.primary.main}20`,
                    }
                  }}
                />
                {paramError && (
                  <Text type="danger" style={{ marginTop: 5, display: 'inline-block' }}>
                    {paramError}
                  </Text>
                )}
              </Form.Item>
            </div>

            {/* 推理SQL配置区 - 可选 */}
            {showInferSection && (
              <div>
                <Title level={4} style={{ marginBottom: 16, color: theme.palette.text.primary }}>
                  推理SQL配置
                  <Tag
                    color="blue"
                    size="small"
                    style={{ marginLeft: 8, backgroundColor: `${theme.palette.secondary.main}10`, color: theme.palette.secondary.main }}
                  >
                    可选
                  </Tag>
                </Title>

                <Form.Item
                  name="inferSql"
                  label={
                    <span>
                      推理查询SQL
                      <Tooltip title="支持SELECT语句和命名参数（格式:参数名）">
                        <QuestionCircleOutlined style={{ marginLeft: 5, color: theme.palette.primary.main }} />
                      </Tooltip>
                    </span>
                  }
                >
                  <TextArea
                    rows={6}
                    placeholder="示例: SELECT * FROM user_behavior WHERE date >= :start_date"
                    spellCheck={false}
                    style={{
                      borderColor: `${theme.palette.primary.main}30`,
                      '&:focus': {
                        borderColor: theme.palette.primary.main,
                        boxShadow: `0 0 0 2px ${theme.palette.primary.main}20`,
                      }
                    }}
                  />
                </Form.Item>

                <Form.Item>
                  <Button
                    type={showInferParams ? "primary" : "default"}
                    onClick={() => setShowInferParams(!showInferParams)}
                    icon={<SettingOutlined />}
                    style={showInferParams ? buttonStyle : {}}
                  >
                    {showInferParams ? "隐藏推理参数" : "显示推理参数"}
                  </Button>

                  <Button
                    type="primary"
                    icon={<SearchOutlined />}
                    onClick={() => executeQuery(false)}
                    loading={loading}
                    style={buttonStyle}
                  >
                    调试推理查询
                  </Button>
                </Form.Item>

                <Form.Item
                  name="inferParams"
                  label={
                    <span>
                      推理查询参数
                      <Tooltip title="JSON对象格式，键需与SQL中的:参数名完全匹配">
                        <QuestionCircleOutlined style={{ marginLeft: 5, color: theme.palette.primary.main }} />
                      </Tooltip>
                    </span>
                  }
                  style={{
                    display: showInferParams ? 'block' : 'none',
                    marginBottom: showInferParams ? 16 : 0
                  }}
                >
                  <TextArea
                    rows={3}
                    placeholder='请输入JSON格式的参数，例如: {"start_date": "2024-01-01"}'
                    spellCheck={false}
                    value={inferParamsInput}
                    onChange={(e) => {
                      const value = e.target.value;
                      setInferParamsInput(value);
                      form.setFieldsValue({ inferParams: value });
                      const sql = form.getFieldValue('inferSql') || '';
                      debouncedInferValidate(value, sql);
                    }}
                    style={{
                      borderColor: `${theme.palette.primary.main}30`,
                      '&:focus': {
                        borderColor: theme.palette.primary.main,
                        boxShadow: `0 0 0 2px ${theme.palette.primary.main}20`,
                      }
                    }}
                  />
                  {inferParamError && (
                    <Text type="danger" style={{ marginTop: 5, display: 'inline-block' }}>
                      {inferParamError}
                    </Text>
                  )}
                </Form.Item>
              </div>
            )}

            <Divider style={{ backgroundColor: `${theme.palette.primary.main}20` }}>任务执行选项</Divider>

            <Form.Item>
              <Radio.Group
                value={queryType}
                onChange={(e) => setQueryType(e.target.value)}
                style={{ marginBottom: 16 }}
              >
                <Radio.Button value="single">单次测试查询</Radio.Button>
                <Radio.Button value="task">创建定时任务</Radio.Button>
              </Radio.Group>
            </Form.Item>

            {queryType === 'task' && (
              <Form form={taskForm} layout="vertical">
                <Form.Item>
                  <Button
                    type="primary"
                    icon={<SearchOutlined />}
                    size="large"
                    onClick={executeTaskQuery}
                    loading={loading}
                    style={buttonStyle}
                  >
                    创建获取执行任务
                  </Button>
                </Form.Item>
              </Form>
            )}
          </Form>
        </Card>
      )}

      {/* 查询结果展示（保持不变） */}
      {queryResults && queryResults.data && (
        <Card style={{
          marginTop: 20,
          ...cardStyle
        }}>
          <Title level={4} style={{ margin: 0, marginBottom: 16, color: theme.palette.text.primary }}>
            查询结果 ({queryResults.count} 条)
          </Title>

          {queryResults.data.length > 0 ? (
            <Table
              dataSource={queryResults.data}
              columns={queryResults.columns.map(col => ({
                title: col,
                dataIndex: col,
                key: col,
                render: (text) => {
                  if (typeof text === 'string' && text.length > 100) {
                    return <Tooltip title={text}><Text ellipsis>{text}</Text></Tooltip>;
                  }
                  if (typeof text === 'object' && text !== null) {
                    return <Text>{JSON.stringify(text)}</Text>;
                  }
                  return text;
                }
              }))}
              scroll={{ x: 'max-content' }}
              bordered
              pagination={{
                pageSize: 10,
                showSizeChanger: true,
                showTotal: (total) => `共 ${total} 条`
              }}
              style={{ borderColor: `${theme.palette.primary.main}20` }}
            />
          ) : (
            <Text type="warning">查询成功，但未返回任何数据</Text>
          )}
        </Card>
      )}

      {/* 任务历史标签页（保持不变） */}
      {activeTabKey === 'history' && (
        <Card style={{...cardStyle}}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 16, alignItems: 'center' }}>
            <Title level={4} style={{ margin: 0, color: theme.palette.text.primary }}>任务历史记录</Title>
            <div style={{ display: 'flex', gap: 10 }}>
              <Popconfirm
                title="确定要清空所有任务历史吗？"
                onConfirm={clearTaskHistory}
                okText="是"
                cancelText="否"
              >
                <Button icon={<DeleteOutlined />} type="text" danger>
                  清空历史
                </Button>
              </Popconfirm>
              <Button
                icon={<SyncOutlined />}
                onClick={() => loadTaskHistory(currentConfigName)}
                loading={loading}
              >
                刷新
              </Button>
            </div>
          </div>

          <Table
            dataSource={taskHistory}
            columns={[
              {
                title: '任务ID',
                dataIndex: 'id',
                key: 'id',
                width: 120,
                render: (id) => <Text code>{id}</Text>
              },
              {
                title: '配置名称',
                dataIndex: 'configname',
                key: 'configname'
              },
              {
                title: '状态',
                dataIndex: 'status',
                key: 'status',
                render: (status) => (
                  <Tag color={
                    status === 'completed' ? 'success' :
                    status === 'failed' ? 'error' :
                    status === 'processing' ? 'processing' : 'default'
                  }>
                    {status}
                  </Tag>
                )
              },
              {
                title: '触发时间',
                dataIndex: 'triggeredAt',
                key: 'triggeredAt',
                render: (time) => time ? moment(time).format('YYYY-MM-DD HH:mm:ss') : '-'
              },
              {
                title: '完成时间',
                dataIndex: 'completedAt',
                key: 'completedAt',
                render: (time) => time ? moment(time).format('YYYY-MM-DD HH:mm:ss') : '-'
              },
             {
              title: 'SQL配置',
              dataIndex: 'sql_json',
              key: 'sql_json',
              width: 500, // 可以适当减小宽度
              render: (sqlJson, record) => {
                // 格式化显示用的JSON
                let displayValue = '';
                try {
                  if (typeof sqlJson === 'string') {
                    const parsed = JSON.parse(sqlJson);
                    displayValue = JSON.stringify(parsed, null, 2);
                  } else if (typeof sqlJson === 'object') {
                    displayValue = JSON.stringify(sqlJson, null, 2);
                  } else {
                    displayValue = sqlJson || '';
                  }
                } catch (e) {
                  displayValue = sqlJson || '';
                }

                // 判断当前行是否处于编辑状态
                const isEditing = editingTaskId === record.id;

                if (!isEditing) {
                  // 非编辑状态 - 紧凑版本
                  return (
                    <div style={{
                      backgroundColor: '#f8f9fa',
                      padding: '8px',
                      borderRadius: '4px',
                      position: 'relative',
                      minHeight: '60px',
                      border: '1px solid #e9ecef'
                    }}>
                      <pre style={{
                        margin: 0,
                        whiteSpace: 'pre-wrap',
                        wordBreak: 'break-all',
                        fontSize: '12px',
                        fontFamily: "'Monaco', 'Menlo', 'Ubuntu Mono', monospace",
                        lineHeight: '1.3',
                        color: '#24292e',
                        maxHeight: '80px',
                        overflow: 'auto'
                      }}>
                        {displayValue || '{}'}
                      </pre>
                      <Button
                        type="text"
                        size="small"
                        icon={<EditOutlined />}
                        onClick={() => handleEdit(record)}
                        style={{
                          position: 'absolute',
                          top: 4,
                          right: 4,
                          padding: '2px 6px',
                          height: '24px',
                          fontSize: '12px',
                          backgroundColor: '#fff',
                          border: '1px solid #d0d7de',
                          borderRadius: '3px',
                          minWidth: 'auto'
                        }}
                      >
                        编辑
                      </Button>
                    </div>
                  );
                }

                // 编辑状态 - 紧凑版本
                return (
                  <div style={{ position: 'relative' }}>
                    <TextArea
                      value={editSqlValue}
                      rows={4} // 减少行数
                      style={{
                        fontFamily: "'Monaco', 'Menlo', 'Ubuntu Mono', monospace",
                        fontSize: '12px',
                        marginBottom: 8,
                        border: `1px solid ${theme.palette.primary.main}80`,
                        borderRadius: '4px',
                        padding: '8px',
                        lineHeight: '1.3',
                        backgroundColor: '#fafbfc'
                      }}
                      onChange={(e) => setEditSqlValue(e.target.value)}
                      autoSize={{ minRows: 4, maxRows: 8 }} // 调整自动调整范围
                    />
                    <div style={{
                      display: 'flex',
                      gap: 6,
                      justifyContent: 'flex-end',
                      alignItems: 'center'
                    }}>
                      <Button
                        size="small"
                        onClick={handleCancelEdit}
                        style={{
                          padding: '2px 8px',
                          height: '28px',
                          fontSize: '12px'
                        }}
                      >
                        取消
                      </Button>
                      <Button
                        type="primary"
                        size="small"
                        icon={<SaveOutlined />}
                        onClick={() => saveModifiedSql(record.id, editSqlValue)}
                        style={{
                          padding: '2px 8px',
                          height: '28px',
                          fontSize: '12px',
                          borderRadius: '3px'
                        }}
                      >
                        保存
                      </Button>
                    </div>
                  </div>
                );
              }
            },
              {
                title: '结果',
                key: 'action',
                render: (_, record) => {
                  let content = '-';
                  if (record.status === 'completed' && record.downloadInfo) {
                    try {
                      const downloadData = JSON.parse(record.downloadInfo);
                      if (downloadData.single_file) {
                        const fileName = downloadData.single_file.split(/[\\/]/).pop();
                        const baseURL = axios.defaults.baseURL || '';
                        const shouldPrependBaseURL = !downloadData.single_file.startsWith('http') &&
                                                  !downloadData.single_file.startsWith('s3://') &&
                                                  baseURL;
                        let downloadURL = downloadData.single_file;
                        if (shouldPrependBaseURL) {
                          const adjustedBaseURL = baseURL.endsWith('/') ? baseURL : baseURL + '/';
                          downloadURL = adjustedBaseURL + downloadData.single_file;
                        }

                        content = (
                          <a
                            href={downloadURL}
                            target="_blank"
                            rel="noopener noreferrer"
                            style={{ textDecoration: 'none', color: theme.palette.primary.main }}
                            download={fileName}
                          >
                            <Tag color="blue" size="small">
                              {fileName}
                            </Tag>
                          </a>
                        );
                      }
                    } catch (err) {
                      console.error('解析文件信息失败:', err);
                      content = <Tag color="red" size="small">解析失败</Tag>;
                    }
                  } else if (record.status === 'failed' && record.statusDetails) {
                    content = (
                      <div style={{ maxWidth: '150px' }}>
                        <Text color="red" size="small" style={{ wordBreak: 'break-word' }}>
                          {record.statusDetails}
                        </Text>
                      </div>
                    );
                  }
                  return content;
                }
              }
            ]}
            rowKey="id"
            pagination={{ pageSize: 10 }}
            emptyText="暂无任务历史记录"
          />
        </Card>
      )}
    </div>
  );
});

export default SqlQueryComponent;