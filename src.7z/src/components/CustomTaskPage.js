import React, { useState, useEffect } from 'react';
import {
  Box, Card, CardContent, CardHeader, Typography, Button,
  TextField, Grid, Divider, IconButton, Dialog, DialogTitle,
  DialogContent, DialogActions, Snackbar, Alert, Paper,
  Table, TableBody, TableCell, TableContainer, TableHead,
  TableRow, TablePagination, Chip, FormControl, InputLabel,
  Select, Tabs, Tab, Tooltip, CircularProgress, Switch,
  MenuItem, FormControlLabel, Accordion, AccordionSummary,
  AccordionDetails, LinearProgress, Stepper, Step, StepLabel,
  StepContent, Avatar, List, ListItem, ListItemText, ListItemIcon,
  Fab, InputAdornment, TabContext, TabPanel,useTheme
} from '@mui/material';
import {
  Add as AddIcon, Edit as EditIcon, Delete as DeleteIcon,
  PlayArrow as RunIcon, Save as SaveIcon, Cancel as CancelIcon,
  Email as EmailIcon, Code as CodeIcon, Description as ReportIcon,
  Description as DescriptionIcon, PlayArrow as PlayArrowIcon,
  DataObject as SqlIcon, Schedule as ScheduleIcon, Help as HelpIcon,
  ExpandMore as ExpandMoreIcon, ChevronRight as ChevronRightIcon,
  CheckCircle as SuccessIcon, Info as InfoIcon, People as PeopleIcon,
  AccessTime as TimeIcon, Error as ErrorIcon,
  AccessTime, Close as CloseIcon,
  Visibility as ViewIcon, Refresh as RefreshIcon,
  FileDownload as DownloadIcon, CopyAll as CopyIcon,
  CheckCircle as CheckCircleIcon, KeyboardArrowRight as ArrowRightIcon,
  KeyboardArrowLeft as ArrowLeftIcon, AddCircle as AddCircleIcon,
  RemoveCircle as RemoveCircleIcon, Send as SendIcon
} from '@mui/icons-material';

// 添加 date-fns 的格式化函数
import { formatDistanceToNow, format } from 'date-fns';

import axios from 'axios';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { dracula } from 'react-syntax-highlighter/dist/esm/styles/prism';

const CustomTaskPage = () => {
  // 状态管理
  const theme = useTheme();
  const [activeStep, setActiveStep] = useState(0);
  const [selectedTaskType, setSelectedTaskType] = useState('report'); // 用于UI选择的状态
  const [taskType, setTaskType] = useState('report'); // 默认任务类型
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [notification, setNotification] = useState({
    open: false,
    message: '',
    severity: 'success'
  });
  // 帮助面板展开状态
  const [expandedHelp, setExpandedHelp] = useState(false);
  
  // 新增：任务详情弹窗状态
  const [detailDialogOpen, setDetailDialogOpen] = useState(false);
  const [currentTaskDetail, setCurrentTaskDetail] = useState(null);

  // 任务编辑相关状态
  const [dialogOpen, setDialogOpen] = useState(false);
  const [currentTask, setCurrentTask] = useState(null);
  const [isNewTask, setIsNewTask] = useState(false);
  
  // 新增：任务执行中的加载状态
  const [executingTaskId, setExecutingTaskId] = useState(null);

  // 核心表单状态（区分共同部分和类型特有部分）
  const [formData, setFormData] = useState({
    // 共同部分
    common: {
      taskName: '',
      taskType: 'report', // 默认任务类型：sql/python/email
      summary: '',
      needEmail: false, // 是否需要发送邮件
      emailSubject: '',
      recipients: [],
      // 新增定时任务设置
      schedule: {
        enable: false,          // 是否启用定时
        type: 'daily',          // 定时类型：daily/weekly/monthly (预留扩展)
        daily: {
          hour: '08',           // 小时 (00-23)
          minute: '00'          // 分钟 (00-59)
        }
      }
    },
    // 类型特有部分
    specific: {
      // SQL任务特有
      sql: {
        sqlContent: '',
        dataDescription: ''
      },
      // Python任务特有
      python: {
        code: '',
        inputParams: {},
        outputType: 'text'
      },
      // 邮件报表特有（简化数据来源，直接关联SQL语句）
      report: {
        bodySections: [{ title: '', content: '', sql: '' }] // 每个段落可关联独立SQL
      }
    }
  });

  // 分页和筛选
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [filterType, setFilterType] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');

  // 加载任务列表
  useEffect(() => {
    fetchTasks();
  }, []);

  // 获取任务列表
  const fetchTasks = async () => {
    try {
      setLoading(true);
      const response = await axios.get('/api/pdtasks', { withCredentials: true });
      setTasks(Array.isArray(response.data.data) ? response.data.data : []);
      setError(null);
    } catch (err) {
      console.error('获取任务列表失败:', err);
      setError('获取任务列表失败，请刷新页面重试');
      showNotification('获取任务列表失败', 'error');
    } finally {
      setLoading(false);
    }
  };

  // 通知提示
  const showNotification = (message, severity = 'success') => {
    setNotification({ open: true, message, severity });
  };

  const handleCloseNotification = () => {
    setNotification(prev => ({ ...prev, open: false }));
  };
  const resetSteps = () => {
    setActiveStep(0);
  };
  // 步骤处理函数
  const handleNext = () => {
    // 第一步：选择任务类型后，需要同步到表单数据
    if (activeStep === 0) {
      handleCommonChange('taskType', taskType);
    }
    setActiveStep((prevStep) => prevStep + 1);
  };

  const handleBack = () => {
    setActiveStep((prevStep) => prevStep - 1);
  };

  // 打开新建任务对话框
  const handleAddTask = () => {
    setCurrentTask(null);
    setIsNewTask(true);
    setFormData({
      common: {
        taskName: '',
        taskType: 'report',
        summary: '',
        needEmail: false,
        emailSubject: '',
        recipients: [],
        schedule: {
          enable: false,
          type: 'daily',
          daily: {
            hour: '08',
            minute: '00'
          }
        }
      },
      specific: {
        sql: { sqlContent: '', dataDescription: '' },
        python: { code: '', inputParams: { param1: '' }, outputType: 'text' },
        report: { bodySections: [{ title: '', content: '', sql: '' }] }
      }
    });
    setDialogOpen(true);
    resetSteps();
    setTaskType('report');
  };

  // 打开编辑任务对话框
  const handleEditTask = (task) => {
    setCurrentTask(task);
    setIsNewTask(false);
    setFormData({
      common: {
        taskName: task.taskName,
        taskType: task.taskType || 'report',
        summary: task.common?.summary || '',
        needEmail: task.common?.needEmail || false,
        emailSubject: task.common?.emailSubject || '',
        recipients: task.common?.recipients || [],
        // 初始化定时设置
        schedule: task.common?.schedule || {
          enable: false,
          type: 'daily',
          daily: {
            hour: '08',
            minute: '00'
          }
        }
      },
      specific: task.specific || {
        sql: { sqlContent: '', dataDescription: '' },
        python: { code: '', inputParams: { param1: '' }, outputType: 'text' },
        report: { bodySections: [{ title: '', content: '', sql: '' }] }
      }
    });
    setDialogOpen(true);
  };
  
  // 新增：打开任务详情对话框
  const handleViewDetail = (task) => {
    setCurrentTaskDetail(task);
    setDetailDialogOpen(true);
  };

  // 处理共同部分字段变化
  const handleCommonChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      common: { ...prev.common, [field]: value }
    }));
  };

  // 处理定时设置变化
  const handleScheduleChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      common: {
        ...prev.common,
        schedule: { ...prev.common.schedule, [field]: value }
      }
    }));
  };

  // 处理每日定时设置变化
  const handleDailyScheduleChange = (field, value) => {
    // 验证时间格式
    if (field === 'hour' && (value < 0 || value > 23)) return;
    if (field === 'minute' && (value < 0 || value > 59)) return;
    
    setFormData(prev => ({
      ...prev,
      common: {
        ...prev.common,
        schedule: {
          ...prev.common.schedule,
          daily: { ...prev.common.schedule.daily, [field]: value.padStart(2, '0') }
        }
      }
    }));
  };

  // 处理特有部分字段变化（根据任务类型）
  const handleSpecificChange = (field, value) => {
    const { taskType } = formData.common;
    setFormData(prev => ({
      ...prev,
      specific: {
        ...prev.specific,
        [taskType]: { ...prev.specific[taskType], [field]: value }
      }
    }));
  };

  // 处理收件人输入
  const handleRecipientsChange = (e) => {
    const recipients = e.target.value
      .split(',')
      .map(r => r.trim())
      .filter(r => r);
    handleCommonChange('recipients', recipients);
  };

  // ------------------------------
  // SQL任务特有方法
  // ------------------------------
  const handleSqlChange = (field, value) => {
    handleSpecificChange(field, value);
  };

  // ------------------------------
  // Python任务特有方法
  // ------------------------------
  const addPythonParam = () => {
    const { inputParams } = formData.specific.python;
    const newKey = `param${Object.keys(inputParams).length + 1}`;
    handleSpecificChange('inputParams', { ...inputParams, [newKey]: '' });
  };

  const removePythonParam = (key) => {
    if (Object.keys(formData.specific.python.inputParams).length <= 1) {
      showNotification('至少保留一个参数', 'warning');
      return;
    }
    const { inputParams } = formData.specific.python;
    const newParams = { ...inputParams };
    delete newParams[key];
    handleSpecificChange('inputParams', newParams);
  };

  const updatePythonParam = (key, value) => {
    const { inputParams } = formData.specific.python;
    handleSpecificChange('inputParams', { ...inputParams, [key]: value });
  };

  const updatePythonParamKey = (oldKey, newKey) => {
    const { inputParams } = formData.specific.python;
    if (!newKey.trim()) {
      showNotification('参数名称不能为空', 'warning');
      return;
    }
    const newParams = { ...inputParams };
    const value = newParams[oldKey];
    delete newParams[oldKey];
    newParams[newKey] = value;
    handleSpecificChange('inputParams', newParams);
  };

  // ------------------------------
  // 邮件任务特有方法（简化版）
  // ------------------------------
  const addEmailSection = () => {
    const { bodySections } = formData.specific.email;
    const newSections = [...bodySections, { title: '', content: '', sql: '' }];
    setFormData(prev => ({
      ...prev,
      specific: {
        ...prev.specific,
        email: {
          ...prev.specific.email,
          bodySections: newSections
        }
      }
    }));
  };

  const removeEmailSection = (index) => {
    if (formData.specific.email.bodySections.length <= 1) {
      showNotification('至少保留一个邮件段落', 'warning');
      return;
    }
    const newSections = formData.specific.email.bodySections.filter((_, i) => i !== index);
    setFormData(prev => ({
      ...prev,
      specific: {
        ...prev.specific,
        email: {
          ...prev.specific.email,
          bodySections: newSections
        }
      }
    }));
  };

  const updateReportSection = (index, field, value) => {
    const newSections = [...formData.specific.report.bodySections];
    newSections[index][field] = value;
    setFormData(prev => ({
      ...prev,
      specific: {
        ...prev.specific,
        report: {
          ...prev.specific.email,
          bodySections: newSections
        }
      }
    }));
  };

  // 渲染步骤式新建任务对话框
  const renderTaskCreationDialog = () => {
    const steps = [
      {
        label: '选择任务类型',
        description: '选择您要创建的任务类型',
        content: (
          <Box sx={{ p: 2 }}>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
              根据您的需求选择适合的任务类型
            </Typography>
            <Grid container spacing={2}>
              <Grid item xs={12} md={4}>
                <Card 
                  sx={{ 
                    cursor: 'pointer',
                    border: taskType === 'report' ? 2 : 1,
                    borderColor: taskType === 'report' ? 'primary.main' : 'divider',
                    transition: 'all 0.3s ease',
                    '&:hover': {
                      transform: 'translateY(-4px)',
                      boxShadow: 4,
                      borderColor: 'primary.main'
                    }
                  }}
                  onClick={() => setTaskType('report')}
                >
                  <CardContent sx={{ textAlign: 'center', p: 3 }}>
                    <Avatar sx={{ 
                      bgcolor: taskType === 'report' ? 'primary.main' : 'grey.200', 
                      color: taskType === 'report' ? 'white' : 'grey.600',
                      width: 56, 
                      height: 56, 
                      mx: 'auto',
                      mb: 2
                    }}>
                      <ReportIcon />
                    </Avatar>
                    <Typography variant="h6" gutterBottom>
                      报表
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      生成报表，适合定期报告
                    </Typography>
                  </CardContent>
                </Card>
              </Grid>

              <Grid item xs={12} md={4}>
                <Card 
                  sx={{ 
                    cursor: 'pointer',
                    border: taskType === 'sql' ? 2 : 1,
                    borderColor: taskType === 'sql' ? 'primary.main' : 'divider',
                    transition: 'all 0.3s ease',
                    '&:hover': {
                      transform: 'translateY(-4px)',
                      boxShadow: 4,
                      borderColor: 'primary.main'
                    }
                  }}
                  onClick={() => setTaskType('sql')}
                >
                  <CardContent sx={{ textAlign: 'center', p: 3 }}>
                    <Avatar sx={{ 
                      bgcolor: taskType === 'sql' ? 'primary.main' : 'grey.200', 
                      color: taskType === 'sql' ? 'white' : 'grey.600',
                      width: 56, 
                      height: 56, 
                      mx: 'auto',
                      mb: 2
                    }}>
                      <SqlIcon />
                    </Avatar>
                    <Typography variant="h6" gutterBottom>
                      SQL任务
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      定期执行SQL查询生成数据
                    </Typography>
                  </CardContent>
                </Card>
              </Grid>
              
              <Grid item xs={12} md={4}>
                <Card 
                  sx={{ 
                    cursor: 'pointer',
                    border: taskType === 'python' ? 2 : 1,
                    borderColor: taskType === 'python' ? 'primary.main' : 'divider',
                    transition: 'all 0.3s ease',
                    '&:hover': {
                      transform: 'translateY(-4px)',
                      boxShadow: 4,
                      borderColor: 'primary.main'
                    }
                  }}
                  onClick={() => setTaskType('python')}
                >
                  <CardContent sx={{ textAlign: 'center', p: 3 }}>
                    <Avatar sx={{ 
                      bgcolor: taskType === 'python' ? 'primary.main' : 'grey.200', 
                      color: taskType === 'python' ? 'white' : 'grey.600',
                      width: 56, 
                      height: 56, 
                      mx: 'auto',
                      mb: 2
                    }}>
                      <CodeIcon />
                    </Avatar>
                    <Typography variant="h6" gutterBottom>
                      Python脚本
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      执行Python代码[复杂数据处理]
                    </Typography>
                  </CardContent>
                </Card>
              </Grid>
              
              
            </Grid>
          </Box>
        )
      },
      {
        label: '基本信息',
        description: '填写任务的基本信息',
        content: (
          <Box sx={{ p: 2 }}>
            <Grid container spacing={3}>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="任务名称"
                  value={formData.common.taskName}
                  onChange={(e) => handleCommonChange('taskName', e.target.value)}
                  variant="outlined"
                  placeholder="请输入有意义的任务名称"
                  helperText="请使用清晰的任务名称，便于后续识别和管理"
                />
              </Grid>
              
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="任务描述"
                  value={formData.common.summary}
                  onChange={(e) => handleCommonChange('summary', e.target.value)}
                  variant="outlined"
                  multiline
                  rows={3}
                  placeholder="描述此任务的目的和功能"
                  helperText="详细描述有助于他人理解此任务的用途"
                />
              </Grid>
              
              <Grid item xs={12}>
                <FormControlLabel
                  control={
                    <Switch
                      checked={formData.common.needEmail}
                      onChange={(e) => handleCommonChange('needEmail', e.target.checked)}
                      color="primary"
                    />
                  }
                  label="启用邮件通知"
                />
                {formData.common.needEmail && (
                  <Box sx={{ mt: 2, pl: 3, borderLeft: 2, borderColor: 'primary.light' }}>
                    <Grid container spacing={2}>
                      <Grid item xs={12}>
                        <TextField
                          fullWidth
                          label="邮件主题"
                          value={formData.common.emailSubject}
                          onChange={(e) => handleCommonChange('emailSubject', e.target.value)}
                          variant="outlined"
                          size="small"
                          placeholder="请输入邮件主题"
                        />
                      </Grid>
                      <Grid item xs={12}>
                        <TextField
                          fullWidth
                          label="收件人"
                          value={formData.common.recipients.join(', ')}
                          onChange={handleRecipientsChange}
                          variant="outlined"
                          size="small"
                          placeholder="请输入邮箱地址，多个地址用逗号分隔"
                          helperText="例如: user1@example.com, user2@example.com"
                        />
                      </Grid>
                    </Grid>
                  </Box>
                )}
              </Grid>
            </Grid>
          </Box>
        )
      },
      {
        label: '任务配置',
        description: `配置${taskType === 'sql' ? 'SQL' : taskType === 'python' ? 'Python' : '邮件'}任务`,
        content: (
          <Box sx={{ p: 2 }}>
            {taskType === 'sql' && renderSqlContent()}
            {taskType === 'python' && renderPythonContent()}
            {taskType === 'report' && renderEmailContent()}
          </Box>
        )
      },
      {
        label: '定时设置',
        description: '配置任务执行计划',
        content: (
          <Box sx={{ p: 2 }}>
            {renderScheduleSettings()}
          </Box>
        )
      },
      {
        label: '确认信息',
        description: '确认任务配置信息',
        content: (
          <Box sx={{ p: 2 }}>
            <Typography variant="h6" gutterBottom>
              任务概览
            </Typography>
            
            <Grid container spacing={3}>
              <Grid item xs={12} md={6}>
                <Card variant="outlined" sx={{ p: 2 }}>
                  <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                    基本信息
                  </Typography>
                  <List dense>
                    <ListItem>
                      <ListItemText 
                        primary="任务名称" 
                        secondary={formData.common.taskName || '未设置'} 
                      />
                    </ListItem>
                    <ListItem>
                      <ListItemText 
                        primary="任务类型" 
                        secondary={
                          taskType === 'sql' ? 'SQL任务' : 
                          taskType === 'python' ? 'Python脚本' : '邮件报表'
                        } 
                      />
                    </ListItem>
                    <ListItem>
                      <ListItemText 
                        primary="任务描述" 
                        secondary={formData.common.summary || '未设置'} 
                      />
                    </ListItem>
                  </List>
                </Card>
              </Grid>
              
              <Grid item xs={12} md={6}>
                <Card variant="outlined" sx={{ p: 2 }}>
                  <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                    通知设置
                  </Typography>
                  <List dense>
                    <ListItem>
                      <ListItemText 
                        primary="邮件通知" 
                        secondary={formData.common.needEmail ? '启用' : '禁用'} 
                      />
                    </ListItem>
                    {formData.common.needEmail && (
                      <>
                        <ListItem>
                          <ListItemText 
                            primary="邮件主题" 
                            secondary={formData.common.emailSubject || '未设置'} 
                          />
                        </ListItem>
                        <ListItem>
                          <ListItemText 
                            primary="收件人" 
                            secondary={
                              formData.common.recipients.length > 0 
                                ? formData.common.recipients.join(', ') 
                                : '未设置'
                            } 
                          />
                        </ListItem>
                      </>
                    )}
                  </List>
                </Card>
              </Grid>
              
              <Grid item xs={12}>
                <Card variant="outlined" sx={{ p: 2 }}>
                  <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                    定时设置
                  </Typography>
                  <List dense>
                    <ListItem>
                      <ListItemText 
                        primary="定时执行" 
                        secondary={formData.common.schedule.enable ? '启用' : '禁用'} 
                      />
                    </ListItem>
                    {formData.common.schedule.enable && (
                      <ListItem>
                        <ListItemText 
                          primary="执行时间" 
                          secondary={`每日 ${formData.common.schedule.daily.hour}:${formData.common.schedule.daily.minute}`} 
                        />
                      </ListItem>
                    )}
                  </List>
                </Card>
              </Grid>
            </Grid>
          </Box>
        )
      }
    ];

    return (
      <Dialog
        open={dialogOpen}
        onClose={() => setDialogOpen(false)}
        fullWidth
        maxWidth="md"
        PaperProps={{
          sx: {
            maxHeight: '90vh',
            overflow: 'auto',
            borderRadius: 2,
            boxShadow: 8
          }
        }}
      >
        <DialogTitle sx={{ 
          pb: 1, 
          borderBottom: 1, 
          borderColor: 'divider', 
          px: 3, 
          pt: 2,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between'
        }}>
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <AddIcon sx={{ mr: 1, color: 'primary.main' }} />
            <Typography variant="h6">
              {isNewTask ? '新建任务' : '编辑任务'}
            </Typography>
          </Box>
          <IconButton onClick={() => setDialogOpen(false)} size="small">
            <CloseIcon />
          </IconButton>
        </DialogTitle>
        
        <DialogContent sx={{ p: 0 }}>
          <Stepper activeStep={activeStep} orientation="vertical" sx={{ p: 2 }}>
            {steps.map((step, index) => (
              <Step key={step.label}>
                <StepLabel 
                  optional={
                    index === steps.length - 1 ? null : (
                      <Typography variant="caption">{step.description}</Typography>
                    )
                  }
                >
                  {step.label}
                </StepLabel>
                <StepContent>
                  {step.content}
                  <Box sx={{ mb: 2, mt: 2 }}>
                    <div>
                      <Button
                        variant="contained"
                        onClick={index === steps.length - 1 ? handleSaveTask : handleNext}
                        sx={{ mt: 1, mr: 1 }}
                        endIcon={index === steps.length - 1 ? <SendIcon /> : <ArrowRightIcon />}
                      >
                        {index === steps.length - 1 ? '创建任务' : '继续'}
                      </Button>
                      <Button
                        disabled={index === 0}
                        onClick={handleBack}
                        sx={{ mt: 1, mr: 1 }}
                        startIcon={<ArrowLeftIcon />}
                      >
                        上一步
                      </Button>
                    </div>
                  </Box>
                </StepContent>
              </Step>
            ))}
          </Stepper>
          
          {activeStep === steps.length && (
            <Paper square elevation={0} sx={{ p: 3 }}>
              <Typography>所有步骤已完成 - 任务已创建</Typography>
              <Button onClick={handleSaveTask} sx={{ mt: 1, mr: 1 }}>
                查看任务
              </Button>
            </Paper>
          )}
        </DialogContent>
      </Dialog>
    );
  };


  // ------------------------------
  // 表单验证
  // ------------------------------
  const validateForm = () => {
    const { common, specific } = formData;

    // 共同部分验证
    if (!common.taskName.trim()) {
      showNotification('请输入任务名称', 'error');
      return false;
    }

    // 邮件相关验证
    if (common.needEmail) {
      if (!common.emailSubject.trim()) {
        showNotification('请输入邮件主题', 'error');
        return false;
      }
      if (common.recipients.length === 0) {
        showNotification('请输入邮件接收人', 'error');
        return false;
      }
    }

    // 定时任务验证
    if (common.schedule.enable) {
      const { hour, minute } = common.schedule.daily;
      if (hour < 0 || hour > 23 || minute < 0 || minute > 59) {
        showNotification('请设置有效的执行时间', 'error');
        return false;
      }
    }

    // 类型特有验证
    switch (common.taskType) {
      case 'sql':
        if (!specific.sql?.sqlContent?.trim()) {
          showNotification('请输入SQL语句', 'error');
          return false;
        }
        break;
      case 'python':
        if (!specific.python?.code?.trim()) {
          showNotification('请输入Python代码', 'error');
          return false;
        }
        break;
      case 'report':
        if (!specific.report?.bodySections || specific.report.bodySections.length === 0) {
          showNotification('请至少添加一个邮件段落', 'error');
          return false;
        }
        // 修复：检查每个邮件段落的内容
        for (let i = 0; i < specific.report.bodySections.length; i++) {
          const section = specific.report.bodySections[i];
          if (!section.title.trim()) {
            showNotification(`请填写第 ${i + 1} 个段落的标题`, 'error');
            return false;
          }
          // 内容和SQL至少填一项
          if (!section.content.trim() && !section.sql.trim()) {
            showNotification(`第 ${i + 1} 个段落需要填写内容或SQL语句`, 'error');
            return false;
          }
          // 如果填写了SQL，需要验证SQL内容
          if (section.sql.trim() && !section.sql.trim().toLowerCase().startsWith('select')) {
            showNotification(`第 ${i + 1} 个段落的SQL语句必须以SELECT开头`, 'error');
            return false;
          }
        }
        break;
    }

    return true;
  };

  // 保存任务
  const handleSaveTask = async () => {
    if (!validateForm()) return;

    try {
      const taskData = {
        taskName: formData.common.taskName,
        taskType: formData.common.taskType,
        common: formData.common,
        specific: formData.specific
      };
      //[formData.common.taskType]
      let response;
      if (isNewTask) {
        response = await axios.post('/api/pdtasks', taskData, { withCredentials: true });
      } else {
        response = await axios.put(`/api/pdtasks/${currentTask.id}`, taskData, { withCredentials: true });
      }

      if (response.data.success) {
        showNotification(isNewTask ? '任务创建成功' : '任务更新成功');
        setDialogOpen(false);
        fetchTasks();
      } else {
        showNotification(response.data.message || '操作失败', 'error');
      }
    } catch (err) {
      console.error('保存任务失败:', err);
      showNotification('保存任务失败，请重试', 'error');
    }
  };

  // 删除/执行任务
  const handleDeleteTask = async (id) => {
    if (!window.confirm('确定要删除这个任务吗？此操作不可撤销。')) return;
    try {
      const response = await axios.delete(`/api/pdtasks/${id}`, { withCredentials: true });
      if (response.data.success) {
        showNotification('任务删除成功');
        fetchTasks();
      } else {
        showNotification(response.data.message || '删除失败', 'error');
      }
    } catch (err) {
      console.error('删除任务失败:', err);
      showNotification('删除任务失败，请重试', 'error');
    }
  };

  const handleRunTask = async (task) => {
    try {
      // 标记任务为执行中
      setExecutingTaskId(task.id);
      
      const response = await axios.post(`/api/pdtasks/${task.id}/execute`, {}, { withCredentials: true });
      if (response.data.success) {
        showNotification('任务已开始执行');
        // 轮询检查任务状态
        const checkStatus = async () => {
          const res = await axios.get(`/api/pdtasks/${task.id}`, { withCredentials: true });
          if (res.data.data.status !== 'running') {
            setExecutingTaskId(null);
            fetchTasks();
            return;
          }
          // 继续轮询
          setTimeout(checkStatus, 2000);
        };
        checkStatus();
      } else {
        setExecutingTaskId(null);
        showNotification(response.data.message || '执行失败', 'error');
      }
    } catch (err) {
      setExecutingTaskId(null);
      console.error('执行任务失败:', err);
      showNotification('执行任务失败，请重试', 'error');
    }
  };

  // 分页和筛选处理
  const handleChangePage = (event, newPage) => setPage(newPage);
  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  // 新增：多条件筛选
  const filteredTasks = Array.isArray(tasks)
    ? tasks.filter(task => 
        (filterType === 'all' || task.taskType === filterType) &&
        (filterStatus === 'all' || task.status === filterStatus)
      )
    : [];

  // ------------------------------
  // 渲染辅助函数
  // ------------------------------
  // 渲染任务状态标签
  const renderStatusChip = (status) => {
    const statusMap = {
      'pending': { color: 'default', label: '待执行', bg: '#f0f0f0', icon: <AccessTime /> },
      'running': { color: 'info', label: '执行中', bg: '#e3f2fd', icon: <CircularProgress size={16} /> },
      'completed': { color: 'success', label: '已完成', bg: '#e8f5e9', icon: <SuccessIcon /> },
      'failed': { color: 'error', label: '失败', bg: '#ffebee', icon: <ErrorIcon /> }
    };
    const { color, label, bg, icon } = statusMap[status] || statusMap.pending;
    return (
      <Chip 
        label={
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            {icon && <Box sx={{ mr: 0.5 }}>{icon}</Box>}
            {label}
          </Box>
        }
        color={color} 
        size="small" 
        sx={{ 
          ml: 1, 
          backgroundColor: bg,
          '& .MuiChip-label': { fontWeight: 500, display: 'flex', alignItems: 'center' }
        }}
      />
    );
  };

  // 渲染定时任务信息
  const renderScheduleInfo = (schedule) => {
    if (!schedule?.enable) {
      return <Chip label="未启用定时" color="default" size="small" />;
    }
    
    switch (schedule.type) {
      case 'daily':
        return (
          <Chip 
            label={`每日 ${schedule.daily.hour}:${schedule.daily.minute}`} 
            color="primary" 
            size="small"
            startIcon={<TimeIcon fontSize="small" />}
          />
        );
      default:
        return <Chip label="定时任务" color="primary" size="small" />;
    }
  };

  // 渲染任务类型图标和文本
  const renderTaskType = (taskType) => {
    const typeMap = {
      'sql': { 
        icon: <SqlIcon fontSize="small" sx={{ mr: 1, color: '#3498db' }} />, 
        text: 'SQL任务',
        bg: '#e3f2fd'
      },
      'python': { 
        icon: <CodeIcon fontSize="small" sx={{ mr: 1, color: '#2ecc71' }} />, 
        text: 'Python脚本',
        bg: '#e8f5e9'
      },
      'report': { 
        icon: <ReportIcon fontSize="small" sx={{ mr: 1, color: '#e67e22' }} />, 
        text: '报表',
        bg: '#fff3e0'
      }
    };
    const { icon, text, bg } = typeMap[taskType] || { 
      icon: <ReportIcon fontSize="small" sx={{ mr: 1 }} />, 
      text: '其他任务',
      bg: '#f5f5f5'
    };
    return (
      <Box sx={{ 
        display: 'flex', 
        alignItems: 'center',
        backgroundColor: bg,
        px: 1.5,
        py: 0.5,
        borderRadius: 1,
        fontSize: '0.85rem'
      }}>
        {icon}
        {text}
      </Box>
    );
  };

  // 渲染定时设置区域
  const renderScheduleSettings = () => (
    <Card sx={{ 
      mt: 2, 
      boxShadow: 2, 
      transition: '0.3s',
      borderLeft: 4,
      borderLeftColor: '#5c6bc0',
      '&:hover': { boxShadow: 3 }
    }}>
      <CardHeader 
        title="定时执行设置" 
        sx={{ 
          py: 1.5, 
          backgroundColor: '#f3e5f5',
          borderBottom: 1,
          borderColor: 'divider'
        }} 
      />
      <CardContent sx={{ py: 2 }}>
        <Grid container spacing={2}>
          <Grid item xs={12}>
            <FormControlLabel
              control={
                <Switch
                  checked={formData.common.schedule.enable}
                  onChange={(e) => handleScheduleChange('enable', e.target.checked)}
                  color="primary"
                />
              }
              label="启用定时执行"
            />
          </Grid>

          {formData.common.schedule.enable && (
            <>
              <Grid item xs={12} sx={{ pl: 4 }}>
                <Typography variant="body2" color="text.secondary" sx={{ mb: 2, fontWeight: 500 }}>
                  执行频率：每日
                </Typography>
                
                <Grid container spacing={2} alignItems="center">
                  <Grid item xs={12} sm={3}>
                    <Typography variant="body2">执行时间：</Typography>
                  </Grid>
                  <Grid item xs={5} sm={3}>
                    <TextField
                      fullWidth
                      label="小时"
                      value={formData.common.schedule.daily.hour}
                      onChange={(e) => handleDailyScheduleChange('hour', e.target.value)}
                      variant="outlined"
                      size="small"
                      inputProps={{ 
                        type: 'number',
                        min: 0,
                        max: 23,
                        style: { textAlign: 'center' }
                      }}
                    />
                  </Grid>
                  <Grid item xs={2} sx={{ textAlign: 'center' }}>
                    <Typography>:</Typography>
                  </Grid>
                  <Grid item xs={5} sm={3}>
                    <TextField
                      fullWidth
                      label="分钟"
                      value={formData.common.schedule.daily.minute}
                      onChange={(e) => handleDailyScheduleChange('minute', e.target.value)}
                      variant="outlined"
                      size="small"
                      inputProps={{ 
                        type: 'number',
                        min: 0,
                        max: 59,
                        style: { textAlign: 'center' }
                      }}
                    />
                  </Grid>
                </Grid>
              </Grid>
            </>
          )}
        </Grid>
      </CardContent>
    </Card>
  );

  // ------------------------------
  // 渲染不同任务类型的表单内容
  // ------------------------------
  const renderSqlContent = () => (
    <Card sx={{ mt: 2, boxShadow: 2, transition: '0.3s', '&:hover': { boxShadow: 3 } }}>
      <CardHeader 
        title="SQL任务设置" 
        sx={{ 
          py: 1.5, 
          backgroundColor: '#f5f9ff',
          borderBottom: 1,
          borderColor: 'divider'
        }} 
      />
      <CardContent sx={{ py: 2 }}>
        <Grid container spacing={2}>
          <Grid item xs={12}>
            <TextField
              fullWidth
              label="数据说明"
              value={formData.specific.sql.dataDescription}
              onChange={(e) => handleSqlChange('dataDescription', e.target.value)}
              variant="outlined"
              size="small"
              placeholder="描述该SQL的用途和返回数据格式"
              sx={{ 
                '& .MuiOutlinedInput-root': {
                  '& fieldset': { borderColor: '#bbdefb' },
                  '&:hover fieldset': { borderColor: '#90caf9' },
                }
              }}
            />
          </Grid>
          <Grid item xs={12}>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 1, fontWeight: 500 }}>
              SQL语句（仅支持SELECT查询）*
            </Typography>
            <Box sx={{ 
              border: 1, 
              borderColor: formData.specific.sql.sqlContent.trim() ? '#bbdefb' : '#f44336', 
              borderRadius: 1, 
              overflow: 'hidden',
              transition: '0.3s',
              '&:hover': { borderColor: formData.specific.sql.sqlContent.trim() ? '#90caf9' : '#f44336' }
            }}>
              <SyntaxHighlighter
                language="sql"
                style={dracula}
                customStyle={{ margin: 0, padding: '1rem', fontSize: '0.875rem' }}
              >
                {formData.specific.sql.sqlContent || '-- 请输入SQL语句'}
              </SyntaxHighlighter>
              <TextField
                fullWidth
                value={formData.specific.sql.sqlContent}
                onChange={(e) => handleSqlChange('sqlContent', e.target.value)}
                variant="outlined"
                multiline
                rows={6}
                hidden
                inputProps={{ style: { fontFamily: 'monospace' } }}
                error={!formData.specific.sql.sqlContent.trim()}
                helperText={!formData.specific.sql.sqlContent.trim() ? 'SQL语句不能为空' : ''}
              />
            </Box>
            {formData.specific.sql.sqlContent.trim() && 
             !formData.specific.sql.sqlContent.trim().toLowerCase().startsWith('select') && (
              <Typography variant="caption" color="error" sx={{ mt: 1, display: 'block' }}>
                SQL语句必须以SELECT开头
              </Typography>
            )}
          </Grid>
        </Grid>
      </CardContent>
    </Card>
  );

  const renderPythonContent = () => (
    <Card sx={{ mt: 2, boxShadow: 2, transition: '0.3s', '&:hover': { boxShadow: 3 } }}>
      <CardHeader 
        title="Python脚本设置" 
        sx={{ 
          py: 1.5, 
          backgroundColor: '#f1f8e9',
          borderBottom: 1,
          borderColor: 'divider'
        }} 
      />
      <CardContent sx={{ py: 2 }}>
        <Grid container spacing={2}>
          <Grid item xs={12}>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 1, fontWeight: 500 }}>
              Python代码
            </Typography>
            <Box sx={{ 
              border: 1, 
              borderColor: '#c8e6c9', 
              borderRadius: 1, 
              overflow: 'hidden',
              transition: '0.3s',
              '&:hover': { borderColor: '#a5d6a7' }
            }}>
              <SyntaxHighlighter
                language="python"
                style={dracula}
                customStyle={{ margin: 0, padding: '1rem', fontSize: '0.875rem' }}
              >
                {formData.specific.python.code}
              </SyntaxHighlighter>
              <TextField
                fullWidth
                value={formData.specific.python.code}
                onChange={(e) => handleSpecificChange('code', e.target.value)}
                variant="outlined"
                multiline
                rows={6}
                hidden
                inputProps={{ style: { fontFamily: 'monospace' } }}
              />
            </Box>
          </Grid>

          <Grid item xs={12}>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 1, fontWeight: 500 }}>
              输入参数
            </Typography>
            {Object.entries(formData.specific.python.inputParams).map(([key, value], index) => (
              <Grid container spacing={1} key={key} sx={{ mb: 1 }}>
                <Grid item xs={4}>
                  <TextField
                    fullWidth
                    label={`参数 ${index + 1} 名称`}
                    value={key}
                    onChange={(e) => updatePythonParamKey(key, e.target.value)}
                    variant="outlined"
                    size="small"
                    sx={{ 
                      '& .MuiOutlinedInput-root': {
                        '& fieldset': { borderColor: '#c8e6c9' },
                      }
                    }}
                  />
                </Grid>
                <Grid item xs={7}>
                  <TextField
                    fullWidth
                    label={`参数 ${index + 1} 值`}
                    value={value}
                    onChange={(e) => updatePythonParam(key, e.target.value)}
                    variant="outlined"
                    size="small"
                    sx={{ 
                      '& .MuiOutlinedInput-root': {
                        '& fieldset': { borderColor: '#c8e6c9' },
                      }
                    }}
                  />
                </Grid>
                <Grid item xs={1} sx={{ display: 'flex', alignItems: 'center' }}>
                  <IconButton size="small" color="error" onClick={() => removePythonParam(key)}>
                    <DeleteIcon fontSize="small" />
                  </IconButton>
                </Grid>
              </Grid>
            ))}
            <Button
              variant="outlined"
              startIcon={<AddIcon fontSize="small" />}
              onClick={addPythonParam}
              size="small"
              sx={{ 
                borderColor: '#a5d6a7',
                color: '#2e7d32',
                '&:hover': {
                  backgroundColor: '#f1f8e9',
                  borderColor: '#81c784'
                }
              }}
            >
              添加参数
            </Button>
          </Grid>

          <Grid item xs={12}>
            <FormControl size="small" sx={{ mt: 1, minWidth: 200 }}>
              <InputLabel>输出类型</InputLabel>
              <Select
                value={formData.specific.python.outputType}
                label="输出类型"
                onChange={(e) => handleSpecificChange('outputType', e.target.value)}
              >
                <MenuItem value="text">文本</MenuItem>
                <MenuItem value="table">表格</MenuItem>
                <MenuItem value="chart">图表</MenuItem>
              </Select>
            </FormControl>
          </Grid>
        </Grid>
      </CardContent>
    </Card>
  );

  // 简化版邮件报表内容（直接关联SQL）
  const renderEmailContent = () => (
    <Card sx={{ mt: 2, boxShadow: 2, transition: '0.3s', '&:hover': { boxShadow: 3 } }}>
      <CardHeader 
        title="邮件报表设置" 
        sx={{ 
          py: 1.5, 
          backgroundColor: '#fff8e1',
          borderBottom: 1,
          borderColor: 'divider'
        }} 
      />
      <CardContent sx={{ py: 2 }}>
        <Grid container spacing={2}>
          <Grid item xs={12}>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 2, fontWeight: 500 }}>
              邮件内容段落（每个段落可直接填写内容或通过SQL查询生成）
            </Typography>
            
            {formData.specific.report.bodySections.map((section, index) => (
              <Card key={index} sx={{ 
                mb: 2, 
                boxShadow: 1, 
                borderLeft: 4,
                borderLeftColor: '#ffb74d',
                transition: '0.3s',
                '&:hover': { boxShadow: 2 }
              }}>
                <CardContent sx={{ p: 2 }}>
                  <Grid container spacing={2}>
                    <Grid item xs={12}>
                      <TextField
                        fullWidth
                        label={`段落 ${index + 1} 标题 *`}
                        value={section.title}
                        onChange={(e) => updateReportSection(index, 'title', e.target.value)}
                        variant="outlined"
                        size="small"
                        sx={{ 
                          '& .MuiOutlinedInput-root': {
                            '& fieldset': { borderColor: '#ffe082' },
                          }
                        }}
                        error={!section.title.trim()}
                        helperText={!section.title.trim() ? '标题不能为空' : ''}
                      />
                    </Grid>
                    <Grid item xs={12}>
                      <TextField
                        fullWidth
                        label={`段落 ${index + 1} 静态内容（可选）`}
                        value={section.content}
                        onChange={(e) => updateReportSection(index, 'content', e.target.value)}
                        variant="outlined"
                        multiline
                        rows={2}
                        size="small"
                        sx={{ 
                          '& .MuiOutlinedInput-root': {
                            '& fieldset': { borderColor: '#ffe082' },
                          }
                        }}
                        placeholder="直接填写静态内容（与SQL二选一）"
                      />
                    </Grid>
                    <Grid item xs={12}>
                      <TextField
                        fullWidth
                        label={`段落 ${index + 1} SQL查询（可选）`}
                        value={section.sql}
                        onChange={(e) => updateReportSection(index, 'sql', e.target.value)}
                        variant="outlined"
                        multiline
                        rows={2}
                        size="small"
                        sx={{ 
                          '& .MuiOutlinedInput-root': {
                            '& fieldset': { borderColor: '#ffe082' },
                          }
                        }}
                        placeholder="通过SQL查询生成内容（与静态内容二选一），必须以SELECT开头"
                        error={section.sql.trim() && !section.sql.trim().toLowerCase().startsWith('select')}
                        helperText={
                          section.sql.trim() && !section.sql.trim().toLowerCase().startsWith('select') 
                            ? 'SQL语句必须以SELECT开头' 
                            : ''
                        }
                      />
                    </Grid>
                    <Grid item xs={12} sx={{ display: 'flex', justifyContent: 'flex-end' }}>
                      <IconButton 
                        size="small" 
                        color="error" 
                        onClick={() => removeEmailSection(index)}
                        sx={{ transition: '0.3s', '&:hover': { transform: 'scale(1.1)' } }}
                      >
                        <DeleteIcon fontSize="small" />
                      </IconButton>
                    </Grid>
                  </Grid>
                </CardContent>
              </Card>
            ))}
            
            <Button
              variant="outlined"
              startIcon={<AddIcon fontSize="small" />}
              onClick={addEmailSection}
              size="small"
              sx={{ 
                mt: 1,
                borderColor: '#ffb74d',
                color: '#e65100',
                '&:hover': {
                  backgroundColor: '#fff8e1',
                  borderColor: '#ffa726'
                }
              }}
            >
              添加段落
            </Button>
          </Grid>
        </Grid>
      </CardContent>
    </Card>
  );

  // 渲染任务类型对应的表单内容
  const renderSpecificContent = () => {
    switch (formData.common.taskType) {
      case 'sql':
        return renderSqlContent();
      case 'python':
        return renderPythonContent();
      case 'email':
        return renderEmailContent();
      default:
        return null;
    }
  };

  // 新增：渲染任务详情内容
  const renderTaskDetailContent = () => {
    if (!currentTaskDetail) return null;
    
    // 解析JSON字段
    let commonConfig = {};
    let resultData = {};
    try {
      if (currentTaskDetail.common) {
        commonConfig = typeof currentTaskDetail.common === 'string' 
          ? JSON.parse(currentTaskDetail.common) 
          : currentTaskDetail.common;
      }
      
      if (currentTaskDetail.result) {
        resultData = typeof currentTaskDetail.result === 'string' 
          ? JSON.parse(currentTaskDetail.result) 
          : currentTaskDetail.result;
      }
    } catch (e) {
      console.error('解析任务详情失败:', e);
    }
    
    // 格式化日期
    const formatDate = (dateStr) => {
      if (!dateStr) return '未执行';
      return format(new Date(dateStr), 'yyyy-MM-dd HH:mm:ss');
    };

    return (
      <Grid container spacing={3}>
        {/* 基本信息 */}
        <Grid item xs={12} md={6}>
          <Card sx={{ boxShadow: 2 }}>
            <CardHeader title="基本信息" />
            <CardContent>
              <Grid container spacing={2}>
                <Grid item xs={12}>
                  <Typography variant="body2" color="text.secondary">任务名称</Typography>
                  <Typography variant="body1" sx={{ fontWeight: 500 }}>
                    {currentTaskDetail.taskName}
                  </Typography>
                </Grid>
                <Grid item xs={12}>
                  <Typography variant="body2" color="text.secondary">任务类型</Typography>
                  <Typography variant="body1">
                    {renderTaskType(currentTaskDetail.taskType)}
                  </Typography>
                </Grid>
                <Grid item xs={12}>
                  <Typography variant="body2" color="text.secondary">当前状态</Typography>
                  <Typography variant="body1" sx={{ 
                    display: 'flex', 
                    alignItems: 'center',
                    color: currentTaskDetail.status === 'failed' ? 'error.main' : 
                           currentTaskDetail.status === 'completed' ? 'success.main' :
                           currentTaskDetail.status === 'running' ? 'info.main' : 'text.primary'
                  }}>
                    {renderStatusChip(currentTaskDetail.status)}
                  </Typography>
                </Grid>
                <Grid item xs={12}>
                  <Typography variant="body2" color="text.secondary">状态详情</Typography>
                  <Typography variant="body1" sx={{ 
                    wordBreak: 'break-all',
                    backgroundColor: currentTaskDetail.status === 'failed' ? '#ffebee' : 'inherit',
                    p: 1,
                    borderRadius: 1
                  }}>
                    {currentTaskDetail.statusDetail || '无详细信息'}
                  </Typography>
                </Grid>
              </Grid>
            </CardContent>
          </Card>
        </Grid>
        
        {/* 执行信息 */}
        <Grid item xs={12} md={6}>
          <Card sx={{ boxShadow: 2 }}>
            <CardHeader title="执行信息" />
            <CardContent>
              <Grid container spacing={2}>
                <Grid item xs={12}>
                  <Typography variant="body2" color="text.secondary">创建时间</Typography>
                  <Typography variant="body1">
                    {formatDate(currentTaskDetail.created_at)}
                  </Typography>
                </Grid>
                <Grid item xs={12}>
                  <Typography variant="body2" color="text.secondary">最后执行时间</Typography>
                  <Typography variant="body1">
                    {formatDate(currentTaskDetail.last_run_time)}
                  </Typography>
                </Grid>
                <Grid item xs={12}>
                  <Typography variant="body2" color="text.secondary">执行耗时</Typography>
                  <Typography variant="body1">
                    {resultData.duration_ms ? `${resultData.duration_ms} 毫秒` : '未知'}
                  </Typography>
                </Grid>
                <Grid item xs={12}>
                  <Typography variant="body2" color="text.secondary">定时设置</Typography>
                  <Typography variant="body1">
                    {renderScheduleInfo(commonConfig.schedule)}
                  </Typography>
                </Grid>
              </Grid>
            </CardContent>
          </Card>
        </Grid>
        
        {/* 执行结果 */}
        {currentTaskDetail.result && (
          <Grid item xs={12}>
            <Card sx={{ boxShadow: 2 }}>
              <CardHeader title="执行结果" />
              <CardContent>
                <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                  {resultData.success ? '执行成功' : '执行失败'} {resultData.message || ''}
                </Typography>
                
                {resultData.data && (
                  <Box sx={{ 
                    border: 1, 
                    borderColor: 'divider', 
                    borderRadius: 1, 
                    p: 2,
                    maxHeight: 400,
                    overflow: 'auto',
                    backgroundColor: '#f9f9f9'
                  }}>
                    <SyntaxHighlighter
                      language="json"
                      style={dracula}
                      customStyle={{ margin: 0, fontSize: '0.875rem' }}
                    >
                      {JSON.stringify(resultData.data, null, 2)}
                    </SyntaxHighlighter>
                  </Box>
                )}
                 <a key="downfile"  href={resultData.data.single_file} download="single_file" style={{ textDecoration: 'none' }} >
                                                    <Chip
                                                      label="single_file"
                                                      size="small"
                                                      variant="outlined"
                                                      color="primary"
                                                      component="span"
                                                    />
                                                  </a>
                
                <Box sx={{ mt: 2, display: 'flex', justifyContent: 'flex-end' }}>
                  <Button 
                    startIcon={<CopyIcon />} 
                    size="small"
                    onClick={() => {
                      navigator.clipboard.writeText(JSON.stringify(resultData, null, 2));
                      showNotification('结果已复制到剪贴板');
                    }}
                  >
                    复制结果
                  </Button>
                  <Button 
                    startIcon={<DownloadIcon />} 
                    size="small"
                    sx={{ ml: 1 }}
                    onClick={() => {
                      const blob = new Blob([JSON.stringify(resultData, null, 2)], { type: 'application/json' });
                      const url = URL.createObjectURL(blob);
                      const a = document.createElement('a');
                      a.href = url;
                      a.download = `${currentTaskDetail.taskName}_result.json`;
                      a.click();
                      URL.revokeObjectURL(url);
                    }}
                  >
                    下载结果
                  </Button>
                </Box>
              </CardContent>
            </Card>
          </Grid>
        )}
        
        {/* 邮件设置 */}
        {commonConfig.needEmail && (
          <Grid item xs={12}>
            <Card sx={{ boxShadow: 2 }}>
              <CardHeader title="邮件设置" />
              <CardContent>
                <Grid container spacing={2}>
                  <Grid item xs={12} md={6}>
                    <Typography variant="body2" color="text.secondary">邮件主题</Typography>
                    <Typography variant="body1">{commonConfig.emailSubject || '无'}</Typography>
                  </Grid>
                  <Grid item xs={12} md={6}>
                    <Typography variant="body2" color="text.secondary">收件人</Typography>
                    <Typography variant="body1">
                      {commonConfig.recipients?.join(', ') || '无'}
                    </Typography>
                  </Grid>
                </Grid>
              </CardContent>
            </Card>
          </Grid>
        )}
      </Grid>
    );
  };

  // ------------------------------
  // 帮助指导内容
  // ------------------------------
  const renderHelpSection = () => (
  <Accordion 
    expanded={expandedHelp} 
    onChange={(event, isExpanded) => setExpandedHelp(isExpanded)}
    sx={{ 
      mb: 3,
      borderRadius: 3,
      overflow: 'hidden',
      boxShadow: '0 4px 20px rgba(0,0,0,0.08)',
      '&:before': { display: 'none' },
      transition: 'all 0.3s ease',
      background: 'linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%)',
      border: '1px solid rgba(106, 90, 205, 0.2)'
    }}
  >
    <AccordionSummary 
      expandIcon={<ExpandMoreIcon sx={{ color: '#6A5ACD' }} />}
      sx={{ 
        py: 2,
        px: 3,
        '&:hover': { 
          backgroundColor: 'rgba(106, 90, 205, 0.05)',
        },
        '& .MuiAccordionSummary-content': {
          alignItems: 'center'
        }
      }}
    >
      <Box sx={{ 
        width: 40, 
        height: 40, 
        borderRadius: '50%', 
        backgroundColor: 'rgba(106, 90, 205, 0.1)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        mr: 2
      }}>
        <HelpIcon sx={{ color: '#6A5ACD', fontSize: '1.5rem' }} />
      </Box>
      <Typography variant="h6" sx={{ 
        fontWeight: 600,
        color: '#343a40',
        fontSize: '1.1rem'
      }}>
        任务管理使用指南
      </Typography>
    </AccordionSummary>
    <AccordionDetails sx={{ p: 0 }}>
      <Grid container spacing={0}>
        {/* 适用人群 */}
        <Grid item xs={12} md={4} sx={{ p: 3, borderRight: '1px solid rgba(0,0,0,0.05)' }}>
          <Box sx={{ 
            display: 'flex', 
            flexDirection: 'column', 
            height: '100%',
            p: 3,
            borderRadius: 2,
            backgroundColor: 'white',
            boxShadow: '0 2px 8px rgba(0,0,0,0.04)',
            transition: 'all 0.3s ease',
            '&:hover': {
              transform: 'translateY(-4px)',
              boxShadow: '0 6px 16px rgba(0,0,0,0.08)'
            }
          }}>
            <Box sx={{ 
              width: 60, 
              height: 60, 
              borderRadius: '50%', 
              backgroundColor: 'rgba(147, 112, 219, 0.1)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              mb: 2
            }}>
              <PeopleIcon sx={{ color: '#9370DB', fontSize: '1.8rem' }} />
            </Box>
            <Typography variant="subtitle1" sx={{ 
              fontWeight: 700, 
              mb: 2,
              color: '#495057',
              fontSize: '1rem'
            }}>
              适用人群
            </Typography>
            <Box component="ul" sx={{ 
              pl: 2, 
              mb: 0,
              '& li': {
                mb: 1,
                color: '#6c757d',
                fontSize: '0.9rem',
                lineHeight: 1.6
              }
            }}>
              <li><strong>业务人员：</strong>生成自动化邮件报表，定时推送经营数据</li>
              <li><strong>数据分析师：</strong>快速创建SQL查询任务，低代码形成定时任务</li>
              <li><strong>开发人员：</strong>运行Python脚本处理复杂场景数据</li>
              <li><strong>团队协作：</strong>统一管理各类定时数据处理任务</li>
            </Box>
          </Box>
        </Grid>

        {/* 使用步骤 */}
        <Grid item xs={12} md={4} sx={{ p: 3, borderRight: '1px solid rgba(0,0,0,0.05)' }}>
          <Box sx={{ 
            display: 'flex', 
            flexDirection: 'column', 
            height: '100%',
            p: 3,
            borderRadius: 2,
            backgroundColor: 'white',
            boxShadow: '0 2px 8px rgba(0,0,0,0.04)',
            transition: 'all 0.3s ease',
            '&:hover': {
              transform: 'translateY(-4px)',
              boxShadow: '0 6px 16px rgba(0,0,0,0.08)'
            }
          }}>
            <Box sx={{ 
              width: 60, 
              height: 60, 
              borderRadius: '50%', 
              backgroundColor: 'rgba(106, 90, 205, 0.1)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              mb: 2
            }}>
              <ChevronRightIcon sx={{ color: '#6A5ACD', fontSize: '1.8rem' }} />
            </Box>
            <Typography variant="subtitle1" sx={{ 
              fontWeight: 700, 
              mb: 2,
              color: '#495057',
              fontSize: '1rem'
            }}>
              使用步骤
            </Typography>
            <Box sx={{ 
              counterReset: 'step',
              '& div': {
                position: 'relative',
                pl: 3,
                mb: 2,
                '&:before': {
                  counterIncrement: 'step',
                  content: 'counter(step)',
                  position: 'absolute',
                  left: 0,
                  top: 0,
                  backgroundColor: '#6A5ACD',
                  color: 'white',
                  width: 22,
                  height: 22,
                  borderRadius: '50%',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: '0.75rem',
                  fontWeight: 700
                }
              },
              '& p': {
                color: '#6c757d',
                fontSize: '0.9rem',
                lineHeight: 1.6,
                mb: 0
              }
            }}>
              <div><p>点击"新建任务"按钮</p></div>
              <div><p>选择任务类型（Report/SQL/Python</p></div>
              <div><p>填写任务基本信息</p></div>
              <div><p>配置类型特有参数</p></div>
              <div><p>按需设置定时执行和邮件通知</p></div>
              <div><p>保存并执行任务</p></div>
            </Box>
          </Box>
        </Grid>

        {/* 功能价值 */}
        <Grid item xs={12} md={4} sx={{ p: 3 }}>
          <Box sx={{ 
            display: 'flex', 
            flexDirection: 'column', 
            height: '100%',
            p: 3,
            borderRadius: 2,
            backgroundColor: 'white',
            boxShadow: '0 2px 8px rgba(0,0,0,0.04)',
            transition: 'all 0.3s ease',
            '&:hover': {
              transform: 'translateY(-4px)',
              boxShadow: '0 6px 16px rgba(0,0,0,0.08)'
            }
          }}>
            <Box sx={{ 
              width: 60, 
              height: 60, 
              borderRadius: '50%', 
              backgroundColor: 'rgba(72, 61, 139, 0.1)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              mb: 2
            }}>
              <SuccessIcon sx={{ color: '#483D8B', fontSize: '1.8rem' }} />
            </Box>
            <Typography variant="subtitle1" sx={{ 
              fontWeight: 700, 
              mb: 2,
              color: '#495057',
              fontSize: '1rem'
            }}>
              功能价值
            </Typography>
            <Box sx={{ 
              '& div': {
                display: 'flex',
                alignItems: 'flex-start',
                mb: 2,
                '& svg': {
                  color: '#6A5ACD',
                  fontSize: '1rem',
                  mt: '0.25rem',
                  mr: 1.5
                }
              },
              '& p': {
                color: '#6c757d',
                fontSize: '0.9rem',
                lineHeight: 1.6,
                mb: 0
              }
            }}>
              <div><SuccessIcon/><p><strong>自动化处理：</strong>减少重复工作，提升工作效率</p></div>
              <div><SuccessIcon/><p><strong>统一管理：</strong>集中管理各类数据任务，降低维护成本</p></div>
              <div><SuccessIcon/><p><strong>智能调度：</strong>灵活定时执行，自动邮件推送结果</p></div>
              <div><SuccessIcon/><p><strong>低门槛：</strong>结构化配置，业务人员也能轻松使用</p></div>
            </Box>
          </Box>
        </Grid>

        {/* 注意事项 */}
        <Grid item xs={12} sx={{ 
          p: 3,
          borderTop: '1px solid rgba(0,0,0,0.05)',
          backgroundColor: 'rgba(255, 193, 7, 0.05)'
        }}>
          <Box sx={{ 
            p: 3,
            borderRadius: 2,
            backgroundColor: 'white',
            boxShadow: '0 2px 8px rgba(0,0,0,0.04)',
            borderLeft: '4px solid #FFA000'
          }}>
            <Typography variant="subtitle1" sx={{ 
              fontWeight: 700, 
              mb: 2,
              color: '#495057',
              fontSize: '1rem',
              display: 'flex',
              alignItems: 'center'
            }}>
              <InfoIcon sx={{ 
                mr: 1.5, 
                fontSize: '1.2rem', 
                color: '#FFA000' 
              }} />
              注意事项
            </Typography>
            <Box sx={{ 
              '& div': {
                display: 'flex',
                alignItems: 'flex-start',
                mb: 1.5,
                '& svg': {
                  color: '#FFA000',
                  fontSize: '0.8rem',
                  mt: '0.3rem',
                  mr: 1.5
                }
              },
              '& p': {
                color: '#6c757d',
                fontSize: '0.9rem',
                lineHeight: 1.6,
                mb: 0
              }
            }}>
              <div><InfoIcon fontSize="small"/><p><strong>SQL限制：</strong>仅支持SELECT查询，请确保查询性能</p></div>
              <div><InfoIcon fontSize="small"/><p><strong>Python环境：</strong>运行在沙箱模式，部分系统库可能受限</p></div>
              <div><InfoIcon fontSize="small"/><p><strong>邮件格式：</strong>SQL查询结果会自动转换为表格格式</p></div>
              <div><InfoIcon fontSize="small"/><p><strong>定时任务：</strong>执行状态可在任务列表查看，支持失败重试</p></div>
            </Box>
          </Box>
        </Grid>
      </Grid>
    </AccordionDetails>
  </Accordion>
);

  // ------------------------------
  // 主界面渲染
  // ------------------------------
  return (
    <Box sx={{ flexGrow: 1, p: 3, maxWidth: '1400px', margin: '0 auto' }}>
      {/* 帮助指导区域 */}
      {renderHelpSection()}

      {/* 页面标题和操作按钮 */}
      <Box sx={{ 
  display: 'flex', 
  justifyContent: 'space-between', 
  alignItems: 'center', 
  mb: 4,
  p: 3,
  borderRadius: 3,
  backgroundColor: 'white',
  boxShadow: '0 2px 12px rgba(106, 90, 205, 0.1)',
  borderLeft: '4px solid #6A5ACD'
}}>
  <Box sx={{ display: 'flex', alignItems: 'center' }}>
    <Box sx={{
      width: 48,
      height: 48,
      borderRadius: '50%',
      backgroundColor: 'rgba(106, 90, 205, 0.1)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      mr: 2
    }}>
      <ScheduleIcon sx={{ color: '#6A5ACD', fontSize: '1.8rem' }} />
    </Box>
    <Box>
      <Typography variant="h5" component="h1" sx={{ 
        fontWeight: 700, 
        color: '#343a40',
        lineHeight: 1.2
      }}>
        任务管理中心
      </Typography>
      <Typography variant="body2" sx={{ 
        color: '#6c757d',
        fontSize: '0.875rem'
      }}>
        创建、管理和执行自动化数据处理任务
      </Typography>
    </Box>
  </Box>
  <Button
    variant="contained"
    startIcon={<AddIcon />}
    onClick={handleAddTask}
    sx={{
      px: 3,
      py: 1.5,
      borderRadius: 2,
      textTransform: 'none',
      fontSize: '0.9375rem',
      fontWeight: 600,
      boxShadow: '0 2px 6px rgba(106, 90, 205, 0.1)',
      background: theme.secondary,  // background: 'linear-gradient(135deg, #6A5ACD 0%, #9370DB 5%)',
      '&:hover': { 
        boxShadow: '0 4px 12px rgba(106, 90, 205, 0.2)',
        transform: 'translateY(-2px)',
        // background: 'linear-gradient(135deg, #5F4BBA 0%, #8364C8 100%)'
      },
      '&:active': { 
        transform: 'translateY(0)',
        boxShadow: '0 2px 6px rgba(106, 90, 205, 0.3)'
      },
      transition: 'all 0.3s ease'
    }}
  >
    新建任务
  </Button>
</Box>

      {/* 筛选器 */}
      <Box sx={{ mb: 3, display: 'flex', alignItems: 'center', gap: 2, flexWrap: 'wrap' }}>
        <FormControl size="small" sx={{ minWidth: 200, boxShadow: 1 }}>
          <InputLabel>任务类型</InputLabel>
          <Select
            value={filterType}
            label="任务类型"
            onChange={(e) => setFilterType(e.target.value)}
            sx={{ 
              '& .MuiSelect-select': { py: 1.2 },
              transition: '0.3s'
            }}
          >
            <MenuItem value="all">所有任务</MenuItem>
            <MenuItem value="sql">SQL任务</MenuItem>
            <MenuItem value="python">Python脚本</MenuItem>
            <MenuItem value="email">邮件报表</MenuItem>
          </Select>
        </FormControl>
        
        {/* 新增：状态筛选 */}
        <FormControl size="small" sx={{ minWidth: 200, boxShadow: 1 }}>
          <InputLabel>任务状态</InputLabel>
          <Select
            value={filterStatus}
            label="任务状态"
            onChange={(e) => setFilterStatus(e.target.value)}
            sx={{ 
              '& .MuiSelect-select': { py: 1.2 },
              transition: '0.3s'
            }}
          >
            <MenuItem value="all">所有状态</MenuItem>
            <MenuItem value="pending">待执行</MenuItem>
            <MenuItem value="running">执行中</MenuItem>
            <MenuItem value="completed">已完成</MenuItem>
            <MenuItem value="failed">失败</MenuItem>
          </Select>
        </FormControl>
        
        {/* 新增：刷新按钮 */}
        <Button
          variant="outlined"
          startIcon={<RefreshIcon />}
          onClick={fetchTasks}
          size="small"
          sx={{
            ml: 'auto'
          }}
        >
          刷新列表
        </Button>
      </Box>

      {/* 任务列表 */}
      <Paper sx={{ 
  width: '100%', 
  overflow: 'hidden', 
  borderRadius: 3,
  boxShadow: '0 4px 20px rgba(0,0,0,0.06)',
  transition: 'all 0.3s ease',
  '&:hover': { 
    boxShadow: '0 6px 24px rgba(0,0,0,0.1)'
  }
}}>
  {/* 新增：任务执行进度条 */}
  {executingTaskId && (
    <LinearProgress sx={{ height: 2 }} />
  )}
  
  <TableContainer>
    <Table stickyHeader>
      <TableHead>
        <TableRow sx={{
          '& th': {
            fontWeight: 700,
            color: '#495057',
            backgroundColor: '#f8f9fa',
            borderBottom: '1px solid #e9ecef',
            py: 2,
            fontSize: '0.875rem',
            textTransform: 'uppercase',
            letterSpacing: '0.5px'
          }
        }}>
          <TableCell sx={{ borderRadius: '12px 0 0 0' }}>任务名称</TableCell>
          <TableCell>类型</TableCell>
          <TableCell>状态</TableCell>
          <TableCell>定时设置</TableCell>
          <TableCell>最后执行时间</TableCell>
          <TableCell sx={{ borderRadius: '0 12px 0 0' }}>操作</TableCell>
        </TableRow>
      </TableHead>
      <TableBody>
        {loading ? (
          <TableRow>
            <TableCell colSpan={6} align="center" sx={{ py: 6 }}>
              <Box sx={{ 
                display: 'flex', 
                flexDirection: 'column', 
                alignItems: 'center',
                color: '#6c757d'
              }}>
                <CircularProgress size={48} sx={{ 
                  color: '#6A5ACD',
                  mb: 2
                }} />
                <Typography>加载任务中...</Typography>
              </Box>
            </TableCell>
          </TableRow>
        ) : error ? (
          <TableRow>
            <TableCell colSpan={6} align="center" sx={{ py: 4 }}>
              <Box sx={{ 
                display: 'flex', 
                flexDirection: 'column', 
                alignItems: 'center',
                color: '#E53935'
              }}>
                <ErrorIcon sx={{ fontSize: '2.5rem', mb: 1 }} />
                <Typography variant="body1" sx={{ fontWeight: 500, mb: 1 }}>
                  加载失败
                </Typography>
                <Typography variant="body2" sx={{ color: '#6c757d' }}>
                  {error}
                </Typography>
                <Button 
                  variant="outlined" 
                  onClick={fetchTasks}
                  sx={{ 
                    mt: 2,
                    color: '#6A5ACD',
                    borderColor: '#6A5ACD',
                    '&:hover': {
                      backgroundColor: 'rgba(106, 90, 205, 0.04)',
                      borderColor: '#5F4BBA'
                    }
                  }}
                >
                  重试
                </Button>
              </Box>
            </TableCell>
          </TableRow>
        ) : filteredTasks.length === 0 ? (
          <TableRow>
            <TableCell colSpan={6} align="center" sx={{ py: 6 }}>
              <Box sx={{ 
                display: 'flex', 
                flexDirection: 'column', 
                alignItems: 'center',
                color: '#6c757d'
              }}>
                <DescriptionIcon sx={{ fontSize: '2.5rem', mb: 1, opacity: 0.6 }} />
                <Typography variant="body1" sx={{ fontWeight: 500, mb: 1 }}>
                  暂无任务
                </Typography>
                <Typography variant="body2" sx={{ mb: 2 }}>
                  点击"新建任务"按钮创建您的第一个任务
                </Typography>
                <Button 
                  variant="contained" 
                  onClick={handleAddTask}
                  startIcon={<AddIcon />}
                  sx={{
                    background: 'linear-gradient(135deg, #6A5ACD 0%, #9370DB 100%)',
                    boxShadow: '0 2px 6px rgba(106, 90, 205, 0.3)'
                  }}
                >
                  新建任务
                </Button>
              </Box>
            </TableCell>
          </TableRow>
        ) : (
          filteredTasks
            .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
            .map((task) => (
              <TableRow
                key={task.id}
                hover
                sx={{
                  '&:last-child td': { borderBottom: 0 },
                  '& td': {
                    py: 2,
                    borderBottom: '1px solid #f1f3f5',
                    transition: 'all 0.2s ease'
                  },
                  '&:hover td': {
                    backgroundColor: '#f8f9fa'
                  }
                }}
              >
                <TableCell>
                  <Box sx={{ 
                    display: 'flex', 
                    alignItems: 'center',
                    fontWeight: 500
                  }}>
                    {task.taskName}
                  </Box>
                </TableCell>
                <TableCell>{renderTaskType(task.taskType)}</TableCell>
                <TableCell>
                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    {renderStatusChip(task.status)}
                  </Box>
                </TableCell>
                <TableCell>
                  {renderScheduleInfo(task.common?.schedule)}
                </TableCell>
                <TableCell>
                  <Tooltip title={task.last_run_time ? new Date(task.last_run_time).toLocaleString() : '未执行'}>
                    <Typography sx={{ fontSize: '0.875rem' }}>
                      {task.last_run_time ? formatDistanceToNow(new Date(task.last_run_time), { addSuffix: true }) : '未执行'}
                    </Typography>
                  </Tooltip>
                </TableCell>
                <TableCell>
                  <Box sx={{ display: 'flex' }}>
                    {/* 新增：详情按钮 */}
                    <Tooltip title="详情" arrow>
                      <IconButton 
                        size="small" 
                        onClick={() => handleViewDetail(task)}
                        sx={{ 
                          color: '#6A5ACD',
                          backgroundColor: 'rgba(106, 90, 205, 0.1)',
                          '&:hover': { 
                            color: '#5F4BBA', 
                            backgroundColor: 'rgba(106, 90, 205, 0.2)'
                          },
                          mr: 1,
                          transition: 'all 0.2s ease'
                        }}
                      >
                        <ViewIcon fontSize="small" />
                      </IconButton>
                    </Tooltip>

                    <Tooltip title="执行" arrow>
                      <IconButton 
                        size="small" 
                        onClick={() => handleRunTask(task)}
                        disabled={executingTaskId === task.id}
                        sx={{ 
                          color: '#4caf50',
                          backgroundColor: executingTaskId === task.id ? 'rgba(76, 175, 80, 0.2)' : 'rgba(76, 175, 80, 0.1)',
                          '&:hover': { 
                            color: '#388e3c', 
                            backgroundColor: 'rgba(76, 175, 80, 0.2)'
                          },
                          mr: 1,
                          transition: 'all 0.2s ease'
                        }}
                      >
                        {executingTaskId === task.id ? (
                          <CircularProgress size={16} color="inherit" />
                        ) : (
                          <PlayArrowIcon fontSize="small" />
                        )}
                      </IconButton>
                    </Tooltip>

                    <Tooltip title="编辑" arrow>
                      <IconButton 
                        size="small" 
                        onClick={() => handleEditTask(task)}
                        disabled={executingTaskId === task.id}
                        sx={{ 
                          color: '#2196f3',
                          backgroundColor: 'rgba(33, 150, 243, 0.1)',
                          '&:hover': { 
                            color: '#1976d2', 
                            backgroundColor: 'rgba(33, 150, 243, 0.2)'
                          },
                          mr: 1,
                          transition: 'all 0.2s ease',
                          opacity: executingTaskId === task.id ? 0.5 : 1
                        }}
                      >
                        <EditIcon fontSize="small" />
                      </IconButton>
                    </Tooltip>

                    <Tooltip title="删除" arrow>
                      <IconButton 
                        size="small" 
                        onClick={() => handleDeleteTask(task.id)}
                        disabled={executingTaskId === task.id}
                        sx={{ 
                          color: '#f44336',
                          backgroundColor: 'rgba(244, 67, 54, 0.1)',
                          '&:hover': { 
                            color: '#d32f2f', 
                            backgroundColor: 'rgba(244, 67, 54, 0.2)'
                          },
                          transition: 'all 0.2s ease',
                          opacity: executingTaskId === task.id ? 0.5 : 1
                        }}
                      >
                        <DeleteIcon fontSize="small" />
                      </IconButton>
                    </Tooltip>
                  </Box>
                </TableCell>
              </TableRow>
            ))
        )}
      </TableBody>
    </Table>
  </TableContainer>
  <TablePagination
    rowsPerPageOptions={[5, 10, 25]}
    component="div"
    count={filteredTasks.length}
    rowsPerPage={rowsPerPage}
    page={page}
    onPageChange={handleChangePage}
    onRowsPerPageChange={handleChangeRowsPerPage}
    sx={{ 
      borderTop: '1px solid #e9ecef',
      '& .MuiTablePagination-selectLabel, & .MuiTablePagination-displayedRows': {
        fontSize: '0.875rem'
      }
    }}
  />
</Paper>

      {/* 任务详情对话框 */}
      <Dialog
        open={detailDialogOpen}
        onClose={() => setDetailDialogOpen(false)}
        fullWidth
        maxWidth="lg"
        PaperProps={{
          sx: {
            maxHeight: '90vh',
            overflow: 'auto',
            borderRadius: 2,
            boxShadow: 8
          }
        }}
      >
        <DialogTitle sx={{
          py: 2,
          px: 4,
          backgroundColor: '#f5f5f5',
          borderBottom: 1,
          borderColor: 'divider',
          fontWeight: 600,
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center'
        }}>
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <ScheduleIcon sx={{ mr: 1.5, color: '#6A5ACD' }} />
            任务详情
          </Box>
          <Typography variant="body2" color="text.secondary">
            {currentTaskDetail?.taskName}
          </Typography>
        </DialogTitle>
        <DialogContent sx={{ p: 4 }}>
          {renderTaskDetailContent()}
        </DialogContent>
        <DialogActions sx={{
          p: 2,
          borderTop: 1,
          borderColor: 'divider',
          justifyContent: 'center'
        }}>
          <Button
            onClick={() => setDetailDialogOpen(false)}
            variant="contained"
            sx={{
              backgroundColor: '#6A5ACD',
              '&:hover': {
                backgroundColor: '#5F4BBA'
              }
            }}
          >
            关闭
          </Button>
        </DialogActions>
      </Dialog>

      {/* 任务编辑对话框 */}
      <Dialog
        open={dialogOpen}
        onClose={() => setDialogOpen(false)}
        fullWidth
        maxWidth="lg"
        PaperProps={{
          sx: {
            maxHeight: '90vh',
            overflow: 'auto',
            boxShadow: 5,
            p: 0,
            borderRadius: 2
          }
        }}
        transitionDuration={300}
      >
        <DialogTitle sx={{ 
          pb: 2, 
          borderBottom: 1, 
          borderColor: 'divider', 
          px: 4, 
          pt: 3,
          backgroundColor: '#f5f5f5',
          fontWeight: 600
        }}>
          {isNewTask ? '新建任务' : '编辑任务'}
        </DialogTitle>
        <DialogContent sx={{ p: 4, pt: 3 }}>
          <Grid container spacing={3}>
            {/* 共同部分 */}
            <Grid item xs={12} md={6}>
              <Card sx={{ boxShadow: 2, transition: '0.3s', '&:hover': { boxShadow: 3 } }}>
                <CardHeader 
                  title="基本信息" 
                  sx={{ 
                    py: 1.5, 
                    backgroundColor: '#f5f5f5',
                    borderBottom: 1,
                    borderColor: 'divider'
                  }} 
                />
                <CardContent sx={{ py: 1.5 }}>
                  <Grid container spacing={2}>
                    <Grid item xs={12}>
                      <TextField
                        fullWidth
                        label="任务名称 *"
                        value={formData.common.taskName}
                        onChange={(e) => handleCommonChange('taskName', e.target.value)}
                        variant="outlined"
                        size="small"
                      />
                    </Grid>

                    <Grid item xs={12}>
                      <FormControl fullWidth size="small">
                        <InputLabel>任务类型 *</InputLabel>
                        <Select
                          value={formData.common.taskType}
                          label="任务类型"
                          onChange={(e) => handleCommonChange('taskType', e.target.value)}
                        >
                          <MenuItem value="sql">SQL任务</MenuItem>
                          <MenuItem value="python">Python脚本</MenuItem>
                          <MenuItem value="email">邮件报表</MenuItem>
                        </Select>
                      </FormControl>
                    </Grid>

                    

                    <Grid item xs={12}>
                      <FormControlLabel
                        control={
                          <Switch
                            checked={formData.common.needEmail}
                            onChange={(e) => handleCommonChange('needEmail', e.target.checked)}
                            color="primary"
                          />
                        }
                        label="是否发送邮件通知"
                      />
                    </Grid>
                  </Grid>
                </CardContent>
              </Card>
            </Grid>

            {/* 邮件设置（条件显示） */}
            {formData.common.needEmail && (
              <Grid item xs={12} md={6}>
                <Card sx={{ boxShadow: 2, transition: '0.3s', '&:hover': { boxShadow: 3 } }}>
                  <CardHeader 
                    title="邮件设置" 
                    sx={{ 
                      py: 1.5, 
                      backgroundColor: '#fff3e0',
                      borderBottom: 1,
                      borderColor: 'divider'
                    }} 
                  />
                  <CardContent sx={{ py: 1.5 }}>
                    <Grid container spacing={2}>
                      <Grid item xs={12}>
                        <TextField
                          fullWidth
                          label="邮件主题 *"
                          value={formData.common.emailSubject}
                          onChange={(e) => handleCommonChange('emailSubject', e.target.value)}
                          variant="outlined"
                          size="small"
                        />
                      </Grid>
                      <Grid item xs={12}>
                        <TextField
                          fullWidth
                          label="接收人（逗号分隔） *"
                          value={formData.common.recipients.join(', ')}
                          onChange={handleRecipientsChange}
                          variant="outlined"
                          size="small"
                          placeholder="例如：user1@example.com, user2@example.com"
                        />
                      </Grid>
                    </Grid>
                  </CardContent>
                </Card>
              </Grid>
            )}

            {/* 定时设置区域 */}
            <Grid item xs={12}>
              {renderScheduleSettings()}
            </Grid>

            {/* 类型特有内容 */}
            <Grid item xs={12}>
              {renderSpecificContent()}
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions sx={{ 
          p: 2, 
          borderTop: 1, 
          borderColor: 'divider', 
          justifyContent: 'flex-end',
          backgroundColor: '#fafafa'
        }}>
          <Button 
            onClick={() => setDialogOpen(false)} 
            startIcon={<CancelIcon />}
            sx={{
              transition: '0.2s',
              '&:hover': { transform: 'translateY(-2px)' },
              '&:active': { transform: 'translateY(0)' }
            }}
          >
            取消
          </Button>
          <Button
            onClick={handleSaveTask}
            color="primary"
            startIcon={<SaveIcon />}
            variant="contained"
            sx={{
              transition: '0.2s',
              '&:hover': { transform: 'translateY(-2px)', boxShadow: 3 },
              '&:active': { transform: 'translateY(0)' },
              backgroundColor: '#5c6bc0'
            }}
          >
            保存
          </Button>
        </DialogActions>
      </Dialog>
       {renderTaskCreationDialog()}
      {/* 通知提示 */}
      <Snackbar
        open={notification.open}
        autoHideDuration={6000}
        onClose={handleCloseNotification}
        anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
        TransitionProps={{
          onEnter: (node) => {
            node.style.transform = 'translateY(-20px)';
            node.style.opacity = 0;
            setTimeout(() => {
              node.style.transform = 'translateY(0)';
              node.style.opacity = 1;
              node.style.transition = 'transform 0.3s, opacity 0.3s';
            }, 10);
          }
        }}
      >
        <Alert
          onClose={handleCloseNotification}
          severity={notification.severity}
          elevation={6}
          variant="filled"
          sx={{ borderRadius: 1 }}
        >
          {notification.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default CustomTaskPage;