import React, { useState, useEffect } from 'react';
import { useParams, useLocation } from 'react-router-dom';
import { styled } from '@mui/material/styles';
import {
  Box,
  Typography,
  Button,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  CircularProgress,
  TextField,
  InputAdornment,
  IconButton,
  Snackbar,
  Alert,
  Tabs,
  Tab,
  Card,
  CardContent,
  Grid,
  FormGroup,
  FormControlLabel,
  Checkbox,
  Radio,
  Dialog,
  DialogTitle,
  DialogActions,
  DialogContent,
  FormControl,
  FormLabel,
  Drawer,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Chip,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  alpha,
  SwipeableDrawer, // 添加可滑动抽屉
  useTheme,
  useMediaQuery,
  Divider,
  ListItemButton,
  Badge,
} from '@mui/material';
import {
  Upload as UploadIcon,
  Description as DescriptionIcon,
  ShowChart as ShowChartIcon,
  FindReplace as FindReplaceIcon,
  Assessment as AssessmentIcon,
  Close as CloseIcon,
  CloudUpload as CloudUploadIcon,
  InsertDriveFile as InsertDriveFileIcon,
  AccountTree as AccountTreeIcon,
  Calculate as CalculateIcon,
  Settings as SettingsIcon,
  BarChart as BarChartIcon,
  Link as LinkIcon,
  SwapHoriz as SwapHorizIcon,
  Dashboard as DashboardIcon,
  Analytics as AnalyticsIcon,
  TableChart as TableChartIcon,
  Numbers as NumbersIcon,
  FilterNone as FilterNoneIcon,
  ScatterPlot as ScatterPlotIcon,
  ExpandMore as ExpandMoreIcon,
    ExpandLess as ExpandLessIcon,       // 需要添加这一行
  ChevronRight as ChevronRightIcon,
  ChevronLeft as ChevronLeftIcon,
  Menu as MenuIcon, // 添加菜单图标
  Home as HomeIcon,
  TrendingUp as TrendingUpIcon,
} from '@mui/icons-material';

// 图表组件导入
import { BarChart, PieChart } from '@mui/x-charts';
import axios from 'axios';
import BIAnalysis from './BIAnalysis';

// 样式定义
const StyledPaper = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(3),
  marginBottom: theme.spacing(3),
  borderRadius: theme.shape.borderRadius,
  boxShadow: theme.shadows[2],
  transition: 'all 0.3s ease',
  '&:hover': {
    boxShadow: theme.shadows[4],
  },
}));

const StyledCard = styled(Card)(({ theme }) => ({
  height: '100%',
  display: 'flex',
  flexDirection: 'column',
  transition: 'transform 0.2s, box-shadow 0.2s',
  '&:hover': {
    transform: 'translateY(-4px)',
    boxShadow: theme.shadows[6],
  },
}));

const SidebarDrawer = styled(Drawer)(({ theme }) => ({
  width: 280,
  flexShrink: 0,
  '& .MuiDrawer-paper': {
    width: 280,
    boxSizing: 'border-box',
    backgroundColor: theme.palette.background.default,
    borderRight: `1px solid ${theme.palette.divider}`,
  },
}));

const AnalysisSection = ({ title, icon, children, actionButton, variant = 'default' }) => {
  const IconComponent = icon;

  if (variant === 'minimal') {
    return (
      <Box sx={{ mb: 3 }}>
        <Box display="flex" alignItems="center" mb={2}>
          <IconComponent color="primary" sx={{ mr: 1 }} />
          <Typography variant="h6" component="h3">
            {title}
          </Typography>
        </Box>
        {children}
      </Box>
    );
  }

  return (
    <StyledPaper>
      <Box display="flex" alignItems="center" justifyContent="space-between" mb={2}>
        <Box display="flex" alignItems="center">
          <IconComponent color="primary" sx={{ mr: 1 }} />
          <Typography variant="h6" component="h3">
            {title}
          </Typography>
        </Box>
        {actionButton}
      </Box>
      {children}
    </StyledPaper>
  );
};

const DataTable = ({ data, title }) => {
  if (!data || data.length === 0) return null;

  const columns = Object.keys(data[0]);

  return (
    <TableContainer component={Paper} sx={{ maxHeight: 440, border: 1, borderColor: 'divider' }}>
      {title && <Typography variant="subtitle1" sx={{ p: 2, bgcolor: 'grey.50' }}>{title}</Typography>}
      <Table stickyHeader size="small">
        <TableHead>
          <TableRow>
            {columns.map((col) => (
              <TableCell key={col} sx={{ fontWeight: 'bold', bgcolor: 'grey.100' }}>{col}</TableCell>
            ))}
          </TableRow>
        </TableHead>
        <TableBody>
          {data.map((row, i) => (
            <TableRow key={i} hover>
              {columns.map((col) => (
                <TableCell key={`${i}-${col}`}>
                  {typeof row[col] === 'number' ? row[col].toFixed(4) : String(row[col])}
                </TableCell>
              ))}
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
};

const StatCard = ({ title, value, icon, color }) => {
  const IconComponent = icon;
  return (
    <StyledCard variant="outlined">
      <CardContent sx={{ p: 2 }}>
        <Box display="flex" justifyContent="space-between" alignItems="flex-start">
          <Box>
            <Typography variant="body2" color="textSecondary" gutterBottom>
              {title}
            </Typography>
            <Typography variant="h5" fontWeight="bold">
              {typeof value === 'number' ? value.toLocaleString() : value}
            </Typography>
          </Box>
          <IconComponent sx={{ color: color || 'primary.main', fontSize: 32, opacity: 0.8 }} />
        </Box>
      </CardContent>
    </StyledCard>
  );
};

function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p: 2 }}>
          {children}
        </Box>
      )}
    </div>
  );
}

const DataAnalysis = () => {


const theme = useTheme();
const isMobile = useMediaQuery(theme.breakpoints.down('md'));

  const { configname } = useParams();
  const location = useLocation();
  const queryParams = new URLSearchParams(location.search);
  const queryConfigName = queryParams.get('config');

  // 新增：获取URL参数中的文件URL
  const fileUrlFromParams = queryParams.get('url');

  // URL输入相关状态
  const [fileUrl, setFileUrl] = useState('');
  const [inputMode, setInputMode] = useState('upload'); // 'upload' 或 'url'

  // 最终生效的配置名：优先使用路由参数，其次使用查询参数
  const effectiveConfigName = configname || queryConfigName;
  const [activeTab, setActiveTab] = useState(0);
  const [file, setFile] = useState(null);
  const [fileName, setFileName] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);
  const [analysisResult, setAnalysisResult] = useState(null);
  const [previewData, setPreviewData] = useState([]);
  const [tabValue, setTabValue] = useState(0); // 配置对话框Tabs控制
  const [allColumns, setAllColumns] = useState([]); // 所有列名
  const [pcaDimensions, setPcaDimensions] = useState(3);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [fileInputExpanded, setFileInputExpanded] = useState(!effectiveConfigName);

  // 配置对话框状态
  const [openConfig, setOpenConfig] = useState(false);
  const [currentAnalysisType, setCurrentAnalysisType] = useState('');
  const [isCollapsed, setIsCollapsed] = useState(true);
  // 特征选择状态 - 包含taskType用于区分分类/回归
  const [featureSelection, setFeatureSelection] = useState({
    target: null,       // 目标变量 (y)
    features: [],       // 选择的特征 (X)
    ignore: [],         // 忽略的列
    taskType: 'classification' // 任务类型：classification/regression
  });

  const toggleCollapse = () => {
    setIsCollapsed(prev => !prev);
  };

  const [selectedAlgorithms, setSelectedAlgorithms] = useState([
    'rf',
    'linear',
    'mi'
  ]);

  // 新增：处理从URL参数传递的文件URL
  useEffect(() => {
    if (fileUrlFromParams) {
      // 解码URL参数
      const filePath = decodeURIComponent(fileUrlFromParams);
      const baseURL = axios.defaults.baseURL || '';

      // 检查是否需要添加baseURL
      const shouldPrependBaseURL = !filePath.startsWith('http') &&
                                  !filePath.startsWith('s3://') &&
                                  baseURL;
      // 生成最终下载URL
      let downloadURL = filePath;
      if (shouldPrependBaseURL) {
        // 确保baseURL以斜杠结尾
        const adjustedBaseURL = baseURL.endsWith('/') ? baseURL : baseURL + '/';
        downloadURL = adjustedBaseURL + filePath;
      }

      setFileUrl(downloadURL);
      setInputMode('url'); // 自动切换到URL模式

      // 如果没有正在加载且没有分析结果，自动执行分析
      if (!isLoading && !analysisResult) {
        handleUrlAnalysis();
      }
    }
  }, [fileUrlFromParams, isLoading, analysisResult]);

  useEffect(() => {
    if (effectiveConfigName) {
      // 清空之前的文件状态，避免冲突
      setFile(null);
      setFileName('');
      setFileUrl('');
      setFileInputExpanded(false);
      // 加载配置对应的分析结果
      loadConfigAnalysis(effectiveConfigName);
    }
  }, [effectiveConfigName]);

  useEffect(() => {
    if (analysisResult?.preview_data?.length > 0) {
      const columns = Object.keys(analysisResult.preview_data[0]);
      setAllColumns(columns);
      // 初始化特征选择
      setFeatureSelection(prev => ({
        ...prev,
        features: columns.filter(col => col !== prev.target)
      }));
    }
  }, [analysisResult]);


  // 添加悬浮按钮和侧边栏的样式
const FloatingSidebarButton = styled(IconButton)(({ theme }) => ({
  position: 'fixed',
  left: 2,
  top: 80,
  zIndex: 1200,
  backgroundColor: theme.palette.primary.main,
  color: 'white',
  boxShadow: theme.shadows[4],
  '&:hover': {
    backgroundColor: theme.palette.primary.dark,
    boxShadow: theme.shadows[6],
  },
  width: 48,
  height: 48,
}));

const StyledDrawer = styled(Drawer)(({ theme }) => ({
  '& .MuiDrawer-paper': {
    width: 170,
    background: `linear-gradient(135deg, ${theme.palette.background.paper} 0%, ${alpha(theme.palette.primary.light, 0.05)} 100%)`,
    border: 'none',
    boxShadow: theme.shadows[8],
    borderRadius: '0 16px 16px 0',
    marginTop: 64,
    height: 'calc(100vh - 64px)',
    '&::-webkit-scrollbar': {
      width: 6,
    },
    '&::-webkit-scrollbar-track': {
      background: alpha(theme.palette.primary.main, 0.1),
      borderRadius: 3,
    },
    '&::-webkit-scrollbar-thumb': {
      background: alpha(theme.palette.primary.main, 0.3),
      borderRadius: 3,
    },
  },
}));

const SidebarListItem = styled(ListItemButton)(({ theme, selected }) => ({
  borderRadius: 12,
  margin: '4px 8px',
  padding: '8px 16px',
  transition: 'all 0.2s ease',
  backgroundColor: selected
    ? alpha(theme.palette.primary.main, 0.1)
    : 'transparent',
  border: selected
    ? `1px solid ${alpha(theme.palette.primary.main, 0.2)}`
    : '1px solid transparent',
  '&:hover': {
    backgroundColor: alpha(theme.palette.primary.main, 0.05),
    transform: 'translateX(4px)',
  },
  '& .MuiListItemIcon-root': {
    minWidth: 40,
    color: selected ? theme.palette.primary.main : theme.palette.text.secondary,
  },
  '& .MuiListItemText-primary': {
    fontWeight: selected ? 600 : 400,
    color: selected ? theme.palette.primary.main : theme.palette.text.primary,
  },
}));
  // 列选择器组件
  const ColumnSelector = ({ columns, selected, onChange, multiSelect }) => {
    return (
      <FormGroup>
        {columns.map((col) => (
          <FormControlLabel
            key={col}
            control={
              multiSelect ? (
                <Checkbox
                  checked={selected.includes(col)}
                  onChange={(e) =>
                    onChange(
                      e.target.checked
                        ? [...selected, col]
                        : selected.filter((c) => c !== col)
                    )
                  }
                />
              ) : (
                <Radio
                  checked={selected === col}
                  onChange={() => onChange(col)}
                />
              )
            }
            label={col}
          />
        ))}
      </FormGroup>
    );
  };
  // 在组件中添加分析项目配置
const analysisItems = [
    {
    id: 6,
    label: 'BI',
    icon: AnalyticsIcon,
    badge: '推荐',
    color: 'secondary'
  },
  { id: 0, label: 'OV', icon: DashboardIcon, badge: null },
  { id: 1, label: 'Abs', icon: TableChartIcon, badge: null },
  { id: 2, label: 'DI', icon: FilterNoneIcon, badge: null },
  { id: 3, label: 'COR', icon: ShowChartIcon, badge: null },
  { id: 4, label: 'FS', icon: AssessmentIcon, badge: null },
  { id: 5, label: 'PCA', icon: ScatterPlotIcon, badge: null },

];

  const loadConfigAnalysis = async (configName) => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await axios.get(`/analysis/${configName}`);
      setAnalysisResult(response.data);
      setPreviewData(response.data.preview_data || []);
      setSuccess(`Analysis loaded for configuration: ${configName}`);
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to load analysis');
    } finally {
      setIsLoading(false);
    }
  };

  const handleFileChange = (event) => {
    const selectedFile = event.target.files[0];
    console.info(  )
    if (selectedFile) {
      setFile(selectedFile);
      setFileName(selectedFile.name);
      previewFile(selectedFile);
    }
    
  };
  useEffect( () => {

    setTimeout(async () => {
        await handleUpload();
      },0 );
  }, [fileName]);

  const previewFile = (file) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const content = e.target.result;
      const lines = content.split('\n').slice(0, 5);
      const headers = lines[0].split(',');
      const preview = lines.slice(1).map(line => {
        const values = line.split(',');
        return headers.reduce((obj, header, i) => {
          obj[header.trim()] = values[i]?.trim() || '';
          return obj;
        }, {});
      });
      setPreviewData(preview);
    };
    reader.readAsText(file);
  };

  const handleUpload = async () => {
  if (!file) {
    setError('Please select a file first');
    return;
  }
  // 2. 防重复上传（若已在上传中，直接返回）
  if (isLoading) return;


  setIsLoading(true);
  setError(null);

  const formData = new FormData();
  formData.append('file', file);

  try {
    const response = await axios.post('/analysis/upload', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
    setAnalysisResult(response.data);
    setSuccess('File uploaded and analyzed successfully');
    setFileInputExpanded(false);
    setSidebarOpen(true); // 上传成功后自动打开侧边栏
  } catch (err) {
    setError(err.response?.data?.error || 'Failed to analyze file');
  } finally {
    setIsLoading(false);
  }
};

  // 处理URL分析的函数
  const handleUrlAnalysis = async () => {
    if (!fileUrl) {
      setError('Please enter a file URL first');
      return;
    }

    // 简单的URL验证
    try {
      new URL(fileUrl);
    } catch (err) {
      setError('Please enter a valid URL');
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      const response = await axios.post('/analysis/url', {
        url: fileUrl
      });
      setAnalysisResult(response.data);
      setFileName(response.data.file_name); // 从响应中获取文件名
      setSuccess('File from URL analyzed successfully');
      setFileInputExpanded(false);
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to analyze file from URL');
    } finally {
      setIsLoading(false);
    }
  };

  const handleCloseSnackbar = () => {
    setError(null);
    setSuccess(null);
  };

  const handleTabChange = (event, newValue) => {
    setActiveTab(newValue);
  };

  // 关键：根据相关系数计算背景色（0→1红渐变，-1→0蓝渐变）
  const getCorrelationColor = (corrValue) => {
    // 处理异常值（如undefined/null，默认白色）
    if (corrValue === undefined || corrValue === null || isNaN(corrValue)) {
      return '#FFFFFF';
    }

    // 限制相关系数在 [-1, 1] 范围内（防止数据异常导致颜色错乱）
    const clampedCorr = Math.max(-1, Math.min(1, corrValue));

    if (clampedCorr > 0) {
      // 正相关：从白色（#FFFFFF）→ 纯大红（#FF0000）
      // 计算红色通道（R=255，固定；G/B从255递减到0，值越大G/B越小，越接近红色）
      const gb = 235 - Math.round(clampedCorr * 235); // 线性映射：0→255，1→0
      return `rgb(235, ${gb}, ${gb})`; // R固定255，G/B同步递减
    } else if (clampedCorr < 0) {
      // 负相关：从白色（#FFFFFF）→ 纯深蓝（#0000FF）
      // 计算蓝色通道（B=255，固定；R/G从255递减到0，值越小R/G越小，越接近蓝色）
      const rg = 235 - Math.round(Math.abs(clampedCorr) * 255); // 线性映射：0→255，-1→0
      return `rgb(${rg}, ${rg}, 235)`; // B固定255，R/G同步递减
    }

    // 0值：纯白色
    return '#FFFFFF';
  };

  // 打开配置对话框
  const openAnalysisConfig = (analysisType) => {
    setCurrentAnalysisType(analysisType);
    setTabValue(0); // 重置Tab
    setOpenConfig(true);
  };

  // 运行带配置的分析
  const runWithConfig = async () => {
    // 验证配置
    if (currentAnalysisType === 'feature_importance' && !featureSelection.target) {
      setError('Please select a target variable for feature importance analysis');
      return;
    }

    if (featureSelection.features.length === 0) {
      setError('Please select at least one feature for analysis');
      return;
    }

    setOpenConfig(false);
    setIsLoading(true);

    try {
      const currentFileName = analysisResult?.file_name || fileName;
      if (!currentFileName) throw new Error("No file available for analysis");

      const response = await axios.post('/analysis/advanced', {
        file_name: currentFileName,
        target: featureSelection.target,
        features: featureSelection.features,
        ignore: featureSelection.ignore,
        analysis_types: [currentAnalysisType],
        algorithms: selectedAlgorithms,
        task_type: featureSelection.taskType, // 传递任务类型
        pca_dimensions: currentAnalysisType === 'pca' ? pcaDimensions : undefined
      });

      // 更新分析结果
      setAnalysisResult(prev => ({
        ...prev,
        ...(currentAnalysisType === 'feature_importance' && {
          feature_importance: response.data.feature_importance
        }),
        ...(currentAnalysisType === 'pca' && {
          pca: response.data.pca
        }),
        shape: prev?.shape || response.data.shape,
        descriptive_stats: prev?.descriptive_stats || response.data.descriptive_stats,
        missing_values: prev?.missing_values || response.data.missing_values,
        numeric_columns: prev?.numeric_columns || response.data.numeric_columns,
        correlation_matrix: prev?.correlation_matrix || response.data.correlation_matrix,
        preview_data: prev?.preview_data || response.data.preview_data
      }));

      setSuccess(`${currentAnalysisType} analysis completed successfully`);
    } catch (error) {
      setError(error.response?.data?.error || error.message || 'Analysis failed');
    } finally {
      setIsLoading(false);
    }
  };

  const renderAnalysisResults = () => {
    if (!analysisResult) return null;

    return (
      <Box sx={{ display: 'flex', minHeight: 'calc(100vh - 120px)' }}>
        {/* 侧边栏导航 */}

        {!sidebarOpen && (
        <FloatingSidebarButton
          onClick={() => setSidebarOpen(true)}
          size="large"
        >
          <MenuIcon />
        </FloatingSidebarButton>
       )}

        <StyledDrawer
        variant={isMobile ? "temporary" : "persistent"}
        open={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
        ModalProps={{
          keepMounted: true, // 更好的移动端性能
        }}
      >
        
         <Box sx={{ 
            display: 'flex', 
            justifyContent: 'flex-end', 
            p: 1,
            borderBottom: `1px solid ${alpha(theme.palette.divider, 0.1)}`
          }}>
            <IconButton
              size="small"
              onClick={() => setSidebarOpen(false)}
              sx={{ 
                color: 'text.secondary',
                '&:hover': {
                  backgroundColor: alpha(theme.palette.primary.main, 0.1),
                }
              }}
            >
              <ChevronLeftIcon />
            </IconButton>
          </Box>

         
        <Box sx={{ p: 2, textAlign: 'center', borderBottom: `1px solid ${alpha(theme.palette.divider, 0.1)}` }}>
          <Typography
            variant="h6"
            sx={{
              fontWeight: 300,
              background: `linear-gradient(45deg, ${theme.palette.primary.main}, ${theme.palette.secondary.main})`,
              backgroundClip: 'text',
              textFillColor: 'transparent',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
            }}
          >
            Navigation
          </Typography>
          <Typography variant="caption" color="text.secondary">
            {analysisResult?.file_name || fileName}
          </Typography>
        </Box>

        <List sx={{ p: 1 }}>
          {analysisItems.map((item) => (
            <SidebarListItem
              key={item.id}
              selected={activeTab === item.id}
              onClick={() => {
                setActiveTab(item.id);
                if (isMobile) setSidebarOpen(false);
              }}
            >
              <ListItemIcon>
              <item.icon />
              </ListItemIcon>
              <ListItemText
                primary={
                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    {item.label}
                    {item.badge && (
                      <Chip
                        label={item.badge}
                        size="small"
                        color={item.color || 'default'}
                        sx={{
                          ml: 1,
                          height: 20,
                          fontSize: '0.5rem',
                          fontWeight: 400
                        }}
                      />
                    )}
                  </Box>
                }
              />
              {activeTab === item.id && (
                <ChevronRightIcon color="primary" />
              )}
            </SidebarListItem>
          ))}
        </List>

        <Box sx={{ mt: 'auto', p: 2, borderTop: `1px solid ${alpha(theme.palette.divider, 0.1)}` }}>
          <Button
            fullWidth
            variant="outlined"
            startIcon={<HomeIcon />}
            onClick={() => setFileInputExpanded(true)}
            sx={{ borderRadius: 2 }}
          >
            更换文件
          </Button>
        </Box>
      </StyledDrawer>

        {/* 主内容区域 */}
        <Box    component="main"  sx={{flexGrow: 1, p: 3, ml: sidebarOpen && !isMobile ? 0 : 0,transition: 'margin-left 0.3s ease'}}>
          {isMobile && sidebarOpen && (
          <Box
            sx={{
              position: 'fixed',
              top: 0,
              left: 0,
              right: 0,
              bottom: 0,
              backgroundColor: 'rgba(0, 0, 0, 0.5)',
              zIndex: 1199,
            }}
            onClick={() => setSidebarOpen(false)}
          />
        )}

          {/* 概览Tab */}
          {activeTab === 0 && (
            <>

             <Accordion defaultExpanded={false} sx={{ mb: 4, border: '1px solid', borderColor: 'divider' }}>
      <AccordionSummary expandIcon={<ExpandMoreIcon />} sx={{ minHeight: 56 }}>
        <Typography variant="subtitle1" sx={{ display: 'flex', alignItems: 'center', fontWeight: 500 }}>
          <AssessmentIcon sx={{ mr: 1, fontSize: 20 }} />
          Overview:数据质量评估框架
        </Typography>
      </AccordionSummary>
      <AccordionDetails>
        <Box sx={{ p: 2, backgroundColor: 'grey.50', borderRadius: 1, mb: 2 }}>
          <Typography variant="body2" color="text.secondary">
            数据质量是分析可靠性的基础，通过系统性评估为后续深度分析提供数据保障
          </Typography>
        </Box>

        <Typography variant="h6" gutterBottom color="primary" sx={{ fontWeight: 600 }}>
          数据质量维度
        </Typography>
        
        <Grid container spacing={2} sx={{ mb: 2 }}>
          <Grid item xs={12} md={6}>
            <Box sx={{ p: 2, border: '1px solid', borderColor: 'divider', borderRadius: 1, height: '100%' }}>
              <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600, display: 'flex', alignItems: 'center' }}>
                <Box component="span" sx={{ width: 24, height: 24, backgroundColor: 'info.main', color: 'white', borderRadius: '50%', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', mr: 1, fontSize: 12 }}>1</Box>
                Database Integrity:数据完整性
              </Typography>
              <Typography variant="body2" color="text.secondary">
                评估数据记录的完整程度，识别缺失值比例和分布，确保分析基础可靠性
              </Typography>
            </Box>
          </Grid>
          
          <Grid item xs={12} md={6}>
            <Box sx={{ p: 2, border: '1px solid', borderColor: 'divider', borderRadius: 1, height: '100%' }}>
              <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600, display: 'flex', alignItems: 'center' }}>
                <Box component="span" sx={{ width: 24, height: 24, backgroundColor: 'info.main', color: 'white', borderRadius: '50%', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', mr: 1, fontSize: 12 }}>2</Box>
                数据规模评估
              </Typography>
              <Typography variant="body2" color="text.secondary">
                分析数据集的观测值和变量数量，评估分析粒度和统计显著性基础
              </Typography>
            </Box>
          </Grid>
        </Grid>

        <Typography variant="h6" gutterBottom color="primary" sx={{ fontWeight: 600, mt: 3 }}>
          评估方法论
        </Typography>
        
        <Box component="ol" sx={{ pl: 2, mb: 2 }}>
          <li>
            <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600 }}>
              基础统计描述
            </Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
              通过行数、列数等基础指标建立数据规模认知
            </Typography>
          </li>
          <li>
            <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600 }}>
              缺失值诊断
            </Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
              系统扫描各变量缺失情况，评估数据完整性风险
            </Typography>
          </li>
          <li>
            <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600 }}>
              数据类型鉴定
            </Typography>
            <Typography variant="body2" color="text.secondary">
              区分数值型与分类型变量，为后续分析方法选择提供依据
            </Typography>
          </li>
        </Box>

        <Box sx={{ p: 2, backgroundColor: 'info.light', borderRadius: 1 }}>
          <Typography variant="body2" color="info.contrastText">
            <strong>输出价值：</strong>建立数据质量基线，识别数据治理重点，为深度分析提供可靠性保障
          </Typography>
        </Box>
      </AccordionDetails>
    </Accordion> 
             
              <Grid container spacing={3} sx={{ mb: 3 }}>
                <Grid item xs={12} sm={6} md={3}>
                  <StatCard
                    title="总行数"
                    value={analysisResult.shape?.rows || 0}
                    icon={InsertDriveFileIcon}
                    color="info.main"
                  />
                </Grid>
                <Grid item xs={12} sm={6} md={3}>
                  <StatCard
                    title="总列数"
                    value={analysisResult.shape?.columns || 0}
                    icon={AssessmentIcon}
                    color="success.main"
                  />
                </Grid>
                <Grid item xs={12} sm={6} md={3}>
                  <StatCard
                    title="缺失值"
                    value={analysisResult.missing_values?.total || 0}
                    icon={FindReplaceIcon}
                    color="warning.main"
                  />
                </Grid>
                <Grid item xs={12} sm={6} md={3}>
                  <StatCard
                    title="数值列"
                    value={analysisResult.numeric_columns?.length || 0}
                    icon={ShowChartIcon}
                    color="primary.main"
                  />
                </Grid>
              </Grid>

              <AnalysisSection title="数据样本预览" icon={DescriptionIcon} variant="minimal">
                <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                通过数据样本检视，验证数据结构和质量，确保后续分析的数据基础可靠性
              </Typography>
                <DataTable data={previewData} title="前10行数据" />
              </AnalysisSection>
            </>
          )}

          {/* 统计Tab */}
          {activeTab === 1 && (
            <>
              {/* 数据统计介绍 - 默认折叠 */}
     <Accordion defaultExpanded={false} sx={{ mb: 4, border: '1px solid', borderColor: 'divider' }}>
      <AccordionSummary expandIcon={<ExpandMoreIcon />} sx={{ minHeight: 56 }}>
        <Typography variant="subtitle1" sx={{ display: 'flex', alignItems: 'center', fontWeight: 500 }}>
          <TrendingUpIcon sx={{ mr: 1, fontSize: 20 }} />
          Abstract:统计描述分析框架
        </Typography>
      </AccordionSummary>
      <AccordionDetails>
        <Box sx={{ p: 2, backgroundColor: 'grey.50', borderRadius: 1, mb: 2 }}>
          <Typography variant="body2" color="text.secondary">
            通过系统性统计描述，建立数据分布认知，为后续推断性分析奠定基础
          </Typography>
        </Box>

        <Typography variant="h6" gutterBottom color="primary" sx={{ fontWeight: 600 }}>
          统计描述维度
        </Typography>
        
        <Grid container spacing={2} sx={{ mb: 2 }}>
          <Grid item xs={12} md={6}>
            <Box sx={{ p: 2, border: '1px solid', borderColor: 'divider', borderRadius: 1, height: '100%' }}>
              <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600, display: 'flex', alignItems: 'center' }}>
                <Box component="span" sx={{ width: 24, height: 24, backgroundColor: 'success.main', color: 'white', borderRadius: '50%', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', mr: 1, fontSize: 12 }}>1</Box>
                集中趋势分析
              </Typography>
              <Typography variant="body2" color="text.secondary">
                通过均值、中位数等指标识别数据分布的中心位置，反映典型水平
              </Typography>
            </Box>
          </Grid>
          
          <Grid item xs={12} md={6}>
            <Box sx={{ p: 2, border: '1px solid', borderColor: 'divider', borderRadius: 1, height: '100%' }}>
              <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600, display: 'flex', alignItems: 'center' }}>
                <Box component="span" sx={{ width: 24, height: 24, backgroundColor: 'success.main', color: 'white', borderRadius: '50%', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', mr: 1, fontSize: 12 }}>2</Box>
                离散程度评估
              </Typography>
              <Typography variant="body2" color="text.secondary">
                通过标准差、极差等指标衡量数据波动性，评估风险稳定性
              </Typography>
            </Box>
          </Grid>

          <Grid item xs={12} md={6}>
            <Box sx={{ p: 2, border: '1px solid', borderColor: 'divider', borderRadius: 1, height: '100%' }}>
              <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600, display: 'flex', alignItems: 'center' }}>
                <Box component="span" sx={{ width: 24, height: 24, backgroundColor: 'success.main', color: 'white', borderRadius: '50%', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', mr: 1, fontSize: 12 }}>3</Box>
                分布形态诊断
              </Typography>
              <Typography variant="body2" color="text.secondary">
                通过偏度、峰度等指标分析数据分布形态，识别异常分布模式
              </Typography>
            </Box>
          </Grid>

          <Grid item xs={12} md={6}>
            <Box sx={{ p: 2, border: '1px solid', borderColor: 'divider', borderRadius: 1, height: '100%' }}>
              <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600, display: 'flex', alignItems: 'center' }}>
                <Box component="span" sx={{ width: 24, height: 24, backgroundColor: 'success.main', color: 'white', borderRadius: '50%', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', mr: 1, fontSize: 12 }}>4</Box>
                极值识别
              </Typography>
              <Typography variant="body2" color="text.secondary">
                通过最小最大值分析，识别数据边界和潜在异常值点
              </Typography>
            </Box>
          </Grid>
        </Grid>

        <Typography variant="h6" gutterBottom color="primary" sx={{ fontWeight: 600, mt: 3 }}>
          分析应用价值
        </Typography>
        
        <Box component="ul" sx={{ pl: 2, mb: 2 }}>
          <li>
            <Typography variant="body2" color="text.secondary">
              <strong>业务理解：</strong>建立关键业务指标的数值认知基础
            </Typography>
          </li>
          <li>
            <Typography variant="body2" color="text.secondary">
              <strong>数据质量验证：</strong>通过统计特征验证数据采集质量
            </Typography>
          </li>
          <li>
            <Typography variant="body2" color="text.secondary">
              <strong>分析准备：</strong>为后续建模分析提供数据特征洞察
            </Typography>
          </li>
        </Box>

        <Box sx={{ p: 2, backgroundColor: 'success.light', borderRadius: 1 }}>
          <Typography variant="body2" color="success.contrastText">
            <strong>决策支持：</strong>为业务目标设定、绩效评估和风险管控提供量化基准
          </Typography>
        </Box>
      </AccordionDetails>
    </Accordion>
 
              <AnalysisSection title="统计描述摘要" icon={AssessmentIcon} variant="minimal">
                <DataTable
                  data={analysisResult.descriptive_stats || []}
                  title="全面统计描述报告"
                />
              </AnalysisSection>
            </>
          )}

          {/* 缺失值Tab */}
          {activeTab === 2 && (
            <>
          <Accordion defaultExpanded={false} sx={{ mb: 4, border: '1px solid', borderColor: 'divider' }}>
      <AccordionSummary expandIcon={<ExpandMoreIcon />} sx={{ minHeight: 56 }}>
        <Typography variant="subtitle1" sx={{ display: 'flex', alignItems: 'center', fontWeight: 500 }}>
          <FindReplaceIcon sx={{ mr: 1, fontSize: 20 }} />
          Database Integrity:数据完整性治理框架
        </Typography>
      </AccordionSummary>
      <AccordionDetails>
        <Box sx={{ p: 2, backgroundColor: 'grey.50', borderRadius: 1, mb: 2 }}>
          <Typography variant="body2" color="text.secondary">
            系统性诊断数据缺失模式，制定数据治理策略，确保分析结果可靠性
          </Typography>
        </Box>

        <Typography variant="h6" gutterBottom color="primary" sx={{ fontWeight: 600 }}>
          缺失值分析维度
        </Typography>
        
        <Grid container spacing={2} sx={{ mb: 2 }}>
          <Grid item xs={12} md={6}>
            <Box sx={{ p: 2, border: '1px solid', borderColor: 'divider', borderRadius: 1, height: '100%' }}>
              <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600, display: 'flex', alignItems: 'center' }}>
                <Box component="span" sx={{ width: 24, height: 24, backgroundColor: 'warning.main', color: 'white', borderRadius: '50%', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', mr: 1, fontSize: 12 }}>1</Box>
                缺失模式诊断
              </Typography>
              <Typography variant="body2" color="text.secondary">
                识别完全随机缺失、随机缺失、非随机缺失等模式，评估缺失机制
              </Typography>
            </Box>
          </Grid>
          
          <Grid item xs={12} md={6}>
            <Box sx={{ p: 2, border: '1px solid', borderColor: 'divider', borderRadius: 1, height: '100%' }}>
              <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600, display: 'flex', alignItems: 'center' }}>
                <Box component="span" sx={{ width: 24, height: 24, backgroundColor: 'warning.main', color: 'white', borderRadius: '50%', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', mr: 1, fontSize: 12 }}>2</Box>
                影响程度评估
              </Typography>
              <Typography variant="body2" color="text.secondary">
                量化缺失值对分析结果的影响程度，制定风险应对策略
              </Typography>
            </Box>
          </Grid>
        </Grid>

        <Typography variant="h6" gutterBottom color="primary" sx={{ fontWeight: 600, mt: 3 }}>
          治理方法论
        </Typography>
        
        <Box component="ol" sx={{ pl: 2, mb: 2 }}>
          <li>
            <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600 }}>
              缺失模式识别
            </Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
              通过缺失值分布分析，识别系统性缺失模式
            </Typography>
          </li>
          <li>
            <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600 }}>
              关键变量优先级排序
            </Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
              基于业务重要性，确定数据治理的优先级顺序
            </Typography>
          </li>
          <li>
            <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600 }}>
              处理策略制定
            </Typography>
            <Typography variant="body2" color="text.secondary">
              根据缺失机制选择删除、插补或模型调整等处理方案
            </Typography>
          </li>
        </Box>

        <Box sx={{ p: 2, backgroundColor: 'warning.light', borderRadius: 1 }}>
          <Typography variant="body2" color="warning.contrastText">
            <strong>治理价值：</strong>提升数据质量，降低分析偏差风险，增强决策可靠性
          </Typography>
        </Box>
      </AccordionDetails>
    </Accordion>
              
              <AnalysisSection title="缺失值诊断报告" icon={FindReplaceIcon} variant="minimal">
                <DataTable
                  data={analysisResult.missing_values?.by_column || []}
                  title="系统性缺失值分析"
                />
              </AnalysisSection>
            </>
          )}

          {/* 相关性Tab */}
          {activeTab === 3 && (
            <>
              
              {/* 相关性分析介绍 */}
            <Accordion defaultExpanded={false} sx={{ mb: 4, border: '1px solid', borderColor: 'divider' }}>
              <AccordionSummary expandIcon={<ExpandMoreIcon />} sx={{ minHeight: 56 }}>
                <Typography variant="subtitle1" sx={{ display: 'flex', alignItems: 'center', fontWeight: 500 }}>
                  <LinkIcon sx={{ mr: 1, fontSize: 20 }} />
                  Correlation变量关系网络分析框架
                </Typography>
              </AccordionSummary>
              <AccordionDetails>
                <Box sx={{ p: 2, backgroundColor: 'grey.50', borderRadius: 1, mb: 2 }}>
                  <Typography variant="body2" color="text.secondary">
                    通过系统性变量关系分析，揭示业务指标间的内在联系，构建因果关系假设
                  </Typography>
                </Box>

                <Typography variant="h6" gutterBottom color="primary" sx={{ fontWeight: 600 }}>
                  相关性分析维度
                </Typography>
                
                <Grid container spacing={2} sx={{ mb: 2 }}>
                  <Grid item xs={12} md={6}>
                    <Box sx={{ p: 2, border: '1px solid', borderColor: 'divider', borderRadius: 1, height: '100%' }}>
                      <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600, display: 'flex', alignItems: 'center' }}>
                        <Box component="span" sx={{ width: 24, height: 24, backgroundColor: 'info.main', color: 'white', borderRadius: '50%', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', mr: 1, fontSize: 12 }}>1</Box>
                        线性关系探测
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        通过皮尔逊系数识别变量间线性关联强度和方向
                      </Typography>
                    </Box>
                  </Grid>
                  
                  <Grid item xs={12} md={6}>
                    <Box sx={{ p: 2, border: '1px solid', borderColor: 'divider', borderRadius: 1, height: '100%' }}>
                      <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600, display: 'flex', alignItems: 'center' }}>
                        <Box component="span" sx={{ width: 24, height: 24, backgroundColor: 'info.main', color: 'white', borderRadius: '50%', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', mr: 1, fontSize: 12 }}>2</Box>
                        多重共线性诊断
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        识别高度相关变量组，避免建模中的多重共线性问题
                      </Typography>
                    </Box>
                  </Grid>
                </Grid>

                <Typography variant="h6" gutterBottom color="primary" sx={{ fontWeight: 600, mt: 3 }}>
                  分析应用场景
                </Typography>
                
                <Box component="ul" sx={{ pl: 2, mb: 2 }}>
                  <li>
                    <Typography variant="body2" color="text.secondary">
                      <strong>业务驱动因素识别：</strong>发现影响关键绩效指标的主要变量
                    </Typography>
                  </li>
                  <li>
                    <Typography variant="body2" color="text.secondary">
                      <strong>变量筛选：</strong>为机器学习特征工程提供依据
                    </Typography>
                  </li>
                  <li>
                    <Typography variant="body2" color="text.secondary">
                      <strong>因果关系假设：</strong>构建可进一步验证的因果假设
                    </Typography>
                  </li>
                </Box>

                <Box sx={{ p: 2, backgroundColor: 'info.light', borderRadius: 1 }}>
                  <Typography variant="body2" color="info.contrastText">
                    <strong>分析价值：</strong>从孤立指标分析升级为系统关系网络分析，揭示业务内在逻辑
                  </Typography>
                </Box>
              </AccordionDetails>
            </Accordion>
              
              <AnalysisSection title="相关性矩阵" icon={ShowChartIcon} variant="minimal">
                {analysisResult.correlation_matrix && analysisResult.numeric_columns && (
                  <>
                    <TableContainer component={Paper} sx={{ maxHeight: 440, overflow: 'auto' }}>
                      <Table stickyHeader size="small">
                        <TableHead>
                          <TableRow>
                            <TableCell
                              sx={{
                                fontWeight: 'bold',
                                position: 'sticky',
                                left: 0,
                                background: 'white',
                                zIndex: 1
                              }}
                            >
                              变量
                            </TableCell>
                            {analysisResult.numeric_columns.map((col) => (
                              <TableCell
                                key={col}
                                sx={{
                                  fontWeight: 'bold',
                                  background: 'rgb(245, 245, 245)'
                                }}
                                align="right"
                              >
                                {col}
                              </TableCell>
                            ))}
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          {analysisResult.correlation_matrix.map((row) => {
                            if (!row || !row.values) return null;

                            const currentColumn = row.column;
                            if (!analysisResult.numeric_columns.includes(currentColumn)) return null;

                            return (
                              <TableRow key={currentColumn}>
                                <TableCell
                                  component="th"
                                  scope="row"
                                  sx={{
                                    fontWeight: 'bold',
                                    position: 'sticky',
                                    left: 0,
                                    background: 'white',
                                    zIndex: 1
                                  }}
                                >
                                  {currentColumn}
                                </TableCell>
                                {analysisResult.numeric_columns.map((col) => {
                                  const corrValue = row.values[col];
                                  const bgColor = getCorrelationColor(corrValue);
                                  return (
                                    <TableCell
                                      key={`${currentColumn}-${col}`}
                                      align="right"
                                      sx={{
                                        background: bgColor,
                                        border: '1px solid rgba(224, 224, 224, 0.5)',
                                        color: Math.abs(corrValue) > 0.8 ? 'white' : 'inherit',
                                        fontWeight: Math.abs(corrValue) > 0.8 ? 'medium' : 'normal'
                                      }}
                                    >
                                      {corrValue !== undefined ? corrValue.toFixed(4) : '-'}
                                    </TableCell>
                                  );
                                })}
                              </TableRow>
                            );
                          })}
                        </TableBody>
                      </Table>
                    </TableContainer>
                    <Box mt={2}>
                      <Typography variant="body2" color="text.secondary">
                        皮尔逊相关系数 (取值范围: -1 到 1)
                      </Typography>
                      <Typography variant="caption" color="text.secondary">
                        正相关 (0→1): 浅灰到深红色渐变 | 负相关 (-1→0): 浅灰到深蓝色渐变
                      </Typography>
                    </Box>
                  </>
                )}
              </AnalysisSection>
            </>
          )}

          {/* 特征重要性Tab */}
          {activeTab === 4 && (
            <>
               {/* 特征重要性介绍 */}
   {/* 特征重要性介绍 - 默认折叠 */}
    <Accordion defaultExpanded={false} sx={{ mb: 4, border: '1px solid', borderColor: 'divider' }}>
      <AccordionSummary expandIcon={<ExpandMoreIcon />} sx={{ minHeight: 56 }}>
        <Typography variant="subtitle1" sx={{ display: 'flex', alignItems: 'center', fontWeight: 500 }}>
          <CalculateIcon sx={{ mr: 1, fontSize: 20 }} />
          Feature Selection:变量影响力评估框架
        </Typography>
      </AccordionSummary>
      <AccordionDetails>
        <Box sx={{ p: 2, backgroundColor: 'grey.50', borderRadius: 1, mb: 2 }}>
          <Typography variant="body2" color="text.secondary">
            通过多算法集成评估，量化各特征对目标变量的预测贡献度，识别关键驱动因素
          </Typography>
        </Box>

        <Typography variant="h6" gutterBottom color="primary" sx={{ fontWeight: 600 }}>
          评估方法论体系
        </Typography>
        
        <Grid container spacing={2} sx={{ mb: 2 }}>
          <Grid item xs={12} md={6}>
            <Box sx={{ p: 2, border: '1px solid', borderColor: 'divider', borderRadius: 1, height: '100%' }}>
              <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600, display: 'flex', alignItems: 'center' }}>
                <Box component="span" sx={{ width: 24, height: 24, backgroundColor: 'primary.main', color: 'white', borderRadius: '50%', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', mr: 1, fontSize: 12 }}>1</Box>
                树模型评估
              </Typography>
              <Typography variant="body2" color="text.secondary">
                基于随机森林、GBDT等树模型，通过分裂增益评估特征重要性
              </Typography>
            </Box>
          </Grid>
          
          <Grid item xs={12} md={6}>
            <Box sx={{ p: 2, border: '1px solid', borderColor: 'divider', borderRadius: 1, height: '100%' }}>
              <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600, display: 'flex', alignItems: 'center' }}>
                <Box component="span" sx={{ width: 24, height: 24, backgroundColor: 'primary.main', color: 'white', borderRadius: '50%', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', mr: 1, fontSize: 12 }}>2</Box>
                线性模型系数
              </Typography>
              <Typography variant="body2" color="text.secondary">
                通过线性回归系数绝对值评估特征对目标的线性影响强度
              </Typography>
            </Box>
          </Grid>

          <Grid item xs={12} md={6}>
            <Box sx={{ p: 2, border: '1px solid', borderColor: 'divider', borderRadius: 1, height: '100%' }}>
              <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600, display: 'flex', alignItems: 'center' }}>
                <Box component="span" sx={{ width: 24, height: 24, backgroundColor: 'primary.main', color: 'white', borderRadius: '50%', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', mr: 1, fontSize: 12 }}>3</Box>
                互信息分析
              </Typography>
              <Typography variant="body2" color="text.secondary">
                评估特征与目标变量间的非线性关联强度，捕捉复杂关系
              </Typography>
            </Box>
          </Grid>

          <Grid item xs={12} md={6}>
            <Box sx={{ p: 2, border: '1px solid', borderColor: 'divider', borderRadius: 1, height: '100%' }}>
              <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600, display: 'flex', alignItems: 'center' }}>
                <Box component="span" sx={{ width: 24, height: 24, backgroundColor: 'primary.main', color: 'white', borderRadius: '50%', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', mr: 1, fontSize: 12 }}>4</Box>
                 permutation重要性
              </Typography>
              <Typography variant="body2" color="text.secondary">
                通过特征值随机置换，评估模型性能下降程度，验证特征重要性
              </Typography>
            </Box>
          </Grid>
        </Grid>

        <Typography variant="h6" gutterBottom color="primary" sx={{ fontWeight: 600, mt: 3 }}>
          业务应用场景
        </Typography>
        
        <Box component="ul" sx={{ pl: 2, mb: 2 }}>
          <li>
            <Typography variant="body2" color="text.secondary">
              <strong>关键驱动因素识别：</strong>定位影响业务核心指标的关键变量
            </Typography>
          </li>
          <li>
            <Typography variant="body2" color="text.secondary">
              <strong>特征工程优化：</strong>为机器学习模型提供特征筛选依据
            </Typography>
          </li>
          <li>
            <Typography variant="body2" color="text.secondary">
              <strong>资源分配决策：</strong>基于影响力分析制定精准的业务投入策略
            </Typography>
          </li>
          <li>
            <Typography variant="body2" color="text.secondary">
              <strong>业务假设验证：</strong>量化验证业务经验判断的准确性
            </Typography>
          </li>
        </Box>

        <Box sx={{ p: 2, backgroundColor: 'primary.light', borderRadius: 1 }}>
          <Typography variant="body2" color="primary.contrastText">
            <strong>决策价值：</strong>从经验驱动升级为数据驱动的决策模式，提升资源配置效率
          </Typography>
        </Box>
      </AccordionDetails>
    </Accordion>
    
              <AnalysisSection
                title="特征筛选"
                icon={AssessmentIcon}
                actionButton={
                  <Button
                    variant="outlined"
                    startIcon={<SettingsIcon />}
                    onClick={() => openAnalysisConfig('feature_importance')}
                  >
                    配置分析
                  </Button>
                }
                variant="minimal"
              >
                {isLoading && currentAnalysisType === 'feature_importance' ? (
                  <Box display="flex" justifyContent="center" my={4}>
                    <CircularProgress />
                  </Box>
                ) : analysisResult.feature_importance ? (
                  <DataTable
                    data={analysisResult.feature_importance}
                    title="特征重要性评分"
                  />
                ) : (
                  <Box my={3}>
                    <Typography variant="body1" gutterBottom>
                      特征重要性分析帮助识别哪些特征对目标变量影响最大。
                    </Typography>
                    <Button
                      variant="contained"
                      startIcon={<CalculateIcon />}
                      onClick={() => openAnalysisConfig('feature_importance')}
                      sx={{ mt: 2 }}
                    >
                      开始分析
                    </Button>
                  </Box>
                )}
              </AnalysisSection>
            </>
          )}

          {/* PCA分析Tab */}
          {activeTab === 5 && (
  <>
    <Typography variant="h5" gutterBottom sx={{ mb: 3, display: 'flex', alignItems: 'center' }}>
      <ScatterPlotIcon sx={{ mr: 1 }} />Principle Component Analysis:主成份分析
    </Typography>
    
    {/* PCA分析介绍 - 默认折叠 */}
    <Accordion defaultExpanded={false} sx={{ mb: 4, border: '1px solid', borderColor: 'divider' }}>
      <AccordionSummary expandIcon={<ExpandMoreIcon />} sx={{ minHeight: 56 }}>
        <Typography variant="subtitle1" sx={{ display: 'flex', alignItems: 'center', fontWeight: 500 }}>
          <AccountTreeIcon sx={{ mr: 1, fontSize: 20 }} />
          维度约简与特征提取框架
        </Typography>
      </AccordionSummary>
      <AccordionDetails>
        <Box sx={{ p: 2, backgroundColor: 'grey.50', borderRadius: 1, mb: 2 }}>
          <Typography variant="body2" color="text.secondary">
            通过正交变换将相关变量转换为线性不相关的主成份，实现数据降维与结构洞察
          </Typography>
        </Box>

        <Typography variant="h6" gutterBottom color="primary" sx={{ fontWeight: 600 }}>
          分析价值维度
        </Typography>
        
        <Grid container spacing={2} sx={{ mb: 2 }}>
          <Grid item xs={12} md={6}>
            <Box sx={{ p: 2, border: '1px solid', borderColor: 'divider', borderRadius: 1, height: '100%' }}>
              <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600, display: 'flex', alignItems: 'center' }}>
                <Box component="span" sx={{ width: 24, height: 24, backgroundColor: 'secondary.main', color: 'white', borderRadius: '50%', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', mr: 1, fontSize: 12 }}>1</Box>
                数据压缩与降维
              </Typography>
              <Typography variant="body2" color="text.secondary">
                将高维数据投影到低维空间，保留最大方差信息，提升计算效率
              </Typography>
            </Box>
          </Grid>
          
          <Grid item xs={12} md={6}>
            <Box sx={{ p: 2, border: '1px solid', borderColor: 'divider', borderRadius: 1, height: '100%' }}>
              <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600, display: 'flex', alignItems: 'center' }}>
                <Box component="span" sx={{ width: 24, height: 24, backgroundColor: 'secondary.main', color: 'white', borderRadius: '50%', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', mr: 1, fontSize: 12 }}>2</Box>
                特征结构解析
              </Typography>
              <Typography variant="body2" color="text.secondary">
                揭示原始变量间的内在关联模式，识别潜在的业务维度
              </Typography>
            </Box>
          </Grid>

          <Grid item xs={12} md={6}>
            <Box sx={{ p: 2, border: '1px solid', borderColor: 'divider', borderRadius: 1, height: '100%' }}>
              <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600, display: 'flex', alignItems: 'center' }}>
                <Box component="span" sx={{ width: 24, height: 24, backgroundColor: 'secondary.main', color: 'white', borderRadius: '50%', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', mr: 1, fontSize: 12 }}>3</Box>
                噪声过滤
              </Typography>
              <Typography variant="body2" color="text.secondary">
                通过主成分选择，过滤随机噪声，增强信号强度
              </Typography>
            </Box>
          </Grid>

          <Grid item xs={12} md={6}>
            <Box sx={{ p: 2, border: '1px solid', borderColor: 'divider', borderRadius: 1, height: '100%' }}>
              <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600, display: 'flex', alignItems: 'center' }}>
                <Box component="span" sx={{ width: 24, height: 24, backgroundColor: 'secondary.main', color: 'white', borderRadius: '50%', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', mr: 1, fontSize: 12 }}>4</Box>
                可视化优化
              </Typography>
              <Typography variant="body2" color="text.secondary">
                将高维数据降至2-3维，实现复杂数据的直观可视化展示
              </Typography>
            </Box>
          </Grid>
        </Grid>

        <Typography variant="h6" gutterBottom color="primary" sx={{ fontWeight: 600, mt: 3 }}>
          方法论框架
        </Typography>
        
        <Box component="ol" sx={{ pl: 2, mb: 2 }}>
          <li>
            <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600 }}>
              协方差矩阵分解
            </Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
              通过特征值分解，识别数据变化的主要方向
            </Typography>
          </li>
          <li>
            <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600 }}>
              主成分提取
            </Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
              按解释方差比例降序提取主成分，确保信息最大保留
            </Typography>
          </li>
          <li>
            <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600 }}>
              维度选择决策
            </Typography>
            <Typography variant="body2" color="text.secondary">
              基于陡坡图或累计解释方差确定最优主成分数量
            </Typography>
          </li>
        </Box>

        <Box sx={{ p: 2, backgroundColor: 'secondary.light', borderRadius: 1 }}>
          <Typography variant="body2" color="secondary.contrastText">
            <strong>业务价值：</strong>从变量级分析升级为维度级洞察，为多维数据提供结构化的分析框架
          </Typography>
        </Box>
      </AccordionDetails>
    </Accordion>

    {/* 如何解读主成分 - 默认折叠 */}
    <Accordion defaultExpanded={false} sx={{ mb: 3 }}>
      <AccordionSummary expandIcon={<ExpandMoreIcon />}>
        <Typography variant="subtitle2" sx={{ display: 'flex', alignItems: 'center' }}>
          📖 <Box component="span" sx={{ ml: 1 }}>如何解读主成分</Box>
        </Typography>
      </AccordionSummary>
      <AccordionDetails>
        <Typography variant="body2" color="text.secondary">
          <strong>解读主成分的步骤：</strong>
          <Box component="ol" sx={{ pl: 2, mt: 1, mb: 1 }}>
            <li>查看<strong>解释方差</strong>：了解每个主成分包含的信息量占比</li>
            <li>分析<strong>主成分权重</strong>：看哪些原始变量对主成分贡献大</li>
            <li>观察<strong>权重符号</strong>：正权重表示正影响，负权重表示负影响</li>
            <li>结合<strong>业务知识</strong>：给主成分赋予实际意义</li>
          </Box>
          
          <strong>实际应用示例：</strong>
          <Box component="ul" sx={{ pl: 2, mt: 1, mb: 1 }}>
            <li>如果PC1中"收入"和"教育程度"的权重都很大且为正，可能代表"社会经济地位"</li>
            <li>如果PC2中"年龄"权重为正而"创新能力"权重为负，可能代表"传统vs创新"维度</li>
          </Box>
          
          <Box sx={{ p: 1, backgroundColor: 'info.light', borderRadius: 1, mt: 2 }}>
            <Typography variant="caption" component="div" color="info.contrastText">
              🎯 <strong>实用建议：</strong>通常前2-3个主成分就能解释大部分数据变化，重点关注这些主成分即可。
            </Typography>
          </Box>
        </Typography>
      </AccordionDetails>
    </Accordion>

    <AnalysisSection
      title="主成分分析 (PCA)"
      icon={AccountTreeIcon}
      actionButton={
        <Button
          variant="outlined"
          startIcon={<SettingsIcon />}
          onClick={() => openAnalysisConfig('pca')}
        >
          配置分析
        </Button>
      }
      variant="minimal"
    >
      <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
        💡 首先选择要生成的主成分数量，系统会自动计算各主成分的权重和解释方差。
      </Typography>
      
      {isLoading && currentAnalysisType === 'pca' ? (
        <Box display="flex" justifyContent="center" my={4}>
          <CircularProgress />
        </Box>
      ) : analysisResult.pca ? (
        <>
          <Grid container spacing={3}>
            <Grid item xs={12} md={6}>
              <Paper sx={{ p: 2 }}>
                <Typography variant="h6" gutterBottom>
                  解释方差比例
                  <Typography variant="caption" color="text.secondary" sx={{ ml: 1 }}>
                    （每个主成分包含的信息量占比）
                  </Typography>
                </Typography>
                <PieChart
                  series={[
                    {
                      data: analysisResult.pca.explained_variance.map((value, i) => ({
                        id: `PC${i+1}`,
                        value: value * 100,
                        label: `PC${i+1} (${(value*100).toFixed(1)}%)`
                      }))
                    }
                  ]}
                  width={400}
                  height={200}
                />
                <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                  前{analysisResult.pca.explained_variance.length}个主成分共解释<br/>
                  <strong>{(analysisResult.pca.explained_variance.reduce((sum, val) => sum + val, 0) * 100).toFixed(1)}%</strong> 的数据变异
                </Typography>
              </Paper>
            </Grid>
            <Grid item xs={12} md={6}>
              <Paper sx={{ p: 2 }}>
                <Typography variant="h6" gutterBottom>
                  主成分权重
                  <Typography variant="caption" color="text.secondary" sx={{ ml: 1 }}>
                    （原始变量对主成分的贡献程度）
                  </Typography>
                </Typography>
                <DataTable
                  data={analysisResult.pca.components.map((comp, i) => {
                    const row = {
                      feature: `PCA${i+1}`,
                      ...comp.weights
                    };
                    return row;
                  })}
                  title="主成分权重系数"
                />
              </Paper>
            </Grid>
          </Grid>
          
          <Box mt={3}>
            <Typography variant="h6" gutterBottom>
              特征贡献度
              <Typography variant="caption" color="text.secondary" sx={{ ml: 1 }}>
                （每个原始特征对各主成分的贡献）
              </Typography>
            </Typography>
            
            {/* 特征贡献度解读说明 - 默认折叠 */}
            <Accordion defaultExpanded={false} sx={{ mb: 2 }}>
              <AccordionSummary expandIcon={<ExpandMoreIcon />}>
                <Typography variant="subtitle2">
                  💬 如何解读特征贡献度表格
                </Typography>
              </AccordionSummary>
              <AccordionDetails>
                <Typography variant="body2" color="text.secondary">
                  <strong>解读技巧：</strong>
                  <Box component="ul" sx={{ pl: 2, mt: 1, mb: 1 }}>
                    <li>横向看：了解每个特征对各个主成分的影响</li>
                    <li>纵向看：了解每个主成分由哪些特征主要构成</li>
                    <li>找极端值：绝对值大的系数表示重要影响</li>
                    <li>看符号：正负号表示影响方向</li>
                  </Box>
                  
                  <strong>示例：</strong>
                  <Box component="ul" sx={{ pl: 2, mt: 1, mb: 1 }}>
                    <li>如果"收入"在PC1的系数是+0.8，说明收入对第一主成分有很强的正向影响</li>
                    <li>如果"年龄"在PC1的系数是-0.6，说明年龄对第一主成分有较强的负向影响</li>
                  </Box>
                </Typography>
              </AccordionDetails>
            </Accordion>
            
            <TableContainer component={Paper}>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell>
                      <strong>原始特征</strong>
                      <Typography variant="caption" display="block">
                        （您的数据列）
                      </Typography>
                    </TableCell>
                    {analysisResult.pca.components.slice(0, pcaDimensions).map((_, i) => (
                      <TableCell key={`pca-header-${i}`}>
                        <strong>PCA{i+1}</strong>
                        <Typography variant="caption" display="block">
                          ({(analysisResult.pca.explained_variance[i] * 100).toFixed(1)}%)
                        </Typography>
                      </TableCell>
                    ))}
                  </TableRow>
                </TableHead>
                <TableBody>
                  {Object.keys(analysisResult.pca.components[0].weights).map(feature => (
                    <TableRow key={feature}>
                      <TableCell>
                        <strong>{feature}</strong>
                      </TableCell>
                      {analysisResult.pca.components.slice(0, pcaDimensions).map((comp, i) => (
                        <TableCell key={`${feature}-pca${i}`}>
                          <Box sx={{ 
                            color: Math.abs(comp.weights[feature]) > 0.5 ? 'primary.main' : 'text.secondary',
                            fontWeight: Math.abs(comp.weights[feature]) > 0.5 ? 'bold' : 'normal'
                          }}>
                            {comp.weights[feature].toFixed(4)}
                            {Math.abs(comp.weights[feature]) > 0.5 && (
                              <Typography variant="caption" color="primary" display="block">
                                {comp.weights[feature] > 0 ? '强正影响' : '强负影响'}
                              </Typography>
                            )}
                          </Box>
                        </TableCell>
                      ))}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </Box>
        </>
      ) : (
        <Box my={3}>
          <Typography variant="body1" gutterBottom>
            PCA (主成分分析) 可以在保留大部分数据变异的同时降低数据维度。
          </Typography>
          <Button
            variant="contained"
            startIcon={<CalculateIcon />}
            onClick={() => openAnalysisConfig('pca')}
            sx={{ mt: 2 }}
          >
            开始分析
          </Button>
        </Box>
      )}
    </AnalysisSection>
  </>
)}

          {/* BI分析Tab - 重点突出 */}
          {activeTab === 6 && (
            <Box>
              
{/* BI分析详细介绍 */}
  <Accordion defaultExpanded={false} sx={{ mb: 4, border: '1px solid', borderColor: 'divider' }}>
  <AccordionSummary expandIcon={<ExpandMoreIcon />} sx={{ minHeight: 56 }}>
    <Typography variant="subtitle1" sx={{ display: 'flex', alignItems: 'center', fontWeight: 500 }}>
      <AnalyticsIcon sx={{ mr: 1, fontSize: 20 }} />
      Business Intelligence:商业智能分析框架
    </Typography>
  </AccordionSummary>
  <AccordionDetails>
    <Box sx={{ p: 2, backgroundColor: 'grey.50', borderRadius: 1, mb: 2 }}>
      <Typography variant="body2" color="text.secondary">
        BI分析超越基础可视化，通过系统性的数据分析方法为企业决策提供深度洞察
      </Typography>
      <Typography variant="body2" color="text.secondary">
        
        <strong>展示级可视化 vs. 洞察级分析：</strong>传统图表局限于对已知结论的呈现，而BI分析实现了从原始数据到商业洞察的完整价值链。
    通过多维度聚合分析（均值、方差、极值等统计方法）、趋势探测、异常识别和模式发现，BI分析将繁杂的原始数据转化为可行动的决策智慧，
    帮助企业在数据中发掘潜在机会，预见业务风险，优化运营策略，最终实现从"数据展示"到"价值创造"的跨越。
      </Typography>
      <Typography variant="body2" color="text.secondary" paragraph>
    <strong>基础图表 vs. BI深度分析：</strong>
  </Typography>
  
  <Box component="ul" sx={{ pl: 2, mb: 1 }}>
    <li>
      <Typography variant="body2" color="text.secondary">
        <strong>基础图表：</strong>如同展示一张照片，呈现的是静态的结果或事实，用于说明一个已知的结论
      </Typography>
    </li>
    <li>
      <Typography variant="body2" color="text.secondary">
        <strong>BI分析：</strong>如同进行一场科学实验，从原始数据开始，通过聚合、均值、方差、最大最小值等统计方法，
        主动探索数据中的规律，发现未知的洞察
      </Typography>
    </li>
  </Box>

  <Typography variant="body2" color="text.secondary" paragraph>
    <strong>简单比喻：</strong>基础图表是给您看一份烹饪好的菜肴照片，而BI分析是带您进入厨房，
    从挑选食材、调配佐料开始，亲自参与整个烹饪过程，最终理解为什么这道菜会如此美味。
  </Typography>

  <Typography variant="body2" color="text.secondary">
    <strong>核心价值：</strong>BI分析让您从被动的"数据观看者"转变为主动的"洞察发现者"，
    能够在海量数据中自主发现商机、识别风险、优化决策。
  </Typography>
    </Box>

    <Typography variant="h6" gutterBottom color="primary" sx={{ fontWeight: 600 }}>
      分析方法论体系
    </Typography>
    
    <Grid container spacing={2} sx={{ mb: 2 }}>
      <Grid item xs={12} md={6}>
        <Box sx={{ p: 2, border: '1px solid', borderColor: 'divider', borderRadius: 1, height: '100%' }}>
          <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600, display: 'flex', alignItems: 'center' }}>
            <Box component="span" sx={{ width: 24, height: 24, backgroundColor: 'primary.main', color: 'white', borderRadius: '50%', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', mr: 1, fontSize: 12 }}>1</Box>
            对比分析 (Comparative Analysis)
          </Typography>
          <Typography variant="body2" color="text.secondary">
            通过时间序列对比、基准对比、同类群组分析，识别异常值、趋势变化和绩效差距，建立数据参照体系
          </Typography>
        </Box>
      </Grid>
      
      <Grid item xs={12} md={6}>
        <Box sx={{ p: 2, border: '1px solid', borderColor: 'divider', borderRadius: 1, height: '100%' }}>
          <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600, display: 'flex', alignItems: 'center' }}>
            <Box component="span" sx={{ width: 24, height: 24, backgroundColor: 'primary.main', color: 'white', borderRadius: '50%', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', mr: 1, fontSize: 12 }}>2</Box>
            聚合分析 (Aggregation Analysis)
          </Typography>
          <Typography variant="body2" color="text.secondary">
            基于多维度数据汇总，构建KPI指标体系，从宏观到微观呈现业务全景，支持战略层决策
          </Typography>
        </Box>
      </Grid>
      
      <Grid item xs={12} md={6}>
        <Box sx={{ p: 2, border: '1px solid', borderColor: 'divider', borderRadius: 1, height: '100%' }}>
          <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600, display: 'flex', alignItems: 'center' }}>
            <Box component="span" sx={{ width: 24, height: 24, backgroundColor: 'primary.main', color: 'white', borderRadius: '50%', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', mr: 1, fontSize: 12 }}>3</Box>
            下探分析 (Drill-Down Analysis)
          </Typography>
          <Typography variant="body2" color="text.secondary">
            从汇总数据逐层深入至明细数据，定位问题根因，实现从现象到本质的诊断路径
          </Typography>
        </Box>
      </Grid>
      
      <Grid item xs={12} md={6}>
        <Box sx={{ p: 2, border: '1px solid', borderColor: 'divider', borderRadius: 1, height: '100%' }}>
          <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600, display: 'flex', alignItems: 'center' }}>
            <Box component="span" sx={{ width: 24, height: 24, backgroundColor: 'primary.main', color: 'white', borderRadius: '50%', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', mr: 1, fontSize: 12 }}>4</Box>
            交叉分析 (Cross-Dimensional Analysis)
          </Typography>
          <Typography variant="body2" color="text.secondary">
            通过多维度组合分析，揭示变量间隐藏关系，发现细分市场的机会与风险点
          </Typography>
        </Box>
      </Grid>
    </Grid>

    <Typography variant="h6" gutterBottom color="primary" sx={{ fontWeight: 600, mt: 3 }}>
      完整分析叙事框架
    </Typography>
    
    <Box sx={{ p: 2, backgroundColor: 'success.light', color: 'success.contrastText', borderRadius: 1, mb: 2 }}>
      <Typography variant="body2">
        <strong>问题定义 → 数据准备 → 多维分析 → 根因定位 → 洞察提炼 → 行动建议</strong>
      </Typography>
    </Box>

    <Box component="ol" sx={{ pl: 2, mb: 2 }}>
      <li>
        <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600 }}>
          宏观态势把握
        </Typography>
        <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
          通过关键指标汇总，建立业务整体认知，识别主要矛盾点
        </Typography>
      </li>
      <li>
        <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600 }}>
          维度拆解诊断
        </Typography>
        <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
          按时间、地域、产品、渠道等多维度进行问题分解，定位异常维度
        </Typography>
      </li>
      <li>
        <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600 }}>
          深度下探溯源
        </Typography>
        <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
          针对异常维度进行层层下钻，直至定位到具体业务单元或交易明细
        </Typography>
      </li>
      <li>
        <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600 }}>
          关联分析验证
        </Typography>
        <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
          通过交叉维度和相关性分析，验证假设并发现隐藏模式
        </Typography>
      </li>
      <li>
        <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600 }}>
          故事线构建
        </Typography>
        <Typography variant="body2" color="text.secondary">
          将分析发现转化为有逻辑的数据叙事，支持管理层决策
        </Typography>
      </li>
    </Box>

    <Box sx={{ p: 2, backgroundColor: 'warning.light', borderRadius: 1 }}>
      <Typography variant="body2" color="warning.contrastText">
        <strong>价值输出：</strong>从数据展示升级为洞察驱动，为企业战略制定、运营优化、风险管控提供量化依据
      </Typography>
    </Box>
  </AccordionDetails>
</Accordion>

              <Box sx={{ mb: 4 }}>
                <Typography variant="body1" paragraph>
                  BI分析提供高级数据可视化和商业智能洞察，帮助您发现数据中的模式和趋势。
                </Typography>
              </Box>

              <AnalysisSection title="BI分析控制台" icon={BarChartIcon} variant="minimal">
                <BIAnalysis analysisResult={analysisResult} />
              </AnalysisSection>
            </Box>
          )}
        </Box>
      </Box>
    );
  };

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', minHeight: '100vh' }}>
      {/* 顶部标题栏 */}
      <Box sx={{ p: 2, borderBottom: 1, borderColor: 'divider', bgcolor: 'background.paper' }}>
        <Typography variant="h4" component="h1" gutterBottom>
          数据分析平台
        </Typography>
        
         


        {effectiveConfigName ? (
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <Typography variant="subtitle1" color="text.secondary">
              正在分析配置: <strong>{effectiveConfigName}</strong>
            </Typography>
            <Button
              variant="outlined"
              size="small"
              sx={{ ml: 2 }}
              onClick={() => {
                // 清除配置，切换到文件上传模式
                window.location.href = '/analysis';
              }}
            >
              切换到文件上传
            </Button>
          </Box>
        ) : (
          <Accordion
            expanded={fileInputExpanded}
            onChange={() => setFileInputExpanded(!fileInputExpanded)}
            sx={{ mb: fileInputExpanded ? 2 : 0, mt: 2 }}
          >
            <AccordionSummary expandIcon={<ExpandMoreIcon />}>
              <Typography variant="h6">
                {fileInputExpanded ? '隐藏文件输入' : '显示文件输入'}
              </Typography>
            </AccordionSummary>
            <AccordionDetails>
              <StyledPaper sx={{ p: 2 }}>
                <AccordionDetails>
                  <Accordion defaultExpanded={false} sx={{ mb: 3, border: '1px solid', borderColor: 'divider' }}>
        <AccordionSummary expandIcon={<ExpandMoreIcon />} sx={{ minHeight: 48 }}>
          <Typography variant="subtitle2" sx={{ display: 'flex', alignItems: 'center', fontWeight: 500 }}>
            <CloudUploadIcon sx={{ mr: 1, fontSize: 18 }} />
            数据接入与质量管理框架
          </Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Box sx={{ p: 2, backgroundColor: 'grey.50', borderRadius: 1, mb: 2 }}>
            <Typography variant="body2" color="text.secondary">
              建立标准化的数据接入流程，确保数据质量与分析可靠性
            </Typography>
          </Box>

          <Typography variant="subtitle2" gutterBottom color="primary" sx={{ fontWeight: 600 }}>
            数据接入标准
          </Typography>
          
          <Grid container spacing={2} sx={{ mb: 2 }}>
            <Grid item xs={12} md={6}>
              <Box sx={{ p: 1.5, border: '1px solid', borderColor: 'divider', borderRadius: 1 }}>
                <Typography variant="body2" sx={{ fontWeight: 600, display: 'flex', alignItems: 'center' }}>
                  <Box component="span" sx={{ width: 20, height: 20, backgroundColor: 'success.main', color: 'white', borderRadius: '50%', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', mr: 1, fontSize: 10 }}>✓</Box>
                  格式兼容性
                </Typography>
                <Typography variant="caption" color="text.secondary">
                  支持CSV、Excel、JSON等主流数据格式
                </Typography>
              </Box>
            </Grid>
            
            <Grid item xs={12} md={6}>
              <Box sx={{ p: 1.5, border: '1px solid', borderColor: 'divider', borderRadius: 1 }}>
                <Typography variant="body2" sx={{ fontWeight: 600, display: 'flex', alignItems: 'center' }}>
                  <Box component="span" sx={{ width: 20, height: 20, backgroundColor: 'success.main', color: 'white', borderRadius: '50%', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', mr: 1, fontSize: 10 }}>✓</Box>
                  结构规范性
                </Typography>
                <Typography variant="caption" color="text.secondary">
                  首行为列标题，确保数据结构清晰
                </Typography>
              </Box>
            </Grid>

            <Grid item xs={12} md={6}>
              <Box sx={{ p: 1.5, border: '1px solid', borderColor: 'divider', borderRadius: 1 }}>
                <Typography variant="body2" sx={{ fontWeight: 600, display: 'flex', alignItems: 'center' }}>
                  <Box component="span" sx={{ width: 20, height: 20, backgroundColor: 'success.main', color: 'white', borderRadius: '50%', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', mr: 1, fontSize: 10 }}>✓</Box>
                  编码标准化
                </Typography>
                <Typography variant="caption" color="text.secondary">
                  推荐UTF-8编码，避免字符集兼容问题
                </Typography>
              </Box>
            </Grid>

            <Grid item xs={12} md={6}>
              <Box sx={{ p: 1.5, border: '1px solid', borderColor: 'divider', borderRadius: 1 }}>
                <Typography variant="body2" sx={{ fontWeight: 600, display: 'flex', alignItems: 'center' }}>
                  <Box component="span" sx={{ width: 20, height: 20, backgroundColor: 'success.main', color: 'white', borderRadius: '50%', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', mr: 1, fontSize: 10 }}>✓</Box>
                  规模合理性
                </Typography>
                <Typography variant="caption" color="text.secondary">
                  单文件建议不超过10MB，确保分析效率
                </Typography>
              </Box>
            </Grid>
          </Grid>

          <Typography variant="subtitle2" gutterBottom color="primary" sx={{ fontWeight: 600, mt: 2 }}>
            接入方式选择
          </Typography>
          
          <Box component="ul" sx={{ pl: 2, mb: 2 }}>
            <li>
              <Typography variant="body2" color="text.secondary">
                <strong>本地文件上传：</strong>适用于内部数据资产分析
              </Typography>
            </li>
            <li>
              <Typography variant="body2" color="text.secondary">
                <strong>URL数据接入：</strong>支持外部数据源集成分析
              </Typography>
            </li>
            <li>
              <Typography variant="body2" color="text.secondary">
                <strong>配置化分析：</strong>支持历史分析配置快速调用
              </Typography>
            </li>
          </Box>

          <Box sx={{ p: 1.5, backgroundColor: 'success.light', borderRadius: 1 }}>
            <Typography variant="caption" component="div" color="success.contrastText">
              <strong>质量保障：</strong>系统自动进行数据质量预检，确保分析输入可靠性
            </Typography>
          </Box>
        </AccordionDetails>
      </Accordion>

                  {/* ... 原有的上传界面内容 */}
                </AccordionDetails>
                {/* 模式切换按钮 */}
                <Box display="flex" justifyContent="flex-end" mb={2}>
                  <Button
                    variant="outlined"
                    size="small"
                    startIcon={<SwapHorizIcon />}
                    onClick={() => setInputMode(inputMode === 'upload' ? 'url' : 'upload')}
                  >
                    {inputMode === 'upload' ? '使用文件URL' : '使用文件上传'}
                  </Button>
                </Box>

                {inputMode === 'upload' ? (
                  // 原有文件上传模式
                  <>
                    <Typography variant="h6" gutterBottom>
                      从上传数据文件开始
                    </Typography>
                    <Box display="flex" alignItems="center" gap={2} flexWrap="wrap">
                      <TextField
                        variant="outlined"
                        placeholder="选择文件"
                        value={fileName}
                        InputProps={{
                          startAdornment: (
                            <InputAdornment position="start">
                              <InsertDriveFileIcon />
                            </InputAdornment>
                          ),
                          endAdornment: (
                            <>
                              <input
                                accept=".csv,.xlsx,.json"
                                style={{ display: 'none' }}
                                id="contained-button-file"
                                type="file"
                                onChange={handleFileChange}
                              />
                              <label htmlFor="contained-button-file">
                                <Button
                                  variant="contained"
                                  component="span"
                                  startIcon={<UploadIcon />}
                                  sx={{ mr: 1 }}
                                >
                                  
                                </Button>
                              </label>
                            </>
                          ),
                        }}
                      />
                      <Button
                        variant="contained"
                        color="primary"
                        startIcon={<CloudUploadIcon />}
                        onClick={handleUpload}
                        disabled={!file || isLoading}
                      >
                        {isLoading ? '分析中...' : '上传并分析'}
                      </Button>
                    </Box>
                  </>
                ) : (
                  // URL输入模式
                  <>
                    <Typography variant="h6" gutterBottom>
                      从URL分析文件
                    </Typography>
                    <Box display="flex" alignItems="center" gap={2} flexWrap="wrap">
                      <TextField
                        variant="outlined"
                        placeholder="输入文件URL (仅支持CSV)"
                        value={fileUrl}
                        onChange={(e) => setFileUrl(e.target.value)}
                        fullWidth
                        InputProps={{
                          startAdornment: (
                            <InputAdornment position="start">
                              <LinkIcon />
                            </InputAdornment>
                          ),
                        }}
                      />
                      <Button
                        variant="contained"
                        color="primary"
                        startIcon={<CloudUploadIcon />}
                        onClick={handleUrlAnalysis}
                        disabled={!fileUrl || isLoading}
                      >
                        {isLoading ? '分析中...' : '从URL分析'}
                      </Button>
                    </Box>
                    <Typography variant="body2" color="text.secondary" sx={{ mt: 2 }}>
                      支持HTTP/HTTPS协议的CSV文件URL，文件大小建议不超过10MB
                    </Typography>
                  </>
                )}

                {previewData.length > 0 && (
                  <Box sx={{ mt: 3, border: '1px solid #e0e0e0', borderRadius: 2, overflow: 'hidden' }}>
                    <Box
                      sx={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                        p: 2,
                        backgroundColor: '#f5f5f5',
                        cursor: 'pointer',
                        '&:hover': { backgroundColor: '#eeeeee' }
                      }}
                      onClick={toggleCollapse}
                    >
                      <Typography variant="subtitle1" fontWeight="medium">
                        文件预览
                      </Typography>
                      <IconButton size="small" sx={{ p: 0 }}>
                        {isCollapsed ? <ExpandMoreIcon /> : <ExpandLessIcon />}
                      </IconButton>
                    </Box>

                    <Box
                      sx={{
                        p: 2,
                        display: isCollapsed ? 'none' : 'block',
                        height: isCollapsed ? 0 : 'auto',
                        overflow: 'hidden',
                        transition: 'height 0.3s ease-in-out'
                      }}
                    >
                      <DataTable data={previewData} title="前5行数据" />
                    </Box>
                  </Box>
                )}
              </StyledPaper>
            </AccordionDetails>
          </Accordion>
        )}
      </Box>

      {isLoading && !openConfig && (
        <Box display="flex" justifyContent="center" alignItems="center" sx={{ height: '50vh' }}>
          <Box textAlign="center">
            <CircularProgress size={60} />
            <Typography variant="h6" sx={{ mt: 2 }}>
              数据分析中，请稍候...
            </Typography>
          </Box>
        </Box>
      )}

      {analysisResult && renderAnalysisResults()}

      {/* 错误提示 */}
      <Snackbar
        open={!!error}
        autoHideDuration={6000}
        onClose={handleCloseSnackbar}
        anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
      >
        <Alert onClose={handleCloseSnackbar} severity="error" sx={{ width: '100%' }}>
          {error}
        </Alert>
      </Snackbar>

      {/* 成功提示 */}
      <Snackbar
        open={!!success}
        autoHideDuration={6000}
        onClose={handleCloseSnackbar}
        anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
      >
        <Alert onClose={handleCloseSnackbar} severity="success" sx={{ width: '100%' }}>
          {success}
        </Alert>
      </Snackbar>

      {/* 配置对话框 */}
      <Dialog open={openConfig} onClose={() => setOpenConfig(false)} fullWidth maxWidth="md">
        <DialogTitle>
          {currentAnalysisType === 'feature_importance'
            ? '配置特征重要性分析'
            : '配置PCA分析'}
        </DialogTitle>
        <DialogContent>
          <Tabs value={tabValue} onChange={(e, newValue) => setTabValue(newValue)}>
            {/* 特征重要性特有Tab */}
            {currentAnalysisType === 'feature_importance' && (
              <>
                <Tab label="目标变量 (y)" />
                <Tab label="任务类型" />
              </>
            )}
            {/* 公共Tab */}
            <Tab label="特征 (X)" />
            {/* 特征重要性特有Tab */}
            {currentAnalysisType === 'feature_importance' && (
              <Tab label="算法" />
            )}
            {/* PCA特有Tab */}
            {currentAnalysisType === 'pca' && (
              <Tab label="维度" />
            )}
            {/* 公共Tab */}
            <Tab label="忽略列" />
          </Tabs>

          {/* 特征重要性 - 目标变量Tab */}
          {currentAnalysisType === 'feature_importance' && (
            <TabPanel value={tabValue} index={0}>
              <Typography variant="subtitle2" gutterBottom>
                选择要预测的目标变量:
              </Typography>
              <ColumnSelector
                columns={allColumns}
                selected={featureSelection.target}
                onChange={(value) => setFeatureSelection({
                  ...featureSelection,
                  target: value,
                  features: featureSelection.features.filter(f => f !== value)
                })}
                multiSelect={false}
              />
            </TabPanel>
          )}

          {/* 特征重要性 - 任务类型Tab */}
          {currentAnalysisType === 'feature_importance' && (
            <TabPanel value={tabValue} index={1}>
              <Typography variant="subtitle2" gutterBottom>
                选择分析任务类型:
              </Typography>
              <FormControl component="fieldset">
                <FormLabel component="legend">任务类型</FormLabel>
                <FormGroup>
                  <FormControlLabel
                    control={
                      <Radio
                        checked={featureSelection.taskType === 'classification'}
                        onChange={() => setFeatureSelection({
                          ...featureSelection,
                          taskType: 'classification'
                        })}
                      />
                    }
                    label="分类 (预测类别)"
                  />
                  <FormControlLabel
                    control={
                      <Radio
                        checked={featureSelection.taskType === 'regression'}
                        onChange={() => setFeatureSelection({
                          ...featureSelection,
                          taskType: 'regression'
                        })}
                      />
                    }
                    label="回归 (预测数值)"
                  />
                </FormGroup>
              </FormControl>
            </TabPanel>
          )}

          {/* 特征选择Tab */}
          <TabPanel value={tabValue} index={currentAnalysisType === 'feature_importance' ? 2 : 0}>
            <Typography variant="subtitle2" gutterBottom>
              选择要包含在分析中的特征:
            </Typography>
            <ColumnSelector
              columns={allColumns.filter(col =>
                currentAnalysisType === 'feature_importance' ? col !== featureSelection.target : true
              )}
              selected={featureSelection.features}
              onChange={(values) => setFeatureSelection({
                ...featureSelection,
                features: values
              })}
              multiSelect={true}
            />
          </TabPanel>

          {/* 特征重要性 - 算法选择Tab */}
          {currentAnalysisType === 'feature_importance' && (
            <TabPanel value={tabValue} index={3}>
              <Typography variant="subtitle2" gutterBottom>
                选择特征重要性算法:
              </Typography>
              <FormControl fullWidth>
                <FormLabel>算法选择</FormLabel>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={selectedAlgorithms.includes('rf')}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setSelectedAlgorithms([...selectedAlgorithms, 'rf']);
                          } else {
                            setSelectedAlgorithms(selectedAlgorithms.filter(a => a !== 'rf'));
                          }
                        }}
                      />
                    }
                    label="随机森林"
                  />
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={selectedAlgorithms.includes('linear')}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setSelectedAlgorithms([...selectedAlgorithms, 'linear']);
                          } else {
                            setSelectedAlgorithms(selectedAlgorithms.filter(a => a !== 'linear'));
                          }
                        }}
                      />
                    }
                    label="线性模型 (线性/逻辑回归)"
                  />
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={selectedAlgorithms.includes('mi')}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setSelectedAlgorithms([...selectedAlgorithms, 'mi']);
                          } else {
                            setSelectedAlgorithms(selectedAlgorithms.filter(a => a !== 'mi'));
                          }
                        }}
                      />
                    }
                    label="互信息"
                  />
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={selectedAlgorithms.includes('tree')}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setSelectedAlgorithms([...selectedAlgorithms, 'tree']);
                          } else {
                            setSelectedAlgorithms(selectedAlgorithms.filter(a => a !== 'tree'));
                          }
                        }}
                      />
                    }
                    label="决策树"
                  />
                </div>
              </FormControl>
            </TabPanel>
          )}

          {/* PCA - 维度设置Tab */}
          {currentAnalysisType === 'pca' && (
            <TabPanel value={tabValue} index={1}>
              <Typography variant="subtitle2" gutterBottom>
                主成分数量:
              </Typography>
              <TextField
                type="number"
                value={pcaDimensions}
                onChange={(e) => setPcaDimensions(Math.max(1, Math.min(10, parseInt(e.target.value) || 3)))}
                inputProps={{ min: 1, max: 10 }}
                sx={{ width: 100 }}
              />
              <Typography variant="body2" color="text.secondary" sx={{ mt: 2 }}>
                选择要生成的主成分数量 (1-10)
              </Typography>
            </TabPanel>
          )}

          {/* 忽略列Tab */}
          <TabPanel value={tabValue} index={currentAnalysisType === 'feature_importance' ? 4 : 2}>
            <Typography variant="subtitle2" gutterBottom>
              选择在分析中忽略的列:
            </Typography>
            <ColumnSelector
              columns={allColumns.filter(col =>
                !featureSelection.features.includes(col) &&
                (currentAnalysisType !== 'feature_importance' || col !== featureSelection.target)
              )}
              selected={featureSelection.ignore}
              onChange={(values) => setFeatureSelection({
                ...featureSelection,
                ignore: values
              })}
              multiSelect={true}
            />
          </TabPanel>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenConfig(false)}>取消</Button>
          <Button
            onClick={runWithConfig}
            color="primary"
            variant="contained"
            disabled={featureSelection.features.length === 0 ||
                      (currentAnalysisType === 'feature_importance' && !featureSelection.target)}
          >
            运行分析
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default DataAnalysis;