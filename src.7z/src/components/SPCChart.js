import  { React,useState, useEffect, useCallback, useMemo } from 'react';
import {
  Box,
  Typography,
  Card,
  CardContent,
  Tabs,
  Tab,
  Grid,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Button,
  Chip,
  CircularProgress,
  TextField,
  IconButton,
  Tooltip as MuiTooltip
} from '@mui/material';
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend,
  ResponsiveContainer, ReferenceLine
} from 'recharts';
import { Download, Refresh } from '@mui/icons-material';
import axios from 'axios';

// 控制图类型
const CONTROL_CHART_TYPES = {
  XMR: 'xmr', // 单值-移动极差图
  XBAR_R: 'xbar_r', // 均值-极差图
  XBAR_S: 'xbar_s' // 均值-标准差图
};

// 控制图选项
const controlChartOptions = [
  { value: CONTROL_CHART_TYPES.XMR, label: '单值-移动极差图' },
  { value: CONTROL_CHART_TYPES.XBAR_R, label: '均值-极差图' },
  { value: CONTROL_CHART_TYPES.XBAR_S, label: '均值-标准差图' }
];

// TabPanel组件
function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`spc-tabpanel-${index}`}
      aria-labelledby={`spc-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p: 2 }}>
          {children}
        </Box>
      )}
    </div>
  );
}

const SPCChart = ({ data, processVariables, fileName, onLoading }) => {

  // 新增分片相关状态
  const [chunkIndex, setChunkIndex] = useState(0); // 当前分片索引
  const [totalPoints, setTotalPoints] = useState(0); // 总数据点数
  const [loadedPoints, setLoadedPoints] = useState(0); // 已加载点数
  const [allData, setAllData] = useState([]); // 累计所有分片数据

  // 状态管理
  const [spcDataMap, setSpcDataMap] = useState({});
  const [loading, setLoading] = useState({});
  const [activeVarIndex, setActiveVarIndex] = useState(0);
  const [filters, setFilters] = useState([]);
  const [availableColumns, setAvailableColumns] = useState([]);
  const [newFilter, setNewFilter] = useState({
    column: '',
    type: 'equals',
    value: '',
    value2: ''
  });
  const [controlChartType, setControlChartType] = useState(CONTROL_CHART_TYPES.XMR);
  const [subgroupSize, setSubgroupSize] = useState(5);
  
  // 筛选条件类型
  const filterTypes = [
    { value: 'equals', label: '等于' },
    { value: 'not_equals', label: '不等于' },
    { value: 'greater_than', label: '大于' },
    { value: 'less_than', label: '小于' },
    { value: 'greater_equals', label: '大于等于' },
    { value: 'less_equals', label: '小于等于' },
    { value: 'between', label: '在区间内' },
    { value: 'contains', label: '包含' }
  ];

  // 提取所有可用列
  useEffect(() => {
    if (data && data.length > 0) {
      const cols = Object.keys(data[0] || {});
      const filterCols = cols.filter(col => !processVariables.includes(col));
      setAvailableColumns(filterCols);
    }
  }, [data, processVariables]);

  // 获取筛选值
  const getFilterValues = useCallback((column) => {
    if (!data || !column) return [];
    const values = new Set();
    data.forEach(item => {
      if (item[column] !== undefined) {
        values.add(item[column]);
      }
    });
    return Array.from(values);
  }, [data]);

  // 筛选条件变化处理
  const handleFilterChange = (field, value) => {
    setNewFilter(prev => ({
      ...prev,
      [field]: value,
      ...((field === 'column' || field === 'type') && { value: '', value2: '' })
    }));
  };

  // 添加筛选条件
  const handleAddFilter = () => {
    if (!newFilter.column) return;
    
    if (newFilter.type === 'between' && (!newFilter.value || !newFilter.value2)) {
      alert('区间筛选需要输入两个值');
      return;
    }
    
    if (!newFilter.value && newFilter.type !== 'between') {
      alert('请输入筛选值');
      return;
    }
    
    setFilters(prev => [
      ...prev.filter(f => f.column !== newFilter.column),
      { ...newFilter }
    ]);
    
    setNewFilter({
      column: '',
      type: 'equals',
      value: '',
      value2: ''
    });
  };

  // 移除筛选条件
  const handleRemoveFilter = (column) => {
    setFilters(prev => prev.filter(f => f.column !== column));
  };

  // 获取SPC数据
  const fetchSPCData = useCallback(async (variable) => {
  // 防止重复请求
  if (loading[variable]) return;

  // 重置当前变量的加载状态和数据
  setLoading(prev => ({ ...prev, [variable]: true }));
  setSpcDataMap(prev => ({
    ...prev,
    [variable]: { ...prev[variable], isLoading: true }
  }));
  onLoading(true);

  // 分片加载参数
  let currentChunk = 0;
  const allDataPoints = [];
  let totalPoints = 0;
  let isFinished = false;

  try {
    // 循环加载所有分片
    while (!isFinished) {
      // 构造请求参数（包含当前分片索引）
      const response = await axios.post(
        `/analysis/bi/spc?chunk_index=${currentChunk}`,
        {
          file_name: fileName,
          variable_column: variable,
          subgroup_size: subgroupSize,
          chart_type: controlChartType,
          filters: filters.map(filter => ({
            column: filter.column,
            type: filter.type,
            value: filter.value,
            ...(filter.type === 'between' && { value2: filter.value2 })
          }))
        },
        {
          timeout: 30000, // 超时时间30秒
        }
      );

      if (!response.data.success) {
        throw new Error(response.data.error || '获取SPC数据失败');
      }

      // 累计数据
      allDataPoints.push(...response.data.data);
      totalPoints = response.data.total_points;
      isFinished = response.data.is_finished;

      // 更新进度状态（供UI展示）
      setSpcDataMap(prev => ({
        ...prev,
        [variable]: {
          ...response.data,
          data: [...(prev[variable]?.data || []), ...response.data.data],
          loadedPoints: response.data.loaded_points,
          totalPoints: response.data.total_points,
          isLoading: !isFinished
        }
      }));

      // 准备下一分片请求
      if (!isFinished) {
        currentChunk++;
      }
    }

    // 所有分片加载完成
    setSpcDataMap(prev => ({
      ...prev,
      [variable]: {
        ...prev[variable],
        data: allDataPoints,
        isLoading: false,
        isFinished: true
      }
    }));

  } catch (error) {
    console.error(`SPC分析错误 (${variable}):`, error);
    setSpcDataMap(prev => ({
      ...prev,
      [variable]: {
        ...prev[variable],
        error: error.response?.data?.error || error.message,
        isLoading: false
      }
    }));
    alert(`获取${variable}的SPC数据失败: ${error.response?.data?.error || error.message}`);
  } finally {
    // 无论成功失败，都更新加载状态
    setLoading(prev => ({ ...prev, [variable]: false }));
    onLoading(false);
  }
}, [fileName, subgroupSize, controlChartType, filters, onLoading]);


// console.error(`SPC分析错误 (${variable}):`, error);
//       alert(`获取${variable}的SPC数据失败: ` + (error.response?.data?.error || error.message));

  // 当过程变量、筛选条件或图表类型变化时获取数据
  useEffect(() => {
    if (!fileName || !processVariables || processVariables.length === 0) return;
    
    processVariables.forEach(variable => {
      fetchSPCData(variable);
    });
  }, [fileName, processVariables, filters, controlChartType, subgroupSize, fetchSPCData]);

  // 手动刷新数据
  const handleRefreshData = (variable) => {
    fetchSPCData(variable);
  };

  // 控制限映射
  const controlLimitsMap = useMemo(() => {
    const result = {};
    processVariables.forEach(varName => {
      const spcData = spcDataMap[varName] || {};
      const hasData = Array.isArray(spcData.data) && spcData.data.length > 0;
      result[varName] = {
        data: hasData ? spcData.data : [],
        mean: spcData.mean || 0,
        ucl: spcData.ucl || 0,
        lcl: spcData.lcl || 0,
        avgRange: spcData.avgRange || 0,
        rangeUcl: spcData.rangeUcl || 0,
        capability: spcData.Capability || null
      };
    });
    return result;
  }, [spcDataMap, processVariables]);

  // 加载状态
  if (processVariables.length === 0) {
    return (
      <Card>
        <CardContent>
          <Typography variant="body1" color="text.secondary" align="center" sx={{ py: 3 }}>
            请添加过程变量以进行SPC分析
          </Typography>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardContent>
        {/* 图表配置选项 */}
        <Grid container spacing={2} mb={3} alignItems="flex-end">
          <Grid item xs={12} md={4}>
            <FormControl fullWidth size="small">
              <InputLabel>控制图类型</InputLabel>
              <Select
                value={controlChartType}
                label="控制图类型"
                onChange={(e) => setControlChartType(e.target.value)}
              >
                {controlChartOptions.map(option => (
                  <MenuItem key={option.value} value={option.value}>{option.label}</MenuItem>
                ))}
              </Select>
            </FormControl>
          </Grid>
          
          {(controlChartType === CONTROL_CHART_TYPES.XBAR_R || 
            controlChartType === CONTROL_CHART_TYPES.XBAR_S) && (
            <Grid item xs={12} md={2}>
              <FormControl fullWidth size="small">
                <InputLabel>子组大小</InputLabel>
                <Select
                  value={subgroupSize}
                  label="子组大小"
                  onChange={(e) => setSubgroupSize(Number(e.target.value))}
                >
                  {[2, 3, 4, 5, 6, 7, 8, 9, 10].map(size => (
                    <MenuItem key={size} value={size}>{size}</MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
          )}
          
          <Grid item xs={12} md={6} />
        </Grid>
        
        {/* 筛选条件区域 */}
        <Card sx={{ mb: 3 }}>
          <CardContent>
            <Typography variant="subtitle2" gutterBottom>数据筛选:</Typography>

            <Grid container spacing={2} alignItems="flex-end" mb={2}>
              <Grid item xs={12} sm={3}>
                <FormControl fullWidth size="small">
                  <InputLabel>选择筛选列</InputLabel>
                  <Select
                    value={newFilter.column}
                    label="选择筛选列"
                    sx={{ width: 200 }} 
                    onChange={(e) => handleFilterChange('column', e.target.value)}
                  >
                    {availableColumns.map(col => (
                      <MenuItem key={col} value={col}>{col}</MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Grid>

              <Grid item xs={12} sm={2}>
                <FormControl fullWidth size="small">
                  <InputLabel>筛选类型</InputLabel>
                  <Select
                    value={newFilter.type}
                    label="筛选类型"
                    sx={{ width: 200 }} 
                    onChange={(e) => handleFilterChange('type', e.target.value)}
                    disabled={!newFilter.column}
                  >
                    {filterTypes.map(option => (
                      <MenuItem key={option.value} value={option.value}>{option.label}</MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Grid>

              <Grid item xs={12} sm={newFilter.type === 'between' ? 3 : 4}>
                <TextField
                  fullWidth
                  size="small"
                  label="值"
                  value={newFilter.value}
                  onChange={(e) => handleFilterChange('value', e.target.value)}
                  disabled={!newFilter.column}
                />
              </Grid>

              {newFilter.type === 'between' && (
                <Grid item xs={12} sm={3}>
                  <TextField
                    fullWidth
                    size="small"
                    label="到"
                    value={newFilter.value2}
                    onChange={(e) => handleFilterChange('value2', e.target.value)}
                    disabled={!newFilter.column}
                  />
                </Grid>
              )}

              <Grid item xs={12} sm={1}>
                <Button
                  variant="contained"
                  size="small"
                  fullWidth
                  onClick={handleAddFilter}
                  disabled={!newFilter.column || (!newFilter.value && newFilter.type !== 'between') || 
                           (newFilter.type === 'between' && (!newFilter.value || !newFilter.value2))}
                >
                  添加
                </Button>
              </Grid>
            </Grid>

            {/* 已选筛选条件 */}
            {filters.length > 0 && (
              <Box>
                {filters.map((filter, idx) => {
                  const filterTypeLabel = filterTypes.find(o => o.value === filter.type)?.label || filter.type;
                  let valueLabel = filter.value;
                  
                  if (filter.type === 'between') {
                    valueLabel = `${filter.value} - ${filter.value2}`;
                  }
                  
                  return (
                    <Chip
                      key={idx}
                      label={`${filter.column} ${filterTypeLabel} ${valueLabel}`}
                      size="small"
                      sx={{ mr: 1, mb: 1 }}
                      onDelete={() => handleRemoveFilter(filter.column)}
                    />
                  );
                })}
              </Box>
            )}
          </CardContent>
        </Card>

        {/* 多变量标签切换 */}
        <Tabs
          value={activeVarIndex}
          onChange={(_, index) => setActiveVarIndex(index)}
          sx={{ mb: 3 }}
          variant="scrollable"
          scrollButtons="auto"
        >
          {processVariables.map((varName, index) => (
            <Tab 
              key={varName} 
              label={varName} 
              id={`spc-tab-${index}`}
              icon={loading[varName] ? <CircularProgress size={16} /> : null}
            />
          ))}
        </Tabs>

        {/* 每个变量的SPC图表内容 */}
        {processVariables.map((varName, index) => {
          const controlLimits = controlLimitsMap[varName] || {};
          const hasData = controlLimits.data && controlLimits.data.length > 0;
          const isLoading = loading[varName] || false;

          return (
            <TabPanel key={varName} value={activeVarIndex} index={index}>
              <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
                <Typography variant="h6">SPC 控制图 - {varName}</Typography>
                <Box>
                  <MuiTooltip title="刷新数据">
                    <IconButton
                      size="small"
                      onClick={() => handleRefreshData(varName)}
                      disabled={isLoading}
                    >
                      <Refresh fontSize="small" />
                    </IconButton>
                  </MuiTooltip>
                  <MuiTooltip title="下载数据">
                    <IconButton size="small" disabled={!hasData}>
                      <Download fontSize="small" />
                    </IconButton>
                  </MuiTooltip>
                </Box>
              </Box>

              {isLoading ? (
                <Box display="flex" justifyContent="center" alignItems="center" minHeight="300px">
                  <CircularProgress />
                  <Typography variant="body1" sx={{ ml: 2 }}>正在计算SPC数据（已加载 {spcDataMap[processVariables[activeVarIndex]]?.loadedPoints || 0}/{spcDataMap[processVariables[activeVarIndex]]?.totalPoints || 0}） ）......</Typography>
                </Box>
              ) : hasData ? (
                <>
                  {/* 主控制图 */}
                  <Box height={400} mb={4}>
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={controlLimits.data} isAnimationActive={false}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                        <XAxis
                          dataKey="index"
                          name="样本"
                          tick={{ fontSize: 12 }}
                          label={{ value: '样本索引', position: 'bottom', offset: 10 }}
                        />
                        <YAxis
                          tick={{ fontSize: 12 }}
                          label={{ value: '测量值', angle: -90, position: 'left', offset: -10 }}
                        />
                        <Tooltip
                          contentStyle={{ backgroundColor: 'white', border: '1px solid #ccc' }}
                          formatter={(value, name) => {
                            switch(name) {
                              case 'value': return [value.toFixed(4), '测量值'];
                              case 'mean': return [value.toFixed(4), '均值'];
                              case 'ucl': return [value.toFixed(4), '上控制限'];
                              case 'lcl': return [value.toFixed(4), '下控制限'];
                              default: return [value, name];
                            }
                          }}
                        />
                        <Legend />
                        
                        <ReferenceLine y={controlLimits.ucl} stroke="#ff4081" strokeDasharray="3 3" />
                        <ReferenceLine y={controlLimits.lcl} stroke="#ff4081" strokeDasharray="3 3" />
                        <ReferenceLine y={controlLimits.mean} stroke="#82ca9d" strokeDasharray="5 5" />
                        
                        <Line
                          type="monotone"
                          dataKey="value"
                          name="测量值"
                          stroke="#8884d8"
                          strokeWidth={2}
                          dot={{ r: 3 }}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </Box>
                  
                  {/* 极差图 */}
                  {(controlChartType === CONTROL_CHART_TYPES.XMR || 
                    controlChartType === CONTROL_CHART_TYPES.XBAR_R) && (
                    <Box height={300} mb={4}>
                      <Typography variant="subtitle1" gutterBottom>
                        {controlChartType === CONTROL_CHART_TYPES.XMR ? '移动极差图' : '极差图'}
                      </Typography>
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={controlLimits.data.slice(1)} isAnimationActive={false}>
                          <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                          <XAxis
                            dataKey="index"
                            name="样本"
                            tick={{ fontSize: 12 }}
                          />
                          <YAxis
                            tick={{ fontSize: 12 }}
                            label={{ value: '极差', angle: -90, position: 'left', offset: -10 }}
                          />
                          <Tooltip
                            formatter={(value) => [value.toFixed(4), '极差']}
                          />
                          <Legend />
                          
                          <ReferenceLine y={controlLimits.rangeUcl} stroke="#ff4081" strokeDasharray="3 3" />
                          <ReferenceLine y={controlLimits.avgRange} stroke="#82ca9d" strokeDasharray="5 5" />
                          
                          <Line
                            type="monotone"
                            dataKey="range"
                            name="极差"
                            stroke="#ff8042"
                            dot={{ r: 3 }}
                          />
                        </LineChart>
                      </ResponsiveContainer>
                    </Box>
                  )}
                  
                  {/* SPC统计指标 */}
                  <Grid container spacing={2} sx={{ mt: 3 }}>
                    <Grid item xs={12} sm={3}>
                      <Typography variant="body2">
                        <strong>数据点数量:</strong> {controlLimits.data.length}
                      </Typography>
                    </Grid>
                    <Grid item xs={12} sm={3}>
                      <Typography variant="body2">
                        <strong>均值 (μ):</strong> {controlLimits.mean.toFixed(4)}
                      </Typography>
                    </Grid>
                    <Grid item xs={12} sm={3}>
                      <Typography variant="body2">
                        <strong>上控制限 (UCL):</strong> {controlLimits.ucl.toFixed(4)}
                      </Typography>
                    </Grid>
                    <Grid item xs={12} sm={3}>
                      <Typography variant="body2">
                        <strong>下控制限 (LCL):</strong> {controlLimits.lcl.toFixed(4)}
                      </Typography>
                    </Grid>
                    
                    {(controlChartType === CONTROL_CHART_TYPES.XMR || 
                      controlChartType === CONTROL_CHART_TYPES.XBAR_R) && (
                      <>
                        <Grid item xs={12} sm={3}>
                          <Typography variant="body2">
                            <strong>平均极差:</strong> {controlLimits.avgRange.toFixed(4)}
                          </Typography>
                        </Grid>
                        <Grid item xs={12} sm={3}>
                          <Typography variant="body2">
                            <strong>极差上控制限:</strong> {controlLimits.rangeUcl.toFixed(4)}
                          </Typography>
                        </Grid>
                      </>
                    )}
                  </Grid>
                  
                  {/* 过程能力分析 */}
                  {controlLimits.capability && (
                    <Box mt={4} p={2} border="1px solid #e0e0e0" borderRadius={1}>
                      <Typography variant="subtitle1" gutterBottom>过程能力分析</Typography>
                      <Grid container spacing={2}>
                        <Grid item xs={12} sm={3}>
                          <Typography variant="body2">
                            <strong>Cp:</strong> {controlLimits.capability.Cp.toFixed(4)}
                          </Typography>
                        </Grid>
                        <Grid item xs={12} sm={3}>
                          <Typography variant="body2">
                            <strong>Cpk:</strong> {controlLimits.capability.Cpk.toFixed(4)}
                          </Typography>
                        </Grid>
                        <Grid item xs={12} sm={3}>
                          <Typography variant="body2">
                            <strong>Pp:</strong> {controlLimits.capability.Pp.toFixed(4)}
                          </Typography>
                        </Grid>
                        <Grid item xs={12} sm={3}>
                          <Typography variant="body2">
                            <strong>Ppk:</strong> {controlLimits.capability.Ppk.toFixed(4)}
                          </Typography>
                        </Grid>
                      </Grid>
                    </Box>
                  )}
                </>
              ) : (
                <Box display="flex" justifyContent="center" alignItems="center" minHeight="300px">
                  <Typography variant="body1" color="text.secondary">
                    没有"{varName}"的可用数据，请调整筛选条件
                  </Typography>
                </Box>
              )}
            </TabPanel>
          );
        })}
      </CardContent>
    </Card>
  );
};

export default SPCChart;

// import React, { useState, useEffect, useCallback, useMemo } from 'react';
// import {
//   Box,
//   Typography,
//   Card,
//   CardContent,
//   Tabs,
//   Tab,
//   Grid,
//   FormControl,
//   InputLabel,
//   Select,
//   MenuItem,
//   Button,
//   Chip,
//   CircularProgress,
//   TextField,
//   IconButton,
//   Tooltip as MuiTooltip
// } from '@mui/material';
// import {
//   LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend,
//   ResponsiveContainer, ReferenceLine
// } from 'recharts';
// import { Download, Refresh } from '@mui/icons-material';
// import axios from 'axios';

// // 控制图类型
// const CONTROL_CHART_TYPES = {
//   XMR: 'xmr', // 单值-移动极差图
//   XBAR_R: 'xbar_r', // 均值-极差图
//   XBAR_S: 'xbar_s' // 均值-标准差图
// };

// // 控制图选项
// const controlChartOptions = [
//   { value: CONTROL_CHART_TYPES.XMR, label: '单值-移动极差图' },
//   { value: CONTROL_CHART_TYPES.XBAR_R, label: '均值-极差图' },
//   { value: CONTROL_CHART_TYPES.XBAR_S, label: '均值-标准差图' }
// ];

// // TabPanel组件，用于Tabs内容展示
// function TabPanel(props) {
//   const { children, value, index, ...other } = props;

//   return (
//     <div
//       role="tabpanel"
//       hidden={value !== index}
//       id={`spc-tabpanel-${index}`}
//       aria-labelledby={`spc-tab-${index}`}
//       {...other}
//     >
//       {value === index && (
//         <Box sx={{ p: 2 }}>
//           {children}
//         </Box>
//       )}
//     </div>
//   );
// }

// // 计算控制限的辅助函数


// // 提取控制限数据的工具函数（移到组件外部或顶层）

// const SPCChart = ({ data, processVariables, fileName, onLoading }) => {
//   // 状态管理
//   const [spcDataMap, setSpcDataMap] = useState({});  // 存储多个变量的SPC数据
//   const [loading, setLoading] = useState({}); // 每个变量的加载状态
//   const [activeVarIndex, setActiveVarIndex] = useState(0);
//   const [filters, setFilters] = useState([]);
//   const [availableColumns, setAvailableColumns] = useState([]);
//   const [newFilter, setNewFilter] = useState({
//     column: '',
//     type: 'equals',
//     value: '',
//     value2: ''
//   });
//   const [controlChartType, setControlChartType] = useState(CONTROL_CHART_TYPES.XMR);
//   const [subgroupSize, setSubgroupSize] = useState(5);
  
//   // 筛选条件类型
//   const filterTypes = [
//     { value: 'equals', label: '等于' },
//     { value: 'not_equals', label: '不等于' },
//     { value: 'greater_than', label: '大于' },
//     { value: 'less_than', label: '小于' },
//     { value: 'greater_equals', label: '大于等于' },
//     { value: 'less_equals', label: '小于等于' },
//     { value: 'between', label: '在区间内' },
//     { value: 'contains', label: '包含' }
//   ];

//   // 提取所有可用列（排除当前分析的变量列）
//   useEffect(() => {
//     if (data && data.length > 0) {
//       const cols = Object.keys(data[0] || {});
//       // 排除所有过程变量列
//       const filterCols = cols.filter(col => !processVariables.includes(col));
//       setAvailableColumns(filterCols);
//     }
//   }, [data, processVariables]);

//   // 获取筛选值
//   const getFilterValues = useCallback((column) => {
//     if (!data || !column) return [];
//     const values = new Set();
//     data.forEach(item => {
//       if (item[column] !== undefined) {
//         values.add(item[column]);
//       }
//     });
//     return Array.from(values);
//   }, [data]);

//   // 当选择筛选列变化时更新筛选值
//   const handleFilterChange = (field, value) => {
//     setNewFilter(prev => ({
//       ...prev,
//       [field]: value,
//       ...((field === 'column' || field === 'type') && { value: '', value2: '' })
//     }));
//   };

//   // 添加筛选条件
//   const handleAddFilter = () => {
//     if (!newFilter.column) return;
    
//     // 验证筛选值
//     if (newFilter.type === 'between' && (!newFilter.value || !newFilter.value2)) {
//       alert('区间筛选需要输入两个值');
//       return;
//     }
    
//     if (!newFilter.value && newFilter.type !== 'between') {
//       alert('请输入筛选值');
//       return;
//     }
    
//     // 添加新筛选条件，替换同列的旧筛选
//     setFilters(prev => [
//       ...prev.filter(f => f.column !== newFilter.column),
//       { ...newFilter }
//     ]);
    
//     // 重置筛选表单
//     setNewFilter({
//       column: '',
//       type: 'equals',
//       value: '',
//       value2: ''
//     });
//   };

//   // 移除筛选条件
//   const handleRemoveFilter = (column) => {
//     setFilters(prev => prev.filter(f => f.column !== column));
//   };

//   // 获取SPC数据 - 优化：只在必要时请求，避免重复请求
//   const fetchSPCData = useCallback(async (variable) => {
//     // 如果已有数据且没有筛选条件变化，不重新请求
//     if (spcDataMap[variable] && !filters.some(f => 
//       spcDataMap[variable].filters?.find(of => 
//         of.column === f.column && of.type === f.type && of.value === f.value && of.value2 === f.value2
//       ) === undefined
//     )) {
//       return;
//     }
    
//     setLoading(prev => ({ ...prev, [variable]: true }));
//     onLoading(true);
    
//     try {
//       // 转换筛选条件格式
//       const formattedFilters = filters.map(filter => {
//         const result = {
//           column: filter.column,
//           type: filter.type,
//           value: filter.value
//         };
        
//         if (filter.type === 'between') {
//           result.value2 = filter.value2;
//         }
        
//         return result;
//       });
      
//       const response = await axios.post('/analysis/bi/spc', {
//         file_name: fileName,
//         variable_column: variable,
//         subgroup_size: subgroupSize,
//         chart_type: controlChartType,
//         filters: formattedFilters
//       });

//       if (response.data.success) {
//         setSpcDataMap(prev => ({
//           ...prev,
//           [variable]: {
//             ...response.data,
//            data: response.data.data, // 显式保存小写data字段
//            filters: formattedFilters
//           }
//         }));
//       }
//     } catch (error) {
//       console.error(`SPC分析错误 (${variable}):`, error);
//       alert(`获取${variable}的SPC数据失败: ` + (error.response?.data?.error || error.message));
//     } finally {
//       setLoading(prev => ({ ...prev, [variable]: false }));
//       onLoading(false);
//     }
//   }, [fileName, subgroupSize, controlChartType, filters, spcDataMap, onLoading]);

//   // 当过程变量、筛选条件或图表类型变化时获取数据
//   useEffect(() => {
//     if (!fileName || !processVariables || processVariables.length === 0) return;
    
//     // 为每个变量获取SPC数据
//     processVariables.forEach(variable => {
//       fetchSPCData(variable);
//     });
//   }, [fileName, processVariables, filters, controlChartType, subgroupSize, fetchSPCData]);

//   // 手动刷新数据
//   const handleRefreshData = (variable) => {
//     fetchSPCData(variable);
//   };

//   // 检查是否有有效的SPC数据
//   const hasValidData = useMemo(() => 
//   processVariables.some(varName => {
//     const spcData = spcDataMap[varName] || {};
//     return Array.isArray(spcData.data) && spcData.data.length > 0; // 小写data
//   }), [processVariables, spcDataMap]
// );

//   // 计算所有变量的控制限（移到循环外部，使用useMemo缓存）
//  const controlLimitsMap = useMemo(() => {
//   const result = {};
//   processVariables.forEach(varName => {
//     const spcData = spcDataMap[varName] || {};
//     // 关键：使用小写data字段
//     const hasData = Array.isArray(spcData.data) && spcData.data.length > 0; 
//     if (hasData) {
//       result[varName] = {
//         data: spcData.data, // 小写data
//         mean: spcData.mean,
//         ucl: spcData.ucl,
//         lcl: spcData.lcl,
//         avgRange: spcData.avgRange || 0,
//         rangeUcl: spcData.rangeUcl || 0
//       };
//     } else {
//       result[varName] = { data: [], mean: 0, ucl: 0, lcl: 0, avgRange: 0, rangeUcl: 0 };
//     }
//   });
//   return result;
// }, [spcDataMap, processVariables]);

//   // 加载状态
//   if (processVariables.length === 0) {
//     return (
//       <Card>
//         <CardContent>
//           <Typography variant="body1" color="text.secondary" align="center" sx={{ py: 3 }}>
//             请添加过程变量以进行SPC分析
//           </Typography>
//         </CardContent>
//       </Card>
//     );
//   }

//   return (
//     <Card>
//       <CardContent>
//         {/* 图表配置选项 */}
//         <Grid container spacing={2} mb={3} alignItems="flex-end">
//           <Grid item xs={12} md={4}>
//             <FormControl fullWidth size="small">
//               <InputLabel>控制图类型</InputLabel>
//               <Select
//                 value={controlChartType}
//                 label="控制图类型"
//                 onChange={(e) => setControlChartType(e.target.value)}
//               >
//                 {controlChartOptions.map(option => (
//                   <MenuItem key={option.value} value={option.value}>{option.label}</MenuItem>
//                 ))}
//               </Select>
//             </FormControl>
//           </Grid>
          
//           {(controlChartType === CONTROL_CHART_TYPES.XBAR_R || 
//             controlChartType === CONTROL_CHART_TYPES.XBAR_S) && (
//             <Grid item xs={12} md={2}>
//               <FormControl fullWidth size="small">
//                 <InputLabel>子组大小</InputLabel>
//                 <Select
//                   value={subgroupSize}
//                   label="子组大小"
//                   onChange={(e) => setSubgroupSize(Number(e.target.value))}
//                 >
//                   {[2, 3, 4, 5, 6, 7, 8, 9, 10].map(size => (
//                     <MenuItem key={size} value={size}>{size}</MenuItem>
//                   ))}
//                 </Select>
//               </FormControl>
//             </Grid>
//           )}
          
//           <Grid item xs={12} md={6} />
//         </Grid>
        
//         {/* 筛选条件区域 */}
//         <Card sx={{ mb: 3 }}>
//           <CardContent>
//             <Typography variant="subtitle2" gutterBottom>数据筛选:</Typography>

//             <Grid container spacing={2} alignItems="flex-end" mb={2}>
//               <Grid item xs={12} sm={3}>
//                 <FormControl fullWidth size="small">
//                   <InputLabel>选择筛选列</InputLabel>
//                   <Select
//                     value={newFilter.column}
//                     label="选择筛选列"
//                     sx={{ width: 200 }}
//                     onChange={(e) => handleFilterChange('column', e.target.value)}
//                   >
//                     {availableColumns.map(col => (
//                       <MenuItem key={col} value={col}>{col}</MenuItem>
//                     ))}
//                   </Select>
//                 </FormControl>
//               </Grid>

//               <Grid item xs={12} sm={2}>
//                 <FormControl fullWidth size="small">
//                   <InputLabel>筛选类型</InputLabel>
//                   <Select
//                     value={newFilter.type}
//                     label="筛选类型"
//                     sx={{ width: 100 }}
//                     onChange={(e) => handleFilterChange('type', e.target.value)}
//                     disabled={!newFilter.column}
//                   >
//                     {filterTypes.map(option => (
//                       <MenuItem key={option.value} value={option.value}>{option.label}</MenuItem>
//                     ))}
//                   </Select>
//                 </FormControl>
//               </Grid>

//               <Grid item xs={12} sm={newFilter.type === 'between' ? 3 : 4}>
//                 <TextField
//                   fullWidth
//                   size="small"
//                   label="值"
//                   value={newFilter.value}
//                   onChange={(e) => handleFilterChange('value', e.target.value)}
//                   disabled={!newFilter.column}
//                 />
//               </Grid>

//               {newFilter.type === 'between' && (
//                 <Grid item xs={12} sm={3}>
//                   <TextField
//                     fullWidth
//                     size="small"
//                     label="到"
//                     value={newFilter.value2}
//                     onChange={(e) => handleFilterChange('value2', e.target.value)}
//                     disabled={!newFilter.column}
//                   />
//                 </Grid>
//               )}

//               <Grid item xs={12} sm={1}>
//                 <Button
//                   variant="contained"
//                   size="small"
//                   fullWidth
//                   onClick={handleAddFilter}
//                   disabled={!newFilter.column || (!newFilter.value && newFilter.type !== 'between') || 
//                            (newFilter.type === 'between' && (!newFilter.value || !newFilter.value2))}
//                 >
//                   添加
//                 </Button>
//               </Grid>
//             </Grid>

//             {/* 已选筛选条件 */}
//             {filters.length > 0 && (
//               <Box>
//                 {filters.map((filter, idx) => {
//                   const filterTypeLabel = filterTypes.find(o => o.value === filter.type)?.label || filter.type;
//                   let valueLabel = filter.value;
                  
//                   if (filter.type === 'between') {
//                     valueLabel = `${filter.value} - ${filter.value2}`;
//                   }
                  
//                   return (
//                     <Chip
//                       key={idx}
//                       label={`${filter.column} ${filterTypeLabel} ${valueLabel}`}
//                       size="small"
//                       sx={{ mr: 1, mb: 1 }}
//                       onDelete={() => handleRemoveFilter(filter.column)}
//                     />
//                   );
//                 })}
//               </Box>
//             )}
//           </CardContent>
//         </Card>

//         {/* 多变量标签切换 */}
//         <Tabs
//           value={activeVarIndex}
//           onChange={(_, index) => setActiveVarIndex(index)}
//           sx={{ mb: 3 }}
//           variant="scrollable"
//           scrollButtons="auto"
//         >
//           {processVariables.map((varName, index) => (
//             <Tab 
//               key={varName} 
//               label={varName} 
//               id={`spc-tab-${index}`}
//               icon={loading[varName] ? <CircularProgress size={16} /> : null}
//             />
//           ))}
//         </Tabs>

//         {/* 每个变量的SPC图表内容 */}
//         {processVariables.map((varName, index) => {
//           const spcData = spcDataMap[varName] || {};
//           const hasData = controlLimits.data && controlLimits.data.length > 0;
//           const isLoading = loading[varName] || false;
//           // 从缓存的控制限映射中获取当前变量的控制限
//           const controlLimits = controlLimitsMap[varName];

//           return (
//             <TabPanel key={varName} value={activeVarIndex} index={index}>
//               <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
//                 <Typography variant="h6">SPC 控制图 - {varName}</Typography>
//                 <Box>
//                   <MuiTooltip title="刷新数据">
//                     <IconButton
//                       size="small"
//                       onClick={() => handleRefreshData(varName)}
//                       disabled={isLoading}
//                     >
//                       <Refresh fontSize="small" />
//                     </IconButton>
//                   </MuiTooltip>
//                   <MuiTooltip title="下载数据">
//                     <IconButton size="small" disabled={!hasData}>
//                       <Download fontSize="small" />
//                     </IconButton>
//                   </MuiTooltip>
//                 </Box>
//               </Box>

//               {/* 图表显示区域 */}
//               {isLoading ? (
//                 <Box display="flex" justifyContent="center" alignItems="center" minHeight="300px">
//                   <CircularProgress />
//                   <Typography variant="body1" sx={{ ml: 2 }}>正在计算SPC数据...</Typography>
//                 </Box>
//               ) : hasData ? (
//                 <>
//                   {/* 主控制图 */}
//                   <Box height={400} mb={4}>
//                     <ResponsiveContainer width="100%" height="100%">
//                       <LineChart data={controlLimits.data}>
//                         <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
//                         <XAxis
//                           dataKey="index"
//                           name="样本"
//                           tick={{ fontSize: 12 }}
//                           label={{ value: '样本索引', position: 'bottom', offset: 10 }}
//                         />
//                         <YAxis
//                           tick={{ fontSize: 12 }}
//                           label={{ value: '测量值', angle: -90, position: 'left', offset: -10 }}
//                         />
//                         <Tooltip
//                           contentStyle={{ backgroundColor: 'white', border: '1px solid #ccc' }}
//                           formatter={(value, name) => {
//                             switch(name) {
//                               case 'value': return [value.toFixed(4), '测量值'];
//                               case 'mean': return [value.toFixed(4), '均值'];
//                               case 'ucl': return [value.toFixed(4), '上控制限'];
//                               case 'lcl': return [value.toFixed(4), '下控制限'];
//                               default: return [value, name];
//                             }
//                           }}
//                         />
//                         <Legend />
                        
//                         {/* 警戒线 - 超出控制限时显示为红色 */}
//                         <ReferenceLine y={controlLimits.ucl} stroke="#ff4081" strokeDasharray="3 3" />
//                         <ReferenceLine y={controlLimits.lcl} stroke="#ff4081" strokeDasharray="3 3" />
//                         <ReferenceLine y={controlLimits.mean} stroke="#82ca9d" strokeDasharray="5 5" />
                        
//                         <Line
//                           type="monotone"
//                           dataKey="value" // 与后端返回的"value"字段匹配
//                           name="测量值"
//                           stroke="#8884d8"
//                           strokeWidth={2}
//                         />
//                       </LineChart>
//                     </ResponsiveContainer>
//                   </Box>
                  
//                   {/* 极差/标准差图 (对于Xbar-R和Xbar-S图) */}
//                   {(controlChartType === CONTROL_CHART_TYPES.XMR || 
//                     controlChartType === CONTROL_CHART_TYPES.XBAR_R) && (
//                     <Box height={300} mb={4}>
//                       <Typography variant="subtitle1" gutterBottom>
//                         {controlChartType === CONTROL_CHART_TYPES.XMR ? '移动极差图' : '极差图'}
//                       </Typography>
//                       <ResponsiveContainer width="100%" height="100%">
//                         <LineChart data={controlLimits.data.slice(1)}>
//                           <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
//                           <XAxis
//                             dataKey="index"
//                             name="样本"
//                             tick={{ fontSize: 12 }}
//                           />
//                           <YAxis
//                             tick={{ fontSize: 12 }}
//                             label={{ value: '极差', angle: -90, position: 'left', offset: -10 }}
//                           />
//                           <Tooltip
//                             formatter={(value) => [value.toFixed(4), '极差']}
//                           />
//                           <Legend />
                          
//                           <ReferenceLine y={controlLimits.rangeUcl} stroke="#ff4081" strokeDasharray="3 3" />
//                           <ReferenceLine y={controlLimits.avgRange} stroke="#82ca9d" strokeDasharray="5 5" />
                          
//                           <Line
//                               type="monotone"
//                               dataKey="range" // 确保后端数据中有"range"字段
//                               name="极差"
//                               stroke="#ff8042"
//                             />
//                         </LineChart>
//                       </ResponsiveContainer>
//                     </Box>
//                   )}
                  
//                   {/* SPC统计指标 */}
//                   <Grid container spacing={2} sx={{ mt: 3 }}>
//                     <Grid item xs={12} sm={3}>
//                       <Typography variant="body2">
//                         <strong>数据点数量:</strong> {spcData.Data.length}
//                       </Typography>
//                     </Grid>
//                     <Grid item xs={12} sm={3}>
//                       <Typography variant="body2">
//                         <strong>均值 (μ):</strong> {controlLimits.mean.toFixed(4)}
//                       </Typography>
//                     </Grid>
//                     <Grid item xs={12} sm={3}>
//                       <Typography variant="body2">
//                         <strong>上控制限 (UCL):</strong> {controlLimits.ucl.toFixed(4)}
//                       </Typography>
//                     </Grid>
//                     <Grid item xs={12} sm={3}>
//                       <Typography variant="body2">
//                         <strong>下控制限 (LCL):</strong> {controlLimits.lcl.toFixed(4)}
//                       </Typography>
//                     </Grid>
                    
//                     {(controlChartType === CONTROL_CHART_TYPES.XMR || 
//                       controlChartType === CONTROL_CHART_TYPES.XBAR_R) && (
//                       <>
//                         <Grid item xs={12} sm={3}>
//                           <Typography variant="body2">
//                             <strong>平均极差:</strong> {controlLimits.avgRange.toFixed(4)}
//                           </Typography>
//                         </Grid>
//                         <Grid item xs={12} sm={3}>
//                           <Typography variant="body2">
//                             <strong>极差上控制限:</strong> {controlLimits.rangeUcl.toFixed(4)}
//                           </Typography>
//                         </Grid>
//                       </>
//                     )}
//                   </Grid>
                  
//                   {/* 过程能力分析 */}
//                   {spcData.Capability && (
//                     <Box mt={4} p={2} border="1px solid #e0e0e0" borderRadius={1}>
//                       <Typography variant="subtitle1" gutterBottom>过程能力分析</Typography>
//                       <Grid container spacing={2}>
//                         <Grid item xs={12} sm={3}>
//                           <Typography variant="body2">
//                             <strong>Cp:</strong> {spcData.Capability.Cp.toFixed(4)}
//                           </Typography>
//                         </Grid>
//                         <Grid item xs={12} sm={3}>
//                           <Typography variant="body2">
//                             <strong>Cpk:</strong> {spcData.Capability.Cpk.toFixed(4)}
//                           </Typography>
//                         </Grid>
//                         <Grid item xs={12} sm={3}>
//                           <Typography variant="body2">
//                             <strong>Pp:</strong> {spcData.Capability.Pp.toFixed(4)}
//                           </Typography>
//                         </Grid>
//                         <Grid item xs={12} sm={3}>
//                           <Typography variant="body2">
//                             <strong>Ppk:</strong> {spcData.Capability.Ppk.toFixed(4)}
//                           </Typography>
//                         </Grid>
//                       </Grid>
//                     </Box>
//                   )}
//                 </>
//               ) : (
//                 <Box display="flex" justifyContent="center" alignItems="center" minHeight="300px">
//                   <Typography variant="body1" color="text.secondary">
//                     没有"{varName}"的可用数据，请调整筛选条件
//                   </Typography>
//                 </Box>
//               )}
//             </TabPanel>
//           )})}
//         </CardContent>
//       </Card>
//     );
// };

// export default SPCChart;
